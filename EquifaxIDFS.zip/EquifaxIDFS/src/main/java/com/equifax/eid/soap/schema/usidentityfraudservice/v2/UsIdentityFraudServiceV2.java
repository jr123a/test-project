package com.equifax.eid.soap.schema.usidentityfraudservice.v2;

import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebEndpoint;
import javax.xml.ws.WebServiceClient;
import javax.xml.ws.WebServiceFeature;

@WebServiceClient(name = "usIdentityFraudServiceV2", 
    targetNamespace = "http://eid.equifax.com/soap/schema/usidentityfraudservice/v2/wsdl", 
    wsdlLocation = "usidentityfraudservicev2.wsdl")
public class UsIdentityFraudServiceV2 extends Service
{

    private static final String WSDL_NAME = "usidentityfraudservicev2.wsdl";
	private static final String URL = "http://eid.equifax.com/soap/schema/usidentityfraudservice/v2/wsdl";
	public static final URL WSDL_LOCATION;
    public static final QName SERVICE = new QName(URL, "usIdentityFraudServiceV2");
    public static final QName US_IDENTITY_FRAUD_SERVICE_TYPE_V2 = new QName(URL, "UsIdentityFraudServiceTypeV2");

    static {
        URL url = UsIdentityFraudServiceV2.class.getResource(WSDL_NAME);
        if (url == null) {
            url = UsIdentityFraudServiceV2.class.getClassLoader().getResource(WSDL_NAME);
        } 
        if (url == null) {
            java.util.logging.Logger.getLogger(UsIdentityFraudServiceV2.class.getName())
                .log(java.util.logging.Level.INFO, 
                     "Can not initialize the default wsdl from {0}", WSDL_NAME);
        }       
        WSDL_LOCATION = url;
    }
    
    public UsIdentityFraudServiceV2() {
        super(WSDL_LOCATION, SERVICE);
    }

    public UsIdentityFraudServiceV2(URL wsdlLocation) {
        super(wsdlLocation, SERVICE);
    }

    public UsIdentityFraudServiceV2(URL wsdlLocation, QName serviceName) {
        super(wsdlLocation, serviceName);
    }

    /**
     * 
     * @return
     *     returns UsIdentityFraudServiceTypeV2
     */
    @WebEndpoint(name = "usIdentityFraudServiceHttpPort")
    public UsIdentityFraudServiceTypeV2 getUsIdentityFraudServiceHttpPort() {
        return super.getPort(new QName(URL, "usIdentityFraudServiceHttpPort"), UsIdentityFraudServiceTypeV2.class);
    }

    /**
     * 
     * @param features
     *     A list of {@link javax.xml.ws.WebServiceFeature} to configure on the proxy.  Supported features not in the <code>features</code> parameter will have their default values.
     * @return
     *     returns UsIdentityFraudServiceTypeV2
     */
    @WebEndpoint(name = "usIdentityFraudServiceHttpPort")
    public UsIdentityFraudServiceTypeV2 getUsIdentityFraudServiceHttpPort(WebServiceFeature... features) {
        return super.getPort(new QName(URL, "usIdentityFraudServiceHttpPort"), UsIdentityFraudServiceTypeV2.class, features);
    }


}
