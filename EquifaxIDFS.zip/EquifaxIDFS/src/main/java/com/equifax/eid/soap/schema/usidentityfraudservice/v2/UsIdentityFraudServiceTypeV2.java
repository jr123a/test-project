
package com.equifax.eid.soap.schema.usidentityfraudservice.v2;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;

@WebService(name = "usIdentityFraudServiceTypeV2", targetNamespace = "http://eid.equifax.com/soap/schema/usidentityfraudservice/v2/wsdl")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
@XmlSeeAlso({
    com.equifax.eid.soap.schema.usidentityfraudservice.v2.ObjectFactory.class,
    com.equifax.eid.soap.schema.identityfraudservice.v2.ObjectFactory.class
})
public interface UsIdentityFraudServiceTypeV2 {


    /**
     * 
     * @param initialRequest
     * @return
     *     returns com.equifax.eid.soap.schema.usidentityfraudservice.v2.InitialResponse
     * @throws CredentialsErrorFault
     * @throws ValidationErrorFault
     */
    @WebMethod
    @WebResult(name = "InitialResponse", targetNamespace = "http://eid.equifax.com/soap/schema/usidentityfraudservice/v2", partName = "InitialResponse")
    public InitialResponse submit(
        @WebParam(name = "InitialRequest", targetNamespace = "http://eid.equifax.com/soap/schema/usidentityfraudservice/v2", partName = "InitialRequest")
        InitialRequest initialRequest)
        throws CredentialsErrorFault, ValidationErrorFault
    ;

    /**
     * 
     * @param subsequentRequest
     * @return
     *     returns com.equifax.eid.soap.schema.usidentityfraudservice.v2.SubsequentResponse
     * @throws InvalidTransactionKeyFault
     * @throws CredentialsErrorFault
     * @throws ValidationErrorFault
     */
    @WebMethod
    @WebResult(name = "SubsequentResponse", targetNamespace = "http://eid.equifax.com/soap/schema/usidentityfraudservice/v2", partName = "SubsequentResponse")
    public SubsequentResponse resubmit(
        @WebParam(name = "SubsequentRequest", targetNamespace = "http://eid.equifax.com/soap/schema/usidentityfraudservice/v2", partName = "SubsequentRequest")
        SubsequentRequest subsequentRequest)
        throws CredentialsErrorFault, InvalidTransactionKeyFault, ValidationErrorFault
    ;

    /**
     * 
     * @param pollRequest
     * @return
     *     returns com.equifax.eid.soap.schema.usidentityfraudservice.v2.PollResponse
     * @throws CredentialsErrorFault
     * @throws InvalidTransactionKeyFault
     * @throws ValidationErrorFault
     */
    @WebMethod
    @WebResult(name = "PollResponse", targetNamespace = "http://eid.equifax.com/soap/schema/usidentityfraudservice/v2", partName = "PollResponse")
    public PollResponse poll(
        @WebParam(name = "PollRequest", targetNamespace = "http://eid.equifax.com/soap/schema/usidentityfraudservice/v2", partName = "PollRequest")
        PollRequest pollRequest)
        throws CredentialsErrorFault, InvalidTransactionKeyFault, ValidationErrorFault
    ;

}
