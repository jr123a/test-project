package com.equifax.eid.soap.schema.usidentityfraudservice.v2;

import javax.xml.ws.WebFault;

@WebFault(name = "ValidationErrorFault", targetNamespace = "http://eid.equifax.com/soap/schema/identityfraudservice/v2")
public class ValidationErrorFault
    extends Exception
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    /**
     * Java type that goes as soapenv:Fault detail element.
     * 
     */
    private com.equifax.eid.soap.schema.identityfraudservice.v2.ValidationErrorFault faultInfo;

    /**
     * 
     * @param message
     * @param faultInfo
     */
    public ValidationErrorFault(String message, com.equifax.eid.soap.schema.identityfraudservice.v2.ValidationErrorFault faultInfo) {
        super(message);
        this.faultInfo = faultInfo;
    }

    /**
     * 
     * @param message
     * @param faultInfo
     * @param cause
     */
    public ValidationErrorFault(String message, com.equifax.eid.soap.schema.identityfraudservice.v2.ValidationErrorFault faultInfo, Throwable cause) {
        super(message, cause);
        this.faultInfo = faultInfo;
    }

    /**
     * 
     * @return
     *     returns fault bean: com.equifax.eid.soap.schema.identityfraudservice.v2.ValidationErrorFault
     */
    public com.equifax.eid.soap.schema.identityfraudservice.v2.ValidationErrorFault getFaultInfo() {
        return faultInfo;
    }

}
