package com.equifax.eid.soap.schema.usidentityfraudservice.v2;

import javax.xml.ws.WebFault;

@WebFault(name = "CredentialsErrorFault", targetNamespace = "http://eid.equifax.com/soap/schema/identityfraudservice/v2")
public class CredentialsErrorFault
    extends Exception
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    /**
     * Java type that goes as soapenv:Fault detail element.
     * 
     */
    private com.equifax.eid.soap.schema.identityfraudservice.v2.CredentialsErrorFault faultInfo;

    /**
     * 
     * @param message
     * @param faultInfo
     */
    public CredentialsErrorFault(String message, com.equifax.eid.soap.schema.identityfraudservice.v2.CredentialsErrorFault faultInfo) {
        super(message);
        this.faultInfo = faultInfo;
    }

    /**
     * 
     * @param message
     * @param faultInfo
     * @param cause
     */
    public CredentialsErrorFault(String message, com.equifax.eid.soap.schema.identityfraudservice.v2.CredentialsErrorFault faultInfo, Throwable cause) {
        super(message, cause);
        this.faultInfo = faultInfo;
    }

    /**
     * 
     * @return
     *     returns fault bean: com.equifax.eid.soap.schema.identityfraudservice.v2.CredentialsErrorFault
     */
    public com.equifax.eid.soap.schema.identityfraudservice.v2.CredentialsErrorFault getFaultInfo() {
        return faultInfo;
    }

}
