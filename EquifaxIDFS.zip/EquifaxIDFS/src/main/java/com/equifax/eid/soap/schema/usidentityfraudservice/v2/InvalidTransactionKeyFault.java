package com.equifax.eid.soap.schema.usidentityfraudservice.v2;

import javax.xml.ws.WebFault;

@WebFault(name = "InvalidTransactionKeyFault", targetNamespace = "http://eid.equifax.com/soap/schema/identityfraudservice/v2")
public class InvalidTransactionKeyFault
    extends Exception
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    /**
     * Java type that goes as soapenv:Fault detail element.
     * 
     */
    private com.equifax.eid.soap.schema.identityfraudservice.v2.InvalidTransactionKeyFault faultInfo;

    /**
     * 
     * @param message
     * @param faultInfo
     */
    public InvalidTransactionKeyFault(String message, com.equifax.eid.soap.schema.identityfraudservice.v2.InvalidTransactionKeyFault faultInfo) {
        super(message);
        this.faultInfo = faultInfo;
    }

    /**
     * 
     * @param message
     * @param faultInfo
     * @param cause
     */
    public InvalidTransactionKeyFault(String message, com.equifax.eid.soap.schema.identityfraudservice.v2.InvalidTransactionKeyFault faultInfo, Throwable cause) {
        super(message, cause);
        this.faultInfo = faultInfo;
    }

    /**
     * 
     * @return
     *     returns fault bean: com.equifax.eid.soap.schema.identityfraudservice.v2.InvalidTransactionKeyFault
     */
    public com.equifax.eid.soap.schema.identityfraudservice.v2.InvalidTransactionKeyFault getFaultInfo() {
        return faultInfo;
    }

}
