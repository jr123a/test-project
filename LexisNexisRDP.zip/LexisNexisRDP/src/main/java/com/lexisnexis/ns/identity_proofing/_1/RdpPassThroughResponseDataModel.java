package com.lexisnexis.ns.identity_proofing._1;

public class RdpPassThroughResponseDataModel {

	private RdpAccountAddressCityModel AccountAddressCity;
	private RdpAccountAddressCountryModel AccountAddressCountry;
	private RdpAccountAddressStateModel AccountAddressState;
	private RdpAccountAddressStreet1Model AccountAddressStreet1;
	private RdpAccountAddressZipModel AccountAddressZip;
	private String AccountAddressResult;
	private String AgentType;
	private String ApiType;
	private String Browser;
	private String BrowserLanguage;
	private String BrowserStringHash;
	private String BrowserString;
	private String BrowserVersion;
	private String CssImageLoaded;
	private String CustomMatch8;
	private RdpDeviceIdModel DeviceId;
	private String DeviceIdConfidence;
	private String DeviceFirstSeen;
	private String DeviceLastEvent;
	private String DeviceLastUpdate;
	private String DeviceScore;
	private String DeviceWorstScore;
	private String DeviceMatchResult;
	private String DeviceResult;
	private String DigitalId;
	private String DigitalIdConfidence;
	private String DigitalIdFirstSeen;
	private String DigitalIdLastEvent;
	private String DigitalIdLastUpdate;
	private String DigitalIdResult;
	private String DnsIpCity;
	private String DnsIpGeo;
	private String DnsIpIsp;
	private String DnsIpLatitude;
	private String DnsIpLongitude;
	private String DnsIpOrganization;
	private String DnsIpRegion;
	private String DnsIp;
	private String EnabledCk;
	private String EnabledFl;
	private String EnabledIm;
	private String EnabledJs;
	private String EnabledServices;
	private String EtagGuid;
	private RdpEventTypeModel EventType;
	private String FuzzyDeviceIdConfidence;
	private String FuzzyDeviceId;
	private String FuzzyDeviceFirstSeen;
	private String FuzzyDeviceLastEvent;
	private String FuzzyDeviceLastUpdate;
	private String FuzzyDeviceMatchResult;
	private String FuzzyDeviceResult;
	private String FuzzyDeviceScore;
	private String FuzzyDeviceWorstScore;
	private String HeadersNameValueHash;
	private String HeadersOrderStringHash;
	private String HttpOsSigAdvMss;
	private String HttpOsSigRcvMss;
	private String HttpOsSigSndMss;
	private String HttpRefererDomain;
	private String HttpRefererUrl;
	private String HttpReferer;
	private String ImageLoaded;
	private String JsBrowser;
	private String JsBrowserString;
	private String JsBrowserStringHash;
	private String JsOs;
	private String MimeTypeHash;
	private String MimeTypeNumber;
	private String OrgId;
	private String Os;
	private String OsVersion;
	private String PageTimeOn;
	private String PluginHash;
	private String PluginNumber;
	private String Policy;
	private String PolicyScore;
	private String ProfiledDomain;
	private String ProfiledUrl;
	private String ProfilingDatetime;
	private RdpReasonCodesModel ReasonCodes;
	private String RequestDuration;
	private String RequestId;
	private String RequestResult;
	private String ReviewStatus;
	private String RiskRating;
	private String ScreenColorDepth;
	private String ScreenRes;
	private String ServiceType;
	private String SessionId;
	private String SessionIdQueryCount;
	private String SummaryRiskScore;
	private String ThirdPartyCookie;
	private String TimeZoneDstOffset;
	private String TimeZone;
	private RdpTmxReasonCodesModel TmxReasonCodes;
	private String TmxRiskRating;
	private RdpTmxVariablesModel TmxVariables;
	private String TransactionId;
	private RdpTrueIpModel TrueIp;
	private RdpTrueIpAssertHistoryRecordsModel TrueIpAssertHistoryRecords;
	private RdpTrueIpAttributeRecordsModel TrueIpAttributeRecords;
	private String TrueIpFirstSeen;
	private String TrueIpLastEvent;
	private String TrueIpLastUpdate;
	private String TrueIpResult;
	private String TrueIpScore;
	private String TrueIpWorstScore;
	private String TrueIpCity;
	private String TrueIpGeo;
	private String TrueIpIsp;
	private String TrueIpLatitude;
	private String TrueIpLongitude;
	private String TrueIpOrganization;
	private String TrueIpRegion;
	private String UaBrowser;
	private String UaOs;
	private String UaPlatform;
	
	public RdpAccountAddressCityModel getAccountAddressCity() {
		return AccountAddressCity;
	}
	
	public void setAccountAddressCity(RdpAccountAddressCityModel accountAddressCity) {
		AccountAddressCity = accountAddressCity;
	}

	public RdpAccountAddressCountryModel getAccountAddressCountry() {
		return AccountAddressCountry;
	}

	public void setAccountAddressCountry(RdpAccountAddressCountryModel accountAddressCountry) {
		AccountAddressCountry = accountAddressCountry;
	}

	public RdpAccountAddressStateModel getAccountAddressState() {
		return AccountAddressState;
	}

	public void setAccountAddressState(RdpAccountAddressStateModel accountAddressState) {
		AccountAddressState = accountAddressState;
	}

	public RdpAccountAddressStreet1Model getAccountAddressStreet1() {
		return AccountAddressStreet1;
	}

	public void setAccountAddressStreet1(RdpAccountAddressStreet1Model accountAddressStreet1) {
		AccountAddressStreet1 = accountAddressStreet1;
	}

	public RdpAccountAddressZipModel getAccountAddressZip() {
		return AccountAddressZip;
	}

	public void setAccountAddressZip(RdpAccountAddressZipModel accountAddressZip) {
		AccountAddressZip = accountAddressZip;
	}

	public String getAccountAddressResult() {
		return AccountAddressResult;
	}

	public void setAccountAddressResult(String accountAddressResult) {
		AccountAddressResult = accountAddressResult;
	}

	public String getAgentType() {
		return AgentType;
	}

	public void setAgentType(String agentType) {
		AgentType = agentType;
	}

	public String getApiType() {
		return ApiType;
	}

	public void setApiType(String apiType) {
		ApiType = apiType;
	}

	public String getBrowser() {
		return Browser;
	}

	public void setBrowser(String browser) {
		Browser = browser;
	}

	public String getBrowserLanguage() {
		return BrowserLanguage;
	}

	public void setBrowserLanguage(String browserLanguage) {
		BrowserLanguage = browserLanguage;
	}

	public String getBrowserStringHash() {
		return BrowserStringHash;
	}

	public void setBrowserStringHash(String browserStringHash) {
		BrowserStringHash = browserStringHash;
	}

	public String getBrowserString() {
		return BrowserString;
	}

	public void setBrowserString(String browserString) {
		BrowserString = browserString;
	}

	public String getBrowserVersion() {
		return BrowserVersion;
	}

	public void setBrowserVersion(String browserVersion) {
		BrowserVersion = browserVersion;
	}

	public String getCssImageLoaded() {
		return CssImageLoaded;
	}

	public void setCssImageLoaded(String cssImageLoaded) {
		CssImageLoaded = cssImageLoaded;
	}

	public String getCustomMatch8() {
		return CustomMatch8;
	}

	public void setCustomMatch8(String customMatch8) {
		CustomMatch8 = customMatch8;
	}

	public RdpDeviceIdModel getDeviceId() {
		return DeviceId;
	}

	public void setDeviceId(RdpDeviceIdModel deviceId) {
		DeviceId = deviceId;
	}

	public String getDeviceIdConfidence() {
		return DeviceIdConfidence;
	}

	public void setDeviceIdConfidence(String deviceIdConfidence) {
		DeviceIdConfidence = deviceIdConfidence;
	}

	public String getDeviceFirstSeen() {
		return DeviceFirstSeen;
	}

	public void setDeviceFirstSeen(String deviceFirstSeen) {
		DeviceFirstSeen = deviceFirstSeen;
	}

	public String getDeviceLastEvent() {
		return DeviceLastEvent;
	}

	public void setDeviceLastEvent(String deviceLastEvent) {
		DeviceLastEvent = deviceLastEvent;
	}

	public String getDeviceLastUpdate() {
		return DeviceLastUpdate;
	}

	public void setDeviceLastUpdate(String deviceLastUpdate) {
		DeviceLastUpdate = deviceLastUpdate;
	}

	public String getDeviceScore() {
		return DeviceScore;
	}

	public void setDeviceScore(String deviceScore) {
		DeviceScore = deviceScore;
	}

	public String getDeviceWorstScore() {
		return DeviceWorstScore;
	}

	public void setDeviceWorstScore(String deviceWorstScore) {
		DeviceWorstScore = deviceWorstScore;
	}

	public String getDeviceMatchResult() {
		return DeviceMatchResult;
	}

	public void setDeviceMatchResult(String deviceMatchResult) {
		DeviceMatchResult = deviceMatchResult;
	}

	public String getDeviceResult() {
		return DeviceResult;
	}

	public void setDeviceResult(String deviceResult) {
		DeviceResult = deviceResult;
	}

	public String getDigitalId() {
		return DigitalId;
	}

	public void setDigitalId(String digitalId) {
		DigitalId = digitalId;
	}

	public String getDigitalIdConfidence() {
		return DigitalIdConfidence;
	}

	public void setDigitalIdConfidence(String digitalIdConfidence) {
		DigitalIdConfidence = digitalIdConfidence;
	}

	public String getDigitalIdFirstSeen() {
		return DigitalIdFirstSeen;
	}

	public void setDigitalIdFirstSeen(String digitalIdFirstSeen) {
		DigitalIdFirstSeen = digitalIdFirstSeen;
	}

	public String getDigitalIdLastEvent() {
		return DigitalIdLastEvent;
	}

	public void setDigitalIdLastEvent(String digitalIdLastEvent) {
		DigitalIdLastEvent = digitalIdLastEvent;
	}

	public String getDigitalIdLastUpdate() {
		return DigitalIdLastUpdate;
	}

	public void setDigitalIdLastUpdate(String digitalIdLastUpdate) {
		DigitalIdLastUpdate = digitalIdLastUpdate;
	}

	public String getDigitalIdResult() {
		return DigitalIdResult;
	}

	public void setDigitalIdResult(String digitalIdResult) {
		DigitalIdResult = digitalIdResult;
	}

	public String getDnsIpCity() {
		return DnsIpCity;
	}

	public void setDnsIpCity(String dnsIpCity) {
		DnsIpCity = dnsIpCity;
	}

	public String getDnsIpGeo() {
		return DnsIpGeo;
	}

	public void setDnsIpGeo(String dnsIpGeo) {
		DnsIpGeo = dnsIpGeo;
	}

	public String getDnsIpIsp() {
		return DnsIpIsp;
	}

	public void setDnsIpIsp(String dnsIpIsp) {
		DnsIpIsp = dnsIpIsp;
	}

	public String getDnsIpLatitude() {
		return DnsIpLatitude;
	}

	public void setDnsIpLatitude(String dnsIpLatitude) {
		DnsIpLatitude = dnsIpLatitude;
	}

	public String getDnsIpLongitude() {
		return DnsIpLongitude;
	}

	public void setDnsIpLongitude(String dnsIpLongitude) {
		DnsIpLongitude = dnsIpLongitude;
	}

	public String getDnsIpOrganization() {
		return DnsIpOrganization;
	}

	public void setDnsIpOrganization(String dnsIpOrganization) {
		DnsIpOrganization = dnsIpOrganization;
	}

	public String getDnsIpRegion() {
		return DnsIpRegion;
	}

	public void setDnsIpRegion(String dnsIpRegion) {
		DnsIpRegion = dnsIpRegion;
	}

	public String getDnsIp() {
		return DnsIp;
	}

	public void setDnsIp(String dnsIp) {
		DnsIp = dnsIp;
	}

	public String getEnabledCk() {
		return EnabledCk;
	}

	public void setEnabledCk(String enabledCk) {
		EnabledCk = enabledCk;
	}

	public String getEnabledFl() {
		return EnabledFl;
	}

	public void setEnabledFl(String enabledFl) {
		EnabledFl = enabledFl;
	}

	public String getEnabledIm() {
		return EnabledIm;
	}

	public void setEnabledIm(String enabledIm) {
		EnabledIm = enabledIm;
	}

	public String getEnabledJs() {
		return EnabledJs;
	}

	public void setEnabledJs(String enabledJs) {
		EnabledJs = enabledJs;
	}

	public String getEnabledServices() {
		return EnabledServices;
	}

	public void setEnabledServices(String enabledServices) {
		EnabledServices = enabledServices;
	}

	public String getEtagGuid() {
		return EtagGuid;
	}

	public void setEtagGuid(String etagGuid) {
		EtagGuid = etagGuid;
	}

	public RdpEventTypeModel getEventType() {
		return EventType;
	}

	public void setEventType(RdpEventTypeModel eventType) {
		EventType = eventType;
	}

	public String getFuzzyDeviceIdConfidence() {
		return FuzzyDeviceIdConfidence;
	}

	public void setFuzzyDeviceIdConfidence(String fuzzyDeviceIdConfidence) {
		FuzzyDeviceIdConfidence = fuzzyDeviceIdConfidence;
	}

	public String getFuzzyDeviceId() {
		return FuzzyDeviceId;
	}

	public void setFuzzyDeviceId(String fuzzyDeviceId) {
		FuzzyDeviceId = fuzzyDeviceId;
	}

	public String getFuzzyDeviceFirstSeen() {
		return FuzzyDeviceFirstSeen;
	}

	public void setFuzzyDeviceFirstSeen(String fuzzyDeviceFirstSeen) {
		FuzzyDeviceFirstSeen = fuzzyDeviceFirstSeen;
	}

	public String getFuzzyDeviceLastEvent() {
		return FuzzyDeviceLastEvent;
	}

	public void setFuzzyDeviceLastEvent(String fuzzyDeviceLastEvent) {
		FuzzyDeviceLastEvent = fuzzyDeviceLastEvent;
	}

	public String getFuzzyDeviceLastUpdate() {
		return FuzzyDeviceLastUpdate;
	}

	public void setFuzzyDeviceLastUpdate(String fuzzyDeviceLastUpdate) {
		FuzzyDeviceLastUpdate = fuzzyDeviceLastUpdate;
	}

	public String getFuzzyDeviceMatchResult() {
		return FuzzyDeviceMatchResult;
	}

	public void setFuzzyDeviceMatchResult(String fuzzyDeviceMatchResult) {
		FuzzyDeviceMatchResult = fuzzyDeviceMatchResult;
	}

	public String getFuzzyDeviceResult() {
		return FuzzyDeviceResult;
	}

	public void setFuzzyDeviceResult(String fuzzyDeviceResult) {
		FuzzyDeviceResult = fuzzyDeviceResult;
	}

	public String getFuzzyDeviceScore() {
		return FuzzyDeviceScore;
	}

	public void setFuzzyDeviceScore(String fuzzyDeviceScore) {
		FuzzyDeviceScore = fuzzyDeviceScore;
	}

	public String getFuzzyDeviceWorstScore() {
		return FuzzyDeviceWorstScore;
	}

	public void setFuzzyDeviceWorstScore(String fuzzyDeviceWorstScore) {
		FuzzyDeviceWorstScore = fuzzyDeviceWorstScore;
	}

	public String getHeadersNameValueHash() {
		return HeadersNameValueHash;
	}

	public void setHeadersNameValueHash(String headersNameValueHash) {
		HeadersNameValueHash = headersNameValueHash;
	}

	public String getHeadersOrderStringHash() {
		return HeadersOrderStringHash;
	}

	public void setHeadersOrderStringHash(String headersOrderStringHash) {
		HeadersOrderStringHash = headersOrderStringHash;
	}

	public String getHttpOsSigAdvMss() {
		return HttpOsSigAdvMss;
	}

	public void setHttpOsSigAdvMss(String httpOsSigAdvMss) {
		HttpOsSigAdvMss = httpOsSigAdvMss;
	}

	public String getHttpOsSigRcvMss() {
		return HttpOsSigRcvMss;
	}

	public void setHttpOsSigRcvMss(String httpOsSigRcvMss) {
		HttpOsSigRcvMss = httpOsSigRcvMss;
	}

	public String getHttpOsSigSndMss() {
		return HttpOsSigSndMss;
	}

	public void setHttpOsSigSndMss(String httpOsSigSndMss) {
		HttpOsSigSndMss = httpOsSigSndMss;
	}

	public String getHttpRefererDomain() {
		return HttpRefererDomain;
	}

	public void setHttpRefererDomain(String httpRefererDomain) {
		HttpRefererDomain = httpRefererDomain;
	}

	public String getHttpRefererUrl() {
		return HttpRefererUrl;
	}

	public void setHttpRefererUrl(String httpRefererUrl) {
		HttpRefererUrl = httpRefererUrl;
	}

	public String getHttpReferer() {
		return HttpReferer;
	}

	public void setHttpReferer(String httpReferer) {
		HttpReferer = httpReferer;
	}

	public String getImageLoaded() {
		return ImageLoaded;
	}

	public void setImageLoaded(String imageLoaded) {
		ImageLoaded = imageLoaded;
	}

	public String getJsBrowser() {
		return JsBrowser;
	}

	public void setJsBrowser(String jsBrowser) {
		JsBrowser = jsBrowser;
	}

	public String getJsBrowserString() {
		return JsBrowserString;
	}

	public void setJsBrowserString(String jsBrowserString) {
		JsBrowserString = jsBrowserString;
	}

	public String getJsBrowserStringHash() {
		return JsBrowserStringHash;
	}

	public void setJsBrowserStringHash(String jsBrowserStringHash) {
		JsBrowserStringHash = jsBrowserStringHash;
	}

	public String getJsOs() {
		return JsOs;
	}

	public void setJsOs(String jsOs) {
		JsOs = jsOs;
	}

	public String getMimeTypeHash() {
		return MimeTypeHash;
	}

	public void setMimeTypeHash(String mimeTypeHash) {
		MimeTypeHash = mimeTypeHash;
	}

	public String getMimeTypeNumber() {
		return MimeTypeNumber;
	}

	public void setMimeTypeNumber(String mimeTypeNumber) {
		MimeTypeNumber = mimeTypeNumber;
	}

	public String getOrgId() {
		return OrgId;
	}

	public void setOrgId(String orgId) {
		OrgId = orgId;
	}

	public String getOs() {
		return Os;
	}

	public void setOs(String os) {
		Os = os;
	}

	public String getOsVersion() {
		return OsVersion;
	}

	public void setOsVersion(String osVersion) {
		OsVersion = osVersion;
	}

	public String getPageTimeOn() {
		return PageTimeOn;
	}

	public void setPageTimeOn(String pageTimeOn) {
		PageTimeOn = pageTimeOn;
	}

	public String getPluginHash() {
		return PluginHash;
	}

	public void setPluginHash(String pluginHash) {
		PluginHash = pluginHash;
	}

	public String getPluginNumber() {
		return PluginNumber;
	}

	public void setPluginNumber(String pluginNumber) {
		PluginNumber = pluginNumber;
	}

	public String getPolicy() {
		return Policy;
	}

	public void setPolicy(String policy) {
		Policy = policy;
	}

	public String getPolicyScore() {
		return PolicyScore;
	}

	public void setPolicyScore(String policyScore) {
		PolicyScore = policyScore;
	}

	public String getProfiledDomain() {
		return ProfiledDomain;
	}

	public void setProfiledDomain(String profiledDomain) {
		ProfiledDomain = profiledDomain;
	}

	public String getProfiledUrl() {
		return ProfiledUrl;
	}

	public void setProfiledUrl(String profiledUrl) {
		ProfiledUrl = profiledUrl;
	}

	public String getProfilingDatetime() {
		return ProfilingDatetime;
	}

	public void setProfilingDatetime(String profilingDatetime) {
		ProfilingDatetime = profilingDatetime;
	}

	public RdpReasonCodesModel getReasonCodes() {
		return ReasonCodes;
	}

	public void setReasonCodes(RdpReasonCodesModel reasonCodes) {
		ReasonCodes = reasonCodes;
	}

	public String getRequestDuration() {
		return RequestDuration;
	}

	public void setRequestDuration(String requestDuration) {
		RequestDuration = requestDuration;
	}

	public String getRequestId() {
		return RequestId;
	}

	public void setRequestId(String requestId) {
		RequestId = requestId;
	}

	public String getRequestResult() {
		return RequestResult;
	}

	public void setRequestResult(String requestResult) {
		RequestResult = requestResult;
	}

	public String getReviewStatus() {
		return ReviewStatus;
	}

	public void setReviewStatus(String reviewStatus) {
		ReviewStatus = reviewStatus;
	}

	public String getRiskRating() {
		return RiskRating;
	}

	public void setRiskRating(String riskRating) {
		RiskRating = riskRating;
	}

	public String getScreenColorDepth() {
		return ScreenColorDepth;
	}

	public void setScreenColorDepth(String screenColorDepth) {
		ScreenColorDepth = screenColorDepth;
	}

	public String getScreenRes() {
		return ScreenRes;
	}

	public void setScreenRes(String screenRes) {
		ScreenRes = screenRes;
	}

	public String getServiceType() {
		return ServiceType;
	}

	public void setServiceType(String serviceType) {
		ServiceType = serviceType;
	}

	public String getSessionId() {
		return SessionId;
	}

	public void setSessionId(String sessionId) {
		SessionId = sessionId;
	}

	public String getSessionIdQueryCount() {
		return SessionIdQueryCount;
	}

	public void setSessionIdQueryCount(String sessionIdQueryCount) {
		SessionIdQueryCount = sessionIdQueryCount;
	}

	public String getSummaryRiskScore() {
		return SummaryRiskScore;
	}

	public void setSummaryRiskScore(String summaryRiskScore) {
		SummaryRiskScore = summaryRiskScore;
	}

	public String getThirdPartyCookie() {
		return ThirdPartyCookie;
	}

	public void setThirdPartyCookie(String thirdPartyCookie) {
		ThirdPartyCookie = thirdPartyCookie;
	}

	public String getTimeZoneDstOffset() {
		return TimeZoneDstOffset;
	}

	public void setTimeZoneDstOffset(String timeZoneDstOffset) {
		TimeZoneDstOffset = timeZoneDstOffset;
	}

	public String getTimeZone() {
		return TimeZone;
	}

	public void setTimeZone(String timeZone) {
		TimeZone = timeZone;
	}

	public RdpTmxReasonCodesModel getTmxReasonCodes() {
		return TmxReasonCodes;
	}

	public void setTmxReasonCodes(RdpTmxReasonCodesModel tmxReasonCodes) {
		TmxReasonCodes = tmxReasonCodes;
	}

	public String getTmxRiskRating() {
		return TmxRiskRating;
	}

	public void setTmxRiskRating(String tmxRiskRating) {
		TmxRiskRating = tmxRiskRating;
	}

	public RdpTmxVariablesModel getTmxVariables() {
		return TmxVariables;
	}

	public void setTmxVariables(RdpTmxVariablesModel tmxVariables) {
		TmxVariables = tmxVariables;
	}

	public String getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}

	public RdpTrueIpModel getTrueIp() {
		return TrueIp;
	}

	public void setTrueIp(RdpTrueIpModel trueIp) {
		TrueIp = trueIp;
	}

	public RdpTrueIpAssertHistoryRecordsModel getTrueIpAssertHistoryRecords() {
		return TrueIpAssertHistoryRecords;
	}

	public void setTrueIpAssertHistoryRecords(RdpTrueIpAssertHistoryRecordsModel trueIpAssertHistoryRecords) {
		TrueIpAssertHistoryRecords = trueIpAssertHistoryRecords;
	}

	public RdpTrueIpAttributeRecordsModel getTrueIpAttributeRecords() {
		return TrueIpAttributeRecords;
	}

	public void setTrueIpAttributeRecords(RdpTrueIpAttributeRecordsModel trueIpAttributeRecords) {
		TrueIpAttributeRecords = trueIpAttributeRecords;
	}

	public String getTrueIpFirstSeen() {
		return TrueIpFirstSeen;
	}

	public void setTrueIpFirstSeen(String trueIpFirstSeen) {
		TrueIpFirstSeen = trueIpFirstSeen;
	}

	public String getTrueIpLastEvent() {
		return TrueIpLastEvent;
	}

	public void setTrueIpLastEvent(String trueIpLastEvent) {
		TrueIpLastEvent = trueIpLastEvent;
	}

	public String getTrueIpLastUpdate() {
		return TrueIpLastUpdate;
	}

	public void setTrueIpLastUpdate(String trueIpLastUpdate) {
		TrueIpLastUpdate = trueIpLastUpdate;
	}

	public String getTrueIpResult() {
		return TrueIpResult;
	}

	public void setTrueIpResult(String trueIpResult) {
		TrueIpResult = trueIpResult;
	}

	public String getTrueIpScore() {
		return TrueIpScore;
	}

	public void setTrueIpScore(String trueIpScore) {
		TrueIpScore = trueIpScore;
	}

	public String getTrueIpWorstScore() {
		return TrueIpWorstScore;
	}

	public void setTrueIpWorstScore(String trueIpWorstScore) {
		TrueIpWorstScore = trueIpWorstScore;
	}

	public String getTrueIpCity() {
		return TrueIpCity;
	}

	public void setTrueIpCity(String trueIpCity) {
		TrueIpCity = trueIpCity;
	}

	public String getTrueIpGeo() {
		return TrueIpGeo;
	}

	public void setTrueIpGeo(String trueIpGeo) {
		TrueIpGeo = trueIpGeo;
	}

	public String getTrueIpIsp() {
		return TrueIpIsp;
	}

	public void setTrueIpIsp(String trueIpIsp) {
		TrueIpIsp = trueIpIsp;
	}

	public String getTrueIpLatitude() {
		return TrueIpLatitude;
	}

	public void setTrueIpLatitude(String trueIpLatitude) {
		TrueIpLatitude = trueIpLatitude;
	}

	public String getTrueIpLongitude() {
		return TrueIpLongitude;
	}

	public void setTrueIpLongitude(String trueIpLongitude) {
		TrueIpLongitude = trueIpLongitude;
	}

	public String getTrueIpOrganization() {
		return TrueIpOrganization;
	}

	public void setTrueIpOrganization(String trueIpOrganization) {
		TrueIpOrganization = trueIpOrganization;
	}

	public String getTrueIpRegion() {
		return TrueIpRegion;
	}

	public void setTrueIpRegion(String trueIpRegion) {
		TrueIpRegion = trueIpRegion;
	}

	public String getUaBrowser() {
		return UaBrowser;
	}

	public void setUaBrowser(String uaBrowser) {
		UaBrowser = uaBrowser;
	}

	public String getUaOs() {
		return UaOs;
	}

	public void setUaOs(String uaOs) {
		UaOs = uaOs;
	}

	public String getUaPlatform() {
		return UaPlatform;
	}

	public void setUaPlatform(String uaPlatform) {
		UaPlatform = uaPlatform;
	}

}
