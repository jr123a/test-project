package com.lexisnexis.ns.identity_proofing._1;

public class TmxQueryResponseModel {

	private String account_email;
	private String account_login;
	private String action;
	private String api_call_datetime;
	private String api_type;
	
	private String error_detail;
	private String event_datetime;
	
	private String org_id;
	
	private String request_duration;
	private String request_id;
	private String request_result;
	
	private String service_type;
	
	public String getAccount_email() {
		return account_email;
	}
	
	public void setAccount_email(String account_email) {
		this.account_email = account_email;
	}

	public String getAccount_login() {
		return account_login;
	}

	public void setAccount_login(String account_login) {
		this.account_login = account_login;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getApi_call_datetime() {
		return api_call_datetime;
	}

	public void setApi_call_datetime(String api_call_datetime) {
		this.api_call_datetime = api_call_datetime;
	}

	public String getApi_type() {
		return api_type;
	}

	public void setApi_type(String api_type) {
		this.api_type = api_type;
	}

	public String getError_detail() {
		return error_detail;
	}

	public void setError_detail(String error_detail) {
		this.error_detail = error_detail;
	}

	public String getEvent_datetime() {
		return event_datetime;
	}

	public void setEvent_datetime(String event_datetime) {
		this.event_datetime = event_datetime;
	}

	public String getOrg_id() {
		return org_id;
	}

	public void setOrg_id(String org_id) {
		this.org_id = org_id;
	}

	public String getRequest_duration() {
		return request_duration;
	}

	public void setRequest_duration(String request_duration) {
		this.request_duration = request_duration;
	}

	public String getRequest_id() {
		return request_id;
	}

	public void setRequest_id(String request_id) {
		this.request_id = request_id;
	}

	public String getRequest_result() {
		return request_result;
	}

	public void setRequest_result(String request_result) {
		this.request_result = request_result;
	}

	public String getService_type() {
		return service_type;
	}

	public void setService_type(String service_type) {
		this.service_type = service_type;
	}

}
