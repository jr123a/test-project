package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpTrueIpAssertHistoryRecordsModel {

	private List<String> TrueIpAssertHistories;

	public List<String> getTrueIpAssertHistories() {
		return TrueIpAssertHistories;
	}

	public void setTrueIpAssertHistories(List<String> trueIpAssertHistories) {
		TrueIpAssertHistories = trueIpAssertHistories;
	}

}
