package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpBusinessModel {

	private String CompanyName;
	private String Fein;
	private List<RdpAddressModel> Addresses;
	private List<RdpPhoneModel> Phones;
	
	public String getCompanyName() {
		return CompanyName;
	}
	
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public String getFein() {
		return Fein;
	}

	public void setFein(String fein) {
		Fein = fein;
	}

	public List<RdpAddressModel> getAddresses() {
		return Addresses;
	}

	public void setAddresses(List<RdpAddressModel> addresses) {
		Addresses = addresses;
	}

	public List<RdpPhoneModel> getPhones() {
		return Phones;
	}

	public void setPhones(List<RdpPhoneModel> phones) {
		Phones = phones;
	}

	
}
