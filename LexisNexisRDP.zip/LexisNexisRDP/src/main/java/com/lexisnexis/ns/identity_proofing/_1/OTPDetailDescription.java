package com.lexisnexis.ns.identity_proofing._1;

public class OTPDetailDescription {
	
	private String Text;

	public String getText() {
		return Text;
	}

	public void setText(String text) {
		Text = text;
	}

}
