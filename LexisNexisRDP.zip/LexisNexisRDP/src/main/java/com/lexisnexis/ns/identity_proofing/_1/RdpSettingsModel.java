package com.lexisnexis.ns.identity_proofing._1;

public class RdpSettingsModel {

	private String Mode;
	private String Reference;
	private String Locale;
	private String Venue;

	public String getMode() {
		return Mode;
	}

	public void setMode(String mode) {
		this.Mode = mode;
	}

	public String getReference() {
		return Reference;
	}

	public void setReference(String reference) {
		this.Reference = reference;
	}

	public String getLocale() {
		return Locale;
	}

	public void setLocale(String locale) {
		this.Locale = locale;
	}

	public String getVenue() {
		return Venue;
	}

	public void setVenue(String venue) {
		this.Venue = venue;
	}
}
