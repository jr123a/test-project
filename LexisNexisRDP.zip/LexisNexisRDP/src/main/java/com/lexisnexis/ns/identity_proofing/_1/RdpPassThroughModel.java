package com.lexisnexis.ns.identity_proofing._1;

public class RdpPassThroughModel {

	private String Type;
	private String Data;
	private RdpPassThroughDataModel passThroughData;
	
	public String getType() {
		return Type;
	}
	
	public void setType(String type) {
		Type = type;
	}

	public String getData() {
		return Data;
	}

	public void setData(String data) {
		Data = data;
	}

	public RdpPassThroughDataModel getPassThroughData() {
		return passThroughData;
	}

	public void setPassThroughData(RdpPassThroughDataModel passThroughData) {
		this.passThroughData = passThroughData;
	}

}
