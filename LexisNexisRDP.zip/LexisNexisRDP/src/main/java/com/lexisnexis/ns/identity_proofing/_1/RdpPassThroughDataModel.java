package com.lexisnexis.ns.identity_proofing._1;

public class RdpPassThroughDataModel {

	private RdpTrustDefenderResponseExModel TrustDefenderResponseEx;

	public RdpTrustDefenderResponseExModel getTrustDefenderResponseEx() {
		return TrustDefenderResponseEx;
	}

	public void setTrustDefenderResponseEx(RdpTrustDefenderResponseExModel trustDefenderResponseEx) {
		TrustDefenderResponseEx = trustDefenderResponseEx;
	}

}
