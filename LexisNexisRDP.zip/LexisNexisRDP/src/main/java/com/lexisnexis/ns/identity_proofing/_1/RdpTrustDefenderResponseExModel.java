package com.lexisnexis.ns.identity_proofing._1;

public class RdpTrustDefenderResponseExModel {

	private RdpPassThroughResponseModel response;

	public RdpPassThroughResponseModel getResponse() {
		return response;
	}

	public void setResponse(RdpPassThroughResponseModel response) {
		this.response = response;
	}
	
}
