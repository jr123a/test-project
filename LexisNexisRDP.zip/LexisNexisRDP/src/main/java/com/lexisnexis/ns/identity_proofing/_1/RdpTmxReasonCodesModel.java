package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpTmxReasonCodesModel {

	private List<String> TmxReasonCodes;

	public List<String> getTmxReasonCodes() {
		return TmxReasonCodes;
	}

	public void setTmxReasonCodes(List<String> tmxReasonCodes) {
		TmxReasonCodes = tmxReasonCodes;
	}

}
