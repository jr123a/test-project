package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpReasonCodesModel {

	private List<String> ReasonCode;

	public List<String> getReasonCode() {
		return ReasonCode;
	}

	public void setReasonCode(List<String> reasonCode) {
		ReasonCode = reasonCode;
	}
}
