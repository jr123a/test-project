package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpQuestionModel {

	private String QuestionId;
	private String Key;
	private String Type;
	private RdpQuestionTextModel Text;
	private RdpQuestionTextModel HelpText;
	private List<RdpQuestionChoiceModel> Choices;
	
	public String getQuestionId() {
		return QuestionId;
	}
	
	public void setQuestionId(String questionId) {
		QuestionId = questionId;
	}

	public String getKey() {
		return Key;
	}

	public void setKey(String key) {
		Key = key;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public RdpQuestionTextModel getText() {
		return Text;
	}

	public void setText(RdpQuestionTextModel text) {
		Text = text;
	}

	public RdpQuestionTextModel getHelpText() {
		return HelpText;
	}

	public void setHelpText(RdpQuestionTextModel helpText) {
		HelpText = helpText;
	}

	public List<RdpQuestionChoiceModel> getChoices() {
		return Choices;
	}

	public void setChoices(List<RdpQuestionChoiceModel> choices) {
		Choices = choices;
	}    

}
