package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpDeviceAssessmentResponseModel {

	private RdpStatusModel Status;
	private List<RdpProductModel> Products;
	private List<RdpPassThroughModel> PassThroughs;
	
	public RdpStatusModel getStatus() {
		return Status;
	}
	
	public void setStatus(RdpStatusModel status) {
		Status = status;
	}

	public List<RdpProductModel> getProducts() {
		return Products;
	}

	public void setProducts(List<RdpProductModel> products) {
		Products = products;
	}

	public List<RdpPassThroughModel> getPassThroughs() {
		return PassThroughs;
	}

	public void setPassThroughs(List<RdpPassThroughModel> passThroughs) {
		PassThroughs = passThroughs;
	}
	
}
