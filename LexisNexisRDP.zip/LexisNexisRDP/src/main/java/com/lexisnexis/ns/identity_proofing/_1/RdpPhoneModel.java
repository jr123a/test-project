package com.lexisnexis.ns.identity_proofing._1;

public class RdpPhoneModel {

	private String Number;
	private String Context;
	
	public String getNumber() {
		return Number;
	}
	
	public void setNumber(String number) {
		Number = number;
	}

	public String getContext() {
		return Context;
	}

	public void setContext(String context) {
		Context = context;
	}
	
}
