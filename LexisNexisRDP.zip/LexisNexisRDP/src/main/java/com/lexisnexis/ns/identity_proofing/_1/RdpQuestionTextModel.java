package com.lexisnexis.ns.identity_proofing._1;

public class RdpQuestionTextModel {

	private String Statement;
	
	public String getStatement() {
		return Statement;
	}

	public void setStatement(String statement) {
		Statement = statement;
	}

}
