package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpTrueIpAttributeRecordsModel {

	private List<String> TrueIpAttributes;

	public List<String> getTrueIpAttributes() {
		return TrueIpAttributes;
	}

	public void setTrueIpAttributes(List<String> trueIpAttributes) {
		TrueIpAttributes = trueIpAttributes;
	}

}
