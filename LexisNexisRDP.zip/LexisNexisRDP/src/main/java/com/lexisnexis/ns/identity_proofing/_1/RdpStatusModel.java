package com.lexisnexis.ns.identity_proofing._1;

public class RdpStatusModel {

	private String ConversationId;
	private String RequestId;
	private String IVSReferenceId;
	private String TransactionStatus;
	private String ActionType;
	private String Reference;
	private String LexID;
	private RdpReasonCodeModel TransactionReasonCode;

	public String getConversationId() {
		return ConversationId;
	}

	public void setConversationId(String conversationId) {
		ConversationId = conversationId;
	}

	public String getRequestId() {
		return RequestId;
	}

	public void setRequestId(String requestId) {
		RequestId = requestId;
	}

	public String getTransactionStatus() {
		return TransactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		TransactionStatus = transactionStatus;
	}

	public String getActionType() {
		return ActionType;
	}

	public void setActionType(String actionType) {
		ActionType = actionType;
	}

	public String getReference() {
		return Reference;
	}

	public void setReference(String reference) {
		Reference = reference;
	}

	public String getLexID() {
		return LexID;
	}

	public void setLexID(String lexID) {
		LexID = lexID;
	}

	public RdpReasonCodeModel getTransactionReasonCode() {
		return TransactionReasonCode;
	}

	public void setTransactionReasonCode(RdpReasonCodeModel transactionReasonCode) {
		TransactionReasonCode = transactionReasonCode;
	}

	public String getIVSReferenceId() {
		return IVSReferenceId;
	}

	public void setIVSReferenceId(String iVSReferenceId) {
		IVSReferenceId = iVSReferenceId;
	}
}
