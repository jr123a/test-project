package com.lexisnexis.ns.identity_proofing._1;

public class RdpAccountAddressStreet1Model {

	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
