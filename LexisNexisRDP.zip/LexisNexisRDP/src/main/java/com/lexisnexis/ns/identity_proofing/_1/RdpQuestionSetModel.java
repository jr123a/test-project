package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpQuestionSetModel {

	private int QuestionSetId;
	private List<RdpQuestionModel> Questions;
	
	public int getQuestionSetId() {
		return QuestionSetId;
	}
	
	public void setQuestionSetId(int questionSetId) {
		QuestionSetId = questionSetId;
	}

	public List<RdpQuestionModel> getQuestions() {
		return Questions;
	}

	public void setQuestions(List<RdpQuestionModel> questions) {
		Questions = questions;
	}
	
}
