package com.lexisnexis.ns.identity_proofing._1;

public class RdpProductException {

	private String ProductType;
	private String ProductStatus;
	private RdpReasonCodeModel ProductReason;
	
	public String getProductType() {
		return ProductType;
	}
	
	public void setProductType(String productType) {
		ProductType = productType;
	}

	public String getProductStatus() {
		return ProductStatus;
	}

	public void setProductStatus(String productStatus) {
		ProductStatus = productStatus;
	}

	public RdpReasonCodeModel getProductReason() {
		return ProductReason;
	}

	public void setProductReason(RdpReasonCodeModel productReason) {
		ProductReason = productReason;
	}

}
