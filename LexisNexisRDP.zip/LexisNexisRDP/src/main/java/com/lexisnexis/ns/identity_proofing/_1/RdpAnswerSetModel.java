package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpAnswerSetModel {

	private int QuestionSetId;
	private List<RdpAnswerModel> Questions;
	
	public int getQuestionSetId() {
		return QuestionSetId;
	}
	
	public void setQuestionSetId(int questionSetId) {
		QuestionSetId = questionSetId;
	}

	public List<RdpAnswerModel> getQuestions() {
		return Questions;
	}

	public void setQuestions(List<RdpAnswerModel> questions) {
		Questions = questions;
	}
	
}
