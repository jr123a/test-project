package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpAnswerModel {

	private long QuestionId;
	private List<RdpQuestionChoiceModel> Choices;
	
	public long getQuestionId() {
		return QuestionId;
	}
	
	public void setQuestionId(long questionId) {
		QuestionId = questionId;
	}

	public List<RdpQuestionChoiceModel> getChoices() {
		return Choices;
	}

	public void setChoices(List<RdpQuestionChoiceModel> choices) {
		Choices = choices;
	}
}
