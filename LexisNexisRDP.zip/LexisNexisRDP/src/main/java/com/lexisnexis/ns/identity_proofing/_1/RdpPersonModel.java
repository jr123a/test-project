package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpPersonModel {

	private RdpPersonNameModel Name;
	private List<RdpAddressModel> Addresses;
	private RdpPersonSsnModel SSN;
	private RdpDateOfBirthModel DateOfBirth;
	private List<RdpPhoneModel> Phones;
	private List<String> Emails;
	private String Context;
	
	public RdpPersonNameModel getName() {
		return Name;
	}
	
	public void setName(RdpPersonNameModel name) {
		Name = name;
	}

	public List<RdpAddressModel> getAddresses() {
		return Addresses;
	}

	public void setAddresses(List<RdpAddressModel> addresses) {
		Addresses = addresses;
	}

	public RdpPersonSsnModel getSSN() {
		return SSN;
	}

	public void setSSN(RdpPersonSsnModel sSN) {
		SSN = sSN;
	}

	public RdpDateOfBirthModel getDateOfBirth() {
		return DateOfBirth;
	}

	public void setDateOfBirth(RdpDateOfBirthModel dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}

	public List<RdpPhoneModel> getPhones() {
		return Phones;
	}

	public void setPhones(List<RdpPhoneModel> phones) {
		Phones = phones;
	}

	public List<String> getEmails() {
		return Emails;
	}

	public void setEmails(List<String> emails) {
		Emails = emails;
	}

	public String getContext() {
		return Context;
	}

	public void setContext(String context) {
		Context = context;
	}

}
