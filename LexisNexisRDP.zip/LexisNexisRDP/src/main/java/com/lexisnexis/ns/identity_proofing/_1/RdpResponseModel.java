package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpResponseModel {

	private RdpStatusModel Status;
	private List<RdpProductModel> Products;
	private List<OTPInformationModel> Information;
	
	public RdpStatusModel getStatus() {
		return Status;
	}
	
	public void setStatus(RdpStatusModel status) {
		Status = status;
	}

	public List<RdpProductModel> getProducts() {
		return Products;
	}

	public void setProducts(List<RdpProductModel> products) {
		Products = products;
	}

	public List<OTPInformationModel> getInformation() {
		return Information;
	}

	public void setInformation(List<OTPInformationModel> information) {
		Information = information;
	}

}
