package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class OTPParameterDetailsModel {

	private String Group;
	private String Name;
	private List<OTPValuesModel> Values;

	public String getGroup() {
		return Group;
	}

	public void setGroup(String group) {
		Group = group;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public List<OTPValuesModel> getValues() {
		return Values;
	}

	public void setValues(List<OTPValuesModel> values) {
		Values = values;
	}
}
