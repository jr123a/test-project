package com.lexisnexis.ns.identity_proofing._1;

public class RdpCustomDataModel {

	private String Type;
	private String Name;
	private String Value;
	
	public String getType() {
		return Type;
	}
	
	public void setType(String type) {
		Type = type;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getValue() {
		return Value;
	}

	public void setValue(String value) {
		Value = value;
	}

}
