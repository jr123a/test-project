package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpTransactionException {

	private String TransactionStatus;
	private RdpReasonCodeModel TransactionReasonCode;
	private List<RdpProductException> ProductExceptions;
	
	public String getTransactionStatus() {
		return TransactionStatus;
	}
	
	public void setTransactionStatus(String transactionStatus) {
		TransactionStatus = transactionStatus;
	}

	public RdpReasonCodeModel getTransactionReasonCode() {
		return TransactionReasonCode;
	}

	public void setTransactionReasonCode(RdpReasonCodeModel transactionReasonCode) {
		TransactionReasonCode = transactionReasonCode;
	}

	public List<RdpProductException> getProductExceptions() {
		return ProductExceptions;
	}

	public void setProductExceptions(List<RdpProductException> productExceptions) {
		ProductExceptions = productExceptions;
	}

}
