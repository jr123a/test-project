package com.lexisnexis.ns.identity_proofing._1;

public class RdpQuestionChoiceModel {

	private String ChoiceId;
	private String Choice;
	private RdpQuestionTextModel Text;
	
	public String getChoiceId() {
		return ChoiceId;
	}
	
	public void setChoiceId(String choiceId) {
		ChoiceId = choiceId;
	}

	public String getChoice() {
		return Choice;
	}

	public void setChoice(String choice) {
		Choice = choice;
	}
	
	public RdpQuestionTextModel getText() {
		return Text;
	}

	public void setText(RdpQuestionTextModel text) {
		Text = text;
	}

}
