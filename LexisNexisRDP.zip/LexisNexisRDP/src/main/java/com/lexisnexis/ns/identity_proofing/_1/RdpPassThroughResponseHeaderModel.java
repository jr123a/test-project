package com.lexisnexis.ns.identity_proofing._1;

public class RdpPassThroughResponseHeaderModel {

	private String TransactionId;

	public String getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}
	
}
