package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpTmxVariablesModel {

	private List<RdpTmxVariableModel> TmxVariables;

	public List<RdpTmxVariableModel> getTmxVariables() {
		return TmxVariables;
	}

	public void setTmxVariables(List<RdpTmxVariableModel> tmxVariables) {
		TmxVariables = tmxVariables;
	}

}
