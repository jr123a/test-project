package com.lexisnexis.ns.identity_proofing._1;

public class RdpDeviceAssessmentModel {

	private String Provider;
	private String SessionId;
	
	public String getProvider() {
		return Provider;
	}
	
	public void setProvider(String provider) {
		Provider = provider;
	}

	public String getSessionId() {
		return SessionId;
	}

	public void setSessionId(String sessionId) {
		SessionId = sessionId;
	}

}
