package com.lexisnexis.ns.identity_proofing._1;

public class RdpProductItemModel {

	private String ItemName;
	private String ItemStatus;
	private RdpItemReasonModel ItemReason;
	
	public String getItemName() {
		return ItemName;
	}
	
	public void setItemName(String itemName) {
		ItemName = itemName;
	}

	public String getItemStatus() {
		return ItemStatus;
	}

	public void setItemStatus(String itemStatus) {
		ItemStatus = itemStatus;
	}

	public RdpItemReasonModel getItemReason() {
		return ItemReason;
	}

	public void setItemReason(RdpItemReasonModel itemReason) {
		ItemReason = itemReason;
	}

}
