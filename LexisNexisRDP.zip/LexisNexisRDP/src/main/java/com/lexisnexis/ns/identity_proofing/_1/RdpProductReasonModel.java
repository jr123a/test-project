package com.lexisnexis.ns.identity_proofing._1;

public class RdpProductReasonModel {

	private String Code;

	public String getCode() {
		return Code;
	}

	public void setCode(String code) {
		Code = code;
	}
	
}
