package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpDeviceAssessmentRequestModel {

	private String Type;
	private RdpSettingsModel Settings;
	private RdpDeviceAssessmentModel DeviceAssessment;
	private List<RdpCustomDataModel> CustomData;
	private List<RdpPersonModel> Persons;
	private List<RdpBusinessModel> Businesses;
	private String CustomerIpAddress;
	
	public String getType() {
		return Type;
	}
	
	public void setType(String type) {
		Type = type;
	}

	public RdpDeviceAssessmentModel getDeviceAssessment() {
		return DeviceAssessment;
	}

	public void setDeviceAssessment(RdpDeviceAssessmentModel deviceAssessment) {
		DeviceAssessment = deviceAssessment;
	}

	public RdpSettingsModel getSettings() {
		return Settings;
	}

	public void setSettings(RdpSettingsModel settings) {
		Settings = settings;
	}

	public List<RdpCustomDataModel> getCustomData() {
		return CustomData;
	}

	public void setCustomData(List<RdpCustomDataModel> customData) {
		CustomData = customData;
	}

	public List<RdpPersonModel> getPersons() {
		return Persons;
	}

	public void setPersons(List<RdpPersonModel> persons) {
		Persons = persons;
	}

	public List<RdpBusinessModel> getBusinesses() {
		return Businesses;
	}

	public void setBusinesses(List<RdpBusinessModel> businesses) {
		Businesses = businesses;
	}

	public String getCustomerIpAddress() {
		return CustomerIpAddress;
	}

	public void setCustomerIpAddress(String customerIpAddress) {
		CustomerIpAddress = customerIpAddress;
	}

}
