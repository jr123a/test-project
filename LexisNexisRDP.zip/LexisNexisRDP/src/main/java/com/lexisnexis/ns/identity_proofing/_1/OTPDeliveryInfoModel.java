package com.lexisnexis.ns.identity_proofing._1;

public class OTPDeliveryInfoModel {

	private String Method;
	private String Language;

	public String getMethod() {
		return Method;
	}

	public void setMethod(String method) {
		Method = method;
	}

	public String getLanguage() {
		return Language;
	}

	public void setLanguage(String language) {
		Language = language;
	}

}
