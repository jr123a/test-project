package com.lexisnexis.ns.identity_proofing._1;

public class TmxQueryRequestModel {

	private String account_email;
	private String account_login;
	private String action;
	private String api_key;
	
	private String org_id;
	private String output_format;
	
	private String service_type;

	public String getAccount_email() {
		return account_email;
	}

	public void setAccount_email(String account_email) {
		this.account_email = account_email;
	}

	public String getAccount_login() {
		return account_login;
	}

	public void setAccount_login(String account_login) {
		this.account_login = account_login;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getApi_key() {
		return api_key;
	}

	public void setApi_key(String api_key) {
		this.api_key = api_key;
	}

	public String getOrg_id() {
		return org_id;
	}

	public void setOrg_id(String org_id) {
		this.org_id = org_id;
	}

	public String getOutput_format() {
		return output_format;
	}

	public void setOutput_format(String output_format) {
		this.output_format = output_format;
	}

	public String getService_type() {
		return service_type;
	}

	public void setService_type(String service_type) {
		this.service_type = service_type;
	}
	

}
