package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpProductModel {

	private String ProductType;
	private String ExecutedStepName;
	private String ProductConfigurationName;
	private String ProductStatus;
	private RdpReasonCodeModel ProductReason;
	private List<RdpProductItemModel> Items;
	private RdpQuestionSetModel QuestionSet;
	private List<OTPParameterDetailsModel> ParameterDetails;

	public String getProductType() {
		return ProductType;
	}
	
	public void setProductType(String productType) {
		ProductType = productType;
	}

	public String getExecutedStepName() {
		return ExecutedStepName;
	}

	public void setExecutedStepName(String executedStepName) {
		ExecutedStepName = executedStepName;
	}

	public String getProductConfigurationName() {
		return ProductConfigurationName;
	}

	public void setProductConfigurationName(String productConfigurationName) {
		ProductConfigurationName = productConfigurationName;
	}

	public String getProductStatus() {
		return ProductStatus;
	}

	public void setProductStatus(String productStatus) {
		ProductStatus = productStatus;
	}

	public RdpReasonCodeModel getProductReason() {
		return ProductReason;
	}

	public void setProductReason(RdpReasonCodeModel productReason) {
		ProductReason = productReason;
	}
	
	public List<RdpProductItemModel> getItems() {
		return Items;
	}

	public void setItems(List<RdpProductItemModel> items) {
		Items = items;
	}

	public RdpQuestionSetModel getQuestionSet() {
		return QuestionSet;
	}

	public void setQuestionSet(RdpQuestionSetModel questionSet) {
		QuestionSet = questionSet;
	}

	public List<OTPParameterDetailsModel> getParameterDetails() {
		return ParameterDetails;
	}

	public void setParameterDetails(List<OTPParameterDetailsModel> parameterDetails) {
		ParameterDetails = parameterDetails;
	}
	
}
