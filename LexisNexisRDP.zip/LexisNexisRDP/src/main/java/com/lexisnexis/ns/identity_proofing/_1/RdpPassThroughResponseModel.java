package com.lexisnexis.ns.identity_proofing._1;

public class RdpPassThroughResponseModel {

	private RdpPassThroughResponseHeaderModel Header;
	private RdpPassThroughResponseSummaryModel Summary;
	private RdpPassThroughResponseDataModel Data;
	
	public RdpPassThroughResponseHeaderModel getHeader() {
		return Header;
	}
	
	public void setHeader(RdpPassThroughResponseHeaderModel header) {
		Header = header;
	}

	public RdpPassThroughResponseSummaryModel getSummary() {
		return Summary;
	}

	public void setSummary(RdpPassThroughResponseSummaryModel summary) {
		Summary = summary;
	}

	public RdpPassThroughResponseDataModel getData() {
		return Data;
	}

	public void setData(RdpPassThroughResponseDataModel data) {
		Data = data;
	}

}
