package com.lexisnexis.ns.identity_proofing._1;

public class RdpPassThroughResponseSummaryModel {

	private String ApiType;
	private String OrgId;
	private String Policy;
	private String PolicyScore;
	private String RequestDuration;
	private String RequestId;
	private String RequestResult;
	private String ReviewStatus;
	private String RiskRating;
	private String ServiceType;
	private String SummaryRiskScore;
	private String conversationId;
	private RdpReasonCodesModel ReasonCodes;
	
	public String getApiType() {
		return ApiType;
	}
	
	public void setApiType(String apiType) {
		ApiType = apiType;
	}

	public String getOrgId() {
		return OrgId;
	}

	public void setOrgId(String orgId) {
		OrgId = orgId;
	}

	public String getPolicy() {
		return Policy;
	}

	public void setPolicy(String policy) {
		Policy = policy;
	}

	public String getPolicyScore() {
		return PolicyScore;
	}

	public void setPolicyScore(String policyScore) {
		PolicyScore = policyScore;
	}

	public String getRequestDuration() {
		return RequestDuration;
	}

	public void setRequestDuration(String requestDuration) {
		RequestDuration = requestDuration;
	}

	public String getRequestId() {
		return RequestId;
	}

	public void setRequestId(String requestId) {
		RequestId = requestId;
	}

	public String getRequestResult() {
		return RequestResult;
	}

	public void setRequestResult(String requestResult) {
		RequestResult = requestResult;
	}

	public String getReviewStatus() {
		return ReviewStatus;
	}

	public void setReviewStatus(String reviewStatus) {
		ReviewStatus = reviewStatus;
	}

	public String getRiskRating() {
		return RiskRating;
	}

	public void setRiskRating(String riskRating) {
		RiskRating = riskRating;
	}

	public String getServiceType() {
		return ServiceType;
	}

	public void setServiceType(String serviceType) {
		ServiceType = serviceType;
	}

	public String getSummaryRiskScore() {
		return SummaryRiskScore;
	}

	public void setSummaryRiskScore(String summaryRiskScore) {
		SummaryRiskScore = summaryRiskScore;
	}

	public RdpReasonCodesModel getReasonCodes() {
		return ReasonCodes;
	}

	public void setReasonCodes(RdpReasonCodesModel reasonCodes) {
		ReasonCodes = reasonCodes;
	}

	public String getConversationId() {
		return conversationId;
	}

	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
	
}
