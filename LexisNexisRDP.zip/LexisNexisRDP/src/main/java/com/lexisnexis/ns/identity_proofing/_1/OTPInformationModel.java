package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class OTPInformationModel {

	private String InformationType;
	private String Code;
	private String Description;
	private List<OTPDetailDescription> DetailDescription;

	public String getInformationType() {
		return InformationType;
	}

	public void setInformationType(String informationType) {
		InformationType = informationType;
	}

	public String getCode() {
		return Code;
	}

	public void setCode(String code) {
		Code = code;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public List<OTPDetailDescription> getDetailDescription() {
		return DetailDescription;
	}

	public void setDetailDescription(List<OTPDetailDescription> detailDescription) {
		DetailDescription = detailDescription;
	}

}
