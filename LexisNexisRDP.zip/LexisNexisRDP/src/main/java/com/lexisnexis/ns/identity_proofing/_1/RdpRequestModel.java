package com.lexisnexis.ns.identity_proofing._1;

import java.util.List;

public class RdpRequestModel {

	private String Type;
	private RdpSettingsModel Settings;
	private List<RdpPersonModel> Persons;
	private RdpAnswerSetModel Answers;
	private OTPDeliveryInfoModel OtpDeliveryInfo;
	private String Passcode;
	private List<SMSCustomDataModel> CustomData;
	
	public String getType() {
		return Type;
	}

	public void setType(String type) {
		this.Type = type;
	}

	public RdpSettingsModel getSettings() {
		return Settings;
	}

	public void setSettings(RdpSettingsModel settings) {
		this.Settings = settings;
	}

	public List<RdpPersonModel> getPersons() {
		return Persons;
	}

	public void setPersons(List<RdpPersonModel> persons) {
		this.Persons = persons;
	}

	public RdpAnswerSetModel getAnswers() {
		return Answers;
	}

	public void setAnswers(RdpAnswerSetModel answers) {
		Answers = answers;
	}

	public OTPDeliveryInfoModel getOtpDeliveryInfo() {
		return OtpDeliveryInfo;
	}

	public void setOtpDeliveryInfo(OTPDeliveryInfoModel otpDeliveryInfo) {
		OtpDeliveryInfo = otpDeliveryInfo;
	}

	public String getPasscode() {
		return Passcode;
	}

	public void setPasscode(String passcode) {
		this.Passcode = passcode;
	}

	public List<SMSCustomDataModel> getCustomData() {
		return CustomData;
	}

	public void setCustomData(List<SMSCustomDataModel> customData) {
		CustomData = customData;
	}
}
