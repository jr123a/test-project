package com.lexisnexis.ns.identity_proofing._1;

public class RdpAccountAddressCountryModel {

	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
