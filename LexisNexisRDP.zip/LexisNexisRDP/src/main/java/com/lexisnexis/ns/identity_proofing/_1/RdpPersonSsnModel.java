package com.lexisnexis.ns.identity_proofing._1;

public class RdpPersonSsnModel {

	private String Number;
	private String Type;
	
	public String getNumber() {
		return Number;
	}
	
	public void setNumber(String number) {
		Number = number;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

}
