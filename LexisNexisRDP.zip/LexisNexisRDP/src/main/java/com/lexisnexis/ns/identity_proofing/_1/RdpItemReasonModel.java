package com.lexisnexis.ns.identity_proofing._1;

public class RdpItemReasonModel {

	private String Code;
	private String Description;
	
	public String getCode() {
		return Code;
	}
	
	public void setCode(String code) {
		Code = code;
	}
	
	public String getDescription() {
		return Description;
	}
	
	public void setDescription(String description) {
		Description = description;
	}
}
