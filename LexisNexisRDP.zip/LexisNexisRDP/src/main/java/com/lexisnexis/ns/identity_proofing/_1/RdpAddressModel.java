package com.lexisnexis.ns.identity_proofing._1;

public class RdpAddressModel {

	private String StreetAddress1;
	private String StreetAddress2;
	private String City;
	private String State;
	private String Zip5;
	private String Country;
	private String Context;

	public String getStreetAddress1() {
		return StreetAddress1;
	}

	public void setStreetAddress1(String streetAddress1) {
		this.StreetAddress1 = streetAddress1;
	}

	public String getStreetAddress2() {
		return StreetAddress2;
	}

	public void setStreetAddress2(String streetAddress2) {
		StreetAddress2 = streetAddress2;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		this.City = city;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		this.State = state;
	}

	public String getZip5() {
		return Zip5;
	}

	public void setZip5(String zip5) {
		this.Zip5 = zip5;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		this.Country = country;
	}

	public String getContext() {
		return Context;
	}

	public void setContext(String context) {
		this.Context = context;
	}
}
