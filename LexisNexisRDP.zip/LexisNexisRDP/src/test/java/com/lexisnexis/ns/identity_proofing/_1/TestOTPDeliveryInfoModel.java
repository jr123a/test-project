package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import org.junit.jupiter.api.Test;

class TestOTPDeliveryInfoModel {

	@Test
	void testEquals() {
		OTPDeliveryInfoModel model = new OTPDeliveryInfoModel();
		model.setMethod("method");
		model.setLanguage("language");
		
		OTPDeliveryInfoModel model2 = new OTPDeliveryInfoModel();
		model2 = model;
		assertEquals(model, model2, "Two OTPDeliveryInfoModel are equal");
	}

	@Test
	void testNotEquals() {
		OTPDeliveryInfoModel model = new OTPDeliveryInfoModel();
		model.setMethod("method");
		model.setLanguage("language");

		OTPDeliveryInfoModel model2 = new OTPDeliveryInfoModel();
		model2.setMethod(model.getMethod());
		model2.setLanguage(model.getLanguage());
		
		assertNotEquals(model, model2, "Two OTPDeliveryInfoModel are not equal");
	}
}
