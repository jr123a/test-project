package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TestRdpAnswerSetModel {

	@Test
	void testEquals() {
		RdpAnswerSetModel model = new RdpAnswerSetModel();
		List<RdpAnswerModel> questions = new ArrayList<>();
		model.setQuestionSetId(1);
		model.setQuestions(questions);
		
		RdpAnswerSetModel model2 = new RdpAnswerSetModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpAnswerSetModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpAnswerSetModel model = new RdpAnswerSetModel();
		List<RdpAnswerModel> questions = new ArrayList<>();
		model.setQuestionSetId(1);
		model.setQuestions(questions);

		RdpAnswerSetModel model2 = new RdpAnswerSetModel();
		model2.setQuestionSetId(model.getQuestionSetId());
		model2.setQuestions(model.getQuestions());
		
		assertNotEquals(model, model2, "Two RdpAnswerSetModel are not equal");
	}
}
