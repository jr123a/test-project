package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestRdpPersonSsnModel {

	@Test
	void testEquals() {
		RdpPersonSsnModel model = new RdpPersonSsnModel();
		model.setNumber("number");
		model.setType("type");
		
		RdpPersonSsnModel model2 = new RdpPersonSsnModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpPersonSsnModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpPersonSsnModel model = new RdpPersonSsnModel();
		model.setNumber("number");
		model.setType("type");

		RdpPersonSsnModel model2 = new RdpPersonSsnModel();
		model2.setNumber(model.getNumber());
		model2.setType(model.getType());
		
		assertNotEquals(model, model2, "Two RdpPersonSsnModel are not equal");
	}
}
