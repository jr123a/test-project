package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestRdpQuestionTextModel {

	@Test
	void testEquals() {
		RdpQuestionTextModel model = new RdpQuestionTextModel();
		model.setStatement("statement");
		
		RdpQuestionTextModel model2 = new RdpQuestionTextModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpQuestionTextModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpQuestionTextModel model = new RdpQuestionTextModel();
		model.setStatement("statement");

		RdpQuestionTextModel model2 = new RdpQuestionTextModel();
		model2.setStatement(model.getStatement());
		
		assertNotEquals(model, model2, "Two RdpQuestionTextModel are not equal");
	}
}
