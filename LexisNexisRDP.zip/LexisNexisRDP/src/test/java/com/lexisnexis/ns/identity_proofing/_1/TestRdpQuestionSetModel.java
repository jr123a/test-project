package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TestRdpQuestionSetModel {

	@Test
	void testEquals() {
		RdpQuestionSetModel model = new RdpQuestionSetModel();
		List<RdpQuestionModel> questions = new ArrayList<>();
		model.setQuestionSetId(1);
		model.setQuestions(questions);
		
		RdpQuestionSetModel model2 = new RdpQuestionSetModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpQuestionSetModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpQuestionSetModel model = new RdpQuestionSetModel();
		List<RdpQuestionModel> questions = new ArrayList<>();
		model.setQuestionSetId(1);
		model.setQuestions(questions);

		RdpQuestionSetModel model2 = new RdpQuestionSetModel();
		model2.setQuestionSetId(model.getQuestionSetId());
		model2.setQuestions(model.getQuestions());
		
		assertNotEquals(model, model2, "Two RdpQuestionSetModel are not equal");
	}
}
