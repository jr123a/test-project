package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestRdpPersonNameModel {

	@Test
	void testEquals() {
		RdpPersonNameModel model = new RdpPersonNameModel();
		model.setFirstName("John");
		model.setLastName("Smith");
		
		RdpPersonNameModel model2 = new RdpPersonNameModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpPersonNameModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpPersonNameModel model = new RdpPersonNameModel();
		model.setFirstName("John");
		model.setLastName("Smith");

		RdpPersonNameModel model2 = new RdpPersonNameModel();
		model2.setFirstName(model.getFirstName());
		model2.setLastName(model.getLastName());
		
		assertNotEquals(model, model2, "Two RdpPersonNameModel are not equal");
	}
}
