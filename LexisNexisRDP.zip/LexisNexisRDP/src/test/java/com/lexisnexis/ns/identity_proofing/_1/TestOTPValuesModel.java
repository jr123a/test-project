package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestOTPValuesModel {

	@Test
	void testEquals() {
		OTPValuesModel model = new OTPValuesModel();
		model.setValue("value");
		
		OTPValuesModel model2 = new OTPValuesModel();
		model2 = model;
		assertEquals(model, model2, "Two OTPValuesModel are equal");
	}

	@Test
	void testNotEquals() {
		OTPValuesModel model = new OTPValuesModel();
		model.setValue("value");

		OTPValuesModel model2 = new OTPValuesModel();
		model2.setValue(model.getValue());
		
		assertNotEquals(model, model2, "Two OTPValuesModel are not equal");
	}
}
