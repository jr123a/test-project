package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestRdpPhoneModel {

	@Test
	void testEquals() {
		RdpPhoneModel model = new RdpPhoneModel();
		model.setNumber("number");
		model.setContext("context");
		
		RdpPhoneModel model2 = new RdpPhoneModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpPhoneModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpPhoneModel model = new RdpPhoneModel();
		model.setNumber("number");
		model.setContext("context");

		RdpPhoneModel model2 = new RdpPhoneModel();
		model2.setNumber(model.getNumber());
		model2.setContext(model.getContext());
		
		assertNotEquals(model, model2, "Two RdpPhoneModel are not equal");
	}
}
