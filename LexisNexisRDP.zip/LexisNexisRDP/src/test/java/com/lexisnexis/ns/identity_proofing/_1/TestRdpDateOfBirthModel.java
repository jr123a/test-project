package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestRdpDateOfBirthModel {

	@Test
	void testEquals() {
		RdpDateOfBirthModel model = new RdpDateOfBirthModel();
		model.setYear("2019");
		model.setMonth("January");
		model.setDay("2");
		
		RdpDateOfBirthModel model2 = new RdpDateOfBirthModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpDateOfBirthModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpDateOfBirthModel model = new RdpDateOfBirthModel();
		model.setYear("2019");
		model.setMonth("January");
		model.setDay("2");

		RdpDateOfBirthModel model2 = new RdpDateOfBirthModel();
		model2.setYear(model.getYear());
		model2.setMonth(model.getMonth());
		model2.setDay(model.getDay());
		
		assertNotEquals(model, model2, "Two RdpDateOfBirthModel are not equal");
	}
}
