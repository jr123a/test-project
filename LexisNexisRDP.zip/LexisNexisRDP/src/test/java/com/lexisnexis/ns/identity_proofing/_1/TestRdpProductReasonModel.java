package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestRdpProductReasonModel {

	@Test
	void testEquals() {
		RdpProductReasonModel model = new RdpProductReasonModel();
		model.setCode("code");
		
		RdpProductReasonModel model2 = new RdpProductReasonModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpProductReasonModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpProductReasonModel model = new RdpProductReasonModel();
		model.setCode("code");

		RdpProductReasonModel model2 = new RdpProductReasonModel();
		model2.setCode(model.getCode());
		
		assertNotEquals(model, model2, "Two RdpProductReasonModel are not equal");
	}
}
