package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestRdpQuestionChoiceModel {

	@Test
	void testEquals() {
		RdpQuestionChoiceModel model = new RdpQuestionChoiceModel();
		RdpQuestionTextModel text = new RdpQuestionTextModel();
		model.setChoiceId("choiceId");
		model.setChoice("choice");
		model.setText(text);
		
		RdpQuestionChoiceModel model2 = new RdpQuestionChoiceModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpQuestionChoiceModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpQuestionChoiceModel model = new RdpQuestionChoiceModel();
		RdpQuestionTextModel text = new RdpQuestionTextModel();
		model.setChoiceId("choiceId");
		model.setChoice("choice");
		model.setText(text);

		RdpQuestionChoiceModel model2 = new RdpQuestionChoiceModel();
		model2.setChoiceId(model.getChoiceId());
		model2.setChoice(model.getChoice());
		model2.setText(model.getText());
		
		assertNotEquals(model, model2, "Two RdpQuestionChoiceModel are not equal");
	}
}
