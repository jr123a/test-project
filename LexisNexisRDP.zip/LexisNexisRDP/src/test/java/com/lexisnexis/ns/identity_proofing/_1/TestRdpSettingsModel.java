package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestRdpSettingsModel {

	@Test
	void testEquals() {
		RdpSettingsModel model = new RdpSettingsModel();
		model.setMode("mode");
		model.setReference("reference");
		model.setLocale("locale");
		model.setVenue("venue");
		
		RdpSettingsModel model2 = new RdpSettingsModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpSettingsModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpSettingsModel model = new RdpSettingsModel();
		model.setMode("mode");
		model.setReference("reference");
		model.setLocale("locale");
		model.setVenue("venue");

		RdpSettingsModel model2 = new RdpSettingsModel();
		model2.setMode(model.getMode());
		model2.setReference(model.getReference());
		model2.setLocale(model.getLocale());
		model2.setVenue(model.getVenue());
		
		assertNotEquals(model, model2, "Two RdpSettingsModel are not equal");
	}
}
