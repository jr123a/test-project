package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TestOTPParameterDetailsModel {

	@Test
	void testEquals() {
		OTPParameterDetailsModel model = new OTPParameterDetailsModel();
		List<OTPValuesModel> values = new ArrayList<>();
		
		model.setGroup("group");
		model.setName("name");
		model.setValues(values);
		
		OTPParameterDetailsModel model2 = new OTPParameterDetailsModel();
		model2 = model;
		assertEquals(model, model2, "Two OTPParameterDetailsModel are equal");
	}

	@Test
	void testNotEquals() {
		OTPParameterDetailsModel model = new OTPParameterDetailsModel();
		List<OTPValuesModel> values = new ArrayList<>();
		
		model.setGroup("group");
		model.setName("name");
		model.setValues(values);

		OTPParameterDetailsModel model2 = new OTPParameterDetailsModel();		
		model2.setGroup(model.getGroup());
		model2.setName(model.getName());
		model2.setValues(model.getValues());
		
		assertNotEquals(model, model2, "Two OTPParameterDetailsModel are not equal");
	}
}
