package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import org.junit.jupiter.api.Test;

class TestOTPDetailDescription {

	@Test
	void testEquals() {
		OTPDetailDescription model = new OTPDetailDescription();
		model.setText("text");
		
		OTPDetailDescription model2 = new OTPDetailDescription();
		model2 = model;
		assertEquals(model, model2, "Two OTPDetailDescription are equal");
	}

	@Test
	void testNotEquals() {
		OTPDetailDescription model = new OTPDetailDescription();
		model.setText("text");

		OTPDetailDescription model2 = new OTPDetailDescription();
		model2.setText(model.getText());
		
		assertNotEquals(model, model2, "Two OTPDetailDescription are not equal");
	}
}
