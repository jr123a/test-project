package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import org.junit.jupiter.api.Test;

class TestRdpProductException {

	@Test
	void testEquals() {
		RdpProductException model = new RdpProductException();
		RdpReasonCodeModel productReason = new RdpReasonCodeModel();
		model.setProductType("productType");
		model.setProductStatus("productStatus");
		model.setProductReason(productReason);
		
		RdpProductException model2 = new RdpProductException();
		model2 = model;
		assertEquals(model, model2, "Two RdpProductException are equal");
	}

	@Test
	void testNotEquals() {
		RdpProductException model = new RdpProductException();
		RdpReasonCodeModel productReason = new RdpReasonCodeModel();
		model.setProductType("productType");
		model.setProductStatus("productStatus");
		model.setProductReason(productReason);

		RdpProductException model2 = new RdpProductException();
		model2.setProductType(model.getProductType());
		model2.setProductType(model.getProductType());
		model2.setProductType(model.getProductType());
		
		assertNotEquals(model, model2, "Two RdpProductException are not equal");
	}
}
