package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestRdpReasonCodeModel {

	@Test
	void testEquals() {
		RdpReasonCodeModel model = new RdpReasonCodeModel();
		model.setCode("code");
		
		RdpReasonCodeModel model2 = new RdpReasonCodeModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpReasonCodeModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpReasonCodeModel model = new RdpReasonCodeModel();
		model.setCode("code");

		RdpReasonCodeModel model2 = new RdpReasonCodeModel();
		model2.setCode(model.getCode());
		
		assertNotEquals(model, model2, "Two RdpReasonCodeModel are not equal");
	}
}
