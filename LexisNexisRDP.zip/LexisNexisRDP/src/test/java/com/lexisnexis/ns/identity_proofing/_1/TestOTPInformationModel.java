package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TestOTPInformationModel {

	@Test
	void testEquals() {
		OTPInformationModel model = new OTPInformationModel();
		List<OTPDetailDescription> detailDescription = new ArrayList<>();
		
		model.setInformationType("informationType");
		model.setCode("code");
		model.setDescription("description");
		model.setDetailDescription(detailDescription);
		
		OTPInformationModel model2 = new OTPInformationModel();
		model2 = model;
		assertEquals(model, model2, "Two OTPInformationModel are equal");
	}

	@Test
	void testNotEquals() {
		OTPInformationModel model = new OTPInformationModel();
		List<OTPDetailDescription> detailDescription = new ArrayList<>();
		
		model.setInformationType("informationType");
		model.setCode("code");
		model.setDescription("description");
		model.setDetailDescription(detailDescription);

		OTPInformationModel model2 = new OTPInformationModel();
		model2.setInformationType(model.getInformationType());
		model2.setCode(model.getCode());
		model2.setDescription(model.getDescription());
		model2.setDetailDescription(model.getDetailDescription());
		
		assertNotEquals(model, model2, "Two OTPInformationModel are not equal");
	}
}
