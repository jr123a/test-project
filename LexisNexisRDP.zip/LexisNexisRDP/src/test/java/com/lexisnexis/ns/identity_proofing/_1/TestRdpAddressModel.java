package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import org.junit.jupiter.api.Test;

class TestRdpAddressModel {

	@Test
	void testEquals() {
		RdpAddressModel model = new RdpAddressModel();
		model.setStreetAddress1("address1");
		model.setCity("city");
		model.setState("state");
		model.setZip5("zip5");
		model.setCountry("country");
		model.setContext("context");
		
		RdpAddressModel model2 = new RdpAddressModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpAddressModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpAddressModel model = new RdpAddressModel();
		model.setStreetAddress1("address1");
		model.setCity("city");
		model.setState("state");
		model.setZip5("zip5");
		model.setCountry("country");
		model.setContext("context");

		RdpAddressModel model2 = new RdpAddressModel();
		model2.setStreetAddress1(model.getStreetAddress1());
		model2.setCity(model.getCity());
		model2.setState(model.getState());
		model2.setZip5(model.getZip5());
		model2.setCountry(model.getCountry());
		model2.setContext(model.getContext());
		
		assertNotEquals(model, model2, "Two RdpAddressModel are not equal");
	}
}
