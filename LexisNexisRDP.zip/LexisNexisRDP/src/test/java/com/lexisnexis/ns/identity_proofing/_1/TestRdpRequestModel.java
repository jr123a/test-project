package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TestRdpRequestModel {

	@Test
	void testEquals() {
		RdpRequestModel model = new RdpRequestModel();
		List<RdpPersonModel> persons = new ArrayList<>();
		RdpSettingsModel settings = new RdpSettingsModel();
		RdpAnswerSetModel answers = new RdpAnswerSetModel();
		OTPDeliveryInfoModel otpDeliveryInfo = new OTPDeliveryInfoModel();
		
		model.setType("type");
		model.setSettings(settings);
		model.setPersons(persons);
		model.setAnswers(answers);
		model.setOtpDeliveryInfo(otpDeliveryInfo);
		model.setPasscode("passcode");
		
		RdpRequestModel model2 = new RdpRequestModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpRequestModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpRequestModel model = new RdpRequestModel();
		List<RdpPersonModel> persons = new ArrayList<>();
		RdpSettingsModel settings = new RdpSettingsModel();
		RdpAnswerSetModel answers = new RdpAnswerSetModel();
		OTPDeliveryInfoModel otpDeliveryInfo = new OTPDeliveryInfoModel();
		
		model.setType("type");
		model.setSettings(settings);
		model.setPersons(persons);
		model.setAnswers(answers);
		model.setOtpDeliveryInfo(otpDeliveryInfo);
		model.setPasscode("passcode");

		RdpRequestModel model2 = new RdpRequestModel();
		model2.setType(model.getType());
		model2.setSettings(model.getSettings());
		model2.setPersons(model.getPersons());
		model2.setAnswers(model.getAnswers());
		model2.setOtpDeliveryInfo(model.getOtpDeliveryInfo());
		model2.setPasscode(model.getPasscode());
		
		assertNotEquals(model, model2, "Two RdpRequestModel are not equal");
	}
}
