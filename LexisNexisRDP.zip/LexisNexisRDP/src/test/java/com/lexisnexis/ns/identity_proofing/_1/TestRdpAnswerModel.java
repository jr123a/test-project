package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TestRdpAnswerModel {

	@Test
	void testEquals() {
		RdpAnswerModel model = new RdpAnswerModel();
		List<RdpQuestionChoiceModel> choices = new ArrayList<>();
		model.setQuestionId(1L);
		model.setChoices(choices);
		
		RdpAnswerModel model2 = new RdpAnswerModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpAnswerModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpAnswerModel model = new RdpAnswerModel();
		List<RdpQuestionChoiceModel> choices = new ArrayList<>();
		model.setQuestionId(1L);
		model.setChoices(choices);

		RdpAnswerModel model2 = new RdpAnswerModel();
		model2.setQuestionId(model.getQuestionId());
		model2.setChoices(model.getChoices());
		
		assertNotEquals(model, model2, "Two RdpAnswerModel are not equal");
	}
}
