package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestRdpStatusModel {

	@Test
	void testEquals() {
		RdpStatusModel model = new RdpStatusModel();
		RdpReasonCodeModel transactionReasonCode = new RdpReasonCodeModel();
		model.setConversationId("conversationId");
		model.setRequestId("requestId");
		model.setTransactionStatus("transactionStatus");
		model.setActionType("actionType");
		model.setReference("reference");
		model.setLexID("lexID");
		model.setTransactionReasonCode(transactionReasonCode);
		
		RdpStatusModel model2 = new RdpStatusModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpStatusModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpStatusModel model = new RdpStatusModel();
		RdpReasonCodeModel transactionReasonCode = new RdpReasonCodeModel();
		model.setConversationId("conversationId");
		model.setRequestId("requestId");
		model.setTransactionStatus("transactionStatus");
		model.setActionType("actionType");
		model.setReference("reference");
		model.setLexID("lexID");
		model.setTransactionReasonCode(transactionReasonCode);

		RdpStatusModel model2 = new RdpStatusModel();
		model2.setConversationId(model.getConversationId());
		model2.setRequestId(model.getRequestId());
		model2.setTransactionStatus(model.getTransactionStatus());
		model2.setActionType(model.getActionType());
		model2.setReference(model.getReference());
		model2.setLexID(model.getLexID());
		model2.setTransactionReasonCode(model.getTransactionReasonCode());
		
		assertNotEquals(model, model2, "Two RdpStatusModel are not equal");
	}
}
