package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TestRdpProductModel {

	@Test
	void testEquals() {
		RdpProductModel model = new RdpProductModel();
		List<RdpProductItemModel> items = new ArrayList<>();
		List<OTPParameterDetailsModel> parameterDetails = new ArrayList<>();
		RdpReasonCodeModel productReason = new RdpReasonCodeModel();
		RdpQuestionSetModel questionSet = new RdpQuestionSetModel();
		
		model.setProductType("productType");
		model.setExecutedStepName("executedStepName");
		model.setProductConfigurationName("productConfigurationName");
		model.setProductStatus("productStatus");
		model.setProductReason(productReason);
		model.setItems(items);
		model.setQuestionSet(questionSet);
		model.setParameterDetails(parameterDetails);
		
		RdpProductModel model2 = new RdpProductModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpProductModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpProductModel model = new RdpProductModel();
		List<RdpProductItemModel> items = new ArrayList<>();
		List<OTPParameterDetailsModel> parameterDetails = new ArrayList<>();
		RdpReasonCodeModel productReason = new RdpReasonCodeModel();
		RdpQuestionSetModel questionSet = new RdpQuestionSetModel();
		
		model.setProductType("productType");
		model.setExecutedStepName("executedStepName");
		model.setProductConfigurationName("productConfigurationName");
		model.setProductStatus("productStatus");
		model.setProductReason(productReason);
		model.setItems(items);
		model.setQuestionSet(questionSet);
		model.setParameterDetails(parameterDetails);

		RdpProductModel model2 = new RdpProductModel();
		model2.setProductType(model.getProductType());
		model2.setExecutedStepName(model.getExecutedStepName());
		model2.setProductConfigurationName(model.getProductConfigurationName());
		model2.setProductStatus(model.getProductStatus());
		model2.setProductReason(model.getProductReason());	
		model2.setItems(model.getItems());
		model2.setQuestionSet(model.getQuestionSet());
		model2.setParameterDetails(model.getParameterDetails());
		
		assertNotEquals(model, model2, "Two RdpProductModel are not equal");
	}
}
