package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TestRdpResponseModel {

	@Test
	void testEquals() {
		RdpResponseModel model = new RdpResponseModel();
		List<RdpProductModel> products = new ArrayList<>();
		List<OTPInformationModel> information = new ArrayList<>();
		RdpStatusModel status = new RdpStatusModel();
		
		model.setStatus(status);
		model.setProducts(products);
		model.setInformation(information);
		
		RdpResponseModel model2 = new RdpResponseModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpResponseModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpResponseModel model = new RdpResponseModel();
		List<RdpProductModel> products = new ArrayList<>();
		List<OTPInformationModel> information = new ArrayList<>();
		RdpStatusModel status = new RdpStatusModel();
		
		model.setStatus(status);
		model.setProducts(products);
		model.setInformation(information);

		RdpResponseModel model2 = new RdpResponseModel();
		model2.setStatus(model.getStatus());
		model2.setProducts(model.getProducts());
		model2.setInformation(model.getInformation());
		
		assertNotEquals(model, model2, "Two RdpResponseModel are not equal");
	}
}
