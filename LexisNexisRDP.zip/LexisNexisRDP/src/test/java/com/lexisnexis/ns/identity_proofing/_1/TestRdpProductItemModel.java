package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class TestRdpProductItemModel {

	@Test
	void testEquals() {
		RdpProductItemModel model = new RdpProductItemModel();
		model.setItemName("itemName");
		model.setItemStatus("itemStatus");
		
		RdpProductItemModel model2 = new RdpProductItemModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpProductItemModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpProductItemModel model = new RdpProductItemModel();
		model.setItemName("itemName");
		model.setItemStatus("itemStatus");

		RdpProductItemModel model2 = new RdpProductItemModel();
		model2.setItemName(model.getItemName());
		model2.setItemStatus(model.getItemStatus());
		
		assertNotEquals(model, model2, "Two RdpProductItemModel are not equal");
	}
}
