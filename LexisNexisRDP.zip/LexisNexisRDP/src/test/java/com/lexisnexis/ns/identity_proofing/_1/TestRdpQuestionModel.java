package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TestRdpQuestionModel {

	@Test
	void testEquals() {
		RdpQuestionModel model = new RdpQuestionModel();
		List<RdpQuestionChoiceModel> choices = new ArrayList<>();
		RdpQuestionTextModel text = new RdpQuestionTextModel();
		RdpQuestionTextModel helpText = new RdpQuestionTextModel();
		
		model.setQuestionId("questionId");
		model.setKey("key");
		model.setType("type");
		model.setText(text);
		model.setHelpText(helpText);
		model.setChoices(choices);
	
		RdpQuestionModel model2 = new RdpQuestionModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpQuestionModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpQuestionModel model = new RdpQuestionModel();
		List<RdpQuestionChoiceModel> choices = new ArrayList<>();
		RdpQuestionTextModel text = new RdpQuestionTextModel();
		RdpQuestionTextModel helpText = new RdpQuestionTextModel();
		
		model.setQuestionId("questionId");
		model.setKey("key");
		model.setType("type");
		model.setText(text);
		model.setHelpText(helpText);
		model.setChoices(choices);

		RdpQuestionModel model2 = new RdpQuestionModel();
		model2.setQuestionId(model.getQuestionId());
		model2.setKey(model.getKey());
		model2.setType(model.getType());
		model2.setText(model.getText());
		model2.setHelpText(model.getHelpText());
		model2.setChoices(model.getChoices());
		
		assertNotEquals(model, model2, "Two RdpQuestionModel are not equal");
	}
}
