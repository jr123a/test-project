package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TestRdpPersonModel {

	@Test
	void testEquals() {
		RdpPersonModel model = new RdpPersonModel();
		List<RdpAddressModel> addresses = new ArrayList<>();
		List<RdpPhoneModel> phones = new ArrayList<>();
		RdpPersonNameModel name = new RdpPersonNameModel();
		RdpPersonSsnModel ssn = new RdpPersonSsnModel();
		RdpDateOfBirthModel dateOfBirth = new RdpDateOfBirthModel();
		
		model.setName(name);
		model.setAddresses(addresses);
		model.setSSN(ssn);
		model.setDateOfBirth(dateOfBirth);
		model.setPhones(phones);
		model.setContext("context");
		
		RdpPersonModel model2 = new RdpPersonModel();
		model2 = model;
		assertEquals(model, model2, "Two RdpPersonModel are equal");
	}

	@Test
	void testNotEquals() {
		RdpPersonModel model = new RdpPersonModel();
		List<RdpAddressModel> addresses = new ArrayList<>();
		List<RdpPhoneModel> phones = new ArrayList<>();
		RdpPersonNameModel name = new RdpPersonNameModel();
		RdpPersonSsnModel ssn = new RdpPersonSsnModel();
		RdpDateOfBirthModel dateOfBirth = new RdpDateOfBirthModel();
		
		model.setName(name);
		model.setAddresses(addresses);
		model.setSSN(ssn);
		model.setDateOfBirth(dateOfBirth);
		model.setPhones(phones);
		model.setContext("context");

		RdpPersonModel model2 = new RdpPersonModel();
		model2.setName(model.getName());
		model2.setAddresses(model.getAddresses());
		model2.setSSN(model.getSSN());
		model2.setDateOfBirth(model.getDateOfBirth());
		model2.setPhones(model.getPhones());
		model2.setContext(model.getContext());
		
		assertNotEquals(model, model2, "Two RdpPersonModel are not equal");
	}
}
