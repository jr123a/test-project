package com.lexisnexis.ns.identity_proofing._1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TestRdpTransactionException {

	@Test
	void testEquals() {
		RdpTransactionException model = new RdpTransactionException();
		List<RdpProductException> productExceptions = new ArrayList<>();
		RdpReasonCodeModel transactionReasonCode = new RdpReasonCodeModel();
		
		model.setTransactionStatus("transactionStatus");
		model.setTransactionReasonCode(transactionReasonCode);
		model.setProductExceptions(productExceptions);
		
		RdpTransactionException model2 = new RdpTransactionException();
		model2 = model;
		assertEquals(model, model2, "Two RdpTransactionException are equal");
	}

	@Test
	void testNotEquals() {
		RdpTransactionException model = new RdpTransactionException();
		List<RdpProductException> productExceptions = new ArrayList<>();
		RdpReasonCodeModel transactionReasonCode = new RdpReasonCodeModel();
		
		model.setTransactionStatus("transactionStatus");
		model.setTransactionReasonCode(transactionReasonCode);
		model.setProductExceptions(productExceptions);

		RdpTransactionException model2 = new RdpTransactionException();
		model2.setTransactionStatus(model.getTransactionStatus());
		model2.setTransactionReasonCode(model.getTransactionReasonCode());
		model2.setProductExceptions(model.getProductExceptions());
		
		assertNotEquals(model, model2, "Two RdpTransactionException are not equal");
	}
}
