package com.ips.jaxrs;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ibm.websphere.jaxrs.providers.json4j.JSON4JObjectProvider;
import org.springframework.stereotype.Component;

@ApplicationPath("resources")
@Component
public class IPSRemoteRestApplication extends Application implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private static final Logger LOG = LogManager.getLogger(IPSRemoteRestApplication.class.getName()); 
    
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<Class<?>>();
        classes.add(JacksonJsonProvider.class);
        classes.add(JSON4JObjectProvider.class);
        classes.add(RemoteRestResource.class);
        LOG.debug("IPSRemoteRestApplication REST Classes:"+classes);
        return classes;
    }
}
