package com.ips.dao.impl;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.AddressVerificationDao;
import com.ips.entity.AddressVerification;

@Repository
public class AddressVerificationDaoImpl extends GenericJPADAO<AddressVerification, Long>
		implements AddressVerificationDao,Serializable {

	/**
	 * 
	 */
	private static final String DAY_BEFORE = "dayBefore";
	private static final String DAY_AFTER = "dayAfter";

	@SuppressWarnings("unchecked")
	@Override
	public List<AddressVerification> getEventsByCreateDate(Timestamp beforeDate, Timestamp afterDate) {
		Query query = em.createNamedQuery("AddressVerification.getEventsByTransactionEndDate");
		query.setParameter(DAY_BEFORE, beforeDate);
		query.setParameter(DAY_AFTER, afterDate);
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AddressVerification> getAllData() {
		Query query = em.createNamedQuery("AddressVerification.getAllData");
		return query.getResultList();
	}

	@Override
	public void update(AddressVerification av) {
		super.merge(av);
		
	}

}
