package com.ips.dao;

import com.ips.entity.RefLexisNexisReasonCodeMap;

public interface RefLexisNexisReasonCodeMapDao {
    
    RefLexisNexisReasonCodeMap retireveByValue(String column, String value);
}
