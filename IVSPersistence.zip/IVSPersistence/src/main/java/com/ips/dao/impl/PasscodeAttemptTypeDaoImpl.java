package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.PasscodeAttemptTypeDao;
import com.ips.entity.RefOtpAttemptType;

@Repository
public class PasscodeAttemptTypeDaoImpl extends GenericJPADAO<RefOtpAttemptType,String> implements PasscodeAttemptTypeDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefOtpAttemptType> getAll() {
        Query query = em.createNamedQuery("RefOtpAttemptType.findAll");
        return query.getResultList();
    }

    @Override
    public RefOtpAttemptType findAttemptTypeByName(String typeName) {
        Query query = em.createNamedQuery("RefOtpAttemptType.findByAttemptType")
                .setParameter("attemptType", typeName);
        RefOtpAttemptType type = null;
        @SuppressWarnings("unchecked")
        List<RefOtpAttemptType> list = query.getResultList();    
        Optional<RefOtpAttemptType> result = list.stream().findFirst();
        
        if (result.isPresent()) {
            type = result.get();
        }

        return type;
    }
    
    @Override
    public void save(RefOtpAttemptType entity) {
        super.save(entity);
    }

    @Override
    public void update(RefOtpAttemptType entity) {
        super.merge(entity);
    }

    @Override
    public void delete(RefOtpAttemptType entity) {
        super.delete(entity);
    }

}
