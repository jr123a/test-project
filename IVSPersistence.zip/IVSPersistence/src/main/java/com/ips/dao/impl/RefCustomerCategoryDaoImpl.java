package com.ips.dao.impl;

import com.ips.dao.RefCustomerCategoryDao;
import com.ips.entity.RefCustomerCategory;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.io.Serializable;
import java.util.Collection;

@Repository
public class RefCustomerCategoryDaoImpl extends GenericJPADAO<RefCustomerCategory, Long> implements
        RefCustomerCategoryDao,Serializable {

    private static final long serialVersionUID = 1L;

    @Override
    public Collection<RefCustomerCategory> getAll() {
        Query query = em.createNamedQuery("RefCustomerCategory.findAll");
        return query.getResultList();
    }

    @Override
    public RefCustomerCategory getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void save(RefCustomerCategory customerCategory) {
        super.persist(customerCategory);
    }

    @Override
    public void update(RefCustomerCategory customerCategory) {
        super.merge(customerCategory);
    }

    @Override
    public void delete(RefCustomerCategory customerCategory) {
        super.delete(customerCategory);
    }
}
