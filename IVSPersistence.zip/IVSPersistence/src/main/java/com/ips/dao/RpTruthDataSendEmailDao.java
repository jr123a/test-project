package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RpTruthDataSendEmail;
import com.ips.persistence.common.FraudEmailVo;

public interface RpTruthDataSendEmailDao {

    Collection<RpTruthDataSendEmail> getAll();    
    Collection<RpTruthDataSendEmail> getPendingBlacklist();
    Collection<FraudEmailVo> getPendingTIUFraudlist();
    Collection<FraudEmailVo> getPendingTIUFraudlist(Long truthDataSendEmailId);
    RpTruthDataSendEmail getById(Long id);
    void create(RpTruthDataSendEmail entity);
    void update(RpTruthDataSendEmail entity);
}
