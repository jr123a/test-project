package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefPhoneMatchQuality;

public interface PhoneMatchQualityDao {
    Collection<RefPhoneMatchQuality> getAll();    
    RefPhoneMatchQuality getById(Long id);
    void save(RefPhoneMatchQuality entity);
    void update(RefPhoneMatchQuality entity);
    void delete(RefPhoneMatchQuality entity);
    RefPhoneMatchQuality getQualityByName(String name);
}
