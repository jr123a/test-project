package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpSmfaInitiateResponseDao;
import com.ips.entity.RpSmfaInitiateResponse;


@Repository
public class RpSmfaInitiateResponseDaoImpl extends GenericJPADAO<RpSmfaInitiateResponse, Long> implements RpSmfaInitiateResponseDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
    @Override
    public Collection<RpSmfaInitiateResponse> getAll() {        
        Query query = em.createNamedQuery("RpSmfaInitiateResponse.getAll");
        return query.getResultList();
    }

    @Override
    public RpSmfaInitiateResponse getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpSmfaInitiateResponse entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpSmfaInitiateResponse entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpSmfaInitiateResponse entity) {
        super.persist(entity);        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpSmfaInitiateResponse> getListByPersonId(long personId) {
        Query query = em.createNamedQuery("RpSmfaInitiateResponse.getListByPersonId");
        query.setParameter("personId", personId);
         
        return query.getResultList(); 
    }
    
    @Override
    public RpSmfaInitiateResponse getByPersonId(long personId) {
        List<RpSmfaInitiateResponse> results = getListByPersonId(personId);
        
        return results.isEmpty()? null : results.get(0);    
    }
    
    /**
     * Named Query
     */
    @SuppressWarnings("unchecked")
    @Override
    public RpSmfaInitiateResponse getByKbaUid(String kbaUid) {
        Query query = em.createNamedQuery("RpSmfaInitiateResponse.getByKbaUid");
        query.setParameter("kbaUid", kbaUid);
        List<RpSmfaInitiateResponse> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);    
    }
    
    /**
     * Native Query
     */
    @Override
    public String findRedirectUrl(String kbaUid) {
		Query query = em.createNativeQuery("select r.redirect_url from RP_SMFA_INITIATE_RESPONSE r, PERSON p where r.PERSON_ID = p.PERSON_ID and p.KBA_UID = ? ORDER BY r.update_date DESC");
        query.setParameter(1, kbaUid);
        @SuppressWarnings("unchecked")
        List<String> results = query.getResultList();

        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }
    
}
