package com.ips.dao;

import com.ips.entity.IppEventSecondaryID;

public interface IppEventSecondaryIdDao {

    long getSecondaryIdCountByEventSecondary(long idType);

	void delete(IppEventSecondaryID ids);

}
