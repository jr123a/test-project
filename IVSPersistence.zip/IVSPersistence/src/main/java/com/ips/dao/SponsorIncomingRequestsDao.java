package com.ips.dao;

import java.util.List;

import com.ips.entity.SponsorIncomingRequests;

public interface SponsorIncomingRequestsDao {
    void create(SponsorIncomingRequests entity);
    void update(SponsorIncomingRequests entity);
    void delete(SponsorIncomingRequests entity);
    SponsorIncomingRequests findBySponsorAndRequestId(long sponsorId, String requestId);
    int findCountBySponsorIdAndRequestIdAndEndpointName(long sponsorId, String requestId, String endpointName);
    List<SponsorIncomingRequests> findSponsorIncomingRequestsBySponsor(long sponsorId);
}
