package com.ips.dao;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.ips.entity.RpDeviceReputation;
import com.ips.persistence.common.DeviceReputationVo;

public interface RpDeviceReputationDao {

    Collection<RpDeviceReputation> getAll(); 
    List<RpDeviceReputation> getListByPersonId(long personId);
    RpDeviceReputation getById(Long id);
    RpDeviceReputation getByRequestId(String id);
    void create(RpDeviceReputation entity);
    void update(RpDeviceReputation entity);
    RpDeviceReputation getByPersonId(long personId);
    List<RpDeviceReputation> getListByPersonAndAppId(long personId, long appId);
    RpDeviceReputation getBySessionId(String sessionId);
    RpDeviceReputation getByPersonIdSessionIdPhoneNumber(String sessionId, String mobilePhoneNumber, long personId);
    RpDeviceReputation getByPersonAndAppId(long personId, long appId);
    List<DeviceReputationVo> getDeviceReputationReport(Date runDate);
}
