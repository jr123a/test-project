package com.ips.dao.impl;

import java.util.Collection;

import javax.persistence.Query;
import org.springframework.stereotype.Repository;

import com.ips.dao.PhoneMatchQualityDao;
import com.ips.entity.RefPhoneMatchQuality;

@Repository
public class PhoneMatchQualityDaoImpl extends GenericJPADAO<RefPhoneMatchQuality,String> implements PhoneMatchQualityDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefPhoneMatchQuality> getAll() {
        Query query = em.createNamedQuery("RefPhoneMatchQuality.findAll");
        return query.getResultList();
    }

    @Override
    public RefPhoneMatchQuality getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void save(RefPhoneMatchQuality entity) {
        super.save(entity);
    }

    @Override
    public void update(RefPhoneMatchQuality entity) {
        super.merge(entity);
    }

    @Override
    public void delete(RefPhoneMatchQuality entity) {
        super.delete(entity);
    }

    @Override
    public RefPhoneMatchQuality getQualityByName(String name) {
        Query query = em.createNamedQuery("RefPhoneMatchQuality.findByName");
        query.setParameter("name", name);
        
        if (query.getResultList() == null || query.getResultList().isEmpty()) {
            return null;
        } else {
            return (RefPhoneMatchQuality) query.getResultList().get(0);
        }
    }

}
