package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.ips.dao.RefPrimaryIdTypeDao;
import com.ips.entity.RefPrimaryIdType;
import com.ips.entity.RefSecondaryIdType;

@Repository
public class RefPrimaryIdTypeDaoImpl extends GenericJPADAO<RefPrimaryIdType, Long>
        implements RefPrimaryIdTypeDao, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefPrimaryIdType> getAll() {
        Query query = em.createNamedQuery("RefPrimaryIdType.findAll");
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefPrimaryIdType> getAvailableStrongList(Long sponsorId) {
        Query query = em.createNamedQuery("RefPrimaryIdType.findAvailableStrongList").setParameter("sponsorId",
                sponsorId);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefPrimaryIdType> getSponsorStrongList(Long sponsorId) {
        Query query = em.createNamedQuery("RefPrimaryIdType.findSponsorStrongList").setParameter("sponsorId",
                sponsorId);
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefPrimaryIdType> getAllStrongList() {
        Query query = em.createNamedQuery("RefPrimaryIdType.findAllStrongList");
        return query.getResultList();
    }

    @Override
    public RefPrimaryIdType getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void update(RefPrimaryIdType entity) {
        super.merge(entity);
    }

    @SuppressWarnings("unchecked")
    @Override
    public String getDescription(int idType) {
        Query query = em.createNamedQuery("RefPrimaryIdType.getDescription");
        query.setParameter("idType", idType);
        List<String> result = query.getResultList();
        if (!result.isEmpty()) {
            return result.get(0);
        }
        return StringUtils.EMPTY;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefPrimaryIdType> getAvailableIdList(String value) {
        if (!value.isEmpty()) {
            value = value.startsWith(",") ? value.substring(1) : value;
            int[] numbers = Arrays.stream(value.split(",")).mapToInt(Integer::parseInt).toArray();

            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM REF_PRIMARY_ID_TYPE WHERE ID_TYPE NOT IN (");
            for (int i = 0; i < numbers.length; i++) {
                sb.append("?" + (i + 1));
                sb.append(",");
            }
            sb.setLength(sb.length() - 1);
            sb.append(")");
            Query query = em.createNativeQuery(sb.toString(), RefPrimaryIdType.class);
            for (int j = 0; j < numbers.length; j++) {
                query.setParameter(j + 1, numbers[j]);

            }

            return query.getResultList();
        } else {
            return Collections.emptyList();
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefPrimaryIdType> getSponsorAcceptedIdTypeList(String value) {
        if (!value.isEmpty()) {
            value = value.startsWith(",") ? value.substring(1) : value;
            int[] numbers = Arrays.stream(value.split(",")).mapToInt(Integer::parseInt).toArray();

            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM REF_PRIMARY_ID_TYPE WHERE ID_TYPE IN (");
            for (int i = 0; i < numbers.length; i++) {
                sb.append("?" + (i + 1));
                sb.append(",");
            }
            sb.setLength(sb.length() - 1);
            sb.append(")");
            Query query = em.createNativeQuery(sb.toString(), RefPrimaryIdType.class);
            for (int j = 0; j < numbers.length; j++) {
                query.setParameter(j + 1, numbers[j]);

            }

            return query.getResultList();
        } else {
            return Collections.emptyList();
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefSecondaryIdType> getAvailableSecondaryIdList(String value) {
        if (!value.isEmpty()) {
            value = value.startsWith(",") ? value.substring(1) : value;
            int[] numbers = Arrays.stream(value.split(",")).mapToInt(Integer::parseInt).toArray();

            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM REF_SECONDARY_ID_TYPE WHERE ID_TYPE NOT IN (");
            for (int i = 0; i < numbers.length; i++) {
                sb.append("?" + (i + 1));
                sb.append(",");
            }
            sb.setLength(sb.length() - 1);
            sb.append(")");
            Query query = em.createNativeQuery(sb.toString(), RefSecondaryIdType.class);
            for (int j = 0; j < numbers.length; j++) {
                query.setParameter(j + 1, numbers[j]);

            }

            return query.getResultList();
        } else {
            return Collections.emptyList();
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefSecondaryIdType> getSponsorAcceptedSecondaryIdTypeList(String value) {
        if (!value.isEmpty()) {
            value = value.startsWith(",") ? value.substring(1) : value;
            int[] numbers = Arrays.stream(value.split(",")).mapToInt(Integer::parseInt).toArray();

            StringBuilder sb = new StringBuilder();
            sb.append("SELECT * FROM REF_SECONDARY_ID_TYPE WHERE ID_TYPE IN (");
            for (int i = 0; i < numbers.length; i++) {
                sb.append("?" + (i + 1));
                sb.append(",");
            }
            sb.setLength(sb.length() - 1);
            sb.append(")");
            Query query = em.createNativeQuery(sb.toString(), RefSecondaryIdType.class);
            for (int j = 0; j < numbers.length; j++) {
                query.setParameter(j + 1, numbers[j]);

            }

            return query.getResultList();
        } else {
            return Collections.emptyList();
        }
    }
    
}
