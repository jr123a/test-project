package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefRpStatusDao;
import com.ips.entity.RefRpStatus;

@Repository
public class RefRpStatusDaoImpl extends GenericJPADAO<RefRpStatus, Long> implements
        RefRpStatusDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;


    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefRpStatus> getAll() {
//        em = getEntityManager();
        Query query = em.createNamedQuery("RefRpStatus.findAll");
        return query.getResultList();
    }

    @Override
    public RefRpStatus getById(Long id) {
        return super.getById(id);
    }


    @Override
    public void update(RefRpStatus status) {
        super.merge(status);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RefRpStatus findByDescription(String statusDesc) {
        Query query = em.createNamedQuery("RefRpStatus.findByDescription");
        query.setParameter("statusDesc", statusDesc);
        List<RefRpStatus> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
        
    }

}
