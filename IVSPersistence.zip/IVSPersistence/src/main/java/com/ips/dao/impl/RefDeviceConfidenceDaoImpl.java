package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.entity.RefDeviceConfidence;
import com.ips.dao.RefDeviceConfidenceDao;

@Repository
public class RefDeviceConfidenceDaoImpl extends GenericJPADAO<RefDeviceConfidence, Long> implements
RefDeviceConfidenceDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefDeviceConfidence> getAll() {        
        Query query = em.createNamedQuery("RefDeviceConfidence.getAll");
        return query.getResultList();
    }

    @Override
    public RefDeviceConfidence getById(Long id) {        
        return super.getById(id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RefDeviceConfidence getByReputationAssessment(String reputationAssessment) {
        Query query = em.createNamedQuery("RefDeviceConfidence.getByReputationAssessment");
        query.setParameter("reputationAssessment", reputationAssessment);
        List<RefDeviceConfidence> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);    
    }

    @Override
    public void save(RefDeviceConfidence entity) {
        super.save(entity);
    }

    @Override
    public void update(RefDeviceConfidence entity) {
        super.merge(entity);
    }

    @Override
    public void delete(RefDeviceConfidence entity) {
        super.delete(entity);
    }
    
}
