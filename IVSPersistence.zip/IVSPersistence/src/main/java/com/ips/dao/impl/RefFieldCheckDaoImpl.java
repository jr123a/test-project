package com.ips.dao.impl;

import java.util.Collection;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.ips.dao.RefFieldCheckDao;
import com.ips.entity.RefFieldCheck;

@Repository
public class RefFieldCheckDaoImpl extends GenericJPADAO<RefFieldCheck,String> implements RefFieldCheckDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefFieldCheck> getAll() {
        Query query = em.createNamedQuery("refFieldCheck.findAll");
        return query.getResultList();
    }

    @Override
    public RefFieldCheck getById(Long id) {
        return super.getById(id);
    }
    
    @Override
    public void save(RefFieldCheck entity) {        
        super.save(entity);
    }

    @Override
    public void update(RefFieldCheck entity) {        
        super.merge(entity);
    }

    @Override
    public void delete(RefFieldCheck entity) {
        super.delete(entity);
    }

    @Override
    public RefFieldCheck getByName(String name) {
        Query query = em.createNamedQuery("refFieldCheck.findByName");
        query.setParameter("name", name);
        
        if (query.getResultList() == null) {
            return null;
        } else {
            return (RefFieldCheck) query.getResultList().get(0);
        }
    }

}
