package com.ips.dao.impl;

import java.util.Collection;

import javax.persistence.Query;
import org.springframework.stereotype.Repository;

import com.ips.dao.OtpMatchQualityDao;
import com.ips.entity.RefOtpMatchQuality;

@Repository
public class OtpMatchQualityDaoImpl extends GenericJPADAO<RefOtpMatchQuality,String> implements OtpMatchQualityDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefOtpMatchQuality> getAll() {
        Query query = em.createNamedQuery("RefOtpMatchQuality.findAll");
        return query.getResultList();
    }

    @Override
    public RefOtpMatchQuality getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void save(RefOtpMatchQuality entity) {
        super.save(entity);
    }

    @Override
    public void update(RefOtpMatchQuality entity) {
        super.merge(entity);
    }

    @Override
    public void delete(RefOtpMatchQuality entity) {
        super.delete(entity);
    }

    @Override
    public RefOtpMatchQuality getQualityByName(String name) {
        Query query = em.createNamedQuery("RefOtpMatchQuality.findByName");
        query.setParameter("name", name);
        
        if (query.getResultList() == null || query.getResultList().isEmpty()) {
            return null;
        } else {
            return (RefOtpMatchQuality) query.getResultList().get(0);
        }
    }

}
