package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpDitResponseDao;
import com.ips.entity.RpDitResponse;

@Repository
public class RpDitResponseDaoImpl extends GenericJPADAO<RpDitResponse, Long> implements RpDitResponseDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpDitResponse> getAll() {        
        Query query = em.createNamedQuery("RpDitResponse.getAll");
        return query.getResultList();
    }

    @Override
    public RpDitResponse getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpDitResponse entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpDitResponse entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpDitResponse entity) {
        super.persist(entity);        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpDitResponse> getListByPersonId(long personId) {
        Query query = em.createNamedQuery("RpDitResponse.getListByPersonId");
        query.setParameter("personId", personId);
        
        return query.getResultList();   
    }
    
    @Override
    public RpDitResponse getByPersonId(long personId) {
        List<RpDitResponse> results = getListByPersonId(personId);
        
        return results.isEmpty()? null : results.get(0);    
    }
}
