package com.ips.dao;

import java.util.List;

import com.ips.entity.IdVerifyServiceRequest;

public interface IdVerifyServiceRequestDao {
    void save(IdVerifyServiceRequest request);
    void update(IdVerifyServiceRequest request);
    void delete(IdVerifyServiceRequest request);
    List<IdVerifyServiceRequest> getServiceRequestsForEvent(long eventId);
    List<IdVerifyServiceRequest> findIdVerifyServiceRequestBySponsor(long sponsorId);
}
