package com.ips.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.SynchronizationType;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.PersonProofingStatusDao;
import com.ips.entity.PersonProofingStatus;

@Repository
public class PersonProofingStatusDaoImpl extends GenericJPADAO<PersonProofingStatus, String>
		implements PersonProofingStatusDao, Serializable {
	private static final long serialVersionUID = 1L;

//	@PersistenceContext
//	private EntityManager em;

	@SuppressWarnings("unchecked")
	@Override
	public PersonProofingStatus getByPersonId(int personId) {

		Query query = em.createNamedQuery("PersonProofingStatus.getByPersonId", PersonProofingStatus.class)
				.setParameter("personId", personId);
		List<PersonProofingStatus> results = query.getResultList();

		if (results.isEmpty()) {
			return null;
		} else {
			return results.get(0);
		}
	}

	@Override
	@Transactional
	public void update(PersonProofingStatus personProofingStatus) {
		super.merge(personProofingStatus);
	}

}
