package com.ips.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.IdPersonDetailsDao;
import com.ips.entity.IdPersonDetails;

@Repository
public class IdPersonDetailsDaoImpl extends GenericJPADAO<IdPersonDetails, Long> implements IdPersonDetailsDao{

    
    @Override
    public void save(IdPersonDetails request) {
        super.save(request);
    }
    
    @Override
    public void update(IdPersonDetails request) {
        super.merge(request);
        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public String getDetailData(long personDetailId) {
        
        Query query = em.createNativeQuery("select GET_DATA_FNC(?) from dual ");
        query.setParameter(1, personDetailId);
        List<String> data = query.getResultList();
        return data.isEmpty() ? "" : data.get(0);
    }
}
