package com.ips.dao;

import java.util.List;

import com.ips.entity.RefIppApplications;

public interface RefIppApplicationsDao {

    List<RefIppApplications> getApplicationList();

    RefIppApplications getAppByAcr(String acr);

    RefIppApplications getAppById(long appId);

}
