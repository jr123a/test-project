package com.ips.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RefIppApplicationsDao;
import com.ips.entity.RefIppApplications;

@Repository
public class RefIppApplicationsDaoImpl extends GenericJPADAO<RefIppApplications, Long>
        implements RefIppApplicationsDao {

    @SuppressWarnings("unchecked")
    @Override
    public List<RefIppApplications> getApplicationList() {
        List<RefIppApplications> list = null;
        try {
            Query query = em.createNamedQuery("RefIppApplications.findAll");

            list = query.getResultList();
            if (list == null) {
                list = new ArrayList<>();
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception getting RefIppApplications data", e);
        }

        return list;

    }

    @Override
    public RefIppApplications getAppByAcr(String appAcronym) {
        try {
            Query query = em.createNamedQuery("RefIppApplications.findByApplicationAcronym").setParameter("appAcronym",
                    appAcronym);
            RefIppApplications app = null;
            @SuppressWarnings("unchecked")
            List<RefIppApplications> list = query.getResultList();
            Optional<RefIppApplications> result = list.stream().findFirst();

            if (result.isPresent()) {
                app = result.get();
            }

            return app;
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception getting getAppByAcr data", e);
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RefIppApplications getAppById(long appId) {
            Query query = em.createNamedQuery("RefIppApplications.findByApplicationId").setParameter("appId", appId);
            List<RefIppApplications> results = query.getResultList();
            return results.isEmpty() ? null : results.get(0);
    }
}
