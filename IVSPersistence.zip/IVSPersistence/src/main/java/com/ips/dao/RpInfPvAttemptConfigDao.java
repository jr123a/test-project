package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpInfPvAttemptConfig;
import com.ips.entity.RpInfPvAttemptConfigPK;

public interface RpInfPvAttemptConfigDao {
    Collection<RpInfPvAttemptConfig> getAll();    
    RpInfPvAttemptConfig getById(RpInfPvAttemptConfigPK id);
    RpInfPvAttemptConfig findByPrimaryKey(long proofingLevel, long sponsorId, long otpSupplierId);
    void save(RpInfPvAttemptConfig otpAttemptConfig);
    void update(RpInfPvAttemptConfig otpAttemptConfig);
    void delete(RpInfPvAttemptConfig otpAttemptConfig);
    Collection<RpInfPvAttemptConfig> getByProofingLevel(long proofingLevel, long sponsorId);
    Collection<RpInfPvAttemptConfig> getByProofingLevelSorted(List<Long> otpSupplierIds, long proofingLevel, long sponsorId);
    List<RpInfPvAttemptConfig> findRowsForReset();
}
