package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefAdminGroup;


public interface RefAdminGroupDao {
    Collection<RefAdminGroup> getAll();    
    RefAdminGroup getById(Long id);
    void save(RefAdminGroup group);
    void update(RefAdminGroup group);
    void delete(RefAdminGroup group);
    RefAdminGroup findByGroupName(String name);
}
