package com.ips.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpTruthDataSendEmailDao;
import com.ips.entity.RpTruthDataSendEmail;
import com.ips.persistence.common.FraudEmailVo;

@Repository
public class RpTruthDataSendEmailDaoImpl extends GenericJPADAO<RpTruthDataSendEmail, Long> implements RpTruthDataSendEmailDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpTruthDataSendEmail> getAll() {        
        Query query = em.createNamedQuery("RpTruthDataSendEmail.getAll");
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpTruthDataSendEmail> getPendingBlacklist() {        
        Query query = em.createNamedQuery("RpTruthDataSendEmail.getPendingBlacklist");
         return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection<FraudEmailVo> getPendingTIUFraudlist() {

            ArrayList<FraudEmailVo> list = new ArrayList<>();
        try {        
             String sql = getPendingTIUFraudlistQuery();
             Query q = em.createNativeQuery(sql);
             List<Object[]> resultList = q.getResultList();

             for (Object[] item : resultList) {
                 Long emailRecordId = Long.parseLong((String.valueOf((BigDecimal) item[0])));
                 Long personId = Long.parseLong((String.valueOf((BigDecimal) item[1])));
                 String requestId = (String) item[2];
                 String emailAddress = (String) item[3];
                 
                 FraudEmailVo vo = new FraudEmailVo(emailRecordId, personId, requestId, emailAddress);
                 list.add(vo);
             }
        } catch (Exception ex) {
            CustomLogger.error(this.getClass(), "Error in getting getPendingTIUFraudlist vo item list.",ex);
        } 
        
        return list;
    }
        
    @Override
    public RpTruthDataSendEmail getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpTruthDataSendEmail entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpTruthDataSendEmail entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpTruthDataSendEmail entity) {
        super.persist(entity);        
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection<FraudEmailVo> getPendingTIUFraudlist(Long truthDataSendEmailId) {

            ArrayList<FraudEmailVo> list = new ArrayList<>();
        try {        
             String sql = getPendingTIUFraudlistQueryByID();
             Query q = em.createNativeQuery(sql);
             q.setParameter(1, truthDataSendEmailId.longValue());
             List<Object[]> resultList = q.getResultList();

             for (Object[] item : resultList) {
                 Long emailRecordId = Long.parseLong((String.valueOf((BigDecimal) item[0])));
                 Long personId = Long.parseLong((String.valueOf((BigDecimal) item[1])));
                 String requestId = (String) item[2];
                 String emailAddress = (String) item[3];
                 
                 FraudEmailVo vo = new FraudEmailVo(emailRecordId, personId, requestId, emailAddress);
                 list.add(vo);
             }
        } catch (Exception ex) {
            CustomLogger.error(this.getClass(), "Error in getting getPendingTIUFraudlist vo item list.",ex);
        } 
        
        return list;
    }
    
    private String getPendingTIUFraudlistQuery() {
        StringBuilder sqlSb = new StringBuilder();
    
        sqlSb.append("SELECT se.truth_data_send_email_id, dr.person_id, dr.request_id, se.email_address "); 
        sqlSb.append("FROM ips_own.rp_truth_data_send_email se, ips_own.rp_device_reputation dr, ips_own.person_data pd "); 
        sqlSb.append("WHERE se.email_address = pd.email_address AND dr.person_id = pd.person_id AND dr.request_id is not null AND length(dr.request_id) > 12 ");
        sqlSb.append("AND sent_final_review_status IS NULL");

        return sqlSb.toString();
    }
    
    private String getPendingTIUFraudlistQueryByID() {
        StringBuilder sqlSb = new StringBuilder();
    
        sqlSb.append("SELECT se.truth_data_send_email_id, dr.person_id, dr.request_id, se.email_address "); 
        sqlSb.append("FROM ips_own.rp_truth_data_send_email se, ips_own.rp_device_reputation dr, ips_own.person_data pd "); 
        sqlSb.append("WHERE se.email_address = pd.email_address AND dr.person_id = pd.person_id AND dr.request_id is not null AND length(dr.request_id) > 12 ");
        sqlSb.append("AND sent_final_review_status IS NULL and se.truth_data_send_email_id =?1");

        return sqlSb.toString();
    }
}
