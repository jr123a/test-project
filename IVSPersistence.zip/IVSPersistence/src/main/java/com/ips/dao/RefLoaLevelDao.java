package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefLoaLevel;


public interface RefLoaLevelDao {

    Collection<RefLoaLevel> getAll();    
    RefLoaLevel getById(Long id);
    void save(RefLoaLevel status);
    void update(RefLoaLevel status);
    void delete(RefLoaLevel status);
    RefLoaLevel findByLevel(String level);
    RefLoaLevel findByCode(long code);
}
