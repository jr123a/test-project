package com.ips.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefOtpSupplierDao;
import com.ips.entity.RefOtpSupplier;

@Repository
public class RefOtpSupplierDaoImpl extends GenericJPADAO<RefOtpSupplier, Long> implements
    RefOtpSupplierDao {

    @SuppressWarnings("unchecked")
	@Override
    public RefOtpSupplier findBySupplierId(long id) {
        Query query = em.createNamedQuery("RefOtpSupplier.findBySupplierId");
        query.setParameter("supplierId", id);
  		List<RefOtpSupplier> results = query.getResultList();
        
 		return results.isEmpty() ? null : results.get(0);
     }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RefOtpSupplier> getActiveSupplierList() {        
        Query query = em.createNamedQuery("RefOtpSupplier.getActiveSupplierList");
        return query.getResultList();
    }

}
