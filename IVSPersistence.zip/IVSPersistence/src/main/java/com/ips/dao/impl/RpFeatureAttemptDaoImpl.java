package com.ips.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RpFeatureAttemptDao;
import com.ips.entity.RpFeatureAttempt;

@Repository
public class RpFeatureAttemptDaoImpl extends GenericJPADAO<RpFeatureAttempt, Long> implements RpFeatureAttemptDao {

    @Override
    public RpFeatureAttempt getById(long id) {
        return super.getById(id);
    }

    @Override
    public void create(RpFeatureAttempt featureAttempt) {
        super.save(featureAttempt);
    }
    
    @Override
    public void update(RpFeatureAttempt featureAttempt) {
        super.merge(featureAttempt);
    }
    
    @Override
    public void delete(RpFeatureAttempt featureAttempt) {
        super.delete(featureAttempt);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RpFeatureAttempt> getListBySponsorId(long sponsorId) {
        Query query = em.createNamedQuery("RpFeatureAttempt.findBySponsorId");
        query.setParameter("sponsorId", sponsorId);

        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpFeatureAttempt> getListByAppId(long appId) {
        Query query = em.createNamedQuery("RpFeatureAttempt.findByAppId");
        query.setParameter("appId", appId);

        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpFeatureAttempt> getBySponsorAndAppId(long sponsorId, long appId) {
        Query query = em.createNamedQuery("RpFeatureAttempt.findBySponsorAndAppId");
        query.setParameter("sponsorId", sponsorId);
        query.setParameter("appId", appId);

        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpFeatureAttempt findBySponsorIdAndFeatureName(long sponsorId, String featureName) {
        Query query = em.createNamedQuery("RpFeatureAttempt.findBySponsorIdAndFeatureName");
        query.setParameter("sponsorId", sponsorId);
        query.setParameter("featureName", featureName);
        
        List<RpFeatureAttempt> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpFeatureAttempt findByAppIdAndFeatureName(long appId, String featureName) {
        Query query = em.createNamedQuery("RpFeatureAttempt.findByAppIdAndFeatureName");
        query.setParameter("appId", appId);
        query.setParameter("featureName", featureName);
        
        List<RpFeatureAttempt> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } else {
            return results.get(0);
        }
    }

    @Override
    public long getMaxConfigId() {
        return (long) em.createNamedQuery("RpFeatureAttempt.getMaxConfigId").getSingleResult();
    }
}

