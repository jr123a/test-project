package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefOtpAttemptType;

public interface PasscodeAttemptTypeDao {
    Collection<RefOtpAttemptType> getAll();    
    RefOtpAttemptType findAttemptTypeByName(String typeName);
    void save(RefOtpAttemptType rpLexisNexisResult);
    void update(RefOtpAttemptType rpLexisNexisResult);
    void delete(RefOtpAttemptType rpLexisNexisResult);
}
