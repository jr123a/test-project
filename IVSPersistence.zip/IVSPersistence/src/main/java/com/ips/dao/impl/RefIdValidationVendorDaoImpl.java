package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefIdValidationVendorDao;
import com.ips.entity.RefIdValidationVendor;

@Repository
@SuppressWarnings("unchecked")
public class RefIdValidationVendorDaoImpl extends GenericJPADAO<RefIdValidationVendor, Long> implements
    RefIdValidationVendorDao,Serializable  {

    private static final long serialVersionUID = 1L;

    @Override
    public Collection<RefIdValidationVendor> getAll() {        
        Query query = em.createNamedQuery("RefIdValidationVendor.findAll");
        return query.getResultList();
    }

    @Override
    public RefIdValidationVendor getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void update(RefIdValidationVendor sponsor) {
        // TODO Auto-generated method stub
        
    }
    
}
