package com.ips.dao;

import java.util.List;

import com.ips.entity.IppEventIDValidation;

public interface IppEventIDValidationDao {

    long getPrimaryIdUsedCountByIdValidation(long idType);
    public void save(IppEventIDValidation validation);
    public void update(IppEventIDValidation validation);
    List<IppEventIDValidation> getValidationsForEvent(long eventId);
	List<IppEventIDValidation> getValidationsForEventAndIdType(long eventId, long strongIdType);
}
