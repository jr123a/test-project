package com.ips.dao.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RpLexisNexisFinalReasonCodeDao;
import com.ips.entity.RefOtpReasonCode;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefSponsor;
import com.ips.entity.RpLexisNexisFinalReasonCode;

@Repository
public class RpLexisNexisFinalReasonCodeDaoImpl extends GenericJPADAO<RpLexisNexisFinalReasonCode, Long>
        implements RpLexisNexisFinalReasonCodeDao {

    @Override
    public RpLexisNexisFinalReasonCode getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void save(RpLexisNexisFinalReasonCode reasonCode) {
        super.save(reasonCode);
        
    }

    @Override
    public void update(RpLexisNexisFinalReasonCode reasonCode) {
        super.merge(reasonCode);
        
    }

    @Override
    public void delete(RpLexisNexisFinalReasonCode reasonCode) {
        super.delete(reasonCode);
        
    }

    @SuppressWarnings("unchecked")
    @Override
    /**
     * Retrieves the Equifax negative reason codes in the timeframe.
     * @param start
     * @param end
     * @return
     */
    public List<RefOtpReasonCode> getLexisNegativeReasons(Date start, Date end, RefLoaLevel loa) {
    
        Query query = em.createNativeQuery(
                "SELECT k.reason_code, k.assert_flag, k.create_date, k.kba_supplier_id, " +
                "k.reason_code_description, k.update_date " +
                "FROM rp_event e, rp_lexisnexis_finalreason_code r, ref_kba_reason_code k, person p " +
                "WHERE e.event_id = r.event_id " +
                "AND r.reason_code = k.reason_code " +
                "AND e.person_id = p.person_id " +
                "AND e.proofing_level_sought = ? " +
                "AND k.negative_reason = 'Y' " +
                "AND e.initiation_datetime >= ? " +
                "AND e.initiation_datetime <= ? " +
                "AND p.sponsor_id = ?", RefOtpReasonCode.class);
        
        query.setParameter(1, loa.getLoaCode());
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefSponsor.SPONSOR_ID_CUSTREG);
        
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getReasonCodeCount(Date start, Date end, String reasonCode, RefLoaLevel loa) {
        Query query = em.createNativeQuery(
                "SELECT count(distinct e.event_id) " +
                "FROM rp_event e, rp_lexisnexis_finalreason_code r, person p " +
                "WHERE e.event_id = r.event_id " +
                "AND e.person_id = p.person_id " +
                "AND r.reason_code = ? " +
                "AND e.proofing_level_sought = ? " +
                "AND e.initiation_datetime >= ? " +
                "AND e.initiation_datetime <= ? " +
                "AND p.sponsor_id = ?");
        
        query.setParameter(1, reasonCode);
        query.setParameter(2, loa.getLoaCode());
        query.setParameter(3, start);
        query.setParameter(4, end);
        query.setParameter(5, RefSponsor.SPONSOR_ID_CUSTREG);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    public List<RpLexisNexisFinalReasonCode> getReasonCodesByEvent(long eventId) {
        Query query = em.createNamedQuery("RpLexisNexisFinalReasonCode.getReasonCodeByEventId");
        query.setParameter("eventId", eventId);
        
        return query.getResultList();
    }
}
