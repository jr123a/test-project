package com.ips.dao.impl;

import com.ips.dao.RefWorkflowApiTypeDao;
import com.ips.entity.RefWorkflowApiType;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.io.Serializable;
import java.util.Collection;

@Repository
public class RefWorkflowApiTypeDaoImpl extends GenericJPADAO<RefWorkflowApiType, Long> 
        implements RefWorkflowApiTypeDao, Serializable {
    
    private static final long serialVersionUID = 1L;
    @Override
    public Collection<RefWorkflowApiType> getAll() {
        Query query = em.createNamedQuery("RefWorkflowApiType.findAll");
        return query.getResultList();
    }

    @Override
    public RefWorkflowApiType getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void save(RefWorkflowApiType workflowApiType) {
        super.persist(workflowApiType);
    }

    @Override
    public void update(RefWorkflowApiType workflowApiType) {
        super.merge(workflowApiType);
    }

    @Override
    public void delete(RefWorkflowApiType workflowApiType) {
        super.delete(workflowApiType);
    }
}
