package com.ips.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.IdDocumentDetailsDao;
import com.ips.entity.IdDocumentDetails;

@Repository
public class IdDocumentDetailsDaoImpl extends GenericJPADAO<IdDocumentDetails, Long> implements IdDocumentDetailsDao{

    
    @Override
    public void save(IdDocumentDetails request) {
        super.save(request);
    }
    
    @Override
    public void update(IdDocumentDetails request) {
        super.merge(request);
        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<IdDocumentDetails> getDocumentDetailsForEvent(long eventId) {
        List<IdDocumentDetails> details = new ArrayList<IdDocumentDetails>();
        Query query = em.createNamedQuery("IdDocumentDetails.getByEvent");
        query.setParameter("eventId", eventId);
        List<IdDocumentDetails> results = query.getResultList();
        // Create a mutable list so it can be sorted
        details.addAll(results);
        return details;
    }
}
