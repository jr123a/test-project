package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpTruthDataSendResponse;

public interface RpTruthDataSendResponseDao {

    Collection<RpTruthDataSendResponse> getAll();    
    RpTruthDataSendResponse getById(Long id);
    RpTruthDataSendResponse getByRequestId(String id);
    void create(RpTruthDataSendResponse entity);
    void update(RpTruthDataSendResponse entity);
    List<RpTruthDataSendResponse> getListByPersonId(long personId);
    RpTruthDataSendResponse getByPersonId(long personId);
    RpTruthDataSendResponse getByEventId(long eventId);
}
