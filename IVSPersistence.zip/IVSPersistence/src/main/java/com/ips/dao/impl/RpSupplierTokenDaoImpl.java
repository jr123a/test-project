package com.ips.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RpSupplierTokenDao;
import com.ips.entity.RpSupplierToken;


@Repository
public class RpSupplierTokenDaoImpl extends GenericJPADAO<RpSupplierToken, Long> implements
	RpSupplierTokenDao,Serializable  {
    
    private static final long serialVersionUID = 1L;
    
    @Override
    public void save(RpSupplierToken token) {
        super.save(token);
    }

    @Override
    public void update(RpSupplierToken token) {
        super.merge(token);
    }
    
    @Override
    public void delete(RpSupplierToken token) {
        super.delete(token);
    }

    @SuppressWarnings("unchecked")
    @Override
    public RpSupplierToken getByCode(String code) {
     	
        Query query = em.createNamedQuery("RpSupplierToken.findByCode");
        query.setParameter("code", code);
        List<RpSupplierToken> results = query.getResultList();
 
        if (results.isEmpty()) {
             return null;
        } 
        else {
            return results.get(0);
        }        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpSupplierToken getByType(String type) {
     	
        Query query = em.createNamedQuery("RpSupplierToken.findByType");
        query.setParameter("type", type);
        List<RpSupplierToken> results = query.getResultList();
 
        if (results.isEmpty()) {
             return null;
        } 
        else {
            return results.get(0);
        }        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpSupplierToken getByCodeAndType(String code, String type) {
     	
        Query query = em.createNamedQuery("RpSupplierToken.findByCodeAndType");
        query.setParameter("code", code);
        query.setParameter("type", type);
        List<RpSupplierToken> results = query.getResultList();
 
        if (results.isEmpty()) {
             return null;
        } 
        else {
            return results.get(0);
        }        
    }

}

