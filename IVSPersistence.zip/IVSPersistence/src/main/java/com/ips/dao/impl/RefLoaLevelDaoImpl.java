package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefLoaLevelDao;
import com.ips.entity.RefLoaLevel;

@Repository
public class RefLoaLevelDaoImpl extends GenericJPADAO<RefLoaLevel, Long> implements
        RefLoaLevelDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;


    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefLoaLevel> getAll() {
//        em = getEntityManager();
        Query query = em.createNamedQuery("RefLoaLevel.findAll");
        return query.getResultList();
    }

    @Override
    public RefLoaLevel getById(Long id) {
        return super.getById(id);
    }
    
    @Override
    public void update(RefLoaLevel level) {
        super.merge(level);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RefLoaLevel findByLevel(String level) {
        Query query = em.createNamedQuery("RefLoaLevel.findByLevel");
        query.setParameter("level", level);
        List<RefLoaLevel> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RefLoaLevel findByCode(long code) {
        Query query = em.createNamedQuery("RefLoaLevel.findByCode");
        query.setParameter("code", code);
        List<RefLoaLevel> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
        
    }

}
