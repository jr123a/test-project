package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpTruthDataSendResponseDao;
import com.ips.entity.RpTruthDataSendResponse;

@Repository
public class RpTruthDataSendResponseDaoImpl extends GenericJPADAO<RpTruthDataSendResponse, Long> implements RpTruthDataSendResponseDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpTruthDataSendResponse> getAll() {        
        Query query = em.createNamedQuery("RpTruthDataSendResponse.getAll");
        return query.getResultList();
    }

    @Override
    public RpTruthDataSendResponse getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpTruthDataSendResponse entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpTruthDataSendResponse entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpTruthDataSendResponse entity) {
        super.persist(entity);        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpTruthDataSendResponse getByRequestId(String id) {
        Query query = em.createNamedQuery("RpTruthDataSendResponse.getByRequestId");
        query.setParameter("requestId", id);
        List<RpTruthDataSendResponse> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);    
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RpTruthDataSendResponse> getListByPersonId(long personId) {
        Query query = em.createNamedQuery("RpTruthDataSendResponse.getListByPersonId");
        query.setParameter("personId", personId);
        
        return query.getResultList();  
    }
    
    @Override
    public RpTruthDataSendResponse getByPersonId(long personId) {
        List<RpTruthDataSendResponse> results = getListByPersonId(personId);
        
        return results.isEmpty()? null : results.get(0);    
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpTruthDataSendResponse getByEventId(long eventId) {
        Query query = em.createNamedQuery("RpTruthDataSendResponse.getByEventId");
        query.setParameter("eventId", eventId);
        List<RpTruthDataSendResponse> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);    
    }
}
