package com.ips.dao.impl;

import java.util.List;

import javax.persistence.PersistenceException;

import org.springframework.stereotype.Repository;

import com.ips.common.common.CustomLogger;
import com.ips.dao.SponsorApplicationMapDao;
import com.ips.entity.SponsorApplicationMap;

@Repository
public class SponsorApplicationMapDaoImpl extends GenericJPADAO<SponsorApplicationMap, Long> implements SponsorApplicationMapDao {
    @SuppressWarnings("unchecked")
    @Override
    public List<SponsorApplicationMap> getRelationsBySponsor(long sponsorId) {
        List<SponsorApplicationMap> samList = em.createNamedQuery("SponsorApplicationMap.getRelationsBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return samList == null || samList.isEmpty() ? null : samList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<SponsorApplicationMap> getRelationsByApplication(long appId) {
        List<SponsorApplicationMap> samList = em.createNamedQuery("SponsorApplicationMap.getRelationsByApplication").setParameter("appId", appId).getResultList();
        return samList == null || samList.isEmpty() ? null : samList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public SponsorApplicationMap getRelationBySponsorAndApplication(long sponsorId, long appId) {
        List<SponsorApplicationMap> samList = em.createNamedQuery("SponsorApplicationMap.getRelationBySponsorAndApplication").setParameter("sponsorId", sponsorId).setParameter("appId", appId).getResultList();
        return samList == null || samList.isEmpty() ? null : samList.get(0);
    }

    @Override
    public void create(SponsorApplicationMap entity) {
        super.save(entity);
    }

    @Override
    public void update(SponsorApplicationMap entity) {
        try {
            super.merge(entity);
            em.flush();
         } catch (PersistenceException pe) {
             CustomLogger.error(this.getClass(), "Error in merging SponsorApplicationMap entity.  ", pe);
        }
    }

    @Override
    public void delete(SponsorApplicationMap entity) {
        super.delete(entity);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<SponsorApplicationMap> getAllRelations() {
        List<SponsorApplicationMap> samList = em.createNamedQuery("SponsorApplicationMap.getAllRelations").getResultList();
        return samList == null || samList.isEmpty() ? null : samList;
    }
}
