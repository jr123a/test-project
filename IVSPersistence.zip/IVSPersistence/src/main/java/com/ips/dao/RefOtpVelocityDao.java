package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefOtpVelocity;


public interface RefOtpVelocityDao {

    Collection<RefOtpVelocity> getAll();    
    RefOtpVelocity getById(Long id);
    void save(RefOtpVelocity refOtpVelocity);
    void update(RefOtpVelocity refOtpVelocity);
    void delete(RefOtpVelocity refOtpVelocity);
    List<RefOtpVelocity> findAllByOtpSupplier(RefOtpSupplier supplier);
    RefOtpVelocity findByVelocityType(RefOtpSupplier supplier, String velocityType);
    RefOtpVelocity findByIdAndVelocityType(long supplierId, String velocityType);
}
