package com.ips.dao;

import java.util.List;

import com.ips.entity.SponsorWebServiceQueue;

public interface SponsorWebServiceQueueDao {
    SponsorWebServiceQueue getQueue(String enrollmentCode);
    void save(SponsorWebServiceQueue queue);
    void update(SponsorWebServiceQueue queue);
    void delete(SponsorWebServiceQueue queue);
    List<SponsorWebServiceQueue> findSponsorWebServiceQueueBySponsor(long sponsorId);

}
