package com.ips.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.IdImagesDao;
import com.ips.entity.IdImages;

@Repository
public class IdImagesDaoImpl extends GenericJPADAO<IdImages, Long> implements IdImagesDao {

	@Override
	public void save(IdImages request) {
		super.save(request);

	}

	@Override
	public void update(IdImages request) {
		super.merge(request);

	}
	
	 @SuppressWarnings("unchecked")
	 @Override
	 public IdImages findIdImagesByippEventIdandIdType(Long ippEventId,Long idType, Long idNumber) {
		
	        Query query = em.createNamedQuery("IdImages.findIdImagesByippEventIdandIdType");
	        query.setParameter("ippEventId", ippEventId);
	        query.setParameter("idType", idType);
	        query.setParameter("idNumber", idNumber);
	        List<IdImages> results = query.getResultList();
	        
	        if (results.isEmpty()) {
	            return null;
	        } 
	        else {
	            return results.get(0);
	        }
	        
	    }
	@SuppressWarnings("unchecked")
	@Override
	public IdImages findIdImagesByippEventIdandIdNumber(Long ippEventId, Long idNumber) {
		Query query = em.createNamedQuery("IdImages.findIdImagesByippEventIdandIdNumber");
        query.setParameter("ippEventId", ippEventId);
        query.setParameter("idNumber", idNumber);
        List<IdImages> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
	}

}
