package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.PersonDataDao;
import com.ips.entity.PersonData;

@Repository
public class PersonDataDaoImpl extends GenericJPADAO<PersonData, Long> implements PersonDataDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<PersonData> getAll() {        
        Query query = em.createNamedQuery("PersonData.findAll");
        return query.getResultList();
    }

    @Override
    public PersonData getById(Long id) {        
        return super.getById(id);
    }

    @Override
    public void update(PersonData personData) {
        super.merge(personData);
        
    }
    
    @Override
    public PersonData findBySponsorUserId(String sponsorUserId) {
        Query query = em.createNamedQuery("PersonData.findBySponsorUserId");
        query.setParameter("sponsorUserId", sponsorUserId);
        
        @SuppressWarnings("unchecked")
        List<PersonData> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0); 
    }
}
