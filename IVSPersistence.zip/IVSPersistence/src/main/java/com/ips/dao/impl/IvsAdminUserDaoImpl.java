package com.ips.dao.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.ips.dao.IvsAdminUserDao;
import com.ips.entity.IvsAdminUser;

@Repository
@SuppressWarnings("unchecked")
public class IvsAdminUserDaoImpl extends GenericJPADAO<IvsAdminUser, Long> implements IvsAdminUserDao {

    @Override
    public Collection<IvsAdminUser> getAll() {
        Query query = em.createNamedQuery("IvsAdminUser.findAll");
        return query.getResultList();
    }

    @Override
    public IvsAdminUser getByUserId(String userId) {
        if (StringUtils.isAlphanumeric(userId)) {
            Query query = em.createNamedQuery("IvsAdminUser.findByUserId").setParameter("userId", userId);
            
            List<IvsAdminUser> results = query.getResultList();    
            if (results.isEmpty()) {
                return null;
            } 
            else {
                return results.get(0);
            }
        }
        else {
            return null;
        }
    }

    @Override
    public void update(IvsAdminUser user) {
        super.merge(user);
    }
    
    @Override
    public Collection<IvsAdminUser> getOtherAdmins(String userId) {
        if (StringUtils.isAlphanumeric(userId)) {
            Query query = em.createNamedQuery("IvsAdminUser.findOtherAdmins");
            query.setParameter("userId", userId);
            return query.getResultList();
        }
        return Collections.emptyList();
    }
}
