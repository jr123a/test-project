package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpDitResponse;

public interface RpDitResponseDao {

    Collection<RpDitResponse> getAll();    
    RpDitResponse getById(Long id);
    void create(RpDitResponse entity);
    void update(RpDitResponse entity);
    List<RpDitResponse> getListByPersonId(long personId);
    RpDitResponse getByPersonId(long personId);
}
