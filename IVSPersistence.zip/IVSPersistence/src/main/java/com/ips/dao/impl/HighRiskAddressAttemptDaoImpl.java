package com.ips.dao.impl;

import org.springframework.stereotype.Repository;

import com.ips.dao.HighRiskAddressAttemptDao;
import com.ips.entity.HighRiskAddressAttempt;

@Repository
public class HighRiskAddressAttemptDaoImpl extends GenericJPADAO<HighRiskAddressAttempt, Long> implements HighRiskAddressAttemptDao {    

    @Override
    public void update(HighRiskAddressAttempt highRiskAddressAttempt) {
        super.merge(highRiskAddressAttempt);        
    }
    
    @Override
    public HighRiskAddressAttempt getById(Long id) {
        return super.getById(id);
    }
}
