package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RpProofingSessionDao;
import com.ips.entity.Person;
import com.ips.entity.RpProofingSession;

@Repository
public class RpProofingSessionDaoImpl extends
        GenericJPADAO<RpProofingSession, Long> implements RpProofingSessionDao,
        Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings({ "unchecked" })
    @Override
    public Collection<RpProofingSession> getAll() {
        Query query = em.createNamedQuery("RpProofingSession.findAll");
        return query.getResultList();
    }

    @Override
    public RpProofingSession getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void update(RpProofingSession proofingSession) {
        super.merge(proofingSession);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RpProofingSession> findRpSessionByPerson(Person person) {
        Query query = em.createNamedQuery("RpProofingSession.findRpSessionByPerson").setParameter("person", person);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Long> findSumOfTotalAttempts(Person person) {
        Query query = em.createNamedQuery("RpProofingSession.findSumOfTotalAttempts").setParameter("person", person);
        return query.getResultList();
    }

}
