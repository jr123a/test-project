package com.ips.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefEmailTypeDao;
import com.ips.entity.RefEmailType;

@Repository
public class RefEmailTypeDaoImpl extends GenericJPADAO<RefEmailType, Long> implements RefEmailTypeDao {
    @SuppressWarnings("unchecked")
    @Override
    public List<RefEmailType> getAllTypes() {
        return em.createNamedQuery("RefEmailType.findAll").getResultList();
    }
    
    @Override
    public RefEmailType getByPK(Long id) {
        return (RefEmailType) em.createNamedQuery("RefEmailType.findByPK").setParameter("id", id).getSingleResult();
    }
}
