package com.ips.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.SponsorWebServiceRequestDao;
import com.ips.entity.SponsorWebServiceRequests;

@Repository
public class SponsorWebServiceRequestDaoImpl extends GenericJPADAO<SponsorWebServiceRequests, Long> implements SponsorWebServiceRequestDao{

    
    @Override
    public void save(SponsorWebServiceRequests request) {
        super.save(request);
    }
    
    @Override
    public void update(SponsorWebServiceRequests request) {
        super.merge(request);
        
    }
    
    @Override
    public void delete(SponsorWebServiceRequests request) {
        super.delete(request);
    }

    /**
     * Retrieves the transaction_success for an enrollment code.  There can be multiple rows in the table for an enrollment
     * code but there should only be one row where transaction_success is Y.
     * 
     * @param enrollmentCode
     * @return Y if the record with Y is found, empty string otherwise
     */
    public String getSuccessForEnrollmentCode(String enrollmentCode) {
        Query query = em.createNamedQuery("SponsorWebServiceRequests.getSuccessForEnrollmentCode");
        query.setParameter("enrollmentCode", enrollmentCode);
        
        @SuppressWarnings("unchecked")
        List<String> results = query.getResultList();
        
        if (results.isEmpty()) {
            return "";
        } 
        else {
            return results.get(0);
        }
    }

    @SuppressWarnings("unchecked")
	@Override
    public SponsorWebServiceRequests findRequestByEnrollmentCode(String enrollmentCode) {
        Query query = em.createNamedQuery("SponsorWebServiceRequests.findRequestByEnrollmentCode");
        query.setParameter("enrollmentCode", enrollmentCode);
        List<SponsorWebServiceRequests> results = query.getResultList();

        if (results.isEmpty()) {
            return null;
        } else {
            return results.get(0);
        }
    }
    
    @Override
    public List<SponsorWebServiceRequests> findSponsorWebServiceRequestsBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<SponsorWebServiceRequests> list = em.createNamedQuery("SponsorWebServiceRequests.findSponsorWebServiceRequestsBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
}
