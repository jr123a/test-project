package com.ips.dao;

import com.ips.entity.RefWorkflowApiType;

import java.util.Collection;

public interface RefWorkflowApiTypeDao {
    Collection<RefWorkflowApiType> getAll();
    
    RefWorkflowApiType getById(Long id);
    void save(RefWorkflowApiType customerCategory);
    void update(RefWorkflowApiType customerCategory);
    void delete(RefWorkflowApiType customerCategory);
    
}
