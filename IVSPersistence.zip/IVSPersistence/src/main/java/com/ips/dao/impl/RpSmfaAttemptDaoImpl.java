package com.ips.dao.impl;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpSmfaAttemptDao;
import com.ips.entity.RpEvent;
import com.ips.entity.RpSmfaAttempt;

@Transactional
@Repository
public class RpSmfaAttemptDaoImpl extends GenericJPADAO<RpEvent, Long> implements Serializable, RpSmfaAttemptDao{    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public List<RpSmfaAttempt> getSmfaAttemptsListInWindow(long personId, Timestamp window, 
    		Timestamp currentTime, long smfaSupplierId, long rpEventId) {
        List<RpSmfaAttempt> results = null;

        try {
            Query query = em.createNamedQuery("RpSmfaAttempt.getSmfaAttemptsListInWindow")
                    .setParameter("personId", personId)
                    .setParameter("smfaSupplierId", smfaSupplierId)
                    .setParameter("rpEventId", rpEventId)
                    .setParameter("window", window)
                    .setParameter("currentTime", currentTime);
 
            results = query.getResultList();
        } catch (NoResultException ne) {
            CustomLogger.error(this.getClass(), "Exception occured when querying", ne);
            results = Collections.emptyList();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format("Exception occurred while retrieving the RpSmfaAttempt list for personId: %s and otpSupplierId: %s ", personId, smfaSupplierId), e);
        }

        return results; 
    }
    
	@SuppressWarnings("unchecked")
	@Override
    public List<RpSmfaAttempt> getSmfaAttemptsListInWindow(long personId, long supplierId, int attemptWindow, long rpEventId) {
    	StringBuilder sqlSb =  new StringBuilder();	 
			sqlSb.append("SELECT a.* FROM rp_smfa_attempts a, rp_event e ");
			sqlSb.append(String.format("WHERE e.event_id = a.event_id AND e.person_id = %s ", personId));
			sqlSb.append(String.format("AND e.kba_supplier_id = %s ", supplierId));
			sqlSb.append(String.format("AND e.event_id = %s ", rpEventId));
			sqlSb.append(String.format("AND e.create_date >= (CURRENT_TIMESTAMP - (%s/24)) ", attemptWindow));
			sqlSb.append("AND e.create_date <= CURRENT_TIMESTAMP ");
			sqlSb.append("ORDER BY a.create_date ");
		
		List<RpSmfaAttempt> results = null;
    	Query query = em.createNativeQuery(sqlSb.toString());   
    	results = query.getResultList();
    	
    	return results; 
    }
	
    @SuppressWarnings("unchecked")
    @Override
    public List<RpSmfaAttempt> getSmfaAttemptsInTransaction(long personId, long smfaSupplierId, String transactionKey) {
        List<RpSmfaAttempt> results = null;
        try {
            Query query = em.createNamedQuery("RpSmfaAttempt.getOtpAttemptInTransaction")
                    .setParameter("personId", personId)
                    .setParameter("otpSupplierId", smfaSupplierId)
                    .setParameter("transactionKey", transactionKey);
            
            results = query.getResultList();
        } catch (NoResultException ne) {
            results = Collections.emptyList();
            CustomLogger.error(this.getClass(), "Exception occured when querying", ne);
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format("Exception occurred while retrieving the RpSmfaAttempt list for personId: %s and otpSupplierId: %s ", personId, smfaSupplierId), e);
        }
        
        return results; 
    }
    
    @Override
    public RpSmfaAttempt getSmfaAttemptBySessionId(String sessionId) {
 
        RpSmfaAttempt entity = null;
        
    	try {
            Query query = em.createNamedQuery("RpSmfaAttempt.getSmfaAttemptsBySessionId")
                    .setParameter("sessionId", sessionId);
            
             @SuppressWarnings("unchecked")
            List<RpSmfaAttempt> list = query.getResultList();    
            Optional<RpSmfaAttempt> result = list.stream().findFirst();
            
            if (result.isPresent()) {
            	entity= result.get();
            }
        } catch (NoResultException ne) {
             CustomLogger.error(this.getClass(), "Exception occured when querying", ne);
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format("Exception occurred while retrieving the RpSmfaAttempt list for sessionId: %s ", sessionId), e);
        }
        return entity; 
    }
}
