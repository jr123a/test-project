package com.ips.dao.impl;

import java.util.Collection;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.ips.dao.RefLexisNexisResponseCodeDao;
import com.ips.entity.RefLexisNexisResponseCode;

@Repository
public class RefLexisNexisResponseCodeDaoImpl extends GenericJPADAO<RefLexisNexisResponseCode,String>
        implements RefLexisNexisResponseCodeDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefLexisNexisResponseCode> getAll() {
        Query query = em.createNamedQuery("lnResponseCode.findAll");
        return query.getResultList();
    }

    @Override
    public RefLexisNexisResponseCode getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void save(RefLexisNexisResponseCode responseCode) {
         super.save(responseCode);
    }

    @Override
    public void update(RefLexisNexisResponseCode responseCode) {
        super.merge(responseCode);
    }

    @Override
    public void delete(RefLexisNexisResponseCode responseCode) {
        super.delete(responseCode);
    }

    @Override
    public RefLexisNexisResponseCode getById(String code) {
        Query query = em.createNamedQuery("lnResponseCode.findById");
        query.setParameter("code", code);
        
        if (query.getResultList() == null || query.getResultList().isEmpty()) {
            return null;
        } else{
            return (RefLexisNexisResponseCode) query.getResultList().get(0);
        }
    }
    
    @Override
    public RefLexisNexisResponseCode getByDescription(String description) {
        Query query = em.createNamedQuery("lnResponseCode.findByDescription");
        query.setParameter("description", description);
        
        if (query.getResultList() == null || query.getResultList().isEmpty()) {
            return null;
        } 
        else {
            return (RefLexisNexisResponseCode) query.getResultList().get(0);
        }
    }
    
    @Override
    public RefLexisNexisResponseCode getByProductReason(String productReason) {
        Query query = em.createNamedQuery("lnResponseCode.findByProductReason");
        query.setParameter("productReason", productReason.toUpperCase());
        
        if (query.getResultList() == null || query.getResultList().isEmpty()) {
            return null;
        } 
        else {
            return (RefLexisNexisResponseCode) query.getResultList().get(0);
        }
    }

}
