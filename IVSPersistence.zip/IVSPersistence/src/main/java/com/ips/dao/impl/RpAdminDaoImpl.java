package com.ips.dao.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RpAdminDao;
import com.ips.entity.RpAdmin;

@Repository
public class RpAdminDaoImpl extends GenericJPADAO< RpAdmin, String> implements RpAdminDao {

    //TODO why did this return null? doesn't seem to be used
    @Override
    public Collection<RpAdmin> getAll() {
        return Collections.emptyList();
    }

    @Override
    public RpAdmin getById(String id) {
        return super.getById(id);
    }

    @Override
    public void save(RpAdmin rpAdmin) {
        super.save(rpAdmin);
    }
    
    @Override
    public void update(RpAdmin rpAdmin) {
        super.merge(rpAdmin);
    }
    
    @Override
    public void delete(RpAdmin rpAdmin) {
        super.delete(rpAdmin);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public String getAuditEventDescription(String userId) {
        Query query = em.createNativeQuery("SELECT admin_event_detailed_desc FROM audit_rp_admin " +
                "WHERE user_id = ? " +
                "ORDER BY audit_rm_admin_id DESC");
        
        query.setParameter(1, userId);
        
        List<String> results = query.getResultList();
        
        if (results.isEmpty()) {
            return "";
        } 
        return results.get(0);
    }
    
    @Override
    public List<RpAdmin> findRpAdminBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<RpAdmin> list = em.createNamedQuery("RpAdmin.findRpAdminBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }

}
