package com.ips.dao;

import com.ips.entity.RefValidationStatusCode;

public interface RefValidationStatusCodeDao {
    void update(RefValidationStatusCode code);
    RefValidationStatusCode getByName(String name);
}
