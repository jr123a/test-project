package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RefAttributeGroup;
import com.ips.entity.RefAttributeGroupPK;


public interface RefAttributeGroupDao {

    Collection<RefAttributeGroup> getAll();    
    RefAttributeGroup getById(RefAttributeGroupPK id);
    void save(RefAttributeGroup refAttributeGroup);
    void update(RefAttributeGroup refAttributeGroup);
    void delete(RefAttributeGroup refAttributeGroup);
    List<RefAttributeGroup> findByIndex(short attrIndex);
}
