package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpOtpAttemptConfig;
import com.ips.entity.RpOtpAttemptConfigPK;

public interface RpOtpAttemptConfigDao {
    Collection<RpOtpAttemptConfig> getAll();    
    RpOtpAttemptConfig getById(RpOtpAttemptConfigPK id);
    RpOtpAttemptConfig findByPrimaryKey(long proofingLevel, long sponsorId, long otpSupplierId);
    void save(RpOtpAttemptConfig otpAttemptConfig);
    void update(RpOtpAttemptConfig otpAttemptConfig);
    void delete(RpOtpAttemptConfig otpAttemptConfig);
    Collection<RpOtpAttemptConfig> getByProofingLevel(long proofingLevel, long sponsorId);
    Collection<RpOtpAttemptConfig> getByProofingLevelSorted(List<Long> otpSupplierIds, long proofingLevel, long sponsorId);
    List<RpOtpAttemptConfig> findRowsForReset();
}
