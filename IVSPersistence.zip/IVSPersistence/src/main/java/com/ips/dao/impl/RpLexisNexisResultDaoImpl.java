package com.ips.dao.impl;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RpLexisNexisResultDao;
import com.ips.entity.RefLexisNexisResponseCode;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefSponsor;
import com.ips.entity.RpEvent;
import com.ips.entity.RpLexisNexisResult;

@Repository
public class RpLexisNexisResultDaoImpl extends GenericJPADAO<RpLexisNexisResult, Long> implements
        RpLexisNexisResultDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpLexisNexisResult> getAll() {
        Query query = em.createNamedQuery("lnResults.findAll");
        return query.getResultList();
    }

    @Override
    public RpLexisNexisResult getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void save(RpLexisNexisResult rpLexisNexisResult) {
        super.save(rpLexisNexisResult);
    }

    @Override
    public void update(RpLexisNexisResult rpLexisNexisResult) {
        super.merge(rpLexisNexisResult);
    }

    @Override
    public void delete(RpLexisNexisResult rpLexisNexisResult) {
        super.delete(rpLexisNexisResult);
    }

    @Override
    public RpLexisNexisResult findByEvent(RpEvent rpEvent) {
        Query query = em.createNamedQuery("lnResults.findByEvent").setParameter("event", rpEvent);
        if(query.getResultList().isEmpty()){
            return null;
        } else{
            return (RpLexisNexisResult) query.getResultList().get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Retrieves the Lexis Nexis response codes in the timeframe.
     * @param start
     * @param end
     * @return
     */
    public List<RefLexisNexisResponseCode> getLexisResponseCodes(Date start, Date end, RefLoaLevel loa) {
        Query query = em.createNativeQuery(
                "SELECT l.response_code, l.response_code_description, l.create_date, l.update_date " +
                "FROM rp_event e, rp_lexisnexis_result r, ref_lexisnexis_response_code l, person p " +
                "WHERE e.event_id = r.event_id " +
                "AND r.response_code = l.response_code " +
                "AND e.person_id = p.person_id " +
                "AND e.proofing_level_sought = ? " +
                "AND e.initiation_datetime >= ? " +
                "AND e.initiation_datetime <= ? " +
                "AND p.sponsor_id = ?", RefLexisNexisResponseCode.class);
        
        query.setParameter(1, loa.getLoaCode());
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefSponsor.SPONSOR_ID_CUSTREG);
        
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getResponseCodeCount(Date start, Date end, String responseCode) {
        Query query = em.createNativeQuery(
                "SELECT count(distinct e.event_id) " +
                "FROM rp_event e, rp_lexisnexis_result r, person p " +
                "WHERE e.event_id = r.event_id " +
                "AND e.person_id = p.person_id " +
                "AND r.response_code = ? " +
                "AND e.initiation_datetime >= ? " +
                "AND e.initiation_datetime <= ? " +
                "AND p.sponsor_id = ?");
        
        query.setParameter(1, responseCode);
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefSponsor.SPONSOR_ID_CUSTREG);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return new Long(count.longValue());
        }
    }

}
