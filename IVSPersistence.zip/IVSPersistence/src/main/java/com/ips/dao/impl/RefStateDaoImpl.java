package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefStateDao;
import com.ips.entity.RefState;

@Repository
public class RefStateDaoImpl extends GenericJPADAO<RefState, String> implements
        RefStateDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefState> getAllActiveStates() {
        Query query = em.createNamedQuery("RefState.findAllActiveStates");
        return  query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefState> getAll() {
        Query query = em.createNamedQuery("RefState.findAll");
        return query.getResultList();
    }

    @Override
    public void update(RefState refState) {
        super.merge(refState);
    }

    @SuppressWarnings("unchecked")
    @Override
    public RefState findByStateCode(String stateCode) {
        Query query = em.createNamedQuery("RefState.findByStateCode").setParameter("stateCode", stateCode);
        List<RefState> results = query.getResultList();
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }

}
