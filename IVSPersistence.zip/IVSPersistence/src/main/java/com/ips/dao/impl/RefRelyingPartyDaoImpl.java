package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefRelyingPartyDao;
import com.ips.entity.RefRelyingParty;

@Repository
public class RefRelyingPartyDaoImpl extends GenericJPADAO<RefRelyingParty, Long> implements
        RefRelyingPartyDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;


    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefRelyingParty> getAll() {
//        em = getEntityManager();
        Query query = em.createNamedQuery("RefRelyingParty.findAll");
        return query.getResultList();
    }

    @Override
    public RefRelyingParty getById(Long id) {
        return super.getById(id);
    }


    @Override
    public void update(RefRelyingParty status) {
        super.merge(status);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RefRelyingParty findByAcronym(String acronym) {
        Query query = em.createNamedQuery("RefRelyingParty.findByAcronym");
        query.setParameter("acronym", acronym);
        List<RefRelyingParty> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
        
    }

}
