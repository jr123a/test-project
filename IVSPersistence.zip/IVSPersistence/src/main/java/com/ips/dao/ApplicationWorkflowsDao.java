package com.ips.dao;

import java.util.List;

import com.ips.entity.ApplicationWorkflows;

public interface ApplicationWorkflowsDao {

    List<ApplicationWorkflows> list();

    List<ApplicationWorkflows> getWorkflowCombo(long acr, long device, long sponsor, long workflow);
    
    List<ApplicationWorkflows> getWorkflowsByAppDeviceLoaCodeSponsor(long appID, long deviceID, long loaCode, long sponsorId);

    ApplicationWorkflows getWorkflowFromId(long workflowId);

    void save(ApplicationWorkflows apps);

    ApplicationWorkflows merge(ApplicationWorkflows apps);
    
    List<ApplicationWorkflows> findApplicationWorkflowsBySponsor(long sponsorId);

    void delete(ApplicationWorkflows apps);

}
