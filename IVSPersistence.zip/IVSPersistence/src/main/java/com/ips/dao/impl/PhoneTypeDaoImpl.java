package com.ips.dao.impl;

import java.util.Collection;

import javax.persistence.Query;
import org.springframework.stereotype.Repository;

import com.ips.dao.PhoneTypeDao;
import com.ips.entity.RefPhoneType;

@Repository
public class PhoneTypeDaoImpl extends GenericJPADAO<RefPhoneType,String> implements PhoneTypeDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefPhoneType> getAll() {
        Query query = em.createNamedQuery("RefPhoneType.findAll");
        return query.getResultList();
    }

    @Override
    public RefPhoneType getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void save(RefPhoneType entity) {
        super.save(entity);
    }

    @Override
    public void update(RefPhoneType entity) {
        super.merge(entity);
    }

    @Override
    public void delete(RefPhoneType entity) {
        super.delete(entity);
    }

    @Override
    public RefPhoneType getPhoneTypeByName(String name) {
        Query query = em.createNamedQuery("RefPhoneType.findByName");
        query.setParameter("name", name);
        
        if (query.getResultList() == null || query.getResultList().isEmpty()) {
            return null;
        } else {
            return (RefPhoneType) query.getResultList().get(0);
        }
    }

}
