package com.ips.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.IppBarcodeScansDao;
import com.ips.entity.IppBarcodeScans;

@Repository
public class IppBarcodeScansDaoImpl extends GenericJPADAO<IppBarcodeScans, Long> implements IppBarcodeScansDao,Serializable {
    
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public List<IppBarcodeScans> list() {
            Query query = em.createNamedQuery("IppBarcodeScans.findAll");
            return query.getResultList();
    }
    
    @Override
    public IppBarcodeScans getInvalidScanFromId(long invalidScanId) {
        Query query = em.createNamedQuery("IppBarcodeScans.findByID");
        return (IppBarcodeScans) query.getResultList().get(0);
    }
    
    @Override
    public void save(IppBarcodeScans entity) {
        super.save(entity);
    }
}
