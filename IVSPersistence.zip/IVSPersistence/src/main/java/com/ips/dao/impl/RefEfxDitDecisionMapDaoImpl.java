package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefEfxDitDecsionMapDao;
import com.ips.entity.RefEfxDitDecisionMap;


@Repository
public class RefEfxDitDecisionMapDaoImpl extends GenericJPADAO<RefEfxDitDecisionMap, Long> implements
		RefEfxDitDecsionMapDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefEfxDitDecisionMap> getAll() {        
        Query query = em.createNamedQuery("RefEfxDitDecisionMap.findAll");
        return query.getResultList();
    }
    
   
}

