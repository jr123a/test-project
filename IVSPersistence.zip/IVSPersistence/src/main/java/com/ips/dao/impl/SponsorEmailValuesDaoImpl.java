package com.ips.dao.impl;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ips.dao.SponsorEmailValuesDao;
import com.ips.entity.SponsorEmailValues;

@Repository
public class SponsorEmailValuesDaoImpl extends GenericJPADAO<SponsorEmailValues, Long> implements SponsorEmailValuesDao, Serializable {
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public SponsorEmailValues getEmailBySponsorIdAndEmailType(Long id, Long emailType) {
        List<SponsorEmailValues> sev = em.createNamedQuery("SponsorEmailValues.getEmailBySponsorIdAndEmailType").setParameter("sponsorId", id).setParameter("emailType", emailType).getResultList();
        return sev.isEmpty() ? null : sev.get(0);
    }
    
    @Override
    public void update(SponsorEmailValues entity) {
        super.merge(entity);
    }
    
    @Override
    public void create(SponsorEmailValues entity) {
        super.save(entity);
    }
    
    @Override
    public void delete(SponsorEmailValues entity) {
        super.delete(entity);
    }
    
    @Override
    public List<SponsorEmailValues> findSponsorEmailValuesBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<SponsorEmailValues> list = em.createNamedQuery("SponsorEmailValues.findSponsorEmailValuesBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
}
