package com.ips.dao;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.ips.entity.ReportExecuted;


public interface ReportDao {

    Collection<ReportExecuted> getAll();
    ReportExecuted getById(String reportName);
    void save(ReportExecuted reportExecuted);
    void update(ReportExecuted reportExecuted);
    void delete(ReportExecuted reportExecuted);
    List<ReportExecuted> findReports(String reportName, Date executionDate);
}
