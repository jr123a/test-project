package com.ips.dao;

import java.util.List;

import com.ips.entity.RefIppWorkflows;

public interface RefIppWorkflowsDao {

    List<RefIppWorkflows> list();
    RefIppWorkflows getById(Long id);
    void save(RefIppWorkflows entity);
    void update(RefIppWorkflows entity);
    void delete(RefIppWorkflows entity);    
}
