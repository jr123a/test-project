package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefServiceStatusCode;

public interface PhoneServiceStatusDao {
    Collection<RefServiceStatusCode> getAll();    
    RefServiceStatusCode getById(Long id);
    void save(RefServiceStatusCode entity);
    void update(RefServiceStatusCode entity);
    void delete(RefServiceStatusCode entity);
    RefServiceStatusCode getServiceStatusByName(String name);
}
