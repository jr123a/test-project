package com.ips.dao;

import java.util.List;

import com.ips.entity.RefOtpSupplier;

public interface RefOtpSupplierDao {
    RefOtpSupplier findBySupplierId(long id);
    List<RefOtpSupplier> getActiveSupplierList();
}
