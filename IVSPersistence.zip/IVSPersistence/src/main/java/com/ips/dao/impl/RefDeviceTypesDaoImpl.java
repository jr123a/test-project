package com.ips.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RefDeviceTypesDao;
import com.ips.entity.RefDeviceTypes;

@Repository
public class RefDeviceTypesDaoImpl extends GenericJPADAO<RefDeviceTypes, Long> implements RefDeviceTypesDao {

    @SuppressWarnings("unchecked")
    @Override
    public List<RefDeviceTypes> getDeviceList() {
        List<RefDeviceTypes> list = null;
        try {
            Query query = em.createNamedQuery("RefDeviceTypes.findAll");

            list = query.getResultList();
            if (list == null) {
                list = new ArrayList<>();
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception getting RefDeviceTypes data", e);
        }

        return list;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RefDeviceTypes getDeviceTypeById(long deviceID) {
        Query query = em.createNamedQuery("RefDeviceTypes.findByDeviceId");
        query.setParameter("device", deviceID);
        List<RefDeviceTypes> results = query.getResultList();
        return results.isEmpty() ? null : results.get(0);
    }

}
