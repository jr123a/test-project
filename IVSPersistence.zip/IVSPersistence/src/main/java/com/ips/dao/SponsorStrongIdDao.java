package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.SponsorStrongId;

public interface SponsorStrongIdDao {
    Collection<SponsorStrongId> getAll();
    Collection<SponsorStrongId> getListBySponsorId(Long sponsorId);
    SponsorStrongId create(SponsorStrongId entity);
    void remove(Long sponsorId, Long idType);
    void delete(SponsorStrongId entity);
    long getPrimaryIdCountForSponsor(long idType);
    List<SponsorStrongId> findSponsorStrongIdBySponsor(long sponsorId);
    SponsorStrongId getByPK(Long sponsorId, Long idType);
}
