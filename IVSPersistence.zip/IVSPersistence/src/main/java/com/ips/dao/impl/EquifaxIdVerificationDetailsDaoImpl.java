package com.ips.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.EquifaxIdVerificationDetailsDao;
import com.ips.entity.EquifaxIdVerificationDetails;

@Repository
public class EquifaxIdVerificationDetailsDaoImpl extends GenericJPADAO<EquifaxIdVerificationDetails, Long> implements EquifaxIdVerificationDetailsDao{

	
	@Override
	public void save(EquifaxIdVerificationDetails request) {
		super.save(request);
	}
	
	@Override
	public void update(EquifaxIdVerificationDetails request) {
		super.merge(request);
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<EquifaxIdVerificationDetails> getVerificationDetailsForEvent(long eventId) {
		List<EquifaxIdVerificationDetails> details = new ArrayList<EquifaxIdVerificationDetails>();
		Query query = em.createNamedQuery("EquifaxIdVerificationDetails.getVerificationDetailsByEvent");
		query.setParameter("eventId", eventId);
		List <EquifaxIdVerificationDetails> results = query.getResultList();
		// Create a mutable list so it can be sorted
		details.addAll(results);
		return details;
	}
}
