package com.ips.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.RpEventDao;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefSponsor;
import com.ips.entity.RpEvent;
import com.ips.persistence.common.AuditPersonVo;
import com.ips.persistence.common.AutomatedTransactionReportVo;

@Transactional
@Repository
public class RpEventDaoImpl extends GenericJPADAO<RpEvent, Long> implements Serializable, RpEventDao{    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private static final String APP_ID_PARAM = "appId";
    private static final String BIG_DECIMAL = "BigDecimal"; 
    private static final String CURRENT_TIME_PARAM = "currentTime";
    private static final String DECISION_PARAM = "decision";
    private static final String END_PARAM = "end";
    private static final String LEVEL_PARAM = "level";
    private static final String MOBILE_PHONE_NUMBER_PARAM = "mobilePhoneNumber";
    private static final String PID_PARAM = "pid";
    private static final String PERSON_ID_PARAM = "personId";
    private static final String SPONSOR_PARAM = "sponsor";
    private static final String START_PARAM = "start";
    private static final String SUPPLIER_ID_PARAM = "supplierId";
    private static final String TRANSACTION_ID_PARAM = "transactionId";
    private static final String WINDOW_PARAM = "window";
       

    @SuppressWarnings("unchecked")
    public List<RpEvent> getEventByPersonId(long personId) {
        Query query = em.createNamedQuery("RpEvent.getEventByPersonId")
        		.setParameter(PID_PARAM, personId);
        return query.getResultList();
    }
    
    @Override
    public RpEvent findLatestEventByPersonId(long personId) {
    	List<RpEvent> list = (List<RpEvent>) getEventByPersonId(personId);
        return list.isEmpty() ? null : list.get(0);
    }

    @SuppressWarnings("unchecked")
    public List<RpEvent> getEventBySponsorUserId(String sponsorUserId) {
        Query query = em.createNamedQuery("RpEvent.getEventBySponsorUserId")
        		.setParameter("sponsorUserId", sponsorUserId);
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    public List<Long> countEventIds(long personId, long supplierId, Timestamp window,
            Timestamp current) {
        Query query = em.createNamedQuery("RpEvent.countEventIDs")
                .setParameter(PID_PARAM, personId)
                .setParameter(SUPPLIER_ID_PARAM, supplierId)
                .setParameter(WINDOW_PARAM, window)
                .setParameter(CURRENT_TIME_PARAM, current);
        return query.getResultList();
    }
    
    public RpEvent getRpEventById(long eventId){
        return em.find(RpEvent.class, eventId);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpEvent> getAll() {
        Query query = em.createNamedQuery("RpEvent.findAll");
        return query.getResultList();
    }

    @Override
    public void update(RpEvent rpEvent) {
        super.merge(rpEvent);        
    }

    @Override
    public RpEvent getById(Long id) {        
        return super.getById(id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RpEvent> getRpEventsInWindow(long personId, long supplierId, Timestamp window,
            Timestamp current) {
        Query query = em.createNamedQuery("RpEvent.getRpEventsInWindow")
                .setParameter(PID_PARAM, personId)
                .setParameter(SUPPLIER_ID_PARAM, supplierId)
                .setParameter(WINDOW_PARAM, window)
                .setParameter(CURRENT_TIME_PARAM, current);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Long> countRpEvents(long personId, long supplierId) {
        Query query = em.createNamedQuery("RpEvent.countRpEvents")
        		.setParameter(PID_PARAM, personId)
                .setParameter(SUPPLIER_ID_PARAM, supplierId);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Long> ctRpEventsPerDate(Date start, Date end, RefLoaLevel loaLevel, RefSponsor sponsor) {
        Query query = em.createNamedQuery("RpEvent.ctRpEventsPerDate")
        		.setParameter(START_PARAM, start)
                .setParameter(END_PARAM, end)
                .setParameter(LEVEL_PARAM, loaLevel)
                .setParameter(SPONSOR_PARAM,  sponsor);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Long> ctRpEventsPerDateByDecision(String decision, Date start, Date end, RefLoaLevel loaLevel, RefSponsor sponsor) {
        Query query = em.createNamedQuery("RpEvent.ctRpEventsPerDateByDecision")
        		.setParameter(DECISION_PARAM, decision)
        		.setParameter(START_PARAM, start)
                .setParameter(END_PARAM, end)
                .setParameter(LEVEL_PARAM, loaLevel)
                .setParameter(SPONSOR_PARAM,  sponsor);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Long> ctRpEventsPerDateNoDecision(Date start, Date end, RefLoaLevel loaLevel, RefSponsor sponsor) {
        Query query = em.createNamedQuery("RpEvent.ctRpEventsPerDateNoDecision")
        		.setParameter(START_PARAM, start)
                .setParameter(END_PARAM, end)
                .setParameter(LEVEL_PARAM, loaLevel)
                .setParameter(SPONSOR_PARAM,  sponsor);
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * If a user enters the IVS application more than once on a particular day, this query will count every time they come in.
     * @param start
     * @param end
     * @return
     */
    public Long getEnteredIVSCount(Date start, Date end) {
    	StringBuilder sqlSb =  new StringBuilder();
    	sqlSb.append("SELECT COUNT(*) FROM audit_person ");
    	sqlSb.append("WHERE proofing_status like 'Just Login%' ");
    	sqlSb.append("AND person_id IN (SELECT person_id FROM person ");
    	sqlSb.append("WHERE user_type IS NULL) ");
    	sqlSb.append("AND entered_ivs_datetime >= ? AND entered_ivs_datetime <= ? ");
    	sqlSb.append("AND proofing_level = ? ");
    	sqlSb.append("AND sponsor_id = ?");
 
        Query query = em.createNativeQuery(sqlSb.toString());
        
        query.setParameter(1, start);
        query.setParameter(2, end);
        query.setParameter(3, RefLoaLevel.LOA_15);
        query.setParameter(4, RefSponsor.SPONSOR_ID_CUSTREG);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getIVSLockoutCount(Date start, Date end) {
    	StringBuilder sqlSb =  new StringBuilder();
    	sqlSb.append("SELECT COUNT(*) FROM audit_kba_lockout_info ");
    	sqlSb.append("WHERE person_id IN (SELECT person_id FROM person  ");
    	sqlSb.append("WHERE user_type IS NULL AND sponsor_id = ?)  ");
    	sqlSb.append("AND ivs_lockout_datetime >= ? AND ivs_lockout_datetime <= ? "); 
    	sqlSb.append("AND proofing_level = ? ");

        Query query = em.createNativeQuery(sqlSb.toString());
        
        query.setParameter(1, RefSponsor.SPONSOR_ID_CUSTREG);
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefLoaLevel.LOA_15);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Reason code 07 indicates a pattern recognition failure for the user.
     */
    public Long getPatternRecognitionCount(Date start, Date end) {
    	StringBuilder sqlSb =  new StringBuilder();
    	sqlSb.append("SELECT COUNT(*)  ");
    	sqlSb.append("FROM rp_event e, rp_equifax_final_reason_codes r ");
    	sqlSb.append("WHERE person_id IN (SELECT person_id FROM person   ");
    	sqlSb.append("WHERE user_type IS NULL AND sponsor_id = ?)   ");
    	sqlSb.append("AND e.event_id =  r.event_id ");
    	sqlSb.append("AND r.reason_code = '07' ");
    	sqlSb.append("AND initiation_datetime >= ? AND initiation_datetime <= ?  ");
    	sqlSb.append("AND proofing_level_sought = ?  ");
    			
        Query query = em.createNativeQuery(sqlSb.toString());
        
        query.setParameter(1, RefSponsor.SPONSOR_ID_CUSTREG);
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefLoaLevel.LOA15_CODE);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getEquifaxErrorsCount(Date start, Date end) {
    	StringBuilder sqlSb =  new StringBuilder();
    	sqlSb.append("SELECT COUNT(*) "); 
    	sqlSb.append("FROM rp_event e, rp_equifax_errors r ");
    	sqlSb.append("WHERE person_id IN  (SELECT person_id FROM person ");
    	sqlSb.append("WHERE user_type IS NULL AND  sponsor_id = ?) ");
    	sqlSb.append("AND e.event_id = r.event_id  ");
    	sqlSb.append("AND avs_errors_datetime >= ? AND avs_errors_datetime <= ? ");
    	sqlSb.append("AND proofing_level_sought = ?  ");
    			
        Query query = em.createNativeQuery(sqlSb.toString());
        
        query.setParameter(1, RefSponsor.SPONSOR_ID_CUSTREG);
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefLoaLevel.LOA15_CODE);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getFieldCheckErrorsCount(Date start, Date end) {
    	StringBuilder sqlSb =  new StringBuilder();
    	sqlSb.append("SELECT COUNT(*) "); 
    	sqlSb.append("FROM rp_event e, rp_equifax_field_checks r "); 
    	sqlSb.append("WHERE person_id  IN (SELECT person_id FROM person "); 
    	sqlSb.append("WHERE user_type  IS NULL AND sponsor_id = ?) "); 
    	sqlSb.append("AND e.event_id = r.event_id  "); 
    	sqlSb.append("AND initiation_datetime >= ? AND initiation_datetime <= ?  "); 
    	sqlSb.append("AND proofing_level_sought = ?"); 
    			
        Query query = em.createNativeQuery(sqlSb.toString());
        
        query.setParameter(1, RefSponsor.SPONSOR_ID_CUSTREG);
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefLoaLevel.LOA15_CODE);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Returns a count of times when reason codes were returned and no questions were presented.
     */
    public Long getNoQuestionsCount(Date start, Date end) {
    	StringBuilder sqlSb =  new StringBuilder();
    		sqlSb.append("SELECT COUNT(distinct e.event_id)  ");
    		sqlSb.append("FROM rp_event e, rp_equifax_final_reason_codes r ");
    		sqlSb.append("WHERE person_id IN (SELECT person_id FROM person ");
    		sqlSb.append("WHERE user_type IS NULL AND sponsor_id = ?) ");
    		sqlSb.append("AND e.event_id = r.event_id ");
    		sqlSb.append("AND r.reason_code != '07' ");
    		sqlSb.append("AND (questions_returned = 'N' OR questions_returned IS NULL)  ");
    		sqlSb.append("AND initiation_datetime >= ? AND initiation_datetime <= ? ");
    		sqlSb.append("AND proofing_level_sought = ? ");
    			
        Query query = em.createNativeQuery(sqlSb.toString());
        
        query.setParameter(1, RefSponsor.SPONSOR_ID_CUSTREG);
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefLoaLevel.LOA15_CODE);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getTakenBySupplier(Date start, Date end, RefLoaLevel loaLevel, long supplierId, RefSponsor refSponsor) {
        Query query = em.createNamedQuery("RpEvent.getTakenBySupplier");
        
        query.setParameter(START_PARAM, start);
        query.setParameter(END_PARAM, end);
        query.setParameter(LEVEL_PARAM, loaLevel);
        query.setParameter(SUPPLIER_ID_PARAM, supplierId);
        query.setParameter(SPONSOR_PARAM, refSponsor);
        
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getIncompleteBySupplier(Date start, Date end, RefLoaLevel loaLevel, long supplierId, RefSponsor refSponsor) {
        Query query = em.createNamedQuery("RpEvent.getIncompleteBySupplier");
        
        query.setParameter(START_PARAM, start);
        query.setParameter(END_PARAM, end);
        query.setParameter(LEVEL_PARAM, loaLevel);
        query.setParameter(SUPPLIER_ID_PARAM, supplierId);
        query.setParameter(SPONSOR_PARAM, refSponsor);
        
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Returns a count of times Lexis returned velocity check failure (response code IA:40).
     */
    public Long getLexisVelocityCount(Date start, Date end) {
    	StringBuilder sqlSb =  new StringBuilder();
			sqlSb.append("SELECT COUNT(distinct e.event_id) "); 
			sqlSb.append("FROM rp_event e, rp_lexisnexis_result r "); 
			sqlSb.append("WHERE person_id IN (SELECT person_id FROM person "); 
			sqlSb.append("WHERE user_type IS NULL AND sponsor_id = ?) "); 
			sqlSb.append("AND e.event_id = r.event_id "); 
			sqlSb.append("AND r.response_code = 'IA:40' "); 
			sqlSb.append("AND (questions_returned = 'N' OR questions_returned IS NULL) "); 
			sqlSb.append("AND initiation_datetime >= ? AND initiation_datetime <= ? "); 
			sqlSb.append("AND proofing_level_sought = ? "); 
				
        Query query = em.createNativeQuery(sqlSb.toString());
        
        query.setParameter(1, RefSponsor.SPONSOR_ID_CUSTREG);
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefLoaLevel.LOA15_CODE);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Returns a count of times response codes were returned.  A response code may be returned and still get questions (for example, quiz expired).
     */
    public Long getLexisErrorsCount(Date start, Date end) {
    	StringBuilder sqlSb =  new StringBuilder();
			sqlSb.append("SELECT COUNT(distinct e.event_id) "); 
			sqlSb.append("FROM rp_event e, rp_lexisnexis_result r "); 
			sqlSb.append("WHERE person_id IN (SELECT person_id FROM person "); 
			sqlSb.append("WHERE user_type IS NULL AND sponsor_id = ?) "); 
			sqlSb.append("AND e.event_id = r.event_id "); 
			sqlSb.append("AND r.response_code != 'IA:40' "); 
			sqlSb.append("AND initiation_datetime >= ? AND initiation_datetime <= ? ");  
			sqlSb.append("AND proofing_level_sought = ? "); 
				
        Query query = em.createNativeQuery(sqlSb.toString());
        
        query.setParameter(1, RefSponsor.SPONSOR_ID_CUSTREG);
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefLoaLevel.LOA15_CODE);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Returns a count of times users failed the Lexis/Nexis prechecks (current residency check for LOA 1.5) 
     * rather than getting the quiz.
     */
    public Long getVerifyFailureCount(Date start, Date end) {
    	StringBuilder sqlSb =  new StringBuilder();
			sqlSb.append("SELECT COUNT(distinct e.event_id) "); 
			sqlSb.append("FROM rp_event e, rp_lexisnexis_finalreason_code r, ref_kba_reason_code rc ");
			sqlSb.append("WHERE person_id IN (SELECT person_id FROM person ");
			sqlSb.append("WHERE user_type IS NULL AND sponsor_id = ?) ");
			sqlSb.append("AND e.event_id = r.event_id ");
			sqlSb.append("AND r.reason_code = rc.reason_code ");
			sqlSb.append("AND r.reason_code in ('Z1', 'Z3', 'Z5', 'Z7', 'Z9', 'ZB')");
			sqlSb.append("AND (questions_returned = 'N' OR questions_returned IS NULL) ");
			sqlSb.append("AND initiation_datetime >= ? AND initiation_datetime <= ? "); 
			sqlSb.append("AND proofing_level_sought = ? ");
				
        Query query = em.createNativeQuery(sqlSb.toString());
        
        query.setParameter(1, RefSponsor.SPONSOR_ID_CUSTREG);
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefLoaLevel.LOA15_CODE);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getTotalEventsByLevelAndSupplier(Date start, Date end, RefLoaLevel loaLevel, long supplierId, RefSponsor refSponsor) {
        Query query = em.createNamedQuery("RpEvent.getTotalEventsByLevelAndSupplier");
        
        query.setParameter(START_PARAM, start);
        query.setParameter(END_PARAM, end);
        query.setParameter(LEVEL_PARAM, loaLevel);
        query.setParameter(SUPPLIER_ID_PARAM, supplierId);
        query.setParameter(SPONSOR_PARAM, refSponsor);
        
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getTotalEventsByLevel(Date start, Date end, RefLoaLevel loaLevel, RefSponsor refSponsor) {
        Query query = em.createNamedQuery("RpEvent.getTotalEventsByLevel");
        
        query.setParameter(START_PARAM, start);
        query.setParameter(END_PARAM, end);
        query.setParameter(LEVEL_PARAM, loaLevel);
        query.setParameter(SPONSOR_PARAM, refSponsor);
        
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    public RpEvent getEventByTransactionId(String transactionId) {
        Query query = em.createNamedQuery("RpEvent.getEventByTransactionId")
        		.setParameter(TRANSACTION_ID_PARAM, transactionId);
        @SuppressWarnings("unchecked")
        List<RpEvent> list = (List<RpEvent>) query.getResultList();
        return list.isEmpty() ? null : list.get(0);
    }

    @SuppressWarnings("unchecked")
    @Override
    public RpEvent getLatestPhoneVerification(long personId, long supplierId) {
        Query query = em.createNamedQuery("RpEvent.getLatestPhoneVerificationEvent");
        query.setParameter(PERSON_ID_PARAM, personId);
        query.setParameter(SUPPLIER_ID_PARAM, supplierId);
        
        List<RpEvent> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getCountInWindow(long personId, long supplierId, Timestamp window, Timestamp current) {
        Query query = em.createNamedQuery("RpEvent.getCountInWindow")
                .setParameter(PID_PARAM, personId)
                .setParameter(SUPPLIER_ID_PARAM, supplierId)
                .setParameter(WINDOW_PARAM, window)
                .setParameter(CURRENT_TIME_PARAM, current);
        
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getPhoneCountInWindow(long personId, long supplierId, int attemptWindow) {
    	StringBuilder sqlSb =  new StringBuilder();
			sqlSb.append("SELECT COUNT(*) FROM rp_event e, rp_phone_verifications v  ");
			sqlSb.append(String.format("WHERE e.person_id = %s ", personId));
			sqlSb.append(String.format("AND e.kba_supplier_id = %s ", supplierId));
			sqlSb.append("AND e.event_id = v.event_id ");
			sqlSb.append("AND phone_verification_decision != 'PENDING' ");
			sqlSb.append("AND kba_transaction_id IS NULL ");
			sqlSb.append(String.format("AND e.create_date >= (CURRENT_TIMESTAMP - (%s/24)) ", attemptWindow));
			sqlSb.append("AND e.create_date <= CURRENT_TIMESTAMP");
	 
    	Query query = em.createNativeQuery(sqlSb.toString());   
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getRepeatPhoneAssessmentCountInWindow(long personId, long supplierId, int attemptWindow) {
    	StringBuilder sqlSb =  new StringBuilder();
			sqlSb.append("SELECT COUNT(*) FROM rp_event e, rp_phone_verifications v  ");
			sqlSb.append(String.format("WHERE e.person_id = %s ", personId));
			sqlSb.append(String.format("AND e.kba_supplier_id = %s ", supplierId));
			sqlSb.append("AND e.event_id = v.event_id ");
			sqlSb.append("AND kba_transaction_id IS NOT NULL ");
			sqlSb.append(String.format("AND e.create_date >= (CURRENT_TIMESTAMP - (%s/24)) ", attemptWindow));
			sqlSb.append("AND e.create_date <= CURRENT_TIMESTAMP");
	 
    	Query query = em.createNativeQuery(sqlSb.toString());   
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Since the count of phone verifications does not include PENDING events, we also need a method that returns
     * the events that are not still PENDING.
     * @param personId
     * @param supplierId
     * @param window
     * @param current
     * @return
     */
    public List<RpEvent> getPhoneEventsInWindow(long personId, long supplierId, Timestamp window, Timestamp current) {
        Query query = em.createNamedQuery("RpEvent.getPhoneEventsInWindow")
                .setParameter(PID_PARAM, personId)
                .setParameter(SUPPLIER_ID_PARAM, supplierId)
                .setParameter(WINDOW_PARAM, window)
                .setParameter(CURRENT_TIME_PARAM, current);
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * To determine previous event with same mobile phone number
     * the events that are not still PENDING.
     * @param personId
     * @param mobilePhoneNumber
     * @return
     */
    public RpEvent getLatestPhoneEventsByPersonIdAndPhoneNumber(long personId, String mobilePhoneNumber) {
        Query query = em.createNamedQuery("RpEvent.getLatestPhoneEventsByPersonIdAndPhoneNumber")
                .setParameter(PERSON_ID_PARAM, personId)
                .setParameter(MOBILE_PHONE_NUMBER_PARAM, mobilePhoneNumber);
        List<RpEvent> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);    
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<AutomatedTransactionReportVo> getAutomatedTransactions(long sponsorId, LocalDateTime startDateTime, LocalDateTime endDateTime) {
        
        DateTimeFormatter queryDateformatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss");
        String startDateString = startDateTime.format(queryDateformatter); 
        String endDateString =     endDateTime.format(queryDateformatter); 
        
        StringBuilder sqlSb =  new StringBuilder();
			sqlSb.append("select b.person_id, d.SPONSOR_USER_ID CustRegID,a.EMAIL_ADDRESS,");
			sqlSb.append("c.KBA_SUPPLIER_NAME, z.MOBILE_PHONE_NUMBER,z.TRANSACTION_KEY, "); 
			sqlSb.append("CASE b.kba_supplier_id ");
			sqlSb.append("when 3 THEN z.OVERALL_ASSESSMENT ");
			sqlSb.append("when 4 THEN z.PHONE_VERIFICATION_DECISION "); 
			sqlSb.append("END AS PVOutcome, ");
			sqlSb.append("NVL(b.final_decision,'Abandon') FinalDecision, z.NUMBER_OF_SUBMIT_ATTEMPTS SubmitOTP, "); 
			sqlSb.append("z.NUMBER_OF_RENEW_ATTEMPTS RequestNewCodes, b.create_date ");
			sqlSb.append("from ips_own.rp_event b, ips_own.ref_kba_supplier c,IPS_OWN.RP_PHONE_VERIFICATIONS z,");
			sqlSb.append("IPS_OWN.PERSON_DATA a, IPS_OWN.PERSON d "); 
			sqlSb.append("where (b.CREATE_DATE between TO_DATE( ? , 'dd-mon-yyyy hh24:mi:ss') ");
			sqlSb.append("and TO_DATE( ? ,'dd-mon-yyyy hh24:mi:ss')) "); 
			sqlSb.append("and b.event_id=z.event_id (+) "); 
			sqlSb.append("and b.person_id = a.person_id "); 
			sqlSb.append("and b.person_id = d.person_id "); 
			sqlSb.append("and d.SPONSOR_ID= ? ");
			sqlSb.append("and b.kba_supplier_id = c.kba_supplier_id ");
				
        Query query = em.createNativeQuery(sqlSb.toString());            
        
        query.setParameter(1, startDateString);
        query.setParameter(2, endDateString);
        query.setParameter(3, sponsorId);
        
        List<Object[]> results = query.getResultList();
        List<AutomatedTransactionReportVo> list = new ArrayList<>();
        
        if (!results.isEmpty()) {
            for (Object[] row: results) {
                AutomatedTransactionReportVo vo = new AutomatedTransactionReportVo(); 
                
                for (int columnIndex=0; columnIndex<11; columnIndex++) { 
                    switch (columnIndex) { 
                    case 0:
                        if (validateSQLObjectValue(BIG_DECIMAL, row[columnIndex])) { 
                            long personIdLongValue = ((BigDecimal)row[0]).longValue(); 
                            vo.setPersonId(personIdLongValue);
                        }
                        break; 
                    case 1:
                        vo.setCustRegId((String)row[1]);
                        break;         
                    case 2:
                        vo.setEmailAddress((String)row[2]);
                        break; 
                    case 3:
                        vo.setOtpSupplierName((String)row[3]);
                        break; 
                    case 4:
                        vo.setMobilePhoneNumber((String)row[4]);
                        break; 
                    case 5:
                        vo.setTransactionKey((String)row[5]);
                        break; 
                    case 6:
                        vo.setPvOutcome((String)row[6]);
                        break; 
                    case 7:
                        vo.setFinalDecision((String)row[7]);
                        break; 
                    case 8: 
                        if (validateSQLObjectValue(BIG_DECIMAL, row[8])) { 
                            int submitToOtpIntValue = ((BigDecimal)row[8]).intValue();
                            vo.setSubmitOtp(submitToOtpIntValue);
                        }
                        break; 
                    case 9:
                        if (validateSQLObjectValue(BIG_DECIMAL, row[9])) { 
                            int requestNewCodesIntValue = ((BigDecimal)row[9]).intValue(); 
                            vo.setRequestNewCodes(requestNewCodesIntValue); 
                        }
                        break; 
                    case 10:
                        Timestamp createDateTimestamp = (Timestamp)row[10]; 
                        LocalDateTime ldt = createDateTimestamp.toLocalDateTime();
                        String createDateString = ldt.format(queryDateformatter);                 
                        vo.setCreateDate(createDateString);
                        break; 
                    default:
                        break; 
                    }
                          
                }
                
                list.add(vo);
                
            }
        }
        
        return list;
    }    
    
    private boolean validateSQLObjectValue(String dataType, Object o) { 
        try { 
            if (BIG_DECIMAL.equalsIgnoreCase(dataType) && (BigDecimal)o == null) {
            	return false;
            }
        } catch(ClassCastException cce) { 
            return false; 
        }
        return true; 
    }    
 
    @SuppressWarnings("unchecked")
    @Override
    public int getEventCountByApplicationId(long appId) {
        List<Long> result = em.createNamedQuery("RpEvent.getEventCountByApplicationId")
        		.setParameter(APP_ID_PARAM, appId).getResultList();
        if (result != null && !result.isEmpty()) {
            return result.get(0).intValue();
        } else {
            return -1;
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<AuditPersonVo> getAuditPersonList(long sponsorId, String sponsorUserId) { 
        
    	final int PERSON_ID = 0;
    	final int SPONSOR_ID = 1;
    	final int SPONSOR_USER_ID = 2;
    	final int FULL_PERSON_NAME = 3;
    	final int EMAIL_ADDRESS = 4;
    	final int PROOFING_STATUS = 5;
    	final int PROOFING_LEVEL = 6;
    	final int PROOFING_STATUS_DATETIME = 7;
  
    	StringBuilder sqlSb =  new StringBuilder();
        sqlSb.append("SELECT PERSON_ID, SPONSOR_ID, SPONSOR_USER_ID, FULL_PERSON_NAME,");
        sqlSb.append("EMAIL_ADDRESS,PROOFING_STATUS, PROOFING_LEVEL, ");
        sqlSb.append("TO_CHAR(PROOFING_STATUS_DATETIME, 'YYYY-MM-DD HH.MI.SS') PROOFING_STATUS_DATETIME_STR "); 
        sqlSb.append("FROM IPS_OWN.AUDIT_PERSON WHERE SPONSOR_ID = ? AND SPONSOR_USER_ID = ? "); 
        sqlSb.append("ORDER BY PROOFING_STATUS_DATETIME DESC");     
          
        Query query = em.createNativeQuery(sqlSb.toString());             
        query.setParameter(1, sponsorId);
        query.setParameter(2, sponsorUserId);
        
       List<Object[]> results = query.getResultList();
       List<AuditPersonVo> list = new ArrayList<>();
            
        if (!results.isEmpty()) {
            for (Object[] row: results) {
            	AuditPersonVo vo = new AuditPersonVo(); 
                
                for (int columnIndex=0; columnIndex<13; columnIndex++) { 
                    switch (columnIndex) { 
                    case PERSON_ID: 
                    	if (validateSQLObjectValue(BIG_DECIMAL, row[columnIndex])) { 
                    		long longValue = ((BigDecimal)row[columnIndex]).longValue(); 
                    		vo.setPersonId(Long.toString(longValue));
                    	} 
                    	break;
                    case SPONSOR_ID: 
                    	if (validateSQLObjectValue(BIG_DECIMAL, row[columnIndex])) { 
                    		long longValue = ((BigDecimal)row[columnIndex]).longValue(); 
                    		vo.setSponsorId(Long.toString(longValue));
                    	} 
                    	break;
                    case SPONSOR_USER_ID: 
                    	vo.setSponsorUserId((String)row[columnIndex]);
                    	break;
                    case FULL_PERSON_NAME:
                    	vo.setFullPersonName((String)row[columnIndex]);
                    	break;
                    case EMAIL_ADDRESS: 
                    	vo.setEmailAddress((String)row[columnIndex]);
                    	break;
                    case PROOFING_STATUS: 
                    	vo.setProofingStatus((String)row[columnIndex]);
                    	break;
                    case PROOFING_LEVEL: 
                    	vo.setProofingLevel((String)row[columnIndex]);
                    	break;
                    case PROOFING_STATUS_DATETIME: 
                    	vo.setProofingStatusDatetime((String)row[columnIndex]);
                    	break;
                    default:
                        break; 
                    }
                          
                }
                
                list.add(vo);
            }
        }
        
        return list;
    
    }
}
