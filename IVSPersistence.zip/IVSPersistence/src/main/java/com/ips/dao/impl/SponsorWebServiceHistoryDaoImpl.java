package com.ips.dao.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.SponsorWebServiceHistoryDao;
import com.ips.entity.RefSponsor;
import com.ips.entity.SponsorWebServiceHistory;

@Repository
public class SponsorWebServiceHistoryDaoImpl extends GenericJPADAO<SponsorWebServiceHistory, Long> implements SponsorWebServiceHistoryDao{

    @Override
    public void save(SponsorWebServiceHistory history) {
        super.save(history);
    }
    
    @Override
    public void delete(SponsorWebServiceHistory history) {
        super.delete(history);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Retrieve the number of failed web service calls for the sponsor in the date range.
     * @param sponsor
     * @param start
     * @param end
     * @return
     */
    public Long getFailedWebServiceCount(RefSponsor sponsor, Date start, Date end) {
        long queueFailures = 0;
        long historyFailures = 0;
        
        Query queueQuery = em.createNamedQuery("SponsorWebServiceQueue.getQueueFalures");
        queueQuery.setParameter("startDate", start);
        queueQuery.setParameter("endDate", end);
        queueQuery.setParameter("sponsorId", sponsor.getSponsorId());
        
        List<Long> results = queueQuery.getResultList();
        
        if(!results.isEmpty() && (Long)results.get(0)!=null) {
        	queueFailures = ((Long)results.get(0)).longValue();
        }
        
        
        Query historyQuery = em.createNamedQuery("SponsorWebServiceHistory.getHistoryFalures");
        historyQuery.setParameter("startDate", start);
        historyQuery.setParameter("endDate", end);
        historyQuery.setParameter("sponsorId", sponsor.getSponsorId());
        
        results = historyQuery.getResultList();
        
        if (!results.isEmpty() && (Long)results.get(0)!=null) {
            historyFailures = ((Long)results.get(0)).longValue();
        }
        
        return new Long(queueFailures + historyFailures);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Retrieve the number of failed web service calls that succeeded on retry for the sponsor in the date range.
     * @param sponsor
     * @param start
     * @param end
     * @return
     */
    public Long getRetrySucceededCount(RefSponsor sponsor, Date start, Date end) {
        
        Query query = em.createNamedQuery("SponsorWebServiceHistory.getRetrySucceededCount");
        query.setParameter("startDate", start);
        query.setParameter("endDate", end);
        query.setParameter("sponsorId", sponsor.getSponsorId());
        
        List<Long> results = query.getResultList();
        
        if (results.isEmpty() && results.get(0)==null) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Retrieve the number of failed web service calls that caused the Failure confirmation email to be sent
     * for the sponsor in the date range.
     * 
     * @param sponsor
     * @param start
     * @param end
     * @param maxAttempts
     * @return
     */
    public Long getFailedEmailSentCount(RefSponsor sponsor, Date start, Date end, int maxAttempts) {
        
        Query query = em.createNamedQuery("SponsorWebServiceHistory.getFailedEmailCount");
        query.setParameter("startDate", start);
        query.setParameter("endDate", end);
        query.setParameter("sponsorId", sponsor.getSponsorId());
        query.setParameter("maxAttempts", maxAttempts);
        
        List<Long> results = query.getResultList();
        
        if (results.isEmpty() && results.get(0)==null) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    @Override
    public List<SponsorWebServiceHistory> findSponsorWebServiceHistoryBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<SponsorWebServiceHistory> list = em.createNamedQuery("SponsorWebServiceHistory.findSponsorWebServiceHistoryBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
    
}
