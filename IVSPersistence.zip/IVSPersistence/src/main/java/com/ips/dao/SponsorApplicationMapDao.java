package com.ips.dao;

import com.ips.entity.SponsorApplicationMap;
import java.util.List;

public interface SponsorApplicationMapDao {
    public List<SponsorApplicationMap> getRelationsBySponsor(long sponsorId);
    public List<SponsorApplicationMap> getRelationsByApplication(long appId);
    public SponsorApplicationMap getRelationBySponsorAndApplication(long sponsorId, long appId);
    public void create(SponsorApplicationMap entity);
    public void update(SponsorApplicationMap entity);
    public void delete(SponsorApplicationMap entity);
    public List<SponsorApplicationMap> getAllRelations();
}
