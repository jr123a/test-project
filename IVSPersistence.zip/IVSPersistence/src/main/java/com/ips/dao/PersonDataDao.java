package com.ips.dao;

import java.util.Collection;

import com.ips.entity.PersonData;


public interface PersonDataDao {
    
    Collection<PersonData> getAll();    
    PersonData getById(Long id);
    void save(PersonData personData);
    void update(PersonData personData);
    void delete(PersonData personData);    
    PersonData findBySponsorUserId(String sponsorUserId);
}
