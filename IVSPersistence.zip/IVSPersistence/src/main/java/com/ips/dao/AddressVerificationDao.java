package com.ips.dao;

import java.sql.Timestamp;
import java.util.List;

import com.ips.entity.AddressVerification;

public interface AddressVerificationDao {

	void save(AddressVerification av);

	List<AddressVerification> getEventsByCreateDate(Timestamp beforeDate, Timestamp afterDate);

	List<AddressVerification> getAllData();

	void update(AddressVerification av);

}
