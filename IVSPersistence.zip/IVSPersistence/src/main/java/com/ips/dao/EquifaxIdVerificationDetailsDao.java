package com.ips.dao;

import java.util.List;

import com.ips.entity.EquifaxIdVerificationDetails;

public interface EquifaxIdVerificationDetailsDao {
	public void save(EquifaxIdVerificationDetails details);
	public void update(EquifaxIdVerificationDetails details);
	List<EquifaxIdVerificationDetails> getVerificationDetailsForEvent(long eventId);
}
