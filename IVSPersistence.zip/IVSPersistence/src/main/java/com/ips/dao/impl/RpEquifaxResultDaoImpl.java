package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.RpEquifaxResultDao;
import com.ips.entity.RpEquifaxResult;

@Transactional
@Repository
public class RpEquifaxResultDaoImpl extends GenericJPADAO<RpEquifaxResult, Long> implements Serializable, RpEquifaxResultDao{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpEquifaxResult> getAll() {
        Query query = em.createNamedQuery("RpEquifaxResult.findAll");
        return query.getResultList();
    }

    @Override
    public RpEquifaxResult getById(Long id) {        
        return super.getById(id);
    }

    @Override
    public void update(RpEquifaxResult rpEquifaxResult) {
        super.merge(rpEquifaxResult);        
    }
}
