package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import com.ips.dao.ProgramOnlineStatsDao;
import com.ips.entity.ProgramOnlineStats;
import com.ips.entity.RefOtpSupplier;

import org.springframework.stereotype.Repository;

@Repository
public class ProgramOnlineStatsDaoImpl extends GenericJPADAO<ProgramOnlineStats, Long> implements
        ProgramOnlineStatsDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<ProgramOnlineStats> getAll() {
        Query query = em.createNamedQuery("ProgramOnlineStats.findAll");
        return query.getResultList();
    }

    @Override
    public void update(ProgramOnlineStats programOnlineStats) {
        super.merge(programOnlineStats);
    }
    
    @Override
    public ProgramOnlineStats getById(Long id) {        
        return super.getById(id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public ProgramOnlineStats getByOtpSupplier(RefOtpSupplier otpSupplier) {
        Query query = em.createNamedQuery("ProgramOnlineStats.findBySupplier")
                .setParameter("supplierId", otpSupplier);
        List<ProgramOnlineStats> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }
}
