package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpExperianHeaderData;

public interface RpExperianHeaderDataDao {

    Collection<RpExperianHeaderData> getAll();    
    RpExperianHeaderData getById(Long id);
    void create(RpExperianHeaderData entity);
    void update(RpExperianHeaderData entity);
    List<RpExperianHeaderData> getListByResultId(long resultId);
    RpExperianHeaderData getByResultId(long resultId);
    List<RpExperianHeaderData> getListByResultIdRequestType(long resultId, String requestType);
    List<RpExperianHeaderData> getListByClientReferenceId(String clientReferenceId);
    RpExperianHeaderData getByResultIdRequestType(long resultId, String requestType);
}
