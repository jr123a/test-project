package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpExperianHeaderDataDao;
import com.ips.entity.RpExperianHeaderData;

@Repository
public class RpExperianHeaderDataDaoImpl extends GenericJPADAO<RpExperianHeaderData, Long> implements RpExperianHeaderDataDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpExperianHeaderData> getAll() {        
        Query query = em.createNamedQuery("RpExperianHeaderData.getAll");
        return query.getResultList();
    }

    @Override
    public RpExperianHeaderData getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpExperianHeaderData entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpExperianHeaderData entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpExperianHeaderData entity) {
        super.persist(entity);        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpExperianHeaderData> getListByResultId(long resultId) {
        Query query = em.createNamedQuery("RpExperianHeaderData.getListByResultId");
        query.setParameter("resultId", resultId);
        
        return query.getResultList();   
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpExperianHeaderData> getListByClientReferenceId(String clientReferenceId) {
        Query query = em.createNamedQuery("RpExperianHeaderData.getListByClientReferenceId");
        query.setParameter("clientReferenceId", clientReferenceId);
        
        return query.getResultList();   
    } 
     
    @Override
    public RpExperianHeaderData getByResultId(long resultId) {
        List<RpExperianHeaderData> results = getListByResultId(resultId);
        
        return results.isEmpty()? null : results.get(0);    
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpExperianHeaderData> getListByResultIdRequestType(long resultId, String requestType) {
        Query query = em.createNamedQuery("RpExperianHeaderData.getListByResultIdRequestType");
        query.setParameter("resultId", resultId);
        query.setParameter("requestType", requestType);
        
        return query.getResultList();   
    }
     
    @Override
    public RpExperianHeaderData getByResultIdRequestType(long resultId, String requestType) {
        List<RpExperianHeaderData> results = getListByResultIdRequestType(resultId, requestType);
        
        return results.isEmpty()? null : results.get(0);    
    }
}
