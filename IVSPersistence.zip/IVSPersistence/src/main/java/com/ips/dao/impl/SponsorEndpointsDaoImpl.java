package com.ips.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.SponsorEndpointsDao;
import com.ips.entity.SponsorEndpoints;

@Repository
public class SponsorEndpointsDaoImpl extends GenericJPADAO<SponsorEndpoints, Long> implements SponsorEndpointsDao{

    @SuppressWarnings("unchecked")
    @Override
    public SponsorEndpoints getSponsorEndpointByEnv(String env) {
        Query query = em.createNamedQuery("SponsorEndpoints.findByEnvironment");
        query.setParameter("env", env);
        List<SponsorEndpoints> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }
    
    @Override
    public List<SponsorEndpoints> findSponsorEndpointsBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<SponsorEndpoints> list = em.createNamedQuery("SponsorEndpoints.findSponsorEndpointsBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
    
    @Override
    public void save(SponsorEndpoints endpoint) {
        super.save(endpoint);
    }
    
    @Override
    public void delete(SponsorEndpoints endpoint) {
        super.delete(endpoint);
    }

}
