package com.ips.dao;

import java.util.List;

import com.ips.entity.OtpLockoutInfo;
import com.ips.entity.Person;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefLoaLevel;

public interface OtpLockoutInfoDao {
    OtpLockoutInfo getById(Long id);
    void save(OtpLockoutInfo otpLockoutInfo);
    void update(OtpLockoutInfo otpLockoutInfo);
    void delete(OtpLockoutInfo otpLockoutInfo);
    public List<OtpLockoutInfo> findByPersonID(Person person);
    public OtpLockoutInfo findCurrentLockoutForSupplier(Long personId, RefOtpSupplier supplier, RefLoaLevel level);
}
