package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefDeviceConfidence;

public interface RefDeviceConfidenceDao {

    Collection<RefDeviceConfidence> getAll();    
    RefDeviceConfidence getById(Long id);
    RefDeviceConfidence getByReputationAssessment(String reputationAssessment);
    void save(RefDeviceConfidence entity);
    void update(RefDeviceConfidence entity);
    void delete(RefDeviceConfidence entity);
}
