package com.ips.dao.impl;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpOtpAttemptDao;
import com.ips.entity.RpEvent;
import com.ips.entity.RpOtpAttempt;

@Transactional
@Repository
public class RpOtpAttemptDaoImpl extends GenericJPADAO<RpEvent, Long> implements Serializable, RpOtpAttemptDao{    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public List<RpOtpAttempt> getOtpAttemptListInWindow(long personId, Timestamp window, Timestamp currentTime,
            long otpSupplierId, long rpEventId, String attemptType) {
        List<RpOtpAttempt> results = null;
        try {
        	String queryName = "Confirm".equalsIgnoreCase(attemptType) ? 
        			"RpOtpAttempt.getOtpConfirmAttemptListInWindow" : "RpOtpAttempt.getOtpRequestAttemptListInWindow";
            Query query = em.createNamedQuery(queryName)
                    .setParameter("personId", personId)
                    .setParameter("otpSupplierId", otpSupplierId)
                    .setParameter("rpEventId", rpEventId)
                    .setParameter("window", window)
                    .setParameter("currentTime", currentTime);
  
            results = query.getResultList();
        } catch (NoResultException ne) {
            CustomLogger.error(this.getClass(), "Exception occured when querying", ne);
            results = Collections.emptyList();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format("Exception occurred while retrieving the RpOtpAttempt list for personId: %s and otpSupplierId: %s ", personId, otpSupplierId), e);
        }
        
        return results; 
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpOtpAttempt> getOtpRequestAndConfirmAttemptListInWindow(long personId, Timestamp window, Timestamp currentTime,
            long otpSupplierId, long rpEventId) {
        List<RpOtpAttempt> results = null;
        try {
        	String queryName = "RpOtpAttempt.getOtpRequestAndConfirmAttemptListInWindow";
            Query query = em.createNamedQuery(queryName)
                    .setParameter("personId", personId)
                    .setParameter("otpSupplierId", otpSupplierId)
                    .setParameter("rpEventId", rpEventId)
                    .setParameter("window", window)
                    .setParameter("currentTime", currentTime);
  
            results = query.getResultList();
        } catch (NoResultException ne) {
            CustomLogger.error(this.getClass(), "Exception occured when querying", ne);
            results = Collections.emptyList();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format("Exception occurred while retrieving the RpOtpAttempt list for personId: %s and otpSupplierId: %s ", personId, otpSupplierId), e);
        }
        
        return results; 
    }
    
	@SuppressWarnings("unchecked")
	@Override
    public List<RpOtpAttempt> getOtpAttemptListInWindow(long personId, long supplierId, int attemptWindow, long rpEventId) {
		List<RpOtpAttempt> results = null;
        try {
        	StringBuilder sqlSb =  new StringBuilder();	 
			sqlSb.append("SELECT a.* FROM rp_otp_attempts a, rp_event e ");
			sqlSb.append(String.format("WHERE e.event_id = a.event_id AND e.person_id = %s ", personId));
			sqlSb.append(String.format("AND e.kba_supplier_id = %s ", supplierId));
			sqlSb.append(String.format("AND e.event_id = %s ", rpEventId));
			sqlSb.append("AND a.attempt_type_id <> 2 ");
			
			sqlSb.append(String.format("AND e.create_date >= (CURRENT_TIMESTAMP - (%s/24)) ", attemptWindow));
			sqlSb.append("AND e.create_date <= CURRENT_TIMESTAMP ");
			sqlSb.append("ORDER BY a.create_date ");
			
			Query query = em.createNativeQuery(sqlSb.toString());   
			results = query.getResultList();
        } catch (NoResultException ne) {
            CustomLogger.error(this.getClass(), "Exception occured when querying", ne);
            results = Collections.emptyList();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format("Exception occurred while retrieving the RpOtpAttempt list for personId: %s and otpSupplierId: %s ", personId, supplierId), e);
        }

    	return results; 
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpOtpAttempt> getOtpAttemptInTransaction(long personId, long otpSupplierId, String transactionKey, String attemptType) {
        List<RpOtpAttempt> results = null;
        try {
            Query query = em.createNamedQuery("RpOtpAttempt.getOtpAttemptInTransaction")
                    .setParameter("personId", personId)
                    .setParameter("otpSupplierId", otpSupplierId)
                    .setParameter("attemptType", attemptType)
                    .setParameter("transactionKey", transactionKey);
            
            results = query.getResultList();
        } catch (NoResultException ne) {
            results = Collections.emptyList();
            CustomLogger.error(this.getClass(), "Exception occured when querying", ne);
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format("Exception occurred while retrieving the RpOtpAttempt list for personId: %s and otpSupplierId: %s ", personId, otpSupplierId), e);
        }
        
        return results; 
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpOtpAttempt getLatestOtpConfirmAttempt(long personId, long otpSupplierId, long rpEventId) {
    	List<RpOtpAttempt> results = null;
    	RpOtpAttempt attempt = null;
        try {
            Query query = em.createNamedQuery("RpOtpAttempt.getOtpConfirmAttemptList")
                    .setParameter("personId", personId)
                    .setParameter("otpSupplierId", otpSupplierId)
                    .setParameter("rpEventId", rpEventId);

            results = query.getResultList();
            if (results != null && results.size() > 0) {
            	attempt = (RpOtpAttempt) results.get(0);
            }
        } catch (NoResultException ne) {
            CustomLogger.error(this.getClass(), "NoResultException occured when getting Latest OtpConfirmAttempt", ne);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occured when getting Latest OtpConfirmAttempt", e);
        }
        
        return attempt; 
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpOtpAttempt getLatestOtpAttempt(long personId, long otpSupplierId, long rpEventId) {
      	 
    	RpOtpAttempt attempt = null;
        try {
             Query query = em.createNamedQuery("RpOtpAttempt.getOtpRequestAndConfirmAttemptList")
                    .setParameter("personId", personId)
                    .setParameter("otpSupplierId", otpSupplierId)
                    .setParameter("rpEventId", rpEventId);

            List<RpOtpAttempt> results = query.getResultList();

            if (results != null && results.size() > 0) {
            	attempt = (RpOtpAttempt) results.get(0);
            }
        } catch (NoResultException ne) {
            CustomLogger.error(this.getClass(), "NoResultException occured when getting Latest OtpAttempt", ne);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occured when getting Latest OtpAttempt", e);
        }
        
        return attempt; 
    }
}
