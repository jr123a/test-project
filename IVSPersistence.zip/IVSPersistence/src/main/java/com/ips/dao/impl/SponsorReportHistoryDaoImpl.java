package com.ips.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.SponsorReportHistoryDao;
import com.ips.entity.SponsorReportHistory;

@Repository
@Transactional
public class SponsorReportHistoryDaoImpl extends GenericJPADAO<SponsorReportHistory, Long> implements SponsorReportHistoryDao {    

    @Override
    public void update(SponsorReportHistory history) {
        super.merge(history);        
    }
    
    @Override
    public void delete(SponsorReportHistory history) {
        super.delete(history);
    }
    
    @Override
    public SponsorReportHistory getById(Long id) {
        return super.getById(id);
    }
    
    @Override
    public List<SponsorReportHistory> findSponsorReportHistoryBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<SponsorReportHistory> list = em.createNamedQuery("SponsorReportHistory.findSponsorReportHistoryBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
}
