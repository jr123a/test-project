package com.ips.dao.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.SponsorTokensDao;
import com.ips.entity.SponsorTokens;

@Repository
public class SponsorTokensDaoImpl extends GenericJPADAO<SponsorTokens, Long> implements SponsorTokensDao {

    @Override
    public void update(SponsorTokens token) {
        super.merge(token);

    }
    
    @Override
    public void save(SponsorTokens token) {
        super.save(token);
    }
    
    @Override
    public void delete(SponsorTokens token) {
        super.delete(token);
    }

    @SuppressWarnings("unchecked")
    @Override
    public String getToken(Long sponsorId) {
        Query query = em.createNamedQuery("SponsorTokens.getToken");
        query.setParameter("sponsorId", sponsorId);
        List<String> results = query.getResultList();

        if (results.isEmpty()) {
            return null;
        } else {
            return results.get(0).toString();
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public Date getExpiration(Long sponsorId) {
        Query query = em.createNamedQuery("SponsorTokens.getExpiration");
        query.setParameter("sponsorId", sponsorId);
        List<Date> results = query.getResultList();

        if (results.isEmpty()) {
            return null;
        } else {
            return results.get(0);
        }
    }
    
    @Override
    public List<SponsorTokens> findSponsorTokensBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<SponsorTokens> list = em.createNamedQuery("SponsorTokens.findSponsorTokensBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }

}
