package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpSmfaValidateResponse;

public interface RpSmfaValidateResponseDao {

    Collection<RpSmfaValidateResponse> getAll();    
    RpSmfaValidateResponse getById(Long id);
    void create(RpSmfaValidateResponse entity);
    void update(RpSmfaValidateResponse entity);
    List<RpSmfaValidateResponse> getListByPersonId(long personId);
    RpSmfaValidateResponse getByPersonId(long personId);
    RpSmfaValidateResponse getByPersonIdAndSessionId(long personId, String sessionId);
}
