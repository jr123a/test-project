package com.ips.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;

import javax.persistence.NamedQuery;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefSponsorDao;
import com.ips.entity.RefSponsor;

@Repository
@SuppressWarnings("unchecked")
public class RefSponsorDaoImpl extends GenericJPADAO<RefSponsor, Long> implements
        RefSponsorDao,Serializable  {

    private static final long serialVersionUID = 1L;

    @Override
    public Collection<RefSponsor> getAll() {        
        Query query = em.createNamedQuery("RefSponsor.findAll");
        return query.getResultList();
    }
    
    @Override
    public List<RefSponsor> getNonExternalSponsors() {
        return em.createNamedQuery("RefSponsor.findNonExternalSponsors").getResultList();
    }
    
    @Override
    public List<RefSponsor> getAllRemoteProofingClients() {
    	return em.createNamedQuery("RefSponsor.findAllRemoteProofingClients").getResultList();
    }
    
    @Override
    public List<RefSponsor> getIAL2Sponsors(String name) {
        Query query = em.createNamedQuery("RefSponsor.findIAL2Sponsors");
        query.setParameter("name", name);
        return query.getResultList();
    }

    @Override
    public RefSponsor getById(Long id) {        
        return super.getById(id);
    }

    @Override
    public void save(RefSponsor sponsor) {
        super.persist(sponsor);
    }
    
    @Override
    public void update(RefSponsor sponsor) {
        super.merge(sponsor);
    }
    
    @Override
    public void delete(RefSponsor sponsor) {
        super.delete(sponsor);
        
    }

    @Override
    public RefSponsor getBySponsorName(String sponsor) {
        Query query = em.createNamedQuery("RefSponsor.findBySponsorName");
        query.setParameter("sponsor", sponsor);
        List<RefSponsor> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } else {
            return results.get(0);
        }
    }

    @Override
    public RefSponsor findBySponsorId(long sponsorId) {
        Query query = em.createNamedQuery("RefSponsor.findBySponsorId");
        query.setParameter("sponsorId", sponsorId);
        List<RefSponsor> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } else {
            return results.get(0);
        }
    }

    @Override
    public List<RefSponsor> getExternalClients() {
        return em.createNamedQuery("RefSponsor.getExternalClients").getResultList();
    }
    
    @Override
    public List<RefSponsor> findSponsorReceivingReports() {
        return em.createNamedQuery("RefSponsor.findSponsorReceivingReports").getResultList();
    }

    @Override
    public List<RefSponsor> getActiveExternalSponsorList() {
        Query query = em.createNamedQuery("RefSponsor.getActiveExternalClients");
        return query.getResultList();
    }
    
    @Override
    public List<RefSponsor> getActiveInternalSponsorList() {
        return em.createNamedQuery("RefSponsor.getActiveInternalSponsors").getResultList();
    }

    @Override
	public Collection<RefSponsor> getEditableList() {
		String sql = "select rs.sponsor_id from ips_own.ref_sponsor rs where rs.sponsor_id > 2 "
				+ "and rs.sponsor_id not in (select distinct p.sponsor_id from ips_own.ipp_event ie, ips_own.person p where ie.ipp_event_status = 1 " 
				+ "and ie.person_id = p.person_id)";
		Query query = em.createNativeQuery(sql, RefSponsor.class);
		return query.getResultList();
	}
	
	@Override
	public Collection<RefSponsor> getDeletableList() {
		String sql = "select rs.sponsor_id from ips_own.ref_sponsor rs where rs.sponsor_id > 2 "
				+ "and rs.sponsor_id not in (select distinct am.sponsor_id from ips_own.sponsor_application_map am) " 
				+ "and rs.sponsor_id not in (select distinct p.sponsor_id from ips_own.person p where p.sponsor_id > 2)";
		
		Query query = em.createNativeQuery(sql, RefSponsor.class);

		return query.getResultList();
	}
	
	@Override
	public Collection<RefSponsor> getNotModifiableList() {
		String sql = "select distinct p.sponsor_id from ips_own.ipp_event ie, ips_own.person p "
				+ "where ie.ipp_event_status = 1 and ie.person_id = p.person_id";
		
		Query query = em.createNativeQuery(sql, RefSponsor.class);

		return query.getResultList();
	}
	
	@Override
    public boolean isSponsorEditable(Long sponsorId) {
        Query query = em.createNativeQuery("SELECT COUNT(p.sponsor_id) FROM ips_own.ipp_event ie, ips_own.person p " + 
        		"WHERE ie.ipp_event_status = 1 AND ie.person_id = p.person_id AND p.sponsor_id = ?");
        query.setParameter(1, sponsorId);
          
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return true;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue() == 0L;
        }
    }
	
	@Override
    public boolean isSponsorDeletable(Long sponsorId) {
		
		 if (isSponsorNotRegular(sponsorId) && isSponsorNotReferencedInSponsorAppMap(sponsorId) && isSponsorNotReferencedInPerson(sponsorId)) {
			 return true;
		 }
		 
		 return false;
    }
	
	@Override
    public boolean isSponsorNotRegular(Long sponsorId) {
        Query query = em.createNativeQuery("SELECT COUNT(rs.sponsor_id) FROM ips_own.ref_sponsor rs " +
        		"WHERE rs.sponsor_id > 2 AND rs.sponsor_id = ?");
        query.setParameter(1, sponsorId);
          
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return false;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue() > 0L;
        }
    }
    
	@Override
    public boolean isSponsorNotReferencedInSponsorAppMap(Long sponsorId) {
        Query query = em.createNativeQuery("SELECT COUNT(rs.sponsor_id) FROM ips_own.ref_sponsor rs " + 
        		"WHERE rs.sponsor_id NOT IN (SELECT DISTINCT am.sponsor_id " +
        		"FROM ips_own.sponsor_application_map am) AND rs.sponsor_id = ?");
        query.setParameter(1, sponsorId);
          
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return false;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue() > 0L;
        }
    }
    
	@Override
    public boolean isSponsorNotReferencedInPerson(Long sponsorId) {
        Query query = em.createNativeQuery("SELECT COUNT(rs.sponsor_id) FROM ips_own.ref_sponsor rs " + 
        		"WHERE rs.sponsor_id NOT IN (SELECT DISTINCT p.sponsor_id FROM ips_own.person p WHERE p.sponsor_id > 2) AND rs.sponsor_id = ?");
        query.setParameter(1, sponsorId);
          
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return false;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue() > 0L;
        }
    }
	
}
