package com.ips.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.ips.entity.IppEvent;
import com.ips.entity.Person;
import com.ips.entity.RefIppApplications;
import com.ips.entity.RefIppEventStatus;
import com.ips.entity.RefIppFailureReason;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefSponsor;
import com.ips.persistence.common.FacilityTransactionReportVo;
import com.ips.persistence.common.IndividualTransactionReportVo;


public interface IppEventDao {

    Collection<IppEvent> getAll();    
    IppEvent getById(Long id);
    void save(IppEvent ippEvent);
    void update(IppEvent ippEvent);
    void delete(IppEvent ippEvent);
    IppEvent findByRecordLocator(String recordLocator);
    IppEvent findConfirmationNumber(RefIppEventStatus ippEventStatus, Person person);
    IppEvent findAppointment(RefIppEventStatus ippEventStatus, long personId);
    IppEvent findByStatus(RefIppEventStatus ippEventStatus, Person person);
    List<IppEvent> findAllIppEventsAtResidence(String inPersonProofingType, Date appointmentDate);
    List<IppEvent> validationQuery();
    Long getIPPOptInCount(Date start, Date end);
    Long getIPPStatusCount(RefIppEventStatus ippEventStatus, Date start, Date end);
    Long getIPPFlaggedAsFraudCount(Date start, Date end);
    List<BigDecimal> getFacilityIdsForCompletedEvents(Date start, Date end);
    List<String> findMonthsForEventsWithNoFacility();
    List<IppEvent> findEventsWithNoFacilityByMonth(Date start, Date end, int firstResult, int maxResults);
    Long getEventsWithNoFacilityCountByMonth(Date start, Date end);
    Long getIPPStatusCountByLevel(RefIppEventStatus ippEventStatus, Date start, Date end, RefLoaLevel loa);
    Long getIPPFlaggedAsFraudCountByLevel(Date start, Date end, RefLoaLevel loa);
    Collection<RefIppFailureReason> getIppFailureReasons(Date start, Date end, RefLoaLevel loa);
    Long getReasonCodeCount(Date start, Date end, String reasonCode, RefLoaLevel loa);
    Long getIPPOptInCountByLevel(Date start, Date end, String loaLevel);
    List<IppEvent> getReminderEvents(RefSponsor sponsor, RefIppEventStatus ippEventStatus, Date start, Date end);
    RefIppApplications findByApplicationAcronym(String appAcronym);
    Long getIPPStatusCountBySponsor(RefIppEventStatus ippEventStatus, Date start, Date end, RefSponsor sponsor);
    void getIPPFacilityTransactionCounts(long sponsorId, Date start, Date end, boolean daily, List<FacilityTransactionReportVo> list);
    List<IndividualTransactionReportVo> getIPPIndividualTransactions(long sponsorId, Date start, Date end);
    List<IppEvent> findNewEventsForSponsor(Date start, Date end, RefSponsor sponsor, RefIppEventStatus ippEventStatus);
    Long getOptInCountBySponsor(RefSponsor sponsor, Date start, Date end);
    Long getPolicyResultCountBySponsor(RefIppEventStatus proofingResult, RefSponsor sponsor, Date start, Date end);
    Long getPrimaryIdUsedCountByIdType(long idType);
    Long getSecondaryIdUsedCountByIdType(long idType);
    public int getEventCountByApplicationId(long appId);
    List<IppEvent> getEventsByTransactionEndDate(Timestamp beforeDate, Timestamp afterDate);
    public int getEventCountWithStartStatusBySponsor(long sponsorId);
	IppEvent refreshIPPEvent(IppEvent entity);
}
