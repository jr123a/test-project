package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefIppFailureReason;


public interface RefIppFailureReasonDao {

    Collection<RefIppFailureReason> getAll();    
    RefIppFailureReason getById(Long id);
    void save(RefIppFailureReason entity);
    void update(RefIppFailureReason entity);
    void delete(RefIppFailureReason entity);    
}
