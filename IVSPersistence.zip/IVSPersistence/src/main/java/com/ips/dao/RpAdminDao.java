package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpAdmin;

public interface RpAdminDao {

    Collection<RpAdmin> getAll();    
    RpAdmin getById(String id);
    void save(RpAdmin rpAdmin);
    void update(RpAdmin rpAdmin);
    void delete(RpAdmin rpAdmin);
    String getAuditEventDescription(String userId);
    List<RpAdmin> findRpAdminBySponsor(long sponsorId);
}
