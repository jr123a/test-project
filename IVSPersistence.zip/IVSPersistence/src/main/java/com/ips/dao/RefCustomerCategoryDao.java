package com.ips.dao;

import com.ips.entity.RefCustomerCategory;

import java.util.Collection;

public interface RefCustomerCategoryDao {
    Collection<RefCustomerCategory> getAll();
    
    RefCustomerCategory getById(Long id);
    void save(RefCustomerCategory customerCategory);
    void update(RefCustomerCategory customerCategory);
    void delete(RefCustomerCategory customerCategory);
    
}
