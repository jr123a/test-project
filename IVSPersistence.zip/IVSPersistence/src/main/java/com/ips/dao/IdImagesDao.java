package com.ips.dao;

import com.ips.entity.IdImages;

	public interface IdImagesDao {
		IdImages findIdImagesByippEventIdandIdType(Long ippEventId,Long idType, Long idNumber);
		IdImages findIdImagesByippEventIdandIdNumber(Long ippEventId, Long idNumber);
	    public void save(IdImages request);
	    public void update(IdImages request);
	}

