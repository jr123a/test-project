package com.ips.dao.impl;

import javax.persistence.Query;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ips.dao.OtpLockoutInfoDao;
import com.ips.entity.OtpLockoutInfo;
import com.ips.entity.Person;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefLoaLevel;

@Repository
public class OtpLockoutInfoDaoImpl extends GenericJPADAO<OtpLockoutInfo, Long> implements
    OtpLockoutInfoDao {

    @Override
    public OtpLockoutInfo getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void update(OtpLockoutInfo otpLockoutInfo) {
        super.merge(otpLockoutInfo);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<OtpLockoutInfo> findByPersonID(Person person) {
        Query query = em.createNamedQuery("OtpLockoutInfo.findByPersonID");
        query.setParameter("personid", person);
        return query.getResultList();
    }

    public OtpLockoutInfo findCurrentLockoutForSupplier(Long personId, RefOtpSupplier supplier, RefLoaLevel level) {
        Query query = em.createNamedQuery("OtpLockoutInfo.findCurrentLockoutForSupplier");
        query.setParameter("personid", personId);
        query.setParameter("supplier", supplier);
        query.setParameter("loaLevel", level);
        
        @SuppressWarnings("unchecked")
        List<OtpLockoutInfo> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return (OtpLockoutInfo) results.get(0);
        }
    }
}
