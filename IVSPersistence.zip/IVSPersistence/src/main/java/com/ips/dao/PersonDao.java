package com.ips.dao;

import java.util.Collection;
import java.util.Date;

import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefSponsor;
import com.ips.persistence.common.UserVo;


public interface PersonDao {

    Collection<Person> getAll();    
    Person getById(Long id);
    void save(Person person);
    void update(Person person);
    void delete(Person person);
    Person findByUid(String uid);
    String getPIN(String sponsorUserId);
    Collection<PersonProofingStatus> findUnusedCredentials(RefLoaLevel loa, Date eighteenMonthsAgo);
    Person findFirstBySponsor(RefSponsor refSponsor, String sponsorUserId);
    Collection<UserVo> findByNameAndEmail(String firstName, String lastName, String email);
    int getPersonCountBySponsor(long sponsorId);
}
