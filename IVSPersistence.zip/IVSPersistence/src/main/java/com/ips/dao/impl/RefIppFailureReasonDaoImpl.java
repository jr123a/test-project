package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefIppFailureReasonDao;
import com.ips.entity.RefIppFailureReason;

@Repository
public class RefIppFailureReasonDaoImpl extends GenericJPADAO<RefIppFailureReason, Long> implements
        RefIppFailureReasonDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefIppFailureReason> getAll() {        
        Query query = em.createNamedQuery("RefIppFailureReason.findAll");
        return query.getResultList();
    }

    @Override
    public RefIppFailureReason getById(Long id) {        
        return super.getById(id);
    }

    @Override
    public void update(RefIppFailureReason entity) {
        super.merge(entity);
    }

}
