package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RefAdminEventDao;
import com.ips.entity.RefAdminEvent;

@Repository
public class RefAdminEventDaoImpl extends GenericJPADAO<RefAdminEvent, Long> implements
        RefAdminEventDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefAdminEvent> getAll() {
        Query query = em.createNamedQuery("RefAdminEvent.findAll");
        return query.getResultList();
    }

    @Override
    public RefAdminEvent getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void update(RefAdminEvent refAdminEvent) {
        try {
            super.merge(refAdminEvent);
            em.flush();
         } catch (PersistenceException pe) {
             CustomLogger.error(this.getClass(), "Error in merging RefAdminEvent entity.  ", pe);
        }
    }

    @Override
    public RefAdminEvent getByDescription(String eventDescription) {
        Query query = em.createNamedQuery("RefAdminEvent.findByDescription");
        query.setParameter("description", eventDescription);
        @SuppressWarnings("unchecked")
        List<RefAdminEvent> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }

}
