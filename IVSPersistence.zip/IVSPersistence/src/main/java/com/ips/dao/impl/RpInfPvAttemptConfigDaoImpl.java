package com.ips.dao.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RpInfPvAttemptConfigDao;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RpInfPvAttemptConfig;
import com.ips.entity.RpInfPvAttemptConfigPK;

@Repository
public class RpInfPvAttemptConfigDaoImpl extends GenericJPADAO<RpInfPvAttemptConfig, Long> implements
RpInfPvAttemptConfigDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpInfPvAttemptConfig> getAll() {
        Query query = em.createNamedQuery("RpInfPvAttemptConfig.findAll");
        return query.getResultList();
    }

    @Override
    public RpInfPvAttemptConfig getById(RpInfPvAttemptConfigPK id) {
        return super.getById(id);
    }

    @Override
    public void save(RpInfPvAttemptConfig infPvAttemptConfig) {
        super.save(infPvAttemptConfig);
    }
    
    @Override
    public void update(RpInfPvAttemptConfig infPvAttemptConfig) {
        super.merge(infPvAttemptConfig);
    }
    
    @Override
    public void delete(RpInfPvAttemptConfig infPvAttemptConfig) {
        super.delete(infPvAttemptConfig);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RpInfPvAttemptConfig> getByProofingLevel(long proofingLevel, long sponsorId) {
        List<Long> otpSupplierIds = new ArrayList<>();
        otpSupplierIds.add(RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID);
        otpSupplierIds.add(RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID);
        otpSupplierIds.add(RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID);
        otpSupplierIds.add(RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID);
 
        Query query = em.createNamedQuery("RpInfPvAttemptConfig.findByProofingLevel");
        query.setParameter("proofingLevel", proofingLevel);
        query.setParameter("sponsorId", sponsorId);
        query.setParameter("otpSupplierIds", otpSupplierIds);
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpInfPvAttemptConfig> getByProofingLevelSorted(List<Long> otpSupplierIds, long proofingLevel, long sponsorId) {       
        Query query = em.createNamedQuery("RpInfPvAttemptConfig.findByProofingLevelSorted");
        query.setParameter("proofingLevel", proofingLevel);
        query.setParameter("sponsorId", sponsorId);
        query.setParameter("otpSupplierIds", otpSupplierIds);
        
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpInfPvAttemptConfig> findRowsForReset() {
        Query query = em.createNativeQuery("SELECT * FROM rp_inf_pv_attempts WHERE attempts >= total_attempts * 2 " +
                "AND attempts <> 0 FOR UPDATE", 
                RpInfPvAttemptConfig.class);
    
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public RpInfPvAttemptConfig findByPrimaryKey(long proofingLevel, long sponsorId, long otpSupplierId) {
         
        Query query = em.createNamedQuery("RpInfPvAttemptConfig.findByPrimaryKey");
        query.setParameter("proofingLevel", proofingLevel);
        query.setParameter("sponsorId", sponsorId);
        query.setParameter("otpSupplierId", otpSupplierId);
        
        List<RpInfPvAttemptConfig> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);
    }

}
