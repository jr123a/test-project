package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefAttributeGroupDao;
import com.ips.entity.RefAttributeGroup;
import com.ips.entity.RefAttributeGroupPK;

@Repository
public class RefAttributeGroupDaoImpl extends GenericJPADAO<RefAttributeGroup, Long> implements
        RefAttributeGroupDao,Serializable  {

    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefAttributeGroup> getAll() {
//        em = getEntityManager();
        Query query = em.createNamedQuery("RefAttributeGroup.findAll");
        return query.getResultList();
    }

    @Override
    public RefAttributeGroup getById(RefAttributeGroupPK id) {
        return super.getById(id);
    }
    
    @Override
    public void update(RefAttributeGroup level) {
        super.merge(level);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RefAttributeGroup> findByIndex(short attrIndex) {
        Query query = em.createNamedQuery("RefAttributeGroup.findByIndex");
        query.setParameter("attrIndex", attrIndex);
        List<RefAttributeGroup> results = query.getResultList();
        
        if (results.isEmpty()) {
            return Collections.emptyList();
        } else {
            return results;
        }
    }
    
}
