package com.ips.dao;

import java.util.Date;
import java.util.List;

import com.ips.entity.SponsorFacilities;

public interface SponsorFacilitiesDao {
    List<SponsorFacilities> getActiveFacilitiesBySponsorId(Long sponsorId);
    List<String> getActiveFacilitiesIdsBySponsorId(Long sponsorId, Integer firstResultCount, Integer maxResultCount);
    List<String> getActiveFacilitiesIdsBySponsorId(Long sponsorId);
    SponsorFacilities getFacilityBySponsorIdAndFacilityId(Long sponsorId, Long refFacId);
    long getActiveFacilitiesCountBySponsorId(Long sponsorId);
    void save(SponsorFacilities spFacility);
    void update(SponsorFacilities spFacility);
    void delete(SponsorFacilities spFacility);
    int deactivateAll(Date activationDate);
    List<SponsorFacilities> findSponsorFacilitiesBySponsor(long sponsorId);
}
