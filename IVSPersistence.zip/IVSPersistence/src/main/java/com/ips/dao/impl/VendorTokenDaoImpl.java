package com.ips.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.VendorTokenDao;
import com.ips.entity.VendorToken;


@Repository
public class VendorTokenDaoImpl extends GenericJPADAO<VendorToken, Long> implements
    VendorTokenDao,Serializable  {
    
    private static final long serialVersionUID = 1L;
    
    @Override
    public void save(VendorToken token) {
        super.save(token);
    }

    @Override
    public void update(VendorToken token) {
        super.merge(token);
    }

    @SuppressWarnings("unchecked")
    @Override
    public VendorToken getByType(String type) {
        Query query = em.createNamedQuery("VendorToken.findByType");
        query.setParameter("type", type);
        List<VendorToken> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }        
    }

}

