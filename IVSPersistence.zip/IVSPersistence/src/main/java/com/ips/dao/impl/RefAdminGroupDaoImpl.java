package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefAdminGroupDao;
import com.ips.entity.RefAdminGroup;

@Repository
public class RefAdminGroupDaoImpl extends GenericJPADAO<RefAdminGroup, Long> implements
        RefAdminGroupDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefAdminGroup> getAll() {        
        Query query = em.createNamedQuery("RefAdminGroup.findAll");
        return query.getResultList();
    }

    @Override
    public RefAdminGroup getById(Long id) {        
        return super.getById(id);
    }

    @Override
    public void save(RefAdminGroup group) {        
        super.save(group);
    }

    @Override
    public void update(RefAdminGroup group) {        
        super.merge(group);
    }

    @Override
    public void delete(RefAdminGroup group) {
        super.delete(group);
    }

    @Override
    @SuppressWarnings("unchecked")
    public RefAdminGroup findByGroupName(String name) {
        Query query = em.createNamedQuery("RefAdminGroup.findByGroupName").setParameter("name", name);
        
        List<RefAdminGroup> results = query.getResultList();    
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }

}
