package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefRelyingParty;


public interface RefRelyingPartyDao {

    Collection<RefRelyingParty> getAll();    
    RefRelyingParty getById(Long id);
    void save(RefRelyingParty status);
    void update(RefRelyingParty status);
    void delete(RefRelyingParty status);
    RefRelyingParty findByAcronym(String acronym);
}
