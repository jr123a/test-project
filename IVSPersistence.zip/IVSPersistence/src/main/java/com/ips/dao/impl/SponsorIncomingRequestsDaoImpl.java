package com.ips.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.SponsorIncomingRequestsDao;
import com.ips.entity.SponsorIncomingRequests;

@Repository
@Transactional
public class SponsorIncomingRequestsDaoImpl extends GenericJPADAO<SponsorIncomingRequests, Long> implements SponsorIncomingRequestsDao {
    @Override
    public void create(SponsorIncomingRequests entity) {
        super.save(entity);
        //this.em.flush();  
    }

    @Override
    public void update(SponsorIncomingRequests entity) {
        super.merge(entity);
    }
    
    @Override
    public void delete(SponsorIncomingRequests entity) {
        super.delete(entity);
    }

    @SuppressWarnings("unchecked")
    @Override
    public SponsorIncomingRequests findBySponsorAndRequestId(long sponsorId, String requestId) {
        List<SponsorIncomingRequests> request = em.createNamedQuery("SponsorIncomingRequests.findBySponsorAndRequestId")
                                                   .setParameter("sponsorId", sponsorId).setParameter("requestId", requestId)
                                                   .getResultList();
        return request.isEmpty() ? null : request.get(0);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public int findCountBySponsorIdAndRequestIdAndEndpointName(long sponsorId, String requestId, String endpointName) {
        List<Long> count = em.createNamedQuery("SponsorIncomingRequests.findCountBySponsorIdAndRequestIdAndEndpointName")
                             .setParameter("sponsorId", sponsorId).setParameter("requestId", requestId).setParameter("endpointName", endpointName)
                             .getResultList();
        return count.isEmpty() ? 0 : count.get(0).intValue();
    }
    
    @Override
    public List<SponsorIncomingRequests> findSponsorIncomingRequestsBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<SponsorIncomingRequests> list = em.createNamedQuery("SponsorIncomingRequests.findSponsorIncomingRequestsBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }

}
