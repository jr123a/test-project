package com.ips.dao;

import java.util.Date;
import java.util.List;

import com.ips.entity.RefSponsor;
import com.ips.entity.SponsorWebServiceHistory;

public interface SponsorWebServiceHistoryDao {

    void save(SponsorWebServiceHistory history);
    void delete(SponsorWebServiceHistory history);
    Long getFailedWebServiceCount(RefSponsor sponsor, Date start, Date end);
    Long getRetrySucceededCount(RefSponsor sponsor, Date start, Date end);
    Long getFailedEmailSentCount(RefSponsor sponsor, Date start, Date end, int maxAttempts);
    List<SponsorWebServiceHistory> findSponsorWebServiceHistoryBySponsor(long sponsorId);
}
