package com.ips.dao.impl;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.ReportDao;
import com.ips.entity.ReportExecuted;

@Repository
public class ReportDaoImpl extends GenericJPADAO<ReportExecuted, Long> implements ReportDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<ReportExecuted> getAll() {
        Query query = em.createNamedQuery("ReportExecuted.findAll");
        return query.getResultList();
    }
    
    @Override
    public ReportExecuted getById(String id) {
        return super.getById(id);
    }

    @Override
    public void update(ReportExecuted reportExecuted) {
        super.merge(reportExecuted);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ReportExecuted> findReports(String reportName, Date executionDate) {
        Query query = em.createNativeQuery("SELECT * FROM report_executed WHERE report_name = ? AND " +
                "(last_date_executed <= ? OR last_date_executed IS NULL) FOR UPDATE", ReportExecuted.class);
        
        query.setParameter(1, reportName);
        query.setParameter(2, executionDate);
        return query.getResultList();
    }
}
