package com.ips.dao.impl;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.SponsorFacilitiesDao;
import com.ips.entity.SponsorFacilities;

@Repository
public class SponsorFacilitiesDaoImpl extends GenericJPADAO<SponsorFacilities, Long> implements SponsorFacilitiesDao {
    @SuppressWarnings("unchecked")
    @Override
    public List<SponsorFacilities> getActiveFacilitiesBySponsorId(Long sponsorId) {
        Query query = em.createNamedQuery("SponsorFacilities.findActiveFacilitiesBySponsorId").setParameter("sponsorId", sponsorId);
        List<SponsorFacilities> results = query.getResultList();
        return (List<SponsorFacilities>) (results.isEmpty() ? Collections.emptyList() : results);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<String> getActiveFacilitiesIdsBySponsorId(Long sponsorId, Integer firstResultCount, Integer maxResultCount) {
        Query query = em.createNamedQuery("SponsorFacilities.findActiveFacilitiesIdsBySponsorId").setParameter("sponsorId", sponsorId);
        query.setFirstResult(firstResultCount != null && firstResultCount >= 0 ? firstResultCount : 0);
        query.setMaxResults(maxResultCount != null && maxResultCount > 0 ? maxResultCount : Integer.MAX_VALUE);
        List<String> results = query.getResultList();
        return (List<String>) (results.isEmpty() ? Collections.emptyList() : results);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<String> getActiveFacilitiesIdsBySponsorId(Long sponsorId) {
        Query query = em.createNamedQuery("SponsorFacilities.findActiveFacilitiesIdsBySponsorId").setParameter("sponsorId", sponsorId);
        List<String> results = query.getResultList();
        return results;
    }
    
    @Override
    public SponsorFacilities getFacilityBySponsorIdAndFacilityId(Long sponsorId, Long refFacId) {
        Query query = em.createNamedQuery("SponsorFacilities.findFacilitybySponsorIdAndFacilityId").setParameter("sponsorId", sponsorId).setParameter("facilityId", refFacId);
        return query.getResultList().isEmpty() ? null : (SponsorFacilities) query.getResultList().get(0);
    }
    
    @Override
    public int deactivateAll(Date activationDate) {
        return em.createNamedQuery("SponsorFacilities.deactivateAll").setParameter("activationDate", activationDate).executeUpdate();
    }
    
    @Override
    public void save(SponsorFacilities spFacility) {
        super.save(spFacility);
    }
    
    @Override
    public void update(SponsorFacilities spFacility) {
        super.merge(spFacility);
    }
    
    @Override
    public void delete(SponsorFacilities spFacility) {
        super.delete(spFacility);
    }
    
    @Override
    public long getActiveFacilitiesCountBySponsorId(Long sponsorId) {
        return (long) em.createNamedQuery("SponsorFacilities.getActiveFacilitiesCountBySponsorId").setParameter("sponsorId", sponsorId).getSingleResult();
    }
    
    @Override
    public List<SponsorFacilities> findSponsorFacilitiesBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<SponsorFacilities> list = em.createNamedQuery("SponsorFacilities.findSponsorFacilitiesBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
}
