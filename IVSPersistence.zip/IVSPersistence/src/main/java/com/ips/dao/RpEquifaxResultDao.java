package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RpEquifaxResult;

public interface RpEquifaxResultDao {

    Collection<RpEquifaxResult> getAll();
    RpEquifaxResult getById(Long id);
    void save(RpEquifaxResult rpEquifaxResult);
    void update(RpEquifaxResult rpEquifaxResult);
    void delete(RpEquifaxResult rpEquifaxResult);
}
