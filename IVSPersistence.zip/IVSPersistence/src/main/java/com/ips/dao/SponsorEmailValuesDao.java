package com.ips.dao;

import java.util.List;

import com.ips.entity.SponsorEmailValues;

public interface SponsorEmailValuesDao {
    SponsorEmailValues getEmailBySponsorIdAndEmailType(Long id, Long emailType);
    void update(SponsorEmailValues entity);
    void create(SponsorEmailValues entity);
    void delete(SponsorEmailValues entity);
    List<SponsorEmailValues> findSponsorEmailValuesBySponsor(long sponsorId);
}