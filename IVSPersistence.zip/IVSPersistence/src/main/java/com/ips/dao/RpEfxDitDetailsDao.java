package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpEfxDitDetails;

public interface RpEfxDitDetailsDao {

    Collection<RpEfxDitDetails> getAll();    
    RpEfxDitDetails getById(Long id);
    void create(RpEfxDitDetails entity);
    void update(RpEfxDitDetails entity);
    List<RpEfxDitDetails> getListByPersonId(long personId);
    RpEfxDitDetails getByPersonId(long personId);
}
