package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefRpStatus;


public interface RefRpStatusDao {

    Collection<RefRpStatus> getAll();    
    RefRpStatus getById(Long id);
    void save(RefRpStatus status);
    void update(RefRpStatus status);
    void delete(RefRpStatus status);
    RefRpStatus findByDescription(String statusDesc);
}
