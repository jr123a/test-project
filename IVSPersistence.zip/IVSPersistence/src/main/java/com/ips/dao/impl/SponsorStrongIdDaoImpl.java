package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.SponsorStrongIdDao;
import com.ips.entity.SponsorStrongId;
import com.ips.entity.SponsorStrongIdPK;

@Repository
@SuppressWarnings("unchecked")
public class SponsorStrongIdDaoImpl extends GenericJPADAO<SponsorStrongId, SponsorStrongIdPK> implements
        SponsorStrongIdDao, Serializable  {

    private static final long serialVersionUID = 1L;

    @Override
    public Collection<SponsorStrongId> getAll() {        
        Query query = em.createNamedQuery("SponsorStrongId.findAll");
        return query.getResultList();
    }

    @Override
    public Collection<SponsorStrongId> getListBySponsorId(Long sponsorId) {        
        Query query = em.createNamedQuery("SponsorStrongId.findBySponsor").setParameter("sponsorId", sponsorId);
        return query.getResultList();
    }
    
    @Override
    public SponsorStrongId create(SponsorStrongId entity) {
        super.save(entity);
        return entity;
    }
    
    @Override
    public void remove(Long sponsorId, Long idType) {
        SponsorStrongId entity = getByPK(sponsorId, idType);
        super.delete(entity);
    }
    
    @Override
    public void delete(SponsorStrongId entity) {
        super.delete(entity);
    }
    
    @Override
    public SponsorStrongId getByPK(Long sponsorId, Long idType) {
        Query query = em.createNamedQuery("SponsorStrongId.findByPrimaryKey");
            query.setParameter("sponsorId", sponsorId);
            query.setParameter("idType", idType);
            
            if (query.getResultList() != null) {
                return (SponsorStrongId) query.getResultList().get(0);
            }
        return null;
    }

    @Override
    public long getPrimaryIdCountForSponsor(long idType) {
        Query query = em.createNamedQuery("SponsorStrongId.getPrimaryIdCountForSponsor");
        query.setParameter("idType", idType);
        List<Long> results = query.getResultList();
        if (results.isEmpty()) {
            return 0L;
        } else {
            return results.get(0);
        }
    }

    @Override
    public List<SponsorStrongId> findSponsorStrongIdBySponsor(long sponsorId) {
 		List<SponsorStrongId> list = em.createNamedQuery("SponsorStrongId.findSponsorStrongIdBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
    
}
