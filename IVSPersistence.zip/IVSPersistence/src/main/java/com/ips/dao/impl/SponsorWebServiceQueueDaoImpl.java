package com.ips.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.SponsorWebServiceQueueDao;
import com.ips.entity.SponsorWebServiceQueue;

@Repository
public class SponsorWebServiceQueueDaoImpl extends GenericJPADAO<SponsorWebServiceQueue, Long> implements SponsorWebServiceQueueDao{

    @SuppressWarnings("unchecked")
	@Override
    public SponsorWebServiceQueue getQueue(String enrollmentCode) {
        Query query = em.createNamedQuery("SponsorWebServiceQueue.getQueue");
        query.setParameter("enrollmentCode", enrollmentCode);
        List<SponsorWebServiceQueue> results = query.getResultList();

        if (results.isEmpty()) {
            return null;
        } else {
            return results.get(0);
        }
    }

    @Override
    public void save(SponsorWebServiceQueue queue) {
        super.save(queue);
    }
    
    @Override
    public void update(SponsorWebServiceQueue queue) {
        super.merge(queue);
        
    }
    
    @Override
    public void delete(SponsorWebServiceQueue queue) {
        super.delete(queue);
    }
    
    @Override
    public List<SponsorWebServiceQueue> findSponsorWebServiceQueueBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<SponsorWebServiceQueue> list = em.createNamedQuery("SponsorWebServiceQueue.findSponsorWebServiceQueueBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
    
}
