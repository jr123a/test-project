package com.ips.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefIAL2ConfirmationNotificationDao;
import com.ips.entity.RefIAL2ConfirmationNotification;

@Repository
public class RefIAL2ConfirmationNotificationDaoImpl extends GenericJPADAO<RefIAL2ConfirmationNotification, Long> implements RefIAL2ConfirmationNotificationDao {
    @SuppressWarnings("unchecked")
    @Override
    public List<RefIAL2ConfirmationNotification> findAll() {
        return em.createNamedQuery("RefIAL2ConfirmationNotification.findAll").getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public RefIAL2ConfirmationNotification findById(long id) {
        List<RefIAL2ConfirmationNotification> list = em.createNamedQuery("RefIAL2ConfirmationNotification.findById").setParameter("id", id).getResultList();
        return list != null && !list.isEmpty() ? list.get(0) : null;
    }
}
