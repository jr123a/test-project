package com.ips.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.PersonDao;
import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefSponsor;
import com.ips.persistence.common.UserVo;

@Repository
public class PersonDaoImpl extends GenericJPADAO<Person, Long> implements PersonDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<Person> getAll() {        
        Query query = em.createNamedQuery("Person.findAll");
        return query.getResultList();
    }

    @Override
    public Person getById(Long id) {        
        return super.getById(id);
    }

    @Override
    public void update(Person person) {        
        super.merge(person);
    }

    @Override
    public Person findByUid(String uid) {
        Query query = em.createNamedQuery("Person.findByUID");
        query.setParameter("uid", uid);
        
        @SuppressWarnings("unchecked")
        List<Person> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }

    @Override
    public String getPIN(String sponsorUserId) {
        Query query = em.createNativeQuery("select DE_CRYPT(PIN) from PERSON where SPONSOR_USER_ID = ?");
        query.setParameter(1, sponsorUserId);
        @SuppressWarnings("unchecked")
        List<String> results = query.getResultList();
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }
    
    @Override
    public List<PersonProofingStatus> findUnusedCredentials(RefLoaLevel loa, Date eighteenMonthsAgo) {
        Query query = em.createNamedQuery("PersonProofingStatus.findUnusedCredentials");
        query.setParameter("loaLevel", loa);
        query.setParameter("eighteenMonthsAgo", eighteenMonthsAgo);
        
        @SuppressWarnings("unchecked")
        List<PersonProofingStatus> results = query.getResultList();
        return results;
    }
    
    @Override
    /**
     * Retrieves the first person record for the sponsor user id (i.e., the one with the lowest person id).
     */
    public Person findFirstBySponsor(RefSponsor refSponsor, String sponsorUserId) {
        // Tried using a correlated subquery here but the performance was very poor.
        // Retrieve the min person id and then retrieve the person record.
        
        Query query = em.createNativeQuery("select MIN(person_id) from PERSON " +
                "where SPONSOR_USER_ID = ? and SPONSOR_ID = ?");
        
        query.setParameter(1, sponsorUserId);
        query.setParameter(2, refSponsor.getSponsorId());
        
        @SuppressWarnings("unchecked")
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty() || results.get(0) == null) {
            return null;
        } else {
            BigDecimal id = results.get(0);
            Long personId = id.longValue();
            return this.getById(personId);
        }
    }
    
    @SuppressWarnings("unchecked")
	@Override
    public Collection<UserVo> findByNameAndEmail(String firstName, String lastName, String email) {
   	
  	String sql = "select p.sponsor_user_id, pd.last_name, pd.first_name from ips_own.person p "
  		  	+  "inner join ips_own.person_data pd on pd.person_id = p.person_id where p.person_id in "
  		  	+ "(select person_id from ips_own.person_data where upper(first_name) like ('%" + firstName.toUpperCase() + "%') " 
    		+ "and upper(last_name) like ('%" + lastName.toUpperCase() + "%') "
    		+ "and upper(email_address) like ('%" + email.toUpperCase() + "%'))";
  	
    	Query query = em.createNativeQuery(sql);
     	List<Object[]> resultList = query.getResultList();
    	ArrayList<UserVo> list = new ArrayList<>();
    	
    	for (Object[] item : resultList) {
    		UserVo user = new UserVo();
    		user.setSponsorUserId((String) item[0]);
       	 	user.setFirstName((String) item[1]);
       	 	user.setLastName((String) item[2]);
       	 	list.add(user);
        }
    	
    	return list;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public int getPersonCountBySponsor(long sponsorId) {
        List<Long> results = em.createNamedQuery("Person.getPersonCountBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        if (results == null || results.isEmpty()) {
            return -1;
        } else {
            return results.get(0).intValue();
        }
    }
}
