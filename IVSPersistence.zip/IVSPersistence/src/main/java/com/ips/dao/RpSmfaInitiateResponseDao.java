package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpSmfaInitiateResponse;

public interface RpSmfaInitiateResponseDao {

    Collection<RpSmfaInitiateResponse> getAll();    
    RpSmfaInitiateResponse getById(Long id);
    void create(RpSmfaInitiateResponse entity);
    void update(RpSmfaInitiateResponse entity);
    List<RpSmfaInitiateResponse> getListByPersonId(long personId);
    RpSmfaInitiateResponse getByPersonId(long personId);
    RpSmfaInitiateResponse getByKbaUid(String kbaUid);
    String findRedirectUrl(String kbaUid);
}
