package com.ips.dao;

import com.ips.entity.HighRiskAddressAttempt;

public interface HighRiskAddressAttemptDao {

    void save(HighRiskAddressAttempt highRiskAddressAttempt);
    void update(HighRiskAddressAttempt highRiskAddressAttempt);
    HighRiskAddressAttempt getById(Long id);
}
