package com.ips.proofing;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang3.StringUtils;
import org.apache.wink.client.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.Utils;
import com.ips.entity.Person;
import com.ips.entity.PersonData;
import com.ips.entity.RefApp;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpDeviceReputation;
import com.ips.entity.RpEvent;
import com.ips.entity.RpExperianDecisionResult;
import com.ips.entity.RpExperianHeaderData;
import com.ips.entity.RpExperianResponsePayload;
import com.ips.entity.RpOtpAttempt;
import com.ips.entity.RpPhoneVerification;
import com.ips.entity.RpSupplierToken;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.ExperianResultVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.NameValueVo;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationResponse;
import com.ips.persistence.experianRest.request.ApplicationApplicantModel;
import com.ips.persistence.experianRest.request.ApplicationProductDetailModel;
import com.ips.persistence.experianRest.request.ContactAddressModel;
import com.ips.persistence.experianRest.request.ContactEmailModel;
import com.ips.persistence.experianRest.request.ContactIdentityDocumentModel;
import com.ips.persistence.experianRest.request.ContactPersonModel;
import com.ips.persistence.experianRest.request.ContactTelephoneModel;
import com.ips.persistence.experianRest.request.CrossCoreRequestModel;
import com.ips.persistence.experianRest.request.HeaderOptionModel;
import com.ips.persistence.experianRest.request.PayloadApplicationModel;
import com.ips.persistence.experianRest.request.PayloadContactModel;
import com.ips.persistence.experianRest.request.PayloadControlModel;
import com.ips.persistence.experianRest.request.PersonNameModel;
import com.ips.persistence.experianRest.request.RequestHeaderModel;
import com.ips.persistence.experianRest.request.RequestPayloadModel;
import com.ips.service.DeviceReputationServiceImpl;
import com.ips.service.ExperianDataService;
import com.ips.service.PersonDataService;
import com.ips.service.RefAppService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RpDeviceReputationService;
import com.ips.service.RpEventDataService;
import com.ips.service.RpExperianDecisionResultService;
import com.ips.service.RpExperianHeaderDataService;
import com.ips.service.RpExperianResponsePayloadService;
import com.ips.service.RpOtpAttemptDataService;
import com.ips.service.RpSupplierTokenService;
import com.ips.service.TruthDataReturnService;
import com.ips.service.TruthDataReturnServiceImpl;

@Service("experianService")
public class ExperianServiceImpl implements Serializable, ExperianService {

	private static final long serialVersionUID = 1L;

	public static final String EXPERIAN_CC_JWT_ENDPT = "com.ipsweb.ExperianCrossCoreJWTEndpoint";
	public static final String EXPERIAN_CROSSCORE_ENDPT = "com.ipsweb.ExperianCrossCoreEndpoint";
	public static final String EXPERIAN_JWT_ACCT_NAME = "com.ipsweb.ExperianJWTAcctName";
	public static final String EXPERIAN_JWT_ACCT_CODE = "com.ipsweb.ExperianJWTAcctCode";
	public static final String EXPERIAN_JWT_CLIENT_ID = "com.ipsweb.ExperianJWTClientId";
	public static final String EXPERIAN_JWT_CLIENT_SECRET = "com.ipsweb.ExperianJWTClientSecret";
	public static final String EXPERIAN_PID_ACCT_NAME = "com.ipsweb.ExperianPIDAcctName";
	public static final String EXPERIAN_PID_ACCT_CODE = "com.ipsweb.ExperianPIDAcctCode";
	public static final String EXPERIAN_PID_SUBSCRIBER_SUBCODE = "com.ipsweb.ExperianPIDSubscriberSubCode";
	public static final String EXPERIAN_CC_TENANT_ID = "com.ipsweb.ExperianCCTenantId";
	public static final String EXPERIAN_JWT_TOKEN_CODE = "crosscore_jwt";
	public static final String EXPERIAN_JWT_TOKEN_TYPE = "CC TOKEN BEARER";
	public static final String HEADER_USER_DOMAIN_NAME = "X-User-Domain";
	public static final String HEADER_USER_DOMAIN_VALUE = "usps.gov";
	public static final String HEADER_CORRELATION_ID_NAME = "X-Correlation-Id";
	public static final String HEADER_CORRELATION_ID_VALUE = "ccb82bd2-4438-45bf-9817-9a964d2e08fa";
  
	private static final String FIELD_APP_REFERENCE = "appReference";
	private static final String FIELD_AUTHENTICATION_KEY = "authenticationKey";
	private static final String FIELD_BACKING_APP = "backingApp";
	private static final String FIELD_CLIENT_REFERENCE_ID = "clientReferenceId";
	private static final String FIELD_CLIENT_RESPONSE_PAYLOAD = "clientResponsePayload";
	private static final String FIELD_CONTACTS = "contacts";
	private static final String FIELD_CORRELATION_ID = "correlationId";
	private static final String FIELD_DECISION = "decision";
	private static final String FIELD_DECISION_ELEMENTS = "decisionElements";
	private static final String FIELD_DECISION_REASONS = "decisionReasons";
	private static final String FIELD_DECISION_SOURCE = "decisionSource";
	private static final String FIELD_DECISION_TEXT = "decisionText";
	private static final String FIELD_ERROR_CODE = "ErrorCode";
	private static final String FIELD_ERROR_DESCRIPTION = "ErrorDescription";
	private static final String FIELD_EXP_REQUEST_ID = "expRequestId";
	private static final String FIELD_EV_URL = "evurl";
	private static final String FIELD_ORCHESTRATION_DECISIONS = "orchestrationDecisions";
	private static final String FIELD_ORIGINAL_REQUEST_DATA = "originalRequestData";
	private static final String FIELD_OTHER_DATA = "otherData";
	private static final String FIELD_REFERENCE_ID = "referenceId";
	private static final String FIELD_RESPONSE = "response";
	private static final String FIELD_RESPONSE_CODE = "responseCode";
	private static final String FIELD_RESPONSE_MESSAGE = "responseMessage";
	private static final String FIELD_REQUEST_TYPE = "requestType";
	private static final String FIELD_SEQUENCE_ID = "sequenceId";
	private static final String FIELD_SERVICE_NAME = "serviceName";
	private static final String FIELD_SCORES = "scores";
	private static final String FIELD_WARNING_ERRORS = "warningsErrors";
	
	private static final String ACTION_RESEND_PASSCODE = "ResendPasscode";
	private static final String ACTION_AUTHENTICATE_PHONE = "AuthenticatePhone";
	private static final String ACTION_VALIDATE_PASSCODE = "ValidatePasscode";
	private static final String ACTION_VERIFY_PHONE = "VerifyPhone";

	private static String propHost;
	private static String propPort;

	@Autowired
	private CommonRestService commonRestService;
	@Autowired
	private ExperianDataService experianDataService;
	@Autowired
	private ManageDeviceReputationService manageDeviceReputationService;
	@Autowired
	private ManageEventService manageEventService;
	@Autowired
	private PersonDataService personService;
	@Autowired
	private ProofingService proofingService;
	@Autowired
	private RefAppService refAppService;
	@Autowired
	private RefSponsorConfigurationService refSponsorConfigurationService;
	@Autowired
	private RpDeviceReputationService rpDeviceReputationService;
	@Autowired
	private RpEventDataService rpEventService;
	@Autowired
	private RpExperianDecisionResultService rpExperianDecisionResultService;
	@Autowired
	private RpExperianHeaderDataService rpExperianHeaderDataService;
	@Autowired
	private RpExperianResponsePayloadService rpExperianResponsePayloadService;
	@Autowired
	private RpOtpAttemptDataService rpOtpAttemptDataService;
	@Autowired
	private RpSupplierTokenService rpSupplierTokenService;
	@Autowired
	private TruthDataReturnService truthDataReturnService;
	
	static {
		List<String> props = new ArrayList<>();
		props.add("com.ipsweb.ln.proxyHost");
		props.add("com.ipsweb.proxyPort");
		props = Utils.getProperty(props);
		if (!props.isEmpty()) {
			propHost = props.get(0);
			propPort = props.get(1);
		}
	}

	/**** CHECK PREVIOUS IDENTITY AND PHONE VERIFICATION ****/
	/*
	 * Calls the Experian PreciseID web service to verify the customer's identity
	 * and phone number. Persists all of the related data to the database after the
	 * call. This method MUST throw a PhoneVerificationException to ensure that
	 * failover will occur to the other supplier
	 */
	public PhoneVerificationResponse verifyPhone(Person person, PersonVo personVo, ExperianResultVo resultVo)
			throws IPSException, PhoneVerificationException {

		PhoneVerificationResponse pvResponse = null;

		if (person == null || personVo == null) {
			return pvResponse;
		}
		
		if (resultVo == null) {
			resultVo = new ExperianResultVo();		
		}

		String phoneVerificationSupplier = personVo.getPhoneVerificationSupplierName();
		String loaSought = personVo.getProofingLevelSought();
		proofingService.updateProofingStatus(RefRpStatus.RpStatus.Identity_verification_initiated.getValue(), person,
				loaSought);
		CustomLogger.debug(this.getClass(), String.format("Remote proofing status: %s Phone verification is initiated.",
				phoneVerificationSupplier));
	
		try {
			boolean hasPreviousPhoneVerificationDecision = personVo.hasPreviousPhoneVerificationDecision();

			RpEvent prevPhoneEvent = null;
			String phoneVerificationDecision = "";
			long supplierId = RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID;
			String supplierName = RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_NAME;

			if (hasPreviousPhoneVerificationDecision) {
				prevPhoneEvent = rpEventService.getLatestPhoneEventsByPersonIdAndPhoneNumber(person.getPersonId(),
						personVo.getMobileNumber());
			}

			RpEvent phoneEvent = manageEventService.createEvent(personVo, prevPhoneEvent, supplierId);

			// Device Reputation
			manageDeviceReputationService.updateDeviceReputation(person, personVo, phoneEvent);
			
			CustomLogger.debug(this.getClass(), "Process check: Service verifyPhone> hasPreviousPhoneVerificationDecision:" + hasPreviousPhoneVerificationDecision);

			if (hasPreviousPhoneVerificationDecision) {
				pvResponse = manageEventService.savePreviousPhoneVerificationResults(phoneEvent, prevPhoneEvent,
						personVo, supplierId);
				
				if (pvResponse == null) {
			        return new PhoneVerificationResponse(supplierId, supplierName, PhoneVerificationResponse.PV_DECISION_FAIL, phoneEvent.getFinalDecision());    
				}
				
				String pvDecision = pvResponse.getPhoneVerificationDecision();

				CustomLogger.debug(this.getClass(), String.format(
						"Process check: Service verifyPhone> User with sponsorUserId %s has previous %s phone verification with a decision of %s.",
						person.getSponsorUserId(), supplierName, pvDecision));

				boolean passedVerification = PhoneVerificationResponse.PV_DECISION_PASS.equalsIgnoreCase(pvDecision)
						|| PhoneVerificationResponse.PV_DECISION_REVIEW.equalsIgnoreCase(pvDecision);

				if (passedVerification) {
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verified.getValue(), person,
							loaSought);
				} else {
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_failed.getValue(),
							person, loaSought);
				}

				experianDataService.assertPhoneVerificationResult(person, personVo, pvDecision, resultVo);

				phoneVerificationDecision = pvDecision;
				personVo.setPhoneVerificationDecision(pvDecision);
				
				return new PhoneVerificationResponse(RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID,
						RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_NAME, phoneVerificationDecision, phoneEvent.getFinalDecision());
			} else {
				pvResponse =  verifyPhoneWithExperianCrossCore(personVo, resultVo, person.getSponsorUserId(), phoneEvent);
				String pvDecision = pvResponse.getPhoneVerificationDecision();
				personVo.setPhoneVerificationDecision(pvDecision);
				
				return pvResponse;
			}
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(), "Exception occurred during the Experian call for sponsorUserId: "
					+ personVo.getSponsorUserId() + " " + personVo.getFullName(), ex);
			throw new PhoneVerificationException(ex.getMessage());
		}
	}

	/**** INITIATE NEW IDENTITY AND PHONE VERIFICATION ****/

	private PhoneVerificationResponse verifyPhoneWithExperianCrossCore(PersonVo personVo, ExperianResultVo resultVo,
			String sponsorUserId, RpEvent rpEvent) throws Exception {
	
		CustomLogger.debug(this.getClass(), "Process check: Experian Service verifyPhoneWithExperianCrossCore "
				+ String.format("sponsorUserId: %s", sponsorUserId));
		
		PhoneVerificationResponse pvResponse = new PhoneVerificationResponse();
		pvResponse.setPhoneVerificationSupplierId(RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID);
		pvResponse.setPhoneVerificationSupplierName(RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_NAME);

		Person person = getPerson(personVo.getId());

		resultVo.setProofingAction(ACTION_VERIFY_PHONE);

		initializeExperianResultVo(personVo, resultVo);
		callCrossCoreWorkflow(person, personVo, rpEvent, null, resultVo);

		if (resultVo.hasResponseError()) {
			resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_REVIEW);
			resultVo.setFailureReason(ExperianResultVo.FAILURE_REASON_CODE_ERROR_RESPONSE);
			resultVo.setRequestComplete(true);
		}
		
		// Initial Request
	
		if (resultVo.isRequestComplete()) {
			/* Following decisions have request completed and need to be returned to VerifyPhone Caller
			 * 1. PreciseIdDecision = Fail (Mobile & Desktop) > FAIL
			 *    To be returned and redirected to verification_cancel_confirmed.xhtml (IPP)
			 * 2. BokuServiceInfoDecision = Fail (Mobile & Desktop) > FAIL
			 * 	  To be returned and redirected to verification_cancel_confirmed.xhtml (IPP)
			 * 3. BokuScoreInfoDecision = Fail (Mobile & Desktop) > FAIL
			 *    To be returned and be redirected to verification_cancel_confirmed.xhtml (IPP)
			 * 4. BokuSendOtpDecision = Pass (Desktop) > REVIEW
			 *    Call savePasscodeRequest and be redirected to verification_enter_passcode.xhtml
			 * 5. BokuSendOtpDecision = Fail (Desktop) > REVIEW
			 *    Call savePasscodeRequest and be redirected to verification_request_passcode.xhtml for retry
			 * 6. BokuPNVReqInfoDecision = Pass/Fail (Mobile) > REVIEW
			 *    Need to be redirected to verification_silent_authentication.xhtml to invoke the Boku URL
			 * 7. BokuValidateOtpDecision = Pass (Mobile & Desktop) > PASS
			 *    Call savePasscodeResult and be redirected to verification_success.xhtml 
			 * 8. BokuValidateOtpDecision = Fail ((Mobile & Desktop) > REVIEW
			 *    Call savePasscodeResult and be redirected to verification_enter_passcode.xhtml for retry
			 */

			if (ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuSendOtpDecision())
					|| ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuSendOtpDecision())) {
				experianDataService.savePasscodeRequest(resultVo, personVo);
			}

			pvResponse.setPhoneVerificationDecision(resultVo.getPhoneVerificationDecision());
			pvResponse.setFailureReason(resultVo.getFailureReason());
			
			CustomLogger.debug(this.getClass(), String.format("Exp Svc > verifyPhoneWithExperianCrossCore > is RequestComplete: "
				+ "PhoneVerificationDecision:%s ", resultVo.getPhoneVerificationDecision()));
			
			return returnPhoneVerificationResponse(pvResponse, person, personVo, resultVo, rpEvent); 
		}
		//Not isRequestComplete
		else {
			return resumeWithClientSideUrlInvocation(person, personVo, resultVo, rpEvent, pvResponse);
		}
	}
	
	private PhoneVerificationResponse resumeWithClientSideUrlInvocation(Person person, PersonVo personVo, ExperianResultVo resultVo,
			RpEvent rpEvent, PhoneVerificationResponse pvResponse) throws Exception {

		String workflowRequestType = resultVo.getWorkflowRequestType();

		CustomLogger.debug(this.getClass(), String.format("Exp Svc > verifyPhoneWithExperianCrossCore > is not RequestComplete: "
			+ "WorkflowRequestType:%s, PhoneVerificationDecision:%s, RequestComplete:%s, "
			+ "NextAction:%s ", workflowRequestType, resultVo.getPhoneVerificationDecision(),
			resultVo.isRequestComplete(), resultVo.getNextAction()));

		//Initial/Not complete request for SilentAuthFlow (Mobile) Only
		if (ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW.equalsIgnoreCase(workflowRequestType)) {
			if (ExperianResultVo.BOKU_SERVICE_RESULT_FAIL.equalsIgnoreCase(resultVo.getBokuPNVReqInfoDecision())) {
				//Failed BokuPNVReqInfoDecision
				/* Expected Results:
				   resultVo> PhoneVerificationDecision = PhoneVerificationResponse.PV_DECISION_REVIEW;
				   resultVo> NextAction = ExperianResultVo.NEXT_ACTION_INIT_BOKU_OTP;
				*/
					
				if (personVo.isWebServiceCall()) {
					pvResponse.setPhoneVerificationDecision(RpPhoneVerification.DECISION_PASSED);
					return returnPhoneVerificationResponse(pvResponse, person, personVo, resultVo, rpEvent); 
				}
				
				callBokuSendOtpWorkflow(person, personVo, resultVo, pvResponse, rpEvent);
				return returnPhoneVerificationResponse(pvResponse, person, personVo, resultVo, rpEvent); 
			} 
		}
		//Initial/Not complete request for OTPFlow (Desktop) Only
		else {
			/* Flwg decisions need to continue
			 * 1. BokuSendOtpDecision = Pass (Desktop) > Need to execute OTPFlow resume call (BokuValidateOtp)
			 * 2. BokuSendOtpDecision = Fail (Desktop) > To be redirected to verification_request_passcode.xhtml for retry
			 */

			if (ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuSendOtpDecision())) {
				/* Expected Results:
				   resultVo> PhoneVerificationDecision = PhoneVerificationResponse.PV_DECISION_REVIEW;
				   resultVo> NextAction = ExperianResultVo.NEXT_ACTION_RESUME_BOKU_OTP;
				*/
				pvResponse.setPhoneVerificationDecision(resultVo.getPhoneVerificationDecision());
				
				return returnPhoneVerificationResponse(pvResponse, person, personVo, resultVo, rpEvent); 
			} 

		}
		
		pvResponse.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_FAIL);
		CustomLogger.debug(this.getClass(), String.format("Exp Svc > verifyPhoneWithExperianCrossCore " +
				"> before last return: getPhoneVerificationDecision:%s ", resultVo.getPhoneVerificationDecision()));

		return returnPhoneVerificationResponse(pvResponse, person, personVo, resultVo, rpEvent); 
	}
	
	private PhoneVerificationResponse returnPhoneVerificationResponse(PhoneVerificationResponse pvResponse, Person person, PersonVo personVo, 
			ExperianResultVo resultVo, RpEvent rpEvent) {
		boolean saved = experianDataService.savePhoneVerificationResults(resultVo, rpEvent, personVo, person);
		CustomLogger.debug(this.getClass(), String.format("Exp Svc > returnPhoneVerificationResponse : successful:%s ", saved));
		pvResponse.setRecordId(resultVo.getExpResultId());
		pvResponse.setNextAction(resultVo.getNextAction());
		
		return pvResponse;
	}

	private void callBokuSendOtpWorkflow(Person person, PersonVo personVo, ExperianResultVo resultVo,
			PhoneVerificationResponse pvResponse, RpEvent rpEvent) throws Exception {
		resultVo.setBearerToken(null);
		resultVo.setWorkflowRequestType(ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW);
		resultVo.setInitialRequest(true);

	   	boolean isUatMode = false;
		RefSponsorConfiguration useUatEnvConfig = refSponsorConfigurationService.getConfigRecord((int) RefSponsor.SPONSOR_ID_CUSTREG, CommonRestServiceImpl.USE_EXP_UAT_ENV);
		
		if (useUatEnvConfig != null && IPSConstants.CONFIG_VALUE_Y.equalsIgnoreCase(useUatEnvConfig.getValue())) {
			isUatMode = true;
		}
		
		if (!isUatMode) {
			resultVo.setDeviceTypeMobile(isDeviceTypeMobile(personVo));
		}
		else if(personVo.isWebServiceCall()) {
			resultVo.setDeviceTypeMobile(personVo.isDeviceTypeMobile());
		}
		
		CustomLogger.debug(this.getClass(), String.format("Exp Svc > callBokuSendOtpWorkflow > before callCrossCoreWorkflow: "
				+ "TestMode:%s, DeviceTypeMobile:%s, WorkflowRequestType:%s, " 
				+ "InitialRequest:%s, TestScenario:%s, RequestComplete:%s, " 
				+ "PhoneVerificationDecision:%s, PreciseIdDecision:%s, BokuServiceInfoDecision:%s, " 
				+ "BokuScoreInfoDecision:%s, BokuPNVReqInfoDecision:%s, BokuPNVResInfoDecision:%s, " 
				+ " BokuSendOtpDecision:%s, BokuValidateOtpDecision: %s, PersonId:%s", 	
				resultVo.isTestMode(), resultVo.isDeviceTypeMobile(), resultVo.getWorkflowRequestType(), 
				resultVo.isInitialRequest(), resultVo.getTestScenario(), resultVo.isRequestComplete(),
				resultVo.getPhoneVerificationDecision(), resultVo.getPreciseIdDecision(), 
				resultVo.getBokuServiceInfoDecision(), resultVo.getBokuScoreInfoDecision(),
				resultVo.getBokuPNVReqInfoDecision(), resultVo.getBokuPNVResInfoDecision(),
				resultVo.getBokuSendOtpDecision(), resultVo.getBokuValidateOtpDecision(),
				resultVo.getPersonId()));	

		// Initial BokuOTPFlow Request - Boku Send OTP
		callCrossCoreWorkflow(person, personVo, rpEvent, null, resultVo);

		boolean passcodeSent = ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuSendOtpDecision());

		experianDataService.savePasscodeRequest(resultVo, personVo);

		CustomLogger.debug(this.getClass(), String.format("Exp Svc > callBokuSendOtpWorkflow : passcode request %s for sponsorUserId: %s",
				(passcodeSent ? IPSConstants.VALUE_PASSED : IPSConstants.VALUE_FAILED), person.getSponsorUserId()));			

		// Only move on to confirm passcode if the passcode was successfully sent
		String loaSought = personVo.getProofingLevelSought();
		if (passcodeSent) {
			proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_sent.getValue(), person, loaSought);
		} else {
			proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_initiated.getValue(), person, loaSought);
		}
		
		if (resultVo.isRequestComplete() && pvResponse != null) {
			CustomLogger.debug(this.getClass(), String.format("Exp Svc > callBokuSendOtpWorkflow: getPhoneVerificationDecision: %s",
					resultVo.getPhoneVerificationDecision()));
			pvResponse.setPhoneVerificationDecision(resultVo.getPhoneVerificationDecision());
		}
	}
	
	/****
	 * CALL CROSSCORE WEB SERVICES
	 * 
	 * @throws PhoneVerificationException
	 ****/

	@Override
	public void callCrossCoreWorkflow(Person person, PersonVo personVo, RpEvent rpEvent,
			CrossCoreRequestModel ccRequest, ExperianResultVo resultVo)
			throws IPSException, PhoneVerificationException {
		CustomLogger.debug(this.getClass(), String.format("Exp Svc > callCrossCoreWorkflow: personVo fullName: %s", personVo.getFullName()));
		JSONObject ccResponseJsonObj = new JSONObject();
		setExperianAccessCredentials(personVo, rpEvent, resultVo);
		
		if (resultVo.hasResponseError()) {
			return;
		}
		
		try {
			ccResponseJsonObj = getCrossCoreResponse(personVo, ccRequest, resultVo, rpEvent);
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(), String.format("Exp Svc > callCrossCoreWorkflow > Process error: Exception occurred on service callCrossCoreWorkflow for "
					+ "sponsorUserId:%s, person full name:%s", personVo.getSponsorUserId(), personVo.getFullName()), ex);
			ccResponseJsonObj = null;
		}

		if (ccResponseJsonObj != null) {
			processCrossCoreResponse(person, personVo, rpEvent, ccResponseJsonObj, resultVo);
		}
		else {
			resultVo.setHasResponseError(true);
		}
	}

	@Override
	public JSONObject getCrossCoreResponse(PersonVo personVo, CrossCoreRequestModel ccRequest, ExperianResultVo resultVo, RpEvent rpEvent)
			throws IPSException, PhoneVerificationException {
	   	CustomLogger.debug(this.getClass(), "Process check: Experian Service > call getCrossCoreResponse(personVo,ccRequest,resultVo,rpEvent).");

		JSONObject ccResponseJsonObj = new JSONObject();
		String bearerToken = resultVo.getBearerToken();

		if (ccRequest == null) {
			ccRequest = prepareCrossCoreRequest(personVo, resultVo);
		}

		Gson g = new GsonBuilder().disableHtmlEscaping().create();
		String webServiceURL = commonRestService.getIpsPropertyValue(EXPERIAN_CROSSCORE_ENDPT);
		
		RefSponsorConfiguration altXcoreEndptConfig = refSponsorConfigurationService.getConfigRecord((int) RefSponsor.SPONSOR_ID_CUSTREG, CommonRestServiceImpl.USE_EXP_XCORE_ALT_ENDPOINT);
		if (altXcoreEndptConfig != null && IPSConstants.CONFIG_VALUE_Y.equalsIgnoreCase(altXcoreEndptConfig.getValue())) {
			RpSupplierToken altXcoreEndpt = rpSupplierTokenService.findByTokenType(CommonRestServiceImpl.TOKEN_TYPE_EXP_XCORE_ALT_ENDPT);
			
			if (altXcoreEndpt != null) {
				webServiceURL = altXcoreEndpt.getAccessToken();
			}
		}
		
		String requestJson = g.toJson(ccRequest);
		resultVo.setCrossCoreRequestJson(requestJson);

		String callStep = resultVo.isInitialRequest()? "INITIAL" : "RESUME";
		String workflow = resultVo.getWorkflowRequestType().toUpperCase();

		CustomLogger.debug(this.getClass(), String.format("Process check: Service getCrossCoreResponse EXP WEB SERVICE REQUEST> %s %s: %s", workflow, callStep, requestJson));

		try {
			Resource resource = commonRestService.getClientResource(webServiceURL);
			ccResponseJsonObj = commonRestService.getCrossCoreResponse(resultVo, resource, bearerToken, requestJson);
			CustomLogger.debug(this.getClass(), "Experian service debug: getCrossCoreResponse >isSkipFirstAttemptErrorCheck:" + resultVo.isSkipFirstAttemptErrorCheck());

			if (!resultVo.isSkipFirstAttemptErrorCheck()) {
				boolean hasPreciseIdError = hasPreciseIdError(personVo, rpEvent, ccResponseJsonObj, resultVo);
				CustomLogger.debug(this.getClass(), "Experian service debug: getCrossCoreResponse >hasPreciseIdError:" + hasPreciseIdError);

				if (hasPreciseIdError) {	
					resultVo.setHasResponseError(true);
					return null;
				}
			}
			
			CustomLogger.debug(this.getClass(), String.format(" Process check: Service getCrossCoreResponse EXP WEB SERVICE ACTUAL RESPONSE> %s %s:%s", workflow, callStep, ccResponseJsonObj));	
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(), String.format("Process error: Exception on getCrossCoreResponse for sponsorUserId: %s, fullName:%s",
					personVo.getSponsorUserId(), personVo.getFullName()), ex);
			resultVo.setHasResponseError(true);
			return null;
		}

		return ccResponseJsonObj;
	}
	
	private void setExperianAccessCredentials(PersonVo personVo, RpEvent rpEvent, ExperianResultVo resultVo) {
		//Setting BearerToken
		String accessToken = "";

		try {
			accessToken = getExperianAccessToken(personVo, rpEvent, resultVo);
			
			if (resultVo.hasResponseError()) {
				return;
			}
		} catch (IPSException e) {
			CustomLogger.error(this.getClass(), "Error occurs in obtaining Experian accessToken.", e);
		}
		
		String bearerToken = String.format(CommonRestServiceImpl.BEARER_TOKEN_FMT, accessToken);
		resultVo.setBearerToken(bearerToken);
		
		//Setting PidUserName and PidUserKey
		RefSponsorConfiguration altXcoreCredConfig = refSponsorConfigurationService.getConfigRecord((int) RefSponsor.SPONSOR_ID_CUSTREG, CommonRestServiceImpl.USE_EXP_XCORE_ALT_CREDENTIAL);
		String userName = "";
		String userPwd = "";
		
		if (altXcoreCredConfig != null && IPSConstants.CONFIG_VALUE_Y.equalsIgnoreCase(altXcoreCredConfig.getValue())) {
			RpSupplierToken altXcoreCred = rpSupplierTokenService.findByTokenType(CommonRestServiceImpl.TOKEN_TYPE_EXP_XCORE_ALT_CRED);

			if (altXcoreCred != null) {
				userName =altXcoreCred.getTokenCode();
				userPwd = altXcoreCred.getAccessToken();
			}
		}

		resultVo.setPidUserName(userName);
		resultVo.setPidUserKey(userPwd);
	}

	private boolean hasPreciseIdError(PersonVo personVo, RpEvent rpEvent, JSONObject ccResponseJsonObj, ExperianResultVo resultVo) {

		JSONObject clientResponsePayloadObj = (JSONObject) ccResponseJsonObj.get(FIELD_CLIENT_RESPONSE_PAYLOAD);
		boolean hasPreciseIdError = false;
		String orchDecisionsArrJson = "";
		
		if (clientResponsePayloadObj != null) {
			JSONArray orchestrationDecisionsArr = (JSONArray) clientResponsePayloadObj.get(FIELD_ORCHESTRATION_DECISIONS);

			if (orchestrationDecisionsArr != null && !orchestrationDecisionsArr.isEmpty()) {
				Gson g = new GsonBuilder().disableHtmlEscaping().create();
				orchDecisionsArrJson = g.toJson(orchestrationDecisionsArr);
				CustomLogger.debug(this.getClass(), "Experian service hasPreciseIdError> orchDecisionsArrJson: " + orchDecisionsArrJson);

				resultVo.setOrchDecisionJson(orchDecisionsArrJson);
				JSONObject orchDecisionItem = (JSONObject) orchestrationDecisionsArr.get(0);
				if (orchDecisionItem != null) {
					String decision = (String) orchDecisionItem.get(FIELD_DECISION);

					CustomLogger.debug(this.getClass(), "Experian service hasPreciseIdError> decision: " + decision);
	
					hasPreciseIdError = !(IPSConstants.RP_EXPERIAN_CONTINUE.equalsIgnoreCase(decision) || IPSConstants.RP_EXPERIAN_INVESTIGAT.equalsIgnoreCase(decision)
							|| IPSConstants.RP_EXPERIAN_STOP.equalsIgnoreCase(decision) || IPSConstants.RP_EXPERIAN_NODECISION.equalsIgnoreCase(decision));
				}
			}
		}
		
		if (hasPreciseIdError && !Utils.isEmptyString(orchDecisionsArrJson)) {
			savePreciseIdErrorResponse(personVo, rpEvent, orchDecisionsArrJson);
		}

		return hasPreciseIdError;
	}
	
	@Override
	public void processCrossCoreResponse(Person person, PersonVo personVo, RpEvent rpEvent,
			JSONObject ccResponseJsonObj, ExperianResultVo resultVo) throws IPSException, PhoneVerificationException {

		extractCrossCoreResponseData(ccResponseJsonObj, resultVo);
		personVo.setErrorMessage(resultVo.getErrorMessage());
		personVo.setErrorCode(resultVo.getWarningResponseCode());
			
		experianDataService.saveRpExperianDecisionResult(person, rpEvent, resultVo);

		RpExperianDecisionResult decisionResult = retrievedRpExperianDecisionResult(person, resultVo);

		if (decisionResult == null) {
			CustomLogger.debug(this.getClass(), "Experian Service processCrossCoreResponse> RpExperianDecisionResult is null.");

			return;
		}
		
		RefSponsorConfiguration captureExpRespConfig = refSponsorConfigurationService.getConfigRecord((int) RefSponsor.SPONSOR_ID_CUSTREG, CommonRestServiceImpl.CAPTURE_EXP_RESPONSE);
		if (captureExpRespConfig != null && IPSConstants.CONFIG_VALUE_Y.equalsIgnoreCase(captureExpRespConfig.getValue())) {
			Gson g = new GsonBuilder().disableHtmlEscaping().create();
			String ccResponseJsonStr = g.toJson(ccResponseJsonObj);
			resultVo.setResponseJson(ccResponseJsonStr);
		} 
		
		experianDataService.saveRpExperianHeaderData(person, decisionResult, resultVo);
		experianDataService.saveRpExperianResponsePayload(person, personVo, decisionResult, resultVo);
		evaluatePhoneVerificationDecision(person, personVo, rpEvent, ccResponseJsonObj, resultVo);
	}

	@Override
	public void evaluatePhoneVerificationDecision(Person person, PersonVo personVo, RpEvent rpEvent,
			JSONObject ccResponseJsonObj, ExperianResultVo resultVo) throws IPSException, PhoneVerificationException {
		CustomLogger.enter(this.getClass());
	
		String loaSought = personVo.getProofingLevelSought();
		String workflowRequestType = resultVo.getWorkflowRequestType();
		boolean isInitialRequest = resultVo.isInitialRequest();

		if (ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW.equalsIgnoreCase(workflowRequestType)
				|| ExperianResultVo.WORKFLOW_REQUEST_TYPE_OTP_FLOW.equalsIgnoreCase(workflowRequestType)) {
			//Initial request for both SilentAuthFlow and OTPFlow
			if (isInitialRequest) {
				if (!ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getPreciseIdDecision())
						|| !ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuServiceInfoDecision())
						|| !ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuScoreInfoDecision())) {

					if (ExperianResultVo.SERVICE_DECISION_INVESTIGATE.equalsIgnoreCase(resultVo.getPreciseIdDecision())) {
						resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_REVIEW);
						resultVo.setFailureReason(ExperianResultVo.FAILURE_REASON_CODE_CUST_NOT_FOUND);
						resultVo.setRequestComplete(true);
					}
					else if (resultVo.hasResponseError()) {
						resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_REVIEW);
						resultVo.setFailureReason(ExperianResultVo.FAILURE_REASON_CODE_ERROR_RESPONSE);
						resultVo.setRequestComplete(true);
					}
					else if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuServiceInfoDecision())) {
						resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_REVIEW);
						resultVo.setNextAction(ExperianResultVo.NEXT_ACTION_SUBMIT_VALID_PHONE);
						resultVo.setRequestComplete(true);
						proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_failed.getValue(),
								person, loaSought);
					}
					else {
						resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_FAIL);
						resultVo.setRequestComplete(true);
						proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_failed.getValue(),
								person, loaSought);
					}
				}
				//Initial request for SilentAuthFlow Only
				else if (ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW.equalsIgnoreCase(workflowRequestType)) {
					if (ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuScoreInfoDecision())) {
						proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verified.getValue(),
								person, loaSought);
					}

					proofingService.updateProofingStatus(RefRpStatus.RpStatus.Silent_Authentication_initiated.getValue(),
							person, loaSought);
					
					//Boku is going to invoked whether BokuPNVReqInfoDecision is Passed or Failed
					resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_REVIEW);
					resultVo.setNextAction(ExperianResultVo.NEXT_ACTION_INVOKE_BOKU_URL);
					resultVo.setRequestComplete(true);
				}
				//Initial request for OTPFlow Only
				else {
					if (ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuScoreInfoDecision())) {
						proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verified.getValue(),
								person, loaSought);
					}
					
					resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_REVIEW);
					resultVo.setRequestComplete(true);

					if (ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuSendOtpDecision())) {
						resultVo.setNextAction(ExperianResultVo.NEXT_ACTION_RESUME_BOKU_OTP);
							proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_sent.getValue(),
								person, loaSought);
					} 
					else { //Retry
						resultVo.setNextAction(ExperianResultVo.NEXT_ACTION_INIT_BOKU_OTP);
						proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_initiated.getValue(),
								person, loaSought);
					} 
				}
			}
			//Resume Request for both SilentAuthFlow and OTPFlow
			else {
				//Resume request for SilentAuthFlow Only - This if block is superceded by silentAuthenticationSuccessful method
				if (ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW.equalsIgnoreCase(workflowRequestType)) {
					if (ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuPNVResInfoDecision())) {
						resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_PASS);
						resultVo.setRequestComplete(true);
						proofingService.updateProofingStatus(RefRpStatus.RpStatus.LOA_level_achieved.getValue(),
								person, loaSought);
					} 
					else {
						resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_REVIEW);
						resultVo.setRequestComplete(true);
						resultVo.setNextAction(ExperianResultVo.NEXT_ACTION_INVOKE_BOKU_URL);
						proofingService.updateProofingStatus(RefRpStatus.RpStatus.Silent_Authentication_initiated.getValue(),
								person, loaSought);
					} 
				}
				//Resume request for OTPFlow Only
				else {
					if (ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuValidateOtpDecision())) {
						resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_PASS);
						resultVo.setRequestComplete(true);
						proofingService.updateProofingStatus(RefRpStatus.RpStatus.LOA_level_achieved.getValue(),
								person, loaSought);
					} 
					else {
						resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_REVIEW);
						resultVo.setRequestComplete(false);
						resultVo.setNextAction(ExperianResultVo.NEXT_ACTION_INIT_BOKU_OTP);
						proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_confirmation_failed.getValue(),
								person, loaSought);
					} 
				}
			}
		} 
		else if (ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW.equalsIgnoreCase(workflowRequestType)) {
			//Initial request for Boku OTP Flow	
			if (isInitialRequest) {
				resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_REVIEW);
				resultVo.setRequestComplete(true);

				if (ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuSendOtpDecision())) {
					resultVo.setNextAction(ExperianResultVo.NEXT_ACTION_RESUME_BOKU_OTP);
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_sent.getValue(),
							person, loaSought);
				} 
				else {
					resultVo.setNextAction(ExperianResultVo.NEXT_ACTION_INIT_BOKU_OTP);
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_initiated.getValue(),
							person, loaSought);
				} 
			//Resume request for Boku OTP Flow	
			} else {
				if (ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuValidateOtpDecision())) {
					resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_PASS);
					resultVo.setRequestComplete(true);
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.LOA_level_achieved.getValue(),
							person, loaSought);
				} 
				else {
					resultVo.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_REVIEW);
					resultVo.setRequestComplete(false);
					resultVo.setNextAction(ExperianResultVo.NEXT_ACTION_INIT_BOKU_OTP);
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_confirmation_failed.getValue(),
							person, loaSought);
				} 
			}
		}

		CustomLogger.debug(this.getClass(), "Service evaluatePhoneVerificationDecision AFTER> "
				+ "> TestMode:" + resultVo.isTestMode()
				+ "> DeviceTypeMobile:" + resultVo.isDeviceTypeMobile() 
				+ "> WorkflowRequestType:" + resultVo.getWorkflowRequestType() 
				+ "> InitialRequest:" + resultVo.isInitialRequest() 
				+ "> TestScenario:" + resultVo.getTestScenario()
				+ "> RequestComplete:" + resultVo.isRequestComplete()
				+ "> PhoneVerificationDecision:" + resultVo.getPhoneVerificationDecision()
				+ "> PreciseIdDecision:" + resultVo.getPreciseIdDecision()
				+ "> BokuServiceInfoDecision:" + resultVo.getBokuServiceInfoDecision()
				+ "> BokuScoreInfoDecision:" + resultVo.getBokuScoreInfoDecision()
				+ "> BokuPNVReqInfoDecision:" + resultVo.getBokuPNVReqInfoDecision()
				+ "> BokuPNVResInfoDecision:" + resultVo.getBokuPNVResInfoDecision()
				+ "> BokuSendOtpDecision:" + resultVo.getBokuSendOtpDecision()
				+ "> BokuValidateOtpDecision:" + resultVo.getBokuValidateOtpDecision()
				+ "> PersonId:" + resultVo.getPersonId());		

	}

	@Override
	public RpExperianDecisionResult retrievedRpExperianDecisionResult(Person person, ExperianResultVo resultVo)
			throws IPSException, PhoneVerificationException {
		CustomLogger.enter(this.getClass());
		String debugMsg =  "Service retrievedRpExperianDecisionResult> Method was called.";
		CustomLogger.debug(this.getClass(), debugMsg);

		RpExperianDecisionResult decisionResult = null;
		try {
      		decisionResult = rpExperianDecisionResultService.findByPersonId(person.getPersonId());

			if (decisionResult != null) {
				if (resultVo.isInitialRequest()) {
					if (ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW.equalsIgnoreCase(resultVo.getWorkflowRequestType())) {
						resultVo.setExpResultId(decisionResult.getExpResultId());
						resultVo.setBokuPNVReqCorrelationId(decisionResult.getCorrelationId()); 
			   		}
			   		else if (ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW.equalsIgnoreCase(resultVo.getWorkflowRequestType())
			   				|| ExperianResultVo.WORKFLOW_REQUEST_TYPE_OTP_FLOW.equalsIgnoreCase(resultVo.getWorkflowRequestType())) {
			  	      	resultVo.setBokuCorrelationId(decisionResult.getCorrelationId()); 
			  	  		resultVo.setBokuAuthenticationKey(decisionResult.getAuthenticationKey());
			   		}
				}
			}
			else {
				CustomLogger.debug(this.getClass(), "Experian Service retrievedRpExperianDecisionResult> RpExperianDecisionResult is null "
						+ "for PersonId:" + person.getPersonId());
			}
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Error occurs in retrieving RpExperianDecisionResult.", e);
		}

		return decisionResult;
	}

	/**** OBTAIN ACCESS TOKEN ****/

	@Override
	public String getExperianAccessToken(PersonVo personVo, RpEvent rpEvent, ExperianResultVo resultVo) throws IPSException {
	   	CustomLogger.debug(this.getClass(), "Process check: Experian Service > call getExperianAccessToken(personVo,rpEvent).");

		String accessToken = "";
		RpSupplierToken existingToken = null;
		
		//Obtain existing token
		try {
			existingToken = rpSupplierTokenService.getByCodeAndType(EXPERIAN_JWT_TOKEN_CODE, EXPERIAN_JWT_TOKEN_TYPE);
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(), "Exception occurred during retrieving the existing Experian token.", ex);
			existingToken = null;
		}
		
		if (existingToken != null) {
			CustomLogger.debug(this.getClass(), "Existing RpSupplierToken is found");

			Timestamp lastIssueTime = existingToken.getIssueTime();
			long tokenExpiresMinutes = 25;	// Minutes the token will expire

			Date minutesAgo = new Date(System.currentTimeMillis() - tokenExpiresMinutes*60*1000);
			boolean hasTokenExpired = minutesAgo.compareTo(lastIssueTime) > 0;
            
            if (!hasTokenExpired) {
    			CustomLogger.debug(this.getClass(), "Existing RpSupplierToken has not expired.");
            	accessToken = existingToken.getAccessToken();
           
        		if (!StringUtils.isEmpty(accessToken)) {
    				CustomLogger.debug(this.getClass(), "Access Token is not empty.");
    			}
            }
  		}
		
		JSONObject tokenResponseJsonObj = null;
		if (StringUtils.isEmpty(accessToken)) {
			CustomLogger.debug(this.getClass(), "Existing RpSupplierToken has expired or does not exist.");
			tokenResponseJsonObj = getJsonWebTokenResponse(resultVo);

			if (tokenResponseJsonObj != null) {
				CustomLogger.debug(this.getClass(), "RpSupplierToken Json is obtained.");
				accessToken = (String) tokenResponseJsonObj.get("access_token");
			
				if (!StringUtils.isEmpty(accessToken)) {
					CustomLogger.debug(this.getClass(), "Service getExperianAccessToken>  accessToken:"
						+ accessToken.substring(0, 10));
					
					// Save token to db
					saveAccessToken(existingToken, accessToken);
				}
			}
		}
		
        if (!IPSConstants.ENV_PROD.equalsIgnoreCase(Utils.getEnvironmentWithoutDot())) { 
        	if ("webTokenErrorUser".equalsIgnoreCase(resultVo.getTestScenario())) {
        		accessToken = "";
        	}
  		}
		
		if (Utils.isEmptyString(accessToken)) {
			saveFailedJwtResponse(personVo, rpEvent, tokenResponseJsonObj);
			resultVo.setHasResponseError(true);
			CustomLogger.debug(this.getClass(), "Service getExperianAccessToken>  tokenResponseJsonObj is null");
		}
	
		return accessToken;
	}
	
    @Override
    public void saveAccessToken(RpSupplierToken existingToken, String accessToken) {
 		CustomLogger.enter(this.getClass());

		long expiresInSecs = 1500;
		Timestamp currentTime = new Timestamp(new Date().getTime());
		Timestamp expirationTime = Timestamp.valueOf((LocalDateTime.now().plusSeconds(expiresInSecs)));
	
		if (existingToken != null) {
			CustomLogger.debug(this.getClass(), "Updating the existing RpSupplierToken.");
			existingToken.setAccessToken(accessToken);
			existingToken.setIssueTime(currentTime);
			existingToken.setExpirationTime(expirationTime);
			existingToken.setUpdateDate(currentTime);
			
			rpSupplierTokenService.update(existingToken);
		}
		else {
			CustomLogger.debug(this.getClass(), "Saving a new RpSupplierToken.");

			RpSupplierToken newToken = new RpSupplierToken();
			newToken.setAccessToken(accessToken);
			newToken.setTokenCode(EXPERIAN_JWT_TOKEN_CODE);
			newToken.setTokenType(EXPERIAN_JWT_TOKEN_TYPE);
			newToken.setExpiresIn(1500);
			newToken.setIssueTime(currentTime);
			newToken.setExpirationTime(expirationTime);
			newToken.setUpdateDate(currentTime);
			newToken.setCreateDate(currentTime);
			
			rpSupplierTokenService.save(newToken);
		}
    }

	/**** CALL AUTHENTICATION TOKEN WEB SERVICE ****/

	@Override
	public JSONObject getJsonWebTokenResponse(ExperianResultVo resultVo) throws IPSException {
	   	CustomLogger.debug(this.getClass(), "Process check: Experian Service > call getJsonWebTokenResponse().");

		String webServiceURL = commonRestService.getIpsPropertyValue(EXPERIAN_CC_JWT_ENDPT);
		
		RefSponsorConfiguration altJwtEndptConfig = refSponsorConfigurationService.getConfigRecord((int) RefSponsor.SPONSOR_ID_CUSTREG, CommonRestServiceImpl.USE_EXP_JWT_ALT_ENDPOINT);
		if (altJwtEndptConfig != null && IPSConstants.CONFIG_VALUE_Y.equalsIgnoreCase(altJwtEndptConfig.getValue())) {
			RpSupplierToken altJwtEndpt = rpSupplierTokenService.findByTokenType(CommonRestServiceImpl.TOKEN_TYPE_EXP_JWT_ALT_ENDPT);
		   	CustomLogger.debug(this.getClass(), "Process check: Experian Service > RefSponsorConfiguration is found for EXP_JWT_ALT_ENDPT.");

			if (altJwtEndpt != null) {
				webServiceURL = altJwtEndpt.getAccessToken();
			   	CustomLogger.debug(this.getClass(), "Process check: Experian Service > RpSupplierToken altJwtEndpt is not null."
			   			+ " webServiceURL:" + webServiceURL);
			}
		}
		
		List<NameValueVo> headerList = new ArrayList<>();
		headerList.add(new NameValueVo(HEADER_USER_DOMAIN_NAME, HEADER_USER_DOMAIN_VALUE));
		headerList.add(new NameValueVo(HEADER_CORRELATION_ID_NAME, HEADER_CORRELATION_ID_VALUE));

		setJwtCredential(resultVo);
		
		return commonRestService.getJsonWebTokenResponse(webServiceURL, headerList, resultVo);
	}
	
	private void setJwtCredential(ExperianResultVo resultVo) {
		String userName = commonRestService.getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_JWT_ACCT_NAME);
		String userKey = commonRestService.getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_JWT_ACCT_CODE);
	
		RefSponsorConfiguration sponsorConfig = refSponsorConfigurationService.getConfigRecord((int) RefSponsor.SPONSOR_ID_CUSTREG, CommonRestServiceImpl.USE_EXP_JWT_ALT_CREDENTIAL);
		if (sponsorConfig != null && IPSConstants.CONFIG_VALUE_Y.equalsIgnoreCase(sponsorConfig.getValue())) {
			RpSupplierToken altJwtCred = rpSupplierTokenService.findByTokenType(CommonRestServiceImpl.TOKEN_TYPE_EXP_JWT_ALT_CRED);
		   	CustomLogger.debug(this.getClass(), "Process check: CommonRest Service > RefSponsorConfiguration is found for Use.Exp.Jwt.Alt.Credential.");
	
			if (altJwtCred != null) {
				String jwtUserName = altJwtCred.getTokenCode();
				if (!Utils.isEmptyString(jwtUserName)) {
					if (jwtUserName.startsWith("crosscore.prod.non")) {
						userName = jwtUserName + "exp@usps.gov";
					}
					else {
						userName = jwtUserName + "@usps.gov";
					}
				}
						
				userKey = altJwtCred.getAccessToken();
			}
		}
		
		resultVo.setJwtUserName(userName);
		resultVo.setJwtUserKey(userKey);
	}

	/**** CREATE CROSSCORE WEB SERVICE REQUEST ****/

	@Override
	public CrossCoreRequestModel prepareCrossCoreRequest(PersonVo personVo, ExperianResultVo resultVo)
			throws IPSException {
	   	CustomLogger.debug(this.getClass(), "Process check: Experian Service > call prepareCrossCoreRequest(personVo,resultVo).");

		CrossCoreRequestModel ccRequest = new CrossCoreRequestModel();
		String workflowRequestType = resultVo.getWorkflowRequestType();
		
		boolean isSilentAuthFlow = ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW.equalsIgnoreCase(workflowRequestType);
		boolean isOTPflow = ExperianResultVo.WORKFLOW_REQUEST_TYPE_OTP_FLOW.equalsIgnoreCase(workflowRequestType);
		boolean isBokuOTPflow = ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW.equalsIgnoreCase(workflowRequestType);		
		boolean isInitialRequest= resultVo.isInitialRequest();	

		RequestHeaderModel requestHeader = new RequestHeaderModel();
		String tenantId = commonRestService.getIpsPropertyValue(EXPERIAN_CC_TENANT_ID);
		requestHeader.setTenantId(tenantId);
		requestHeader.setRequestType(workflowRequestType);	
			
		if (isInitialRequest) {
			requestHeader.setClientReferenceId(generateClientReferenceId(personVo));
			requestHeader.setExpRequestId(""); 
			
			CustomLogger.debug(this.getClass(), String.format("Process check: Service prepareCrossCoreRequest for Initial Call: " 
					+ "WorkflowRequestType:%s, HeaderClientReferenceId:%s, HeaderExpRequestId:%s",
					resultVo.getWorkflowRequestType(), resultVo.getClientReferenceId(),
					resultVo.getHeaderExpRequestId()));
		}
		else {
			requestHeader.setClientReferenceId(resultVo.getHeaderClientReferenceId());
			requestHeader.setExpRequestId(resultVo.getHeaderExpRequestId());
			
			CustomLogger.debug(this.getClass(), String.format("Process check: Service prepareCrossCoreRequest for Resume Call: " 
					+ "WorkflowRequestType:%s, HeaderClientReferenceId:%s, HeaderExpRequestId:%s",
					resultVo.getWorkflowRequestType(), resultVo.getHeaderClientReferenceId(),
					resultVo.getHeaderExpRequestId()));
		}
		
		ZonedDateTime zdt = ZonedDateTime.now();
		String messageTime = zdt.format(DateTimeFormatter.ISO_INSTANT);
		int dotIndex = messageTime.indexOf(".");
		
		if (dotIndex > 0) {
			messageTime = messageTime.substring(0, dotIndex) + "Z";
		}
		else {
	        LocalDateTime currentDateTime = LocalDateTime.now(); 
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMddyyyyHHmmss");
	        String formattedDatetime = currentDateTime.format(formatter);
	      
	        if (formattedDatetime.length() == 14) {
		        String dtMonth = formattedDatetime.substring(0,2);
		        String dtDay = formattedDatetime.substring(2,4);
		        String dtYear = formattedDatetime.substring(4,8);
		        String dtHour = formattedDatetime.substring(8,10);
		        String dtMinute = formattedDatetime.substring(10,12);
		        String dtSecond = formattedDatetime.substring(12,14);
		      
		        messageTime = String.format("%s-%s-%sT%s:%s:%sZ", dtYear, dtMonth, dtDay, dtHour, dtMinute, dtSecond);
	        }   
		}
		
		requestHeader.setMessageTime(messageTime);
		requestHeader.setTxnId("");
		requestHeader.setTime("");
		HeaderOptionModel headerOption = new HeaderOptionModel();
		requestHeader.setOptions(headerOption);
		resultVo.setHeaderMessageTime(messageTime);

		RequestPayloadModel requestPayload = new RequestPayloadModel();

		/* CONTROL */
		List<PayloadControlModel> payloadControlList = new ArrayList<>();

		PayloadControlModel payloadControl1 = new PayloadControlModel();
		payloadControl1.setOption("PIDXML_VERSION");
		payloadControl1.setValue("06.00");
		payloadControlList.add(payloadControl1);

		PayloadControlModel payloadControl2 = new PayloadControlModel();
		payloadControl2.setOption("SUBSCRIBER_PREAMBLE");
		payloadControl2.setValue("TBD3");
		payloadControlList.add(payloadControl2);

		PayloadControlModel payloadControl3 = new PayloadControlModel();
		payloadControl3.setOption("SUBSCRIBER_OPERATOR_INITIAL");
		payloadControl3.setValue("UP");
		payloadControlList.add(payloadControl3);

		PayloadControlModel payloadControl4 = new PayloadControlModel();
		payloadControl4.setOption("SUBSCRIBER_SUB_CODE");
		String subscriberSubcode = commonRestService.getIpsPropertyValue(EXPERIAN_PID_SUBSCRIBER_SUBCODE);
		payloadControl4.setValue(subscriberSubcode);
		payloadControlList.add(payloadControl4);

		String userName = resultVo.getPidUserName();
		String userPwd  = resultVo.getPidUserKey();
		PayloadControlModel payloadControl5 = new PayloadControlModel();
		payloadControl5.setOption("PID_USERNAME");
		payloadControl5.setValue(userName);
		payloadControlList.add(payloadControl5);
		
		PayloadControlModel payloadControl6 = new PayloadControlModel();
		payloadControl6.setOption("PID_PASSWORD");
		payloadControl6.setValue(userPwd);
		payloadControlList.add(payloadControl6);

		PayloadControlModel payloadControl7 = new PayloadControlModel();
		payloadControl7.setOption("VERBOSE");
		payloadControl7.setValue("Y");
		payloadControlList.add(payloadControl7);

		PayloadControlModel payloadControl8 = new PayloadControlModel();
		payloadControl8.setOption("PRODUCT_OPTION");
		payloadControl8.setValue("01");
		payloadControlList.add(payloadControl8);

		PayloadControlModel payloadControl9 = new PayloadControlModel();
		payloadControl9.setOption("DETAIL_REQUEST");
		payloadControl9.setValue("D");
		payloadControlList.add(payloadControl9);

		PayloadControlModel payloadControl10 = new PayloadControlModel();
		payloadControl10.setOption("VENDOR");
		payloadControl10.setValue("123");
		payloadControlList.add(payloadControl10);

		PayloadControlModel payloadControl11 = new PayloadControlModel();
		payloadControl11.setOption("VENDOR_VERSION");
		payloadControl11.setValue("11");
		payloadControlList.add(payloadControl11);

		PayloadControlModel payloadControl12 = new PayloadControlModel();
		payloadControl12.setOption("BROKER_NUMBER");
		payloadControl12.setValue("");
		payloadControlList.add(payloadControl12);

		PayloadControlModel payloadControl13 = new PayloadControlModel();
		payloadControl13.setOption("END_USER");
		payloadControl13.setValue("");
		payloadControlList.add(payloadControl13);

		PayloadControlModel payloadControl14 = new PayloadControlModel();
		payloadControl14.setOption("FREEZE_KEY_PIN");
		payloadControl14.setValue("");
		payloadControlList.add(payloadControl14);

		String authenticationKey = "";
		String associationKey = "";

		if (!isInitialRequest) {
			if (isSilentAuthFlow) {
				authenticationKey = resultVo.getBokuAuthenticationKey();
				associationKey = resultVo.getBokuCorrelationId();
			}
			else if (isOTPflow || isBokuOTPflow) {
				authenticationKey = resultVo.getBokuAuthenticationKey();
				associationKey = resultVo.getBokuCorrelationId();
			}
			
			CustomLogger.debug(this.getClass(), "Process check: Service prepareCrossCoreRequest for Resume Call" 
					+ " >WorkflowRequestType:" + resultVo.getWorkflowRequestType() 
					+ " >associationKey:" + associationKey 
					+ " >authenticationKey:" + authenticationKey);
		}
		
		PayloadControlModel payloadControl15 = new PayloadControlModel();
		payloadControl15.setOption("AUTHENTICATION_KEY");
		payloadControl15.setValue(authenticationKey);
		payloadControlList.add(payloadControl15);
		
		PayloadControlModel payloadControl16 = new PayloadControlModel();
		payloadControl16.setOption("ASSOCIATION_KEY");
		payloadControl16.setValue(associationKey);
		payloadControlList.add(payloadControl16);

		/* CONTACT */
		List<PayloadContactModel> payloadContactList = new ArrayList<>();

		PayloadContactModel payloadContact1 = new PayloadContactModel();
		payloadContact1.setId("APPLICANT_CONTACT_ID_1");

		/* CONTACT - Person */
		ContactPersonModel contactPerson = new ContactPersonModel();
		contactPerson.setTypeOfPerson("");
		contactPerson.setPersonIdentifier("");

		/* CONTACT - Person Names */
		List<PersonNameModel> personNameList = new ArrayList<>();
		PersonNameModel personName1 = new PersonNameModel();
		personName1.setId("");

		personName1.setFirstName(resultVo.getFirstName().trim());
		personName1.setSurName(resultVo.getLastName().trim());
		personName1.setNameSuffix("");
		personName1.setMiddleNames(resultVo.getMiddleName());

		personNameList.add(personName1);
		contactPerson.setNames(personNameList);
		
		/* CONTACT - Person Addresses */
		List<ContactAddressModel> contactAddressList = new ArrayList<>();
		ContactAddressModel contactAddress1 = new ContactAddressModel();
		contactAddress1.setId("Main_Contact_Address_0");
		contactAddress1.setAddressType("CURRENT");
		contactAddress1.setPoBoxNumber("");
		
		contactAddress1.setStreet(resultVo.getAddressLine1());
		contactAddress1.setStreet2("");
		contactAddress1.setPostTown(resultVo.getCity().trim());
		contactAddress1.setPostal(resultVo.getPostalCode().trim()); 
		contactAddress1.setStateProvinceCode(resultVo.getStateProvince());
		contactAddressList.add(contactAddress1);

		/* CONTACT - Person Telephones */
		List<ContactTelephoneModel> contactTelephoneList = new ArrayList<>();
		ContactTelephoneModel contactTelephone = new ContactTelephoneModel();
		contactTelephone.setId("Main_Phone_0");
		
		String mobileNumber = resultVo.getMobileNumber().trim();

		if (StringUtils.isEmpty(mobileNumber) || "+1".equalsIgnoreCase(mobileNumber)) {
			RpDeviceReputation deviceReputation = rpDeviceReputationService.findByPersonId(personVo.getId());
			mobileNumber = deviceReputation.getMobilePhoneNumber();

			if (StringUtils.isEmpty(mobileNumber)) {
				Person person = personService.findByUid(String.valueOf(personVo.getId()));
				PersonData personData = person.getPersonData();
				mobileNumber = personData.getPhoneINT();
			}
		}
		
		contactTelephone.setNumber(mobileNumber);
		contactTelephoneList.add(contactTelephone);

		/* CONTACT - Person Emails */
		List<ContactEmailModel> contactEmailList = new ArrayList<>();
		ContactEmailModel contactEmail = new ContactEmailModel();
		contactEmail.setId("MAIN_EMAIL_0");
		contactEmail.setType("");
		contactEmail.setEmail(resultVo.getEmailAddress().trim());
		contactEmailList.add(contactEmail);

		/* CONTACT - Person IdentityDocuments */
		
		List<ContactIdentityDocumentModel> contactIdentityDocumentList = new ArrayList<>();
		ContactIdentityDocumentModel contactIdentityDoc = new ContactIdentityDocumentModel();
		contactIdentityDoc.setDocumentNumber("");
		contactIdentityDoc.setHashedDocumentNumber("");
		contactIdentityDoc.setDocumentType("SSN");
		contactIdentityDocumentList.add(contactIdentityDoc);

		payloadContact1.setPerson(contactPerson);
		payloadContact1.setAddresses(contactAddressList);
		payloadContact1.setTelephones(contactTelephoneList);
		payloadContact1.setEmails(contactEmailList);
		payloadContact1.setIdentityDocuments(contactIdentityDocumentList);
		
		payloadContactList.add(payloadContact1);

		/* APPLICATION */
		PayloadApplicationModel payloadApplication = new PayloadApplicationModel();

		if (!isInitialRequest && (isOTPflow || isBokuOTPflow)) {
			payloadApplication.setOneTimePasscode(resultVo.getBokuOneTimePasscode());
		}
		
		ApplicationProductDetailModel productDetail = new ApplicationProductDetailModel();
		productDetail.setProductType("");
		payloadApplication.setProductDetails(productDetail);

		List<ApplicationApplicantModel> applicationApplicantList = new ArrayList<>();
		ApplicationApplicantModel applicationApplicant1 = new ApplicationApplicantModel();
		applicationApplicant1.setId("APPLICANT_ID_1");
		applicationApplicant1.setContactId("APPLICANT_CONTACT_ID_1");
		applicationApplicant1.setApplicantType("APPLICANT");
		applicationApplicant1.setConsentId("y");
		applicationApplicant1.setConsentTimeStamp(messageTime);
		applicationApplicantList.add(applicationApplicant1);
        	 
		payloadApplication.setApplicants(applicationApplicantList);
		
		requestPayload.setControl(payloadControlList);
		requestPayload.setContacts(payloadContactList);
		requestPayload.setApplication(payloadApplication);

		ccRequest.setHeader(requestHeader);
		ccRequest.setPayload(requestPayload);

		Gson g = new GsonBuilder().disableHtmlEscaping().create();

		String requestHeaderJson = g.toJson(requestHeader);
		String contactDataJson = g.toJson(payloadContactList);

		requestHeaderJson = requestHeaderJson.replace(" ", "");
		contactDataJson = contactDataJson.replace(" ", "");

		if (requestHeaderJson.length() > 400) {
			requestHeaderJson = requestHeaderJson.substring(0, 400);
		}
		if (contactDataJson.length() > 2000) {
			contactDataJson = contactDataJson.substring(0, 2000);
		}

		resultVo.setRequestHeaderJson(requestHeaderJson);
		resultVo.setContactDataJson(contactDataJson);
		resultVo.setClientReferenceId(requestHeader.getClientReferenceId());
		resultVo.setHeaderMessageTime(requestHeader.getMessageTime());

		return ccRequest;
	}
	
	/**** PROCESS CROSSCORE WEB SERVICE RESPONSE ****/

	@Override
	public void extractCrossCoreResponseData(JSONObject ccResponseJsonObj, ExperianResultVo resultVo) {
		CustomLogger.enter(this.getClass());

		extractResponseHeaderData(ccResponseJsonObj, resultVo);
		extractResponseDecisionData(ccResponseJsonObj, resultVo);
		extractResponseOriginalData(ccResponseJsonObj, resultVo);
	}

	private void extractResponseHeaderData(JSONObject ccResponseJsonObj, ExperianResultVo resultVo) {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();

		JSONObject responseHeaderObj = (JSONObject) ccResponseJsonObj.get("responseHeader");
		if (responseHeaderObj != null) {
			JSONObject overallResponseObj = (JSONObject) responseHeaderObj.get("overallResponse");
			String headerOverallDecision = null;
			String headerOverallDecisionText = null;

			if (overallResponseObj != null) {
				headerOverallDecision = (String) overallResponseObj.get(FIELD_DECISION);
				headerOverallDecisionText = (String) overallResponseObj.get(FIELD_DECISION_TEXT);
				resultVo.setHeaderOverallDecision(headerOverallDecision);
				resultVo.setHeaderOverallDecisionText(headerOverallDecisionText);
			} 

			String headerRequestType = (String) responseHeaderObj.get(FIELD_REQUEST_TYPE);
			String headerClientReferenceId = (String) responseHeaderObj.get(FIELD_CLIENT_REFERENCE_ID);
			String headerExpRequestId = (String) responseHeaderObj.get(FIELD_EXP_REQUEST_ID);
			String headerResponseCode = (String) responseHeaderObj.get(FIELD_RESPONSE_CODE);
			String headerResponseMessage = (String) responseHeaderObj.get(FIELD_RESPONSE_MESSAGE);

			resultVo.setHeaderRequestType(headerRequestType);
			resultVo.setHeaderClientReferenceId(headerClientReferenceId);
			resultVo.setHeaderExpRequestId(headerExpRequestId);
			resultVo.setHeaderResponseCode(headerResponseCode);
			resultVo.setHeaderResponseMessage(headerResponseMessage);
			
			String responseHeaderJson = g.toJson(responseHeaderObj);
			responseHeaderJson = responseHeaderJson != null ? responseHeaderJson.replace(" ", "") : "";

			if (responseHeaderJson.length() > 1000) {
				responseHeaderJson = responseHeaderJson.substring(0, 1000);
				CustomLogger.debug(this.getClass(), "Process check: Service extractResponseHeaderData> responseHeader Json length > 1000.");
			}

	        if (!IPSConstants.ENV_PROD.equalsIgnoreCase(Utils.getEnvironmentWithoutDot())) {  
	        	if ("frameworkMappingErrorUser".equalsIgnoreCase(resultVo.getTestScenario())) {
	        		if (responseHeaderJson.contains("WorkflowPaused")) {
	        			responseHeaderJson = responseHeaderJson.replace("WorkflowPaused", "FrameworkMapperError");
	        		}
	        		else {
	        			responseHeaderJson += "FrameworkMapperError";
	        		}
	        	}
	        }
	        
			resultVo.setResponseHeaderJson(responseHeaderJson);
		} 
	}

	@Override
	public void extractResponseDecisionData(JSONObject ccResponseJsonObj, ExperianResultVo resultVo) {
		
		JSONObject clientResponsePayloadObj = (JSONObject) ccResponseJsonObj.get(FIELD_CLIENT_RESPONSE_PAYLOAD);
		resultVo.clearOrchDecisionJson();
		resultVo.clearDecisionElementJson();

		if (clientResponsePayloadObj != null) {
			String workflowRequestType = resultVo.getWorkflowRequestType();
			String elementRequestType = "";

			boolean isSilentAuthFlow = ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW.equalsIgnoreCase(workflowRequestType);
			boolean isOTPflow = ExperianResultVo.WORKFLOW_REQUEST_TYPE_OTP_FLOW.equalsIgnoreCase(workflowRequestType);
			boolean isBokuOTPflow = ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW.equalsIgnoreCase(workflowRequestType);		
			boolean isInitialRequest= resultVo.isInitialRequest();	

			JSONArray decisionElementsArr = (JSONArray) clientResponsePayloadObj.get(FIELD_DECISION_ELEMENTS);
			JSONArray orchestrationDecisionsArr = (JSONArray) clientResponsePayloadObj.get(FIELD_ORCHESTRATION_DECISIONS);
			boolean hasDecisionData = (decisionElementsArr != null && !decisionElementsArr.isEmpty())
					&& (orchestrationDecisionsArr != null && !orchestrationDecisionsArr.isEmpty());
			
			if (hasDecisionData) {
				int orchDecArraySize = orchestrationDecisionsArr.size();

				for (int i = 0; i < orchDecArraySize; i++) {
					JSONObject decisionElement = (JSONObject) decisionElementsArr.get(i);
					JSONObject orchDecisionItem = (JSONObject) orchestrationDecisionsArr.get(i);
	
					String sequenceId = (String) orchDecisionItem.get(FIELD_SEQUENCE_ID);
					String decisionSource = (String) orchDecisionItem.get(FIELD_DECISION_SOURCE);

					resultVo.setExpSequenceId(sequenceId);
					resultVo.setDecisionSource(decisionSource);

					if (isSilentAuthFlow || isOTPflow || isBokuOTPflow) {
						if (isInitialRequest) {
							if ("1".equals(sequenceId)) {
								if (isBokuOTPflow) {
									elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_SEND_OTP;
									resultVo.setElementRequestType(elementRequestType);
		
									evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo, elementRequestType);
		
									if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuSendOtpDecision())) {
										break;
									}
								}
								else {
									elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_PRECISEID_ONLY;
									resultVo.setElementRequestType(elementRequestType);
										
									evaluatePreciseIdResponse(decisionElement, orchDecisionItem, resultVo);
												
									if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getPreciseIdDecision())) {
										break;
									}
								}
							} else if ("2".equals(sequenceId)) {
								if (isBokuOTPflow) {
									elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_VALIDATE_OTP;
									resultVo.setElementRequestType(elementRequestType);
									evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo, elementRequestType);
		
									if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuValidateOtpDecision())) {
										break;
									}
								}
								else {
									elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_SERVICE_INFO;
									resultVo.setElementRequestType(elementRequestType);
									evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo,
											elementRequestType);
			
									JSONObject decisionElemData = new JSONObject();
									decisionElemData.put(FIELD_SEQUENCE_ID, sequenceId);
		
									if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuServiceInfoDecision())) {
										break;
									}
								}
							} else if ("3".equals(sequenceId)) {
								elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_SCORE_INFO;
								resultVo.setElementRequestType(elementRequestType);
								
								evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo,
										elementRequestType);
		
								if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuScoreInfoDecision())) {
									break;
								}
							} else if ("4".equals(sequenceId) && isSilentAuthFlow) {
								elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_PNV_REQ;
								resultVo.setElementRequestType(elementRequestType);
								
								evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo,
										elementRequestType);

								resultVo.setSilentAuthReferenceId(resultVo.getBokuPNVReqReferenceId());
								resultVo.setSilentAuthCorrelationId(resultVo.getBokuPNVReqCorrelationId());
									
								if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuPNVReqInfoDecision())) {
									break;
								}
							}
							else if ("4".equals(sequenceId) && isOTPflow) {
								elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_SEND_OTP;
								resultVo.setElementRequestType(elementRequestType);
	
								evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo, elementRequestType);
	
								if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuSendOtpDecision())) {
									break;
								}
							}
						} 
						// Not isInitialRequest
						else {
							if ("1".equals(sequenceId) && isBokuOTPflow) {
								elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_SEND_OTP; 
								resultVo.setElementRequestType(elementRequestType);
								evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo, elementRequestType);
		
								if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuSendOtpDecision())) {
									break;
								}
							} 
							else if ("2".equals(sequenceId) && isBokuOTPflow) {
								elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_VALIDATE_OTP; 
								resultVo.setElementRequestType(elementRequestType);
								evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo, elementRequestType);
		
								if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuValidateOtpDecision())) {
									break;
								}
							} 
							else if ("5".equals(sequenceId) && isSilentAuthFlow) {
								elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_PNV_RES;
								resultVo.setElementRequestType(elementRequestType);
									
								evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo, elementRequestType);
	
								if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuPNVResInfoDecision())) {
									break;
								}
							}
							else if ("5".equals(sequenceId) && isOTPflow) {
								elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_VALIDATE_OTP;
								resultVo.setElementRequestType(elementRequestType);
								
								evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo, elementRequestType);
		
								if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuValidateOtpDecision())) {
									break;
								}
							} 
						}
					} 
					else if (isBokuOTPflow){
						if (isInitialRequest) {
							if ("1".equals(sequenceId)) {
								elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_SEND_OTP;
								resultVo.setElementRequestType(elementRequestType);
	
								evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo, elementRequestType);
		
								if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuSendOtpDecision())) {
									break;
								}
							}
						}
						// Not isInitialRequest got BokuOTPFlow
						else {
							if ("2".equals(sequenceId)) {
								elementRequestType = ExperianResultVo.APP_REQUEST_TYPE_BOKU_VALIDATE_OTP;
								resultVo.setElementRequestType(elementRequestType);
								
								evaluateBokuServiceResponse(decisionElement, orchDecisionItem, resultVo, elementRequestType);
	
								if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getBokuValidateOtpDecision())) {
									break;
								}
							} 
						}
					}
				}
			}
			else {
				CustomLogger.debug(this.getClass(), "Process check: Service extractResponseDecisionData> There is no decision data.");			
			}
		} 
		else {
			CustomLogger.debug(this.getClass(), "Process check: Service extractResponseDecisionData> clientResponsePayloadObj is null");
		}
		
		String orchDecisionJson = "";
		Map<String, String> orchDecisionJsonMap = resultVo.getOrchDecisionJsonMap();
		
		for (String key : orchDecisionJsonMap.keySet()) {
			orchDecisionJson += (orchDecisionJson.isEmpty()? "" : ", ") +  orchDecisionJsonMap.get(key);
		}
		resultVo.setOrchDecisionJson(orchDecisionJson);
		
		String decisionElementJson = "";
		Map<String, String> decisionElementJsonMap = resultVo.getDecisionElementJsonMap();
		for (String key : decisionElementJsonMap.keySet()) {
			decisionElementJson += (decisionElementJson.isEmpty()? "" : ", ") +  decisionElementJsonMap.get(key);
		}
		resultVo.setDecisionElementJson(decisionElementJson);
	}

	public void extractResponseOriginalData(JSONObject ccResponseJsonObj, ExperianResultVo resultVo) {
		CustomLogger.enter(this.getClass());

		if (!resultVo.isInitialRequest()) {
			return;
		}

		String debugMsg = "Service extractResponseOriginalData> Method was called.";
		CustomLogger.debug(this.getClass(), debugMsg);

		Gson g = new Gson();

		JSONObject originalRequestDataObj = (JSONObject) ccResponseJsonObj.get(FIELD_ORIGINAL_REQUEST_DATA);

		if (originalRequestDataObj != null) {
			JSONArray contactsArr = (JSONArray) originalRequestDataObj.get(FIELD_CONTACTS);
			String contactDataJson = g.toJson(contactsArr);

			resultVo.setContactDataJson(contactDataJson);
		} else {
			debugMsg = "Service extractResponseOriginalData> originalRequestData was not found.";
			CustomLogger.debug(this.getClass(), debugMsg);
		}
	}

	/**** PROCESS PRECISEID RESPONSE DATA ****/

	private void evaluatePreciseIdResponse(JSONObject decisionElement, JSONObject orchDecisionItem,
			ExperianResultVo resultVo) {
		CustomLogger.enter(this.getClass());
	
		if (decisionElement == null || orchDecisionItem == null) {
			return;
		}

		Gson g = new Gson();
		JSONObject orchDecisionData = new JSONObject();
		JSONObject decisionElemData = new JSONObject();

		decisionElemData.put(FIELD_BACKING_APP, ExperianResultVo.APP_REQUEST_TYPE_PRECISEID_ONLY);
		
		JSONArray warningsErrorsArr = (JSONArray) decisionElement.get(FIELD_WARNING_ERRORS);
		if (warningsErrorsArr != null && !warningsErrorsArr.isEmpty()) {
			orchDecisionData.put(FIELD_WARNING_ERRORS, warningsErrorsArr);

			for (int e = 0; e < warningsErrorsArr.size(); e++) {
				JSONObject errorJsonObj = (JSONObject) warningsErrorsArr.get(e);
				String responseMessage = (String) errorJsonObj.get(FIELD_RESPONSE_MESSAGE);
				
				CustomLogger.debug(this.getClass(), "Service evaluatePreciseIdResponse> Element has warningsErrors :" + responseMessage); 
			}
		}

		String decision = (String) orchDecisionItem.get(FIELD_DECISION);
		String sequenceId = (String) orchDecisionItem.get(FIELD_SEQUENCE_ID);
		String decisionSource = (String) orchDecisionItem.get(FIELD_DECISION_SOURCE);
		String decisionText = (String) orchDecisionItem.get(FIELD_DECISION_TEXT);

		orchDecisionData.put(FIELD_SEQUENCE_ID, sequenceId);
		orchDecisionData.put(FIELD_DECISION, decision);
		orchDecisionData.put(FIELD_DECISION_SOURCE, decisionSource);
			
		JSONArray decisionReasonsArr = (JSONArray) orchDecisionItem.get(FIELD_DECISION_REASONS);
		if (decisionReasonsArr != null && !decisionReasonsArr.isEmpty()) {
			orchDecisionData.put(FIELD_DECISION_REASONS, decisionReasonsArr);
		}
		
		resultVo.putOrchDecisionJson(ExperianResultVo.APP_REQUEST_TYPE_PRECISEID_ONLY,  g.toJson(orchDecisionData));

		resultVo.setPreciseIdDecision(ExperianResultVo.SERVICE_RESULT_FAILED);
		
		if (decision != null) {
			if (ExperianResultVo.SERVICE_DECISION_CONTINUE.equalsIgnoreCase(decision)) {
				resultVo.setPreciseIdDecision(ExperianResultVo.SERVICE_RESULT_PASSED);
			}
			else if (ExperianResultVo.SERVICE_DECISION_INVESTIGATE.equalsIgnoreCase(decision) 
					|| (decisionText != null && (decisionText.contains("093") || decisionText.contains("3001")))) {
				resultVo.setPreciseIdDecision(ExperianResultVo.SERVICE_DECISION_INVESTIGATE);
				String exclusionCodes = decisionText.length() > 20? decisionText.substring(0,20) : decisionText;
				resultVo.setPreciseIdExclusionCodes(exclusionCodes);
			}
			else {
				resultVo.setPreciseIdDecision(ExperianResultVo.SERVICE_RESULT_FAILED);
			}
			
			String appReference = (String) decisionElement.get(FIELD_APP_REFERENCE);
			resultVo.setTransactionId(appReference);
		} 

		if (ExperianResultVo.SERVICE_RESULT_FAILED.equalsIgnoreCase(resultVo.getPreciseIdDecision())) {
			resultVo.setFinalDecision(ExperianResultVo.SERVICE_DECISION_REFER);
			resultVo.setRequestComplete(true);
		}

		CustomLogger.debug(this.getClass(), "Service evaluatePreciseIdResponse> Final PreciseIdOnly decision:" + resultVo.getPreciseIdDecision());
	}

	/**** PROCESS BOKU SERVICES RESPONSE DATA ****/

	private void evaluateBokuServiceResponse(JSONObject decisionElement, JSONObject orchDecisionItem,
			ExperianResultVo resultVo, String elementRequestType) {
		
		CustomLogger.debug(this.getClass(), "Service evaluateBokuServiceResponse>  elementRequestType:" + elementRequestType); 

		if (decisionElement == null) {
			CustomLogger.debug(this.getClass(), String.format("%s has no decisionElement.", elementRequestType));
			return;
		}

		if (resultVo.isTestMode()) {
			setTestUserScenarioDecision(orchDecisionItem, resultVo, elementRequestType); 
		}
		
		Gson g = new Gson();
		JSONObject orchDecisionData = new JSONObject();		
		String sequenceId = (String) orchDecisionItem.get(FIELD_SEQUENCE_ID);
		String decisionValue = (String) orchDecisionItem.get(FIELD_DECISION);
		String decisionSource = (String) orchDecisionItem.get(FIELD_DECISION_SOURCE);
		
		orchDecisionData.put(FIELD_SEQUENCE_ID, sequenceId);
		orchDecisionData.put(FIELD_DECISION, decisionValue);
		orchDecisionData.put(FIELD_DECISION_SOURCE, decisionSource);
		
		JSONArray decisionReasonsArr = (JSONArray) orchDecisionItem.get(FIELD_DECISION_REASONS);
		if (decisionReasonsArr != null && !decisionReasonsArr.isEmpty()) {
			orchDecisionData.put(FIELD_DECISION_REASONS, decisionReasonsArr);
		}
		
		resultVo.putOrchDecisionJson(elementRequestType,  g.toJson(orchDecisionData));
		
		boolean orchDecisionPass = decisionValue != null
				&& (ExperianResultVo.SERVICE_DECISION_CONTINUE.equalsIgnoreCase(decisionValue)
						|| ExperianResultVo.SERVICE_DECISION_ACCEPT.equalsIgnoreCase(decisionValue));
		
		JSONObject decisionElemData = new JSONObject();
		decisionElemData.put(FIELD_BACKING_APP, elementRequestType);

		JSONArray decisionsArr = (JSONArray) decisionElement.get("decisions");
		if (decisionsArr != null && !decisionsArr.isEmpty()) {
			decisionElemData.put("decisions", decisionsArr);
		}

		JSONArray scoresArr = (JSONArray) decisionElement.get(FIELD_SCORES);
		if (scoresArr != null && !scoresArr.isEmpty()) {
			decisionElemData.put(FIELD_SCORES, scoresArr);
		}
		
		JSONObject otherDataObj = (JSONObject) decisionElement.get(FIELD_OTHER_DATA);
		JSONObject otherDataObjMod = new JSONObject();
		
		if (otherDataObj != null) {
			CustomLogger.debug(this.getClass(), "Service evaluateBokuServiceResponse 1b> elementRequestType:" + elementRequestType 
					+ ", >resultVo.getBokuPNVReqInfoDecision:" + resultVo.getBokuPNVReqInfoDecision()
			+ ", >resultVo.getBokuAuthenticationUrl:" + resultVo.getBokuAuthenticationUrl()
			+ "> otherDataObj:" + g.toJson(otherDataObj));

			JSONObject responseObj = (JSONObject) otherDataObj.get(FIELD_RESPONSE);
			JSONObject responseObjMod = new JSONObject();

			if (responseObj != null) {
				String correlationId = (String) responseObj.get(FIELD_CORRELATION_ID);
				responseObjMod.put(FIELD_CORRELATION_ID, correlationId);
				
				if (ExperianResultVo.APP_REQUEST_TYPE_BOKU_PNV_REQ.equalsIgnoreCase(elementRequestType)) {
					String referenceId = (String) responseObj.get(FIELD_REFERENCE_ID);
					responseObjMod.put(FIELD_REFERENCE_ID, referenceId);
					
					String evurl = (String) responseObj.get(FIELD_EV_URL);

					if (evurl == null) {
						evurl = resultVo.getBokuAuthenticationUrl();
					}
					
					if (evurl != null && evurl.length() > 600) {
						CustomLogger.error(this.getClass(), "Boku evurl length is > 600. It was truncated"); 
					}
					
					resultVo.setBokuAuthenticationUrl(evurl);
					
					// To be passed as authenticationKey in BokuPNVRes (2nd SilentAuithFlow Request)
					resultVo.setBokuPNVReqReferenceId(referenceId); 
					resultVo.setSilentAuthReferenceId(referenceId);
					
					CustomLogger.debug(this.getClass(), "Service evaluateBokuServiceResponse 2> elementRequestType:" + elementRequestType 
							+ ", >resultVo.getBokuPNVReqInfoDecision:" + resultVo.getBokuPNVReqInfoDecision()
					+ ", >resultVo.getBokuAuthenticationUrl:" + resultVo.getBokuAuthenticationUrl());

							
					// Same as clientReferenceID. To be passed as AssociationKey in BokuPNVRes
					resultVo.setBokuPNVReqCorrelationId(correlationId); 
					resultVo.setSilentAuthCorrelationId(correlationId);
				} else if (ExperianResultVo.APP_REQUEST_TYPE_BOKU_SEND_OTP.equalsIgnoreCase(elementRequestType)) {
					String authenticationKey = (String) responseObj.get(FIELD_AUTHENTICATION_KEY);
					responseObjMod.put(FIELD_AUTHENTICATION_KEY, authenticationKey);
					
					// To be passed as authenticationKey in BokuValidateOtp Request
					resultVo.setBokuAuthenticationKey(authenticationKey);
					// To be passed as AssociationKey in BokuValidateOtp Request
					resultVo.setBokuCorrelationId(correlationId); 
					CustomLogger.debug(this.getClass(), "Service evaluateBokuServiceResponse > authenticationKey:" + authenticationKey
						+ ", correlationId:" + correlationId);
				}
			}
			
			otherDataObjMod.put(FIELD_RESPONSE, responseObjMod);
		}
		
		decisionElemData.put(FIELD_OTHER_DATA, otherDataObjMod);
		decisionElemData.put(FIELD_APP_REFERENCE, decisionElement.get(FIELD_APP_REFERENCE));
		decisionElemData.put(FIELD_SERVICE_NAME, decisionElement.get(FIELD_SERVICE_NAME));
		
		JSONArray warningsErrorsArr = (JSONArray) decisionElement.get(FIELD_WARNING_ERRORS);
		if (warningsErrorsArr != null && !warningsErrorsArr.isEmpty()) {
			decisionElemData.put(FIELD_WARNING_ERRORS, warningsErrorsArr);

			CustomLogger.debug(this.getClass(), "Service evaluateBokuServiceResponse > has warningsErrors for elementRequestType:" + elementRequestType
					+ "> warningsErrorsArr:" + g.toJson(warningsErrorsArr));

			for (int e = 0; e < warningsErrorsArr.size(); e++) {
				JSONObject errorJsonObj = (JSONObject) warningsErrorsArr.get(e);
				String responseCode = (String) errorJsonObj.get(FIELD_RESPONSE_CODE);
				String responseMessage = (String) errorJsonObj.get(FIELD_RESPONSE_MESSAGE);

				if (Utils.isEmptyString(resultVo.getWarningResponseMessage())) {
					resultVo.setWarningResponseMessage(responseMessage);
					resultVo.setWarningResponseCode(responseCode);
					if ("-5013".equals(responseCode)) {
						resultVo.setErrorMessage(IPSConstants.PASSCODE_EXPIRED_MSG);
						resultVo.setPasscodeExpired(true);
					}
					// responseCode: -5023 - An invalid OTP passcode was provided
					// responseCode: -5004 - An invalid parameter was passed (i.e. passcode with less than the required length) 
					else if ("-5023".equals(responseCode) || "-5004".equals(responseCode)) {
						resultVo.setErrorMessage(IPSConstants.PASSCODE_INVALID_NUMBER_MSG);
					}
				}
			}
		}
		
		resultVo.putDecisionElementJson(elementRequestType,  g.toJson(decisionElemData));
	
		String overallDecision = orchDecisionPass ? ExperianResultVo.SERVICE_RESULT_PASSED	: ExperianResultVo.SERVICE_RESULT_FAILED;

		CustomLogger.debug(this.getClass(), String.format("%s > orchDecisionPass: %s", elementRequestType, orchDecisionPass));

		switch (elementRequestType) {
			case ExperianResultVo.APP_REQUEST_TYPE_BOKU_SERVICE_INFO:
				resultVo.setBokuServiceInfoDecision(overallDecision);
				break;
			case ExperianResultVo.APP_REQUEST_TYPE_BOKU_SCORE_INFO:
				resultVo.setBokuScoreInfoDecision(overallDecision);
				break;
			case ExperianResultVo.APP_REQUEST_TYPE_BOKU_PNV_REQ:
				resultVo.setBokuPNVReqInfoDecision(overallDecision);
				break;
			case ExperianResultVo.APP_REQUEST_TYPE_BOKU_PNV_RES:
				resultVo.setBokuPNVResInfoDecision(overallDecision);
				break;
			case ExperianResultVo.APP_REQUEST_TYPE_BOKU_SEND_OTP:
				resultVo.setBokuSendOtpDecision(overallDecision);
				break;
			case ExperianResultVo.APP_REQUEST_TYPE_BOKU_VALIDATE_OTP:
				resultVo.setBokuValidateOtpDecision(overallDecision);
				break;
			default:
		}
	}
	

	/**** CALL BOKU SILENT AUTHENTICATION URL VALIDATION SERVICE ****/

	@Override
	public JSONObject getAuthenticatePhoneResponse(PersonVo personVo) {
		CustomLogger.enter(this.getClass());

		RpExperianDecisionResult decisionResult = rpExperianDecisionResultService.findByPersonId(personVo.getId());
		long expResultId = decisionResult.getExpResultId();

		RpExperianResponsePayload responsePayload = rpExperianResponsePayloadService.getByResultIdServiceName(expResultId, ExperianResultVo.APP_REQUEST_TYPE_BOKU_PNV_REQ);
		String authenticationUrl = responsePayload.getBokuAuthenticationUrl();

		Resource resource = commonRestService.getClientResource(authenticationUrl);

		try {
			return JSONObject.parse(resource.contentType(MediaType.APPLICATION_JSON).get(String.class));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	/**** CHECK BOKU SILENT AUTHENTICATION URL VALIDATION RESULT ****/

	@Override
	public boolean authenticateBokuUrlSuccessful(PersonVo personVo) {
		CustomLogger.enter(this.getClass());
		JSONObject jsonResponse = getAuthenticatePhoneResponse(personVo);

		int respCode = (int) jsonResponse.get(FIELD_ERROR_CODE);
		String respDesc = (String) jsonResponse.get(FIELD_ERROR_DESCRIPTION);

		return respCode == 0 && ExperianResultVo.BOKU_SERVICE_SUCCESS.equalsIgnoreCase(respDesc);
	}

	/**** CALL BOKU SEND OTP WEB SERVICE (FOR RESEND PASSCODE) ****/

	@Override
	public boolean resendPasscodeSuccessful(Person person, PersonVo personVo)
			throws IPSException, PhoneVerificationException {

		String loaSought = personVo.getProofingLevelSought();
		boolean passcodeSent = false;
		proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_initiated.getValue(), person,
				loaSought);

		try {
			RpEvent rpEvent = rpEventService.findLatestEventByPersonId(person.getPersonId());

			ExperianResultVo resultVo = new ExperianResultVo();

			resultVo.setProofingAction(ACTION_RESEND_PASSCODE);
			initializeExperianResultVo(personVo, resultVo);

			callBokuSendOtpWorkflow(person, personVo, resultVo, null, rpEvent);

			passcodeSent = ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuSendOtpDecision());

		} catch (Exception ex) {
			CustomLogger.error(this.getClass(), "Exception occurred during the Experian OTP call for user: "
					+ personVo.getSponsorUserId() + " " + personVo.getFullName(), ex);
			throw new PhoneVerificationException(ex.getMessage());
		}

		return passcodeSent;
	}

	/**** CALL BOKU VALIDATE OTP WEB SERVICE ****/

	@Override
	public boolean confirmPasscodeSuccessful(Person person, PersonVo personVo, RpEvent event)
			throws IPSException, PhoneVerificationException {

		boolean passcodeConfirmed = false;
		String loaSought = personVo.getProofingLevelSought();

		proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_confirmation_initiated.getValue(), person,
				loaSought);
		
		long otpExpiresMinutes = 5;	// Minutes the pass code will expire
		
		// This is to test otpExpiresMinutes other than 5 (i.e. < 5 minutes) only for lower environments
        if (!IPSConstants.ENV_PROD.equalsIgnoreCase(Utils.getEnvironmentWithoutDot()) && personVo.getOtpExpiresMinutes() != null) {  
        	otpExpiresMinutes = Long.parseLong(personVo.getOtpExpiresMinutes());
        }
        
		RpEvent rpEvent = rpEventService.findLatestEventByPersonId(person.getPersonId());
		ExperianResultVo resultVo = new ExperianResultVo();
		
		// Check if pass code is expired then set appropriate error message if it is
		if (personVo.isWebServiceCall()) {
			long supplierId = RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID;
			RpOtpAttempt latestAttempt = rpOtpAttemptDataService.getLatestOtpAttempt(person.getPersonId(), supplierId, event.getEventId());
			
			if (latestAttempt != null) {
				Date minutesAgo = new Date(System.currentTimeMillis() - otpExpiresMinutes*60*1000);
	            boolean moreThanXminutes = minutesAgo.compareTo(latestAttempt.getOtpSentDateTime()) > 0;

	            if (moreThanXminutes) {
	            	personVo.setErrorMessage(IPSConstants.PASSCODE_EXPIRED_MSG);
	            	personVo.setPasscodeExpired(true);
	            	resultVo.setPasscodeExpired(true);
	            }
			}
		}
		else {
			if (rpEvent.hasPasscodeExpired(otpExpiresMinutes)) {
				personVo.setErrorMessage(IPSConstants.PASSCODE_EXPIRED_MSG);
				personVo.setPasscodeExpired(true);
				return false;
			}
		}

		if (resultVo.isPasscodeExpired()) {
			experianDataService.saveExpiredPasscode(resultVo, personVo, rpEvent); 
			return false;
	    }

		try {
			RpExperianDecisionResult decisionResult = rpExperianDecisionResultService.findByPersonId(personVo.getId());
			String passcode = personVo.getPasscode();
			
			resultVo.setBokuOneTimePasscode(passcode);
			resultVo.setBearerToken(null);
			resultVo.setInitialRequest(false);
			resultVo.setExpResultId(decisionResult.getExpResultId());

			try {
				//Get the latest RpExperianHeaderData
				RpExperianHeaderData headerData = rpExperianHeaderDataService.getByResultId(decisionResult.getExpResultId());
				
				if (headerData != null) {
					String initialRequestType = headerData.getRequestType();
					resultVo.setInitialRequestType(initialRequestType);
				}
				
				String workflowRequestType = headerData != null? headerData.getRequestType() : "";
				resultVo.setWorkflowRequestType(workflowRequestType);

				resultVo.setProofingAction(ACTION_VALIDATE_PASSCODE);
				initializeExperianResultVo(personVo, resultVo);

				if (headerData != null) {
					resultVo.setHeaderClientReferenceId(headerData.getClientReferenceId());
					resultVo.setHeaderExpRequestId(headerData.getExpRequestId());
				}
				
				resultVo.setBokuAuthenticationKey(decisionResult.getAuthenticationKey());
				resultVo.setBokuCorrelationId(decisionResult.getCorrelationId());
			} catch (Exception ex) {
				CustomLogger.error(this.getClass(),
						"Exception occurred during the getCrossCoreResponse call for sponsorUserId: "
								+ personVo.getSponsorUserId() + " " + personVo.getFullName(),
						ex);
				throw new PhoneVerificationException(ex.getMessage());
			}
		
			callCrossCoreWorkflow(person, personVo, rpEvent, null, resultVo);
			
			experianDataService.savePasscodeResult(resultVo, personVo, event);

			passcodeConfirmed = !resultVo.isPasscodeExpired() && ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuValidateOtpDecision());
			
			CustomLogger.debug(this.getClass(), "Service confirmPasscodeSuccessful passcodeConfirmed:" + passcodeConfirmed);
			// Return Truth Data to ThreatMetrix
			truthDataReturnService.returnRemoteProofingTruthData(person, passcodeConfirmed);
			CustomLogger.debug(this.getClass(), "Return Truth Data to ThreatMetrix for Experian OTP Confirmation Result:" 
					+ (passcodeConfirmed? TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_PASS : TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_FAIL) );

			if (passcodeConfirmed) {
				proofingService.updateProofingStatus(RefRpStatus.RpStatus.LOA_level_achieved.getValue(), person,
						loaSought);
			} else {
				proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_confirmation_failed.getValue(), person,
						loaSought);
			}

			experianDataService.assertOtpPhoneVerificationResult(person, personVo, passcodeConfirmed);
			CustomLogger.debug(this.getClass(),
					String.format("Experian passcode validation %s for sponsorUserId: %s",
							(passcodeConfirmed ? IPSConstants.VALUE_PASSED : IPSConstants.VALUE_FAILED),
							person.getSponsorUserId()));
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(), "Exception occurred during the Experian OTP call for user: "
					+ personVo.getSponsorUserId() + " " + personVo.getFullName(), ex);
			throw new PhoneVerificationException(ex.getMessage());
		}

		return passcodeConfirmed;
	}

	/**** CALL BOKU PNV (SILENT AUTHENTICATION) RESUME WEB SERVICE ****/

	@Override
	public boolean silentAuthenticationSuccessful(Person person, PersonVo personVo, ExperianResultVo resultVo)
			throws IPSException, PhoneVerificationException {
		boolean silentAuthSuccessful = false;
		String loaSought = personVo.getProofingLevelSought();

		proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_confirmation_initiated.getValue(), person,
				loaSought);

		RpEvent rpEvent = rpEventService.findLatestEventByPersonId(person.getPersonId());
		RpExperianDecisionResult decisionResult = null;
		try {
			decisionResult = rpExperianDecisionResultService.findByPersonId(personVo.getId());
			resultVo.setWorkflowRequestType(ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW);
			resultVo.setBearerToken(null);
			resultVo.setInitialRequest(false);
			resultVo.setExpResultId(decisionResult.getExpResultId());
			resultVo.setBokuAuthenticationKey(decisionResult.getAuthenticationKey());
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(),
					"Exception occurred during RpExperianDecisionResult findByPersonId call for sponsorUserId: "
							+ personVo.getSponsorUserId() + " " + personVo.getFullName(), ex);
			return silentAuthSuccessful;
		}

		try {
			//Get the latest RpExperianHeaderData
			RpExperianHeaderData headerData = rpExperianHeaderDataService.getByResultId(decisionResult.getExpResultId());
			resultVo.setProofingAction(ACTION_AUTHENTICATE_PHONE);
			initializeExperianResultVo(personVo, resultVo);

			if (headerData != null) {
				resultVo.setHeaderClientReferenceId(headerData.getClientReferenceId());
				resultVo.setHeaderExpRequestId(headerData.getExpRequestId());
			}			
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(),
					"Exception occurred during RpExperianHeaderData getByResultId call for sponsorUserId: "
							+ personVo.getSponsorUserId() + " " + personVo.getFullName(), ex);
			return silentAuthSuccessful;
		}
			
		// Subsequent Request - Resubmit SilentAuthFlow for BokuPNVRes
		try {
		
			CustomLogger.debug(this.getClass(), String.format("Exp Svc > silentAuthenticationSuccessful : "
					+ "TestMode:%s, DeviceTypeMobile:%s, WorkflowRequestType:%s, " 
					+ "InitialRequest:%s, TestScenario:%s, RequestComplete:%s, " 
					+ "PhoneVerificationDecision:%s, PreciseIdDecision:%s, BokuServiceInfoDecision:%s, " 
					+ "BokuScoreInfoDecision:%s, BokuPNVReqInfoDecision:%s, isBokuUrlSuccessfullyInvoked:%s, " 
				    + "BokuPNVResInfoDecision:%s, BokuSendOtpDecision:%s, BokuValidateOtpDecision:%s, PersonId:%s, MobileNumber:%s", 	
					resultVo.isTestMode(), resultVo.isDeviceTypeMobile(), resultVo.getWorkflowRequestType(), 
					resultVo.isInitialRequest(), resultVo.getTestScenario(), resultVo.isRequestComplete(),
					resultVo.getPhoneVerificationDecision(), resultVo.getPreciseIdDecision(), 
					resultVo.getBokuServiceInfoDecision(), resultVo.getBokuScoreInfoDecision(),
					resultVo.getBokuPNVReqInfoDecision(), resultVo.isBokuUrlSuccessfullyInvoked(),
					resultVo.getBokuPNVResInfoDecision(), resultVo.getBokuSendOtpDecision(), 
					resultVo.getBokuValidateOtpDecision(), resultVo.getPersonId(), resultVo.getMobileNumber()));	
			 
			callCrossCoreWorkflow(person, personVo, rpEvent, null, resultVo);

		} catch (Exception ex) {
			CustomLogger.error(this.getClass(),
					"Exception occurred during callCrossCoreWorkflow call for sponsorUserId: "
							+ personVo.getSponsorUserId() + " " + personVo.getFullName(), ex);
			return silentAuthSuccessful;
		}
		
		try {
			silentAuthSuccessful = ExperianResultVo.SERVICE_RESULT_PASSED.equalsIgnoreCase(resultVo.getBokuPNVResInfoDecision());
			resultVo.setBokuUrlSuccessfullyInvoked(silentAuthSuccessful);
					
			// Update ProofingStatus
			Long statusCode = silentAuthSuccessful ? RefRpStatus.RpStatus.LOA_level_achieved.getValue(): RefRpStatus.RpStatus.Silent_Authentication_failed.getValue();
			proofingService.updateProofingStatus(statusCode, person, loaSought);

			// Assert Experian PV Result to CustReg
	        RefSponsorConfiguration assertToCustRegConfig = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
	                RefSponsorConfiguration.ASSERT_TO_CUSTREG);
	        boolean assertToCustReg = ProofingServiceImpl.VALUE_TRUE.equalsIgnoreCase(assertToCustRegConfig.getValue());

			//Use assertOtpPhoneVerificationResult as there's no specific assertion for silent authentication yet
	        if (assertToCustReg) {
	        	experianDataService.assertOtpPhoneVerificationResult(person, personVo, silentAuthSuccessful, true);
	        }
	        
			CustomLogger.debug(this.getClass(),
					String.format("Experian silent authentication %s for sponsorUserId: %s",
							(silentAuthSuccessful ? IPSConstants.VALUE_PASSED : IPSConstants.VALUE_FAILED),
							person.getSponsorUserId()));
			
			// Return Truth Data to ThreatMetrix
			truthDataReturnService.returnRemoteProofingTruthData(person, silentAuthSuccessful);
			CustomLogger.debug(this.getClass(), "Return Truth Data to ThreatMetrix for Experian Silent Authentication Result:" 
					+ (silentAuthSuccessful? TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_PASS : TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_FAIL) );

		} catch (Exception ex) {
			CustomLogger.error(this.getClass(),
					"Exception occurred during assertOtpPhoneVerificationResult call for sponsorUserId: "
							+ personVo.getSponsorUserId() + " " + personVo.getFullName(), ex);
			return silentAuthSuccessful;
		}

		return silentAuthSuccessful;
	}
	
	@Override
	public void initializeExperianResultVo(PersonVo personVo, ExperianResultVo resultVo) {

		boolean isDeviceTypeMobile = isDeviceTypeMobile(personVo);
		resultVo.setDeviceTypeMobile(isDeviceTypeMobile);
		String workflowRequestType = ExperianResultVo.WORKFLOW_REQUEST_TYPE_OTP_FLOW;

		String action = resultVo.getProofingAction();
		boolean isVerifyPhone = ACTION_VERIFY_PHONE.equalsIgnoreCase(action) ;
		boolean isResendPasscode = ACTION_RESEND_PASSCODE.equalsIgnoreCase(action) ;
		boolean isValidatePasscode = ACTION_VALIDATE_PASSCODE.equalsIgnoreCase(action) ;
		boolean isAuthenticatePhone = ACTION_AUTHENTICATE_PHONE.equalsIgnoreCase(action) ;
		
		CustomLogger.debug(this.getClass(), String.format("Experian service debug: Event action is %s.", action));
		
		if (isVerifyPhone) { 
			resultVo.setBearerToken(null);
			resultVo.setInitialRequest(true);
			
			if (isDeviceTypeMobile) {
				workflowRequestType = ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW;
			}
		}
		else if (isResendPasscode) { 
			resultVo.setInitialRequest(true);
			resultVo.setSkipFirstAttemptErrorCheck(true);
			workflowRequestType = ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW;
		}
		else if (isValidatePasscode) { 
			resultVo.setSkipFirstAttemptErrorCheck(true);
			resultVo.setInitialRequest(false);
			
			if (isDeviceTypeMobile) {
				workflowRequestType = ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW;
			}
			else  {
				workflowRequestType = resultVo.getInitialRequestType();
			}
		}
		else if (isAuthenticatePhone) { 
			resultVo.setInitialRequest(false);
			workflowRequestType = ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW;
		}
		else {
			CustomLogger.debug(this.getClass(), "Experian service debug: action is undefined.");
			return;
		}

		resultVo.setWorkflowRequestType(workflowRequestType);
		
		if (personVo.getFirstName() != null) {
			resultVo.setFirstName(personVo.getFirstName().trim().toUpperCase());
		}
		if (personVo.getLastName() != null) {
			resultVo.setFirstName(personVo.getLastName().trim().toUpperCase());
		}
		resultVo.setNameSuffix("");
	
		if (personVo.getMiddleName() != null && personVo.getMiddleName().length() >= 1) {
			resultVo.setMiddleName(personVo.getMiddleName().toUpperCase());
		} else {
			resultVo.setMiddleName("");
		}
		
		resultVo.setAddressLine1(personVo.getAddressLine1());
		resultVo.setCity(personVo.getCity());
		resultVo.setPostalCode(personVo.getPostalCode()); 
		resultVo.setStateProvince(personVo.getStateProvince());
		
		String mobileNumber = personVo.getMobileNumber() != null ? String.format("+1 %s", personVo.getMobileNumber().replace("-","")) : "";
		resultVo.setMobileNumber(mobileNumber);
		resultVo.setEmailAddress(personVo.getEmailAddress() != null ? personVo.getEmailAddress() : "");
		
		/* If isUatMode flag is set to true (or false), the Experian credentials and endpoints for UAT should be configured */
		/* using /RemoteRest/resources/remote/SaveExperianAltApiInfo (refer to Experian runbook for various json requests). */
		/* The config should also be set using /RemoteRest/resources/remote/SaveRefSponsorConfiguration web service with this request: */
		/* {"sponsorCode":"cr","sponsorConfigName":"Use.Exp.Uat.Env","sponsorConfigValue":"??"} where ?? "Y" or "N" */

		/* This flag is used to enable lower environment especially CAT to point to Experian Production environment */
		/* for testing before IVS Production deployment. */
		boolean isUatMode = false;
		RefSponsorConfiguration useUatEnvConfig = refSponsorConfigurationService.getConfigRecord((int) RefSponsor.SPONSOR_ID_CUSTREG, CommonRestServiceImpl.USE_EXP_UAT_ENV);
		
		if (useUatEnvConfig != null && IPSConstants.CONFIG_VALUE_Y.equalsIgnoreCase(useUatEnvConfig.getValue())) {
			isUatMode = true;
			resultVo.setTestMode(true);
		}
		
	   	if (isUatMode) {
			CustomLogger.debug(this.getClass(), "Experian service debug: Using Experian UAT environment.");
		   	long sponsorId = personVo.getSponsorId();
		   	String standInUserName = String.format("%s-%s", personVo.getFirstName(), personVo.getLastName()).toUpperCase();
			Map<String, String> standInUserMap = getStandInUserMap();
	 
			String scenario = standInUserMap.get(standInUserName);

		   	boolean continueDesktopValidateOTPUser = "continueDesktopValidateOTPUser".equalsIgnoreCase(scenario);
		   	boolean continueBokuPNVResUser = "continueBokuPNVResUser".equalsIgnoreCase(scenario);
			boolean continueMobileValidateOTPUser = "continueMobileValidateOTPUser".equalsIgnoreCase(scenario);
			boolean investigatePreciseIdUser = "investigatePreciseIdUser".equalsIgnoreCase(scenario);
		   	boolean stopBokuPNVReqUser = "stopBokuPNVReqUser".equalsIgnoreCase(scenario);
		   	boolean stopBokuServiceInfoUser = "stopBokuServiceInfoUser".equalsIgnoreCase(scenario);
		   	boolean stopBokuScoreInfoUser = "stopBokuScoreInfoUser".equalsIgnoreCase(scenario);
		   	boolean frameworkMappingErrorUser = "frameworkMappingErrorUser".equalsIgnoreCase(scenario);
		   	boolean webTokenErrorUser = "webTokenErrorUser".equalsIgnoreCase(scenario);
			if (continueBokuPNVResUser || continueMobileValidateOTPUser || stopBokuPNVReqUser
					|| frameworkMappingErrorUser || webTokenErrorUser) {
				resultVo.setTestScenario(scenario);
				
				if (isVerifyPhone || isAuthenticatePhone) { 
					//SilentAuthFlow
					resultVo.setDeviceTypeMobile(true);
					setExperianUserData(resultVo, sponsorId, ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW); 
					
					if (continueMobileValidateOTPUser) {
						String mobileNumberMod = resultVo.getMobileNumber();
						
						if (mobileNumberMod.length() > 9) {
							mobileNumberMod = mobileNumberMod.substring(mobileNumberMod.length() - 10, mobileNumberMod.length());
						}
						resultVo.setMobileNumber(mobileNumberMod); 
					}
				}
				else if (isResendPasscode || isValidatePasscode) {  
					//BokuOTPFlow 
					resultVo.setDeviceTypeMobile(true);
					setExperianUserData(resultVo, sponsorId, ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW); 
				}
			}
			else if (continueDesktopValidateOTPUser || investigatePreciseIdUser || stopBokuServiceInfoUser || stopBokuScoreInfoUser) {
				if (continueDesktopValidateOTPUser) {
					resultVo.setTestScenario("continueDesktopValidateOTPUser");
				}
				else if (investigatePreciseIdUser) {
					resultVo.setTestScenario("investigatePreciseIdUser");
				}
				else if (stopBokuServiceInfoUser) {
					resultVo.setTestScenario("stopBokuServiceInfoUser");
				}
				else if (stopBokuScoreInfoUser) {
					resultVo.setTestScenario("stopBokuScoreInfoUser");
				}
				
				if (isVerifyPhone || isValidatePasscode) { 
					if(isValidatePasscode && ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW.equalsIgnoreCase(workflowRequestType)) {
						//BokuOTPFlow 
						setExperianUserData(resultVo, sponsorId, ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW); 
					}
					else {
						//OTPFlow 
						resultVo.setDeviceTypeMobile(false);
						setExperianUserData(resultVo, sponsorId, ExperianResultVo.WORKFLOW_REQUEST_TYPE_OTP_FLOW); 
					}
				}
				else if (isResendPasscode) {
					 //BokuOTPFlow 
					setExperianUserData(resultVo, sponsorId, ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW); 
				}
			}
		}
	}

	/* This sets the Experian provided user data which only work in UAT environment. */
	@Override
	public void setExperianUserData(ExperianResultVo resultVo, long sponsorId, String requestType) {
		InputStream input = DeviceReputationServiceImpl.class.getClassLoader().getResourceAsStream("/ips.properties");
    	Properties prop = new Properties();
    	String propertyName = "";
    	String propertyValue = "";
    	String[] propertyValueArr = null;
    	try {
			prop.load(input);
		} catch (IOException e) {
			CustomLogger.error(this.getClass(), "IO Exception occurred during IPS Properties loading.", e);
		}
    	
    	int testUserConfigIndex = 0;
     	
    	if (resultVo.isUseTargetTestUser()) {
    		testUserConfigIndex = resultVo.getTestUserIndex();
    	}
    	else {
	    	int otpFlowConfigIndex = 1;
	    	int silentAuthFlowConfigIndex = 2;
	    	int bokuOtpFlowConfigIndex = 3;
	    	int otpFlowInvestigateConfigIndex = 4;
	    		    	
			if (ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW.equalsIgnoreCase(requestType)) {
				testUserConfigIndex = silentAuthFlowConfigIndex;
			}
			else if (ExperianResultVo.WORKFLOW_REQUEST_TYPE_OTP_FLOW.equalsIgnoreCase(requestType)) {
				if ("investigatePreciseIdUser".equalsIgnoreCase(resultVo.getTestScenario())) {
					testUserConfigIndex = otpFlowInvestigateConfigIndex;
				}
				else {
					testUserConfigIndex = otpFlowConfigIndex;
				}
			}
			else if (ExperianResultVo.WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW.equalsIgnoreCase(requestType)) {
				testUserConfigIndex = bokuOtpFlowConfigIndex;
			}
    	}
		
		propertyName = "Experian.TestUserData" + testUserConfigIndex;
		resultVo.setWorkflowRequestType(requestType);
		
    	String firstName = "";
    	String lastName = "";
		String addressLine1 = "";
		String city = "";
		String stateProvince = "";
		String postalCode = "";
		String mobileNumber = "";
		
		propertyValue = prop.getProperty(propertyName);
		if (propertyValue != null) {
			propertyValueArr = propertyValue.split(",");
		}
		
		if (propertyValueArr != null ) {
			firstName = propertyValueArr[0];
	    	lastName = propertyValueArr[1];
			addressLine1 = propertyValueArr[2];
			city = propertyValueArr[3];
			stateProvince = propertyValueArr[4];
			postalCode = propertyValueArr[5];
			mobileNumber = propertyValueArr[6];
			mobileNumber = String.format("+1 %s", mobileNumber);
			
			resultVo.setFirstName(firstName.trim());
			resultVo.setLastName(lastName.trim());
			resultVo.setMiddleName("");
			resultVo.setAddressLine1(addressLine1.trim());
			resultVo.setCity(city.trim());
			resultVo.setStateProvince(stateProvince.trim());
			resultVo.setPostalCode(postalCode.trim());
			resultVo.setMobileNumber(mobileNumber.trim());	
		}
 	}
	
	public Map<String, String> getStandInUserMap() {
		InputStream input = DeviceReputationServiceImpl.class.getClassLoader().getResourceAsStream("/ips.properties");
    	Properties prop = new Properties();
    	String propertyName = "";
    	String propertyValue = "";
    	String[] propertyValueArr = null;
    	try {
			prop.load(input);
		} catch (IOException e) {
			CustomLogger.error(this.getClass(), "IO Exception occurred during IPS Properties loading.", e);
		}
					
    	Map<String, String> standInUserMap = new LinkedHashMap<>();
    	
    	for(int i = 1; i < 31; i++) {
			propertyName = "Experian.StandInUser" + i;
			propertyValue = prop.getProperty(propertyName);
			
			if (propertyValue != null) {
				propertyValueArr = propertyValue.split(",");
				
				if (propertyValueArr != null ) {
					String userName = propertyValueArr[0];
					String scenario = propertyValueArr[1];
					
					standInUserMap.put(userName, scenario);
				}
			}
			else {
				break;
			}
		}
    	
		return standInUserMap;
 	}
	
	/* Create a RpExperianResponsePayload record to verify the failure was due to PreciseId error response. */
	private void savePreciseIdErrorResponse(PersonVo personVo, RpEvent rpEvent, String orchDecisionsArrJson) {
    	CustomLogger.enter(this.getClass());

  		RpExperianDecisionResult decisionResult = new RpExperianDecisionResult();
		String referenceId = generateClientReferenceId(personVo);

  		try {
 			decisionResult.setRpEvent(rpEvent);
  			decisionResult.setClientReferenceId(referenceId);
  			decisionResult.setPreciseIdDecision("ERROR-PID");
          	decisionResult.setCreateDate(DateTimeUtil.getCurrentTime());
           	
         	rpExperianDecisionResultService.create(decisionResult);
           
         } catch (Exception e) {
             CustomLogger.error(this.getClass(), "Error in saving RpExperianDecisionResult for PreciseId Error Response.", e);
         }  
 	
      	try {
      		RpExperianDecisionResult savedDecisionResult = rpExperianDecisionResultService.findByPersonId(personVo.getId());
    		long expResultId = savedDecisionResult.getExpResultId();
    		
    		RpExperianResponsePayload responsePayload = new RpExperianResponsePayload();
    		responsePayload.setExpResultId(expResultId);
    		responsePayload.setExpSequenceId("0");
    		responsePayload.setDecisionElements(orchDecisionsArrJson);
     		responsePayload.setOrchestrationDecision("PreciseId Error Response");
       		responsePayload.setServiceName("PreciseId");
       		responsePayload.setRespReferenceId(referenceId);
	     	responsePayload.setCreateDate(DateTimeUtil.getCurrentTime());
	     	
			rpExperianResponsePayloadService.create(responsePayload); 
         } catch (Exception e) {
             CustomLogger.error(this.getClass(), "Error in saving RpExperianResponsePayload for PreciseId Error Response.", e);
         }       	
    }
	
	/* Create a RpExperianResponsePayload record to verify the failure was due to bad JWT response. */
	private void saveFailedJwtResponse(PersonVo personVo, RpEvent rpEvent, JSONObject tokenResponseJsonObj) {
    	CustomLogger.enter(this.getClass());

  		RpExperianDecisionResult decisionResult = new RpExperianDecisionResult();
		String referenceId = generateClientReferenceId(personVo);

  		try {
 			decisionResult.setRpEvent(rpEvent);
  			decisionResult.setClientReferenceId(referenceId);
  			decisionResult.setPreciseIdDecision("ERROR-JWT");
          	decisionResult.setCreateDate(DateTimeUtil.getCurrentTime());
           	
         	rpExperianDecisionResultService.create(decisionResult);
           
         } catch (Exception e) {
             CustomLogger.error(this.getClass(), "Error in saving RpExperianDecisionResult for failed JWT Request.", e);
                      }  
 	
      	try {
      		RpExperianDecisionResult savedDecisionResult = rpExperianDecisionResultService.findByPersonId(personVo.getId());
    		long expResultId = savedDecisionResult.getExpResultId();

    		Gson g = new GsonBuilder().disableHtmlEscaping().create();
     		String failedJwtResponseJsonStr = tokenResponseJsonObj != null? g.toJson(tokenResponseJsonObj) : "No JSON Response";
    		
    		RpExperianResponsePayload responsePayload = new RpExperianResponsePayload();
    		responsePayload.setExpResultId(expResultId);
    		responsePayload.setExpSequenceId("0");
    		responsePayload.setDecisionElements(failedJwtResponseJsonStr);
     		responsePayload.setOrchestrationDecision("Failed JsonWebToken Request");
       		responsePayload.setServiceName("JsonWebToken");
       		responsePayload.setRespReferenceId(referenceId);
	     	responsePayload.setCreateDate(DateTimeUtil.getCurrentTime());
	     	
			rpExperianResponsePayloadService.create(responsePayload); 
         } catch (Exception e) {
             CustomLogger.error(this.getClass(), "Error in saving RpExperianResponsePayload for failed JWT Request.", e);
        }       	
    }
	
	/**** UTILITY SERVICES ****/

	@Override
	public String generateClientReferenceId(PersonVo personVo) {
		CustomLogger.enter(this.getClass());

		long personId = personVo.getId();
		String randomId = UUID.randomUUID().toString().replace("-", "");
		randomId = randomId.substring(0, 10).toUpperCase();

		RefApp refApp = refAppService.findByAppId(personVo.getAppId());
		String appCode = "HM";
		
		if (refApp != null) {
			String appName = refApp.getAppName();
			Map<String, String> appNameCodeMap = commonRestService.getAppNameCodeMap();
			appCode = appNameCodeMap.get(appName);
			appCode = appCode != null? appCode.toUpperCase() : "";
		}
		
		String deviceType = personVo.isDeviceTypeMobile() ? "MB" : "DT";
		
		return String.format("%s-%s-%s-%s", appCode, deviceType, personId, randomId);
	}

	private boolean isDeviceTypeMobile(PersonVo personVo) {
		if(personVo.isWebServiceCall()) {
			return personVo.isDeviceTypeMobile();
		}
		else {
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();
			String userAgent = commonRestService.getUserAgent(request);
			boolean isDeviceTypeMobile = ExperianResultVo.DEVICE_TYPE_MOBILE.equalsIgnoreCase(userAgent);
			personVo.setDeviceTypeMobile(isDeviceTypeMobile);
			return isDeviceTypeMobile;
		}
	}

	private void setTestUserScenarioDecision(JSONObject orchDecisionItem, ExperianResultVo resultVo, String elementRequestType) {
		if ("stopBokuServiceInfoUser".equalsIgnoreCase(resultVo.getTestScenario()) ) {
			if (ExperianResultVo.APP_REQUEST_TYPE_BOKU_SERVICE_INFO.equalsIgnoreCase(elementRequestType)
			    || ExperianResultVo.APP_REQUEST_TYPE_BOKU_SCORE_INFO.equalsIgnoreCase(elementRequestType)
			    || ExperianResultVo.APP_REQUEST_TYPE_BOKU_SEND_OTP.equalsIgnoreCase(elementRequestType)
			    || ExperianResultVo.APP_REQUEST_TYPE_BOKU_PNV_REQ.equalsIgnoreCase(elementRequestType)) {
				orchDecisionItem.put(FIELD_DECISION, ExperianResultVo.SERVICE_DECISION_STOP);
			}
		}
		else if ("stopBokuScoreInfoUser".equalsIgnoreCase(resultVo.getTestScenario()) ) {
			if (ExperianResultVo.APP_REQUEST_TYPE_BOKU_SERVICE_INFO.equalsIgnoreCase(elementRequestType)) {
					orchDecisionItem.put(FIELD_DECISION, ExperianResultVo.SERVICE_DECISION_CONTINUE);
			}
			else if (ExperianResultVo.APP_REQUEST_TYPE_BOKU_SEND_OTP.equalsIgnoreCase(elementRequestType)
			    || ExperianResultVo.APP_REQUEST_TYPE_BOKU_PNV_REQ.equalsIgnoreCase(elementRequestType)) {
				orchDecisionItem.put(FIELD_DECISION, ExperianResultVo.SERVICE_DECISION_STOP);
			}
		}
		else if ("stopBokuPNVReqUser".equalsIgnoreCase(resultVo.getTestScenario()) ) {
			if (ExperianResultVo.APP_REQUEST_TYPE_BOKU_SERVICE_INFO.equalsIgnoreCase(elementRequestType)
			    || ExperianResultVo.APP_REQUEST_TYPE_BOKU_SCORE_INFO.equalsIgnoreCase(elementRequestType)) {
				orchDecisionItem.put(FIELD_DECISION, ExperianResultVo.SERVICE_DECISION_CONTINUE);
			}
			else if (ExperianResultVo.APP_REQUEST_TYPE_BOKU_PNV_REQ.equalsIgnoreCase(elementRequestType)
				|| ExperianResultVo.APP_REQUEST_TYPE_BOKU_PNV_RES.equalsIgnoreCase(elementRequestType)) {
					orchDecisionItem.put(FIELD_DECISION, ExperianResultVo.SERVICE_DECISION_STOP);
			}
		}
	}
	
	private Person getPerson(long id) {
		return personService.findByPK(id);
	}

}
