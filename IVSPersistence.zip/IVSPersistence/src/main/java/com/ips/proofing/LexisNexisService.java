package com.ips.proofing;

import com.ips.entity.Person;
import com.ips.entity.RpEvent;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationResponse;
import com.lexisnexis.ns.identity_proofing._1.RdpResponseModel;

public interface LexisNexisService {

    RdpResponseModel requestPhoneFinder(PersonVo personVo, Person person) throws PhoneVerificationException;
    PhoneVerificationResponse verifyPhone(Person person, PersonVo personVo) throws IPSException, PhoneVerificationException;
    boolean sendPasscodeSuccessful(Person person, PersonVo personVo) throws IPSException, PhoneVerificationException;
    boolean confirmPasscodeSuccessful(Person person, PersonVo personVo, RpEvent event) throws IPSException, PhoneVerificationException;
    boolean userFailedPhoneVerification(Person person);
    boolean isPreCheckPassed();

	RdpResponseModel sendSMSActivationCode(Person person) throws PhoneVerificationException;
}
