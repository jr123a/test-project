package com.ips.proofing;

import com.ips.entity.Person;
import com.ips.entity.RpEvent;
import com.ips.persistence.common.PersonVo;

public interface ManageDeviceReputationService {
    
	void updateDeviceReputation(Person person, PersonVo personVo, RpEvent phoneEvent);
    
}
