package com.ips.proofing;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.xml.bind.DatatypeConverter;

import org.apache.wink.client.ClientConfig;
import org.apache.wink.client.Resource;
import org.apache.wink.client.RestClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.ibm.json.java.JSONObject;
import com.ips.common.common.AliasVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.Utils;
import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefLexisNexisReasonCodeMap;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpEvent;
import com.ips.entity.RpLexisNexisFinalReasonCode;
import com.ips.entity.RpLexisNexisResult;
import com.ips.entity.RpOtpAttempt;
import com.ips.entity.RpPhoneVerification;
import com.ips.entity.RpPhoneVerificationResult;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.CustRegAssertionParamVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationResponse;
import com.ips.service.LexisNexisDataService;
import com.ips.service.PersonDataService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RpEventDataService;
import com.ips.service.RpLexisNexisResultService;
import com.ips.service.RpProofingSessionDataService;
import com.ips.service.TruthDataReturnService;
import com.ips.service.TruthDataReturnServiceImpl;
import com.lexisnexis.ns.identity_proofing._1.OTPDeliveryInfoModel;
import com.lexisnexis.ns.identity_proofing._1.OTPParameterDetailsModel;
import com.lexisnexis.ns.identity_proofing._1.RdpAddressModel;
import com.lexisnexis.ns.identity_proofing._1.RdpDateOfBirthModel;
import com.lexisnexis.ns.identity_proofing._1.RdpPersonModel;
import com.lexisnexis.ns.identity_proofing._1.RdpPersonNameModel;
import com.lexisnexis.ns.identity_proofing._1.RdpPhoneModel;
import com.lexisnexis.ns.identity_proofing._1.RdpProductItemModel;
import com.lexisnexis.ns.identity_proofing._1.RdpProductModel;
import com.lexisnexis.ns.identity_proofing._1.RdpRequestModel;
import com.lexisnexis.ns.identity_proofing._1.RdpResponseModel;
import com.lexisnexis.ns.identity_proofing._1.RdpSettingsModel;
import com.lexisnexis.ns.identity_proofing._1.SMSCustomDataModel;

@Service("lexisNexisService")
public class LexisNexisServiceImpl implements Serializable, LexisNexisService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Autowired
	private LexisNexisDataService lexisnexisDataService;
	@Autowired
	private ManageDeviceReputationService manageDeviceReputationService;
	@Autowired
	private ManageEventService manageEventService;
	@Autowired
	private PersonDataService personService;
	@Autowired
	private ProofingService proofingService;
	@Autowired
	private RpEventDataService rpEventService;
	@Autowired
	private RpLexisNexisResultService rpLexisNexisResultService;
	@Autowired
	private RpProofingSessionDataService rpProofingSessionService;
	@Autowired
	private TruthDataReturnService truthDataReturnService;
    @Autowired
    private RefSponsorConfigurationService refSponsorConfigurationService;

	private static String workflow15;
	private static String workflow20;
	private static String propHost;
	private static String propPort;
	private static String phoneFinderUrl;
	private static String otpUrl;

	private static final String REQUEST_TYPE_CONTINUE = "Continue";
	private static final String REQUEST_TYPE_INITIATE = "Initiate";
	private static final String SETTINGS_MODE_LIVE = "live";
	private static final String SETTINGS_LOCAL_US = "en_US";
	private static final String SETTINGS_REFERENCE = "REST_Transaction";
	private static final String SETTINGS_VENUE_ONLINE = "online";
	private static final String ADDRESS_COUNTRY_US = "US";
	private static final String CONTEXT_PRIMARY = "primary";
	private static final String JSON_HEADER_AUTHORIZATION = "Authorization";
	private static final String DELIVERY_METHOD = "T";
	private static final String DELIVERY_LANGUAGE = "EN";
    private static final String REASON_CODE_CURRENT_RESIDENCY = "CURRENTRESIDENCY";
    private static final String VALUE_TRUE = "True";
    public static final String VERIFY_PHONE = "VerifyPhone";
    public static final String SEND_PASSCODE = "SendPasscode";
    public static final String VALIDATE_PASSCODE = "ValidatePasscode";

	private boolean preCheckPassed;

	static {
		List<String> props = new ArrayList<>();
		props.add("com.ipsweb.LexisNexisPhone");
		props.add("com.ipsweb.LexisNexisOTP");
		props.add("com.ipsweb.ln.proxyHost");
		props.add("com.ipsweb.proxyPort");
		props.add("com.ipsweb.lnWorkflow1.5");
		props.add("com.ipsweb.lnWorkflow2.0");
		props = Utils.getProperty(props);
		
		if (!props.isEmpty()) {
			phoneFinderUrl = props.get(0);
			otpUrl     = props.get(1);
            propHost   = props.get(2);
            propPort   = props.get(3);
            workflow15 = props.get(4);
            workflow20 = props.get(5);
		}
	}

	/**
     * Calls the LexisNexis RDP web service to verify the phone number.  Persists all of the related
     * data to the database after the call.
     * This method MUST throw a PhoneVerificationException to ensure that failover will occur to the other supplier
	 */
    public PhoneVerificationResponse verifyPhone(Person person, PersonVo personVo) throws IPSException, PhoneVerificationException {
    	CustomLogger.enter(this.getClass());
    	 
    	PhoneVerificationResponse pvResponse = null;
    	
    	if (person == null || personVo == null) {
    		return pvResponse;
    	}

       	String phoneVerificationSupplier = personVo.getPhoneVerificationSupplierName();
    	String loaSought = personVo.getProofingLevelSought();

      	proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_initiated.getValue(), person, loaSought);
      	CustomLogger.debug(this.getClass(), String.format("Remote proofing status: %s Phone verification is initiated.", phoneVerificationSupplier));

		try {
			boolean hasPreviousPhoneVerificationDecision = personVo.hasPreviousPhoneVerificationDecision();
            RpEvent prevPhoneEvent = null;
            boolean isPhoneVerified = false;
            String phoneVerificationDecision = "";
            long supplierId = RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID;
            String supplierName = RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_NAME;

			if (hasPreviousPhoneVerificationDecision) {
                prevPhoneEvent = rpEventService.getLatestPhoneEventsByPersonIdAndPhoneNumber(person.getPersonId(), personVo.getMobileNumber());
			}

			RpEvent phoneEvent = manageEventService.createEvent(personVo, prevPhoneEvent, supplierId);

			// Device Reputation
			manageDeviceReputationService.updateDeviceReputation(person, personVo, phoneEvent);

			if (hasPreviousPhoneVerificationDecision) {
	           	pvResponse =  manageEventService.savePreviousPhoneVerificationResults(phoneEvent, prevPhoneEvent, personVo, supplierId);
             	
				if (pvResponse == null) {
			        return new PhoneVerificationResponse(supplierId, supplierName, PhoneVerificationResponse.PV_DECISION_FAIL, phoneEvent.getFinalDecision());    
				}

	           	String pvDecision = pvResponse.getPhoneVerificationDecision();
                boolean verifyPrecheck = verifyPreviousPrecheck(prevPhoneEvent);

            	CustomLogger.debug(this.getClass(), String.format("Remote proofing status: User with sponsorUserId %s has previous %s phone verification with a decision of %s.", 
               			person.getSponsorUserId(), supplierName, pvDecision));        	

                RefSponsorConfiguration config = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
                        RefSponsorConfiguration.ASSERT_TO_CUSTREG);

                if (PhoneVerificationResponse.PV_DECISION_PASS.equalsIgnoreCase(pvDecision)) {
                    proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verified.getValue(), person, loaSought);
                    CustomLogger.debug(this.getClass(), "Has previous passed phone verification with LexisNexis for sponsorUserId:".concat(person.getSponsorUserId()));

                    if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
                    	passedPhoneVerification(person, personVo);
                    }
                 }
                else {
                    proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_failed.getValue(), person, loaSought);
                    CustomLogger.debug(this.getClass(), "Has previous failed phone verification with LexisNexis for sponsorUserId:".concat(person.getSponsorUserId()));
                   
                    if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
                    	failedPhoneVerification(person, personVo);
                    }
                 } 

                phoneVerificationDecision = pvDecision;
                personVo.setPhoneVerificationDecision(pvDecision);
				}
            else {
				RdpResponseModel phoneFinderResponse = requestPhoneFinder(personVo, person);

				if (phoneFinderResponse == null) {
                    CustomLogger.error(this.getClass(), "Error occurred during the LexisNexis call for sponsorUserId: " + personVo.getSponsorUserId());
                    isPhoneVerified = false;
				}

                if (phoneFinderResponse != null && phoneFinderResponse.getProducts() != null) {
                	setStubPhoneFinderResponse(personVo, phoneFinderResponse);
                	
                    boolean saved = lexisnexisDataService.savePhoneVerificationResults(phoneFinderResponse, phoneEvent, personVo, person);
					RpPhoneVerification rpPhoneVerification = phoneEvent.getRpPhoneVerification();

                    isPhoneVerified = rpPhoneVerification.isLexisNexisPhoneVerificationPassed();
                    personVo.setPhoneVerificationDecision(isPhoneVerified ? PhoneVerificationResponse.PV_DECISION_REVIEW : PhoneVerificationResponse.PV_DECISION_FAIL);
                    CustomLogger.debug(this.getClass(), String.format("LexisNexis phone verification %s for sponsorUserId: %s", (isPhoneVerified ? IPSConstants.VALUE_PASSED : IPSConstants.VALUE_FAILED), person.getSponsorUserId()));
                    CustomLogger.debug(this.getClass(), String.format("LexisNexis savePhoneVerificationResults return value: %s", saved));

                    RefSponsorConfiguration config = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
                            RefSponsorConfiguration.ASSERT_TO_CUSTREG);

                    if (saved && isPhoneVerified) {
                        proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verified.getValue(), person, loaSought);
						// setup passcode results
						// Scenario 1
						person = getPerson(person.getPersonId());
						if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
							 passedPhoneVerification(person, personVo);
                        }
					} else {
                        proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_failed.getValue(), person, loaSought);
						// setup passcode results
						// Scenario 3
						person = getPerson(person.getPersonId());
                        
						if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
							failedPhoneVerification(person, personVo);
						}
                        
						// Return Truth Data to ThreatMetrix
						truthDataReturnService.returnRemoteProofingTruthData(person, false);
						CustomLogger.debug(this.getClass(), "Return Truth Data to ThreatMetrix for LexisNexis PV Failed Result:" 
								+ TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_FAIL);
					}
				}
                
                phoneVerificationDecision = isPhoneVerified ? PhoneVerificationResponse.PV_DECISION_REVIEW : PhoneVerificationResponse.PV_DECISION_FAIL;
			}
            
            return new PhoneVerificationResponse(RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID, RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_NAME, 
            		phoneVerificationDecision, phoneEvent.getFinalDecision());
		} catch (Exception ex) {
            CustomLogger.error(this.getClass(), "Exception occurred during the LexisNexis call for sponsorUserId: " + personVo.getSponsorUserId() + " "
                    + personVo.getFullName(), ex);
			throw new PhoneVerificationException(ex.getMessage());
		}
	}
    
	/*
     * This method MUST throw a PhoneVerificationException to ensure that failover will occur to the other supplier
	 */
	@Override
	public RdpResponseModel requestPhoneFinder(PersonVo personVo, Person person) throws PhoneVerificationException {
		PersonProofingStatus proofingStatus = person.getStatusForLoaSought(personVo.getProofingLevelSought());
		RdpRequestModel request = getPhoneFinderRequest(personVo);

		Gson g = new Gson();
		String requestJsonStr = g.toJson(request);
		personVo.setRequestJson(requestJsonStr);
    	CustomLogger.debug(this.getClass(), String.format("LexisNexis phone verification response Json: %s", requestJsonStr));

		return sendPhoneFinderRequest(personVo, request, proofingStatus, phoneFinderUrl, REQUEST_TYPE_INITIATE, VERIFY_PHONE, true);
	}

	private RdpRequestModel getPhoneFinderRequest(PersonVo personVo) {
		RdpRequestModel request = new RdpRequestModel();
		request.setType(REQUEST_TYPE_INITIATE);
		RdpSettingsModel settings = new RdpSettingsModel();
		settings.setMode(SETTINGS_MODE_LIVE);
		settings.setReference(SETTINGS_REFERENCE);
		settings.setLocale(SETTINGS_LOCAL_US);
		settings.setVenue(SETTINGS_VENUE_ONLINE);
		request.setSettings(settings);

		OTPDeliveryInfoModel deliveryinfo = new OTPDeliveryInfoModel();
		deliveryinfo.setMethod(DELIVERY_METHOD);
		deliveryinfo.setLanguage(DELIVERY_LANGUAGE);
		request.setOtpDeliveryInfo(deliveryinfo);

		List<RdpPersonModel> personList = new ArrayList<>();
		RdpPersonModel reqPerson = new RdpPersonModel();
		RdpPersonNameModel names = new RdpPersonNameModel();
		names.setFirstName(personVo.getFirstName());
		names.setLastName(personVo.getLastName());

		List<RdpAddressModel> addrList = new ArrayList<>();
		RdpAddressModel addresses = new RdpAddressModel();
		addresses.setStreetAddress1(personVo.getAddressLine1());
		addresses.setCity(personVo.getCity());
		addresses.setState(personVo.getStateProvince());
		addresses.setZip5(personVo.getZip5());
		addresses.setCountry(ADDRESS_COUNTRY_US);
		addresses.setContext(CONTEXT_PRIMARY);
		addrList.add(addresses);

		reqPerson.setName(names);
		reqPerson.setAddresses(addrList);
		reqPerson.setContext(CONTEXT_PRIMARY);
		personList.add(reqPerson);
		request.setPersons(personList);

		if (personVo.getDob() != null && VERIFY_PHONE.equalsIgnoreCase(personVo.getCallingMethod())) {
			String birthDate = DateTimeUtil.getDateString(personVo.getDob(), "MMddyyyy");
			RdpDateOfBirthModel dob = new RdpDateOfBirthModel();
			dob.setYear(birthDate.substring(4));
			dob.setMonth(birthDate.substring(0, 2));
			dob.setDay(birthDate.substring(2, 4));
			reqPerson.setDateOfBirth(dob);
		}

		List<RdpPhoneModel> phones = new ArrayList<>();
		RdpPhoneModel phone = new RdpPhoneModel();
		phone.setNumber(personVo.getMobileNumber());
		phone.setContext("mobile");
		phones.add(phone);
		reqPerson.setPhones(phones);

		return request;
	}

	/*
     * This method MUST throw a PhoneVerificationException to ensure that failover will occur to the other supplier
	 */
	private RdpResponseModel sendPhoneFinderRequest(PersonVo personVo, RdpRequestModel requestObj, PersonProofingStatus proofingStatus,
			String resourceUrl, String requestType, String transactionType, boolean isOTP) throws PhoneVerificationException {

		RdpResponseModel responseObj = null;

		// OTP is only for LOA 1.5, this is not needed for an OTP call
		Resource resource = null;
		if (isOTP) {
			resource = getOtpClientResource(resourceUrl);
		} else {
			resource = getOtpClientResource(proofingStatus, resourceUrl);
		}

		CustomLogger.debug(this.getClass(), "sendRequest URL: " + resourceUrl);

		JSONObject responseJson = null;

		try {
			Gson g = new Gson();
			String authStringEnc = getAuthorization();
			String requestJsonString = g.toJson(requestObj);
			
			personVo.setRequestJson(requestJsonString);

            if (REQUEST_TYPE_INITIATE.equalsIgnoreCase(requestType)) {
				CustomLogger.debug(this.getClass(), "sendRequest using POST ");
				responseJson = JSONObject.parse(resource.contentType(MediaType.APPLICATION_JSON).header(JSON_HEADER_AUTHORIZATION, authStringEnc)
						.post(String.class, requestJsonString));
            } else if (REQUEST_TYPE_CONTINUE.equalsIgnoreCase(requestType)) {
				CustomLogger.debug(this.getClass(), "sendRequest using PUT ");
				responseJson = JSONObject.parse(resource.contentType(MediaType.APPLICATION_JSON).header(JSON_HEADER_AUTHORIZATION, authStringEnc)
						.put(String.class, requestJsonString));
			}

			if (responseJson != null) {
				String responseJsonStr = responseJson.toString();
	            CustomLogger.debug(this.getClass(), String.format("LexisNexis response Json for requestType %s: %s", 
	            		requestType, responseJsonStr));

				responseObj = g.fromJson(responseJsonStr, RdpResponseModel.class);
				extractRequestResponse(personVo, requestObj, responseObj, transactionType);
				
				if (responseObj.getStatus() != null) {
					personVo.setRequestId(responseObj.getStatus().getRequestId());
				}
			}
		} catch (Exception e) {
			// Include the exception in the call so that the stacktrace will be included
			CustomLogger.error(this.getClass(), "Error occurred in sending request.", e);
			if (e != null && e.getMessage() != null) {
				throw new PhoneVerificationException(e.getMessage());
			}
			else {
				throw new PhoneVerificationException("Exception");
			}
		}

		return responseObj;
	}

	private void extractRequestResponse(PersonVo personVo, RdpRequestModel request, RdpResponseModel response, String transactionType) {
		Gson g = new Gson();

		if (VERIFY_PHONE.equalsIgnoreCase(transactionType)) {
			String statusStr = g.toJson(response.getStatus());
			personVo.setVerifyPhoneRequestJson(statusStr);
		}
		else if (SEND_PASSCODE.equalsIgnoreCase(transactionType)) {
			String statusStr = g.toJson(response.getStatus());
			personVo.setSendPasscodeRequestJson(statusStr);
		}
		else if (VALIDATE_PASSCODE.equalsIgnoreCase(transactionType)) {
			String statusStr = g.toJson(response.getStatus());
			personVo.setValidatePasscodeRequestJson(statusStr);
		}

		if (response != null) {
			for (RdpProductModel product : response.getProducts()) {
				RdpProductModel productMod = product;
				if (productMod.getParameterDetails() != null && !productMod.getParameterDetails().isEmpty()) {
					List<OTPParameterDetailsModel> emptyList = new ArrayList<>();
					productMod.setParameterDetails(emptyList);
				}
				
				String productStr = g.toJson(productMod);
				
				if (VERIFY_PHONE.equalsIgnoreCase(transactionType)) {
					productStr = (personVo.getVerifyPhoneResponseJson() != null ? personVo.getVerifyPhoneResponseJson() : "") + productStr;
					personVo.setVerifyPhoneResponseJson(productStr);
				}
				else if (SEND_PASSCODE.equalsIgnoreCase(transactionType)) {
					productStr = (personVo.getSendPasscodeResponseJson() != null ? personVo.getSendPasscodeResponseJson() : "") + productStr;
					personVo.setSendPasscodeResponseJson(productStr);
				}
				else if (VALIDATE_PASSCODE.equalsIgnoreCase(transactionType)) {
					productStr = (personVo.getValidatePasscodeResponseJson() != null ? personVo.getValidatePasscodeResponseJson() : "") + productStr;
					personVo.setValidatePasscodeResponseJson(productStr);
				}
			}
		}
		else {
			String errorResponse = String.format("LexisNexis has returned null response on %s transaction for user %s.", transactionType, personVo.getSponsorUserId());
			if (VERIFY_PHONE.equalsIgnoreCase(transactionType)) {
				personVo.setVerifyPhoneResponseJson(errorResponse);
			}
			else if (SEND_PASSCODE.equalsIgnoreCase(transactionType)) {
				personVo.setSendPasscodeResponseJson(errorResponse);
			}
			else if (VALIDATE_PASSCODE.equalsIgnoreCase(transactionType)) {
				personVo.setValidatePasscodeResponseJson(errorResponse);
			}
		}
	}
	
	private Resource getOtpClientResource(PersonProofingStatus proofingStatus, String url) {
		ClientConfig config = new ClientConfig();
		config.proxyHost(propHost);
		config.proxyPort(Integer.parseInt(propPort));
		String workFlow = proofingStatus.getRefLoaLevel().isLoa15() ? workflow15 : workflow20;

		RestClient client = new RestClient(config);
		return client.resource(String.format(url, workFlow));
	}

	private Resource getOtpClientResource(String inputUrl) {
		ClientConfig config = new ClientConfig();
		config.proxyHost(propHost);
		config.proxyPort(Integer.parseInt(propPort));
		RestClient client = new RestClient(config);
		return client.resource(inputUrl);
	}
	
	/*
     * This method MUST throw a PhoneVerificationException to ensure that failover will occur to the other supplier
	 */
	private String getAuthorization() throws PhoneVerificationException {
		AliasVo j2c = null;

		try {
			j2c = getLexisNexisCredentials();
		} catch (IPSException e) {
			CustomLogger.error(this.getClass(), "Error occurred in getting authorization: ", e);
			throw new PhoneVerificationException(e.getMessage());
		}

		return String.format("Basic %s", DatatypeConverter.printBase64Binary(
				String.format("%s:%s", j2c.getUserName(), j2c.getPassword()).getBytes(StandardCharsets.UTF_8)));
	}

	/**
     * Extracted out this public method to allow this application to be mocked with a non-static method
     * getLexisNexisCredentials
     * returns AliasVo object from static method in Utils
	 * @return AliasVo
	 * @throws IPSException
	 */
	public AliasVo getLexisNexisCredentials() throws IPSException {
		AliasVo j2c;
		j2c = Utils.getAppCredentials(IPSConstants.LEXIS_NEXIS_RDP_J2C_ALIAS);
		return j2c;
	}

	public boolean verifyPrecheck(RdpResponseModel response) {
        boolean prechekVerification = lexisnexisDataService.evaluatePreChecks(response, new ArrayList<>());
		setPreCheckPassed(prechekVerification);
		return prechekVerification;
	}

    private boolean verifyPreviousPrecheck(RpEvent prevPhoneEvent) {
    	RpLexisNexisResult lnResult = prevPhoneEvent.getRpLexisNexisResult();
    	
    	if (lnResult == null) {
    		return true;
    	}
    	
    	List<RpLexisNexisFinalReasonCode> finalReasonCodes = lnResult.getRpLexisNexisFinalReasonCodes();

    	RefLexisNexisReasonCodeMap failedCurrResidency = rpLexisNexisResultService.retireveByValue(REASON_CODE_CURRENT_RESIDENCY, "FAIL");
        String failedCurrResidencyCode = failedCurrResidency.getRefOtpReasonCode().getReasonCode();
    	for(RpLexisNexisFinalReasonCode code : finalReasonCodes) {
    		if (code.getRefOtpReasonCode().getReasonCode().equalsIgnoreCase(failedCurrResidencyCode)) {
    			return false;
     		}
    	}
    	return true;
    }

	private Person getPerson(long id) {
		CustomLogger.enter(this.getClass(), String.format("PersonId:%s", id));
		CustomLogger.debug(this.getClass(), "Creating PersonsDataService");
		Person person = personService.findByPK(id);
		CustomLogger.debug(this.getClass(), "getPerson(" + id + ") person=" + person);
		return person;
	}

	/*
	 * Scenario 1 User Passes Phone Verification
	 */
    private void passedPhoneVerification(Person person, PersonVo personVo) {
		CustomLogger.enter(this.getClass());
		String phoneDecision = "";
		String phoneServiceStatus = "";
		String avsErrorsDatetime = "";

		RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(),
                RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID);
		if (event != null) {
			//Assert passed phone regardless of verifyCheck result.
			RpPhoneVerification rpPhoneVerification = event.getRpPhoneVerification();
			phoneDecision = rpPhoneVerification.getPhoneVerificationDecision();
			// passcode Sent date time
			long initiationDatetime = rpPhoneVerification.getCreateDate().getTime();
			// passcode decision date time
            long completionDatetime = rpPhoneVerification.getDecisionDateTime() != null ?
                    rpPhoneVerification.getDecisionDateTime().getTime() : 0L;
			// mobile phone
            String mobilePhone = rpPhoneVerification.getMobilePhoneNumber() != null ? rpPhoneVerification.getMobilePhoneNumber() : "";
			RpPhoneVerificationResult rpPhoneVerificationResult = event.getRpPhoneVerificationResult();
			// phone service status
            phoneServiceStatus = rpPhoneVerificationResult.getRefServiceStatusCode()!=null? rpPhoneVerificationResult.getRefServiceStatusCode().getServiceStatus():"";
			// avsErrorsDatetime
			if (event.getAvsErrorsDatetime() != null) {
				avsErrorsDatetime = event.getAvsErrorsDatetime().toString();
			}
			// transaction key
			String transactionKey = rpPhoneVerification.getTransactionKey();
			// attempts Made
			long attemptsMade = rpPhoneVerification.getNumberOfSubmitAttempts();
			long totalIPSAttempts = 1;
			totalIPSAttempts = rpProofingSessionService.getSumOfTotalAttempts(person);
            CustomLogger.debug(this.getClass(), "LexisNexisServiceImpl.totalOfTOA (totalIPSAttempts)=" + totalIPSAttempts);
			long totalEIDAttempts = 1;
			totalEIDAttempts = rpEventService
					.countRpEvents(person.getPersonId(), IPSConstants.ONE_TIME_PASSCODE_LEXISNEXIS_SUPPLIER_ID)
					.get(0).longValue();
            CustomLogger.debug(this.getClass(), "LexisNexisServiceImpl.totalRpEvents(totalEIDAttempts)=" + totalEIDAttempts);
			// The first one (totalofTOA) is used for total_ips_attempts. The second one
			// (totalRpEvents) is used for total_eid_attempts.

            CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
            assertionVo.setLoaSought(personVo.getProofingLevelSought());
            assertionVo.setMobilePhone(mobilePhone);
            assertionVo.setVerificationDecision(phoneDecision);
            assertionVo.setVerificationMatchQuality(null);
            assertionVo.setVerificationMatchLevel(null);
            assertionVo.setProductStatus(phoneServiceStatus);
            assertionVo.setRpStatusCode(RefRpStatus.RpStatus.Phone_verified.getValue());
            assertionVo.setVerificationSentDatetime(initiationDatetime);
            assertionVo.setVerificationDecisionDatetime(completionDatetime);
            assertionVo.setTotalIPSAttempts(totalIPSAttempts);
            assertionVo.setTotalEIDAttempts(totalEIDAttempts);
            assertionVo.setProofingStatus(IPSConstants.PROOFING_STATUS_PHONE_VERIFIED);
            assertionVo.setAttemptsAllowed(IPSConstants.RP_ATTEMPTS_ALLOWED);
            assertionVo.setAttemptsMade(attemptsMade);
            assertionVo.setAttemptsPeriod(IPSConstants.RP_ATTEMPT_PERIOD);
            assertionVo.setTransactionKey(transactionKey);
            assertionVo.setAvsErrorsDatetime(avsErrorsDatetime);
            assertionVo.setLoaName(IPSConstants.LOA_RP_LN_PV_NAME);
			
			proofingService.phoneVerification(person, assertionVo);

		} else {
            CustomLogger.error(this.getClass(), "Person sponsorUserId: " + person.getSponsorUserId() + " does not have any RpEvents");
		}
	}

	/*
	 * Scenario 4 User fails online phone verification
	 */
    private void failedPhoneVerification(Person person, PersonVo personVo) {
		CustomLogger.enter(this.getClass());
		String sponsorUserId = person.getSponsorUserId();
		RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(),
                RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID);
		if (event != null) {
			RpPhoneVerification rpPhoneVerification = event.getRpPhoneVerification();

			try {
				//Assert failed phone regardless of verifyCheck result.
				// product decision
				String phoneDecision = rpPhoneVerification.getPhoneVerificationDecision();
				// passcode Sent date time
				long initiationDatetime = rpPhoneVerification.getCreateDate().getTime();
				// passcode decision date time
                long completionDatetime = rpPhoneVerification.getDecisionDateTime()!=null? 
                        rpPhoneVerification.getDecisionDateTime().getTime() : 0L;
				// mobile phone
                String mobilePhone = rpPhoneVerification.getMobilePhoneNumber() != null ? rpPhoneVerification.getMobilePhoneNumber() : "";
				RpPhoneVerificationResult rpPhoneVerificationResult = event.getRpPhoneVerificationResult();
				// phone service status
                String phoneServiceStatus = "";
                if (rpPhoneVerificationResult != null && rpPhoneVerificationResult.getRefServiceStatusCode() !=  null) {
                    phoneServiceStatus = rpPhoneVerificationResult.getRefServiceStatusCode().getServiceStatus();
				}

                // avsErrorsDatetime
                String avsErrorsDatetime = "";
                if (event != null && event.getAvsErrorsDatetime() !=  null) {
                	avsErrorsDatetime = event.getAvsErrorsDatetime().toString();
				}
                // transaction key
                String transactionKey = rpPhoneVerification.getTransactionKey();
				// attempts Made
				long attemptsMade = rpPhoneVerification.getNumberOfSubmitAttempts();
				long totalIPSAttempts = 1;
				totalIPSAttempts = rpProofingSessionService.getSumOfTotalAttempts(person);
                CustomLogger.debug(this.getClass(), "LexisNexisServiceImpl.totalOfTOA (totalIPSAttempts)=" + totalIPSAttempts + " for sponsorUserId:" + sponsorUserId);
				long totalEIDAttempts = 1;
				totalEIDAttempts = rpEventService
                        .countRpEvents(person.getPersonId(), IPSConstants.ONE_TIME_PASSCODE_LEXISNEXIS_SUPPLIER_ID).get(0)
                        .longValue();
                CustomLogger.debug(this.getClass(), "LexisNexisServiceImpl.totalRpEvents(totalEIDAttempts)=" + totalEIDAttempts);
 
				// The first one (totalofTOA) is used for total_ips_attempts. The second one
				// (totalRpEvents) is used for total_eid_attempts.
                CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
                assertionVo.setLoaSought(personVo.getProofingLevelSought());
                assertionVo.setMobilePhone(mobilePhone);
                assertionVo.setVerificationDecision(phoneDecision);
                assertionVo.setVerificationMatchQuality(null);
                assertionVo.setVerificationMatchLevel(null);
                assertionVo.setProductStatus(phoneServiceStatus);
                assertionVo.setRpStatusCode(RefRpStatus.RpStatus.Phone_verification_failed.getValue());
                assertionVo.setVerificationSentDatetime(initiationDatetime);
                assertionVo.setVerificationDecisionDatetime(completionDatetime);
                assertionVo.setTotalIPSAttempts(totalIPSAttempts);
                assertionVo.setTotalEIDAttempts(totalEIDAttempts);
                assertionVo.setProofingStatus(IPSConstants.PROOFING_STATUS_PHONE_NOT_VERIFIED);
                assertionVo.setAttemptsAllowed(IPSConstants.RP_ATTEMPTS_ALLOWED);
                assertionVo.setAttemptsMade(attemptsMade);
                assertionVo.setAttemptsPeriod(IPSConstants.RP_ATTEMPT_PERIOD);
                assertionVo.setTransactionKey(transactionKey);
                assertionVo.setAvsErrorsDatetime(avsErrorsDatetime);
                assertionVo.setLoaName(IPSConstants.LOA_RP_LN_PV_NAME); 

                proofingService.phoneVerification(person, assertionVo);
			} catch (Exception e) {
                CustomLogger.error(this.getClass(), "Failed phone verification method is throwing error for sponsorUserId:" + sponsorUserId, e);
			}

		} else {
			CustomLogger.error(this.getClass(), "person does not have any RpEvents for sponsorUserId:" + sponsorUserId);
		}
	}

	/*
     * This method MUST throw a PhoneVerificationException to ensure that the user is directed to In-Person proofing
	 */
	public boolean sendPasscodeSuccessful(Person person, PersonVo personVo) throws IPSException, PhoneVerificationException {
		CustomLogger.enter(this.getClass());

       	String loaSought = personVo.getProofingLevelSought();
        proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_initiated.getValue(), person, loaSought);

		try {
			RdpResponseModel response = callOtpWorkflow(personVo, person);

			if (response != null &&  (CustomLogger.isDebugEnabled())) {
					Gson g = new Gson();
					String responseJsonStr = g.toJson(response);
	            	CustomLogger.debug(this.getClass(), String.format("LexisNexis passcode request Json response: %s", responseJsonStr));
			}

			boolean passcodeSent = lexisnexisDataService.savePasscodeRequest(person, personVo, response);

            CustomLogger.debug(this.getClass(), String.format("LexisNexis passcode request %s for sponsorUserId: %s", (passcodeSent ? IPSConstants.VALUE_PASSED : IPSConstants.VALUE_FAILED), person.getSponsorUserId()));

			// Only move on to confirm passcode if the passcode was successfully sent
			if (passcodeSent) {
                proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_sent.getValue(), person, loaSought);
                return true;
            }
            else {
                 CustomLogger.debug(this.getClass(), "An error response was received from Lexis Nexis when generating passcode for sponsorUserId: " + personVo.getSponsorUserId()
                    + " " + personVo.getFullName());
  			}
		} catch (Exception ex) {
            CustomLogger.error(this.getClass(), "Exception occurred during the Lexis Nexis OTP call for sponsorUserId: " + personVo.getSponsorUserId()
                    + " " + personVo.getFullName(), ex);
		}

		return false;
	}

	private RdpResponseModel callOtpWorkflow(PersonVo personVo, Person person) throws PhoneVerificationException {
		PersonProofingStatus proofingStatus = person.getStatusForLoaSought(personVo.getProofingLevelSought());
		RdpRequestModel request = getPhoneFinderRequest(personVo);

		if (CustomLogger.isDebugEnabled()) {
			Gson g = new Gson();
			String requestJsonStr = g.toJson(request);
        	CustomLogger.debug(this.getClass(), String.format("LexisNexis passcode request Json request: %s", requestJsonStr));
		}

		return sendPhoneFinderRequest(personVo, request, proofingStatus, otpUrl, REQUEST_TYPE_INITIATE, SEND_PASSCODE, true);
	}

	@Override
	public RdpResponseModel sendSMSActivationCode(Person person) throws PhoneVerificationException {
		PersonProofingStatus proofingStatus = person.getStatusForLoaSought(person.getSoughtLoaLevel().getLoaLevel());
		if (!proofingStatus.isIppFailed()) {
			RdpRequestModel request = getSMSRequest(person, proofingStatus);

			if (CustomLogger.isDebugEnabled()) {
				Gson g = new Gson();
				String requestJsonStr = g.toJson(request);
				CustomLogger.debug(this.getClass(),
						String.format("LexisNexis SMS request Json request: %s", requestJsonStr));
			}

			PersonVo personVo = new PersonVo();
			
			return sendPhoneFinderRequest(personVo, request, proofingStatus, otpUrl, REQUEST_TYPE_INITIATE, "ActivateSMS", true);
		}
		return null;
	}

	private RdpRequestModel getSMSRequest(Person person, PersonProofingStatus proofingStatus) {
		RdpRequestModel request = new RdpRequestModel();
		request.setType(REQUEST_TYPE_INITIATE);
		RdpSettingsModel settings = new RdpSettingsModel();
		settings.setMode(SETTINGS_MODE_LIVE);
		settings.setReference(SETTINGS_REFERENCE);
		settings.setLocale(SETTINGS_LOCAL_US);
		settings.setVenue(SETTINGS_VENUE_ONLINE);
		request.setSettings(settings);

		OTPDeliveryInfoModel deliveryinfo = new OTPDeliveryInfoModel();
		deliveryinfo.setMethod(DELIVERY_METHOD);
		deliveryinfo.setLanguage(DELIVERY_LANGUAGE);
		request.setOtpDeliveryInfo(deliveryinfo);

		List<SMSCustomDataModel> customDataList = new ArrayList<>();
		SMSCustomDataModel cusData = new SMSCustomDataModel();
		if (!proofingStatus.isIppFailed()) {
			String activationCode = proofingStatus.getActivationCode();
			cusData.setValue(
					"Congratulations! USPS has verified your identity. Your activaton code is: " + activationCode);
		}
		cusData.setName("SMSBody");
		cusData.setType("otp");

		customDataList.add(cusData);
		request.setCustomData(customDataList);
		List<RdpPhoneModel> phones = new ArrayList<>();
		RdpPhoneModel phone = new RdpPhoneModel();
		phone.setNumber(person.getPersonData().getPhoneINT());
		phone.setContext("mobile");
		phones.add(phone);
		List<RdpPersonModel> personList = new ArrayList<>();
		RdpPersonModel reqPerson = new RdpPersonModel();
		reqPerson.setPhones(phones);
		reqPerson.setContext(CONTEXT_PRIMARY);
		personList.add(reqPerson);
		request.setPersons(personList);

		return request;
	}

	/*
     * This method MUST throw a PhoneVerificationException to ensure that the user is directed to In-Person proofing
	 */
	private RdpResponseModel callConfirmPasscodeWorkflow(PersonVo personVo, String conversationId)
			throws PhoneVerificationException {
		
		String passcode =  personVo.getPasscode();
		
		RdpRequestModel request = new RdpRequestModel();
		request.setType(REQUEST_TYPE_CONTINUE);
		RdpSettingsModel settings = new RdpSettingsModel();
		settings.setMode(SETTINGS_MODE_LIVE);
		settings.setLocale(SETTINGS_LOCAL_US);
		request.setSettings(settings);
		request.setPasscode(passcode);

		String resourceUrl = String.format("%s/%s", otpUrl, conversationId);
		return sendPhoneFinderRequest(personVo, request, null, resourceUrl, REQUEST_TYPE_CONTINUE, VALIDATE_PASSCODE, true);
	}

	/*
	 * This method MUST throw a PhoneVerificationException to ensure that the user
	 * is directed to In-Person proofing
	 */
	public boolean confirmPasscodeSuccessful(Person person, PersonVo personVo, RpEvent rpEvent)
			throws IPSException, PhoneVerificationException {
       	String loaSought = personVo.getProofingLevelSought();
       	boolean passcodeConfirmed = false;
    	//IVS enforced passcode expiration
       	boolean passcodeExpired = hasPasscodeExpired(person, personVo);
       
       	if (passcodeExpired) {
       		lexisnexisDataService.saveExpiredPasscodeResult(personVo, rpEvent);
       	}
       	else {
            proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_confirmation_initiated.getValue(), person, loaSought);

			String conversationId = lexisnexisDataService.retrievePasscodeConversationId(personVo.getId());

			try {
				RdpResponseModel response = callConfirmPasscodeWorkflow(personVo, conversationId);

				if (CustomLogger.isDebugEnabled()) {
					Gson g = new Gson();
					String responseJsonStr = g.toJson(response);
                	CustomLogger.debug(this.getClass(), String.format("LexisNexis passcode confirmation response Json: %s", responseJsonStr));
				}

				passcodeConfirmed = lexisnexisDataService.savePasscodeResult(person, personVo, response, rpEvent);
                CustomLogger.debug(this.getClass(), String.format("LexisNexis passcode confirmation %s for sponsorUserId: %s", (passcodeConfirmed ? IPSConstants.VALUE_PASSED : IPSConstants.VALUE_FAILED), person.getSponsorUserId()));

				// Return Truth Data to ThreatMetrix
				truthDataReturnService.returnRemoteProofingTruthData(person, passcodeConfirmed);
				CustomLogger.debug(this.getClass(), "Return Truth Data to ThreatMetrix for LexisNexis OTP Confirmation Result:" 
						+ (passcodeConfirmed? TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_PASS : TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_FAIL) );

	            RefSponsorConfiguration config = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
	                    RefSponsorConfiguration.ASSERT_TO_CUSTREG);

				if (passcodeConfirmed) {
                    proofingService.updateProofingStatus(RefRpStatus.RpStatus.LOA_level_achieved.getValue(), person, loaSought);
					// setup passcode results
                    if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
                    	passedOnlinePhoneVerification(person, personVo);
                    }
				} else {
                    proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_confirmation_failed.getValue(), person, loaSought);
					// setup passcode results
                    if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
                    	failedOnlinePasscodeVerification(person, personVo);
                    }
				}
			} catch (Exception ex) {
                CustomLogger.error(this.getClass(), "Exception occurred during the Lexis Nexis OTP call for user: " + personVo.getSponsorUserId()
                        + " " + personVo.getFullName(), ex);
				throw new PhoneVerificationException(ex.getMessage());
			}
		}

		return passcodeConfirmed;
	}

	@Override
	public boolean userFailedPhoneVerification(Person person) {
		person = getPerson(person.getPersonId());
		if (person == null) {
			CustomLogger.error(this.getClass(), "person is null, userFailedPhoneVerification() -> false");
			return true; // user failed EID phone verification
		} else {
			// product decision
			RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(),
                    RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID);
			if (event != null) {
				RpPhoneVerification rpPhoneVerification = event.getRpPhoneVerification();
                boolean isPhoneVerifiedFlag = rpPhoneVerification.isLexisNexisPhoneVerificationPassed();
                CustomLogger.info(this.getClass(), "User with sponsor user id: " + person.getSponsorUserId() + " -> isPhoneVerifiedFlag=" + isPhoneVerifiedFlag
                        + " userFailedPhoneVerification=" + (!isPhoneVerifiedFlag));
				return !isPhoneVerifiedFlag;
			} else {
				CustomLogger.error(this.getClass(), "event is null, userFailedPhoneVerification() -> false");
				return true;
			}
		}
	}

	/*
	 * Scenario 3 passed online phone verification
	 */
	private void passedOnlinePhoneVerification(Person person, PersonVo personVo) {
		CustomLogger.enter(this.getClass());
		String passcodeDecision = "";
		long passcodeSentDatetime = 0L;
		long passcodeDecisionDatetime = 0L;
		String otpMatchQuality = "";
		String productStatus = "";
		long totalSubmitAttempts = 0L;
		long totalRenewAttempts = 0L;
		long attemptsMade = 0L;
		try {
			RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(),
                    RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID);
			if (event != null) {
				RpPhoneVerification rpPhoneVerification = event.getRpPhoneVerification();
				attemptsMade = rpPhoneVerification.getNumberOfSubmitAttempts();

				RpOtpAttempt passcodeAttempt = event.getLatestOtpAttempt();

				// product decision
				passcodeDecision = passcodeAttempt.getOtpDecision();
				// passcode Sent date time
				passcodeSentDatetime = System.currentTimeMillis();
				// passcode decision date time
				passcodeDecisionDatetime = System.currentTimeMillis();
				// product status
				if (passcodeAttempt.getRefProductStatusCode() != null) {
					productStatus = passcodeAttempt.getRefProductStatusCode().getProductStatus();
				}
				// otp match quality
				if (passcodeAttempt.getRefOtpMatchQuality() != null) {
					otpMatchQuality = passcodeAttempt.getRefOtpMatchQuality().getMatchQuality();
				}
				// total submit attempts
				totalSubmitAttempts = rpPhoneVerification.getNumberOfSubmitAttempts();
				// total renew attempts
				totalRenewAttempts = rpPhoneVerification.getNumberOfRenewAttempts();
				// attempts Made

                CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
                assertionVo.setLoaSought(personVo.getProofingLevelSought());
                assertionVo.setLoaFlag(IPSConstants.LOA_FLAG_ACHIEVED);
                assertionVo.setVerificationDecision(passcodeDecision);
                assertionVo.setVerificationMatchQuality(otpMatchQuality);
                assertionVo.setProductStatus(productStatus);
                assertionVo.setRpStatusCode(RefRpStatus.RpStatus.LOA_level_achieved.getValue());
                assertionVo.setVerificationSentDatetime(passcodeSentDatetime);
                assertionVo.setVerificationDecisionDatetime(passcodeDecisionDatetime);
                assertionVo.setTotalSubmitAttempts(totalSubmitAttempts);
                assertionVo.setTotalRenewAttempts(totalRenewAttempts);
                assertionVo.setAttemptsAllowed(IPSConstants.RP_ATTEMPTS_ALLOWED);
                assertionVo.setAttemptsMade(attemptsMade);
                assertionVo.setAttemptsPeriod(IPSConstants.RP_ATTEMPT_PERIOD);
                assertionVo.setLoaName(IPSConstants.LOA_RP_LN_OTP_NAME);
                
                proofingService.passcodeOnlinePhoneVerification(person, personVo, assertionVo);
			}
		} catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred asserting passed Lexis Nexis OTP results to CustReg for user: " + personVo.getSponsorUserId(), e);
		}
	}

	/*
	 * Scenario 5 Failed online passcode verification
	 */
	private void failedOnlinePasscodeVerification(Person person, PersonVo personVo) {
		CustomLogger.info(this.getClass(), "failedOnlinePasscodeVerification");

		// passcode Sent date time
		long passcodeSentDatetime = System.currentTimeMillis();
		// passcode decision date time
		long passcodeDecisionDatetime = System.currentTimeMillis();

		// attempts Made
		RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(),
                RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID);
		if (event != null) {
			RpPhoneVerification rpPhoneVerification = event.getRpPhoneVerification();
			long attemptsMade = rpPhoneVerification.getNumberOfSubmitAttempts();

			// total submit attempts
			long totalSubmitAttempts = rpPhoneVerification.getNumberOfSubmitAttempts();
			// total renew attempts
			long totalRenewAttempts = rpPhoneVerification.getNumberOfRenewAttempts();

            CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
            assertionVo.setLoaSought(personVo.getProofingLevelSought());
            assertionVo.setLoaFlag(IPSConstants.LOA_FLAG_NOT_ACHIEVED);
            assertionVo.setVerificationDecision(IPSConstants.RP_DECISION_FAILED);
            assertionVo.setVerificationMatchQuality(IPSConstants.RP_EQUIFAX_IDMS_OTP_MISMATCH);
            assertionVo.setProductStatus(IPSConstants.RP_EQUIFAX_IDMS_OTP_COMPLETED);
            assertionVo.setRpStatusCode(RefRpStatus.RpStatus.OTP_confirmation_failed.getValue());
            assertionVo.setVerificationSentDatetime(passcodeSentDatetime);
            assertionVo.setVerificationDecisionDatetime(passcodeDecisionDatetime);
            assertionVo.setTotalSubmitAttempts(totalSubmitAttempts);
            assertionVo.setTotalRenewAttempts(totalRenewAttempts);
            assertionVo.setAttemptsAllowed(IPSConstants.RP_ATTEMPTS_ALLOWED);
            assertionVo.setAttemptsMade(attemptsMade);
            assertionVo.setAttemptsPeriod(IPSConstants.RP_ATTEMPT_PERIOD);
            assertionVo.setLoaName(IPSConstants.LOA_RP_LN_OTP_NAME);
            
            proofingService.passcodeOnlinePhoneVerification(person, personVo, assertionVo);
		}

	}

	@Override
	public boolean isPreCheckPassed() {
		return preCheckPassed;
	}

	public void setPreCheckPassed(boolean preCheckPassed) {
		this.preCheckPassed = preCheckPassed;
	}

	/*
     * While LexisNexis does track when a passcode expires and will return a message indicating that, there are a 
     * couple of issues with their handling.  They only return the expired indication when the passcode submitted is the correct one.
     * A conversation is also only good for a certain amount of time and will return an error after that time elapses.
     * This method checks if the passcode has expired and updates the rp_otp_attempt record in the database if it has.
	 * 
	 */
	private boolean hasPasscodeExpired(Person person, PersonVo personVo) {
        RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(), RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID);
        
        long otpExpiresMinutes = 5;
       
        String environment = Utils.getEnvironmentWithoutDot();
        if (!IPSConstants.ENV_PROD.equalsIgnoreCase(environment) &&  (personVo.getOtpExpiresMinutes() != null)) {
    			otpExpiresMinutes = Long.parseLong(personVo.getOtpExpiresMinutes());
        }
        
		if (event != null && event.lexisPasscodeHasExpired(otpExpiresMinutes)) {
			lexisnexisDataService.savePasscodeExpired(event);
			personVo.setErrorMessage(IPSConstants.PASSCODE_EXPIRED_MSG);
			personVo.setPasscodeExpired(true);
	   		setReturnResponseData(personVo, event, otpExpiresMinutes);

			return true;
        } 
        else {
        	personVo.setPasscodeExpired(false);
			return false;
		}
	}

	public void setProofingService(ProofingService proofingService) {
		this.proofingService = proofingService;
	}
	
	private void setStubPhoneFinderResponse(PersonVo personVo, RdpResponseModel phoneFinderResponse) {
     	String environment = Utils.getEnvironmentWithoutDot();
     	if (!IPSConstants.ENV_PROD.equalsIgnoreCase(environment)) {
     		if ("Testuser".equalsIgnoreCase(personVo.getFirstName()) && "Phonepass".equalsIgnoreCase(personVo.getLastName())) {
				 phoneFinderResponse.getStatus().setTransactionStatus("passed");
				 phoneFinderResponse.getStatus().getTransactionReasonCode().setCode("phone_finder_pass");
				 
				 int prodIndex = 0;
				 for (RdpProductModel product : phoneFinderResponse.getProducts()) {
	               if ("Discovery".equalsIgnoreCase(product.getProductType()) && product.getProductReason() != null) {
	                   phoneFinderResponse.getProducts().get(prodIndex).setProductReason(null);
	               }
	               else if ("Verification".equalsIgnoreCase(product.getProductType())) {
	               	int itemIndex = 0;
		                for (RdpProductItemModel item : product.getItems()) {
		                    RefLexisNexisReasonCodeMap map = new RefLexisNexisReasonCodeMap();
		                    if ("CurrentResidency".equalsIgnoreCase(item.getItemName())) {
		                    	phoneFinderResponse.getProducts().get(prodIndex).getItems().get(itemIndex).setItemStatus("pass");
		                    	map.setValue(IPSConstants.RP_LEXIS_PASSED);
			                    }
		                    itemIndex++;
		                }
		            }
	               prodIndex ++;
				 }
	     	}
     		
     		setReturnResponseData(personVo, phoneFinderResponse);
     	}
	}
	
	private void setReturnResponseData(PersonVo personVo, RdpResponseModel response) {
		if (personVo.isReturnDebugData()) {
			Gson g = new Gson();
			String responseStr = g.toJson(response);
			personVo.setResponseData(responseStr); 
		}
	}
	
	private void setReturnResponseData(PersonVo personVo, RpEvent event, long otpExpiresMinutes) {
		String environment = Utils.getEnvironmentWithoutDot();
        if (!IPSConstants.ENV_PROD.equalsIgnoreCase(environment) && personVo.isReturnDebugData()) {   
	      	if (event.getLatestOtpAttempt() != null) {
	   	    	  Timestamp lastAttemptDateTime = event.getLatestOtpAttempt().getOtpSentDateTime();
	 	          Date fiveMinutesAgo = new Date(System.currentTimeMillis() - otpExpiresMinutes*60*1000);
	 	          Timestamp fiveMinutesAgoDateTime = new Timestamp(fiveMinutesAgo.getTime());
		          boolean moreThan5minutes = fiveMinutesAgoDateTime.compareTo(lastAttemptDateTime) > 0;
		       	  personVo.setResponseData(String.format("ExpirationDuration:%s, LastAttemptDateTime:%s, fiveMinutesAgoDateTime:%s, moreThan5minutes:%s", 
		       			  otpExpiresMinutes, lastAttemptDateTime, fiveMinutesAgoDateTime, moreThan5minutes));
		    }
		      
			personVo.setPasscodeExpired(true);
        }
	}
	
}
