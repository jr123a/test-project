package com.ips.proofing;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.entity.Person;
import com.ips.entity.RpDeviceReputation;
import com.ips.entity.RpEvent;
import com.ips.persistence.common.PersonVo;
import com.ips.service.DeviceReputationService;
import com.ips.service.RpDeviceReputationService;

@Service("manageDeviceReputationService")
public class ManageDeviceReputationServiceImpl implements Serializable, ManageDeviceReputationService {

    private static final long serialVersionUID = 1L;

    @Autowired
	private DeviceReputationService deviceReputationService;
    @Autowired
	private RpDeviceReputationService rpDeviceReputationService;

   
    @Transactional
    public void updateDeviceReputation(Person person, PersonVo personVo, RpEvent phoneEvent) {
    	CustomLogger.enter(this.getClass());
    	
    	if (deviceReputationService.isDeviceProfilingEnabled(person.getPersonId(), person.getRefSponsor().getSponsorId(), personVo.getTransactionOriginAppName(), false)) {
			RpDeviceReputation deviceReputation = rpDeviceReputationService.getByPersonAndAppId(person.getPersonId(), phoneEvent.getTransactionOriginId().getAppId());

			if (deviceReputation != null) {
				deviceReputation.setRpEvent(phoneEvent);
				deviceReputation.setUpdateDate(DateTimeUtil.getCurrentTime());
				rpDeviceReputationService.update(deviceReputation);
              	CustomLogger.debug(this.getClass(), String.format("Remote proofing status: Device reputation with record id %s is updated with remote proofing event with id %s.", 
              			deviceReputation.getDeviceReputationId(), phoneEvent.getEventId()));        	
			}
		}
    }
}
