package com.ips.proofing;

import java.util.List;

import com.ips.entity.HighRiskAddressAttempt;
import com.ips.entity.Person;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefOtpVelocity;
import com.ips.entity.RefRpStatus.RpStatus;
import com.ips.entity.RpDeviceReputation;
import com.ips.persistence.common.CustRegAssertionParamVo;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.UserVo;
import com.ips.polocator.common.AppointmentVo;
import com.ips.polocator.common.IppVo;
import com.ips.polocator.common.LocationVo;

public interface ProofingService {
    
    UserVo getUserForRouting(UserVo user);
    UserVo optInToIpp(UserVo user) throws Exception;
    UserVo getUserFilteredPOList(UserVo user) throws Exception;
    UserVo optInToIppAtResidence(UserVo user, AppointmentVo appointment) throws Exception;

    UserVo resendIPPEmail(UserVo user, List<LocationVo> locsVo, boolean poListError) throws Exception;
    UserVo retryRemoteProofing(UserVo user) throws Exception;
    String displayConfirmationNumber(UserVo user);
    String getUniqueUID();
    void updateProofingStatus(Long statusCode, UserVo user);
    void updateProofingStatus(Long statusCode, Person person, String loaSought);
    void checkIfReproofing(String sponsorUserId, PersonVo personVo, String loaSought);
    void updatePersonProofingStatus(Person person, RpStatus rpStatus);
    void removePII(Person person);
    
    AppointmentVo findScheduledAppointment(UserVo user); 
    void cancelAppointment(UserVo user, AppointmentVo appt);
    AppointmentVo findAddressOnFile(UserVo user);
    IppVo getIppPageUserInfo(UserVo user);
    UserVo confirmOptIn(UserVo user, HighRiskAddressAttempt attempt, RpDeviceReputation deviceReputation) throws Exception;
    Person updatePerson(PersonVo p) throws Exception;
    
    RefOtpVelocity phoneVelocityCheck(Person person, PersonVo personVo, RefOtpSupplier verifyMethod);
    boolean lockoutStillInEffect(Person person, PersonVo personVo, RefOtpSupplier verifyMethod, RefLoaLevel level);
    void startProofingSession(Person person, PersonVo personVo) throws Exception;
    void phoneVerification(Person person, CustRegAssertionParamVo assertionVo);
    void passcodeOnlinePhoneVerification(Person person, PersonVo personVo, CustRegAssertionParamVo assertionVo);
	void smfaOnlinePhoneVerification(Person person, CustRegAssertionParamVo assertionVo);
	void ditVerification(Person person, CustRegAssertionParamVo assertionVo);
	void bokuOnlinePhoneVerification(Person person, CustRegAssertionParamVo assertionVo);

}
