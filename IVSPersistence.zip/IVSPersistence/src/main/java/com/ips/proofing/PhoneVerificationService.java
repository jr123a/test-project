package com.ips.proofing;

import java.io.IOException;

import com.equifax.eid.soap.schema.usidentityfraudservice.v2.CredentialsErrorFault;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.InvalidTransactionKeyFault;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.ValidationErrorFault;
import com.ips.entity.Person;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RpEvent;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationParamVo;
import com.ips.persistence.common.PhoneVerificationResponse;

public interface PhoneVerificationService {
	PhoneVerificationResponse verifyPhone(PersonVo personVo, RefOtpSupplier otpSupplier) throws Exception, Throwable;
    int sendSmfaLink(PersonVo personVo, RefOtpSupplier otpSupplier, boolean isDesktop) throws IPSException, PhoneVerificationException, IOException;
    boolean sendPasscodeSuccessful(PersonVo personVo, RefOtpSupplier otpSupplier) throws IPSException, PhoneVerificationException, Throwable;	 
    boolean confirmPasscode(PersonVo personVo, RefOtpSupplier otpSupplier, RpEvent event) throws  IPSException, PhoneVerificationException, CredentialsErrorFault, InvalidTransactionKeyFault, ValidationErrorFault;
    boolean resendPasscode(PersonVo personVo, RefOtpSupplier otpSupplier, RpEvent event) throws IPSException, PhoneVerificationException, Throwable;
    boolean hasPreviousPhoneVerificationDecision(Person person, PersonVo personVo, PhoneVerificationParamVo verificationParamVo) throws IPSException, PhoneVerificationException;
    boolean userFailedEIDPhoneVerification(PersonVo personVo, RefOtpSupplier otpSupplier);
    boolean isPrecheckPassed();
}
