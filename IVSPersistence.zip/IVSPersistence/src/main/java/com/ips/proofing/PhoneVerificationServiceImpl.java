package com.ips.proofing;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equifax.eid.soap.schema.usidentityfraudservice.v2.CredentialsErrorFault;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.InvalidTransactionKeyFault;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.ValidationErrorFault;
import com.equifax.smfa.response.InitiateSMFAResponseModel;
import com.ips.common.common.CustomLogger;
import com.ips.entity.Person;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpEvent;
import com.ips.entity.RpPhoneVerification;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.ExperianResultVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationParamVo;
import com.ips.persistence.common.PhoneVerificationResponse;
import com.ips.service.OtpAttemptConfigService;
import com.ips.service.PersonDataService;
import com.ips.service.RefLoaLevelService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;
import com.ips.service.RpEventDataService;


@Service("phoneVerificationService")
public class PhoneVerificationServiceImpl implements Serializable, PhoneVerificationService {

    private static final long serialVersionUID = 1L;

    @Autowired
    private EquifaxService equifaxService;
    @Autowired
    private ExperianService experianService;
    @Autowired
    private LexisNexisService lexisnexisService;
    @Autowired
    private OtpAttemptConfigService otpAttemptConfigService;
    @Autowired
    private PersonDataService personService;
    @Autowired
    private ProofingService proofingService;
    @Autowired
    private RefLoaLevelService refLoaLevelService;
    @Autowired
    private RefSponsorConfigurationService refSponsorConfigurationService;
    @Autowired
    private RefSponsorDataService refSponsorService;
    @Autowired
    private RpEventDataService rpEventDataService;
    @Autowired
    private VerificationProviderService verificationProviderService;
    
    private boolean precheckPassed;
    public static final String IS_EQUIFAX_PHONE_FMT = "isEquifaxPhone:%s";
    public static final String VALUE_TRUE = "true";
    public static final String VALUE_FALSE = "false";
    public static final String NEXT_AVAIL_SUPP_MSG_FMT = "Next available supplier is %s.";
    public static final String ALL_AVAIL_SUPP_FAILED_MSG_FMT = "All calls to available suppliers failed. Route User to In Person Proofing for sponsorUserId: %s.";
    public static final String CALL_TO_SUPP_FAILED_MSG_FMT = "Call to %s VerifyPhone failed. Determine next available supplier.";
    public static final String OTP_SWITCHING_ENABLED_MSG_FMT = "OTP Switching Is Not Enabled (100 Pct %s). Route User to In Person Proofing for sponsorUserId: %s.";
    public static final String VERIFY_PHONE_RESULT_MSG_FMT = "%s VerifyPhone result: PhoneVerified is %s.";

    
    public PhoneVerificationResponse verifyPhone(PersonVo personVo, RefOtpSupplier pvSupplier) throws Throwable {
         // The personVo parameter will include the personal data passed to the web service or retrieved from CustReg
    
        // Retrieve the person record
        Person person = personService.findByPK(personVo.getId());
        RefLoaLevel level = refLoaLevelService.findByCode(RefLoaLevel.LOA15_CODE);
        return getPhoneVerificationResponse(personVo, person, pvSupplier, level);
    }
    
    public PhoneVerificationResponse getPhoneVerificationResponse(PersonVo personVo, Person person, RefOtpSupplier pvSupplier,
    		RefLoaLevel level) throws Throwable {
    	
        RefSponsor sponsor = refSponsorService.findBySponsorName(personVo.getSponsor());
        PhoneVerificationResponse pvResponse = null;
        boolean phoneVerified = false;
        String supplierName = "";
        
        try {
        	if (pvSupplier.isEquifaxDITPhone() || pvSupplier.isEquifaxIDFSPhone()) {
        		pvResponse = equifaxService.verifyPhone(person, personVo, pvSupplier);
        		supplierName = pvSupplier.isEquifaxDITPhone()? RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME : RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_NAME;

	        	if (personVo.isAlternateSupplierForCustNotOnFile()) {
	                personVo.setPhoneVerificationSupplierName(pvResponse.getPhoneVerificationSupplierName());
	                personVo.setCurrentPhoneVerificationSupplierId(pvResponse.getPhoneVerificationSupplierId());

	        		phoneVerified = IPSConstants.VALUE_PASS.equalsIgnoreCase(pvResponse.getPhoneVerificationDecision())
	            			|| IPSConstants.VALUE_REVIEW.equalsIgnoreCase(pvResponse.getPhoneVerificationDecision());
	        		CustomLogger.debug(this.getClass(), String.format(VERIFY_PHONE_RESULT_MSG_FMT, supplierName, phoneVerified));

	                return pvResponse;
	        	}
        	}
        	else if (pvSupplier.isLexisNexisPhone()) {
        		pvResponse = lexisnexisService.verifyPhone(person, personVo);
        		setPrecheckPassed(lexisnexisService.isPreCheckPassed());
        	}
        	else if (pvSupplier.isExperianPhone()) {
         		pvResponse = experianService.verifyPhone(person, personVo, null);
         		boolean reviewDecision = PhoneVerificationResponse.PV_DECISION_REVIEW.equalsIgnoreCase(pvResponse.getPhoneVerificationDecision());
        		boolean custNotFound = ExperianResultVo.FAILURE_REASON_CODE_CUST_NOT_FOUND.equalsIgnoreCase(pvResponse.getFailureReason());
        		boolean errorResponse = ExperianResultVo.FAILURE_REASON_CODE_ERROR_RESPONSE.equalsIgnoreCase(pvResponse.getFailureReason());

         		if (reviewDecision && (custNotFound || errorResponse)) {
        			personVo.setFailedExperianCrossCoreCall(true); 
        			
        			if (custNotFound) {
        				personVo.setExperianCustomerNotOnFile(true);
        			}
        			else if (errorResponse) {
        				personVo.setExperianErrorResponse(true);
        			}
                  	
        			RefOtpSupplier nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor);
        			
        			if (nextSupplier != null) {
	                   	personVo.setPhoneVerificationSupplierName(nextSupplier.getOtpSupplierName());
	        			pvSupplier = nextSupplier;
	        			
	        			if (custNotFound) {
	        				personVo.setAlternateSupplierForCustNotOnFile(true);
	        			}
	        			else if (errorResponse) {
	        				personVo.setAlternateSupplierForErrorResponse(true);
	        			}
	                	return verifyPhone(personVo, nextSupplier);
        			}
        			else {
        	            // In this scenario the alternate supplier selected is still Experian.
                        personVo.setPhoneVerificationSupplierName(null);
                        return new PhoneVerificationResponse(0L, null, PhoneVerificationResponse.PV_DECISION_FAIL, pvResponse.getEventFinalDecision());
        			}
         		}
        		
        		return pvResponse;
        	}
        	
    		if (pvSupplier == null || pvSupplier.getOtpSupplierName() == null) {
    			 return pvResponse;
    		}
		
        } 
        // If the first OTP supplier chosen returns an error, switch to the other supplier.
        catch (PhoneVerificationException e) {
            CustomLogger.info(this.getClass(), String.format(CALL_TO_SUPP_FAILED_MSG_FMT, supplierName));
    		
          	
            if (pvSupplier.isEquifaxDITPhone()) {
          		personVo.setFailedEquifaxDITCall(true);
          	}
        	else if (pvSupplier.isLexisNexisPhone()) {
        		personVo.setFailedLexisNexisRDPCall(true);
        	}
        	else if (pvSupplier.isExperianPhone()) {
        		personVo.setFailedExperianCrossCoreCall(true);
        	}
        	else if (pvSupplier.isEquifaxIDFSPhone()) {
          		personVo.setFailedEquifaxIDFSCall(true);        	
          	}
 
         	RefOtpSupplier nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor);
           	boolean getAnotherSupplier = false;
           	long anotherSupplierId = 0L;
            if (nextSupplier != null) {
	          	if (nextSupplier.isEquifaxDITPhone() && personVo.isFailedEquifaxDITCall()) {
	          		getAnotherSupplier = true;
	          		anotherSupplierId = RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID;
	           	}
	          	else if (nextSupplier.isLexisNexisPhone() && personVo.isFailedLexisNexisRDPCall()) {
	          		getAnotherSupplier = true;
	          		anotherSupplierId = RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID;
	          	}
	          	else if (nextSupplier.isExperianPhone() && personVo.isFailedExperianCrossCoreCall()) {
	          		getAnotherSupplier = true;
	          		anotherSupplierId = RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID;
	          	}
	          	else if (nextSupplier.isEquifaxIDFSPhone() && personVo.isFailedEquifaxIDFSCall()) {
	          		getAnotherSupplier = true;
	          		anotherSupplierId = RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID;
	          	}
	          	
	          	if (getAnotherSupplier) {
	         		otpAttemptConfigService.reset(RefLoaLevel.LOA15_CODE, sponsor.getSponsorId());
	              	nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor, anotherSupplierId);
	          	}
            }
          	
          	if (nextSupplier == null) {
                return new PhoneVerificationResponse(0L, null, PhoneVerificationResponse.PV_DECISION_FAIL, null);
          	}
          	
         	personVo.setPhoneVerificationSupplierName(nextSupplier.getOtpSupplierName());
           	pvSupplier = nextSupplier;
         	String nextSupplierName = nextSupplier.getOtpSupplierName();
           	
         	boolean isEquifaxDITAvailable = nextSupplier.isEquifaxDITPhone() && !personVo.isFailedEquifaxDITCall(); 
  			boolean isEquifaxIDFSAvailable = nextSupplier.isEquifaxIDFSPhone() && !personVo.isFailedEquifaxIDFSCall(); 
      		boolean isLexisNexisAvailable = nextSupplier.isLexisNexisPhone() && !personVo.isFailedLexisNexisRDPCall();
			boolean isExperianAvailable = nextSupplier.isExperianPhone() && !personVo.isFailedExperianCrossCoreCall();
			boolean hasNextAvailableSupplier = false;	

         	if (pvSupplier.isEquifaxDITPhone() && !nextSupplier.isEquifaxDITPhone()) {
         		hasNextAvailableSupplier = isEquifaxIDFSAvailable || isLexisNexisAvailable || isExperianAvailable;
          	}
         	else if (pvSupplier.isEquifaxIDFSPhone() && !nextSupplier.isEquifaxIDFSPhone()) {
         		hasNextAvailableSupplier = isEquifaxDITAvailable || isLexisNexisAvailable || isExperianAvailable;
    		}
         	else if (pvSupplier.isLexisNexisPhone() && !nextSupplier.isLexisNexisPhone()) {
         		hasNextAvailableSupplier = isEquifaxDITAvailable || isEquifaxIDFSAvailable || isExperianAvailable;
    		}
         	else if (pvSupplier.isExperianPhone() && !nextSupplier.isExperianPhone()) {
         		hasNextAvailableSupplier = isEquifaxDITAvailable || isEquifaxIDFSAvailable || isLexisNexisAvailable;
     		}
    		else {
                // In this scenario the selected supplier is configured to 100% so exception needs to be thrown to result in transfer to the confirm cancel page
                CustomLogger.error(this.getClass(), String.format(OTP_SWITCHING_ENABLED_MSG_FMT, supplierName, personVo.getSponsorUserId()));
                personVo.setPhoneVerificationSupplierName(null);
                return new PhoneVerificationResponse(0L, null, PhoneVerificationResponse.PV_DECISION_FAIL, null);
    		}
         	
     		if (hasNextAvailableSupplier) {
       			CustomLogger.debug(this.getClass(), String.format(NEXT_AVAIL_SUPP_MSG_FMT, nextSupplierName));
     			verifyPhone(personVo, nextSupplier);
     			
     			if (pvResponse != null) {
	     			personVo.setPhoneVerificationSupplierName(pvResponse.getPhoneVerificationSupplierName());
	     	        personVo.setCurrentPhoneVerificationSupplierId(pvResponse.getPhoneVerificationSupplierId());
     			}
     			
     	        return pvResponse;
     		}
			else {
                // In this scenario the all calls to available suppliers failed so exception needs to be thrown to result in transfer to the confirm cancel page
                CustomLogger.error(this.getClass(), String.format(ALL_AVAIL_SUPP_FAILED_MSG_FMT, personVo.getSponsorUserId()));
                personVo.setPhoneVerificationSupplierName(null);
                return new PhoneVerificationResponse(0L, null, PhoneVerificationResponse.PV_DECISION_FAIL, null);
    		}
        }
        
       	phoneVerified = IPSConstants.VALUE_PASS.equalsIgnoreCase(pvResponse.getPhoneVerificationDecision())
    			|| IPSConstants.VALUE_REVIEW.equalsIgnoreCase(pvResponse.getPhoneVerificationDecision());
        CustomLogger.debug(this.getClass(), String.format(VERIFY_PHONE_RESULT_MSG_FMT, supplierName, phoneVerified));

        return pvResponse;
    }
    
    public boolean sendPasscodeSuccessful(PersonVo personVo, RefOtpSupplier otpSupplier) throws Throwable {
        // The personVo parameter will include the personal data passed to the web service or retrieved from CustReg
        CustomLogger.enter(this.getClass(), "Passcode being sent by supplier:"+ otpSupplier.getOtpSupplierName());
    
        // Retrieve the person record
        Person person = personService.findByPK(personVo.getId());
        boolean sendPasscodeSuccessful = false;
        
        if (otpSupplier.isEquifaxIDFSPhone()) {
        	sendPasscodeSuccessful = equifaxService.sendPasscodeSuccessful(person, personVo);
        }
        else if (otpSupplier.isLexisNexisPhone()) { 
        	sendPasscodeSuccessful = lexisnexisService.sendPasscodeSuccessful(person, personVo);
        }
        else if (otpSupplier.isExperianPhone()) { 
        	sendPasscodeSuccessful = experianService.resendPasscodeSuccessful(person, personVo);
        }

        return sendPasscodeSuccessful;
    }
    
    public boolean confirmPasscode(PersonVo personVo, RefOtpSupplier otpSupplier, RpEvent event) throws IPSException, PhoneVerificationException, CredentialsErrorFault, InvalidTransactionKeyFault, ValidationErrorFault {
        // The personVo parameter will include the personal data passed to the web service or retrieved from CustReg
        CustomLogger.enter(this.getClass(), String.format(IS_EQUIFAX_PHONE_FMT,  (otpSupplier.isEquifaxIDFSPhone() ? VALUE_TRUE : VALUE_FALSE)));
    
        // Retrieve the person record
        Person person = personService.findByPK(personVo.getId());
        boolean confirmPasscodeSuccessful = false;
        
        if (otpSupplier.isEquifaxIDFSPhone()) {
        	confirmPasscodeSuccessful = equifaxService.confirmPasscodeSuccessful(person, personVo, event);
        }
        else if (otpSupplier.isLexisNexisPhone()) { 
        	confirmPasscodeSuccessful = lexisnexisService.confirmPasscodeSuccessful(person, personVo, event);
        }
        else if (otpSupplier.isExperianPhone()) { 
        	confirmPasscodeSuccessful = experianService.confirmPasscodeSuccessful(person, personVo, event);
        }
        
        return confirmPasscodeSuccessful;
    }

    public boolean resendPasscode(PersonVo personVo, RefOtpSupplier otpSupplier, RpEvent event) throws Throwable {
        // The personVo parameter will include the personal data passed to the web service or retrieved from CustReg
        CustomLogger.enter(this.getClass(), String.format(IS_EQUIFAX_PHONE_FMT,  (otpSupplier.isEquifaxIDFSPhone() ? VALUE_TRUE : VALUE_FALSE)));
    
        boolean renewAttemptsExceeded = false;
        boolean resendPasscodeSuccessful = false;
   
        // Retrieve the person record
        Person person = personService.findByPK(personVo.getId());
        
        if (otpSupplier.isEquifaxIDFSPhone()) {
            // The most recent transaction key must be retrieved from the last otp attempt
        	renewAttemptsExceeded = equifaxService.resendPasscodeSuccessful(event, person, personVo);
        	return renewAttemptsExceeded;
        }
        else if (otpSupplier.isLexisNexisPhone()) { 
            // LexisNexis does not have a renew/resend function - just send another passcode
        	resendPasscodeSuccessful = lexisnexisService.sendPasscodeSuccessful(person, personVo);
        	return resendPasscodeSuccessful;
        }
        else if (otpSupplier.isExperianPhone()) { 
        	resendPasscodeSuccessful = experianService.resendPasscodeSuccessful(person, personVo);
        	return resendPasscodeSuccessful;
        }
        
        return resendPasscodeSuccessful;
    }

    @Override
    public boolean userFailedEIDPhoneVerification(PersonVo personVo, RefOtpSupplier otpSupplier) {
        // Retrieve the person record
        Person person = personService.findByPK(personVo.getId());
 
        if (otpSupplier.isEquifaxIDFSPhone()) {
            return equifaxService.userFailedEIDPhoneVerification(person, RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID);
        }
        else if (otpSupplier.isEquifaxDITPhone()) {
             return equifaxService.userFailedEIDPhoneVerification(person, RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID);
        }
        else if(otpSupplier.isLexisNexisPhone()) {
            return lexisnexisService.userFailedPhoneVerification(person);
        }
        return false;
    }

    @Override
    public boolean hasPreviousPhoneVerificationDecision(Person person, PersonVo personVo, PhoneVerificationParamVo verificationParamVo) throws IPSException, PhoneVerificationException {    
          CustomLogger.enter(this.getClass());
 
          RpEvent previousEvent = rpEventDataService.getLatestPhoneEventsByPersonIdAndPhoneNumber(person.getPersonId(), personVo.getMobileNumber());
          personVo.setHasPreviousPhoneVerificationDecision(false);
 
          if (previousEvent == null) {
                return false;
          }
          
          RpPhoneVerification phoneVerification = previousEvent.getRpPhoneVerification();
           
          if (phoneVerification == null) {
               return false;
          }
          
          boolean isWithinTimerWindow = isWithinVelocityTimerWindow(phoneVerification, personVo.getSponsorId());
 
          if (!isWithinTimerWindow) {
        	  return false;
        }
          
           if (personVo.isResetProofingStatus()) {
               return false;
          }
             
         //Previously assessed with Equifax 
          if (phoneVerification.getEidDecision() != null) {
        	  String overallAssessment = phoneVerification.getOverallAssessment();
        	  boolean isSupplierEquifaxIDFS = RpPhoneVerification.DECISION_PASSED.equalsIgnoreCase(overallAssessment)
        			  || RpPhoneVerification.DECISION_FAILED.equalsIgnoreCase(overallAssessment);
 
        	  long supplierId = isSupplierEquifaxIDFS ? RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID : RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID;
              personVo.setPreviousPhoneVerificationSupplierId(supplierId);
           }
          else {    
        	  //Previously assessed with LexisNexis
              personVo.setPreviousPhoneVerificationSupplierId(RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID);
           }

           personVo.setHasPreviousPhoneVerificationDecision(true);
          
           return true;
      }
    
    private boolean isWithinVelocityTimerWindow(RpPhoneVerification phoneVerification, long sponsorId) {
        CustomLogger.enter(this.getClass());
  
        try {        
            RefSponsorConfiguration velocityTimerConfig = refSponsorConfigurationService.getConfigRecord((int) sponsorId, 
                    RefSponsorConfiguration.DEVICE_VELOCITY_TIMER);
 
            long velocityTimerMinutes = 15L;
           
            if (velocityTimerConfig != null) {
               	velocityTimerMinutes = Long.parseLong(velocityTimerConfig.getValue());
             }
            
            if (velocityTimerMinutes == 0L) {
                 return false;
            }
            
            Timestamp lastTransTime = phoneVerification.getDecisionDateTime();
            Timestamp currentTime = new Timestamp(new Date().getTime());
            long duration = currentTime.getTime() - lastTransTime.getTime();
            long diffMinutes = TimeUnit.MILLISECONDS.toMinutes(duration);

            if (diffMinutes <= velocityTimerMinutes) {
                return true;
            }

        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred on getting RefSponsorConfiguration of velocity timer.", e);
        }

        return false;
    }
    
    /**
     * Changing return from boolean to the following:
     * 0 sent successfully
     * 200 landline
     * 500 error non landline
     * 422 error unable to verify 
     * @throws IOException 
     */
    public int sendSmfaLink(PersonVo personVo, RefOtpSupplier otpSupplier, boolean isDesktop) throws IPSException, PhoneVerificationException, IOException {
    	 CustomLogger.enter(this.getClass());
    	 
    	 Person person = personService.findByPK(personVo.getId());
       	 String loaSought = personVo.getProofingLevelSought();
         proofingService.updateProofingStatus(RefRpStatus.RpStatus.SMFA_initiated.getValue(), person, loaSought);
    	 InitiateSMFAResponseModel initiateResponse = equifaxService.sendSmfaLink(person, personVo, isDesktop);
    	 
    	 if (initiateResponse != null) {
    		 if (initiateResponse.isLinkSuccessfullySent()) {
    			 proofingService.updateProofingStatus(RefRpStatus.RpStatus.SMFA_sent.getValue(), person, loaSought);
    			 return 0;
       		}
     		else if (initiateResponse.getEfxErrorCode() != null) {
     			if ("200".equals(initiateResponse.getEfxErrorCode())) {
     	    		 return 200;
     			}
     			else {
     			// parsing 422.00 to get 422
     			    int efxErrorCode = Integer.parseInt(initiateResponse.getEfxErrorCode().substring(0, 3));
        			return efxErrorCode;
     			}
    		}
    	 }
    	 
    	 return 422;
    }

    @Override
    public boolean isPrecheckPassed() {
        return precheckPassed;
    }

    public void setPrecheckPassed(boolean precheckPassed) {
        this.precheckPassed = precheckPassed;
    }
}

