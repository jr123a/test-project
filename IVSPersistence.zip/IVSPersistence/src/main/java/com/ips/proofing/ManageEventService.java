package com.ips.proofing;

import com.ips.entity.RpEvent;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationResponse;

public interface ManageEventService {
    
	RpEvent createEvent(PersonVo personVo, RpEvent previousEvent, long supplierId);
	PhoneVerificationResponse savePreviousPhoneVerificationResults(RpEvent event, RpEvent prevEvent, 
			PersonVo personVo, long supplierId);

}
