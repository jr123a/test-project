package com.ips.proofing;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equifax.common.AdditionalErrorDetailModel;
import com.equifax.common.ConsumerIdentifierModel;
import com.equifax.dit.request.AdditionalFieldModel;
import com.equifax.dit.request.AddressModel;
import com.equifax.dit.request.DataModel;
import com.equifax.dit.request.EmailModel;
import com.equifax.dit.request.IdentityModel;
import com.equifax.dit.request.InitiateDITRequestModel;
import com.equifax.dit.request.NameModel;
import com.equifax.dit.request.PhoneModel;
import com.equifax.dit.response.DetailModel;
import com.equifax.dit.response.InitiateDITResponseModel;
import com.equifax.eid.soap.schema.identityfraudservice.v2.CredentialsErrorFault;
import com.equifax.eid.soap.schema.identityfraudservice.v2.ValidationErrorFault;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.DynamicOTP;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.InitialRequest;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.InitialResponse;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.InvalidTransactionKeyFault;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.SubsequentRequest;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.SubsequentResponse;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.UsIdentityFraudServiceTypeV2;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.UsIdentityFraudServiceV2;
import com.equifax.smfa.request.InitiateSMFARequestModel;
import com.equifax.smfa.request.StatusSMFARequestModel;
import com.equifax.smfa.response.InitiateSMFAResponseModel;
import com.equifax.smfa.response.OtpLifecycleModel;
import com.equifax.smfa.response.ResponseStatusModel;
import com.equifax.smfa.response.StatusSMFAResponseModel;
import com.google.gson.Gson;
import com.ips.common.common.AliasVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.Utils;
import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefApp;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpDitResponse;
import com.ips.entity.RpEvent;
import com.ips.entity.RpPhoneVerification;
import com.ips.entity.RpPhoneVerificationResult;
import com.ips.entity.RpSmfaAttempt;
import com.ips.entity.RpSmfaInitiateResponse;
import com.ips.entity.RpSmfaValidateResponse;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.jaxb.ConfirmPasscodeIDFSRequestXML;
import com.ips.jaxb.InitialIDFSRequestXML;
import com.ips.jaxb.ResendPasscodeIDFSRequestXML;
import com.ips.jaxb.SendPasscodeIDFSRequestXML;
import com.ips.persistence.common.CustRegAssertionParamVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationResponse;
import com.ips.service.EquifaxDataService;
import com.ips.service.PersonDataService;
import com.ips.service.RefAppService;
import com.ips.service.RefEfxDitDecisionMapService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RpDitResponseService;
import com.ips.service.RpEventDataService;
import com.ips.service.RpProofingSessionDataService;
import com.ips.service.RpSmfaInitiateResponseService;
import com.ips.service.RpSmfaValidateResponseService;
import com.ips.service.TruthDataReturnService;
import com.ips.service.TruthDataReturnServiceImpl;

@Service("equifaxService")
public class EquifaxServiceImpl implements EquifaxService, Serializable {
	private static final long serialVersionUID = 1L;

	@Autowired
	private CommonRestServiceImpl commonRestService;
	@Autowired
	private EquifaxDataService equifaxDataService;
	@Autowired
	private ManageDeviceReputationService manageDeviceReputationService;
	@Autowired
	private ManageEventService manageEventService;
	@Autowired
	private PersonDataService personService;
	@Autowired
	private ProofingService proofingService;
	@Autowired
	private RefAppService refAppService;
	@Autowired
	private RefEfxDitDecisionMapService efxDitDecisionMapService;
	@Autowired
    private RefSponsorConfigurationService refSponsorConfigurationService;
	@Autowired
	private RpDitResponseService rpDitResponseService;
	@Autowired
	private RpEventDataService rpEventService;
	@Autowired
	private RpProofingSessionDataService rpProofingSessionService;
	@Autowired
	private RpSmfaInitiateResponseService rpSmfaInitiateResponseService;
	@Autowired
	private RpSmfaValidateResponseService rpSmfaValidateResponseService;
	@Autowired
	private TruthDataReturnService truthDataReturnService;
  
	private static final String LOG_EQUIFAX_CALL_EXCEPTION_FMT = "Exception occurred during the Equifax call for user: %s";
	private static final String LOG_EQUIFAX_CALL_SOAP_EXCEPTION_FMT = "SOAPFaultException occurred during the Equifax call for user: %s";
	private static final String EQUIFAX_CLIENT_ID_J2C_ALIAS = "Equifax2ClientID";
	private static final String EQUIFAX_CLIENT_SECRET_J2C_ALIAS = "Equifax2ClientSecret";
	private static final String EQUIFAX_DIT_TENANT_ID_J2C_ALIAS = "EquifaxDITTenantID";
	private static final String EQUIFAX_DIT_APPLICATION_ID_J2C_ALIAS = "EquifaxDITApplicationID";
	private static final String EQUIFAX_SMFA_MERCHANT_ID_J2C_ALIAS = "EquifaxSMFAMerchantID";
	private static final String EQUIFAX_2_OAUTH_ENDPT = "com.ipsweb.Equifax2OauthEndpoint";
	public static final String EQUIFAX_DIT_OAUTH_SCOPE = "https://api.equifax.com/business/id-risk-assessment/v2";
	public static final String EQUIFAX_SMFA_OAUTH_SCOPE = "https://api.equifax.com/business/secure-mfa";
	private static final String EQUIFAX_SMFA_TARGET_URL_FMT = "%s/verification_validate_smfa.xhtml";
	private static final String EQUIFAX_SMFA_DESKTOP_TARGET_URL_FMT = "%s/verification_smfa_success.xhtml";
	private static final String EQUIFAX_SMFA_SMS_URL_FMT = "USPS: Tap this secure link to verify your identity: %s/c.xhtml?CONTINUE=%s It expires in 4 min. Do not share it.";

	private static final String EQUIFAX_DIT_OAUTH_GRANT_TYPE = "client_credentials";
	public static final String EQUIFAX_DIT_TOKEN_TYPE = "DIT";
	public static final String EQUIFAX_SMFA_TOKEN_TYPE = "SMFA";
	private static final String SESSION_ID_FORMAT = "%s-%s";
	private static final String SESSION_ID_KEY = "SessionID";
	private static final String SUBJECT_TYPE_MDN = "MDN";
	private static final String USE_CASE_SO = "SO";
	private static final String VALUE_TRUE = "True";
	
	/**
	 * Calls the Equifax web service to verify the phone number. Persists all of the
	 * related data to the database after the call.
	 * @throws Throwable 
	 */
	public PhoneVerificationResponse verifyPhone(Person person, PersonVo personVo, RefOtpSupplier pvSupplier)
			throws Throwable {
		CustomLogger.enter(this.getClass());

		PhoneVerificationResponse pvResponse = null;

		if (person == null || personVo == null) {
			return pvResponse;
		}

		String phoneVerificationSupplier = pvSupplier.getOtpSupplierName();
		boolean isEquifaxDIT = RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME
				.equalsIgnoreCase(phoneVerificationSupplier);
		String supplierName = isEquifaxDIT ? RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME
				: RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_NAME;
		long supplierId = isEquifaxDIT ? RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID
				: RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID;
		String loaSought = personVo.getProofingLevelSought();

		proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_initiated.getValue(), person,
				loaSought);
		CustomLogger.debug(this.getClass(),
				String.format("Remote proofing status: %s Phone verification is initiated.", supplierName));

		try {
			boolean hasPreviousPhoneVerificationDecision = personVo.hasPreviousPhoneVerificationDecision();
			RpEvent prevPhoneEvent = null;

			if (hasPreviousPhoneVerificationDecision) {
				prevPhoneEvent = rpEventService.getLatestPhoneEventsByPersonIdAndPhoneNumber(person.getPersonId(),
						personVo.getMobileNumber());
			}

			RpEvent phoneEvent = manageEventService.createEvent(personVo, prevPhoneEvent, supplierId);

			// Device Reputation
			manageDeviceReputationService.updateDeviceReputation(person, personVo, phoneEvent);


            RefSponsorConfiguration config = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
                    RefSponsorConfiguration.ASSERT_TO_CUSTREG);

			if (hasPreviousPhoneVerificationDecision) {
				pvResponse = manageEventService.savePreviousPhoneVerificationResults(phoneEvent, prevPhoneEvent,
						personVo, supplierId);

				if (pvResponse == null) {
			        return new PhoneVerificationResponse(supplierId, supplierName, PhoneVerificationResponse.PV_DECISION_FAIL, phoneEvent.getFinalDecision());    
				}
				
				String pvDecision = pvResponse.getPhoneVerificationDecision();
				//long supplierId = RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_NAME.equalsIgnoreCase(
				//		personVo.getPhoneVerificationSupplierName()) ? RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID
				//				: RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID;

				CustomLogger.debug(this.getClass(), String.format(
						"Remote proofing status: User with sponsorUserId %s has previous %s phone verification with a decision of %s.",
						person.getSponsorUserId(), supplierName, pvDecision));

				if (RpPhoneVerification.DECISION_PASSED.equalsIgnoreCase(pvDecision)) {
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verified.getValue(), person,
							loaSought);
	               if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
	            	   passedPhoneVerification(person, personVo, supplierId);
	               }
				} else if (RpPhoneVerification.DECISION_FOR_REVIEW.equalsIgnoreCase(pvDecision)) {
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.SMFA_initiated.getValue(), person,
							loaSought);
					if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
						passedPhoneVerification(person, personVo, supplierId);
					}
				} else if (RpPhoneVerification.DECISION_FAILED.equalsIgnoreCase(pvDecision)
						|| RpPhoneVerification.DECISION_DENIED.equalsIgnoreCase(pvDecision)) {
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_failed.getValue(),
							person, loaSought);
					if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
						failedPhoneVerification(person, personVo, supplierId);
					}
				} else if (RpPhoneVerification.DECISION_APPROVED.equalsIgnoreCase(pvDecision)) {
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.LOA_level_achieved.getValue(), person,
							loaSought);
					passedOnlinePhoneVerification(person, personVo, config);
				}

				personVo.setPhoneVerificationDecision(pvDecision);
			} else {
				if (RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_NAME.equalsIgnoreCase(phoneVerificationSupplier)) {
					return verifyPhoneWithEquifaxIDFS(person, personVo, phoneEvent);
				} else if (RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME.equalsIgnoreCase(phoneVerificationSupplier)) {
					return verifyPhoneWithEquifaxDIT(personVo, person.getSponsorUserId(), phoneEvent);
				}
			}

		} catch (SOAPFaultException ex) {
			CustomLogger.error(this.getClass(),
					String.format(LOG_EQUIFAX_CALL_SOAP_EXCEPTION_FMT, personVo.getSponsorUserId()), ex);
			throw new PhoneVerificationException(ex.getMessage());
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(),
					String.format(LOG_EQUIFAX_CALL_EXCEPTION_FMT, personVo.getSponsorUserId()), ex);
			throw new PhoneVerificationException(ex.getMessage());
		}

		return pvResponse;
	}

	public PhoneVerificationResponse verifyPhoneWithEquifaxDIT(PersonVo personVo, String sponsorUserId,
			RpEvent phoneEvent) throws Exception {
		CustomLogger.enter(this.getClass());

		String bearerToken = generateEquifaxBearerToken(EQUIFAX_DIT_OAUTH_SCOPE, EQUIFAX_DIT_TOKEN_TYPE, false);
		CustomLogger.debug(this.getClass(), "Bearer token: " + bearerToken);
		long eventId = phoneEvent.getEventId();
		InitiateDITRequestModel initiateRequest = prepareDitInitiateRequest(personVo, sponsorUserId, eventId);

		Gson g = new Gson();
		String requestStr = g.toJson(initiateRequest);
		CustomLogger.debug(this.getClass(), "Equifax Verify Phone with DIT Request:" + requestStr);

		InitiateDITResponseModel initiateResponse = null;
		int attmptCtr = 0;
		AdditionalErrorDetailModel additionalErrorDetail = null;
		String responseStr = "";
		/**
		 * Attempt DIT three times if 500 error occurs
		 */
		do {
			attmptCtr = attmptCtr + 1;
			if (attmptCtr >= 2) {
				CustomLogger.error(this.getClass(), "Equifax DIT repeating for 500 error " + attmptCtr + " times");
			}
			initiateResponse = commonRestService.sendInitiateDITRequest(bearerToken, initiateRequest);
			responseStr = g.toJson(initiateResponse);

			setStubResponseData(personVo, responseStr);
			CustomLogger.debug(this.getClass(), "Equifax Verify Phone with DIT Response:" + responseStr);
		} while (attmptCtr <= 3 && (initiateResponse != null && initiateResponse.getStatus() == 500));
		boolean hasError = true;
		String overallDecision = RpPhoneVerification.DECISION_FAILED;

		if (additionalErrorDetail == null) {
			hasError = false;
			evaluateDITOverallDecision(initiateResponse);

			if (initiateResponse != null) {
				overallDecision = initiateResponse.getDecision();
			}
			
			// set trust values in PersonVo so they are available in the Cust Reg Assertions
			if (initiateResponse != null) {
				personVo.setPhoneTrust(initiateResponse.getPhoneTrust());
				personVo.setIdentityTrust(initiateResponse.getIdentityTrust());
				personVo.setAddressTrust(initiateResponse.getAddressTrust());
			}
		}

		personVo.setPhoneVerificationDecision(overallDecision);

		 // set session id if it is available from DIT for the Customer Registration
		 // assertion 
		if (initiateRequest.getData() != null 
				 && initiateRequest.getData().getAdditionalFields() != null 
				 && initiateRequest.getData().getAdditionalFields().get(0) != null) {
			 personVo.setSessionId(initiateRequest.getData().getAdditionalFields().get(0).getValue()); 
		}
		processDitInitiateResponse(initiateResponse, personVo, phoneEvent, requestStr, responseStr, hasError);

		if (RpPhoneVerification.DECISION_APPROVED.equalsIgnoreCase(overallDecision)) {
			overallDecision = PhoneVerificationResponse.PV_DECISION_PASS;
		}

		return new PhoneVerificationResponse(RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID,
				RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME, overallDecision, phoneEvent.getFinalDecision());
	}

	public void processDitInitiateResponse(InitiateDITResponseModel initiateResponse, PersonVo personVo,
			RpEvent phoneEvent, String requestStr, String responseStr, boolean hasError)
			throws PhoneVerificationException {
		CustomLogger.enter(this.getClass());

		Person person = getPerson(personVo.getId());
		long supplierId = RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID;
		String transactionId = "";
		String loaSought = personVo.getProofingLevelSought();

		if (initiateResponse != null && initiateResponse.getTransactionId() != null) {
			transactionId = initiateResponse.getTransactionId();
			// set transactionId for the SMFA assertion for approve scenario
			personVo.setTransactionId(transactionId);
		}

		equifaxDataService.saveResultToRpDitResponse(requestStr, responseStr, transactionId, person);

		if (!hasError) {
			equifaxDataService.saveDITPhoneVerificationResults(initiateResponse, phoneEvent, personVo);
			equifaxDataService.saveResultToRpEfxDitDetails(initiateResponse, person, phoneEvent);

			String overallDecision = initiateResponse != null ? initiateResponse.getDecision() : RpPhoneVerification.DECISION_DENIED;

			if (person != null) {
		       RefSponsorConfiguration config = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
		                    RefSponsorConfiguration.ASSERT_TO_CUSTREG);

				if (RpPhoneVerification.DECISION_FOR_REVIEW.equalsIgnoreCase(overallDecision)) {
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.SMFA_initiated.getValue(), person,
							loaSought);
					if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
						passedDITVerification(person, personVo, supplierId);
					}
				} else if (RpPhoneVerification.DECISION_DENIED.equalsIgnoreCase(overallDecision)) {
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_failed.getValue(),
							person, loaSought);
					if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
						failedDITVerification(person, personVo, supplierId);
					}
					// Return Truth Data to ThreatMetrix
					truthDataReturnService.returnRemoteProofingTruthData(person, false);
					CustomLogger.debug(this.getClass(), "Return Truth Data to ThreatMetrix for Equifax DIT Deny Result:" 
							+ TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_FAIL);
				} else if (RpPhoneVerification.DECISION_APPROVED.equalsIgnoreCase(overallDecision)) {
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.LOA_level_achieved.getValue(), person,
							loaSought);
					assertApprovedDITVerification(person, personVo, config, IPSConstants.LOA_RP_EQ_DIT_NAME);

					// Return Truth Data to ThreatMetrix
					truthDataReturnService.returnRemoteProofingTruthData(person, true);
					CustomLogger.debug(this.getClass(), "Return Truth Data to ThreatMetrix for Equifax DIT Approve Result:" 
							+ TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_PASS);
				}
			}
		}

		if (hasError) {
			proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_initiated.getValue(), person,
					loaSought);
		}
	}

	public String generateEquifaxBearerToken(String scope, String tokenType, boolean obtainNewToken) throws Exception {
		CustomLogger.enter(this.getClass());

		String propertyName = EQUIFAX_2_OAUTH_ENDPT;
		String clientIdAlias = EQUIFAX_CLIENT_ID_J2C_ALIAS;
		String clientSecretAlias = EQUIFAX_CLIENT_SECRET_J2C_ALIAS;
		String grantType = EQUIFAX_DIT_OAUTH_GRANT_TYPE;

		return commonRestService.getOAuthToken(propertyName, clientIdAlias, clientSecretAlias, scope, grantType,
				tokenType, obtainNewToken);
	}

	public InitiateDITRequestModel prepareDitInitiateRequest(PersonVo personVo, String sponsorUserId, long eventId)
			throws IPSException {
		CustomLogger.enter(this.getClass());

		List<NameModel> names = new ArrayList<>();
		NameModel name = new NameModel();
		name.setFirstName(personVo.getFirstName().trim());

		if (personVo.getMiddleName() != null && personVo.getMiddleName().length() >= 1) {
			name.setMiddleName(personVo.getMiddleName().toUpperCase());
		} else {
			name.setMiddleName("");
		}

		name.setLastName(personVo.getLastName().trim());
		name.setSecondLastName("");
		name.setNamePrefix(null);
		name.setNameSuffix(null);
		names.add(name);

		List<AddressModel> addresses = new ArrayList<>();
		AddressModel address = new AddressModel();
		address.setAddressLine1(personVo.getAddressLine1());
		address.setAddressLine2("");
		address.setCity(personVo.getCity());
		address.setRegion(personVo.getStateProvince());
		address.setPostalCode(personVo.getPostalCode());
		address.setCounty("");
		address.setCountryCode("US");
		address.setPostalIdentifier("postalIdentifier");
		address.setAddressType("Current");
		address.setPrimary(true);
		addresses.add(address);

		List<EmailModel> emails = new ArrayList<>();
		EmailModel email = new EmailModel();
		email.setEmail(personVo.getEmailAddress());
		email.setEmailType("Personal");
		emails.add(email);

		List<PhoneModel> phones = new ArrayList<>();
		PhoneModel phone = new PhoneModel();
		phone.setCountryCode(1);

		phone.setNumber(Long.valueOf(personVo.getMobileNumber()));
		phone.setType("Mobile");
		phone.setArea("");
		phone.setPrimary(true);
		phones.add(phone);

		List<AdditionalFieldModel> additionalFields = new ArrayList<>();

		AdditionalFieldModel sessionIdField = new AdditionalFieldModel();
		String sessionId = personVo.isWebServiceCall() ? generateSessionId() : getSessionId(sponsorUserId);
		sessionIdField.setKey("sessionId");
		sessionIdField.setValue(sessionId);
		additionalFields.add(sessionIdField);

		IdentityModel identity = new IdentityModel();
		identity.setName(name);
		identity.setAddress(addresses);
		identity.setPhone(phones);
		identity.setEmail(emails);

		DataModel data = new DataModel();
		String ipAddress = "";

		if (!personVo.isWebServiceCall()) {
			HttpServletRequest servletRequest = (HttpServletRequest) FacesContext.getCurrentInstance()
					.getExternalContext().getRequest();
			ipAddress = commonRestService.getClientIpAddress(servletRequest);
		}

		data.setIpAddress(ipAddress);
		data.setIdentity(identity);
		data.setAdditionalFields(additionalFields);

		InitiateDITRequestModel request = new InitiateDITRequestModel();

		RefApp refApp = refAppService.findByAppId(personVo.getAppId());
		String appCode = "";

		if (refApp != null) {
			String appName = refApp.getAppName();
			Map<String, String> appNameCodeMap = commonRestService.getAppNameCodeMap();
			appCode = appNameCodeMap.get(appName);
			appCode = appCode != null? appCode.toUpperCase() : "";
		}
		
		String environment = Utils.getEnvironmentWithoutDot();
		String referenceId = String.format("%s-%s-%s", environment, eventId, getCurrentDateTime());
		String consumerId = appCode;

		String tenantId = "";
		String applicationId = "";

		try {
			tenantId = commonRestService.getJ2CInfo(EQUIFAX_DIT_TENANT_ID_J2C_ALIAS).getPassword();
			applicationId = commonRestService.getJ2CInfo(EQUIFAX_DIT_APPLICATION_ID_J2C_ALIAS).getPassword();
		} catch (IPSException e) {
			CustomLogger.error(this.getClass(), "Error occurred in getting J2C values of tenantId and applicationId.",
					e);
		}

		request.setTenantId(tenantId);
		request.setApplicationId(applicationId);
		request.setReferenceId(referenceId);
		request.setConsumerId(consumerId);
		request.setCorrelationId(personVo.getKbaUid());
		request.setProductId("dit2");
		request.setConfigId("configId");
		request.setEntityId("entityId");
		request.setData(data);

		return request;
	}

	public void evaluateDITOverallDecision(InitiateDITResponseModel initiateResponse) {
		CustomLogger.enter(this.getClass());

		if (initiateResponse != null) {
			List<DetailModel> details = initiateResponse.getDetails();
			if (details != null) {
				String identityTrustKey = DetailModel.IDENTITY_TRUST_KEY;
				String addressTrustKey = DetailModel.ADDRESS_TRUST_KEY;
				String phoneTrustKey = DetailModel.PHONE_TRUST_KEY;
				String phoneVerificationKey = DetailModel.PHONE_VERIFICATION_KEY;
				String identityTrustValue = DetailModel.DETAIL_VALUE_NO;
				String addressTrustValue = DetailModel.DETAIL_VALUE_NO;
				String phoneTrustValue = DetailModel.DETAIL_VALUE_NO;

				for (DetailModel detail : details) {
					if (identityTrustKey.equalsIgnoreCase(detail.getKey())) {
						identityTrustValue = detail.getValue();
						initiateResponse.setIdentityTrust(identityTrustValue);
					} else if (addressTrustKey.equalsIgnoreCase(detail.getKey())) {
						addressTrustValue = detail.getValue();
						initiateResponse.setAddressTrust(addressTrustValue);
					} else if (phoneTrustKey.equalsIgnoreCase(detail.getKey())) {
						phoneTrustValue = detail.getValue();
						initiateResponse.setPhoneTrust(phoneTrustValue);
					} else if (phoneVerificationKey.equalsIgnoreCase(detail.getKey())) {
						String phoneVerificationValue = detail.getValue();
						initiateResponse.setPhoneVerification(phoneVerificationValue);
					}
				}

				String permutationResult = String.format("%s%s%s", identityTrustValue, addressTrustValue,
						phoneTrustValue);
				String decision = initiateResponse.getDecision();

				CustomLogger.debug(this.getClass(), "Equifax Verify Phone with DIT decision:" + decision
						+ " => permutationResult" + permutationResult);

				String overallDecision = efxDitDecisionMapService.getOverallDecision(permutationResult);
				initiateResponse.setDecision(overallDecision);
				CustomLogger.debug(this.getClass(), "Equifax Verify Phone with DIT overallDecision:" + overallDecision);
			}
		}
	}

	private PhoneVerificationResponse verifyPhoneWithEquifaxIDFS(Person person, PersonVo personVo, RpEvent phoneEvent)
			throws Throwable {
		CustomLogger.enter(this.getClass());

		InitialIDFSRequestXML xmlBuilder = new InitialIDFSRequestXML();
		InitialRequest request = xmlBuilder.createXMLInitialRequest(personVo,
				IPSConstants.EQUIFAX_VERIFY_PHONE_ORCHESTRATION_CODE);
		String phoneVerificationDecision = "FAIL";
		String loaSought = personVo.getProofingLevelSought();

		Gson g = new Gson();
		if (CustomLogger.isDebugEnabled()) {
			String requestJsonStr = g.toJson(request);
			CustomLogger.debug(this.getClass(),
					String.format("Equifax phone verification request Json: %s", requestJsonStr));
		}

		InitialResponse response = sendIDFSInitialRequest(request, personVo);

		if (CustomLogger.isDebugEnabled()) {
			String responseJsonStr = g.toJson(response);
			CustomLogger.debug(this.getClass(),
					String.format("Equifax phone verification response Json: %s", responseJsonStr));
		}

		equifaxDataService.saveEquifaxIDFSPhoneVerificationResults(response, phoneEvent, personVo);

		long supplierId = RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID;
		if (response.getProductResponses() != null) {
			RpPhoneVerification rpPhoneVerification = phoneEvent.getRpPhoneVerification();
			boolean phoneVerified = rpPhoneVerification.isEquifaxIDFSPhoneVerificationPassed();
			CustomLogger.debug(this.getClass(),
					String.format("Equifax phone verification %s for sponsorUserId:%s",
							(phoneVerified ? IPSConstants.VALUE_PASSED : IPSConstants.VALUE_FAILED),
							person.getSponsorUserId()));

            RefSponsorConfiguration config = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
                    RefSponsorConfiguration.ASSERT_TO_CUSTREG);

			if (phoneVerified) {
				proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verified.getValue(), person, loaSought);
				// setup passcode results
				// Scenario 1
				person = getPerson(person.getPersonId());

				if (person != null) {

					if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
						passedPhoneVerification(person, personVo, supplierId);
					}
					
					phoneVerificationDecision = RpPhoneVerification.DECISION_PASSED;
					personVo.setPhoneVerificationDecision(phoneVerificationDecision);
				}
			} else {
				proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_failed.getValue(), person,
						loaSought);
				person = getPerson(person.getPersonId());
				
				if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
					failedPhoneVerification(person, personVo, supplierId);
				}
				
				// Return Truth Data to ThreatMetrix
				truthDataReturnService.returnRemoteProofingTruthData(person, false);
			CustomLogger.debug(this.getClass(), "Return Truth Data to ThreatMetrix for Equifax IDFS PV Failed Result:" 
						+ TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_FAIL);

				phoneVerificationDecision = RpPhoneVerification.DECISION_FAILED;
				personVo.setPhoneVerificationDecision(phoneVerificationDecision);
			}
		}

		return new PhoneVerificationResponse(RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID,
				RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_NAME, phoneVerificationDecision, phoneEvent.getFinalDecision());
	}

	private InitialResponse sendIDFSInitialRequest(InitialRequest req, PersonVo personVo)
			throws IPSException, PhoneVerificationException, Exception, Throwable {
		CustomLogger.enter(this.getClass());

		UsIdentityFraudServiceTypeV2 port = setupIDFSSecurityConsiderations();
		InitialResponse response = null;

		try {
			// Fix this log statement when the request is populated
			CustomLogger.debug(this.getClass(), String.format(
					"User with CustRegId: %s is calling Equifax for initial request..", personVo.getSponsorUserId()));
			response = port.submit(req);

			// Use request rather than response to avoid NullPointerException
			CustomLogger.info(this.getClass(), String
					.format("User with CustRegId: %s received a response from Equifax.", personVo.getSponsorUserId()));
			CustomLogger.debug(this.getClass(), "response=" + response.toString());
			if (response.getError() != null) {
				CustomLogger.error(this.getClass(), "error.code=" + response.getError().getCode() + ", error.message="
						+ response.getError().getMessage());
			}

			if (response.getTransactionKey() != null) {
				CustomLogger.debug(this.getClass(), "transactionKey=" + response.getTransactionKey());
			}

			// Don't throw an Exception for errors - will be saved to the database
		} catch (SOAPFaultException ex) {
			CustomLogger.error(this.getClass(), "SOAPFaultException occurred during the call", ex);
			throw new PhoneVerificationException(ex.getMessage());
		}

		return response;
	}

	private SubsequentResponse sendIDFSSubsequentRequest(SubsequentRequest req, PersonVo personVo)
			throws IPSException, InvalidTransactionKeyFault, com.equifax.eid.soap.schema.usidentityfraudservice.v2.CredentialsErrorFault, Exception {
		CustomLogger.enter(this.getClass());

		UsIdentityFraudServiceTypeV2 port = setupIDFSSecurityConsiderations();

		// Fix this log statement when the request is populated
		CustomLogger.info(this.getClass(),
				String.format(
						"User with CustRegId: %s and TransactionKey: %s is calling Equifax for subsequent request.",
						(personVo != null && personVo.getSponsorUserId() != null ? personVo.getSponsorUserId()
								: "sponsor user id is null"),
						(req != null && req.getTransactionKey() != null ? req.getTransactionKey()
								: "transaction key is null")));
		SubsequentResponse response = port.resubmit(req);
		// Use request rather than response to avoid NullPointerException
		CustomLogger.debug(this.getClass(), "response=" + response.toString());
		if (response.getError() != null) {
			CustomLogger.debug(this.getClass(), "error.code=" + response.getError().getCode() + ", error.message="
					+ response.getError().getMessage());
		}
		if (response != null && response.getTransactionKey() != null) {
			CustomLogger.debug(this.getClass(), "TransactionKey=" + response.getTransactionKey());
		}
		if (response != null && response.getTransactionStatus() != null) {
			CustomLogger.debug(this.getClass(), "TransactionStatus=" + response.getTransactionStatus());
		}
		if (req != null && req.getOneTimePasscodeInput() != null
				&& req.getOneTimePasscodeInput().getPasscode() != null) {
			CustomLogger.debug(this.getClass(), "Request passcode=" + req.getOneTimePasscodeInput().getPasscode());
		}

		if (response != null && response.getProductResponses() != null
				&& response.getProductResponses().getDynamicOTP() != null
				&& response.getProductResponses().getDynamicOTP().getPasscode() != null) {
			CustomLogger.debug(this.getClass(),
					"Response passcode=" + response.getProductResponses().getDynamicOTP().getPasscode());
		}
		if (response.getError() != null && !"00".equals(response.getError().getCode())) {
			CustomLogger.error(this.getClass(), response.getError().getMessage());
			personVo.setErrorMessage(response.getError().getMessage());
		}
		if (response != null && response.getProductResponses() != null
				&& response.getProductResponses().getDynamicOTP() != null
				&& response.getProductResponses().getDynamicOTP().getError() != null
				&& response.getProductResponses().getDynamicOTP().getError().getCode() != null) {
			CustomLogger.error(this.getClass(),
					"error code=" + response.getProductResponses().getDynamicOTP().getError().getCode());
			if (response.getProductResponses().getDynamicOTP().getError().getMessage() != null) {
				CustomLogger.error(this.getClass(),
						"error message=" + response.getProductResponses().getDynamicOTP().getError().getMessage());
				personVo.setErrorMessage(response.getProductResponses().getDynamicOTP().getError().getMessage());
			} else {
				personVo.setErrorMessage("Passcode did not match; Please try again.");
			}
		}

		if (response != null && response.getProductResponses() != null
				&& response.getProductResponses().getDynamicOTP() != null
				&& response.getProductResponses().getDynamicOTP().getDecision() != null) {
			CustomLogger.debug(this.getClass(),
					"Decision=" + response.getProductResponses().getDynamicOTP().getDecision());

			// Only do this if the error message is not already set
			if (!IPSConstants.RP_DECISION_PASSED
					.equalsIgnoreCase(response.getProductResponses().getDynamicOTP().getDecision())
					&& personVo.getErrorMessage() == null) {
				personVo.setErrorMessage("Passcode did not match; Please try again.");
			}
		}

		return response;
	}

	@SuppressWarnings("rawtypes")
	private UsIdentityFraudServiceTypeV2 setupIDFSSecurityConsiderations() throws IPSException {
		CustomLogger.enter(this.getClass());

		URL wsdlURL = UsIdentityFraudServiceV2.WSDL_LOCATION;
		if (wsdlURL.toString().length() > 0 && !StringUtils.isEmpty(wsdlURL.toString())) {
			File wsdlFile = new File(wsdlURL.toString());
			try {
				if (wsdlFile.exists()) {
					wsdlURL = wsdlFile.toURI().toURL();
				} else {
					wsdlURL = new URL(wsdlURL.toString());
				}
			} catch (MalformedURLException e) {
				CustomLogger.error(this.getClass(), "Malformed URL", e);
			}
		}

		UsIdentityFraudServiceV2 idfs = new UsIdentityFraudServiceV2(wsdlURL, UsIdentityFraudServiceV2.SERVICE);
		UsIdentityFraudServiceTypeV2 port = idfs.getUsIdentityFraudServiceHttpPort();

		String equifaxIDFSEndpoint = Utils.getProperty("com.ipsweb.EquifaxIDFSEndpoint");

		// get Equifax credentials from j2c alias
		AliasVo j2c = Utils.getAppCredentials(IPSConstants.EQUIFAX_J2C_ALIAS_IDFS);

		// Equifax Settings
		BindingProvider prov = (BindingProvider) port;
		prov.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, equifaxIDFSEndpoint);

		final Binding binding = ((BindingProvider) port).getBinding();
		List<Handler> handlerList = binding.getHandlerChain();
		if (handlerList == null) {
			handlerList = new ArrayList<>();
		}
		SecurityHandler securityHandler = new SecurityHandler();
		securityHandler.setUserName(j2c.getUserName());
		securityHandler.setPassword(j2c.getPassword());
		handlerList.add(securityHandler);
		binding.setHandlerChain(handlerList); // <- important!

		// Set the http proxy to proxy.usps.gov:8080
		prov.getRequestContext().put("https.proxyHost", IPSConstants.USPS_PROXY_HOST);
		prov.getRequestContext().put("https.proxyPort", IPSConstants.USPS_PROXY_PORT);

		return port;
	}

	public boolean sendPasscodeSuccessful(Person person, PersonVo personVo) throws Throwable {

		CustomLogger.enter(this.getClass());

		String loaSought = personVo.getProofingLevelSought();

		proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_initiated.getValue(), person, loaSought);
		SendPasscodeIDFSRequestXML xmlBuilder = new SendPasscodeIDFSRequestXML();

		InitialRequest request = xmlBuilder.createSendPasscodeXMLInitialRequest(personVo);

		Gson g = new Gson();
		if (CustomLogger.isDebugEnabled()) {
			String requestJsonStr = g.toJson(request);
			CustomLogger.debug(this.getClass(),
					String.format("Equifax renew passcode Json request: %s", requestJsonStr));
		}

		try {
			InitialResponse response = sendIDFSInitialRequest(request, personVo);

			if (CustomLogger.isDebugEnabled()) {
				String responseJsonStr = g.toJson(response);
				CustomLogger.debug(this.getClass(),
						String.format("Equifax renew passcode Json response: %s", responseJsonStr));
			}

			// Fix for defect D-44611 - if errors are received then don't set the
			// transactionKey
			// Would prefer to return a boolean but do not want to introduce too many
			// changes this late
			String transactionKey = "";
			if (response.getError() != null) {
				transactionKey = response.getTransactionKey();
			}

			// Fix for defect D-44611 - don't change the proofing status if the passcode was
			// not successfully sent
			// Operation Santa code uses the proofing status to determine if it was sent
			// successfully

			boolean otpSent = equifaxDataService.savePasscodeRequest(response, personVo);
			CustomLogger.debug(this.getClass(), String.format("Equifax renew passcode %s for sponsorUserId: %s",
					(otpSent ? IPSConstants.VALUE_PASSED : IPSConstants.VALUE_FAILED), person.getSponsorUserId()));

			if (otpSent) {
				proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_sent.getValue(), person, loaSought);
				return true;
			}
		} catch (SOAPFaultException ex) {
			CustomLogger.error(this.getClass(),
					String.format(LOG_EQUIFAX_CALL_SOAP_EXCEPTION_FMT, personVo.getSponsorUserId()), ex);
			//throw new PhoneVerificationException(ex.getMessage());
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(),
					String.format(LOG_EQUIFAX_CALL_EXCEPTION_FMT, personVo.getSponsorUserId()), ex);
			//throw new PhoneVerificationException(ex.getMessage());
		}

		// Note that if errors occurred transactionKey will be empty string
		return false;
	}

	public boolean confirmPasscodeSuccessful(Person person, PersonVo personVo, RpEvent event)
			throws IPSException, PhoneVerificationException {
		CustomLogger.enter(this.getClass());

		boolean passcodeConfirmed = false;
		String loaSought = personVo.getProofingLevelSought();
		proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_confirmation_initiated.getValue(), person,
				loaSought);

		ConfirmPasscodeIDFSRequestXML xmlBuilder = new ConfirmPasscodeIDFSRequestXML();

		String transactionKey = equifaxDataService.retrievePasscodeTransactionKey(personVo.getId());
		SubsequentRequest request = xmlBuilder.createConfirmPasscodeXMLSubsequentRequest(personVo, transactionKey);

		Gson g = new Gson();
		if (CustomLogger.isDebugEnabled()) {
			String requestJsonStr = g.toJson(request);
			CustomLogger.debug(this.getClass(),
					String.format("Equifax passcode confirmation request Json: %s", requestJsonStr));
		}

		SubsequentResponse response = null;
		try {
			response = sendIDFSSubsequentRequest(request, personVo);

			if (CustomLogger.isDebugEnabled()) {
				String responseJsonStr = g.toJson(response);
				CustomLogger.debug(this.getClass(),
						String.format("Equifax passcode confirmation response Json: %s", responseJsonStr));
			}

			passcodeConfirmed = equifaxDataService.savePasscodeResult(response, personVo, event);
			CustomLogger.debug(this.getClass(),
					String.format("Equifax passcode confirmation %s for sponsorUserId: %s",
							(passcodeConfirmed ? IPSConstants.VALUE_PASSED : IPSConstants.VALUE_FAILED),
							person.getSponsorUserId()));

			// Return Truth Data to ThreatMetrix
			truthDataReturnService.returnRemoteProofingTruthData(person, passcodeConfirmed);
			CustomLogger.debug(this.getClass(), "Return Truth Data to ThreatMetrix for Equifax IDFS OTP Confirmation Result:" 
					+ (passcodeConfirmed? TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_PASS : TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_FAIL) );

            RefSponsorConfiguration config = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
                    RefSponsorConfiguration.ASSERT_TO_CUSTREG);

			if (passcodeConfirmed) {
				proofingService.updateProofingStatus(RefRpStatus.RpStatus.LOA_level_achieved.getValue(), person,
						loaSought);

				if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
					passedOnlinePhoneVerification(person, personVo, response);
				}
			} else {
				proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_confirmation_failed.getValue(), person,
						loaSought);
				if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
					failedOnlinePasscodeVerification(person, personVo, response);
				}
			}
		} catch (SOAPFaultException ex) {
			CustomLogger.error(this.getClass(),
					String.format(LOG_EQUIFAX_CALL_SOAP_EXCEPTION_FMT, personVo.getSponsorUserId()), ex);
			throw new PhoneVerificationException(ex.getMessage());
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(),
					String.format(LOG_EQUIFAX_CALL_EXCEPTION_FMT, personVo.getSponsorUserId()), ex);
			throw new PhoneVerificationException(ex.getMessage());
		}

		return passcodeConfirmed;
	}

	private void passedOnlinePhoneVerification(Person person, PersonVo personVo, RefSponsorConfiguration config) {

		RpDitResponse rpDitResponse = rpDitResponseService.findByPersonId(person.getPersonId());
		long ditSentDatetime = 0L;
		long ditDecisionDatetime = 0L;
		long ditAttemptsMade = personVo.getPhoneVerificationAttemptCount();

		if (rpDitResponse != null) {
			long createDatetime = rpDitResponse.getCreateDate().getTime();
			ditSentDatetime = createDatetime;
			ditDecisionDatetime = createDatetime;
		}

		personVo.setPath("");
		personVo.setTransactionId(
				(rpDitResponse != null && rpDitResponse.getTransactionId() != null ? rpDitResponse.getTransactionId()
						: ""));
		if (personVo.getSessionId() == null) {
			personVo.setSessionId("");
		}

		if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
			CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
			assertionVo.setLoaName(IPSConstants.LOA_RP_EQ_DIT_NAME);
			assertionVo.setVerificationDecisionDatetime(ditDecisionDatetime);
			assertionVo.setTotalSubmitAttempts(ditAttemptsMade);
			
			assertPhoneVerificationResult(person, personVo, assertionVo, ditSentDatetime, true, EQUIFAX_DIT_TOKEN_TYPE);
		}
	}

	private void assertApprovedDITVerification(Person person, PersonVo personVo, RefSponsorConfiguration config, String loaName) {

		RpDitResponse rpDitResponse = rpDitResponseService.findByPersonId(person.getPersonId());
		long ditSentDatetime = 0L;
		long ditDecisionDatetime = 0L;
		long ditAttemptsMade = personVo.getPhoneVerificationAttemptCount();

		if (rpDitResponse != null) {
			long createDatetime = rpDitResponse.getCreateDate().getTime();
			ditSentDatetime = createDatetime;
			ditDecisionDatetime = createDatetime;
		}
		personVo.setPath("");
		personVo.setTransactionId(
				(rpDitResponse != null && rpDitResponse.getTransactionId() != null ? rpDitResponse.getTransactionId()
						: ""));
		if (personVo.getSessionId() == null) {
			personVo.setSessionId("");
		}

		if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
			CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
			assertionVo.setLoaName(loaName); 
			assertionVo.setVerificationDecisionDatetime(ditDecisionDatetime);
			assertionVo.setTotalSubmitAttempts(ditAttemptsMade);
			
			assertPhoneVerificationResult(person, personVo, assertionVo, ditSentDatetime, true, EQUIFAX_DIT_TOKEN_TYPE);
		}
	}

	/*
	 * Scenario 1: User passed phone verification (PV Only)
	 *
	 * hasPreviousPhoneVerificationDecision: if PhoneVerificationResponse.PV_DECISION_REVIEW.equalsIgnoreCase(pvDecision))
	 *
	 * verifyPhoneWithEquifaxIDFS: if rpPhoneVerification.isEquifaxIDFSPhoneVerificationPassed()) 
	 */
	private void passedPhoneVerification(Person person, PersonVo personVo, long supplierId) {
		CustomLogger.enter(this.getClass());

		RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(), supplierId);
		RpPhoneVerification rpPhoneVerification = null;

		if (event != null) {
			rpPhoneVerification = event.getRpPhoneVerification();
		}

		if (rpPhoneVerification != null) {
			rpPhoneVerification = event.getRpPhoneVerification();
			String phoneDecision = rpPhoneVerification.getPhoneVerificationDecision();
			long initiationDatetime = rpPhoneVerification.getCreateDate().getTime();
			long completionDatetime = rpPhoneVerification.getDecisionDateTime() != null
					? rpPhoneVerification.getDecisionDateTime().getTime()
					: 0L;
			String mobilePhone = rpPhoneVerification.getMobilePhoneNumber() != null
					? rpPhoneVerification.getMobilePhoneNumber()
					: "";

			RpPhoneVerificationResult rpPhoneVerificationResult = event.getRpPhoneVerificationResult();
			String phoneMatchQuality = "";
			String phoneMatchLevel = "";
			String phoneServiceStatus = "";

			if (rpPhoneVerificationResult != null) {
				phoneMatchQuality = rpPhoneVerificationResult.getRefPhoneMatchQuality() != null
						? rpPhoneVerificationResult.getRefPhoneMatchQuality().getMatchQuality()
						: "";
				phoneMatchLevel = rpPhoneVerificationResult.getRefMatchLevel() != null
						? rpPhoneVerificationResult.getRefMatchLevel().getMatchLevel()
						: "";
				phoneServiceStatus = rpPhoneVerificationResult.getRefServiceStatusCode() != null
						? rpPhoneVerificationResult.getRefServiceStatusCode().getServiceStatus()
						: "";
			}

			String avsErrorsDatetime = event.getAvsErrorsDatetime() != null ? event.getAvsErrorsDatetime().toString()
					: "";
			long attemptsMade = rpPhoneVerification.getNumberOfSubmitAttempts();
			long totalIPSAttempts = 1;
			totalIPSAttempts = rpProofingSessionService.getSumOfTotalAttempts(person);
			CustomLogger.debug(this.getClass(), "EquifaxService passedPhoneVerification totalIPSAttempts=" + totalIPSAttempts);
			long totalEIDAttempts = 1;
			totalEIDAttempts = rpEventService
					.countRpEvents(person.getPersonId(), IPSConstants.ONE_TIME_PASSCODE_SUPPLIER_ID).get(0).longValue();
			CustomLogger.debug(this.getClass(),
					"EquifaxServiceImpl.totalRpEvents(totalEIDAttempts)=" + totalEIDAttempts);

			// The first one (totalofTOA) is used for total_ips_attempts. The second one
			// (totalRpEvents) is used for total_eid_attempts.
			CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
			assertionVo.setLoaSought(personVo.getProofingLevelSought());
			assertionVo.setMobilePhone(mobilePhone);
			assertionVo.setVerificationDecision(phoneDecision);
			assertionVo.setVerificationMatchQuality(phoneMatchQuality);
			assertionVo.setVerificationMatchLevel(phoneMatchLevel);
			assertionVo.setProductStatus(phoneServiceStatus);
			assertionVo.setRpStatusCode(RefRpStatus.RpStatus.Phone_verified.getValue());
			assertionVo.setVerificationSentDatetime(initiationDatetime);
			assertionVo.setVerificationDecisionDatetime(completionDatetime);
			assertionVo.setTotalIPSAttempts(totalIPSAttempts);
			assertionVo.setTotalEIDAttempts(totalEIDAttempts);
			assertionVo.setProofingStatus(IPSConstants.PROOFING_STATUS_PHONE_VERIFIED);
			assertionVo.setAttemptsAllowed(IPSConstants.RP_ATTEMPTS_ALLOWED);
			assertionVo.setAttemptsMade(attemptsMade);
			assertionVo.setAttemptsPeriod(IPSConstants.RP_ATTEMPT_PERIOD);
			assertionVo.setTransactionKey(rpPhoneVerification.getTransactionKey());
			assertionVo.setAvsErrorsDatetime(avsErrorsDatetime);

			proofingService.phoneVerification(person, assertionVo);
		} else {
			CustomLogger.error(this.getClass(), "Person does not have any RpEvents.  Person=" + person.toString());
		}
	}

	/*
	 * Scenario 2: User failed phone verification (PV Only)
	 *
	 * hasPreviousPhoneVerificationDecision: if PhoneVerificationResponse.PV_DECISION_FAIL.equalsIgnoreCase(pvDecision))
	 *
	 * verifyPhoneWithEquifaxIDFS: if rpPhoneVerification.isEquifaxIDFSPhoneVerificationFailed())  
	 */
	private void failedPhoneVerification(Person person, PersonVo personVo, long supplierId)
			throws PhoneVerificationException {
		CustomLogger.enter(this.getClass());

		RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(), supplierId);
		RpPhoneVerification rpPhoneVerification = null;

		if (event != null) {
			rpPhoneVerification = event.getRpPhoneVerification();
		}

		if (rpPhoneVerification != null) {
			try {
				String phoneDecision = rpPhoneVerification.getPhoneVerificationDecision();
				long initiationDatetime = rpPhoneVerification.getCreateDate() != null
						? rpPhoneVerification.getCreateDate().getTime()
						: 0L;
				long completionDatetime = rpPhoneVerification.getDecisionDateTime() != null
						? rpPhoneVerification.getDecisionDateTime().getTime()
						: 0L;
				String mobilePhone = rpPhoneVerification.getMobilePhoneNumber() != null
						? rpPhoneVerification.getMobilePhoneNumber()
						: "";

				RpPhoneVerificationResult rpPhoneVerificationResult = event.getRpPhoneVerificationResult();
				String phoneMatchQuality = "";
				String phoneMatchLevel = "";
				String phoneServiceStatus = "";

				if (rpPhoneVerificationResult != null) {
					phoneMatchQuality = rpPhoneVerificationResult.getRefPhoneMatchQuality() != null
							? rpPhoneVerificationResult.getRefPhoneMatchQuality().getMatchQuality()
							: "";
					phoneMatchLevel = rpPhoneVerificationResult.getRefMatchLevel() != null
							? rpPhoneVerificationResult.getRefMatchLevel().getMatchLevel()
							: "";
					phoneServiceStatus = rpPhoneVerificationResult.getRefServiceStatusCode() != null
							? rpPhoneVerificationResult.getRefServiceStatusCode().getServiceStatus()
							: "";
				}

				String avsErrorsDatetime = event.getAvsErrorsDatetime() != null
						? event.getAvsErrorsDatetime().toString()
						: "";
				long attemptsMade = rpPhoneVerification.getNumberOfSubmitAttempts();
				long totalIPSAttempts = 1;
				totalIPSAttempts = rpProofingSessionService.getSumOfTotalAttempts(person);
				CustomLogger.debug(this.getClass(), "EquifaxService failedPhoneVerification totalIPSAttempts=" + totalIPSAttempts);

				long totalEIDAttempts = 1;
				totalEIDAttempts = rpEventService.countRpEvents(person.getPersonId(), supplierId).get(0).longValue();
				CustomLogger.debug(this.getClass(),
						"EquifaxServiceImpl.totalRpEvents(totalEIDAttempts)=" + totalEIDAttempts);

				// The first one (totalofTOA) is used for total_ips_attempts. The second one
				// (totalRpEvents) is used for total_eid_attempts.
				CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
				assertionVo.setLoaSought(personVo.getProofingLevelSought());
				assertionVo.setMobilePhone(mobilePhone);
				assertionVo.setVerificationDecision(phoneDecision);
				assertionVo.setVerificationMatchQuality(phoneMatchQuality);
				assertionVo.setVerificationMatchLevel(phoneMatchLevel);
				assertionVo.setProductStatus(phoneServiceStatus);
				assertionVo.setRpStatusCode(RefRpStatus.RpStatus.Phone_verification_failed.getValue());
				assertionVo.setVerificationSentDatetime(initiationDatetime);
				assertionVo.setVerificationDecisionDatetime(completionDatetime);
				assertionVo.setTotalIPSAttempts(totalIPSAttempts);
				assertionVo.setTotalEIDAttempts(totalEIDAttempts);
				assertionVo.setProofingStatus(IPSConstants.PROOFING_STATUS_PHONE_NOT_VERIFIED);
				assertionVo.setAttemptsAllowed(IPSConstants.RP_ATTEMPTS_ALLOWED);
				assertionVo.setAttemptsMade(attemptsMade);
				assertionVo.setAttemptsPeriod(IPSConstants.RP_ATTEMPT_PERIOD);
				assertionVo.setTransactionKey(rpPhoneVerification.getTransactionKey());
				assertionVo.setAvsErrorsDatetime(avsErrorsDatetime);

				proofingService.phoneVerification(person, assertionVo);
			} catch (Exception e) {
				String exMsg = "Error sending failed phone verification assertion";
				CustomLogger.error(this.getClass(), exMsg, e);
				throw new PhoneVerificationException(exMsg);
			}

		} else {
			CustomLogger.error(this.getClass(), "person does not have any RpEvents");
		}
	}

	/*
	 * Scenario 3: User passed online phone verification (PV+OTP)
	 *
	 * hasPreviousPhoneVerificationDecision: if (PhoneVerificationResponse.PV_DECISION_PASS.equalsIgnoreCase(pvDecision)
	 *
	 * verifyPhoneWithEquifaxIDFS: if (passcodeConfirmed) 
	 */
	private void passedOnlinePhoneVerification(Person person, PersonVo personVo, SubsequentResponse response) {
		CustomLogger.enter(this.getClass());

		String passcodeDecision = "";
		String productStatus = "";
		String otpMatchQuality = "";
		long attemptsMade = 0L;

		try {
			passcodeDecision = EquifaxServiceImpl.parsePasscodeDecision(response, passcodeDecision);
			long passcodeSentDatetime = System.currentTimeMillis();
			long passcodeDecisionDatetime = System.currentTimeMillis();
			productStatus = EquifaxServiceImpl.parseProductStatus(response, productStatus);
			otpMatchQuality = EquifaxServiceImpl.parseOtpMatchQuality(response, otpMatchQuality);
			long totalSubmitAttempts = EquifaxServiceImpl.parseTotalSubmitAttempts(response);
			long totalRenewAttempts = EquifaxServiceImpl.parseTotalRenewAttempts(response);

			RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(),
					RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID);

			if (event != null) {
				RpPhoneVerification rpPhoneVerification = event.getRpPhoneVerification();
				attemptsMade = rpPhoneVerification.getNumberOfSubmitAttempts();
			}

			CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
			assertionVo.setLoaSought(personVo.getProofingLevelSought());
			assertionVo.setLoaFlag(IPSConstants.LOA_FLAG_ACHIEVED);
			assertionVo.setVerificationDecision(passcodeDecision);
			assertionVo.setVerificationMatchQuality(otpMatchQuality);
			assertionVo.setProductStatus(productStatus);
			assertionVo.setRpStatusCode(RefRpStatus.RpStatus.LOA_level_achieved.getValue());
			assertionVo.setVerificationSentDatetime(passcodeSentDatetime);
			assertionVo.setVerificationDecisionDatetime(passcodeDecisionDatetime);
			assertionVo.setTotalSubmitAttempts(totalSubmitAttempts);
			assertionVo.setTotalRenewAttempts(totalRenewAttempts);
			assertionVo.setAttemptsAllowed(IPSConstants.RP_ATTEMPTS_ALLOWED);
			assertionVo.setAttemptsMade(attemptsMade);
			assertionVo.setAttemptsPeriod(IPSConstants.RP_ATTEMPT_PERIOD);
			assertionVo.setLoaName(IPSConstants.LOA_RP_EQ_OTP_NAME);

			proofingService.passcodeOnlinePhoneVerification(person, personVo, assertionVo);

		} catch (Exception e) {
			CustomLogger.error(this.getClass(), e);
		}
	}

	/*
	 * Scenario 4: User failed online phone verification (PV+OTP)
	 *
	 * verifyPhoneWithEquifaxIDFS: if (!passcodeConfirmed) 
	 */
	private void failedOnlinePasscodeVerification(Person person, PersonVo personVo, SubsequentResponse response) {
		CustomLogger.enter(this.getClass());

		long attemptsMade = 0L;
		long passcodeSentDatetime = System.currentTimeMillis();
		long passcodeDecisionDatetime = System.currentTimeMillis();
		long totalSubmitAttempts = EquifaxServiceImpl.parseTotalSubmitAttempts(response);
		long totalRenewAttempts = EquifaxServiceImpl.parseTotalRenewAttempts(response);

		RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(),
				RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID);

		if (event != null) {
			RpPhoneVerification rpPhoneVerification = event.getRpPhoneVerification();
			attemptsMade = rpPhoneVerification.getNumberOfSubmitAttempts();
		}

		CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
		assertionVo.setLoaSought(personVo.getProofingLevelSought());
		assertionVo.setLoaFlag(IPSConstants.LOA_FLAG_NOT_ACHIEVED);
		assertionVo.setVerificationDecision(IPSConstants.RP_DECISION_FAILED);
		assertionVo.setVerificationMatchQuality(IPSConstants.RP_EQUIFAX_IDMS_OTP_MISMATCH);
		assertionVo.setProductStatus(IPSConstants.RP_EQUIFAX_IDMS_OTP_COMPLETED);
		assertionVo.setRpStatusCode(RefRpStatus.RpStatus.OTP_confirmation_failed.getValue());
		assertionVo.setVerificationSentDatetime(passcodeSentDatetime);
		assertionVo.setVerificationDecisionDatetime(passcodeDecisionDatetime);
		assertionVo.setTotalSubmitAttempts(totalSubmitAttempts);
		assertionVo.setTotalRenewAttempts(totalRenewAttempts);
		assertionVo.setAttemptsAllowed(IPSConstants.RP_ATTEMPTS_ALLOWED);
		assertionVo.setAttemptsMade(attemptsMade);
		assertionVo.setAttemptsPeriod(IPSConstants.RP_ATTEMPT_PERIOD);
		assertionVo.setLoaName(IPSConstants.LOA_RP_EQ_OTP_NAME);
		
		proofingService.passcodeOnlinePhoneVerification(person, personVo, assertionVo);
	}

	/*
	 * Scenario 1: User passed DIT verification (DIT Only)
	 */
	private void passedDITVerification(Person person, PersonVo personVo, long supplierId) {
		CustomLogger.enter(this.getClass());

		RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(), supplierId);
		RpPhoneVerification rpPhoneVerification = null;

		if (event != null) {
			rpPhoneVerification = event.getRpPhoneVerification();
		}

		if (rpPhoneVerification != null) {
			rpPhoneVerification = event.getRpPhoneVerification();
			String phoneDecision = rpPhoneVerification.getPhoneVerificationDecision();
			long initiationDatetime = rpPhoneVerification.getCreateDate().getTime();
			long completionDatetime = rpPhoneVerification.getDecisionDateTime() != null
					? rpPhoneVerification.getDecisionDateTime().getTime()
					: 0L;
			String mobilePhone = rpPhoneVerification.getMobilePhoneNumber() != null
					? rpPhoneVerification.getMobilePhoneNumber()
					: "";

			RpPhoneVerificationResult rpPhoneVerificationResult = event.getRpPhoneVerificationResult();
			String phoneMatchQuality = "";
			String phoneMatchLevel = "";
			String phoneServiceStatus = "";
			String phoneTrust = "";
			String identityTrust = "";
			String addressTrust = "";

			if (rpPhoneVerificationResult != null) {
				phoneMatchQuality = rpPhoneVerificationResult.getRefPhoneMatchQuality() != null
						? rpPhoneVerificationResult.getRefPhoneMatchQuality().getMatchQuality()
						: "";
				phoneMatchLevel = rpPhoneVerificationResult.getRefMatchLevel() != null
						? rpPhoneVerificationResult.getRefMatchLevel().getMatchLevel()
						: "";
				phoneServiceStatus = rpPhoneVerificationResult.getRefServiceStatusCode() != null
						? rpPhoneVerificationResult.getRefServiceStatusCode().getServiceStatus()
						: "";
			}

			String avsErrorsDatetime = event.getAvsErrorsDatetime() != null ? event.getAvsErrorsDatetime().toString()
					: "";
			long attemptsMade = rpPhoneVerification.getNumberOfSubmitAttempts();
			long totalIPSAttempts = 1;
			totalIPSAttempts = rpProofingSessionService.getSumOfTotalAttempts(person);
			CustomLogger.debug(this.getClass(), "EquifaxService passedDITVerification totalIPSAttempts=" + totalIPSAttempts);

			long totalEIDAttempts = 1;
			totalEIDAttempts = rpEventService
					.countRpEvents(person.getPersonId(), IPSConstants.ONE_TIME_PASSCODE_SUPPLIER_ID).get(0).longValue();
			CustomLogger.debug(this.getClass(),
					"EquifaxServiceImpl.totalRpEvents(totalEIDAttempts)=" + totalEIDAttempts);

			// The first one (totalofTOA) is used for total_ips_attempts. The second one
			// (totalRpEvents) is used for total_eid_attempts.
			CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
			assertionVo.setLoaSought(personVo.getProofingLevelSought());
			assertionVo.setMobilePhone(mobilePhone);
			assertionVo.setVerificationDecision(phoneDecision);
			assertionVo.setVerificationMatchQuality(phoneMatchQuality);
			assertionVo.setVerificationMatchLevel(phoneMatchLevel);
			assertionVo.setProductStatus(phoneServiceStatus);
			assertionVo.setRpStatusCode(RefRpStatus.RpStatus.Phone_verified.getValue());
			assertionVo.setVerificationSentDatetime(initiationDatetime);
			assertionVo.setVerificationDecisionDatetime(completionDatetime);
			assertionVo.setTotalIPSAttempts(totalIPSAttempts);
			assertionVo.setTotalEIDAttempts(totalEIDAttempts);
			assertionVo.setProofingStatus(IPSConstants.PROOFING_STATUS_PHONE_VERIFIED);
			assertionVo.setAttemptsAllowed(IPSConstants.RP_ATTEMPTS_ALLOWED);
			assertionVo.setAttemptsMade(attemptsMade);
			assertionVo.setAttemptsPeriod(IPSConstants.RP_ATTEMPT_PERIOD);
			assertionVo.setTransactionKey(rpPhoneVerification.getTransactionKey());
			assertionVo.setAvsErrorsDatetime(avsErrorsDatetime);
			// populate trust values for Cust Reg assertions stored in the DIT Initiate
			// response,
			// passed to personVo and populated in assertionVo, so they can be extracted and
			// populated
			// in the DIT assertion to Cust Reg
			phoneTrust = personVo.getPhoneTrust();
			identityTrust = personVo.getIdentityTrust();
			addressTrust = personVo.getAddressTrust();
			assertionVo.setPhoneTrust(phoneTrust);
			assertionVo.setIdentityTrust(identityTrust);
			assertionVo.setAddressTrust(addressTrust);

			proofingService.ditVerification(person, assertionVo);
		} else {
			CustomLogger.error(this.getClass(), "Person does not have any RpEvents.  Person=" + person.toString());
		}
	}

	/*
	 * Scenario 2: User failed DIT verification (DIT Only)
	 */
	private void failedDITVerification(Person person, PersonVo personVo, long supplierId)
			throws PhoneVerificationException {
		CustomLogger.enter(this.getClass());

		RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(), supplierId);
		RpPhoneVerification rpPhoneVerification = null;

		if (event != null) {
			rpPhoneVerification = event.getRpPhoneVerification();
		}

		if (rpPhoneVerification != null) {
			try {
				String phoneDecision = rpPhoneVerification.getPhoneVerificationDecision();
				long initiationDatetime = rpPhoneVerification.getCreateDate() != null
						? rpPhoneVerification.getCreateDate().getTime()
						: 0L;
				long completionDatetime = rpPhoneVerification.getDecisionDateTime() != null
						? rpPhoneVerification.getDecisionDateTime().getTime()
						: 0L;
				String mobilePhone = rpPhoneVerification.getMobilePhoneNumber() != null
						? rpPhoneVerification.getMobilePhoneNumber()
						: "";

				RpPhoneVerificationResult rpPhoneVerificationResult = event.getRpPhoneVerificationResult();
				String phoneMatchQuality = "";
				String phoneMatchLevel = "";
				String phoneServiceStatus = "";
				String phoneTrust = "";
				String identityTrust = "";
				String addressTrust = "";

				if (rpPhoneVerificationResult != null) {
					phoneMatchQuality = rpPhoneVerificationResult.getRefPhoneMatchQuality() != null
							? rpPhoneVerificationResult.getRefPhoneMatchQuality().getMatchQuality()
							: "";
					phoneMatchLevel = rpPhoneVerificationResult.getRefMatchLevel() != null
							? rpPhoneVerificationResult.getRefMatchLevel().getMatchLevel()
							: "";
					phoneServiceStatus = rpPhoneVerificationResult.getRefServiceStatusCode() != null
							? rpPhoneVerificationResult.getRefServiceStatusCode().getServiceStatus()
							: "";
				}

				String avsErrorsDatetime = event.getAvsErrorsDatetime() != null
						? event.getAvsErrorsDatetime().toString()
						: "";
				long attemptsMade = rpPhoneVerification.getNumberOfSubmitAttempts();
				long totalIPSAttempts = 1;
				totalIPSAttempts = rpProofingSessionService.getSumOfTotalAttempts(person);
				CustomLogger.debug(this.getClass(), "EquifaxService failedDITVerification totalIPSAttempts=" + totalIPSAttempts);

				long totalEIDAttempts = 1;
				totalEIDAttempts = rpEventService.countRpEvents(person.getPersonId(), supplierId).get(0).longValue();
				CustomLogger.debug(this.getClass(),
						"EquifaxServiceImpl.totalRpEvents(totalEIDAttempts)=" + totalEIDAttempts);

				// The first one (totalofTOA) is used for total_ips_attempts. The second one
				// (totalRpEvents) is used for total_eid_attempts.
				CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
				assertionVo.setLoaSought(personVo.getProofingLevelSought());
				assertionVo.setMobilePhone(mobilePhone);
				assertionVo.setVerificationDecision(phoneDecision);
				assertionVo.setVerificationMatchQuality(phoneMatchQuality);
				assertionVo.setVerificationMatchLevel(phoneMatchLevel);
				assertionVo.setProductStatus(phoneServiceStatus);
				assertionVo.setRpStatusCode(RefRpStatus.RpStatus.Phone_verification_failed.getValue());
				assertionVo.setVerificationSentDatetime(initiationDatetime);
				assertionVo.setVerificationDecisionDatetime(completionDatetime);
				assertionVo.setTotalIPSAttempts(totalIPSAttempts);
				assertionVo.setTotalEIDAttempts(totalEIDAttempts);
				assertionVo.setProofingStatus(IPSConstants.PROOFING_STATUS_PHONE_NOT_VERIFIED);
				assertionVo.setAttemptsAllowed(IPSConstants.RP_ATTEMPTS_ALLOWED);
				assertionVo.setAttemptsMade(attemptsMade);
				assertionVo.setAttemptsPeriod(IPSConstants.RP_ATTEMPT_PERIOD);
				assertionVo.setTransactionKey(rpPhoneVerification.getTransactionKey());
				assertionVo.setAvsErrorsDatetime(avsErrorsDatetime);
				// populate trust values for Cust Reg assertions stored in the DIT Initiate
				// response,
				// passed to personVo and populated in assertionVo, so they can be extracted and
				// populated
				// in the DIT assertion to Cust Reg
				phoneTrust = personVo.getPhoneTrust();
				identityTrust = personVo.getIdentityTrust();
				addressTrust = personVo.getAddressTrust();
				assertionVo.setPhoneTrust(phoneTrust);
				assertionVo.setIdentityTrust(identityTrust);
				assertionVo.setAddressTrust(addressTrust);

				proofingService.ditVerification(person, assertionVo);
			} catch (Exception e) {
				String exMsg = "Error sending failed Equifax DIT phone verification assertion";
				CustomLogger.error(this.getClass(), exMsg, e);
				throw new PhoneVerificationException(exMsg);
			}
		} else {
			CustomLogger.error(this.getClass(), "person does not have any RpEvents");
		}
	}

	/*
	 * This is actually scenarios 3 & 4 for SMFA in the current ICD 2/23/2022
	 */
	/*
	 * Scenarios 5: User got approved DIT or passed SMFA phone validation Scenarios
	 */
	private void assertPhoneVerificationResult(Person person, PersonVo personVo, CustRegAssertionParamVo assertionVo, long sentDatetime,
			boolean passedVerification, String verificationType) {
		CustomLogger.enter(this.getClass());

		long rpStatus = RefRpStatus.RpStatus.OTP_confirmation_failed.getValue();
		String loaFlag = IPSConstants.LOA_FLAG_NOT_ACHIEVED;
		String decision = IPSConstants.RP_DECISION_FAILED;
		String linkMatchQuality = IPSConstants.RP_EQUIFAX_IDMS_OTP_MISMATCH;
		String productStatus = IPSConstants.RP_EQUIFAX_IDMS_OTP_COMPLETED;
		long attemptsMade = assertionVo.getAttemptsMade();

		if (passedVerification) {
			rpStatus = RefRpStatus.RpStatus.LOA_level_achieved.getValue();
			loaFlag = IPSConstants.LOA_FLAG_ACHIEVED;
			decision = IPSConstants.RP_DECISION_PASSED;
			linkMatchQuality = IPSConstants.RP_EQUIFAX_IDMS_OTP_EXACT;
			productStatus = IPSConstants.RP_EQUIFAX_IDMS_OTP_PASS;
		}

		CustomLogger.debug(this.getClass(),
				String.format("VerificationType:%s, AttemptsMade:%s", verificationType, attemptsMade));
		
		assertionVo.setLoaSought(personVo.getProofingLevelSought());
		assertionVo.setLoaFlag(loaFlag);
		assertionVo.setVerificationDecision(decision);
		assertionVo.setVerificationMatchQuality(linkMatchQuality);
		assertionVo.setProductStatus(productStatus);
		assertionVo.setRpStatusCode(rpStatus);
		assertionVo.setVerificationSentDatetime(sentDatetime);
		assertionVo.setTotalRenewAttempts(0L);
		assertionVo.setAttemptsAllowed(IPSConstants.RP_ATTEMPTS_ALLOWED);
		assertionVo.setAttemptsMade(attemptsMade);
		assertionVo.setAttemptsPeriod(IPSConstants.RP_ATTEMPT_PERIOD);
		assertionVo.setPath(personVo.getPath());
		assertionVo.setMobilePhone(personVo.getMobileNumber());
		assertionVo.setTransactionId(personVo.getTransactionId());
		assertionVo.setSessionId(personVo.getSessionId());

		try {
			proofingService.smfaOnlinePhoneVerification(person, assertionVo);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), e);
		}
	}

	public static long parseTotalRenewAttempts(SubsequentResponse response) {

		long totalRenewAttempts = 0L;
		if (response != null && response.getProductResponses() != null
				&& response.getProductResponses().getDynamicOTP() != null
				&& response.getProductResponses().getDynamicOTP().getNumberOfRenewRequests() != null) {
			totalRenewAttempts = Long
					.parseLong(response.getProductResponses().getDynamicOTP().getNumberOfRenewRequests());
		}
		return totalRenewAttempts;
	}

	public static long parseTotalSubmitAttempts(SubsequentResponse response) {
		long totalSubmitAttempts = 0L;
		if (response != null && response.getProductResponses() != null
				&& response.getProductResponses().getDynamicOTP() != null
				&& response.getProductResponses().getDynamicOTP().getAttempts() != null
				&& response.getProductResponses().getDynamicOTP().getAttempts().getAttempt() != null) {
			List<DynamicOTP.Attempts.Attempt> attemptList = response.getProductResponses().getDynamicOTP().getAttempts()
					.getAttempt();
			totalSubmitAttempts = attemptList.size();
		}
		return totalSubmitAttempts;
	}

	public static String parseOtpMatchQuality(SubsequentResponse response, String otpMatchQuality) {
		if (response != null && response.getProductResponses() != null
				&& response.getProductResponses().getDynamicOTP() != null
				&& response.getProductResponses().getDynamicOTP().getAttempts() != null
				&& response.getProductResponses().getDynamicOTP().getAttempts().getAttempt() != null) {
			List<DynamicOTP.Attempts.Attempt> attemptList = response.getProductResponses().getDynamicOTP().getAttempts()
					.getAttempt();
			Iterator<DynamicOTP.Attempts.Attempt> attemptIterator = attemptList.iterator();
			while (attemptIterator.hasNext()) {
				DynamicOTP.Attempts.Attempt thisAttempt = attemptIterator.next();
				otpMatchQuality = thisAttempt.getValue().toString();
			}
		}
		return otpMatchQuality;
	}

	public static String parseProductStatus(SubsequentResponse response, String productStatus) {
		if (response != null && response.getProductResponses() != null
				&& response.getProductResponses().getDynamicOTP() != null
				&& response.getProductResponses().getDynamicOTP().getProductStatus() != null) {
			productStatus = response.getProductResponses().getDynamicOTP().getProductStatus().toString();
		}
		return productStatus;
	}

	public static String parsePasscodeDecision(SubsequentResponse response, String passcodeDecision) {
		if (response != null && response.getProductResponses() != null
				&& response.getProductResponses().getDynamicOTP() != null
				&& response.getProductResponses().getDynamicOTP().getDecision() != null) {
			passcodeDecision = response.getProductResponses().getDynamicOTP().getDecision();
		}
		return passcodeDecision;
	}

	public boolean resendPasscodeSuccessful(RpEvent event, Person person, PersonVo personVo)
			throws Throwable {
		CustomLogger.enter(this.getClass());

		boolean renewAttemptsExceeded = false;
		boolean sendPasscodeSuccessful = false;
		String transactionKey = event.getLatestOtpAttempt().getTransactionKey();
		String loaSought = personVo.getProofingLevelSought();
		CustomLogger.debug(this.getClass(),
				"TransactionKey=" + transactionKey + ", Person=" + person + ", PersonVo=" + personVo);

		// First check to see if the latest passcode attempt was a timeout. If so, a new
		// passcode request has to be done rather than
		// a renew request.
		if (!event.transactionKeyHasExpired() && !event.lastPasscodeAttemptExpired()
				&& !event.lastPasscodeAttemptExceededSubmit()) {
			proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_initiated.getValue(), person, loaSought);

			ResendPasscodeIDFSRequestXML xmlBuilder = new ResendPasscodeIDFSRequestXML();
			if (transactionKey == null) {
				transactionKey = equifaxDataService.retrievePasscodeTransactionKey(personVo.getId());
			}

			SubsequentRequest request = xmlBuilder.createResendPasscodeXMLSubsequentRequest(transactionKey);

			if (CustomLogger.isDebugEnabled()) {
				Gson g = new Gson();
				String requestJsonStr = g.toJson(request);
				CustomLogger.debug(this.getClass(),
						String.format("Equifax new passcode request Json request: %s", requestJsonStr));
			}

			try {
				SubsequentResponse response = sendIDFSSubsequentRequest(request, personVo);

				if (CustomLogger.isDebugEnabled()) {
					Gson g = new Gson();
					String responseJsonStr = g.toJson(response);
					CustomLogger.debug(this.getClass(),
							String.format("Equifax new passcode request Json response: %s", responseJsonStr));
				}

				proofingService.updateProofingStatus(RefRpStatus.RpStatus.OTP_sent.getValue(), person, loaSought);
				renewAttemptsExceeded = equifaxDataService.renewPasscode(event, response, personVo);
			} catch (SOAPFaultException ex) {
				CustomLogger.error(this.getClass(),
						String.format(LOG_EQUIFAX_CALL_SOAP_EXCEPTION_FMT, personVo.getSponsorUserId()), ex);
				throw new PhoneVerificationException(ex.getMessage());
			} catch (Exception ex) {
				CustomLogger.error(this.getClass(),
						String.format(LOG_EQUIFAX_CALL_EXCEPTION_FMT, personVo.getSponsorUserId()), ex);
				throw new PhoneVerificationException(ex.getMessage());
			}
		} else {
			sendPasscodeSuccessful = sendPasscodeSuccessful(person, personVo);
		}

		return sendPasscodeSuccessful && !renewAttemptsExceeded;
	}

	private Person getPerson(long id) {
		CustomLogger.enter(this.getClass());

		Person person = personService.findByPK(id);
		CustomLogger.debug(this.getClass(),
				"Person sponsorUserId: " + (person != null ? person.getSponsorUserId() : "not found"));
		return person;
	}

	/**
	 * if user did not successfully pass EIDPhone validation return true so the user
	 * can be redirected back to the User Info page and not send themself a passcode
	 * and get LOA 1.5
	 */
	@Override
	public boolean userFailedEIDPhoneVerification(Person person, long supplierId) {
		CustomLogger.enter(this.getClass());

		person = getPerson(person.getPersonId());
		if (person == null) {
			CustomLogger.error(this.getClass(), "person is null, userFailedEIDPhoneVerification() -> false");
			return true; // user failed EID phone verification
		} else {
			// product decision
			RpEvent event = rpEventService.getLatestPhoneVerification(person.getPersonId(), supplierId);
			if (event != null) {
				RpPhoneVerification rpPhoneVerification = event.getRpPhoneVerification();
				boolean userFailedVerification = true;

				if (supplierId == RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID) {
					boolean isPhoneVerifiedFlag = rpPhoneVerification.isEquifaxIDFSPhoneVerificationPassed();
					userFailedVerification = !isPhoneVerifiedFlag;
					CustomLogger.info(this.getClass(),
							"User with sponsor user id: " + person.getSponsorUserId() + " -> isPhoneVerifiedFlag="
									+ isPhoneVerifiedFlag + " userFailedEIDPhoneVerification="
									+ userFailedVerification);

				} else if (supplierId == RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID) {
					boolean isPhoneVerifiedOrForReviewFlag = rpPhoneVerification.isEquifaxDITPhoneVerificationPassed()
							|| rpPhoneVerification.isEquifaxDITPhoneVerificationForReview();
					userFailedVerification = !isPhoneVerifiedOrForReviewFlag;
					CustomLogger.info(this.getClass(),
							"User with sponsor user id: " + person.getSponsorUserId()
									+ " -> isPhoneVerifiedOrForReviewFlag=" + isPhoneVerifiedOrForReviewFlag
									+ " userFailedEIDPhoneVerification=" + userFailedVerification);

				}
				return userFailedVerification;
			} else {
				CustomLogger.error(this.getClass(), "event is null, userFailedEIDPhoneVerification() -> false");
				return true;
			}
		}
	}

	public InitiateSMFARequestModel prepareSmfaInitiateRequest(PersonVo personVo, String kbaUid, boolean isDesktop)
			throws Exception {
		CustomLogger.enter(this.getClass());

		String merchantId = "";
		
		try {
			merchantId = commonRestService.getJ2CInfo(EQUIFAX_SMFA_MERCHANT_ID_J2C_ALIAS).getPassword();
		} catch (IPSException e) {
			CustomLogger.error(this.getClass(), "Error occurred in getting J2C values of merchantId.", e);
		}

		ConsumerIdentifierModel consumerIdentifier = new ConsumerIdentifierModel();
		consumerIdentifier.setSubjectIdentifier(personVo.getMobileNumber());
		consumerIdentifier.setSubjectType(SUBJECT_TYPE_MDN);

		if (RefSponsor.SPONSOR_CHANGE_ADDRESS.equalsIgnoreCase(personVo.getSponsor())) {
			if (!StringUtils.isEmpty(personVo.getTrueIPAddress())) {
				consumerIdentifier.setDeviceIp(personVo.getTrueIPAddress());
			}
		}
		else {
			if (!isDesktop) {
				if (!personVo.isWebServiceCall()) {
					HttpServletRequest servletRequest = (HttpServletRequest) FacesContext.getCurrentInstance()
							.getExternalContext().getRequest();
					String deviceIp = commonRestService.getClientIpAddress(servletRequest);
					consumerIdentifier.setDeviceIp(deviceIp);
				} else {
					consumerIdentifier.setDeviceIp(personVo.getTrueIPAddress());
				}
			}
		}

		String environment = Utils.getEnvironmentWithoutDot();
	
		CustomLogger.debug(this.getClass(), String
				.format("Setting Equifax SMFA target url using %s with sponsor: %s in %s environment.", 
						(isDesktop? "desktop" : "mobile"), personVo.getSponsor(), environment));

		String verificationUrl = Utils.getProperty("com.ipsweb.VERIFICATION_URL");
		String targetUrl = "";
		String smsUrl = "";
	
		if (RefSponsor.SPONSOR_CHANGE_ADDRESS.equalsIgnoreCase(personVo.getSponsor())) {
			if (!StringUtils.isEmpty(personVo.getSmsUrl()) && !StringUtils.isEmpty(personVo.getTargetUrl())) {
				smsUrl = personVo.getSmsUrl();
				targetUrl = personVo.getTargetUrl();
				consumerIdentifier.setTargetUrl(targetUrl);
				consumerIdentifier.setSmsUrl(smsUrl);
			}
		}
		else  {
			if (IPSConstants.ENV_CAT.equalsIgnoreCase(environment) || IPSConstants.ENV_PREPROD.equalsIgnoreCase(environment) 	|| IPSConstants.ENV_PROD.equalsIgnoreCase(environment)) {
				if (isDesktop) {
					smsUrl = String.format(EQUIFAX_SMFA_SMS_URL_FMT, verificationUrl, kbaUid);
					targetUrl = String.format(EQUIFAX_SMFA_DESKTOP_TARGET_URL_FMT, verificationUrl);
				}
				else {
					smsUrl = String.format(EQUIFAX_SMFA_SMS_URL_FMT, verificationUrl, kbaUid);
					targetUrl = String.format(EQUIFAX_SMFA_TARGET_URL_FMT, verificationUrl);
				}
				
				consumerIdentifier.setTargetUrl(targetUrl);
				consumerIdentifier.setSmsUrl(smsUrl);
			}
		}

		InitiateSMFARequestModel initiateRequest = new InitiateSMFARequestModel();
		initiateRequest.setMerchantId(merchantId);
		initiateRequest.setUsecase(USE_CASE_SO);
		initiateRequest.setConsumerIdentifier(consumerIdentifier);

		return initiateRequest;
	}

	public StatusSMFARequestModel prepareSmfaStatusRequest(String mobileNumber) throws Exception {
		CustomLogger.enter(this.getClass());

		String merchantId = "";
		try {
			merchantId = commonRestService.getJ2CInfo(EQUIFAX_SMFA_MERCHANT_ID_J2C_ALIAS).getPassword();
		} catch (IPSException e) {
			CustomLogger.error(this.getClass(), "Error occurred in getting J2C values of merchantId.", e);
		}

		StatusSMFARequestModel statusRequest = new StatusSMFARequestModel();
		statusRequest.setMerchantId(merchantId);
		statusRequest.setUsecase(USE_CASE_SO);

		ConsumerIdentifierModel consumerIdentifier = new ConsumerIdentifierModel();
		consumerIdentifier.setSubjectIdentifier(mobileNumber);
		consumerIdentifier.setSubjectType(SUBJECT_TYPE_MDN);

		statusRequest.setConsumerIdentifier(consumerIdentifier);

		return statusRequest;
	}

	public InitiateSMFAResponseModel sendSmfaLink(Person person, PersonVo personVo, boolean isDesktop)
			throws IPSException, PhoneVerificationException, IOException {
		CustomLogger.enter(this.getClass());

		InitiateSMFARequestModel initiateRequest = null;

		try {
			initiateRequest = prepareSmfaInitiateRequest(personVo, person.getKbaUid(), isDesktop);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in getting InitiateRequestModel request.", e);
		}

		String bearerToken = "";

		try {
			bearerToken = generateEquifaxBearerToken(EquifaxServiceImpl.EQUIFAX_SMFA_OAUTH_SCOPE,
					EQUIFAX_SMFA_TOKEN_TYPE, false);
			personVo.setSmfaToken(bearerToken);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(),
					"Exception occurred in generating Equifax Bearer Token for Equifax SMFA request.", e);
		}

		InitiateSMFAResponseModel initiateResponse = null;
		Gson g = new Gson();
		String requestBodyStr = "";

		if (initiateRequest != null) {
			requestBodyStr = g.toJson(initiateRequest);
			CustomLogger.debug(this.getClass(), "Equifax SMFA Initiate Request:" + requestBodyStr);

			int attemptsSMFAInit = 0;
			do {
				attemptsSMFAInit = attemptsSMFAInit + 1;
				if (attemptsSMFAInit >= 2) {
					CustomLogger.error(this.getClass(), "Equifax SMFA repeating for 500 error " + attemptsSMFAInit + " times");
				}
				initiateResponse = commonRestService.sendInitiateSMFARequest(bearerToken, initiateRequest);
			} while (attemptsSMFAInit <= 3 && initiateResponse.getEfxErrorCode() != null
					&& "500".equals(initiateResponse.getEfxErrorCode()));
		}

		if (initiateResponse != null) {
			OtpLifecycleModel otpLifecycle = initiateResponse.getOtpLifecycle();
			String sendStatus = "";
			if (otpLifecycle != null) {
				sendStatus = otpLifecycle.getStatus();
			} else {
				CustomLogger.error(this.getClass(), "otpLifecycle is Null, defaulting to empty String, sessionID = "
						+ initiateResponse.getSessionId());
			}
			personVo.setSmfaSessionId(initiateResponse.getSessionId());

			if (!personVo.isWebServiceCall()) {
				HttpServletRequest servletRequest = (HttpServletRequest) FacesContext.getCurrentInstance()
						.getExternalContext().getRequest();
				HttpSession session = servletRequest.getSession();
				session.setAttribute(IPSConstants.PERSON_KEY, personVo);
			}

			initiateResponse.setLinkSuccessfullySent(OtpLifecycleModel.EQUIFAX_SMFA_SEND_LINK_SUCCESS.equalsIgnoreCase(sendStatus));
		
			equifaxDataService.saveSmfaSendAttempt(initiateResponse, personVo);

			String responseStr = g.toJson(initiateResponse);
			String redirectUrl = initiateResponse.getRedirectUrl();
			CustomLogger.debug(this.getClass(), "Equifax SMFA Initiate Response:" + responseStr);
			CustomLogger.debug(this.getClass(), "Equifax SMFA Initiate RedirectUrl:" + redirectUrl);

			String requestStr = String.format("Body:%s; Token:%s", requestBodyStr, bearerToken);

			responseStr = String.format("CallingAppUrl:%s, CallingAppName:%s, Body:%s", personVo.getCallingAppUrl(), 
	        		personVo.getCallingAppName(), responseStr);
	        
	        if (responseStr.length() > 4000) {
	        	responseStr = responseStr.substring(0, 4000);
	        }
	        
			equifaxDataService.saveResultToRpSmfaInitiateResponse(requestStr, responseStr,
					initiateResponse.getTransactionId(), initiateResponse.getSessionId(),
					redirectUrl, person);
			
			personVo.setRedirectUrl(redirectUrl);
		}

		return initiateResponse;
	}

	public String getSmfaStatus(PersonVo personVo) throws IPSException, PhoneVerificationException, IOException {
		return getSmfaStatus(personVo, true);
	}
	
	public String getSmfaStatus(PersonVo personVo, boolean checkTokenExpiry) throws IPSException, PhoneVerificationException, IOException {
		CustomLogger.enter(this.getClass());

		String smfaSessionId = personVo.getSmfaSessionId();
		String smfaToken = personVo.getSmfaToken();
		String loaSought = personVo.getProofingLevelSought();

		// SessionId and token would be null when this method was called from RemoteRest
		// web service
		if (smfaSessionId == null) {
			RpSmfaInitiateResponse smfaInitiateResponse = rpSmfaInitiateResponseService
					.findByPersonId(personVo.getId());
			
			if (smfaInitiateResponse == null) {
				return "";
			}
			
			smfaSessionId = smfaInitiateResponse.getSessionId();

			if (smfaToken == null) {
				String requestBody = smfaInitiateResponse.getRequest();
				String indexKey = "Token:";
				int index = requestBody.lastIndexOf(indexKey) + indexKey.length();
				smfaToken = requestBody.substring(index, requestBody.length());
			}
		}

		Person person = personService.findByPK(personVo.getId());
		PersonProofingStatus proofingStatus = person.getStatusForLoaSought(loaSought);
		Long statusCode = RefRpStatus.RpStatus.SMFA_validation_initiated.getValue();

		if (!proofingStatus.getStatusCode().equals(statusCode)) {
			proofingService.updateProofingStatus(statusCode, person, loaSought);
		}

		StatusSMFARequestModel statusRequest = null;

		try {
			statusRequest = prepareSmfaStatusRequest(personVo.getMobileNumber());
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in getting StatusSMFARequestModel request.", e);
		}

		Gson g = new Gson();
		String requestJsonStr = g.toJson(statusRequest);
		String responseJsonStr = "";

		StatusSMFAResponseModel statusResponse = commonRestService.sendStatusSMFARequest(smfaToken, smfaSessionId,
				statusRequest);
		String path = "";

		if (statusResponse != null) {
			responseJsonStr = g.toJson(statusResponse);
			CustomLogger.debug(this.getClass(),
					String.format("Equifax SMFA validate link response Json: %s", responseJsonStr));

			if (checkTokenExpiry && responseJsonStr.contains("Token expired")) {
				return "Token expired";
			}
			
			ResponseStatusModel responseStatus = statusResponse.getResponse();

			if (responseStatus != null) {
				// Retrieve the most recent Equifax DIT+SMFA phone verification event for this
				// person
				RpEvent rpEvent = rpEventService.getLatestPhoneVerification(personVo.getId(),
						RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID);
				RpPhoneVerification rpPhoneVerification = rpEvent.getRpPhoneVerification();
				RpSmfaAttempt smfaAttempt = rpEvent.getLatestSmfaAttempt();

				path = equifaxDataService.getDecisionPath(person, personVo, responseStatus, rpEvent,
						rpPhoneVerification, smfaAttempt);

				// This should cascade the change to phone verification and smfa attempt
				rpEventService.update(rpEvent);

				boolean smfaLinkPassedValidation = ResponseStatusModel.RESPONSE_PATH_GREEN.equalsIgnoreCase(path)
						|| ResponseStatusModel.RESPONSE_PATH_YELLOW.equalsIgnoreCase(path);
				boolean smfaLinkFailedValidation = ResponseStatusModel.RESPONSE_PATH_RED.equalsIgnoreCase(path)
						|| ResponseStatusModel.RESPONSE_PATH_ORANGE.equalsIgnoreCase(path);

				personVo.setSmfaStatus(path);
				
				CustomLogger.debug(this.getClass(),
						String.format("Equifax SMFA validate link %s for sponsorUserId: %s",
								(smfaLinkPassedValidation ? IPSConstants.VALUE_PASSED : IPSConstants.VALUE_FAILED),
								person.getSponsorUserId()));

				// Return Truth Data to ThreatMetrix
				truthDataReturnService.returnRemoteProofingTruthData(person, smfaLinkPassedValidation);
				CustomLogger.debug(this.getClass(), "Return Truth Data to ThreatMetrix for Equifax SMFA Link Validation Result:" 
						+ (smfaLinkPassedValidation? TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_PASS : TruthDataReturnServiceImpl.STATUS_EVENT_TAG_CHALLENGE_FAIL) );

				if (smfaLinkPassedValidation) {
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.LOA_level_achieved.getValue(), person,
							loaSought);
				}

				if (smfaLinkFailedValidation) {
					proofingService.updateProofingStatus(RefRpStatus.RpStatus.SMFA_validation_failed.getValue(), person,
							loaSought);
				}

				if (smfaLinkPassedValidation || smfaLinkFailedValidation) {
					long smfaSentDatetime = smfaAttempt.getMfaSentDatetime().getTime();
					long smfaDecisionDatetime = smfaAttempt.getMfaColorReceivedDatetime().getTime();
					int attemptsMade = rpPhoneVerification.getNumberOfSubmitAttempts();
					personVo.setPath(path);
					personVo.setTransactionId(
							(statusResponse.getTransactionId() != null ? statusResponse.getTransactionId() : ""));
					personVo.setSessionId(smfaSessionId);

					RefSponsorConfiguration config = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
		                    RefSponsorConfiguration.ASSERT_TO_CUSTREG);

					if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
						CustRegAssertionParamVo assertionVo = new CustRegAssertionParamVo();
						assertionVo.setLoaName(IPSConstants.LOA_RP_EQ_SMFA_NAME);
						assertionVo.setVerificationDecisionDatetime(smfaDecisionDatetime);
						assertionVo.setTotalSubmitAttempts(attemptsMade);
						
						assertPhoneVerificationResult(person, personVo, assertionVo, smfaSentDatetime, smfaLinkPassedValidation, EQUIFAX_SMFA_TOKEN_TYPE);
					}
				}
			}
			else {
				AdditionalErrorDetailModel additionalErrorDetail = statusResponse.getAdditionalErrorDetails();
				String efxErrorCode = statusResponse.getEfxErrorCode();
				
				if (additionalErrorDetail != null && efxErrorCode != null) {
					personVo.setErrorMessage(additionalErrorDetail.getDeveloperMessage());
					personVo.setErrorCode(efxErrorCode);
					path = IPSConstants.STATUS_ERROR;
				}
			}
			
			RpSmfaValidateResponse latestResponse = rpSmfaValidateResponseService.findByPersonIdAndSessionId(person.getPersonId(), smfaSessionId);
			boolean saveNewResponse = false;
			
			if (latestResponse != null) {
				if (latestResponse.getResponse() != null && latestResponse.getResponse().contains("efxErrorCode")
						&& !responseJsonStr.contains("efxErrorCode")) {
					saveNewResponse = true;
				}
			}
			else {
				saveNewResponse = true;
			}
			
			if (saveNewResponse) {
				equifaxDataService.saveResultToRpSmfaValidateResponse(requestJsonStr, responseJsonStr,
						statusResponse.getTransactionId(), smfaSessionId, smfaToken, person, personVo);
			}
		}
		return path;
	}

	private String getCurrentDateTime() {
		CustomLogger.enter(this.getClass());

		LocalDateTime currentDateTime = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMddyyyyHHmmss");
		return currentDateTime.format(formatter);
	}

	private String generateSessionId() {
		CustomLogger.enter(this.getClass());

		String randomId = UUID.randomUUID().toString();
		String[] uuidParts = randomId.split("-");
		String upperCasePart = uuidParts[uuidParts.length - 1].toUpperCase();

		return String.format(SESSION_ID_FORMAT, upperCasePart, randomId.substring(0, randomId.lastIndexOf('-')));
	}

	public String getSessionId(String sponsorUserId) {
		CustomLogger.enter(this.getClass());

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
				.getRequest();
		HttpSession session = request.getSession();
		String sessionId = "";

		if (sponsorUserId != null) {
			sessionId = (String) request.getSession().getAttribute(sponsorUserId + SESSION_ID_KEY);

			if (sessionId != null) {
				return sessionId;
			} else {
				sessionId = generateSessionId();
				session.setAttribute(sponsorUserId + SESSION_ID_KEY, sessionId);
			}
		} else {
			sessionId = generateSessionId();
		}

		return sessionId;
	}
	
    private void setStubResponseData(PersonVo personVo, String ditResponse) {    
    	String environment = Utils.getEnvironmentWithoutDot();
     	
		if (!IPSConstants.ENV_PROD.equalsIgnoreCase(environment) && personVo.isReturnDebugData()) {
			personVo.setResponseData(ditResponse); 
		}
    }

}
