package com.ips.proofing;

import java.io.Serializable;
import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.entity.Person;
import com.ips.entity.RefApp;
import com.ips.entity.RefEfxDitDecisionMap;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RpEquifaxResult;
import com.ips.entity.RpEvent;
import com.ips.entity.RpExperianDecisionResult;
import com.ips.entity.RpLexisNexisResult;
import com.ips.entity.RpPhoneVerification;
import com.ips.entity.RpPhoneVerificationResult;
import com.ips.entity.RpProofingSession;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationResponse;
import com.ips.service.PersonDataService;
import com.ips.service.RefAppService;
import com.ips.service.RefLoaLevelService;
import com.ips.service.RpEventDataService;
import com.ips.service.RpLexisNexisResultService;
import com.ips.service.RpProofingSessionDataService;

@Service("manageEventService")
public class ManageEventServiceImpl implements Serializable, ManageEventService {

    private static final long serialVersionUID = 1L;

    @Autowired
    private ExperianService experianService;
    @Autowired
    private RpEventDataService rpEventService;
    @Autowired
    private RpLexisNexisResultService rpLexisNexisResultService;
    @Autowired
    private RpProofingSessionDataService rpProofingSessionService;
    @Autowired
    private PersonDataService personService;
    @Autowired
    private RefLoaLevelService refLoaLevelService;
    @Autowired
    private RefAppService refAppService;
   
    /**
     * Each time the user verifies their phone number a new event will be created. 
     * A new proofing session will also be created to ensure that the proofing_id sent
     * to CustReg is unique for each phone verification flow.
     */
    @Transactional
    public RpEvent createEvent(PersonVo personVo, RpEvent previousEvent, long supplierId) {
        Timestamp currentTime = DateTimeUtil.getCurrentTime();

        Person person = personService.findByPK(personVo.getId());
        
        RpProofingSession proofingSession = rpProofingSessionService.findRpSessionByPerson(person);
        if (proofingSession == null) {
	        proofingSession = new RpProofingSession();
	        proofingSession.setPerson(person);
	        proofingSession.setCreateDate(currentTime);
	        proofingSession.setTotalAttempts(1);
	        rpProofingSessionService.create(proofingSession);
        }
        else {
        	proofingSession.setUpdateDate(currentTime);
 	        proofingSession.setTotalAttempts(1);
 	        rpProofingSessionService.update(proofingSession);
        }
        

        // Create the event
        RpEvent rpEvent = new RpEvent();
        rpEvent.setPersonId(personVo.getId());
        String transactionOriginAppName = personVo.getTransactionOriginAppName();
        RefApp findByAppName = refAppService.findByAppName(transactionOriginAppName);
        rpEvent.setTransactionOriginId(findByAppName);
        RefLoaLevel level = refLoaLevelService.findByLevel(personVo.getProofingLevelSought());
        rpEvent.setRefLoaLevel(level);

        rpEvent.setOtpSupplierId(supplierId);
        rpEvent.setCreateDate(currentTime);
        rpEvent.setInitiationDatetime(currentTime);
        
        // Create the phone verification record
        RpPhoneVerification phoneVerification = new RpPhoneVerification();
        phoneVerification.setMobilePhoneNumber(personVo.getMobileNumber());
        
        if (personVo.hasPreviousPhoneVerificationDecision()) {
              RpPhoneVerification previousPhoneVerification = previousEvent.getRpPhoneVerification();
            rpEvent.setOtpTransactionId(IPSConstants.DEVICE_REPUTATION_REPEAT_ASSESSMENT);  
            String prevPhoneVerificationDecision = previousPhoneVerification.getPhoneVerificationDecision() != null? previousPhoneVerification.getPhoneVerificationDecision() : PhoneVerificationResponse.PV_DECISION_FAIL;;
            phoneVerification.setPhoneVerificationDecision(prevPhoneVerificationDecision);
        }
        else {
            // Initialize to Pending
            phoneVerification.setPhoneVerificationDecision(PhoneVerificationResponse.PV_DECISION_PENDING);
        }
        
        phoneVerification.setCreateDate(currentTime);
        phoneVerification.setRpEvent(rpEvent);
        rpEvent.setRpPhoneVerification(phoneVerification);

        // Should cascade
        return rpEventService.create(rpEvent);
    }
    
    @Transactional
    public PhoneVerificationResponse savePreviousPhoneVerificationResults(RpEvent rpEvent, RpEvent prevEvent, 
    		PersonVo personVo, long supplierId) {
        CustomLogger.enter(this.getClass());
        
        boolean phoneVerified = false;
        boolean phoneForReview = false;
        Timestamp currentTime = DateTimeUtil.getCurrentTime();
         
        RpPhoneVerification prevPhoneVerification = prevEvent.getRpPhoneVerification();
        String prevPhoneVerificationDecision =  prevPhoneVerification.getPhoneVerificationDecision();
        String currPhoneVerificationDecision = PhoneVerificationResponse.PV_DECISION_FAIL;
        rpEvent.getRpPhoneVerification().setTransactionKey(prevPhoneVerification.getTransactionKey());

        // Store EID decision in eid_decision on phone verification
		prevPhoneVerificationDecision = prevPhoneVerificationDecision != null ? prevPhoneVerificationDecision : PhoneVerificationResponse.PV_DECISION_FAIL; 
        rpEvent.getRpPhoneVerification().setEidDecision(prevPhoneVerification.getEidDecision());
        rpEvent.getRpPhoneVerification().setPhoneVerificationDecision(prevPhoneVerificationDecision);
        rpEvent.getRpPhoneVerification().setOverallAssessment(prevPhoneVerification.getOverallAssessment());
        rpEvent.getRpPhoneVerification().setDecisionDateTime(prevPhoneVerification.getDecisionDateTime());
        rpEvent.getRpPhoneVerification().setRefPhoneType(prevPhoneVerification.getRefPhoneType());
        
	    if (RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID == supplierId
	    		|| RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID == supplierId) { 
 
	        RpEquifaxResult equifaxResult = new RpEquifaxResult();
	        RpEquifaxResult prevEquifaxResult = prevEvent.getRpEquifaxResult();
	        
	        if (prevEquifaxResult != null) {
	            equifaxResult.setOverallScore(prevEquifaxResult.getOverallScore());
	            equifaxResult.setMatchAssessmentCode(prevEquifaxResult.getMatchAssessmentCode());
	            equifaxResult.setFraudIndicatorCode(prevEquifaxResult.getFraudIndicatorCode());
	        }
	        
	        equifaxResult.setCreateDate(currentTime);        
	        equifaxResult.setFinalResponseTimestamp(currentTime);    
	        equifaxResult.setEventId(rpEvent.getEventId());    
	        equifaxResult.setRpEvent(rpEvent);
	        equifaxResult.setCreateDate(currentTime);
	        rpEvent.setRpEquifaxResult(equifaxResult);   
	    }
	    else if (RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID == supplierId) {
	        RpLexisNexisResult lexisResult = rpLexisNexisResultService.findByEvent(rpEvent);
	        
	        if (lexisResult == null) {
	        	lexisResult = new RpLexisNexisResult();
	        }
	        
	        RpLexisNexisResult prevLexisResult = prevEvent.getRpLexisNexisResult();
	        
	        lexisResult.setEventId(rpEvent.getEventId());
	        lexisResult.setRpEvent(rpEvent);
	        lexisResult.setRefLexisNexisResponseCode(prevLexisResult != null ? prevLexisResult.getRefLexisNexisResponseCode() : null);
	        lexisResult.setCreateDate(currentTime);
	        rpEvent.setRpLexisNexisResult(lexisResult);
	    }
	    else if (RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID == supplierId) {
	    	RpExperianDecisionResult prevExperianResult = prevEvent.getRpExperianDecisionResult();
	        
	    	if (prevExperianResult != null && prevExperianResult.getFinalDecision() != null) {
	    		RpExperianDecisionResult experianResult = new RpExperianDecisionResult();
	    		String clientReferenceId = experianService.generateClientReferenceId(personVo);
		    	experianResult.setClientReferenceId(clientReferenceId);
		    	
		    	experianResult.setFinalDecision(prevExperianResult.getFinalDecision());
		    	experianResult.setCreateDate(currentTime);
		    	experianResult.setRpEvent(rpEvent);
		    	
		        rpEvent.setRpExperianDecisionResult(experianResult);
	    	}
	    }
        
        RpPhoneVerificationResult phoneResult = new RpPhoneVerificationResult();
        RpPhoneVerificationResult prevPhoneResult = prevEvent.getRpPhoneVerificationResult();
        
        phoneResult.setCreateDate(currentTime);
        phoneResult.setEventId(rpEvent.getEventId());
        phoneResult.setRpEvent(rpEvent);
            
        if (prevPhoneResult != null) {
            phoneResult.setRefPhoneMatchQuality(prevPhoneResult.getRefPhoneMatchQuality());
            phoneResult.setValidNumber(prevPhoneResult.getValidNumber());
            phoneResult.setRefServiceStatusCode(prevPhoneResult.getRefServiceStatusCode());
            phoneResult.setRefProductStatusCode(prevPhoneResult.getRefProductStatusCode());
            phoneResult.setRefMatchLevel(prevPhoneResult.getRefMatchLevel());
        }
        
        rpEvent.setRpPhoneVerificationResult(phoneResult);
        RpPhoneVerification phoneVerification = rpEvent.getRpPhoneVerification();
        
 		rpEvent.setFinalDecision(prevEvent.getFinalDecision());
        rpEvent.setCompletionDatetime(currentTime);
        rpEvent.setUpdateDate(currentTime);
    
        // Should cascade
        rpEventService.update(rpEvent);
                
	    if (RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID == supplierId
	    		|| RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID == supplierId) { 
	
	        String phoneOverallAssessment = phoneVerification.getOverallAssessment();
	 
	    	if (RpPhoneVerification.DECISION_PASSED.equalsIgnoreCase(phoneOverallAssessment) 
	    			|| RpPhoneVerification.DECISION_FAILED.equalsIgnoreCase(phoneOverallAssessment)) {
	    		//Equifax IDFS
	      		phoneVerified = RpPhoneVerification.DECISION_PASSED.equalsIgnoreCase(phoneOverallAssessment);
	      		currPhoneVerificationDecision = phoneVerified? PhoneVerificationResponse.PV_DECISION_REVIEW : PhoneVerificationResponse.PV_DECISION_FAIL;
	    	    CustomLogger.debug(this.getClass(), "PhoneVerificationResponse > savePreviousPhoneVerificationResults for Equifax IDFS: " + currPhoneVerificationDecision);
	    		
	      		return new PhoneVerificationResponse(RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID, RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_NAME, 
	    				currPhoneVerificationDecision, rpEvent.getFinalDecision());
	    	}
	    	else {
	    		//Equifax DIT
	      		phoneVerified = RefEfxDitDecisionMap.DIT_DECISION_APPROVED.equalsIgnoreCase(phoneOverallAssessment);
	      		phoneForReview = RefEfxDitDecisionMap.DIT_DECISION_REVIEW.equalsIgnoreCase(phoneOverallAssessment);
	      		currPhoneVerificationDecision = phoneVerified ? PhoneVerificationResponse.PV_DECISION_PASS :
	      			(phoneForReview ? PhoneVerificationResponse.PV_DECISION_REVIEW : PhoneVerificationResponse.PV_DECISION_FAIL);
	    	    CustomLogger.debug(this.getClass(), "PhoneVerificationResponse > savePreviousPhoneVerificationResults for Equifax DIT: " + currPhoneVerificationDecision);

	      		return new PhoneVerificationResponse(RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID, RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME, 
	      				currPhoneVerificationDecision, rpEvent.getFinalDecision());
	    	}	    	
 	    }
	    else if (RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID == supplierId) {
	        phoneVerified = IPSConstants.VALUE_PASS.equalsIgnoreCase(prevPhoneVerificationDecision);
	        currPhoneVerificationDecision = phoneVerified ? PhoneVerificationResponse.PV_DECISION_REVIEW : PhoneVerificationResponse.PV_DECISION_FAIL;
    	    CustomLogger.debug(this.getClass(), "PhoneVerificationResponse > savePreviousPhoneVerificationResults for LexisNexis: " + currPhoneVerificationDecision);

	        return new PhoneVerificationResponse(RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID, RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_NAME, 
	        		currPhoneVerificationDecision, rpEvent.getFinalDecision());    
	    }
	    else if (RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID == supplierId) {
	        phoneVerified = IPSConstants.VALUE_PASS.equalsIgnoreCase(prevPhoneVerificationDecision);
	        currPhoneVerificationDecision = phoneVerified ? PhoneVerificationResponse.PV_DECISION_REVIEW : PhoneVerificationResponse.PV_DECISION_FAIL;
    	    CustomLogger.debug(this.getClass(), "PhoneVerificationResponse > savePreviousPhoneVerificationResults for Experian: " + currPhoneVerificationDecision);

	        return new PhoneVerificationResponse(RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID, RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_NAME, 
	        		currPhoneVerificationDecision, rpEvent.getFinalDecision());    
	    }
	    
	    CustomLogger.debug(this.getClass(), "Save Previous Results phoneVerified is: " + phoneVerified);
	      	    
	    return null;
    }
}
