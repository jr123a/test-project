package com.ips.proofing;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.xml.soap.SOAPException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.Utils;
import com.ips.entity.HighRiskAddressAttempt;
import com.ips.entity.IppEvent;
import com.ips.entity.OtpLockoutInfo;
import com.ips.entity.Person;
import com.ips.entity.PersonData;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefApp;
import com.ips.entity.RefIppEventStatus;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefOtpVelocity;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefRpStatus.RpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpDeviceReputation;
import com.ips.entity.RpEvent;
import com.ips.entity.RpProofingSession;
import com.ips.exception.AMSException;
import com.ips.exception.IMSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.CustRegAssertionParamVo;
import com.ips.persistence.common.EmailText;
import com.ips.persistence.common.Emailer;
import com.ips.persistence.common.GenerateBarcodeUtil;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.UserVo;
import com.ips.polocator.common.AppointmentVo;
import com.ips.polocator.common.IppVo;
import com.ips.polocator.common.LocationVo;
import com.ips.service.CustRegService;
import com.ips.service.HighRiskAddressService;
import com.ips.service.IppEventService;
import com.ips.service.PersonDataDataService;
import com.ips.service.PersonDataService;
import com.ips.service.PhoneVelocityCheckService;
import com.ips.service.RefAppService;
import com.ips.service.RefIppEventStatusService;
import com.ips.service.RefLoaLevelService;
import com.ips.service.RefRpStatusDataService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;
import com.ips.service.RefStateDataService;
import com.ips.service.RpProofingSessionDataService;
import com.usps.net2x.entreg.data.EntRegUserLOAAssertion;
import com.usps.net2x.entreg.data.EntRegUserLOADITPhoneResults;
import com.usps.net2x.entreg.data.EntRegUserLOAEIDLockoutInfo;
import com.usps.net2x.entreg.data.EntRegUserLOAEIDLockouts;
import com.usps.net2x.entreg.data.EntRegUserLOAEIDPasscodeResults;
import com.usps.net2x.entreg.data.EntRegUserLOAEIDPhoneResults;
import com.usps.net2x.entreg.data.EntRegUserLOAInPersonResults;
import com.usps.net2x.entreg.data.EntRegUserLOASMFAResults;

@Service("ProofingService")
public class ProofingServiceImpl implements Serializable, ProofingService {

    private static final long serialVersionUID = 1L;

    @Autowired
    private PersonDataDataService personDataService;
    @Autowired
    private PersonDataService personService;
    @Autowired
    private RefRpStatusDataService refRpStatusService;
    @Autowired
    private IppEventService ippEventService;
    @Autowired
    private RefIppEventStatusService refIpEventStatusService;
    @Autowired
    private PhoneVelocityCheckService phoneVelocityCheckService;
    @Autowired
    private RpProofingSessionDataService rpProofingSessionService;
    @Autowired
    private RefStateDataService refStateService;
    @Autowired
    private RefLoaLevelService refLoaLevelService;
    @Autowired
    private Emailer emailer;
    @Autowired
    private RefSponsorConfigurationService refSponsorConfigurationService;
    @Autowired
    private CustRegService custRegService;
    @Autowired
    private RefAppService refAppService;
    @Autowired
    private RefSponsorDataService refSponsorDataService;
    @Autowired
    private RefSponsorDataService refSponsorService;
    @Autowired
    private VerifyAddressService verifyAddressService;
    @Autowired
    private HighRiskAddressService riskAddressService;

    private static final String LOG_USER_INFO_FMT = "User SponsorUserId: %s";
    private static final String LOG_PERSON_GET_ERROR_FMT = "Error retrieving Person with UserId: %s";
    private static final String LOG_RETRIEVE_PERSON_ERROR_FMT = "Could not retrieve person with User SponsorUserId: %s";
    private static final String EXCEPTION_NULL_PERSON_MSG = "Person is null";
    public static final String VALUE_TRUE = "True";
    private static final String CANNOT_CALL_IDM_MSG_FMT = "Can not call IDM for PersonID %s to create IPP user.";
    private static final String CANNOT_LOAD_PROP_MSG_FMT = "Can not load properties file when calling IDM for PersonID %s to create IPP user.";
    private static final String ERROR_IDM_INFO_MSG_FMT = "Error info coming from IDM for PersonID %s to create IPP user.";
    private static final String CANNOT_CREATE_IPP_EVENT_MSG_FMT = "Cannot create IppEvent for sponsorUserId: %s.";
    private static final String IPP_EMAIL_SENT_ERROR_MSG_FMT = "Error sending IPP email for sponsorUserId: %s";
    
    @Override
    public String getUniqueUID() {
        CustomLogger.enter(this.getClass());
        String uid = null;
        boolean foundUID = false;
        Person existingPerson = null;

		try {
	        while (!foundUID) {
	            SecureRandom random = new SecureRandom();
	            Double randomNum1 = random.nextDouble() * 100000;
	
	            SecureRandom random2 = new SecureRandom();
	            Double randomNum2 = random2.nextDouble() * 10000;
	
	            uid = randomNum1.toString().substring(0, 10) + randomNum2.toString().substring(0, 10);
	            uid = uid.replace('.', '0');

	            CustomLogger.info(this.getClass(), "UID generated: " + uid);
		        existingPerson = personService.findByUid(uid);

	            if (existingPerson == null) {
	                foundUID = true;
	            }
	
	            CustomLogger.info(this.getClass(), "foundUID " + foundUID);
	        }
		}catch (Exception e) {
			CustomLogger.error(this.getClass(), "Eror in getting UniqueUID ", e);
        }

        return uid;
    }

    private String getLoaLevel(UserVo user, Person person) {
        String loaLevel = "";
        if (user != null) {
            loaLevel = user.getLoaSought();
        } else {
            loaLevel = person.getSoughtLoaLevel().getLoaLevel();
        }
        return loaLevel;
    }
    
    @Override
    public void updateProofingStatus(Long statusCode, UserVo user) {
        CustomLogger.enter(this.getClass());
        Person person = null;
        try {
            person = findPerson(user);
            updateProofingStatus(statusCode, person, user.getLoaSought());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error in updateProofingStatus for sponsorUserId:" + user.getSponsorUserId(), e);
        }

    }

    /**
     * Updates the user's proofing_status.
     * 
     * @param statusCode
     */
    public void updateProofingStatus(Long statusCode, Person existingPerson, String loaSought) {
        CustomLogger.enter(this.getClass());
        Date updateDate = getCurrentTime();

        if (existingPerson != null) {
            try {
                RefRpStatus refStatus = refRpStatusService.findById(statusCode);

                CustomLogger.debug(this.getClass(), "RefStatus: " + refStatus.otpToString());

                PersonProofingStatus proofingStatus = existingPerson.getStatusForLoaSought(loaSought);
                proofingStatus.setRefRpStatus(refStatus);
                proofingStatus.setProofingStatusDatetime(updateDate);
                proofingStatus.setUpdateDate(updateDate);
                existingPerson.setUpdateDate(updateDate);

                CustomLogger.debug(this.getClass(), "Status in updateProofingStatus is: " + statusCode);

                // If status is LOA Achieved, set proofing_level_achieved and datetime
                if (IPSConstants.STATUS_LOA_ACHIEVED.equalsIgnoreCase(proofingStatus.getStatusDescription())) {
                    CustomLogger.debug(this.getClass(), "Status is LOA Achieved, updating achieved fields");
                    long loaCode = RefLoaLevel.convertStringToCode(loaSought);
                    RefLoaLevel level = refLoaLevelService.findByCode(loaCode);
                    existingPerson.setAchievedLoaLevel(level);
                    existingPerson.setLoaAchievedDateTime(updateDate);

                    // Null out the datetime the credential was used so that the job will not expire it
                    proofingStatus.setCredentialUsedDateTime(null);

                    // Clear out the expiration date for the activation code
                    proofingStatus.setCodeExpirationDate(null);
                }

                // ONLY in the case of Remote Proofing Passed (passed quiz online),
                // update any IPP events in Start status to Retried Remote status
                RefIppEventStatus retriedStatus = refIpEventStatusService.findByDescription(IPSConstants.IPP_STATUS_RP_RETRY);
                
                if (IPSConstants.STATUS_RP_PASSED.equalsIgnoreCase(proofingStatus.getStatusDescription())) {
                    for (IppEvent event : existingPerson.getIppEvents()) {
                        if (IPSConstants.IPP_STATUS_STARTED
                                .equalsIgnoreCase(event.getRefIppEventStatus().getEventStatusDescription())) {
                            event.setRefIppEventStatus(retriedStatus);
                            event.setUpdateDate(updateDate);
                        }
                    }
                }

                // Should update the events as well
                existingPerson = personService.update(existingPerson);

            } catch (Exception e) {
                CustomLogger.error(this.getClass(), "Update Proofing Status of User with PersonId "
                        + existingPerson.getPersonId() + " to status " + statusCode + " has failed.", e);
            }
        }
    }
     
    public void startProofingSession(Person person, PersonVo personVo) throws Exception {
        CustomLogger.enter(this.getClass(), String.format("UserSponsorId:%s", personVo.getSponsorUserId()));
       
        try {
            checkProofingSession(person, personVo);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error occurred updating proofing session for sponsorUserId: " + personVo.getSponsorUserId(), e);
            throw e;
        }
    }

    private void checkProofingSession(Person person, PersonVo personVo) {
        CustomLogger.enter(this.getClass());
        // create proofing session
        // check if status is new user, canceled rp, reproofing or started remote
        // proofing
        RpProofingSession proofingSession = new RpProofingSession();
        PersonProofingStatus proofingStatus = person.getStatusForLoaSought(personVo.getProofingLevelSought());
        String status = proofingStatus.getStatusDescription();
        
        if (IPSConstants.STATUS_NEW_TO_IPS.equalsIgnoreCase(status) || IPSConstants.STATUS_RP_CANCELLED.equalsIgnoreCase(status)
                || IPSConstants.STATUS_REPROOFING.equalsIgnoreCase(status) || IPSConstants.STATUS_RP_STARTED.equalsIgnoreCase(status)) {
            try {
                proofingSession.setPerson(person);
                proofingSession.setCreateDate(new Timestamp(new Date().getTime()));
                proofingSession.setTotalAttempts(1);
                rpProofingSessionService.create(proofingSession);
                CustomLogger.debug(this.getClass(),
                        "Rp Proofing Session created for sponsorUserId: " + personVo.getSponsorUserId());
                updateProofingStatus(RefRpStatus.RpStatus.Started_remote_proofing.getValue(), person,
                        personVo.getProofingLevelSought());
            } catch (Exception e) {
                CustomLogger.error(this.getClass(),
                        "Cannot create Rp Proofing Session for sponsorUserId: " + personVo.getSponsorUserId(), e);
                throw e;
            }
        } else {
            try {
                proofingSession = rpProofingSessionService.findRpSessionByPerson(person);
                if (proofingSession != null) {
                	int totalAttempts = proofingSession.getTotalAttempts() + 1;
                	
                	if (totalAttempts > 99) {
                		totalAttempts = 99;
                	}
	                proofingSession.setTotalAttempts(totalAttempts);
	                proofingSession.setUpdateDate(new Timestamp(new Date().getTime()));
	                rpProofingSessionService.update(proofingSession);
                }
            } catch (Exception e) {
                CustomLogger.error(this.getClass(),
                        "Cannot update Rp Proofing Session for sponsorUserId: " + personVo.getSponsorUserId(), e);
                throw e;
            }
        }
    }

    /**
     * Checks to see if the user is already locked out. If there is no record in the
     * kba_lockout_info table, a new one is created for the user.
     */
    public RefOtpVelocity phoneVelocityCheck(Person person, PersonVo personVo, RefOtpSupplier verifyMethod) {
        CustomLogger.enter(this.getClass(), String.format("SponsorUserId:%s", personVo.getSponsorUserId()));

        RefLoaLevel level = refLoaLevelService.findByLevel(personVo.getProofingLevelSought());
        boolean lockoutStillInEffect = lockoutStillInEffect(person, personVo, verifyMethod, level);
        
        RefOtpVelocity phoneVelocity = phoneVelocityCheckService.checkPhoneVelocity(person, personVo, verifyMethod, level);
        phoneVelocity.setLockoutStillInEffect(lockoutStillInEffect);

        return phoneVelocity;
    }
    
    /**
     * Checks to see if the user is already locked out. If there is no record in the
     * kba_lockout_info table, a new one is created for the user.
     */
    public boolean lockoutStillInEffect(Person person, PersonVo personVo, RefOtpSupplier verifyMethod, RefLoaLevel level) {
        CustomLogger.enter(this.getClass(), String.format("SponsorUserId:%s", personVo.getSponsorUserId()));
        
		boolean lockoutStillInEffect = true;
        // This checks to see if there is an existing lockout for the person. If they
        // are locked out with one supplier, that lockout
        // is honored until it expires
        OtpLockoutInfo lockout = person.hasPriorLockout(level);
        personVo.setLockoutStillInEffect(false);
        lockoutStillInEffect = false;
        
        if (lockout != null && lockout.getRefOtpSupplier() != null) {
     		// Phone supplier check is no longer included since suppliers are all phone suppliers and no more KBA supplier.
        	//Prior lockout is honored despite which supplier it was locked out with until it expires.
 
        	if (lockout.stillInEffect()) {
      			personVo.setSupplierEffectingLockout(lockout.getRefOtpSupplier().getOtpSupplierName());
     			personVo.setLockoutStillInEffect(true);
     			lockoutStillInEffect = true;
     		}
         }
 
        return lockoutStillInEffect;
    }

    /**
     * Either creates a new person record or updates the existing one. Sets the
     * date/time the user entered IVS for reporting purposes.
     */
    public Person updatePerson(PersonVo personVo) throws Exception {
        CustomLogger.enter(this.getClass());
        String sponsorUserId = personVo.getSponsorUserId();

        if (sponsorUserId == null) {
            throw new PhoneVerificationException("SponsorUserId cannot be null");
        }

        Person person = new Person();
        person.setSponsorUserId(sponsorUserId);

        Date currentDate = new Date();

        RefSponsor refSponsor = null;
        Person existingPerson = null;

        try {
            refSponsor = refSponsorDataService.findBySponsorName(personVo.getSponsor());

            if (refSponsor != null) {
            	person.setRefSponsor(refSponsor);
            	existingPerson = personService.findFirstBySponsor(person.getRefSponsor(), person.getSponsorUserId());
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred while retrieving refSponsor of sponsorUserId: "
                    + person.getSponsorUserId() + ": ", e);
            throw e;
        }
  
        Timestamp currentDateTime = new Timestamp(new Date().getTime());

        // Do all of the database access up front to prevent duplicate person records
        // from being created

        RefLoaLevel level = refLoaLevelService.findByLevel(personVo.getProofingLevelSought());
        RefLoaLevel noLevel = refLoaLevelService.findByCode(RefLoaLevel.NO_LEVEL_CODE);
        RefRpStatus newStatus = refRpStatusService.findByDescription(IPSConstants.STATUS_NEW_TO_IPS);

        if (existingPerson == null) {
            String uid = getUniqueUID();

            try {
                person.setKbaUid(uid);
                personVo.setKbaUid(uid);
                person.setCreateDate(currentDateTime);

                // LOA achieved must be set
                person.setAchievedLoaLevel(noLevel);

                PersonProofingStatus proofingStatus = new PersonProofingStatus();
                proofingStatus.setRefLoaLevel(level);
                proofingStatus.setRefRpStatus(newStatus);
                proofingStatus.setProofingStatusDatetime(currentDateTime);
                proofingStatus.setCreateDate(currentDateTime);

                //PersonData will be removed for non-CustReg sponsor transaction
                PersonData personData = getPersonData(null, personVo);
                personData.setCreateDate(currentDateTime);
                
                person.setEnteredDateTime(currentDate);
                // Proofing level sought must be set so that proofing level can be captured in
                // audit_person.
                // This allows reporting Entered IVS by proofing level.
                person.setSoughtLoaLevel(level);
                
                if (refSponsor != null) {
                	 person.setRefSponsor(refSponsor);
               
                	 person = personService.createNewPerson(person, personData, proofingStatus);
                	 personVo.setId(person.getPersonId());
                }
            } catch (Exception e) {
                CustomLogger.error(this.getClass(),
                        "Error creating a person with SponsorUserId: " + person.getSponsorUserId() + ": ", e);
                throw e;
            }
        } else {
            try {
                personVo.setKbaUid(existingPerson.getKbaUid());
                personVo.setId(existingPerson.getPersonId());

                PersonData personData = getPersonData(existingPerson, personVo);
                personData.setPersonId(existingPerson.getPersonId());
                personData.setUpdateDate(currentDateTime);
                personData.setCreateDate(existingPerson.getCreateDate());
                personData.setPerson(existingPerson);
                existingPerson.setPersonData(personData);
                existingPerson.setUpdateDate(currentDateTime);

                // If this is a new level of assurance for the user, create a new proofing
                // status and set to Started remote proofing
                PersonProofingStatus proofingStatus = existingPerson
                        .getStatusForLoaSought(personVo.getProofingLevelSought());

                if (proofingStatus == null) {
                    proofingStatus = new PersonProofingStatus();
                    proofingStatus.setRefLoaLevel(level);
                    proofingStatus.setCreateDate(currentDateTime);
                    proofingStatus.setRefRpStatus(refRpStatusService.findByDescription(IPSConstants.STATUS_RP_STARTED));
                    proofingStatus.setProofingStatusDatetime(currentDateTime);
                    existingPerson.addProofingStatus(proofingStatus);
                }

                existingPerson.setEnteredDateTime(currentDate);
                // Proofing level sought must be set so that proofing level can be captured in
                // audit_person.
                // This allows reporting Entered IVS by proofing level.
                existingPerson.setSoughtLoaLevel(level);
                person = personService.update(existingPerson);
            } catch (Exception e) {
                CustomLogger.error(this.getClass(),
                        "Error updating Person with SponsorUserId: " + person.getSponsorUserId(), e);
                throw e;
            }
        }

        return person;
    }
    
    /**
     * Updates the person proofing status with the specified RpStatus for LOA 1.5.
     */
    @Override
    public void updatePersonProofingStatus(Person person, RpStatus rpStatus) {
        CustomLogger.enter(this.getClass());

        try {        
            PersonProofingStatus proofingStatus = person.getStatusForLoaSought(IPSConstants.LOA_15);        
            Date currentDate = new Timestamp(new Date().getTime());
            
            if (rpStatus != null) {
                RefRpStatus refStatus = refRpStatusService.findById(rpStatus.getValue());
                proofingStatus.setRefRpStatus(refStatus);
            }
            
            if (rpStatus == RefRpStatus.RpStatus.LOA_level_achieved) {
                RefLoaLevel level = refLoaLevelService.findByCode(RefLoaLevel.convertStringToCode(IPSConstants.LOA_15));
                person.setAchievedLoaLevel(level);
                person.setLoaAchievedDateTime(currentDate);
            }
            
            proofingStatus.setUpdateDate(new Timestamp(new Date().getTime()));
            person.addProofingStatus(proofingStatus);
            personService.update(person);          
		}
        catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred on updatePersonProofingStatus for personId:" + person.getPersonId(), e);
        }  
    }

    private PersonData getPersonData(Person existingPerson, PersonVo p) {
        CustomLogger.enter(this.getClass());
        
        PersonData personData = new PersonData();
        
        if (existingPerson != null && existingPerson.getPersonData() != null) {
        	personData = existingPerson.getPersonData();
        }
        
        if (p.getAddressLine1() != null) {
        	personData.setAddressLine1(p.getAddressLine1());
        }
        else if (existingPerson != null) {
        	p.setAddressLine1(personData.getAddressLine1());
        }
        
        if (p.getAddressLine2() != null) {
        	personData.setAddressLine2(p.getAddressLine2());
        }
        else if (existingPerson != null) {
        	p.setAddressLine2(personData.getAddressLine2());
        }
        
        if (p.getAddressLine3() != null) {
        	personData.setAddressLine3(p.getAddressLine3());
        }
        else if (existingPerson != null) {
        	p.setAddressLine3(personData.getAddressLine3());
        }
        
        if (p.getDob() != null) {
        	personData.setBirthDate(p.getDob());
        }
        else if (existingPerson != null) {
        	p.setDob(personData.getBirthDate());
        }
        
        if (p.getCity() != null) {
        	personData.setCity(p.getCity());
        }
        else if (existingPerson != null) {
        	p.setCity(personData.getCity());
        }
        
        if (p.getEmailAddress() != null) {
        	personData.setEmailAddress(p.getEmailAddress());
        }
        else if (existingPerson != null) {
        	p.setEmailAddress(personData.getEmailAddress());
        }
        
        if (p.getFirstName() != null) {
        	personData.setFirstName(p.getFirstName());
        }
        else if (existingPerson != null) {
        	p.setFirstName(personData.getFirstName());
        }
        
        if (p.getMiddleName() != null) {
        	personData.setMiddleName(p.getMiddleName());
        }
        else if (existingPerson != null) {
        	p.setMiddleName(personData.getMiddleName());
        }
        
        if (p.getLastName() != null) {
        	personData.setLastName(p.getLastName());
        }
        else if (existingPerson != null) {
        	p.setLastName(personData.getLastName());
        }
        
        if (p.getPhoneNumber() != null) {
        	personData.setPhoneINT(p.getPhoneNumber());
        }
        else if (existingPerson != null) {
        	p.setPhoneNumber(personData.getPhoneINT());
        }
        
        if (p.getPhoneType() != null) {
        	personData.setPhoneType(p.getPhoneType());
        }
        else if (existingPerson != null) {
        	p.setPhoneType(personData.getPhoneType());
        }
        
        if (p.getPostalCode() != null) {
        	personData.setPostalCode(p.getPostalCode());
        }
        else if (existingPerson != null) {
        	p.setPostalCode(personData.getPostalCode());
        }
        
        if (p.getStateProvince() != null) {
        	personData.setStateProvince(p.getStateProvince());
        }
        else if (existingPerson != null) {
        	p.setStateProvince(personData.getStateProvince());
        }
        
        if (p.getCountry() != null) {
        	personData.setCountryName(p.getCountry());
        }
        else if (existingPerson != null) {
        	p.setCountry(personData.getCountryName());
        }

        int addressHash = riskAddressService.calculateAddressHash(p);
        personData.setAddressHash(addressHash);

        return personData;
    }

    private Timestamp getCurrentTime() {
        Date date = new Date();
        return new Timestamp(date.getTime());
    }

    /**
     * Grabs the UserVo from the database based on the sponsor user id and sponsor
     * 
     * @param PersonVo
     *            person
     */
    @Override
    public UserVo getUserForRouting(UserVo user) {
        CustomLogger.enter(this.getClass());
        user.setStatus(IPSConstants.STATUS_ERROR);
        long sponsorId = 0;
        String sponsor = user.getSponsor();
       
        if (IPSConstants.SPONSOR_CUSTREG.equalsIgnoreCase(sponsor)) {
            sponsor = RefSponsor.SPONSOR_CUSTREG;
        }

        try {
            sponsorId = refSponsorDataService.findBySponsorName(sponsor).getSponsorId();
            CustomLogger.debug(this.getClass(), "Sponsor ID of user: " + user.getSponsorUserId() + " is " + sponsorId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error occurred while retrieving Sponsor ID of user: " + user.getSponsorUserId() + ": ", e);
            return user;
        }

        try {
            RefSponsor refSponsor = refSponsorDataService.findByPK(sponsorId);
            Person person = personService.findFirstBySponsor(refSponsor, user.getSponsorUserId());
            if (person != null) {
                user.setUserId(person.getPersonId());
                user.setEmail(person.getPersonData().getEmailAddress());

                // Set first and last name for logging purposes
                user.setFirstName(person.getPersonData().getFirstName());
                user.setLastName(person.getPersonData().getLastName());

                if (resetAbandonedToNew(person, user.getLoaSought())) {
                    user.setStatus(IPSConstants.STATUS_NEW_TO_IPS);
                    return user;
                }

                PersonProofingStatus proofingStatus = person.getStatusForLoaSought(user.getLoaSought());

                // If the status was not found, that means this is a new level of assurance for
                // the user so set status to Started
                if (proofingStatus == null) {
                    user.setStatus(IPSConstants.STATUS_RP_STARTED);
                } else {
                    user.setStatus(proofingStatus.getStatusDescription());
                    user.setStatusCode(proofingStatus.getRefRpStatus().getStatusCode());
                }

                user.setLoaAchieved(person.getAchievedLoaLevel().getLoaCode());
                return user;
            } else {
                CustomLogger.debug(this.getClass(),
                        String.format(LOG_USER_INFO_FMT, user.getSponsorUserId()) + " is new to the system.");
                user.setStatus(IPSConstants.STATUS_NEW_TO_IPS);
                return user;
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error occured during getUser_for_routing for sponsorUserId:" + user.getSponsorUserId(), e);
            return user;
        }
    }

    /**
     * If the proofing status date is more than 30 days in the past or if they have
     * an expired IPPEvent, reset status to New. Return value indicates if value was
     * changed.
     * 
     * @param person
     * @return
     */
    private boolean resetAbandonedToNew(Person person, String loaSought) {
        CustomLogger.enter(this.getClass());
        Date currentDate = new Date();
        Date last30Days = DateTimeUtil.getDateMinusDays(currentDate, 30);

        PersonProofingStatus statusForLoaSought = person.getStatusForLoaSought(loaSought);

        if (statusForLoaSought != null) {
            RefRpStatus currentStatus = statusForLoaSought.getRefRpStatus();
            Date proofingDate = statusForLoaSought.getProofingStatusDatetime();

            if (proofingDate != null && proofingDate.before(last30Days) && !currentStatus.isLoaAchieved()) {
                // Reset to New
                updateProofingStatus(RefRpStatus.RpStatus.New_to_IPS_No_Proofing_Events.getValue(), person, loaSought);
                return true;
            } else if (statusForLoaSought.isIppEmailSent()) {
                List<IppEvent> events = person.getIppEvents();
                Iterator<IppEvent> it = events.iterator();
                boolean abandonedEvent = false;
                boolean noNewEvent = true;
                while (it.hasNext()) {
                    IppEvent event = it.next();
                    if (event.getRefIppEventStatus().isIppNew()) {
                        noNewEvent = false;
                    } else if (event.getRefIppEventStatus().isIppExpired()) {
                        abandonedEvent = true;
                    }
                }

                if (noNewEvent && abandonedEvent) {
                    updateProofingStatus(RefRpStatus.RpStatus.New_to_IPS_No_Proofing_Events.getValue(), person,
                            loaSought);
                    return true;
                }
            }
        }

        return false;
    }

    public UserVo optInToIpp(UserVo user) throws Exception {
        CustomLogger.enter(this.getClass());
        Person person = null;

        try {
            person = findPerson(user);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format(LOG_PERSON_GET_ERROR_FMT, user.getUserId()), e);
            user.setStatus(IPSConstants.STATUS_ERROR);
            return user;
        }

        if (person != null) {
            user.setStatus(IPSConstants.STATUS_IPP_OPT_IN);
            updateProofingStatus(RefRpStatus.RpStatus.Opted_in_for_in_person_proofing.getValue(), person,
                    user.getLoaSought());
            return user;
        }

        user.setStatus(IPSConstants.STATUS_ERROR);
        return user;
    }

    public UserVo confirmOptIn(UserVo user, HighRiskAddressAttempt attempt, RpDeviceReputation deviceReputation)
            throws Exception {
        CustomLogger.enter(this.getClass());
        Person person = null;
        try {
            person = findPerson(user);

            if (person == null) {
                CustomLogger.error(this.getClass(), String.format(LOG_PERSON_GET_ERROR_FMT, user.getUserId()));
                throw new PhoneVerificationException(EXCEPTION_NULL_PERSON_MSG);
            }
            
            // To handle browser page refresh, return if the user has
            // already opted in (i.e user rp status is 5 - In-person email sent)
            PersonProofingStatus proofingStatus = person.getStatusForLoaSought(user.getLoaSought());

            if (IPSConstants.STATUS_IPP_EMAIL_SENT.equalsIgnoreCase(proofingStatus.getStatusDescription())) {
                CustomLogger.debug(this.getClass(),
                        "Handling IPP page refresh button for sponsorUserId:" + user.getSponsorUserId());
                user.setStatus(IPSConstants.STATUS_IPP_EMAIL_SENT);
                return user;
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format(LOG_PERSON_GET_ERROR_FMT, user.getUserId()), e);
            user.setStatus(IPSConstants.STATUS_ERROR);
            return user;
        }

        try {
            user.setStatus(optIn(person, user.getLoaSought(), attempt, deviceReputation));
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error on opt-in to IPP for sponsorUserId: " + user.getSponsorUserId(),
                    e);
            throw e;
        }

        user.setEmail(person.getPersonData().getEmailAddress());

        RefSponsorConfiguration config = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
                RefSponsorConfiguration.ASSERT_TO_CUSTREG);
        if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
            // Assert to CustReg
        	RpProofingSession session = rpProofingSessionService.findRpSessionByPerson(person);
        	
        	if (session != null) {
	            EntRegUserLOAAssertion loaAssertion = getAssertionForOptInIpp(person, user, session);
	            EntRegUserLOAInPersonResults ippResults = new EntRegUserLOAInPersonResults(user.getSponsorUserId(), null);
	            ippResults.setOptInDate(new Date());
	
	            custRegService.assertOptInIpp(loaAssertion, ippResults);
        	} else {
                CustomLogger.error(this.getClass(),
                        "finding RpSession By Person returned null for sponsorUserId:" + person.getSponsorUserId());
            }
        }
        return user;
    }

    public UserVo getUserFilteredPOList(UserVo user) throws Exception {
        CustomLogger.enter(this.getClass());
        Person person = null;

        try {
            person = findPerson(user);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format(LOG_PERSON_GET_ERROR_FMT, user.getUserId()), e);
            user.setStatus(IPSConstants.STATUS_ERROR);
            return user;
        }

        if (person != null) {
            // Get Filtered PO Locations List
            IppVo ippVo = new IppVo();
            ippVo.setAddressLine1(person.getPersonData().getAddressLine1());
            ippVo.setCity(person.getPersonData().getCity());
            ippVo.setStateProvince(person.getPersonData().getStateProvince());
            List<Object> filteredPOList = new ArrayList<>();

            // This method is only called from the front end so Sponsor will be CustReg
            RefSponsor sponsor = refSponsorService.findByPK(RefSponsor.SPONSOR_ID_CUSTREG);
            ippVo.setSponsorId(sponsor.getSponsorId());
            ippVo.setSponsorCustReg(sponsor.isCustomerRegistration());
            ippVo.setSponsorActiveIppClient(sponsor.isIppClientActive());
            ippVo.setSponsorUsingFacilitySubList(sponsor.isClientUsingFacilitySublist());
            // Added for IAL2 transactions
            RefSponsorConfiguration optionEnabled = refSponsorConfigurationService
                    .getConfigRecord((int) sponsor.getSponsorId(), RefSponsorConfiguration.IAL2_REQUIRED);
            if (optionEnabled != null && optionEnabled.getValue() != null) {
                ippVo.setIal2Transaction(optionEnabled.getValue());
            } else {
                ippVo.setIal2Transaction("");
            }

            try {
                filteredPOList = verifyAddressService.getFilteredPOList(ippVo);
                CustomLogger.debug(this.getClass(), "PO Locations Count = " + filteredPOList.size());
            } catch (AMSException e) {
                CustomLogger.error(this.getClass(),
                        "Error occurred when getting PO Locations for sponsorUserId:" + user.getSponsorUserId(), e);
                user.setStatus(IPSConstants.STATUS_ERROR);
            }

            user.setFilteredPOList(filteredPOList);
            return user;
        }
        user.setStatus(IPSConstants.STATUS_ERROR);
        return user;
    }

    private Person findPerson(UserVo user) throws PhoneVerificationException {
        CustomLogger.enter(this.getClass());

        Person person = null;
        if (user != null) {
            String sponsor = null;

            if (IPSConstants.SPONSOR_CUSTREG.equalsIgnoreCase(user.getSponsor())) {
                sponsor = RefSponsor.SPONSOR_CUSTREG;
            }
 
            RefSponsor refsponsor = refSponsorDataService.findBySponsorName(sponsor);
           
            if (refsponsor != null) {
                person = personService.findFirstBySponsor(refsponsor, user.getSponsorUserId());
                
                if (person == null) {
                    CustomLogger.error(this.getClass(), String.format(LOG_RETRIEVE_PERSON_ERROR_FMT, user.getSponsorUserId()));
                    throw new PhoneVerificationException(EXCEPTION_NULL_PERSON_MSG);
                } else {
                    return person;
                }
            }
        }
        return person;
    }

    private String optIn(Person person, String loaSought, HighRiskAddressAttempt attempt,
            RpDeviceReputation deviceReputation) throws Exception {
        CustomLogger.enter(this.getClass());
		
        String status = IPSConstants.STATUS_ERROR;
        IppEvent ippEvent = new IppEvent();
        ippEvent.setPerson(person);
        ippEvent.setCreateDate(getCurrentTime());
        ippEvent.setInPersonProofingType(IPSConstants.IPP_TYPE_FACILITY);

        // ipp events not offered for hold mail so always ID
        ippEvent.setTransactionOriginId(refAppService.findByAppName(RefApp.INFORMED_DELIVERY));

        PersonData personData = person.getPersonData();

        try {
            ippEvent.setRefIppEventStatus(refIpEventStatusService.findByDescription(IPSConstants.IPP_STATUS_STARTED));
            PersonProofingStatus proofingStatus = person.getStatusForLoaSought(loaSought);
            proofingStatus.setRefRpStatus(refRpStatusService.findByDescription(IPSConstants.STATUS_IPP_OPT_IN));
            proofingStatus.setProofingStatusDatetime(getCurrentTime());
            ippEvent.setRefLoaLevel(proofingStatus.getRefLoaLevel());
            ippEvent = ippEventService.optIn(person, ippEvent, attempt, deviceReputation);
        } catch (SOAPException e) {
            CustomLogger.error(this.getClass(),
                    String.format(CANNOT_CALL_IDM_MSG_FMT, person.getPersonId()), e);
            throw e;
        } catch (IMSException e) {
            CustomLogger.error(this.getClass(), 
            		String.format(ERROR_IDM_INFO_MSG_FMT, person.getPersonId()), e);
            throw e;
        } catch (IOException e) {
            CustomLogger.error(this.getClass(), String.format(CANNOT_LOAD_PROP_MSG_FMT, person.getPersonId()), e);
            throw e;
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format(CANNOT_CREATE_IPP_EVENT_MSG_FMT, person.getSponsorUserId()), e);
            throw e;
        }

        if (ippEvent != null) {
            IppVo ippVo = populateIppVo(personData, ippEvent.getRecordLocator());

            if (!emailer.isLocalServer()) {
	            try {
	                ippEventService.sendIPPOptInEmail(ippVo, person, false, true, ippEvent.getCreateDate());
	            } catch (Exception e) {
	                CustomLogger.error(this.getClass(), String.format(IPP_EMAIL_SENT_ERROR_MSG_FMT, person.getSponsorUserId()), e);
	                throw e;
	            }
            }

            ippEmailSent(person, loaSought);
            status = IPSConstants.STATUS_IPP_EMAIL_SENT;
            return status;
        } else {
            return status;
        }
    }

    private IppVo populateIppVo(PersonData personData, String recordLocator) {
        CustomLogger.enter(this.getClass());
        IppVo ippVo = new IppVo();

        ippVo.setAddressLine1(personData.getAddressLine1());
        String address2 = personData.getAddressLine2();

        if (address2 == null) {
            ippVo.setAddressLine2("");
        } else {
            ippVo.setAddressLine2(", " + address2);
        }

        ippVo.setCity(personData.getCity());
        ippVo.setStateProvince(personData.getStateProvince());
        ippVo.setPostalCode(personData.getPostalCode());

        ippVo.setEmail(personData.getEmailAddress());
        ippVo.setRecordLocator(recordLocator);

        RefSponsor sponsor = refSponsorService.findByPK(personData.getPerson().getRefSponsor().getSponsorId());
        ippVo.setSponsorId(sponsor.getSponsorId());
        ippVo.setSponsorCustReg(sponsor.isCustReg());
        ippVo.setSponsorActiveIppClient(sponsor.isIppClientActive());
        ippVo.setSponsorUsingFacilitySubList(sponsor.isClientUsingFacilitySublist());
        // Added for IAL2 transactions
        RefSponsorConfiguration optionEnabled = refSponsorConfigurationService
                .getConfigRecord((int) sponsor.getSponsorId(), RefSponsorConfiguration.IAL2_REQUIRED);
        if (optionEnabled != null && optionEnabled.getValue() != null) {
            ippVo.setIal2Transaction(optionEnabled.getValue());
        } else {
            ippVo.setIal2Transaction("");
        }

        return ippVo;
    }

    public UserVo resendIPPEmail(UserVo user, List<LocationVo> locsVo, boolean poListError) throws Exception {
        CustomLogger.enter(this.getClass());
        Person person = null;
        try {
            person = findPerson(user);

            if (person == null) {
                CustomLogger.error(this.getClass(), String.format(LOG_RETRIEVE_PERSON_ERROR_FMT, user.getSponsorUserId()));
                throw new PhoneVerificationException(EXCEPTION_NULL_PERSON_MSG);
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format(LOG_RETRIEVE_PERSON_ERROR_FMT, user.getSponsorUserId()), e);
            user.setStatus(IPSConstants.STATUS_ERROR);
            return user;
        }

        List<IppEvent> ippEvent = person.getIppEvents();
        String recordLocator = null;
        Collections.sort(ippEvent, new SortIppByCreateDate());
        for (int x = ippEvent.size() - 1; x >= 0; x--) {
            if ((IPSConstants.IPP_STATUS_STARTED
            		.equalsIgnoreCase(ippEvent.get(x).getRefIppEventStatus().getEventStatusDescription())
              || IPSConstants.IPP_STATUS_RP_RETRY
                    .equalsIgnoreCase(ippEvent.get(x).getRefIppEventStatus().getEventStatusDescription()))
              && IPSConstants.IPP_TYPE_FACILITY
              		.equalsIgnoreCase(ippEvent.get(x).getInPersonProofingType())) {
                recordLocator = ippEvent.get(x).getRecordLocator();
                break;
            }

        }

        if (recordLocator != null) {
            IppVo ippVo = populateIppVo(person.getPersonData(), recordLocator);

            if (!emailer.isLocalServer()) {
	            try {
	                ippEventService.sendIPPOptInEmail(ippVo, person, false, false,
	                        ippEventService.findByRecordLocator(recordLocator).getCreateDate());
	            } catch (Exception e) {
	                CustomLogger.error(this.getClass(),
	                        "Error resending IPP email for sponsorUserId: " + user.getSponsorUserId(), e);
	                throw e;
	            }
            }
            
            ippEmailSent(person, user.getLoaSought());
            user.setStatus(IPSConstants.STATUS_IPP_EMAIL_SENT);
        } else {
            CustomLogger.error(this.getClass(),
                    "Cannot find IppEvent with status new for PersonID " + person.getPersonId());
            user.setStatus(IPSConstants.STATUS_ERROR);
        }
        return user;
    }

    public void ippEmailSent(Person person, String loaSought) {
        updateProofingStatus(RefRpStatus.RpStatus.In_person_email_sent.getValue(), person, loaSought);
    }

    public UserVo retryRemoteProofing(UserVo user) throws Exception {
        CustomLogger.enter(this.getClass());
        // Retrieve the current status from the database. If the user has failed
        // in-person proofing, they are not allowed to
        // try again for 30 days.
        Person updatedPerson = null;

        try {
            updatedPerson = findPerson(user);
            
            if (updatedPerson == null) {
                CustomLogger.error(this.getClass(),
                        "Person could not be found with sponsorUserId:" + user.getSponsorUserId());
                throw new PhoneVerificationException(EXCEPTION_NULL_PERSON_MSG);
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Person could not be found with sponsorUserId:" + user.getSponsorUserId(), e);
            throw e;
        }

        String loaSought = getLoaLevel(user, updatedPerson);
        PersonProofingStatus currentStatus = updatedPerson.getStatusForLoaSought(loaSought);

        // Do not reset to New if the status is failed IPP
        if (currentStatus.isIppFailed()) {
            user.setStatus(IPSConstants.STATUS_IPP_FAILED);
        } else {
            // SMG - removed logic to update the status to Retried remote proofing.
            // This will allow the user to proof with any barcode they received until they
            // pass proofing.
            user.setStatus(IPSConstants.STATUS_NEW_TO_IPS);
        }

        return user;
    }

    public UserVo sendNewActivationEmail(UserVo user) throws Exception {
        CustomLogger.enter(this.getClass());
        Person person = new Person();
        user.setStatus(IPSConstants.STATUS_ERROR);
        try {
            person = findPerson(user);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Can not retrieve person with sponsorUserId:" + user.getSponsorUserId(),
                    e);
            return user;
        }

        try {
            return getUpdatedUserVo(user, person);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Exception occurred in sendNewActivationEmail person with User SponsorUserId:"
                            + user.getSponsorUserId(),
                    e);
            throw e;
        }
    }

    private UserVo getUpdatedUserVo(UserVo user, Person person) throws Exception {
        if (user.isResendActivationEmail()) {
            user.setResendActivationEmail(false);

            // Call create user with activation
            try {
                String activationCode = Utils.getActivationCode();

                // Need to make sure the PIN is set correctly
                user.setPin(person != null ? person.getPin() : null);

                // Send Activation email
                sendCustomActivationEmail(person, activationCode, "");
                updateProofingStatus(RefRpStatus.RpStatus.Activation_email_sent.getValue(), person,
                        user.getLoaSought());
            } catch (Exception e) {
                CustomLogger.error(this.getClass(),
                        "Problem with finding remote proofing event for activation for sponsorUserId:"
                                + (person != null ? person.getPersonId() : ""),
                        e);
                throw e;
            }

            user.setStatus(IPSConstants.STATUS_ACTIVATION_EMAIL_SENT);
            return user;
        } else {
            user.setStatus(IPSConstants.STATUS_ACTIVATION_EMAIL_SENT);
            return user;
        }
    }

    /**
     * Check if the account has already been activated. Also, verify that the
     * current status is either remote proofing passed or in-person proofing passed.
     * Display error messages if needed.
     */
    private boolean proofingStatusValid(RefRpStatus proofingStatus) {
        CustomLogger.enter(this.getClass());
        if (proofingStatus.isRpPassed() || proofingStatus.isIppPassed() || proofingStatus.isActivationEmailSent()
                || proofingStatus.isLoaAchieved()) {
            CustomLogger.debug(this.getClass(),
                    "Proofing status: " + proofingStatus.getStatusDescription() + " is valid");
            return true;
        } else {
            CustomLogger.debug(this.getClass(),
                    "Proofing status: " + proofingStatus.getStatusDescription() + " is NOT valid");
            return false;
        }
    }

    @Override
    public String displayConfirmationNumber(UserVo user) {
        CustomLogger.enter(this.getClass());
        Person person = new Person();
        try {
            RefSponsor refSponsor = refSponsorDataService.findBySponsorName(user.getSponsor());
            person = personService.findFirstBySponsor(refSponsor, user.getSponsorUserId());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Cannot retrieve person for User SponsorUserId: " + user.getSponsorUserId(), e);
        }
        String confirmationNumber = null;
        try {
            RefIppEventStatus ippEventStatus = refIpEventStatusService
                    .findByDescription(IPSConstants.IPP_STATUS_FAILED);
            IppEvent event = ippEventService.findConfirmationNumber(ippEventStatus, person);
            if (event != null) {
                confirmationNumber = event.getConfirmationNumber();
            } else {
                throw new PhoneVerificationException(EXCEPTION_NULL_PERSON_MSG);
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Cannot retrieve IPP Event for sponsorUserId: " + user.getSponsorUserId(), e);
        }

        return confirmationNumber;
    }

    /**
     * Update proofing status for reproofing. Also, update record with latest email
     * address.
     *
     * @param sponsorUserId
     * @param lastUpdateDate
     * @param emailAddress
     */
    public void checkIfReproofing(String sponsorUserId, PersonVo personVo, String loaSought) {
        CustomLogger.enter(this.getClass());
        RefSponsor sponsor = new RefSponsor();
        Person person = new Person();
        try {
            sponsor = refSponsorDataService.findBySponsorName(IPSConstants.SPONSOR_CUSTREG);
            person = personService.findFirstBySponsor(sponsor, sponsorUserId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Cannot retrieve Person with User SponsorUserId: " + sponsorUserId + ": ", e);
        }

        // check if user has Rp Passed, or Activation Email Sent
        if (person != null) {
        	CustomLogger.debug(this.getClass(), "Remote proofing status: User has previous proofing data.");

            // Update user's email address
            PersonData personData = person.getPersonData();

            if (!personData.getEmailAddress().equalsIgnoreCase(personVo.getEmailAddress())) {
            	CustomLogger.debug(this.getClass(), "Remote proofing status: User has changed the email address.");
                personData.setEmailAddress(personVo.getEmailAddress());
                personData.setUpdateDate(new Date());
                personDataService.update(personData);
            }

            PersonProofingStatus proofingStatus = person.getStatusForLoaSought(loaSought);
            // If the proofing status was not found at this point, then the user is trying
            // to achieve a new level that they
            // don't already have so there is no need to change their status (in other
            // words, they are not re-proofing)
            if (proofingStatus != null) {
                try {
                    // Removed the try/catch block here - an exception at this point cannot be
                    // swallowed!

                    // Null out the date/time that the user acknowledged terms and conditions
                    person.setTermsConditionsAckDateTime(null);

                    // Status must be changed to Reproofing for all levels of assurance
                    // The status will only be reset if the proofing status datetime is before the
                    // lastUpdateDate
                    updateToReproofing(person, personVo);
                } catch (Exception e) {
                    CustomLogger.error(this.getClass(),
                            "Cannot update status of sponsorUserId: " + sponsorUserId + " to indicate reproofing.", e);
                }
            }
        }
    }

    private boolean updateToReproofing(Person person, PersonVo personVo) {
        CustomLogger.enter(this.getClass());
        RefRpStatus reproofingStatus = refRpStatusService.findByDescription(IPSConstants.STATUS_REPROOFING);
          
        boolean statusReset = person.resetToReproofingStatus(reproofingStatus, person, personVo);
        // If the status was reset, then LOA achieved must be reset
        if (statusReset) {
        	CustomLogger.debug(this.getClass(), "Remote proofing status: User status is reset to 'No Level LOA'.");
            RefLoaLevel noLevel = refLoaLevelService.findByCode(RefLoaLevel.NO_LEVEL_CODE);
            person.setAchievedLoaLevel(noLevel);
            person.setLoaAchievedDateTime(null);
            
            if (!personVo.isResetProofingStatus()) {
                personVo.setResetProofingStatus(statusReset);
            }
        }
        
        personService.update(person);

        return statusReset;
    }

    /**
     * Retrieves a scheduled appointment for the user.
     * 
     * @param user
     * @param appt
     */
    public AppointmentVo findScheduledAppointment(UserVo user) {
        CustomLogger.enter(this.getClass());
        RefIppEventStatus ippEventStatus = refIpEventStatusService.findByDescription(IPSConstants.IPP_STATUS_STARTED);
        IppEvent appointment = ippEventService.findAppointment(ippEventStatus, user.getUserId());
        return createAppointmentVo(appointment);
    }

    private AppointmentVo createAppointmentVo(IppEvent appointment) {
        CustomLogger.enter(this.getClass());
        AppointmentVo vo = new AppointmentVo();
        vo.setAddress1(appointment.getAddress1());
        vo.setAddress2(appointment.getAddress2());
        vo.setCity(appointment.getCity());
        vo.setScheduledDate(appointment.getAppointmentDate());
        vo.setScheduledTime(appointment.getAppointmentTime());
        vo.setState(appointment.getRefState().getStateCode());
        vo.setZip5(appointment.getZip5());
        vo.setZip4(appointment.getZip4());
        vo.setScheduled(true);
        vo.setEventId(appointment.getIppEventId());
        vo.setCanceled(false);
        vo.setRecordLocator(appointment.getRecordLocator());
        return vo;
    }

    /**
     * Cancels a scheduled appointment. The user's proofing status is changed to
     * "Opted-in for In-person Proofing at Residence" and the appointment record is
     * deleted.
     * 
     * @param user
     * @param appt
     */
    public void cancelAppointment(UserVo user, AppointmentVo appt) {
        CustomLogger.enter(this.getClass());
        Person person = personService.findByPK(user.getUserId());

        RefRpStatus optedInResidence = refRpStatusService.findByDescription(IPSConstants.IPP_RESIDENCE_OPT_IN);
        PersonProofingStatus proofingStatus = person.getStatusForLoaSought(user.getLoaSought());
        proofingStatus.setRefRpStatus(optedInResidence);
        Date updateDate = getCurrentTime();
        proofingStatus.setProofingStatusDatetime(updateDate);
        IppEvent event = ippEventService.findByPK(appt.getEventId());
        ippEventService.cancelAppointment(person, event);
    }

    public UserVo optInToIppAtResidence(UserVo user, AppointmentVo appointment) throws Exception {
        CustomLogger.enter(this.getClass());
        Person person = null;
        try {
            person = findPerson(user);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), String.format(LOG_PERSON_GET_ERROR_FMT, user.getUserId()), e);
            user.setStatus(IPSConstants.STATUS_ERROR);
            return user;
        }

        if (person != null) {
            try {
                user.setStatus(optInAtResidence(person, appointment, user.getLoaSought()));
            } catch (Exception e) {
                CustomLogger.error(this.getClass(),
                        "Error on opt-in to residence IPP for sponsorUserId: " + user.getSponsorUserId(), e);
                throw e;
            }

            user.setEmail(person.getPersonData().getEmailAddress());
            
            RefSponsorConfiguration config = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
                    RefSponsorConfiguration.ASSERT_TO_CUSTREG);
            if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
                // Assert to CustReg
            	RpProofingSession session = rpProofingSessionService.findRpSessionByPerson(person);
            	
            	if (session != null) {
                    EntRegUserLOAAssertion loaAssertion = getAssertionForOptInIpp(person, user, session);
                    EntRegUserLOAInPersonResults ippResults = new EntRegUserLOAInPersonResults(user.getSponsorUserId(), null);
                    ippResults.setOptInDate(new Date());
        
                    custRegService.assertOptInIpp(loaAssertion, ippResults);
                } else {
                    CustomLogger.error(this.getClass(),
                            "finding RpSession By Person returned null for sponsorUserId:" + person.getSponsorUserId());
                }
             }
             return user;
        }
        user.setStatus(IPSConstants.STATUS_ERROR);
        return user;
    }

    private String optInAtResidence(Person person, AppointmentVo appointment, String loaSought) throws Exception {
        CustomLogger.enter(this.getClass());
        String status = IPSConstants.STATUS_ERROR;

        IppEvent ippEvent = new IppEvent();
        ippEvent.setPerson(person);
        ippEvent.setCreateDate(getCurrentTime());
        ippEvent.setInPersonProofingType(IPSConstants.IPP_TYPE_RESIDENCE);
        ippEvent.setAppointmentDate(appointment.getScheduledDate());
        ippEvent.setAppointmentTime(appointment.getScheduledTime());
        ippEvent.setAddress1(appointment.getAddress1());
        ippEvent.setAddress2(appointment.getAddress2());
        ippEvent.setCity(appointment.getCity());
        ippEvent.setZip5(appointment.getZip5());
        ippEvent.setZip4(appointment.getZip4());
        ippEvent.setDeliveryPoint(appointment.getDeliveryPoint());
        ippEvent.setCarrierRoute(appointment.getCarrierRoute());
        ippEvent.setLatitude(appointment.getLatitude());
        ippEvent.setLongitude(appointment.getLongitude());

        try {
            ippEvent.setRefState(refStateService.getByStateCode(appointment.getState()));
            ippEvent.setRefIppEventStatus(refIpEventStatusService.findByDescription(IPSConstants.IPP_STATUS_STARTED));
            PersonProofingStatus proofingStatus = person.getStatusForLoaSought(loaSought);
            proofingStatus.setRefRpStatus(
                    refRpStatusService.findByDescription(IPSConstants.STATUS_IPP_AT_RESIDENCE_SCHEDULED));
            proofingStatus.setProofingStatusDatetime(getCurrentTime());
            ippEvent.setRefLoaLevel(proofingStatus.getRefLoaLevel());
            ippEvent = ippEventService.optIn(person, ippEvent, null, null);
        } catch (SOAPException e) {
            CustomLogger.error(this.getClass(),
                    "Can not call IDM for sponsorUserId:" + person.getSponsorUserId() + " to create IPP user.", e);
            throw e;
        } catch (IMSException e) {
            CustomLogger.error(this.getClass(), "Error info coming from IDM for sponsorUserId:"
                    + person.getSponsorUserId() + " to create IPP user.", e);
            throw e;
        } catch (IOException e) {
            CustomLogger.error(this.getClass(), "Can not load properties file when calling IDM for sponsorUserId:"
                    + person.getSponsorUserId() + " to create IPP user", e);
            throw e;
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Cannot create IppEvent for sponsorUserId: " + person.getSponsorUserId() + ": ", e);
            throw e;
        }
        if (ippEvent != null) {
            GenerateBarcodeUtil barcode = new GenerateBarcodeUtil();
            String barcodeFile = barcode.generateBarcode(ippEvent.getRecordLocator());
            CustomLogger.debug(this.getClass(), "Barcode Path: " + barcodeFile);
            // send email
            String emailTo = person.getPersonData().getEmailAddress();
            CustomLogger.debug(this.getClass(), "Email to: " + emailTo);
            try {
                appointment.setAddress1(person.getPersonData().getAddressLine1());
                String address2 = person.getPersonData().getAddressLine2();
                if (address2 == null) {
                    appointment.setAddress2("");
                } else {
                    appointment.setAddress2(", " + address2);
                }
                appointment.setCity(person.getPersonData().getCity());
                appointment.setState(person.getPersonData().getStateProvince());
                appointment.setZip4(person.getPersonData().getPostalCode());
                emailer.sendIppEmail(barcodeFile, emailTo, EmailText.getHTMLTextIPPResidence(appointment, false),
                        EmailText.IPP_SUBJECT, person.getRefSponsor().getSponsorId());
                // delete barcode file
                File file = new File(barcodeFile);
                file.delete();
                CustomLogger.debug(this.getClass(), "Barcode Deleted!");
                return status;
            } catch (Exception e) {
                CustomLogger.error(this.getClass(),
                        "Error sending IPP email for sponsorUserId:" + person.getSponsorUserId(), e);
                status = IPSConstants.IPP_RESIDENCE_SCHEDULED;// CHECK THIS!!!!!!!!!!!!!!
                return status;
            }
        } else {
            return status;
        }
    }

    /**
     * Retrieves the address on file for the user.
     * 
     * @param user
     * @param appt
     */
    public AppointmentVo findAddressOnFile(UserVo user) {
        CustomLogger.enter(this.getClass());
        RefSponsor refSponsor = refSponsorDataService.findBySponsorName(user.getSponsor());

        Person person = personService.findFirstBySponsor(refSponsor, user.getSponsorUserId());
        return createAppointmentVo(person);
    }

    private AppointmentVo createAppointmentVo(Person person) {
        CustomLogger.enter(this.getClass());
        PersonData personData = person.getPersonData();
        AppointmentVo vo = new AppointmentVo();
        vo.setAddress1(personData.getAddressLine1());
        vo.setAddress2(personData.getAddressLine2());
        vo.setCity(personData.getCity());
        vo.setState(personData.getStateProvince());
        vo.setZip5(personData.getPostalCode().substring(0, 5));
        if (personData.getPostalCode().length() == 10) {
            vo.setZip4(personData.getPostalCode().substring(6, 10));
        }
        vo.setScheduled(false);
        vo.setCanceled(false);
        return vo;
    }

    public IppVo getIppPageUserInfo(UserVo user) {
        CustomLogger.enter(this.getClass());
        IppVo ippVo = new IppVo();
        Person person = new Person();
        try {
            RefSponsor refSponsor = refSponsorDataService.findBySponsorName(IPSConstants.SPONSOR_CUSTREG);
            ippVo.setSponsorId(refSponsor.getSponsorId());
            ippVo.setSponsorCustReg(refSponsor.isCustReg());
            ippVo.setSponsorActiveIppClient(refSponsor.isIppClientActive());
            ippVo.setSponsorUsingFacilitySubList(refSponsor.isClientUsingFacilitySublist());

            // Retrieve the expiration days for the sponsor
            RefSponsorConfiguration config = refSponsorConfigurationService
                    .getConfigRecord((int) refSponsor.getSponsorId(), RefSponsorConfiguration.IPP_OPTIN_EXPIRATION);

            if (config != null) {
                ippVo.setExpirationDays(config.getValue());
            }

            person = personService.findFirstBySponsor(refSponsor, user.getSponsorUserId());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "An error occurred trying to find sponsorUserId: " + (user != null? user.getSponsorUserId() : "null"), e);
            ippVo.setStatus(IPSConstants.STATUS_ERROR);
            return ippVo;
        }

        List<IppEvent> ippEvent = person.getIppEvents();
        String recordLocator = null;
        Collections.sort(ippEvent, new SortIppByCreateDate());
        for (int x = ippEvent.size() - 1; x >= 0; x--) {
            if ((IPSConstants.IPP_STATUS_STARTED
                    .equalsIgnoreCase(ippEvent.get(x).getRefIppEventStatus().getEventStatusDescription())
              || IPSConstants.IPP_STATUS_RP_RETRY
                	.equalsIgnoreCase(ippEvent.get(x).getRefIppEventStatus().getEventStatusDescription()))
              && IPSConstants.IPP_TYPE_FACILITY.equalsIgnoreCase(ippEvent.get(x).getInPersonProofingType())) {
                recordLocator = ippEvent.get(x).getRecordLocator();
                break;
            }
        }

        ippVo.setEmail(person.getPersonData().getEmailAddress());
        ippVo.setAddressLine1(person.getPersonData().getAddressLine1());
        ippVo.setAddressLine2(person.getPersonData().getAddressLine2());
        ippVo.setCity(person.getPersonData().getCity());
        ippVo.setStateProvince(person.getPersonData().getStateProvince());
        ippVo.setPostalCode(person.getPersonData().getPostalCode());

        if (recordLocator != null) {
            // Generate Barcode Image
            GenerateBarcodeUtil barcode = new GenerateBarcodeUtil();
            ippVo.setBarcodeImagePath(barcode.generateBarcode(recordLocator));
            ippVo.setBarcodeFileName(recordLocator + ".JPEG");
            ippVo.setRecordLocator(recordLocator);
        }

        return ippVo;
    }

    /**
     * This method returns the user's PIN
     * 
     * @param personVo
     * @return
     */
    public UserVo getPin(String userId) {
        CustomLogger.enter(this.getClass());
        UserVo user = new UserVo();
        String pin = null;
        try {
            pin = personService.getPIN(userId);
            if (pin != null) {
                pin = pin.substring(0, 4);
            }
            user.setPin(pin);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error occurred in retrieving PIN for userId: " + userId, e);
            user.setStatus(IPSConstants.STATUS_ERROR);
            return user;
        }

        return user;
    }

    /**
     * Sends the Activation email without calling IDM.
     * 
     * @param person
     * @throws Exception
     */
    public void sendCustomActivationEmail(Person person, String activationCode, String confirmationNumber)
            throws Exception {
        CustomLogger.enter(this.getClass());
        CustomLogger.info(this.getClass(), "Sending custom Activation email for: " + person.getSponsorUserId());
        emailer.sendHtmlEmail(new String[] { person.getPersonData().getEmailAddress() },
                EmailText.getActivationText(activationCode, confirmationNumber),
                "Activate Your United States Postal Service Identity Verification", true, null);
        CustomLogger.info(this.getClass(), "Activation email successfully sent for: " + person.getSponsorUserId());
    }

    /**
     * Asserts successful and failed OTP Proofing to Cust Reg for Passcode match.
     * 
     * @param status
     */
    @Override
    public void passcodeOnlinePhoneVerification(Person person, PersonVo personVo, CustRegAssertionParamVo assertionVo) {

        CustomLogger.info(this.getClass(),
                String.format("ProofingServiceImpl.passcodeOnlinePhoneVerification(status:%s, sponsorUserId:%s, "
                + "passcodeDecision:%s, otpMatchQuality:%s, productStatus:%s, totalSubmitAttempts:%s, "
                + "totalRenewAttempts:%s", assertionVo.getRpStatusCode(), person.getSponsorUserId(),
                assertionVo.getVerificationDecision(), assertionVo.getVerificationMatchQuality(),
                assertionVo.getProductStatus(), assertionVo.getTotalSubmitAttempts(), assertionVo.getTotalRenewAttempts()));

        RpProofingSession session = rpProofingSessionService.findRpSessionByPerson(person);
        
        if (session != null) {
        	String callingAppName = "";
        	if (personVo.isWebServiceCall()) {
        		callingAppName = personVo.getTransactionOriginAppName();
        	}
        	else {
        		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                        .getRequest();
            	callingAppName = (String) request.getSession().getAttribute(IPSConstants.CALLING_APP_NAME_KEY);
        	}
			
            String sessionID = Long.toString(session.getProofingSessionId());

            PersonProofingStatus proofingStatus = person.getStatusForLoaSought(assertionVo.getLoaSought());

            EntRegUserLOAAssertion loaAssertion = getAssertionForRPOTPLoaPasscodeStatus(person.getSponsorUserId(), sessionID, 
            		proofingStatus.getRefLoaLevel().getLoaLevel(), assertionVo);

            EntRegUserLOAEIDPasscodeResults passcodeResults = new EntRegUserLOAEIDPasscodeResults();
            passcodeResults.setPasscodeDecision(assertionVo.getVerificationDecision());
            passcodeResults.setProductStatus(assertionVo.getProductStatus());
            passcodeResults.setPasscodeSentYYYYMMDDHHMMSS(formatDate(new Date(assertionVo.getVerificationSentDatetime())));
            passcodeResults.setPasscodeDecisionYYYYMMDDHHMMSS(formatDate(new Date(assertionVo.getVerificationDecisionDatetime())));
            passcodeResults.setOtpMatchQuality(assertionVo.getVerificationMatchQuality());
            passcodeResults.setTotalSubmitAttempts(assertionVo.getTotalSubmitAttempts());
            passcodeResults.setTotalRenewAttempts(assertionVo.getTotalRenewAttempts());

            EntRegUserLOAEIDLockouts lockoutWindow = new EntRegUserLOAEIDLockouts(assertionVo.getAttemptsAllowed()
            		, assertionVo.getAttemptsMade(), assertionVo.getAttemptsPeriod());

            custRegService.assertRPOTPLoaPasscodeStatus(loaAssertion, passcodeResults, lockoutWindow, callingAppName);
         } else {
            CustomLogger.error(this.getClass(),
                    "find RpSession By Person returned null for sponsorUserId:" + person.getSponsorUserId());
        }
    }

    /**
     * Asserts successful and failed SMFA Proofing to Cust Reg for Link tap.
     * 
     * @param status
     */
    @Override
    public void smfaOnlinePhoneVerification(Person person, CustRegAssertionParamVo assertionVo) {

        CustomLogger.info(this.getClass(),
                "ProofingServiceImpl.smfaOnlinePhoneVerification(status: " + assertionVo.getRpStatusCode() + ", sponsorUserId: "
                + person.getSponsorUserId() + ", passcodeDecision: " + assertionVo.getVerificationDecision() + ", otpMatchQuality: "
                + assertionVo.getVerificationMatchQuality() + ", productStatus: " + assertionVo.getProductStatus() + ", totalSubmitAttempts: "
                + assertionVo.getTotalSubmitAttempts() + ", totalRenewAttempts: " + assertionVo.getTotalRenewAttempts() + ")");
        
        RpProofingSession session = rpProofingSessionService.findRpSessionByPerson(person);
        
        if (session != null) {
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                        .getRequest();

            String callingAppName = (String) request.getSession().getAttribute(IPSConstants.CALLING_APP_NAME_KEY);
            String sessionID = Long.toString(session.getProofingSessionId());

            PersonProofingStatus proofingStatus = person.getStatusForLoaSought(assertionVo.getLoaSought());

            EntRegUserLOAAssertion loaAssertion = getAssertionForRPDITSMFALoaSMFAStatus(person.getSponsorUserId(),
                    sessionID, proofingStatus.getRefLoaLevel().getLoaLevel(), assertionVo);

            EntRegUserLOASMFAResults userLOASMFAResults = new EntRegUserLOASMFAResults();
            userLOASMFAResults.setSmfaDecision(assertionVo.getVerificationDecision());
            userLOASMFAResults.setProductStatus(assertionVo.getProductStatus());
            userLOASMFAResults.setSmfaSentDate(new Date(assertionVo.getVerificationSentDatetime()));
            userLOASMFAResults.setSmfaDecisionDate(new Date(assertionVo.getVerificationDecisionDatetime()));
            userLOASMFAResults.setPath(assertionVo.getPath());
            userLOASMFAResults.setTotalAttempts(assertionVo.getTotalSubmitAttempts());
            userLOASMFAResults.setMobilePhone(assertionVo.getMobilePhone());
            userLOASMFAResults.setSessionId(assertionVo.getSessionId());
            userLOASMFAResults.setTransactionId(assertionVo.getTransactionId());

            EntRegUserLOAEIDLockouts lockoutWindow = new EntRegUserLOAEIDLockouts(assertionVo.getAttemptsAllowed()
            		, assertionVo.getAttemptsMade(), assertionVo.getAttemptsPeriod());

			custRegService.assertRPSMFALoaSMFAStatus(loaAssertion, userLOASMFAResults, lockoutWindow, callingAppName);
        } else {
            CustomLogger.error(this.getClass(),
                    "find RpSession By Person returned null for sponsorUserId:" + person.getSponsorUserId());
        }
    }

    /**
     * Asserts successful and failed Boku Proofing to Cust Reg for Link tap.
     * 
     * @param status
     */
    @Override
    public void bokuOnlinePhoneVerification(Person person, CustRegAssertionParamVo assertionVo) {

        CustomLogger.info(this.getClass(),
                "ProofingServiceImpl.smfaOnlinePhoneVerification(status: " + assertionVo.getRpStatusCode() + ", sponsorUserId: "
                + person.getSponsorUserId() + ", passcodeDecision: " + assertionVo.getVerificationDecision() + ", otpMatchQuality: "
                + assertionVo.getVerificationMatchQuality() + ", productStatus: " + assertionVo.getProductStatus() + ", totalSubmitAttempts: "
                + assertionVo.getTotalSubmitAttempts() + ", totalRenewAttempts: " + assertionVo.getTotalRenewAttempts() + ")");
        
        RpProofingSession session = rpProofingSessionService.findRpSessionByPerson(person);
        
        if (session != null) {
            RefSponsorConfiguration config = refSponsorConfigurationService.getConfigRecord((int) person.getRefSponsor().getSponsorId(),
                    RefSponsorConfiguration.ASSERT_TO_CUSTREG);
           
            if (VALUE_TRUE.equalsIgnoreCase(config.getValue())) {
                HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                            .getRequest();
    
                String callingAppName = (String) request.getSession().getAttribute(IPSConstants.CALLING_APP_NAME_KEY);
                String sessionID = Long.toString(session.getProofingSessionId());
    
                PersonProofingStatus proofingStatus = person.getStatusForLoaSought(assertionVo.getLoaSought());
    
                EntRegUserLOAAssertion loaAssertion = getAssertionForRPDITSMFALoaSMFAStatus(person.getSponsorUserId(),
                        sessionID, proofingStatus.getRefLoaLevel().getLoaLevel(), assertionVo);
    
                EntRegUserLOASMFAResults userLOASMFAResults = new EntRegUserLOASMFAResults();
                userLOASMFAResults.setSmfaDecision(assertionVo.getVerificationDecision());
                userLOASMFAResults.setProductStatus(assertionVo.getProductStatus());
                userLOASMFAResults.setSmfaSentDate(new Date(assertionVo.getVerificationSentDatetime()));
                userLOASMFAResults.setSmfaDecisionDate(new Date(assertionVo.getVerificationDecisionDatetime()));
                userLOASMFAResults.setPath(assertionVo.getPath());
                userLOASMFAResults.setTotalAttempts(assertionVo.getTotalSubmitAttempts());
                userLOASMFAResults.setMobilePhone(assertionVo.getMobilePhone());
                userLOASMFAResults.setSessionId(assertionVo.getSessionId());
                userLOASMFAResults.setTransactionId(assertionVo.getTransactionId());
    
                EntRegUserLOAEIDLockouts lockoutWindow = new EntRegUserLOAEIDLockouts(assertionVo.getAttemptsAllowed()
                		, assertionVo.getAttemptsMade(), assertionVo.getAttemptsPeriod());
    
				custRegService.assertRPSMFALoaSMFAStatus(loaAssertion, userLOASMFAResults, lockoutWindow, callingAppName);
            }
        } else {
            CustomLogger.error(this.getClass(),
                    "find RpSession By Person returned null for sponsorUserId:" + person.getSponsorUserId());
        }
    }
    
    @Override
    public void phoneVerification(Person person, CustRegAssertionParamVo assertionVo) {

    	CustomLogger.info(this.getClass(), "ProofingServiceImpl.phoneVerification(phoneDecision: " + assertionVo.getVerificationDecision() + ", sponsorUserId: "
                + person.getSponsorUserId() + ", phoneMatchQuality: " + assertionVo.getVerificationMatchQuality() + ", phoneMatchLevel: "
                + assertionVo.getVerificationMatchLevel() + ", loaName:" + assertionVo.getLoaName() + ", proofingStatus:" + assertionVo.getProofingStatus() 
                + ", phoneServiceStatus: " + assertionVo.getProductStatus() + ", attemptsAllowed: " + assertionVo.getAttemptsAllowed() 
                + ", attemptsMade: " + assertionVo.getAttemptsMade() + ", attemptsPeriod: " + assertionVo.getAttemptsPeriod() + ")");
        
        RpProofingSession session = rpProofingSessionService.findRpSessionByPerson(person);
        
        if (session != null) {
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                        .getRequest();
            
            String callingAppName = (String) request.getSession().getAttribute(IPSConstants.CALLING_APP_NAME_KEY);
            String sessionID = Long.toString(session.getProofingSessionId());

            PersonProofingStatus proofingStatusLevel = person.getStatusForLoaSought(assertionVo.getLoaSought());

            EntRegUserLOAAssertion loaAssertion = getAssertionForRPOTPLoaPhoneStatus(person.getSponsorUserId(),
                    sessionID, proofingStatusLevel.getRefLoaLevel().getLoaLevel(), assertionVo);

            String mobilePhoneStr = assertionVo.getMobilePhone();
            String competionYYYYMMDDHHMMSS = formatDate(new Date(assertionVo.getVerificationDecisionDatetime()));
            String initiationYYYYMMDDHHMMSS = formatDate(new Date(assertionVo.getVerificationSentDatetime()));
            String transactionKeyStr = assertionVo.getTransactionKey();
            String sessionInfoStr = String.valueOf(session.getProofingSessionId());

            EntRegUserLOAEIDPhoneResults phoneResults = new EntRegUserLOAEIDPhoneResults();
            phoneResults.setPhoneDecision(assertionVo.getVerificationDecision());
            phoneResults.setInitiationYYYYMMDDHHMMSS(initiationYYYYMMDDHHMMSS);
            phoneResults.setCompetionYYYYMMDDHHMMSS(competionYYYYMMDDHHMMSS);
            phoneResults.setMobilePhone(mobilePhoneStr);
            phoneResults.setPhoneMatchQuality(assertionVo.getVerificationMatchQuality());
            phoneResults.setPhoneMatchLevel(assertionVo.getVerificationMatchLevel());
            phoneResults.setPhoneServiceStatus(assertionVo.getProductStatus());
            phoneResults.setAvsErrorsYYYYMMDDHHMMSS(assertionVo.getAvsErrorsDatetime());
            phoneResults.setTransactionKey(transactionKeyStr);
            phoneResults.setSessionInfo(sessionInfoStr);

            EntRegUserLOAEIDLockouts lockoutWindow = new EntRegUserLOAEIDLockouts();
            lockoutWindow.setAttemptsAllowed(assertionVo.getAttemptsAllowed());
            lockoutWindow.setAttemptsInWindow(assertionVo.getAttemptsMade());
            lockoutWindow.setAttemptsWindowHrs(assertionVo.getAttemptsPeriod());
            EntRegUserLOAEIDLockoutInfo lockoutInfo = new EntRegUserLOAEIDLockoutInfo(lockoutWindow, null, null);

            custRegService.assertRPOTPLoaPhoneStatus(loaAssertion, phoneResults, lockoutInfo, callingAppName);
         } else {
            CustomLogger.error(this.getClass(),
                    "finding RpSession By Person returned null for sponsorUserId:" + person.getSponsorUserId());
        }
    }

    @Override
    public void ditVerification(Person person, CustRegAssertionParamVo assertionVo) {

    	CustomLogger.info(this.getClass(), "ProofingServiceImpl.ditVerification(phoneDecision: " + assertionVo.getVerificationDecision() + ", sponsorUserId: "
                + person.getSponsorUserId() + ", phoneTrust: " + assertionVo.getPhoneTrust() + ", identityTrust: "
                + assertionVo.getIdentityTrust() + ", addressTrust: " + assertionVo.getAddressTrust() + ", attemptsAllowed: "
                + assertionVo.getAttemptsAllowed() + ", attemptsMade: " + assertionVo.getAttemptsMade() + ", attemptsPeriod: " + assertionVo.getAttemptsPeriod() + ")");
        
        RpProofingSession session = rpProofingSessionService.findRpSessionByPerson(person);
        
        if (session != null) {
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                        .getRequest();
            
            String callingAppName = (String) request.getSession().getAttribute(IPSConstants.CALLING_APP_NAME_KEY);
            String sessionID = Long.toString(session.getProofingSessionId());

            PersonProofingStatus proofingStatusLevel = person.getStatusForLoaSought(assertionVo.getLoaSought());

            EntRegUserLOAAssertion loaAssertion = getAssertionForRPDITSMFALoaDITStatus(person.getSponsorUserId(),
                    sessionID, assertionVo.getProofingStatus(), proofingStatusLevel.getRefLoaLevel().getLoaLevel()
                    , assertionVo.getTotalIPSAttempts(), assertionVo.getTotalEIDAttempts());

            String mobilePhoneStr = assertionVo.getMobilePhone();
            String transactionKeyStr = assertionVo.getTransactionKey();
  
            EntRegUserLOADITPhoneResults userLOADITPhoneResults = new EntRegUserLOADITPhoneResults();

            userLOADITPhoneResults.setPhoneDecision(assertionVo.getVerificationDecision());
            userLOADITPhoneResults.setInitiationDate(new Date(assertionVo.getVerificationSentDatetime()));
            userLOADITPhoneResults.setCompletionDate(new Date(assertionVo.getVerificationDecisionDatetime()));
            userLOADITPhoneResults.setMobilePhone(mobilePhoneStr);
            userLOADITPhoneResults.setPhoneTrust(assertionVo.getPhoneTrust());
            userLOADITPhoneResults.setIdentityTrust(assertionVo.getIdentityTrust());
            userLOADITPhoneResults.setAddressTrust(assertionVo.getAddressTrust());
            userLOADITPhoneResults.setTransactionId(transactionKeyStr);

            EntRegUserLOAEIDLockouts lockoutWindow = new EntRegUserLOAEIDLockouts();
            lockoutWindow.setAttemptsAllowed(assertionVo.getAttemptsAllowed());
            lockoutWindow.setAttemptsInWindow(assertionVo.getAttemptsMade());
            lockoutWindow.setAttemptsWindowHrs(assertionVo.getAttemptsPeriod());
            EntRegUserLOAEIDLockoutInfo lockoutInfo = new EntRegUserLOAEIDLockoutInfo(lockoutWindow, null, null);

			custRegService.assertRPDITLoaDITStatus(loaAssertion, userLOADITPhoneResults , lockoutInfo, callingAppName);
        } else {
            CustomLogger.error(this.getClass(),
                    "finding RpSession By Person returned null for sponsorUserId:" + person.getSponsorUserId());
        }
    }
    
    @Override
    public void removePII(Person person) {
		RefSponsor sponsor = person.getRefSponsor();

		if (!sponsor.isCustReg()) {
			personDataService.delete(person.getPersonData());
		}
	}

    private EntRegUserLOAAssertion getAssertionForOptInIpp(Person person, UserVo user, RpProofingSession session) {
        CustomLogger.enter(this.getClass());
 
        PersonProofingStatus proofingStatus = person.getStatusForLoaSought(user.getLoaSought());
        String loaLevel = proofingStatus.getRefLoaLevel().getLoaLevel();
        String loaId = IPSConstants.LOA_15.equalsIgnoreCase(loaLevel) ? IPSConstants.LOA_IP_515
                : IPSConstants.LOA_IP_ID;

        return getEntRegUserLOAAssertion(user.getSponsorUserId(), IPSConstants.LOA_IP_NAME, loaId,
                IPSConstants.LOA_FLAG_NOT_ACHIEVED, Long.toString(session.getProofingSessionId()),
                IPSConstants.PROOFING_STATUS_IN_PROGRESS);
    }

    private EntRegUserLOAAssertion getAssertionForRPOTPLoaPasscodeStatus(String userId, String sessionID,
    	            String loaLevel, CustRegAssertionParamVo assertionVo) {

        CustomLogger.enter(this.getClass());
        String loaFlag = assertionVo.getLoaFlag();
        String loaName = assertionVo.getLoaName(); 
        String proofingStatus = assertionVo.getProofingStatus();
        String loaId = IPSConstants.LOA_15.equalsIgnoreCase(loaLevel) ? String.valueOf(IPSConstants.LOA_RP_525)
                : String.valueOf(IPSConstants.LOA_RP_520);
        
        if (loaName == null) {
        	 loaName = IPSConstants.LOA_RP_OTP_NAME;	
        }

        if (proofingStatus == null) {
        	proofingStatus = IPSConstants.PROOFING_STATUS_COMPLETE;
        }
   
        EntRegUserLOAAssertion loaAssertion = getEntRegUserLOAAssertion(userId, loaName, loaId,
                loaFlag, sessionID, proofingStatus);

        loaAssertion.setActivationDateTime(new Date());

        return loaAssertion;
    }

    private EntRegUserLOAAssertion getAssertionForRPOTPLoaPhoneStatus(String userId, String sessionID, String loaLevel,  
    		CustRegAssertionParamVo assertionVo) {

        CustomLogger.enter(this.getClass());
        String proofingStatus = assertionVo.getProofingStatus();
        String loaName = assertionVo.getLoaName(); 
        long totalIPSAttempts = assertionVo.getTotalIPSAttempts(); 
        long totalEIDAttempts = assertionVo.getTotalEIDAttempts();
        
        String loaId = IPSConstants.LOA_15.equalsIgnoreCase(loaLevel) ? String.valueOf(IPSConstants.LOA_RP_525)
                : String.valueOf(IPSConstants.LOA_RP_520);

        if (loaName == null) {
        	loaName = IPSConstants.LOA_RP_OTP_NAME;
        }
        
        EntRegUserLOAAssertion loaAssertion = getEntRegUserLOAAssertion(userId, loaName, loaId, IPSConstants.LOA_FLAG_NOT_ACHIEVED, sessionID, proofingStatus);
        loaAssertion.setTotalIPSAttempts(String.valueOf(totalIPSAttempts));
        loaAssertion.setTotalEIDAttempts(String.valueOf(totalEIDAttempts));

        return loaAssertion;
    }

    private EntRegUserLOAAssertion getAssertionForRPDITSMFALoaSMFAStatus(String userId, String sessionID,
            String loaLevel, CustRegAssertionParamVo assertionVo) {
        CustomLogger.enter(this.getClass());
        String loaId = IPSConstants.LOA_15.equalsIgnoreCase(loaLevel) ? String.valueOf(IPSConstants.LOA_RP_526)
                : String.valueOf(IPSConstants.LOA_RP_520);
        String loaFlag = assertionVo.getLoaFlag();
        String loaName = assertionVo.getLoaName();
        
        EntRegUserLOAAssertion loaAssertion = getEntRegUserLOAAssertion(userId, loaName, loaId,
                loaFlag, sessionID, IPSConstants.PROOFING_STATUS_COMPLETE);
        loaAssertion.setActivationDateTime(new Date());

        return loaAssertion;
    }

    private EntRegUserLOAAssertion getAssertionForRPDITSMFALoaDITStatus(String userId, String sessionID,
            String proofingStatus, String loaLevel, long totalIPSAttempts, long totalEIDAttempts) {
        CustomLogger.enter(this.getClass());
        String loaId = IPSConstants.LOA_15.equalsIgnoreCase(loaLevel) ? String.valueOf(IPSConstants.LOA_RP_526)
                : String.valueOf(IPSConstants.LOA_RP_520);

        EntRegUserLOAAssertion loaAssertion = getEntRegUserLOAAssertion(userId, IPSConstants.LOA_RP_EQ_DIT_NAME, loaId,
                IPSConstants.LOA_FLAG_NOT_ACHIEVED, sessionID, proofingStatus);
        loaAssertion.setTotalIPSAttempts(String.valueOf(totalIPSAttempts));
        loaAssertion.setTotalEIDAttempts(String.valueOf(totalEIDAttempts));

        return loaAssertion;
    }

    private EntRegUserLOAAssertion getEntRegUserLOAAssertion(String userId, String loaName, String loaId,
            String loaFlag, String proofingId, String proofingStatus) {
        CustomLogger.enter(this.getClass());
        EntRegUserLOAAssertion loaAssertion = new EntRegUserLOAAssertion();
        loaAssertion.setUserId(userId);
        loaAssertion.setLoaId(loaId);
        loaAssertion.setLoaFlag(loaFlag);
        loaAssertion.setProofingId(proofingId);
        loaAssertion.setProofingStatus(proofingStatus);
        loaAssertion.setLoaName(loaName);

        return loaAssertion;
    }

    private String formatDate(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        return format.format(date);
    }

    // TODO These Comparators should be moved into their own package/classes in the
    // future
    /**
     * This is used to override the compare method for IppEvent without overriding
     * the actual class method.
     */
    class SortIppByCreateDate implements Comparator<IppEvent> {

        @Override
        public int compare(IppEvent o1, IppEvent o2) {
            if (o1.getCreateDate().getTime() - o2.getCreateDate().getTime() > 0) {
                return 1;
            }
            if (o1.getCreateDate().getTime() - o2.getCreateDate().getTime() < 0) {
                return -1;
            }
            return 0;
        }
    }

    /**
     * This is used to override the compare method for RpEvent without overriding
     * the actual class method.
     */
    class SortRpByCreateDate implements Comparator<RpEvent> {

        @Override
        public int compare(RpEvent o1, RpEvent o2) {
            if (o1.getCreateDate().getTime() - o2.getCreateDate().getTime() > 0) {
                return 1;
            } else if (o1.getCreateDate().getTime() - o2.getCreateDate().getTime() < 0) {
                return -1;
            } else {
                return 0;
            }
        }
    }

}
