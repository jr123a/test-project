package com.ips.proofing;

import com.ibm.json.java.JSONObject;
import com.ips.entity.Person;
import com.ips.entity.RpEvent;
import com.ips.entity.RpExperianDecisionResult;
import com.ips.entity.RpSupplierToken;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.ExperianResultVo;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationResponse;
import com.ips.persistence.experianRest.request.CrossCoreRequestModel;

public interface ExperianService {

    PhoneVerificationResponse verifyPhone(Person person, PersonVo personVo, ExperianResultVo resultVo) throws IPSException, PhoneVerificationException;
    JSONObject getJsonWebTokenResponse(ExperianResultVo resultVo) throws IPSException;
	JSONObject getAuthenticatePhoneResponse(PersonVo personVo);
	CrossCoreRequestModel prepareCrossCoreRequest(PersonVo personVo, ExperianResultVo resultVo) throws IPSException;
	JSONObject getCrossCoreResponse(PersonVo personVo, CrossCoreRequestModel ccRequest, ExperianResultVo resultVo, RpEvent rpEvent) throws IPSException, PhoneVerificationException;
	
	void callCrossCoreWorkflow(Person person, PersonVo personVo, RpEvent rpEvent, CrossCoreRequestModel ccRequest, ExperianResultVo resultVo) throws IPSException, PhoneVerificationException;
	void processCrossCoreResponse(Person person, PersonVo personVo, RpEvent rpEvent, JSONObject ccResponseJsonObj, ExperianResultVo resultVo) throws IPSException, PhoneVerificationException;
    void extractCrossCoreResponseData(JSONObject ccResponseJsonObj, ExperianResultVo resultVo);
	void evaluatePhoneVerificationDecision(Person person, PersonVo personVo, RpEvent rpEvent, JSONObject ccResponseJsonObj, ExperianResultVo resultVo) throws IPSException, PhoneVerificationException;
	void initializeExperianResultVo(PersonVo personVo, ExperianResultVo resultVo);
	void extractResponseDecisionData(JSONObject ccResponseJsonObj, ExperianResultVo resultVo);
	void setExperianUserData(ExperianResultVo resultVo, long sponsorId, String requestType);
	void saveAccessToken(RpSupplierToken existingToken, String accessToken);

    RpExperianDecisionResult retrievedRpExperianDecisionResult(Person person, ExperianResultVo resultVo) throws IPSException, PhoneVerificationException;
	String getExperianAccessToken(PersonVo personVo, RpEvent rpEvent, ExperianResultVo resultVo) throws IPSException;
	String generateClientReferenceId(PersonVo personVo);

	boolean authenticateBokuUrlSuccessful(PersonVo personVo);
	public boolean silentAuthenticationSuccessful(Person person, PersonVo personVo, ExperianResultVo resultVo)
			throws IPSException, PhoneVerificationException;
	boolean confirmPasscodeSuccessful(Person person, PersonVo personVo, RpEvent event)
			throws IPSException, PhoneVerificationException;
	boolean resendPasscodeSuccessful(Person person, PersonVo personVo) throws IPSException, PhoneVerificationException;
}
