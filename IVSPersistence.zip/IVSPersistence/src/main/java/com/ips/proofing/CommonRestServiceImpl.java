package com.ips.proofing;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.wink.client.ClientConfig;
import org.apache.wink.client.ClientRuntimeException;
import org.apache.wink.client.ClientWebException;
import org.apache.wink.client.Resource;
import org.apache.wink.client.RestClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.equifax.common.AdditionalErrorDetailModel;
import com.equifax.dit.request.InitiateDITRequestModel;
import com.equifax.dit.response.FaultDetailModel;
import com.equifax.dit.response.FaultModel;
import com.equifax.dit.response.InitiateDITResponseModel;
import com.equifax.smfa.request.InitiateSMFARequestModel;
import com.equifax.smfa.request.StatusSMFARequestModel;
import com.equifax.smfa.response.InitiateSMFAResponseModel;
import com.equifax.smfa.response.StatusSMFAResponseModel;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ips.common.common.AliasVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.Utils;
import com.ips.entity.LookupCodesEnv;
import com.ips.entity.RefApp;
import com.ips.entity.RefIdValidationVendor;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpSupplierToken;
import com.ips.entity.VendorToken;
import com.ips.exception.IPSException;
import com.ips.persistence.common.ExperianResultVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.NameValueVo;
import com.ips.persistence.common.OAuthResponse;
import com.ips.persistence.common.UAgentInfo;
import com.ips.persistence.experianRest.request.JsonWebTokenRequestModel;
import com.ips.service.LookupCodesEnvService;
import com.ips.service.RefAppService;
import com.ips.service.RefIdValidationVendorService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RpSupplierTokenService;
import com.ips.service.VendorTokenService;

@Service("commonRestService")
public class CommonRestServiceImpl implements Serializable, CommonRestService {

    private static final long serialVersionUID = 1L;

    @Autowired
	private LookupCodesEnvService lookupCodesEnvService; 
    @Autowired
    private RefAppService refAppService;
    @Autowired
	private RefIdValidationVendorService refIdValidationVendorService;
    @Autowired
    private RefSponsorConfigurationService refSponsorConfigService;
    @Autowired
	private RpSupplierTokenService rpSupplierTokenService;
    @Autowired
   	private VendorTokenService vendorTokenService;
    
    private static final String EQUIFAX_DIT_OAUTH_TOKEN_BODY = "client_id=%s&client_secret=%s&grant_type=%s&scope=%s";
    private static final String RESOURCE_STREAM_PATH = "/ips.properties";
    public static final String HEADER_AUTHORIZATION = "Authorization";
    public static final String HEADER_CONTENT_TYPE = "Content_Type";    
    public static final String HEADER_CORRELATION = "Correlation";  
    public static final String HEADER_ORIGIN = "Origin"; 
    private static final String HEADER_EFX_SESSION_ID = "efx-sessionId";
    private static final String HEADER_ACCEPT = "Accept";
    private static final String HEADER_USER_AGENT = "User-Agent";
    public static final String BEARER_TOKEN_FMT = "Bearer %s";
    private static final String EQUIFAX_DIT_INITIATE_ENDPT = "com.ipsweb.EquifaxDITInitiateEndpoint";
    private static final String EQUIFAX_SMFA_INITIATE_ENDPT = "com.ipsweb.EquifaxSMFAInitiateEndpoint";
    private static final String EQUIFAX_SMFA_STATUS_ENDPT = "com.ipsweb.EquifaxSMFAStatusEndpoint";
    public static final String USE_EXP_JWT_ALT_CREDENTIAL = "Use.Exp.Jwt.Alt.Credential";
    public static final String USE_EXP_XCORE_ALT_CREDENTIAL = "Use.Exp.Xcore.Alt.Credential";
    public static final String USE_EXP_JWT_ALT_ENDPOINT = "Use.Exp.Jwt.Alt.Endpoint";
    public static final String USE_EXP_XCORE_ALT_ENDPOINT = "Use.Exp.Xcore.Alt.Endpoint";
    public static final String USE_EXP_UAT_ENV = "Use.Exp.Uat.Env";
    public static final String CAPTURE_EXP_RESPONSE = "Capture.Exp.Response";
    public static final String TOKEN_TYPE_EXP_JWT_ALT_CRED = "EXP_JWT_ALT_CRED";
    public static final String TOKEN_TYPE_EXP_XCORE_ALT_CRED = "EXP_XCORE_ALT_CRED";
    public static final String TOKEN_TYPE_EXP_JWT_ALT_ENDPT = "EXP_JWT_ALT_ENDPT";
    public static final String TOKEN_TYPE_EXP_XCORE_ALT_ENDPT = "EXP_XCORE_ALT_ENDPT";
    private static final String KEY_EFX_ERROR_CODE = "efxErrorCode";
    private static final String KEY_DESCRIPTION = "description";
    private static final String KEY_DEVELOPER_MESSAGE = "developerMessage";
    private static final String KEY_ERROR_CODE = "errorCode";
    private static final String KEY_ERROR_TYPE = "errorType";
    private static final String KEY_CORRELATION_ID = "correlationId";
    private static final String KEY_ERROR = "error";
    private static final String KEY_MESSAGE = "message";
    private static final String KEY_TRANSACTION_ID = "transactionId";
    private static final String KEY_TIMESTAMP = "timestamp";
    private static final String KEY_FAULT = "fault";
    private static final String KEY_FAULT_STRING = "faultstring";
    private static final String KEY_DETAIL = "detail";  
	public  static final String ADDRESS_COUNTRY_US = "US";
	
    @Override
    public String getOAuthToken(String propertyName, String clientIdAlias, String clientSecretAlias, String scope, String grantType,  
    			String tokenType, boolean obtainNewToken) throws IPSException, IOException {
        CustomLogger.enter(this.getClass());
        
        VendorToken token = vendorTokenService.findByType(tokenType);
        if (!obtainNewToken) {
	    	// Use existing token if still valid
	 		if (token != null && !token.hasExpired()) {
	 			return token.getAccessToken();
	 		}
	 		else {
	 			obtainNewToken = true;
	 		}
        }		
 		
 		if (obtainNewToken) {
 			OAuthResponse response = sendOAuthRequest(propertyName, clientIdAlias, clientSecretAlias, scope, grantType);
 			
 			if (response == null) {
 				return "";
 			}
 			
 			String accessToken = response.getAccess_token();
 			Timestamp expirationTime = Timestamp.valueOf((LocalDateTime.now().plusSeconds(response.getExpires_in_secs())));
 			saveToken(token, accessToken, tokenType, expirationTime);
 			return accessToken;
 		}
 		
 		return "";
 	}
    
    @Override
    public JSONObject getJsonWebTokenResponse(String webServiceURL, List<NameValueVo> headerList, ExperianResultVo resultVo) {
       	CustomLogger.debug(this.getClass(), "Process check: CommonRest Service > call getJsonWebTokenResponse(webServiceURL,headerList,resultVo).");

 		JsonWebTokenRequestModel tokenRequest;
 		Gson g = new GsonBuilder().disableHtmlEscaping().create(); 

		String userName = resultVo.getJwtUserName();
		String userKey = resultVo.getJwtUserKey();

		try {
			tokenRequest = getJsonWebTokenRequest(userName, userKey);
		} catch (IPSException e) {
			JSONObject errorObj = getCommonErrorResponse("500", "IPSException occurs in calling getJsonWebTokenRequest method.");
          	
        	String errorJson = g.toJson(errorObj);
         	CustomLogger.error(this.getClass(), "ClientRuntimeException occurred in getCrossCoreResponse:" + errorJson, e);  
        	return errorObj;     
		}
    	JSONObject tokenResponseJsonObj = new JSONObject();
 		Resource resource = getClientResource(webServiceURL);
		
		
		String errorMessage = "";
		String requestJsonStr = "";
		 
		try {	   
		    requestJsonStr = g.toJson(tokenRequest);
		    
		    for(NameValueVo nameValue : headerList) {
		    	resource.header(nameValue.getName(), nameValue.getStringValue());
		    }
			 		    
		    tokenResponseJsonObj = JSONObject.parse(resource.contentType(MediaType.APPLICATION_JSON)
		    		.post(String.class, requestJsonStr));	
		}
		catch (ClientWebException cwEx) {
			String responseStatus = "null";
			String responseMessage = "null";
			if (cwEx != null && cwEx.getResponse() != null) {
				responseStatus = String.valueOf(cwEx.getResponse().getStatusCode());
				responseMessage = cwEx.getResponse().getMessage();
			}
	            
         	errorMessage = "ClientWebException occurs in calling getJsonWebTokenResponse method. ResponseStatus:" 
         			+ responseStatus + ", ResponseMessage:" + responseMessage + ".";
         	tokenResponseJsonObj = getCommonErrorResponse("500", errorMessage);
         	
        	String tokenResponseJson = g.toJson(tokenResponseJsonObj);
          	CustomLogger.error(this.getClass(), "ClientWebException occurred in getJsonWebTokenResponse > requestJsonStr:" + requestJsonStr);  
          	CustomLogger.error(this.getClass(), errorMessage + "::" + tokenResponseJson, cwEx);           	
        	return tokenResponseJsonObj;         	
    	}
 		catch (ClientRuntimeException crEx) {
			String message = "null";
			if (crEx != null && crEx.getMessage() != null) {
				message = crEx.getMessage();
			}
 			
        	errorMessage = "ClientRuntimeException occurs in calling getJsonWebTokenResponse method. Message:" + message + ".";
        	tokenResponseJsonObj = getCommonErrorResponse("500", errorMessage);

        	String tokenResponseJson = g.toJson(tokenResponseJsonObj);
           	CustomLogger.error(this.getClass(), "ClientRuntimeException occurred in getJsonWebTokenResponse > requestJsonStr:" + requestJsonStr);  
         	CustomLogger.error(this.getClass(), errorMessage + "::" + tokenResponseJson, crEx);  
        	return tokenResponseJsonObj;         	
        } catch (Exception ex) {
        	String message = "null";
        	if (ex.getMessage() != null) {
				message = ex.getMessage();
			}
			
        	errorMessage = "General Exception occurs in calling getJsonWebTokenResponse method. Message:" + message + ".";
        	tokenResponseJsonObj = getCommonErrorResponse("500", errorMessage);

        	String tokenResponseJson = g.toJson(tokenResponseJsonObj);
        	CustomLogger.error(this.getClass(), "General Exception occurred in getJsonWebTokenResponse > requestJsonStr:" + requestJsonStr);  
         	CustomLogger.error(this.getClass(), errorMessage + "::" + tokenResponseJson, ex);  
        	return tokenResponseJsonObj;  
         } 
		
		return tokenResponseJsonObj;
	}
    
    @Override
    public String getJsonWebTokenHttpClientResponse(String webServiceURL, List<NameValueVo> headerList, ExperianResultVo resultVo) {
 		CustomLogger.enter(this.getClass());

    	String responseJsonStr = "";
    	String responseMessage = "";
    	boolean hasResponse = false;

    	JsonWebTokenRequestModel tokenRequest;
 		Gson g = new GsonBuilder().disableHtmlEscaping().create(); 
 		
 		String userName = !Utils.isEmptyString(resultVo.getJwtUserName()) ?
 				resultVo.getJwtUserName() : getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_JWT_ACCT_NAME);
		String userKey = !Utils.isEmptyString(resultVo.getJwtUserKey()) ?
 				resultVo.getJwtUserKey() : getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_JWT_ACCT_CODE);

		RefSponsorConfiguration sponsorConfig = refSponsorConfigService.getConfigRecord((int) RefSponsor.SPONSOR_ID_CUSTREG, "Use.Alt.Credential");
		
		if (sponsorConfig != null && IPSConstants.CONFIG_VALUE_Y.equalsIgnoreCase(sponsorConfig.getValue())) {
			RpSupplierToken altUserId = rpSupplierTokenService.findByTokenCode("EXP_JWT_NAME");
			RpSupplierToken jwtUserKey = rpSupplierTokenService.findByTokenCode("EXP_JWT_KEY");
			
			if (altUserId != null) {
				userName = altUserId.getAccessToken();
			}
			if (jwtUserKey != null) {
				userKey = jwtUserKey.getAccessToken();
			}
		}
		
		try {
			tokenRequest = getJsonWebTokenRequest(userName, userKey);
		} catch (IPSException e) {
			JSONObject errorObj = getCommonErrorResponse("500", "IPSException occurs in calling getJsonWebTokenRequest method.");
          	
        	String errorJson = g.toJson(errorObj);
         	CustomLogger.error(this.getClass(), "ClientRuntimeException occurred in getCrossCoreResponse:" + errorJson, e);  
        	return errorJson;     
		}

        try {
        	String requestJsonStr = g.toJson(tokenRequest);
        	StringEntity entity = new StringEntity(requestJsonStr);
        	
        	HttpPost httpPost = new HttpPost(webServiceURL);  
 	        httpPost.setEntity(entity);             
 	        httpPost.setHeader("Content-Type", MediaType.APPLICATION_JSON); 
 	        httpPost.setHeader("X-User-Domain", "usps.gov");
 	        httpPost.setHeader("X-Correlation-Id", "ccb82bd2-4438-45bf-9817-9a964d2e08fa");   
 	        httpPost.setHeader("Content-type", "application/json"); 
	        
 	        HttpHost proxy = new HttpHost(IPSConstants.USPS_PROXY_HOST, Integer.parseInt(IPSConstants.USPS_PROXY_PORT));
 	        HttpClient httpclient = HttpClientBuilder.create().setProxy(proxy).build();
 	        HttpResponse response = httpclient.execute(httpPost); 

 	        if (response != null) {
 	        	HttpEntity httpEntity = response.getEntity();

 	        	if (httpEntity != null) {
  	        		responseJsonStr = g.toJson(httpEntity);
 	        	}
 	        }

        	hasResponse = true;
        } catch (Exception e) {
        	responseMessage = "Exception occurs in getting resource response"; 
          } 
        
        if (!hasResponse) {
        	JSONObject defaultRespObj = new JSONObject();
        	defaultRespObj.put("responseMessage", responseMessage);  
        	responseJsonStr = g.toJson(defaultRespObj);
          	CustomLogger.debug(this.getClass(), "Default Response JSON::" + responseJsonStr); 
        }
        return responseJsonStr;
	}
     
	/**** CREATE AUTHENTICATION TOKEN WEB SERVICE REQUEST ****/

    public JsonWebTokenRequestModel getJsonWebTokenRequest(String userName, String userKey) throws IPSException {

		JsonWebTokenRequestModel tokenRequest = new JsonWebTokenRequestModel();

		CustomLogger.debug(this.getClass(), "ipsUserName:" + userName + ", JWT ipsUserKey:" + userKey);
		String clientId = getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_JWT_CLIENT_ID);
		String clientSecret = getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_JWT_CLIENT_SECRET);
		
		tokenRequest.setUsername(userName);
		tokenRequest.setPassword(userKey);
		tokenRequest.setClient_id(clientId);
		tokenRequest.setClient_secret(clientSecret);
		
		return tokenRequest;
	}
    
    @Override
    public OAuthResponse sendOAuthRequest(String propertyName, String clientIdAlias, String clientSecretAlias, String scope, String grantType) throws IPSException, IOException {
        CustomLogger.enter(this.getClass());

 		OAuthResponse oAuthResponse = new OAuthResponse();
 		Gson g = new Gson();
		String errorResponseStr = "";
		String webServiceURL = getIpsPropertyValue(propertyName);
		
		Resource resource = getClientResource(webServiceURL);
		CustomLogger.debug(this.getClass(), "Equifax OAuth Web Service URL: " + webServiceURL);

		JSONObject oAuthResponseJson = null;

		String oAuthRequestStr = getOAuthRequestText(clientIdAlias, clientSecretAlias, scope, grantType);
		CustomLogger.debug(this.getClass(), "Equifax OAuth Web Service Request: " + oAuthRequestStr);

		String efxErrorCode = "";
		String errorDescription = "";
			
		try {
			oAuthResponseJson = JSONObject.parse(resource.contentType(MediaType.APPLICATION_FORM_URLENCODED).post(String.class, oAuthRequestStr));
        } catch (ClientWebException e) {
        	JSONObject entity = JSONObject.parse(e.getResponse().getEntity(String.class));
        	efxErrorCode = (String) entity.get(KEY_EFX_ERROR_CODE);
        	errorDescription = (String) entity.get(KEY_DESCRIPTION);
        	errorResponseStr = g.toJson(entity);
        	CustomLogger.error(this.getClass(), "ClientWebException occured in calling Oauth Token web service. Error response:" + errorResponseStr, e); 
        } 
		catch (ClientRuntimeException e) {
        	CustomLogger.error(this.getClass(), "ClientRuntimeException occured in calling Oauth Token web service. ClientRuntimeException Message:" + e.getMessage(), e);  
        	efxErrorCode = "500";
        	errorDescription = "Internal server error. ClientRuntimeException occured in calling Oauth Token web service.";
        } catch (Exception e) {
        	CustomLogger.error(this.getClass(), "Generic Exception occured in calling Oauth Token web service. Exception Message:" + e.getMessage(), e);  
         	efxErrorCode = "500";
        	errorDescription = "Internal server error. Exception occured in calling Oauth Token web service.";
        } 

		if (oAuthResponseJson != null) {
			String responseStr = g.toJson(oAuthResponseJson);
			CustomLogger.debug(this.getClass(), "OAuth Response Json:" + responseStr);
			oAuthResponse = g.fromJson(responseStr, OAuthResponse.class);
		}
		else {
			oAuthResponse.setEfxErrorCode(efxErrorCode);
			oAuthResponse.setDescription(errorDescription);
		}
 		
 		return oAuthResponse;
 	}
 	
    @Override
    public String getOAuthRequestText(String clientIdAlias, String clientSecretAlias, String scope, String grantType) throws IPSException {
        CustomLogger.enter(this.getClass());

        String clientIdInfo = getJ2CInfo(clientIdAlias).getPassword();
        CustomLogger.debug(this.getClass(), "Equifax OAuth clientIdInfo: " + clientIdInfo);

        String clientSecretInfo = getJ2CInfo(clientSecretAlias).getPassword();
        CustomLogger.debug(this.getClass(), "Equifax OAuth clientSecretInfo: " + clientSecretInfo);

        String oAuthRequestJsonStr = String.format(EQUIFAX_DIT_OAUTH_TOKEN_BODY, clientIdInfo, clientSecretInfo, grantType, scope);
        CustomLogger.debug(this.getClass(), "Equifax OAuth Request String: " + oAuthRequestJsonStr);
        
    	return oAuthRequestJsonStr;
 	}
    
    @Override
    public void saveToken(VendorToken token, String accessToken, String type, Timestamp expirationTime) {
        CustomLogger.enter(this.getClass());

    	// Save token to db
 		Timestamp createDate = new Timestamp(new Date().getTime());
 		if (token == null) {
 			RefIdValidationVendor vendor = refIdValidationVendorService.findByPK(RefIdValidationVendor.EQUIFAX_VENDOR_ID);
 			
 			VendorToken newToken = new VendorToken();
 			newToken.setAccessToken(accessToken);
 			newToken.setVendor(vendor);
 			newToken.setTokenType(type);
 			newToken.setExpirationTime(expirationTime);
 			newToken.setCreateDate(createDate);
 			
 			vendorTokenService.save(newToken);
 		}
 		else {
 			// update token
 			token.setAccessToken(accessToken);
 			token.setExpirationTime(expirationTime);
 			token.setUpdateDate(createDate);
 			
 			vendorTokenService.update(token);
 		}
 	}
    
    /*** Equifax DIT + SMFA **/
    
    @Override
	public InitiateDITResponseModel sendInitiateDITRequest(String bearerToken, InitiateDITRequestModel initiateRequest) {
    	CustomLogger.enter(this.getClass());

	
		InitiateDITResponseModel initiateResponse = null;
		Gson g = new Gson();

		try {
			String webServiceURL = getIpsPropertyValue(EQUIFAX_DIT_INITIATE_ENDPT);
			String authorization = String.format(BEARER_TOKEN_FMT, bearerToken);
			String requestJsonStr = g.toJson(initiateRequest);
			
			CustomLogger.debug(this.getClass(), "Equifax DIT Web Service URL:" + webServiceURL);  
			CustomLogger.debug(this.getClass(), "Equifax DIT Web Service Authorization:" + authorization);  
			CustomLogger.debug(this.getClass(), "Equifax DIT Web Service Request Body:" + requestJsonStr);  
			
			Resource resource = getClientResource(webServiceURL);
			JSONObject responseJson = null;
			
			responseJson = JSONObject.parse(resource.contentType(MediaType.APPLICATION_JSON)
						.header(HEADER_AUTHORIZATION, authorization)
						.header(HEADER_ACCEPT, "*/*")
						.post(String.class, requestJsonStr));

            if (responseJson != null) {
            	initiateResponse = g.fromJson(responseJson.toString(), InitiateDITResponseModel.class);
            	initiateResponse.setStatus(200);
            }
	    }
		catch (ClientWebException e) {
				JSONObject entity = null;
				try {
					entity = JSONObject.parse(e.getResponse().getEntity(String.class));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
	        	String errorResponseStr = g.toJson(entity);
	        	int status = e.getResponse().getStatusCode();
	        	String errorMessage = e.getResponse().getMessage();
	        	AdditionalErrorDetailModel errorDetail = new AdditionalErrorDetailModel();
	        	
	        	if (entity != null) {
		        	errorDetail.setDeveloperMessage((String) entity.get(KEY_DEVELOPER_MESSAGE));
		        	errorDetail.setErrorCode((String) entity.get(KEY_ERROR_CODE));
		        	errorDetail.setErrorType((String) entity.get(KEY_ERROR_TYPE));
	        	}
	        	
	        	initiateResponse = new InitiateDITResponseModel();
	        	initiateResponse.setAdditionalErrorDetails(errorDetail);
	        	
	        	if (entity != null) {
		        	initiateResponse.setCorrelationId((String) entity.get(KEY_CORRELATION_ID));
		        	initiateResponse.setError((String) entity.get(KEY_ERROR));
		        	initiateResponse.setMessage(((String) entity.get(KEY_MESSAGE)) + ". " +  errorMessage);
		        	initiateResponse.setTransactionId((String) entity.get(KEY_TRANSACTION_ID));
		        	initiateResponse.setTimestamp((String) entity.get(KEY_TIMESTAMP));
	        	}
	        	
	        	initiateResponse.setStatus(status);

	        	if (entity != null) {
		        	JSONObject faultJson = (JSONObject) entity.get(KEY_FAULT);
		        	
		        	if (faultJson != null) {
		        		String faultstring = (String) faultJson.get(KEY_FAULT_STRING);
		        		JSONObject faultDetail =  (JSONObject) faultJson.get(KEY_DETAIL);
		        		
		        		FaultModel faultModel = new FaultModel();
		        		faultModel.setFaultstring(faultstring);
		        		
		        		if (faultDetail != null) {
		        			String errorcode = (String) faultJson.get(KEY_ERROR_CODE);
		        			FaultDetailModel faultDetailModel = new FaultDetailModel();
		        			faultDetailModel.setErrorcode(errorcode);
		        			faultModel.setDetail(faultDetailModel);
		        		}
		        	}
	        	}

				CustomLogger.debug(this.getClass(), "ClientWebException occurred during Equifax DIT web service call.");  
				CustomLogger.debug(this.getClass(), "ClientWebException error response body:" + errorResponseStr);  
  	    }
		catch (ClientRuntimeException e) {
        	CustomLogger.error(this.getClass(), "ClientRuntimeException occurred in getting Resource response from the web service:" + e.getMessage(), e);  
        } catch (Exception e) {
         	CustomLogger.error(this.getClass(), "Generic Exception occurred in getting Resource response from the web service:" + e.getMessage(), e);  
        } 
		
		return initiateResponse;
	}
    
    @Override
   	public InitiateSMFAResponseModel sendInitiateSMFARequest(String bearerToken, InitiateSMFARequestModel initiateRequest) throws IOException {
       	CustomLogger.enter(this.getClass());
   	
   		InitiateSMFAResponseModel initiateResponse = null;
   		Gson g = new Gson();

   		try {
   			String webServiceURL = getIpsPropertyValue(EQUIFAX_SMFA_INITIATE_ENDPT);
   			String authorization = String.format(BEARER_TOKEN_FMT, bearerToken);
   			String requestJsonStr = g.toJson(initiateRequest);
   			
   			CustomLogger.debug(this.getClass(), "Equifax SMFA Initiate Web Service URL:" + webServiceURL);  
   			CustomLogger.debug(this.getClass(), "Equifax SMFA Initiate Web Service Authorization:" + authorization);  
   			CustomLogger.debug(this.getClass(), "Equifax SMFA Initiate Web Service Request Body:" + requestJsonStr);  
   			
			JSONObject responseJson = null;
   			Resource resource = getClientResource(webServiceURL);
  			
   			responseJson = JSONObject.parse(resource.contentType(MediaType.APPLICATION_JSON)
					.header(HEADER_AUTHORIZATION, authorization)
					.header(HEADER_ACCEPT, "*/*")
						.post(String.class, requestJsonStr));
   			
   			if (responseJson != null) {
            	initiateResponse = g.fromJson(responseJson.toString(), InitiateSMFAResponseModel.class);
            }
     	}
   		catch (ClientWebException e) {
				JSONObject entity = JSONObject.parse(e.getResponse().getEntity(String.class));
   	        	String errorResponseStr = g.toJson(entity);
 	        	
   	        	initiateResponse = new InitiateSMFAResponseModel();
	        	JSONObject additionalErrorDetails = (JSONObject) entity.get("additionalErrorDetails");
	        	
	        	if (additionalErrorDetails != null) {
		        	String developerMessage = (String) additionalErrorDetails.get(KEY_DEVELOPER_MESSAGE);
		        	String errorType = (String) additionalErrorDetails.get(KEY_ERROR_TYPE);
		        	
	 	        	AdditionalErrorDetailModel errorDetail = new AdditionalErrorDetailModel();
	 	        	errorDetail.setDeveloperMessage(developerMessage);
	 	        	errorDetail.setErrorType(errorType);
	 	        	initiateResponse.setAdditionalErrorDetails(errorDetail);
	        	}
 	        	
 	        	initiateResponse.setTransactionId((String) entity.get(KEY_TRANSACTION_ID));

	        	String description = (String) entity.get(KEY_DESCRIPTION);
	        	if (description != null) {
	        		initiateResponse.setDescription(description);
	        	}

	        	String efxErrorCode = (String) entity.get(KEY_EFX_ERROR_CODE);
	        	if (efxErrorCode != null) {
	        		initiateResponse.setEfxErrorCode(efxErrorCode);
	        	}
	        	
   				CustomLogger.debug(this.getClass(), "ClientWebException occurred during Equifax SMFA Initiate web service call.");  
    			CustomLogger.debug(this.getClass(), "ClientWebException Equifax SMFA Initiate error response body:" + errorResponseStr);  
  
     	    }
   		catch (ClientRuntimeException e) {
           	CustomLogger.error(this.getClass(), "ClientRuntimeException occurred in getting Resource response from the Equifax SMFA Initiate web service:" + e.getMessage(), e);  
           } catch (Exception e) {
            	CustomLogger.error(this.getClass(), "Generic Exception occurred in getting Resource response from the Equifax SMFA Initiate web service:" + e.getMessage(), e);  
           } 
   		
   		return initiateResponse;
   	}
    
     @Override
   	public StatusSMFAResponseModel sendStatusSMFARequest(String bearerToken, String smfaSessionId, StatusSMFARequestModel statusRequest) throws IOException {
       	CustomLogger.enter(this.getClass());
   	
   		StatusSMFAResponseModel statusResponse = null;
   		Gson g = new Gson();

   		try {
   			String webServiceURL = getIpsPropertyValue(EQUIFAX_SMFA_STATUS_ENDPT);
   			String authorization = String.format(BEARER_TOKEN_FMT, bearerToken);
   			String requestJsonStr = g.toJson(statusRequest);
   			
   			CustomLogger.debug(this.getClass(), "Equifax SMFA Status Web Service URL:" + webServiceURL);  
			CustomLogger.debug(this.getClass(), "Equifax SMFA Status Web Service Authorization:" + authorization);  
			CustomLogger.debug(this.getClass(), "Equifax SMFA Status Web Service SessionId:" + smfaSessionId);  
   			CustomLogger.debug(this.getClass(), "Equifax SMFA Status Web Service Request Body:" + requestJsonStr);  
 
   			JSONObject responseJson = null;
   			Resource resource = getClientResource(webServiceURL);
   			
   			responseJson = JSONObject.parse(resource.contentType(MediaType.APPLICATION_JSON)
					.header(HEADER_AUTHORIZATION, authorization)
					.header(HEADER_EFX_SESSION_ID, smfaSessionId)  
					.header(HEADER_ACCEPT, "*/*")
						.post(String.class, requestJsonStr));
   			
   			if (responseJson != null) {
   				statusResponse = g.fromJson(responseJson.toString(), StatusSMFAResponseModel.class);
            }
    	}
   		catch (ClientWebException e) {
        	statusResponse = new StatusSMFAResponseModel();
			JSONObject entity = JSONObject.parse(e.getResponse().getEntity(String.class));
			
			if (entity == null) {
	       		statusResponse.setDescription("Validate SMFA Link request is empty.");
				CustomLogger.debug(this.getClass(), "ClientWebException occurred during Equifax SMFA Status web service call. Validate SMFA Link request is empty.");  
				return statusResponse;
			}
			
        	String errorResponseStr = g.toJson(entity);
        	JSONObject additionalErrorDetails = (JSONObject) entity.get("additionalErrorDetails");

        	if (additionalErrorDetails != null) {
        		String developerMessage = (String) additionalErrorDetails.get(KEY_DEVELOPER_MESSAGE);
        		String errorType = (String) additionalErrorDetails.get(KEY_ERROR_TYPE);
        	
        		AdditionalErrorDetailModel errorDetail = new AdditionalErrorDetailModel();
        		errorDetail.setDeveloperMessage(developerMessage);
        		errorDetail.setErrorType(errorType);
        		statusResponse.setAdditionalErrorDetails(errorDetail);
        	}
        	
          	if (entity.get(KEY_TRANSACTION_ID) != null) {
        		statusResponse.setTransactionId((String) entity.get(KEY_TRANSACTION_ID));
        	}
        	
         	if (entity.get(KEY_DESCRIPTION) != null) {
        		statusResponse.setDescription((String) entity.get(KEY_DESCRIPTION));
        	}

        	if (entity.get(KEY_EFX_ERROR_CODE) != null) {
        		statusResponse.setEfxErrorCode((String) entity.get(KEY_EFX_ERROR_CODE));
        	}

			CustomLogger.debug(this.getClass(), "ClientWebException occurred during Equifax SMFA Status web service call.");  
			CustomLogger.debug(this.getClass(), "ClientWebException Equifax SMFA Status error response body:" + errorResponseStr);  
     	}
   		catch (ClientRuntimeException e) {
           	CustomLogger.error(this.getClass(), "ClientRuntimeException occurred in getting Resource response from the Equifax SMFA Status web service:" + e.getMessage(), e);  
        } 
   		catch (Exception e) {
            	CustomLogger.error(this.getClass(), "Generic Exception occurred in getting Resource response from the Equifax SMFA Status web service:" + e.getMessage(), e);  
        } 
   		
   		return statusResponse;
   	}
     
     /*** Experian CrossCore **/
  	
    @Override
 	public JSONObject getCrossCoreResponse(ExperianResultVo resultVo, Resource resource, String bearerToken, String requestJsonStr) {
     	CustomLogger.enter(this.getClass());

     	CustomLogger.debug(this.getClass(), "Process check: Common Service getCrossCoreResponse "
				+ String.format("bearerToken: %s", bearerToken));

    	CustomLogger.debug(this.getClass(), "Process check: Common Service getCrossCoreResponse "
				+ String.format("requestJsonStr: %s", requestJsonStr));

     	JSONObject ccResponseJsonObj = new JSONObject();
     	Gson g = new GsonBuilder().disableHtmlEscaping().create();
 		
		String errorMessage = "";

		try {
			ccResponseJsonObj =  JSONObject.parse(resource.contentType(MediaType.APPLICATION_JSON)
						.header(HEADER_AUTHORIZATION, bearerToken)
						.post(String.class, requestJsonStr));			
   	    }
 		catch (ClientWebException cwEx) {
         	errorMessage = "ClientWebException occurs in calling getCrossCoreResponse API.";
         	ccResponseJsonObj = getCommonErrorResponse("500", errorMessage);

           	CustomLogger.error(this.getClass(), errorMessage + "::" + ccResponseJsonObj, cwEx);
           	resultVo.setHasResponseError(true);
        	return ccResponseJsonObj;         	
    	}
 		catch (ClientRuntimeException crEx) {
         	errorMessage = "ClientRuntimeException occurs in calling getCrossCoreResponse method.";
        	ccResponseJsonObj = getCommonErrorResponse("500", errorMessage);

        	String ccResponseJson = g.toJson(ccResponseJsonObj);
         	CustomLogger.error(this.getClass(), errorMessage + "::" + ccResponseJson, crEx);  
        	resultVo.setHasResponseError(true);
        	return ccResponseJsonObj;         	
        } catch (Exception ex) {
         	errorMessage = "General Exception occurs in calling getCrossCoreResponse method.";
        	ccResponseJsonObj = getCommonErrorResponse("500", errorMessage);

        	String ccResponseJson = g.toJson(ccResponseJsonObj);
         	CustomLogger.error(this.getClass(), errorMessage + "::" + ccResponseJson, ex);  
        	resultVo.setHasResponseError(true);
        	return ccResponseJsonObj;  
         } 

		return ccResponseJsonObj;
 	}
    
    /*** Common Methods **/
    
    @Override
    public String getServiceURL(String serviceName) {
        CustomLogger.enter(this.getClass());

    	LookupCodesEnv lookup = lookupCodesEnvService.getValueByEnvironment(Utils.getEnvironmentWithoutDot().toUpperCase(), serviceName);
 		return lookup == null ? "" : lookup.getValue();
 	}
 	
    @Override
    public AliasVo getJ2CInfo(String aliasName) throws IPSException {
        CustomLogger.enter(this.getClass());

    	AliasVo j2c = null;
 		
 		try {
 			j2c = Utils.getAppCredentials(aliasName);
 		} catch (IPSException e) {
 			CustomLogger.error(this.getClass(), "Error occurred in getting J2C alias info  for: " + aliasName, e);
 			throw e;
 		}
 		
 		return j2c;
 	}
 	
    @Override
    public Resource getClientResource(String inputUrl) {
        CustomLogger.enter(this.getClass());

        ClientConfig config = new ClientConfig();
 		config.proxyHost(IPSConstants.USPS_PROXY_HOST);
 		config.proxyPort(Integer.parseInt(IPSConstants.USPS_PROXY_PORT));
 		RestClient client = new RestClient(config);
 
 		return client.resource(inputUrl);
 	}
 	
    @Override
    public String getIpsPropertyValue(String propertyName) {
        CustomLogger.enter(this.getClass());
        
        String propertyValue = null;
        try {
            Properties prop = getProperties();
            String environment = Utils.getEnvironment();
                         
            propertyName = environment.concat(propertyName);
            propertyValue = prop.getProperty(propertyName);
         } 
        catch (Exception ex) {        
            CustomLogger.error(this.getClass(), "Could not load ips.properties",ex);        
        } 
        
        return propertyValue;
    }
    
    @Override
    public Map<String, String> getAppNameCodeMap() {
    	List<RefApp> appList = refAppService.list();
    	Map<String, String> appNameCodeMap = new LinkedHashMap<>();
    	
     	for(RefApp app : appList) {
    		String appName = app.getAppName();
      		String[] nameParts = appName.split(" ");
       		
     		String dbAppCode = "";
    		
    		if (nameParts.length > 0) {
    			for (int i = 0; i < nameParts.length; i++) {
    			    String part = nameParts[i];    			    
    			    String startChar = "of".equalsIgnoreCase(part)? "" : part.substring(0,1).toUpperCase();
      			    dbAppCode += startChar;
      			}
    		}
 
		    appNameCodeMap.put(appName, dbAppCode.toUpperCase());
       	}
    	
    	return appNameCodeMap;
	}
    
    private Properties getProperties() {
        CustomLogger.enter(this.getClass());
        
        InputStream input = null;
        Properties prop = new Properties();

        try {
            input = CommonRestServiceImpl.class.getClassLoader().getResourceAsStream(RESOURCE_STREAM_PATH);
            // load a properties file
            prop.load(input); 
        } 
        catch (Exception ex) {    
            CustomLogger.error(this.getClass(), "Could not load ips.properties",ex);        
        } 
        
        return prop;
    }
 	
    private JSONObject getCommonErrorResponse(String errorType, String message) {
    	JSONArray errorArr = new JSONArray();
    	JSONObject responseError = new JSONObject();
    	
    	JSONObject errorItem = new JSONObject();
       	errorItem.put("errorType", errorType);
       	errorItem.put("message", message);
    	
    	errorArr.add(errorItem);
    	responseError.put("errors", errorArr);
    	responseError.put("success", false);
   	
		return responseError;
    }
    
    public String getClientIpAddress(HttpServletRequest request) {
        // Get IP from request header populated by CustReg
        String clientIP = request.getHeader(IPSConstants.CLIENT_IP);
        CustomLogger.debug(this.getClass(), IPSConstants.CLIENT_IP + " = " + clientIP);

        if (StringUtils.isBlank(clientIP)) {
            clientIP = request.getHeader(IPSConstants.NS_CLIENT_IP);
            CustomLogger.debug(this.getClass(), IPSConstants.NS_CLIENT_IP + " = " + clientIP);

            // If CustReg header not populated get IP directly from client or last server that sent request
            if (StringUtils.isBlank(clientIP)) {
                clientIP = request.getRemoteAddr();
                CustomLogger.debug(this.getClass(), "IP address of the client or last proxy that sent the request = "    + clientIP);
            }
        }
        
        if (!Utils.isValidIpAddress(clientIP)) {
            CustomLogger.warn(this.getClass(), "WARNING: Invalid IP address found: " + clientIP);
        }
        
        return clientIP;
    }
    
    public String getUserAgent(HttpServletRequest hsr) {

		String userAgent = "";
		String httpAccept = "";
	 	
		try {
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			userAgent = request.getHeader(HEADER_USER_AGENT);
			httpAccept = request.getHeader(HEADER_ACCEPT);
			UAgentInfo detector = new UAgentInfo(userAgent, httpAccept);
			
			if (detector.getIsMobilePhone()) {
				return "MobilePhone";
			}
			return "Desktop";
		}
		catch (Exception ex) {
	        CustomLogger.error(this.getClass(), "Unable to get User-Agent ", ex);
	        return "Unknown";
		}
    }
}
