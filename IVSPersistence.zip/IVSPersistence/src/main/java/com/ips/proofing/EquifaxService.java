package com.ips.proofing;

import java.io.IOException;

import com.equifax.dit.request.InitiateDITRequestModel;
import com.equifax.dit.response.InitiateDITResponseModel;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.CredentialsErrorFault;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.InvalidTransactionKeyFault;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.ValidationErrorFault;
import com.equifax.smfa.request.InitiateSMFARequestModel;
import com.equifax.smfa.request.StatusSMFARequestModel;
import com.equifax.smfa.response.InitiateSMFAResponseModel;
import com.ips.entity.Person;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RpEvent;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationResponse;

public interface EquifaxService {

    //String sendPasscode(Person person, PersonVo personVo) throws IPSException, PhoneVerificationException;
    String generateEquifaxBearerToken(String scope, String tokenType, boolean obtainNewToken) throws Exception;
    String getSmfaStatus(PersonVo personVo) throws IPSException, PhoneVerificationException, IOException;
	String getSmfaStatus(PersonVo personVo, boolean checkTokenExpiry) throws IPSException, PhoneVerificationException, IOException;
    PhoneVerificationResponse verifyPhone(Person person, PersonVo personVo, RefOtpSupplier pvSupplier) throws IPSException, PhoneVerificationException, Throwable;
    PhoneVerificationResponse verifyPhoneWithEquifaxDIT(PersonVo personVo, String sponsorUserId, RpEvent phoneEvent) throws Exception;
    void evaluateDITOverallDecision(InitiateDITResponseModel initiateResponse);
    void processDitInitiateResponse(InitiateDITResponseModel initiateResponse, PersonVo personVo, RpEvent phoneEvent, String requestStr, String responseStr, boolean hasError) throws PhoneVerificationException;
	boolean sendPasscodeSuccessful(Person person, PersonVo personVo) throws IPSException, PhoneVerificationException, Throwable;
    boolean confirmPasscodeSuccessful(Person person, PersonVo personVo, RpEvent event) throws IPSException, PhoneVerificationException, CredentialsErrorFault, InvalidTransactionKeyFault, ValidationErrorFault;
    boolean resendPasscodeSuccessful(RpEvent event, Person person, PersonVo personVo) throws IPSException, PhoneVerificationException, Throwable;
    boolean userFailedEIDPhoneVerification(Person person, long supplierId);
    InitiateDITRequestModel prepareDitInitiateRequest(PersonVo personVo, String sponsorUserId, long eventId) throws IPSException;
    InitiateSMFARequestModel prepareSmfaInitiateRequest(PersonVo personVo, String kbaUid, boolean isDesktop) throws Exception;
    InitiateSMFAResponseModel sendSmfaLink(Person person, PersonVo personVo, boolean isDesktop) throws IPSException, PhoneVerificationException, IOException;
    StatusSMFARequestModel prepareSmfaStatusRequest(String mobileNumber) throws Exception;
}
