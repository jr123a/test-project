package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ref_kba_reason_code database table.
 * 
 */
@Entity
@Table(name="ref_kba_reason_code")
public class RefOtpReasonCode implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="REASON_CODE")
    private String reasonCode;

    @Column(name="ASSERT_FLAG")
    private String assertFlag;
    
    @Column(name="CREATE_DATE")
    private Timestamp createDate;
    
    @Column(name="KBA_SUPPLIER_ID")
    private int otpSupplierId;
    
    @Column(name="REASON_CODE_DESCRIPTION")
    private String reasonCodeDescription;
    
    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    //bi-directional many-to-one association to RefLexisNexisReasonCodeMap
    @OneToMany(mappedBy="refOtpReasonCode")
    private List<RefLexisNexisReasonCodeMap> refLexisNexisReasonCodeMaps;

    //bi-directional many-to-one association to RpEquifaxFinalReasonCode
    @OneToMany(mappedBy="refOtpReasonCode")
    private List<RpEquifaxFinalReasonCode> rpEquifaxFinalReasonCodes;

    //bi-directional many-to-one association to RpLexisNexisFinalReasonCode
    @OneToMany(mappedBy="refOtpReasonCode")
    private List<RpLexisNexisFinalReasonCode> rpLexisNexisFinalReasonCodes;

    public String getReasonCode() {
        return this.reasonCode;
    }

    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }

    public String getAssertFlag() {
        return this.assertFlag;
    }

    public void setAssertFlag(String assertFlag) {
        this.assertFlag = assertFlag;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public int getOtpSupplierId() {
        return this.otpSupplierId;
    }

    public void setOtpSupplierId(int otpSupplierId) {
        this.otpSupplierId = otpSupplierId;
    }

    public String getReasonCodeDescription() {
        return this.reasonCodeDescription;
    }

    public void setReasonCodeDescription(String reasonCodeDescription) {
        this.reasonCodeDescription = reasonCodeDescription;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<RefLexisNexisReasonCodeMap> getRefLexisNexisReasonCodeMaps() {
        return this.refLexisNexisReasonCodeMaps;
    }

    public void setRefLexisNexisReasonCodeMaps(List<RefLexisNexisReasonCodeMap> refLexisNexisReasonCodeMaps) {
        this.refLexisNexisReasonCodeMaps = refLexisNexisReasonCodeMaps;
    }

    public RefLexisNexisReasonCodeMap addRefLexisNexisReasonCodeMap(RefLexisNexisReasonCodeMap refLexisNexisReasonCodeMap) {
        getRefLexisNexisReasonCodeMaps().add(refLexisNexisReasonCodeMap);
        refLexisNexisReasonCodeMap.setRefOtpReasonCode(this);

        return refLexisNexisReasonCodeMap;
    }

    public RefLexisNexisReasonCodeMap removeRefLexisNexisReasonCodeMap(RefLexisNexisReasonCodeMap refLexisNexisReasonCodeMap) {
        getRefLexisNexisReasonCodeMaps().remove(refLexisNexisReasonCodeMap);
        refLexisNexisReasonCodeMap.setRefOtpReasonCode(null);

        return refLexisNexisReasonCodeMap;
    }

    public List<RpEquifaxFinalReasonCode> getRpEquifaxFinalReasonCodes() {
        return this.rpEquifaxFinalReasonCodes;
    }

    public void setRpEquifaxFinalReasonCodes(List<RpEquifaxFinalReasonCode> rpEquifaxFinalReasonCodes) {
        this.rpEquifaxFinalReasonCodes = rpEquifaxFinalReasonCodes;
    }

    public RpEquifaxFinalReasonCode addRpEquifaxFinalReasonCode(RpEquifaxFinalReasonCode rpEquifaxFinalReasonCode) {
        getRpEquifaxFinalReasonCodes().add(rpEquifaxFinalReasonCode);
        rpEquifaxFinalReasonCode.setRefOtpReasonCode(this);

        return rpEquifaxFinalReasonCode;
    }

    public RpEquifaxFinalReasonCode removeRpEquifaxFinalReasonCode(RpEquifaxFinalReasonCode rpEquifaxFinalReasonCode) {
        getRpEquifaxFinalReasonCodes().remove(rpEquifaxFinalReasonCode);
        rpEquifaxFinalReasonCode.setRefOtpReasonCode(null);

        return rpEquifaxFinalReasonCode;
    }

    public List<RpLexisNexisFinalReasonCode> getRpLexisNexisFinalReasonCodes() {
        return this.rpLexisNexisFinalReasonCodes;
    }

    public void setRpLexisNexisFinalReasonCodes(List<RpLexisNexisFinalReasonCode> rpLexisNexisFinalReasonCodes) {
        this.rpLexisNexisFinalReasonCodes = rpLexisNexisFinalReasonCodes;
    }

    public RpLexisNexisFinalReasonCode addRpLexisNexisFinalReasonCode(RpLexisNexisFinalReasonCode rpLexisNexisFinalReasonCode) {
        getRpLexisNexisFinalReasonCodes().add(rpLexisNexisFinalReasonCode);
        rpLexisNexisFinalReasonCode.setRefOtpReasonCode(this);

        return rpLexisNexisFinalReasonCode;
    }

    public RpLexisNexisFinalReasonCode removeRpLexisNexisFinalReasonCode(RpLexisNexisFinalReasonCode rpLexisNexisFinalReasonCode) {
        getRpLexisNexisFinalReasonCodes().remove(rpLexisNexisFinalReasonCode);
        rpLexisNexisFinalReasonCode.setRefOtpReasonCode(null);

        return rpLexisNexisFinalReasonCode;
    }
}
