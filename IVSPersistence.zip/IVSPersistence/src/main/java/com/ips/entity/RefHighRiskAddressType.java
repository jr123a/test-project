package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the ref_loa_level database table.
 * 
 */
@Entity
@Table(name="ref_high_risk_address_types")
@NamedQueries({
    @NamedQuery(name="RefHighRiskAddressType.findByTypeId", query="SELECT r FROM RefHighRiskAddressType r WHERE r.highRiskAddressTypeId = :typeId")
})    
public class RefHighRiskAddressType implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="high_risk_address_type_id")
    private long highRiskAddressTypeId;

    @Column(name="description")
    private String description;
    

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setHighRiskAddressTypeId(long highRiskAddressTypeId) {
        this.highRiskAddressTypeId = highRiskAddressTypeId;
    }
    
    public boolean isPrimary() {
        return "PRIMARY".equalsIgnoreCase(getDescription());
    }
    
    public boolean isSecondary() {
        return "SECONDARY".equalsIgnoreCase(getDescription());
    }
}
