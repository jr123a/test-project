package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="rp_all_verification_results") 
@NamedQueries({
    @NamedQuery(name="RpAllVerificationResults.getAll", query="SELECT r FROM RpAllVerificationResults r"),
    @NamedQuery(name = "RpAllVerificationResults.getListBypersonId", query = "SELECT r FROM RpAllVerificationResults r WHERE r.personId = :personId ORDER BY r.createDate DESC")
})    
public class RpAllVerificationResults implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="rp_all_verification_resultsSeq")
    @SequenceGenerator(name="rp_all_verification_resultsSeq",sequenceName="RP_ALL_VERIFICATION_RESULTS_SEQ", allocationSize=1)
    @Column(name="VER_RESULT_ID")
    private long verResultId;

    @Column(name="PERSON_ID")
    private long personId;
     
	@Column(name="APP_ID")
    private long appId;
    
    @Column(name="TRANSACTION_ID")
    private String transactionId;

    @Column(name="TRANSACTION_SESSION_ID")
    private String transactionSessionId;
    
    @Column(name="PRIMARY_PRE_PV_PRODUCT")
    private String primaryPrePVProduct;  

    @Column(name="PRIMARY_PRE_PV_STATUS")
    private String primaryPrePVStatus;  
    
    @Column(name="PRIMARY_PRE_PV_REPEAT")
    private String primaryPrePVRepeat;  

    @Column(name="SECONDARY_PRE_PV_PRODUCT")
    private String secondaryPrePVProduct;  

    @Column(name="SECONDARY_PRE_PV_STATUS")
    private String secondaryPrePVStatus;  
    
    @Column(name="SECONDARY_PRE_PV_REPEAT")
    private String secondaryPrePVRepeat; 
    
    @Column(name="PRIMARY_PV_PRODUCT")
    private String primaryPVProduct;  

    @Column(name="PRIMARY_PV_STATUS")
    private String primaryPVStatus;  
    
    @Column(name="PRIMARY_PV_REPEAT")
    private String primaryPVRepeat;  
    
    @Column(name="SECONDARY_PV_PRODUCT")
    private String secondaryPVProduct;  

    @Column(name="SECONDARY_PV_STATUS")
    private String secondaryPVStatus;  

    @Column(name="SECONDARY_PV_ATTEMPTS")
    private long secondaryPVAttempts; 
    
    @Column(name="INITIATION_DATETIME")
    private Timestamp initiationDatetime;
    
	@Column(name = "CREATE_DATE")
    private Date createDate;
    
    @Column(name = "UPDATE_DATE")
    private Date updateDate;

	public long getVerResultId() {
		return verResultId;
	}

	public void setVerResultId(long verResultId) {
		this.verResultId = verResultId;
	}

	public long getPersonId() {
		return personId;
	}

	public long getAppId() {
		return appId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public String getTransactionSessionId() {
		return transactionSessionId;
	}

	public String getPrimaryPrePVProduct() {
		return primaryPrePVProduct;
	}

	public String getPrimaryPrePVStatus() {
		return primaryPrePVStatus;
	}

	public String getPrimaryPrePVRepeat() {
		return primaryPrePVRepeat;
	}

	public String getSecondaryPrePVProduct() {
		return secondaryPrePVProduct;
	}

	public String getSecondaryPrePVStatus() {
		return secondaryPrePVStatus;
	}

	public String getSecondaryPrePVRepeat() {
		return secondaryPrePVRepeat;
	}

	public String getPrimaryPVProduct() {
		return primaryPVProduct;
	}

	public String getPrimaryPVStatus() {
		return primaryPVStatus;
	}

	public String getPrimaryPVRepeat() {
		return primaryPVRepeat;
	}

	public String getSecondaryPVProduct() {
		return secondaryPVProduct;
	}

	public String getSecondaryPVStatus() {
		return secondaryPVStatus;
	}

	public long getSecondaryPVAttempts() {
		return secondaryPVAttempts;
	}

	public Timestamp getInitiationDatetime() {
		return initiationDatetime;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setPersonId(long personId) {
		this.personId = personId;
	}

	public void setAppId(long appId) {
		this.appId = appId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setTransactionSessionId(String transactionSessionId) {
		this.transactionSessionId = transactionSessionId;
	}

	public void setPrimaryPrePVProduct(String primaryPrePVProduct) {
		this.primaryPrePVProduct = primaryPrePVProduct;
	}

	public void setPrimaryPrePVStatus(String primaryPrePVStatus) {
		this.primaryPrePVStatus = primaryPrePVStatus;
	}

	public void setPrimaryPrePVRepeat(String primaryPrePVRepeat) {
		this.primaryPrePVRepeat = primaryPrePVRepeat;
	}

	public void setSecondaryPrePVProduct(String secondaryPrePVProduct) {
		this.secondaryPrePVProduct = secondaryPrePVProduct;
	}

	public void setSecondaryPrePVStatus(String secondaryPrePVStatus) {
		this.secondaryPrePVStatus = secondaryPrePVStatus;
	}

	public void setSecondaryPrePVRepeat(String secondaryPrePVRepeat) {
		this.secondaryPrePVRepeat = secondaryPrePVRepeat;
	}

	public void setPrimaryPVProduct(String primaryPVProduct) {
		this.primaryPVProduct = primaryPVProduct;
	}

	public void setPrimaryPVStatus(String primaryPVStatus) {
		this.primaryPVStatus = primaryPVStatus;
	}

	public void setPrimaryPVRepeat(String primaryPVRepeat) {
		this.primaryPVRepeat = primaryPVRepeat;
	}

	public void setSecondaryPVProduct(String secondaryPVProduct) {
		this.secondaryPVProduct = secondaryPVProduct;
	}

	public void setSecondaryPVStatus(String secondaryPVStatus) {
		this.secondaryPVStatus = secondaryPVStatus;
	}

	public void setSecondaryPVAttempts(long secondaryPVAttempts) {
		this.secondaryPVAttempts = secondaryPVAttempts;
	}

	public void setInitiationDatetime(Timestamp initiationDatetime) {
		this.initiationDatetime = initiationDatetime;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

}
