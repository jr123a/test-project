package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the SponsorWebServiceHistory database table.
 * 
 */
@Entity
@Table(name = "sponsor_web_service_history")
@NamedQuery(name = "SponsorWebServiceHistory.getHistoryFalures", query = "select SUM(i.failedAttempts) from SponsorWebServiceHistory i "
            + "where i.attemptDateTime >= :startDate AND i.attemptDateTime <= :endDate "
            + "AND i.refSponsor.sponsorId = :sponsorId")
@NamedQuery(name = "SponsorWebServiceHistory.getRetrySucceededCount", query = "select COUNT(i) from SponsorWebServiceHistory i "
                + "where i.attemptDateTime >= :startDate AND i.attemptDateTime <= :endDate "
                + "AND i.refSponsor.sponsorId = :sponsorId "
                + "and i.transactionSuccess = 'Y'")
@NamedQuery(name = "SponsorWebServiceHistory.getFailedEmailCount", query = "select COUNT(i) from SponsorWebServiceHistory i "
                + "where i.attemptDateTime >= :startDate AND i.attemptDateTime <= :endDate "
                + "AND i.refSponsor.sponsorId = :sponsorId "
                + "and i.transactionSuccess = 'N' "
                + "and i.failedAttempts = :maxAttempts")
@NamedQuery(name="SponsorWebServiceHistory.findSponsorWebServiceHistoryBySponsor", query="SELECT r FROM SponsorWebServiceHistory r WHERE r.refSponsor.sponsorId = :sponsorId")

public class SponsorWebServiceHistory implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="sponsor_web_service_historySeq")
    @SequenceGenerator(name="sponsor_web_service_historySeq",sequenceName="SPONSOR_WEB_SERVICE_HISTORY_SEQ", allocationSize=1)
    @Column(name = "HISTORY_ID")
    private long historyId;

    // bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name = "SPONSOR_ID")
    private RefSponsor refSponsor;

    @Column(name = "ENROLLMENT_CODE")
    private String enrollmentCode;

    @Column(name = "ATTEMPT_DATETIME")
    private Timestamp attemptDateTime;

    @Column(name = "FAILED_ATTEMPTS")
    private int failedAttempts;

    @Column(name = "TRANSACTION_SUCCESS")
    private String transactionSuccess;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;

    public long getHistoryId() {
        return historyId;
    }

    public void setHistoryId(long historyId) {
        this.historyId = historyId;
    }

    public RefSponsor getRefSponsor() {
        return refSponsor;
    }

    public void setRefSponsor(RefSponsor refSponsor) {
        this.refSponsor = refSponsor;
    }

    public String getEnrollmentCode() {
        return enrollmentCode;
    }

    public void setEnrollmentCode(String enrollmentCode) {
        this.enrollmentCode = enrollmentCode;
    }

    public Timestamp getAttemptDateTime() {
        return attemptDateTime;
    }

    public void setAttemptDateTime(Timestamp attemptDateTime) {
        this.attemptDateTime = attemptDateTime;
    }

    public int getFailedAttempts() {
        return failedAttempts;
    }

    public void setFailedAttempts(int failedAttempts) {
        this.failedAttempts = failedAttempts;
    }

    public String getTransactionSuccess() {
        return transactionSuccess;
    }

    public void setTransactionSuccess(String transactionSuccess) {
        this.transactionSuccess = transactionSuccess;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }
}
