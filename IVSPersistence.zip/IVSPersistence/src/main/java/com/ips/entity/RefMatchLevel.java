package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the ref_match_levels database table.
 * 
 */
@Entity
@Table(name="ref_match_levels")
@NamedQueries({
    @NamedQuery(name="RefMatchLevel.findAll", query="SELECT r FROM RefMatchLevel r"),
    @NamedQuery(name="RefMatchLevel.findByName", query="Select r FROM RefMatchLevel r WHERE r.matchLevel = :name")
})    
public class RefMatchLevel implements Serializable {
    private static final long serialVersionUID = 1L;
        
    @Id
    @Column(name="match_level_id")
    private long matchLevelId;
        
    @Column(name="match_level")
    private String matchLevel;
    
    @Column(name="create_date")
    private Timestamp createDate;

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public long getMatchLevelId() {
        return matchLevelId;
    }

    public void setMatchLevelId(long matchLevelId) {
        this.matchLevelId = matchLevelId;
    }

    public String getMatchLevel() {
        return matchLevel;
    }

    public void setMatchLevel(String matchLevel) {
        this.matchLevel = matchLevel;
    }
}
