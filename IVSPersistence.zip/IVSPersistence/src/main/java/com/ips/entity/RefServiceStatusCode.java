package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the ref_service_status_codes database table.
 * 
 */
@Entity
@Table(name="ref_service_status_codes")
@NamedQueries({
    @NamedQuery(name="RefServiceStatusCode.findAll", query="SELECT r FROM RefServiceStatusCode r"),
    @NamedQuery(name="RefServiceStatusCode.findByName", query="Select r FROM RefServiceStatusCode r WHERE r.serviceStatus = :name")
})    
public class RefServiceStatusCode implements Serializable {
    private static final long serialVersionUID = 1L;
        
    @Id
    @Column(name="status_code_id")
    private long statusCodeId;
        
    @Column(name="service_status")
    private String serviceStatus;
    
    @Column(name="create_date")
    private Timestamp createDate;
    
    public String getServiceStatus() {
        return serviceStatus;
    }

    public void setServiceStatus(String serviceStatus) {
        this.serviceStatus = serviceStatus;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }
}

