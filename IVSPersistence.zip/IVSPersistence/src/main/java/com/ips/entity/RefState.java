package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ref_state database table.
 * 
 */
@Entity
@Table(name="ref_state")
@NamedQueries({
    @NamedQuery(name="RefState.findAll", query="SELECT i FROM RefState i"),
    @NamedQuery(name="RefState.findAllActiveStates", query="SELECT s FROM RefState s WHERE s.deleteFlag IS NULL ORDER BY s.stateName ASC"),
    @NamedQuery(name="RefState.findByStateCode", query="SELECT i FROM RefState i WHERE i.stateCode = :stateCode"),
})
public class RefState  implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="state_code")
    private String stateCode;

    @Column(name="create_date")
    private Timestamp createDate;

    @Column(name="delete_flag")
    private String deleteFlag;

    @Column(name="state_name")
    private String stateName;

    @Column(name="update_date")
    private Timestamp updateDate;

    //bi-directional many-to-one association to IppEvent
    @OneToMany(mappedBy="refState")
    private List<IppEvent> ippEvents;

    public String getStateCode() {
        return this.stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getDeleteFlag() {
        return this.deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getStateName() {
        return this.stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<IppEvent> getIppEvents() {
        return this.ippEvents;
    }

    public void setIppEvents(List<IppEvent> ippEvents) {
        this.ippEvents = ippEvents;
    }

    public IppEvent addIppEvent(IppEvent ippEvent) {
        getIppEvents().add(ippEvent);
        ippEvent.setRefState(this);

        return ippEvent;
    }

    public IppEvent removeIppEvent(IppEvent ippEvent) {
        getIppEvents().remove(ippEvent);
        ippEvent.setRefState(null);

        return ippEvent;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((deleteFlag == null) ? 0 : deleteFlag.hashCode());
        result = prime * result + ((stateCode == null) ? 0 : stateCode.hashCode());
        result = prime * result + ((stateName == null) ? 0 : stateName.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefState other = (RefState) obj;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (deleteFlag == null) {
            if (other.deleteFlag != null)
                return false;
        } else if (!deleteFlag.equals(other.deleteFlag))
            return false;
        if (stateCode == null) {
            if (other.stateCode != null)
                return false;
        } else if (!stateCode.equals(other.stateCode))
            return false;
        if (stateName == null) {
            if (other.stateName != null)
                return false;
        } else if (!stateName.equals(other.stateName))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }

}
