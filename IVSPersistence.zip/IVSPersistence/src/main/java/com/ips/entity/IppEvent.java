package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.ips.common.common.DateTimeUtil;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the ipp_event database table.
 * 
 */
@Entity
@Table(name="ipp_event")

	@NamedQuery(name = "IppEvent.findAll", query = "SELECT i FROM IppEvent i")
        @NamedQuery(name = "IppEvent.findByRecordLocator", query = "SELECT i FROM IppEvent i WHERE i.recordLocator = :recordLocator")
        @NamedQuery(name = "IppEvent.findConfirmationNumber", query = "SELECT i FROM IppEvent i WHERE i.refIppEventStatus = :ippEventStatus "
                + "AND i.person = :person ORDER BY i.transactionEndDatetime DESC")
        @NamedQuery(name = "IppEvent.findByStatus", query = "SELECT i FROM IppEvent i WHERE i.refIppEventStatus = :ippEventStatus "
                + "AND i.person = :person AND i.inPersonProofingType = 'F' ORDER BY i.createDate DESC")
        @NamedQuery(name = "IppEvent.findAppointment", query = "SELECT i FROM IppEvent i WHERE i.refIppEventStatus = :ippEventStatus "
                + "AND i.person.personId = :personId AND i.appointmentDate IS NOT NULL ORDER BY i.ippEventId DESC")
        @NamedQuery(name = "IppEvent.findAllIppEventsAtResidence", query = "SELECT i FROM IppEvent i WHERE i.inPersonProofingType = :inPersonProofingType "
                + "AND i.appointmentDate = :appointmentDate")
        @NamedQuery(name = "IppEvent.getIPPStatusCount", query = "SELECT COUNT(i) FROM IppEvent i WHERE i.refIppEventStatus = :ippEventStatus "
                + "AND i.transactionEndDatetime >= :startDate AND i.transactionEndDatetime <= :endDate")
        @NamedQuery(name = "IppEvent.getIPPStatusCountByLevel", query = "SELECT COUNT(i) FROM IppEvent i WHERE i.refIppEventStatus = :ippEventStatus "
                + "AND i.refLoaLevel = :level AND i.transactionEndDatetime >= :startDate AND i.transactionEndDatetime <= :endDate")
        @NamedQuery(name = "IppEvent.getIPPFlaggedAsFraudCount", query = "SELECT COUNT(i) FROM IppEvent i WHERE i.fraudSuspected = 'Y' "
                + "AND i.transactionEndDatetime >= :startDate AND i.transactionEndDatetime <= :endDate")
        @NamedQuery(name = "IppEvent.getIPPFlaggedAsFraudCountByLevel", query = "SELECT COUNT(i) FROM IppEvent i WHERE i.fraudSuspected = 'Y' "
                + "AND i.refLoaLevel = :level AND i.transactionEndDatetime >= :startDate AND i.transactionEndDatetime <= :endDate")
        @NamedQuery(name="IppEvent.findEventsWithNoFacilityByMonth", query="SELECT i FROM IppEvent i WHERE i.refFacFacility.refFacilityId = 0 " 
                + "AND i.inPersonProofingLocation <> '0.000000,0.000000' AND i.inPersonProofingType = 'F' " 
                + "AND i.transactionEndDatetime >= :startDate AND i.transactionEndDatetime < :endDate "
                + "ORDER BY i.transactionEndDatetime")
        @NamedQuery(name="IppEvent.getEventsWithNoFacilityCountByMonth", query="SELECT COUNT(i) FROM IppEvent i WHERE i.refFacFacility.refFacilityId = 0 " 
                + "AND i.inPersonProofingLocation <> '0.000000,0.000000' AND i.inPersonProofingType = 'F' " 
                + "AND i.transactionEndDatetime >= :startDate AND i.transactionEndDatetime < :endDate ")
        @NamedQuery(name = "IppEvent.getReminderEvents", query = "SELECT i FROM IppEvent i WHERE i.person.refSponsor = :sponsorId " 
                + "AND i.refIppEventStatus = :ippEventStatus " 
                + "AND i.inPersonProofingType = 'F' " 
                + "AND i.createDate >= :startDate AND i.createDate <= :endDate")
        @NamedQuery(name = "IppEvent.getIPPStatusCountBySponsor", query = "SELECT COUNT(i) FROM IppEvent i WHERE i.refIppEventStatus = :ippEventStatus "
                        + "AND i.transactionEndDatetime >= :startDate AND i.transactionEndDatetime <= :endDate " 
                        + "AND i.person.refSponsor = :sponsorId ")
        @NamedQuery(name = "IppEvent.findNewEventsBySponsor", query = "SELECT i FROM IppEvent i WHERE i.refIppEventStatus = :ippEventStatus "
                        + "AND i.createDate >= :startDate AND i.createDate <= :endDate " 
                        + "AND i.person.refSponsor = :sponsorId ")
        @NamedQuery(name = "IppEvent.getOptInCountBySponsor", query = "SELECT COUNT(i) FROM IppEvent i "
                        + "WHERE i.createDate >= :startDate AND i.createDate <= :endDate " 
                        + "AND i.person.refSponsor = :sponsorId ")
        @NamedQuery(name = "IppEvent.getPolicyResultCountBySponsor", query = "SELECT COUNT(i) FROM IppEvent i " 
                        + "WHERE i.agencyPolicyProofingResult = :proofingResult "
                        + "AND i.transactionEndDatetime >= :startDate AND i.transactionEndDatetime <= :endDate " 
                        + "AND i.person.refSponsor = :sponsorId ")
        @NamedQuery(name = "IppEvent.getPrimaryIdUsedCountByIdType", query = "SELECT COUNT(i) FROM IppEvent i " 
                + "WHERE i.refPrimaryIdType.idType = :idType ")
        @NamedQuery(name = "IppEvent.getSecondaryIdUsedCountByIdType", query = "SELECT COUNT(i) FROM IppEvent i " 
                + "WHERE i.refSecondaryIdType.idType = :idType ")
        @NamedQuery(name = "IppEvent.getEventCountByApplicationId", query="SELECT COUNT(i) FROM IppEvent i WHERE i.transactionOriginId.appId = :appId")
        @NamedQuery(name = "IppEvent.getEventsByTransactionEndDate", query = "SELECT i FROM IppEvent i " 
                        + "WHERE i.transactionEndDatetime < :dayAfter and i.transactionEndDatetime > :dayBefore")
        @NamedQuery(name="IppEvent.getEventCountWithStartStatusBySponsor", query="SELECT COUNT(i) FROM IppEvent i WHERE i.refIppEventStatus.ippEventStatus = 1 AND i.person.refSponsor.sponsorId = :sponsorId")
        

public class IppEvent implements Serializable, Comparable<IppEvent> {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="IppEventSeq")
    @SequenceGenerator(name="IppEventSeq",sequenceName="SEQ_IPP_EVENT_ID", allocationSize=1)
    @Column(name="ipp_event_id")
    private long ippEventId;
    @Column(name="CONFIRMATION_NUMBER")
    private String confirmationNumber;
    @Column(name="CREATE_DATE")
    private Timestamp createDate;
    @Column(name="FRAUD_SUSPECTED")
    private String fraudSuspected;
    @Column(name="ID_PROOFER_FIRST_NAME")
    private String idProoferFirstName;
    @Column(name="ID_PROOFER_LAST_NAME")
    private String idProoferLastName;
    @Column(name="ID_PROOFER_USER_ID")
    private String idProoferUserId;
    @Column(name="ID_PROOFER_EIN")
    private String idProoferEIN;
    @Column(name="IN_PERSON_PROOFING_LOCATION")
    private String inPersonProofingLocation;
    @Column(name="VISUAL_ALERT_LOCATION")
    private String visualAlertLocation;
    @Column(name="AUDIO_ALERT_LOCATION")
    private String audioAlertLocation;
    @Column(name="RECORD_LOCATOR")
    private String recordLocator;
    @Column(name="TRANSACTION_START_DATETIME")
    private Timestamp transactionStartDatetime;
    @Column(name="TRANSACTION_END_DATETIME")
    private Timestamp transactionEndDatetime;
    @Column(name="VISUAL_ALERT_DATETIME")
    private Timestamp visualAlertDatetime;
    @Column(name="AUDIO_ALERT_DATETIME")
    private Timestamp audioAlertDatetime;
    @Column(name="UPDATE_DATE")
    private Date updateDate;
    @Temporal(TemporalType.DATE)
    @Column(name="APPOINTMENT_DATE")
    private Date appointmentDate;
    @Column(name="APPOINTMENT_TIME")
    private String appointmentTime;
    @Column(name="IN_PERSON_PROOFING_TYPE")
    private String inPersonProofingType;
    @Column(name="ADDRESS_1")
    private String address1;
    @Column(name="ADDRESS_2")
    private String address2;
    @Column(name="CITY")
    private String city;
    @Column(name="ZIP4")
    private String zip4;
    @Column(name="ZIP5")
    private String zip5;
    @Column(name="DELIVERY_POINT")
    private short deliveryPoint;
    @Column(name="ROUTE_ID")
    private String carrierRoute;
    @Column(name="COORDINATE_LAT")
    private double latitude;
    @Column(name="COORDINATE_LONG")
    private double longitude;
    @Column(name="GEOFENCE_BREACH_DATETIME")
    private Timestamp geoFenceBreachDatetime;
    @Column(name="SCAN_COUNT")
    private long scanCount;
    
    //bi-directional many-to-one association to Person
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="person_id")
    private Person person;

    //bi-directional many-to-one association to RefIppEventStatus
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="Ipp_event_status")
    private RefIppEventStatus refIppEventStatus;

    //bi-directional many-to-one association to RefPrimaryIdType
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="Primary_id_type")
    private RefPrimaryIdType refPrimaryIdType;

    //bi-directional many-to-one association to RefSecondaryIdType
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="Secondary_id_type")
    private RefSecondaryIdType refSecondaryIdType;
    
    //bi-directional many-to-one association to RefIppFailureReason
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="failure_reason_code")
    private RefIppFailureReason refIppFailureReason;
    
    //bi-directional many-to-one association to RefState
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="STATE_code")
    private RefState refState;
    
    //bi-directional one-to-one association to IppAppointment
    @OneToOne(mappedBy="ippEvent")
    private IppAppointment ippAppointment;
    
    //many-to-one association to RefLoaLevel
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="proofing_level_sought")
    private RefLoaLevel refLoaLevel;
    
    //bi-directional many-to-one association to RefFacFacility
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="ref_facility_id")
    private RefFacFacility refFacFacility;
    
    //bi-directional many-to-one association to RefIppApplications
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="ipp_application_id")
    private RefIppApplications refIppApplications;
    
    @OneToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
    @JoinColumn(name = "transaction_origin_id")
    private RefApp transactionOriginId;
        
    @Transient
    private boolean selected;
    
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="agency_policy_proofing_result")
    private RefIppEventStatus agencyPolicyProofingResult;
    
    //many-to-one association to RefIppWorkflow
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="workflow_id")
    private RefIppWorkflows refIppWorkflow;
    
    //One-to-many association to IppEventSecondaryID
    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name="ipp_event_id")
    private List<IppEventSecondaryID> secondaryIDs;
    
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.ALL)
    @JoinColumn(name="ipp_event_id")
    private List<IppEventIDValidation> eventIDValidations;
    
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.ALL)
    @JoinColumn(name="ipp_event_id")
    private List<IdVerifyServiceRequest> recievedPrimaryIds;
    
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.ALL)
    @JoinColumn(name="ipp_event_id")
    private List<IdImages> recievedfairIds;
    
    public long getIppEventId() {
        return this.ippEventId;
    }
    public void setEventId(long ippEventId) {
        this.ippEventId = ippEventId;
    }
    public String getConfirmationNumber() {
        return confirmationNumber;
    }
    public void setConfirmationNumber(String confirmationNumber) {
        this.confirmationNumber = confirmationNumber;
    }
    public Timestamp getCreateDate() {
        return this.createDate;
    }
    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }
    public String getFraudSuspected() {
        return this.fraudSuspected;
    }
    public void setFraudSuspected(String fraudSuspected) {
        this.fraudSuspected = fraudSuspected;
    }
    public String getIdProoferFirstName() {
        return this.idProoferFirstName;
    }
    public void setIdProoferFirstName(String idProoferFirstName) {
        this.idProoferFirstName = idProoferFirstName;
    }
    public String getIdProoferLastName() {
        return this.idProoferLastName;
    }
    public void setIdProoferLastName(String idProoferLastName) {
        this.idProoferLastName = idProoferLastName;
    }
    public String getIdProoferUserId() {
        return this.idProoferUserId;
    }
    public void setIdProoferUserId(String idProoferUserId) {
        this.idProoferUserId = idProoferUserId;
    }

    //EIN = employer identification number
    public String getIdProoferEIN() {
        return idProoferEIN;
    }
    public void setIdProoferEIN(String idProoferEIN) {
        this.idProoferEIN = idProoferEIN;
    }

    public String getInPersonProofingLocation() {
        return this.inPersonProofingLocation;
    }
    public void setInPersonProofingLocation(String inPersonProofingLocation) {
        this.inPersonProofingLocation = inPersonProofingLocation;
    }
    public String getVisualAlertLocation() {
        return visualAlertLocation;
    }
    public void setVisualAlertLocation(String visualAlertLocation) {
        this.visualAlertLocation = visualAlertLocation;
    }
    public String getAudioAlertLocation() {
        return audioAlertLocation;
    }
    public void setAudioAlertLocation(String audioAlertLocation) {
        this.audioAlertLocation = audioAlertLocation;
    }
    public String getRecordLocator() {
        return this.recordLocator;
    }
    public void setRecordLocator(String recordLocator) {
        this.recordLocator = recordLocator;
    }
    public Timestamp getTransactionStartDatetime() {
        return this.transactionStartDatetime;
    }
    public void setTransactionStartDatetime(Timestamp transactionStartDatetime) {
        this.transactionStartDatetime = transactionStartDatetime;
    }
    public Timestamp getTransactionEndDatetime() {
        return this.transactionEndDatetime;
    }
    public void setTransactionEndDatetime(Timestamp transactionEndDatetime) {
        this.transactionEndDatetime = transactionEndDatetime;
    }
    public Timestamp getVisualAlertDatetime() {
        return visualAlertDatetime;
    }
    public void setVisualAlertDatetime(Timestamp visualAlertDatetime) {
        this.visualAlertDatetime = visualAlertDatetime;
    }
    public Timestamp getAudioAlertDatetime() {
        return audioAlertDatetime;
    }
    public void setAudioAlertDatetime(Timestamp audioAlertDatetime) {
        this.audioAlertDatetime = audioAlertDatetime;
    }
    public Date getUpdateDate() {
        return this.updateDate;
    }
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    public Date getAppointmentDate() {
        return appointmentDate;
    }
    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }
    public String getAppointmentTime() {
        return appointmentTime;
    }
    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }
    public String getInPersonProofingType() {
        return inPersonProofingType;
    }
    public void setInPersonProofingType(String inPersonProofingType) {
        this.inPersonProofingType = inPersonProofingType;
    }
    public String getAddress1() {
        return address1;
    }
    public void setAddress1(String address1) {
        this.address1 = address1;
    }
    public String getAddress2() {
        return address2;
    }
    public void setAddress2(String address2) {
        this.address2 = address2;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getZip4() {
        return zip4;
    }
    public void setZip4(String zip4) {
        this.zip4 = zip4;
    }
    public String getZip5() {
        return zip5;
    }
    public void setZip5(String zip5) {
        this.zip5 = zip5;
    }
    public short getDeliveryPoint() {
        return deliveryPoint;
    }
    public void setDeliveryPoint(short deliveryPoint) {
        this.deliveryPoint = deliveryPoint;
    }
    public String getCarrierRoute() {
        return carrierRoute;
    }
    public void setCarrierRoute(String carrierRoute) {
        this.carrierRoute = carrierRoute;
    }
    public double getLatitude() {
        return latitude;
    }
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }
    public double getLongitude() {
        return longitude;
    }
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    // geographic fence breach date time (when in person proofing device left the post office)
    public Timestamp getGeoFenceBreachDatetime() {
        return geoFenceBreachDatetime;
    }
    public void setGeoFenceBreachDatetime(Timestamp geoFenceBreachDatetime) {
        this.geoFenceBreachDatetime = geoFenceBreachDatetime;
    }

    public Person getPerson() {
        return this.person;
    }
    public void setPerson(Person person) {
        this.person = person;
    }

    //reference id corresponding to the value of in person proofing event status
    public RefIppEventStatus getRefIppEventStatus() {
        return this.refIppEventStatus;
    }
    public void setRefIppEventStatus(RefIppEventStatus refIppEventStatus) {
        this.refIppEventStatus = refIppEventStatus;
    }

    //reference id corresponding to the value of primary id type
    public RefPrimaryIdType getRefPrimaryIdType() {
        return this.refPrimaryIdType;
    }
    public void setRefPrimaryIdType(RefPrimaryIdType refPrimaryIdType) {
        this.refPrimaryIdType = refPrimaryIdType;
    }

     //id corresponding to the value of secondary id type
    public RefSecondaryIdType getRefSecondaryIdType() {
        return this.refSecondaryIdType;
    }
    public void setRefSecondaryIdType(RefSecondaryIdType refSecondaryIdType) {
        this.refSecondaryIdType = refSecondaryIdType;
    }

    //reference id corresponding to the value of in person proofing failure reason
    public RefIppFailureReason getRefIppFailureReason() {
        return refIppFailureReason;
    }
    public void setRefIppFailureReason(RefIppFailureReason refIppFailureReason) {
        this.refIppFailureReason = refIppFailureReason;
    }        

     //reference id corresponding to the value of state
    public RefState getRefState() {
        return refState;
    }
    public void setRefState(RefState refState) {
        this.refState = refState;
    }

    public IppAppointment getIppAppointment() {
        return ippAppointment;
    }
    public void setIppAppointment(IppAppointment ippAppointment) {
        this.ippAppointment = ippAppointment;
    }

     //reference id corresponding to the value of level of assurance level
    public RefLoaLevel getRefLoaLevel() {
        return refLoaLevel;
    }
    public void setRefLoaLevel(RefLoaLevel refLoaLevel) {
        this.refLoaLevel = refLoaLevel;
    }

     //reference id corresponding to the value of fac facility
    public RefFacFacility getRefFacFacility() {
        return refFacFacility;
    }
    public void setRefFacFacility(RefFacFacility refFacFacility) {
        this.refFacFacility = refFacFacility;
    }

    //reference id corresponding to the value of Ref Ipp Aplications
    public RefIppApplications getRefIppApplications() {
        return refIppApplications;
    }
    public void setRefIppApplications(RefIppApplications refIppApplications) {
        this.refIppApplications = refIppApplications;
    }
    
    public boolean isSelected() {
        return selected;
    }
    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    
    public RefIppEventStatus getAgencyPolicyProofingResult() {
        return agencyPolicyProofingResult;
    }
    
    public void setAgencyPolicyProofingResult(RefIppEventStatus agencyPolicyProofingResult) {
        this.agencyPolicyProofingResult = agencyPolicyProofingResult;
    }
    
    public RefApp getTransactionOriginId() {
        return transactionOriginId;
    }
    public void setTransactionOriginId(RefApp transactionOriginId) {
        this.transactionOriginId = transactionOriginId;
    }
    
    @Override
    public int compareTo(IppEvent o) {        
        if(this.createDate.getTime() - o.getCreateDate().getTime() > 0){
            return 1;
        } 
        if (this.createDate.getTime() - o.getCreateDate().getTime() < 0){
            return -1;
        } 
        return 0;
    }

    public String getFormattedEndDateTime() {
        return DateTimeUtil.getDateString(transactionEndDatetime, "dd-MMM-yy hh:mm:ss a");
    }
    
    public String getProoferName() {
        if (getIdProoferFirstName() == null) {
            return "";
        }
        return getIdProoferFirstName() + " " + getIdProoferLastName();
    }
    
    public RefIppWorkflows getRefIppWorkflow() {
        return refIppWorkflow;
    }
    
    public void setRefIppWorkflow(RefIppWorkflows refIppWorkflow) {
        this.refIppWorkflow = refIppWorkflow;
    }
    
    public List<IppEventSecondaryID> getSecondaryIDs() {
        if (secondaryIDs == null) {
            secondaryIDs = new ArrayList<>();
        }
        
        return this.secondaryIDs;
    }
    
    public void setSecondaryIDs(List<IppEventSecondaryID> secondaryIDs) {
        this.secondaryIDs = secondaryIDs;
    }
    
    public IppEventSecondaryID addSecondaryID(IppEventSecondaryID secondary) {
        secondary.setIppEventId(this.getIppEventId());
        getSecondaryIDs().add(secondary);
        return secondary;
    }
    
    public List<IppEventIDValidation> getEventIDValidations() {
        if (eventIDValidations == null) {
            eventIDValidations = new ArrayList<>();
        }
        
        return this.eventIDValidations;
    }
    
    public void setEventIDValidations(List<IppEventIDValidation> eventIDValidations) {
        this.eventIDValidations = eventIDValidations;
    }
    
    public IppEventIDValidation addEventIDValidation(IppEventIDValidation validation) {
        getEventIDValidations().add(validation);
        validation.setIppEventId(this.ippEventId);

        return validation;
    }
    
    public List<IdVerifyServiceRequest> getRecievedPrimaryIds() {
		return recievedPrimaryIds;
	}
	public void setRecievedPrimaryIds(List<IdVerifyServiceRequest> recievedPrimaryIds) {
		this.recievedPrimaryIds = recievedPrimaryIds;
	}
	public List<IdImages> getRecievedfairIds() {
		return recievedfairIds;
	}
	public void setRecievedfairIds(List<IdImages> recievedfairIds) {
		this.recievedfairIds = recievedfairIds;
	}
	public long getScanCount() {
        return scanCount;
    }
    
    public void setScanCount(long scanCount) {
        this.scanCount = scanCount;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((address1 == null) ? 0 : address1.hashCode());
        result = prime * result + ((address2 == null) ? 0 : address2.hashCode());
        result = prime * result + ((appointmentDate == null) ? 0 : appointmentDate.hashCode());
        result = prime * result + ((appointmentTime == null) ? 0 : appointmentTime.hashCode());
        result = prime * result + ((audioAlertDatetime == null) ? 0 : audioAlertDatetime.hashCode());
        result = prime * result + ((audioAlertLocation == null) ? 0 : audioAlertLocation.hashCode());
        result = prime * result + ((carrierRoute == null) ? 0 : carrierRoute.hashCode());
        result = prime * result + ((city == null) ? 0 : city.hashCode());
        result = prime * result + ((confirmationNumber == null) ? 0 : confirmationNumber.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + deliveryPoint;
        result = prime * result + ((fraudSuspected == null) ? 0 : fraudSuspected.hashCode());
        result = prime * result + ((geoFenceBreachDatetime == null) ? 0 : geoFenceBreachDatetime.hashCode());
        result = prime * result + ((idProoferEIN == null) ? 0 : idProoferEIN.hashCode());
        result = prime * result + ((idProoferFirstName == null) ? 0 : idProoferFirstName.hashCode());
        result = prime * result + ((idProoferLastName == null) ? 0 : idProoferLastName.hashCode());
        result = prime * result + ((idProoferUserId == null) ? 0 : idProoferUserId.hashCode());
        result = prime * result + ((inPersonProofingLocation == null) ? 0 : inPersonProofingLocation.hashCode());
        result = prime * result + ((inPersonProofingType == null) ? 0 : inPersonProofingType.hashCode());
        result = prime * result + (int) (ippEventId ^ (ippEventId >>> 32));
        long temp;
        temp = Double.doubleToLongBits(latitude);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(longitude);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((recordLocator == null) ? 0 : recordLocator.hashCode());
        result = prime * result + (int) (scanCount ^ (scanCount >>> 32));
        result = prime * result + (selected ? 1231 : 1237);
        result = prime * result + ((transactionEndDatetime == null) ? 0 : transactionEndDatetime.hashCode());
        result = prime * result + ((transactionStartDatetime == null) ? 0 : transactionStartDatetime.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        result = prime * result + ((visualAlertDatetime == null) ? 0 : visualAlertDatetime.hashCode());
        result = prime * result + ((visualAlertLocation == null) ? 0 : visualAlertLocation.hashCode());
        result = prime * result + ((zip4 == null) ? 0 : zip4.hashCode());
        result = prime * result + ((zip5 == null) ? 0 : zip5.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        IppEvent other = (IppEvent) obj;
        if (address1 == null) {
            if (other.address1 != null)
                return false;
        } else if (!address1.equals(other.address1))
            return false;
        if (address2 == null) {
            if (other.address2 != null)
                return false;
        } else if (!address2.equals(other.address2))
            return false;
        if (appointmentDate == null) {
            if (other.appointmentDate != null)
                return false;
        } else if (!appointmentDate.equals(other.appointmentDate))
            return false;
        if (appointmentTime == null) {
            if (other.appointmentTime != null)
                return false;
        } else if (!appointmentTime.equals(other.appointmentTime))
            return false;
        if (audioAlertDatetime == null) {
            if (other.audioAlertDatetime != null)
                return false;
        } else if (!audioAlertDatetime.equals(other.audioAlertDatetime))
            return false;
        if (audioAlertLocation == null) {
            if (other.audioAlertLocation != null)
                return false;
        } else if (!audioAlertLocation.equals(other.audioAlertLocation))
            return false;
        if (carrierRoute == null) {
            if (other.carrierRoute != null)
                return false;
        } else if (!carrierRoute.equals(other.carrierRoute))
            return false;
        if (city == null) {
            if (other.city != null)
                return false;
        } else if (!city.equals(other.city))
            return false;
        if (confirmationNumber == null) {
            if (other.confirmationNumber != null)
                return false;
        } else if (!confirmationNumber.equals(other.confirmationNumber))
            return false;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (deliveryPoint != other.deliveryPoint)
            return false;
        if (fraudSuspected == null) {
            if (other.fraudSuspected != null)
                return false;
        } else if (!fraudSuspected.equals(other.fraudSuspected))
            return false;
        if (geoFenceBreachDatetime == null) {
            if (other.geoFenceBreachDatetime != null)
                return false;
        } else if (!geoFenceBreachDatetime.equals(other.geoFenceBreachDatetime))
            return false;
        if (idProoferEIN == null) {
            if (other.idProoferEIN != null)
                return false;
        } else if (!idProoferEIN.equals(other.idProoferEIN))
            return false;
        if (idProoferFirstName == null) {
            if (other.idProoferFirstName != null)
                return false;
        } else if (!idProoferFirstName.equals(other.idProoferFirstName))
            return false;
        if (idProoferLastName == null) {
            if (other.idProoferLastName != null)
                return false;
        } else if (!idProoferLastName.equals(other.idProoferLastName))
            return false;
        if (idProoferUserId == null) {
            if (other.idProoferUserId != null)
                return false;
        } else if (!idProoferUserId.equals(other.idProoferUserId))
            return false;
        if (inPersonProofingLocation == null) {
            if (other.inPersonProofingLocation != null)
                return false;
        } else if (!inPersonProofingLocation.equals(other.inPersonProofingLocation))
            return false;
        if (inPersonProofingType == null) {
            if (other.inPersonProofingType != null)
                return false;
        } else if (!inPersonProofingType.equals(other.inPersonProofingType))
            return false;
        if (ippEventId != other.ippEventId)
            return false;
        if (Double.doubleToLongBits(latitude) != Double.doubleToLongBits(other.latitude))
            return false;
        if (Double.doubleToLongBits(longitude) != Double.doubleToLongBits(other.longitude))
            return false;
        if (recordLocator == null) {
            if (other.recordLocator != null)
                return false;
        } else if (!recordLocator.equals(other.recordLocator))
            return false;
        if (scanCount != other.scanCount)
            return false;
        if (selected != other.selected)
            return false;
        if (transactionEndDatetime == null) {
            if (other.transactionEndDatetime != null)
                return false;
        } else if (!transactionEndDatetime.equals(other.transactionEndDatetime))
            return false;
        if (transactionStartDatetime == null) {
            if (other.transactionStartDatetime != null)
                return false;
        } else if (!transactionStartDatetime.equals(other.transactionStartDatetime))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        if (visualAlertDatetime == null) {
            if (other.visualAlertDatetime != null)
                return false;
        } else if (!visualAlertDatetime.equals(other.visualAlertDatetime))
            return false;
        if (visualAlertLocation == null) {
            if (other.visualAlertLocation != null)
                return false;
        } else if (!visualAlertLocation.equals(other.visualAlertLocation))
            return false;
        if (zip4 == null) {
            if (other.zip4 != null)
                return false;
        } else if (!zip4.equals(other.zip4))
            return false;
        if (zip5 == null) {
            if (other.zip5 != null)
                return false;
        } else if (!zip5.equals(other.zip5))
            return false;
        return true;
    }
}