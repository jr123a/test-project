package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ref_sponsor database table.
 * 
 */
@Entity
@Table(name="ref_id_validation_vendors")
@NamedQueries({
    @NamedQuery(name="RefIdValidationVendor.findAll", query="SELECT r FROM RefIdValidationVendor r")
})    
public class RefIdValidationVendor implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final long EQUIFAX_VENDOR_ID = 1L;
    public static final long LEXISNEXIS_VENDOR_ID = 3L;

    @Id
    @Column(name="VENDOR_ID")
    private long vendorId;

    @Column(name="VENDOR_NAME")
    private String vendorName;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;
    
    public long getVendorId() {
        return vendorId;
    }

    public void setVendorId(long vendorId) {
        this.vendorId = vendorId;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }
    
    public boolean isEquifax() {
        return "Equifax".equalsIgnoreCase(getVendorName());
    }

    public boolean isLexisNexis() {
        return "Lexis Nexis".equalsIgnoreCase(getVendorName());
    }
    
    public boolean isSocure() {
        return "Socure".equalsIgnoreCase(getVendorName());
    }
}
