package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the sponsor_strong_ids database table.
 * 
 */
@Entity
@Table(name = "sponsor_strong_ids")
@NamedQuery(name = "SponsorStrongId.findAll", query = "SELECT s FROM SponsorStrongId s")
@NamedQuery(name = "SponsorStrongId.findByPrimaryKey", query = "SELECT s FROM SponsorStrongId s WHERE s.id.sponsorId = :sponsorId AND s.id.idType = :idType")
@NamedQuery(name = "SponsorStrongId.findBySponsor", query = "SELECT s FROM SponsorStrongId s WHERE s.id.sponsorId = :sponsorId")
@NamedQuery(name = "SponsorStrongId.getPrimaryIdCountForSponsor", query = "SELECT COUNT(i) FROM SponsorStrongId i WHERE i.id.idType = :idType")
@NamedQuery(name="SponsorStrongId.findSponsorStrongIdBySponsor", query="SELECT r FROM SponsorStrongId r WHERE r.id.sponsorId = :sponsorId")

public class SponsorStrongId implements Serializable {
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private SponsorStrongIdPK id;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public SponsorStrongIdPK getId() {
        return id;
    }

    public void setId(SponsorStrongIdPK id) {
        this.id = id;
    }

}
