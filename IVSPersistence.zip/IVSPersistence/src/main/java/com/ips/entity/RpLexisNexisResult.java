package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;


/**
 * The persistent class for the rp_lexis_nexis_result database table.
 * 
 */
@Entity
@Table(name="rp_lexisnexis_result")
@NamedQueries({
    @NamedQuery(name="lnResults.findAll", query = "Select r FROM RpLexisNexisResult r"),
    @NamedQuery(name="lnResults.findByEvent", query = "Select r FROM RpLexisNexisResult r WHERE r.rpEvent = :event")})
public class RpLexisNexisResult implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="EVENT_ID")
    private long eventId;

    @Column(name="REQUEST")
    private String request;
    
    @Column(name="RESPONSE")
    private String response;
    
    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;
    
    @Column(name="QUIZ_SCORE")
    private String quizScore;

    //bi-directional many-to-one association to RefLexisNexisResponseCode
    @ManyToOne
    @JoinColumn(name="Response_Code")
    private RefLexisNexisResponseCode refLexisNexisResponseCode;
    
    //bi-directional many-to-one association to RpLexisNexisFinalReasonCode
        @OneToMany(mappedBy="rpLexisNexisResult", cascade=CascadeType.ALL, fetch=FetchType.EAGER)
        private List<RpLexisNexisFinalReasonCode> rpLexisNexisFinalReasonCodes;

    //bi-directional one-to-one association to RpEvent
    @OneToOne
    @JoinColumn(name="Event_ID" , insertable = false, updatable = false )
    private RpEvent rpEvent;

    public long getEventId() {
        return this.eventId;
    }

    public void setEventId(long eventId) {
        this.eventId = eventId;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public String getQuizScore() {
        return quizScore;
    }

    public void setQuizScore(String quizScore) {
        this.quizScore = quizScore;
    }

    public RefLexisNexisResponseCode getRefLexisNexisResponseCode() {
        return this.refLexisNexisResponseCode;
    }

    public void setRefLexisNexisResponseCode(RefLexisNexisResponseCode refLexisNexisResponseCode) {
        this.refLexisNexisResponseCode = refLexisNexisResponseCode;
    }

    public RpEvent getRpEvent() {
        return this.rpEvent;
    }

    public void setRpEvent(RpEvent rpEvent) {
        this.rpEvent = rpEvent;
    }
    
    public RpLexisNexisFinalReasonCode addRpLexisNexisFinalReasonCode(RpLexisNexisFinalReasonCode rpLexisNexisFinalReasonCode) {
        getRpLexisNexisFinalReasonCodes().add(rpLexisNexisFinalReasonCode);
        rpLexisNexisFinalReasonCode.setRpLexisNexisResult(this);

        return rpLexisNexisFinalReasonCode;
    }

    public List<RpLexisNexisFinalReasonCode> getRpLexisNexisFinalReasonCodes() {
        if (rpLexisNexisFinalReasonCodes == null) {
            rpLexisNexisFinalReasonCodes = new ArrayList<>();
        }
        
        return rpLexisNexisFinalReasonCodes;
    }

    public void setRpLexisNexisFinalReasonCodes(List<RpLexisNexisFinalReasonCode> rpLexisNexisFinalReasonCodes) {
        this.rpLexisNexisFinalReasonCodes = rpLexisNexisFinalReasonCodes;
    }

	public String getRequest() {
		return request;
	}

	public String getResponse() {
		return response;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public void setResponse(String response) {
		this.response = response;
	}

}
