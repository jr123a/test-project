package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ref_rp_decision_code database table.
 * 
 */
@Entity
@Table(name="ref_rp_decision_code")
public class RefRpDecisionCode implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String DECISION_PASS = "PASS";
    public static final String DECISION_FAIL = "FAIL";
    public static final String DECISION_PENDING = "PENDING";

    @Id
    @Column(name = "DECISION_CODE")
    private String decisionCode;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "DECISION_DESCRIPTION")
    private String decisionDescription;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;

    //bi-directional many-to-one association to RpEvent
    @OneToMany(mappedBy="refRpDecisionCode")
    private List<RpEvent> rpEvents;

    public String getDecisionCode() {
        return this.decisionCode;
    }

    public void setDecisionCode(String decisionCode) {
        this.decisionCode = decisionCode;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getDecisionDescription() {
        return this.decisionDescription;
    }

    public void setDecisionDescription(String decisionDescription) {
        this.decisionDescription = decisionDescription;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<RpEvent> getRpEvents() {
        return this.rpEvents;
    }

    public void setRpEvents(List<RpEvent> rpEvents) {
        this.rpEvents = rpEvents;
    }

    public RpEvent addRpEvent(RpEvent rpEvent) {
        getRpEvents().add(rpEvent);
        rpEvent.setRefRpDecisionCode(this);

        return rpEvent;
    }

    public RpEvent removeRpEvent(RpEvent rpEvent) {
        getRpEvents().remove(rpEvent);
        rpEvent.setRefRpDecisionCode(null);

        return rpEvent;
    }

}
