package com.ips.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "sponsor_tokens")
@NamedQuery(name = "SponsorTokens.getToken", query = "select i.accessToken from SponsorTokens i where i.sponsorId = :sponsorId")
@NamedQuery(name = "SponsorTokens.getExpiration", query = "select i.expirationTime from SponsorTokens i where i.sponsorId = :sponsorId")
@NamedQuery(name="SponsorTokens.findSponsorTokensBySponsor", query="SELECT r FROM SponsorTokens r WHERE r.sponsorId = :sponsorId")

public class SponsorTokens {

    @Id
    @Column(name = "SPONSOR_ID")
    private long sponsorId;

    @Column(name = "ACCESS_TOKEN")
    private String accessToken;

    @Column(name = "EXPIRATION_TIME")
    private Timestamp expirationTime;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;

    public long getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public Timestamp getExpirationTime() {
        return expirationTime;
    }

    public void setExpirationTime(Timestamp expirationTime) {
        this.expirationTime = expirationTime;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

}
