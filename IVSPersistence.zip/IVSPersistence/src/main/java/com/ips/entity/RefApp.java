package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="ref_app")
@NamedQueries({
    @NamedQuery(name="RefApp.findAll", query="SELECT r FROM RefApp r"),
    @NamedQuery(name="RefApp.findByAppName", query="SELECT r FROM RefApp r WHERE r.appName = :appName"),
    @NamedQuery(name="RefApp.findByAppId", query="SELECT r FROM RefApp r WHERE r.appId = :appId"),
    @NamedQuery(name="RefApp.findByAppIdList", query="SELECT r FROM RefApp r WHERE r.appId IN :appIdList"),
    @NamedQuery(name="RefApp.findByCustomerCategoryId", query="SELECT r FROM RefApp r WHERE r.customerCategoryId = :customerCategoryId"),
})    
public class RefApp implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String INFORMED_DELIVERY = "Informed Delivery";
    public static final String HOLD_MAIL = "Hold Mail";
    public static final String SOCIAL_SECURITY_ADMINISTRATION = "Social Security Administration";
    public static final long INFORMED_DELIVERY_APP_ID = 1L;
    public static final long HOLD_MAIL_APP_ID = 2L;

    @Id
    @Column(name="APP_ID")
    private long appId;

    @Column(name="APP_NAME")
    private String appName;


    @Column(name="CUSTOMER_CATEGORY_ID")
    private long customerCategoryId;

    @Column(name="WORKFLOW_API_CODES")
    private String workflowApiCodes ;
    
    @Column(name = "CREATE_DATE")
    private Date createDate;
    
    @Column(name = "UPDATE_DATE")
    private Date updateDate;

	@Transient 
	private boolean isModifiable;
	
    public long getAppId() {
        return appId;
    }

    public void setAppId(long appId) {
        this.appId = appId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
	}
	
	public boolean isModifiable() {
		return isModifiable;
	}

	public void setModifiable(boolean isModifiable) {
		this.isModifiable = isModifiable;
    }

    public long getCustomerCategoryId() {
        return customerCategoryId;
    }

    public void setCustomerCategoryId(long customerCategoryId) {
        this.customerCategoryId = customerCategoryId;
    }

    public String getWorkflowApiCodes() {
        return workflowApiCodes;
    }

    public void setWorkflowApiCodes(String workflowApiCodes) {
        this.workflowApiCodes = workflowApiCodes;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (appId ^ (appId >>> 32));
        result = prime * result + ((appName == null) ? 0 : appName.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefApp other = (RefApp) obj;
        if (appId != other.appId)
            return false;
        if (appName == null) {
            if (other.appName != null)
                return false;
        } else if (!appName.equals(other.appName))
            return false;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "RefApp{" +
                "appId=" + appId +
                ", appName='" + appName + '\'' +
                ", customerCategoryId=" + customerCategoryId +
                ", workflowApiCodes='" + workflowApiCodes + '\'' +
                ", createDate=" + createDate +
                ", updateDate=" + updateDate +
                ", isModifiable=" + isModifiable +
                '}';
    }
}
