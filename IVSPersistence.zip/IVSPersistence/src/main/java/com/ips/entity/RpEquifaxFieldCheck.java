package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the rp_equifax_field_checks database table.
 * 
 */
@Entity
@Table(name="rp_equifax_field_checks")
public class RpEquifaxFieldCheck implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="EFXFieldCheckSeq")
    @SequenceGenerator(name="EFXFieldCheckSeq",sequenceName="SEQ_FIELD_CHECK_FAILURE_ID", allocationSize=1)
    @Column(name="FIELD_CHECK_FAILURE_ID")
    private long fieldCheckFailureId;
    
    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    //bi-directional many-to-one association to RefFieldCheck
    @ManyToOne
    @JoinColumn(name="REF_FIELD_CHECK_ID")
    private RefFieldCheck refFieldCheck;

    //bi-directional many-to-one association to RpEvent
    @ManyToOne
    @JoinColumn(name="EVENT_ID")
    private RpEvent rpEvent;

    public RefFieldCheck getRefFieldCheck() {
        return refFieldCheck;
    }

    public void setRefFieldCheck(RefFieldCheck refFieldCheck) {
        this.refFieldCheck = refFieldCheck;
    }

    public RpEvent getRpEvent() {
        return rpEvent;
    }

    public void setRpEvent(RpEvent rpEvent) {
        this.rpEvent = rpEvent;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

}
