package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the ref_relying_party database table.
 * 
 */
@Entity
@Table(name="ref_relying_party")
@NamedQueries({
    @NamedQuery(name="RefRelyingParty.findAll", query="SELECT r FROM RefRelyingParty r"),
    @NamedQuery(name="RefRelyingParty.findByAcronym", query="SELECT r FROM RefRelyingParty r WHERE r.relyingPartyAcronym = :acronym")
})    
public class RefRelyingParty implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String VA = "VA";

    @Id
    @Column(name="relying_party_code")
    private long relyingPartyCode;

    @Column(name="relying_party_acronym")
    private String relyingPartyAcronym;
    
    @Column(name="relying_party_description")
    private String relyingPartyDescription;

    public long getRelyingPartyCode() {
        return relyingPartyCode;
    }

    public void setRelyingPartyCode(long relyingPartyCode) {
        this.relyingPartyCode = relyingPartyCode;
    }

    public String getRelyingPartyAcronym() {
        return relyingPartyAcronym;
    }

    public void setRelyingPartyAcronym(String relyingPartyAcronym) {
        this.relyingPartyAcronym = relyingPartyAcronym;
    }

    public String getRelyingPartyDescription() {
        return relyingPartyDescription;
    }

    public void setRelyingPartyDescription(String relyingPartyDescription) {
        this.relyingPartyDescription = relyingPartyDescription;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((relyingPartyAcronym == null) ? 0 : relyingPartyAcronym.hashCode());
        result = prime * result + (int) (relyingPartyCode ^ (relyingPartyCode >>> 32));
        result = prime * result + ((relyingPartyDescription == null) ? 0 : relyingPartyDescription.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefRelyingParty other = (RefRelyingParty) obj;
        if (relyingPartyAcronym == null) {
            if (other.relyingPartyAcronym != null)
                return false;
        } else if (!relyingPartyAcronym.equals(other.relyingPartyAcronym))
            return false;
        if (relyingPartyCode != other.relyingPartyCode)
            return false;
        if (relyingPartyDescription == null) {
            if (other.relyingPartyDescription != null)
                return false;
        } else if (!relyingPartyDescription.equals(other.relyingPartyDescription))
            return false;
        return true;
    }
}
