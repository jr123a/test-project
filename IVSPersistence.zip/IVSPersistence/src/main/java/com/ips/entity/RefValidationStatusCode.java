package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ref_sponsor database table.
 * 
 */
@Entity
@Table(name="ref_validation_status_codes")
@NamedQueries({
    @NamedQuery(name="RefValidationStatusCode.findByCode", query="SELECT r FROM RefValidationStatusCode r WHERE r.statusCode = :code")
})    
public class RefValidationStatusCode implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="STATUS_ID")
    private long statusId;

    @Column(name="STATUS_CODE")
    private String statusCode;
    
    @Column(name="DETAILED_MESSAGE")
    private String detailedMessage;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;
    

    public long getStatusId() {
        return statusId;
    }

    public void setStatusId(long statusId) {
        this.statusId = statusId;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getDetailedMessage() {
        return detailedMessage;
    }

    public void setDetailedMessage(String detailedMessage) {
        this.detailedMessage = detailedMessage;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }
    
    public boolean isPendingDecision() {
        return "PENDING_DECISION".equalsIgnoreCase(getStatusCode());
    }

}
