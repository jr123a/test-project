package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "sponsor_application_map")
@NamedQueries({
    @NamedQuery(name="SponsorApplicationMap.getAllRelations", query="SELECT s FROM SponsorApplicationMap s"),
    @NamedQuery(name="SponsorApplicationMap.getRelationsBySponsor", query="SELECT s FROM SponsorApplicationMap s WHERE s.id.sponsorId = :sponsorId"),
    @NamedQuery(name="SponsorApplicationMap.getRelationsByApplication", query="SELECT s FROM SponsorApplicationMap s WHERE s.id.appId = :appId"),
    @NamedQuery(name="SponsorApplicationMap.getRelationBySponsorAndApplication", query="SELECT s FROM SponsorApplicationMap s WHERE s.id.sponsorId = :sponsorId AND s.id.appId = :appId")
})
public class SponsorApplicationMap implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @EmbeddedId
    private SponsorApplicationMapPK id;
    
    @MapsId("sponsorId")
    @JoinColumn(name = "sponsor_id")
    @OneToOne
    private RefSponsor sponsor;
    
    @MapsId("appId")
    @JoinColumn(name = "app_id")
    @OneToOne
    private RefApp app;
    
    @Column(name = "activation_date")
    private Date activationDate;
    
    @Column(name = "deactivation_date")
    private Date deactivationDate;
    
    @Column(name = "create_date")
    private Date createDate;
    
    @Column(name = "update_date")
    private Date updateDate;
    
    public RefSponsor getSponsor() {
        return sponsor;
    }
    public void setSponsor(RefSponsor sponsor) {
        this.sponsor = sponsor;
    }
    
    public RefApp getApp() {
        return app;
    }
    public void setApp(RefApp app) {
        this.app = app;
    }
    
    public SponsorApplicationMapPK getId() {
        return id;
    }
    public void setId(SponsorApplicationMapPK id) {
        this.id = id;
    }
    
    public Date getActivationDate() {
        return activationDate;
    }
    public void setActivationDate(Date activationDate) {
        this.activationDate = activationDate;
    }
    
    public Date getDeactivationDate() {
        return deactivationDate;
    }
    public void setDeactivationDate(Date deactivationDate) {
        this.deactivationDate = deactivationDate;
    }
    
    public Date getCreateDate() {
        return createDate;
    }
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
    
    public Date getUpdateDate() {
        return updateDate;
    }
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    
    /**
     * @return true if activationDate is before or equal to today. If the deactivationDate is not null, then deactivationDate is after or equal to today.
     */
    public boolean isActive() {
        Date now = new Date();
        int activationDateBeforeOrEqualToToday = activationDate.compareTo(now);
        boolean isActive = activationDateBeforeOrEqualToToday <= 0;
        if (deactivationDate != null) {
            isActive = isActive && deactivationDate.compareTo(now) >= 0;
        }
        
        return isActive;
    }
}
