package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ref_admin_event database table.
 * 
 */
@Entity
@Table(name="ref_admin_event")
@NamedQueries({
    @NamedQuery(name="RefAdminEvent.findAll", query="SELECT a FROM RefAdminEvent a"),    
    @NamedQuery(name="RefAdminEvent.findByDescription", query="SELECT a FROM RefAdminEvent a WHERE a.adminEventDescription = :description"),
    @NamedQuery(name="RefAdminEvent.findByLikeDescription", query="SELECT a FROM RefAdminEvent a WHERE a.adminEventDescription like '% :description %'")
})
public class RefAdminEvent implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String ADMIN_LOGIN = "has logged in at ";
    public static final String ADMIN_SET_LOA15_OTP_PERCENTAGES = "has changed LOA 1.5 KBA percentages.";
    public static final String ADMIN_SET_LOA15_INF_PV_PERCENTAGES = "has changed LOA 1.5 PV percentages for Individual-Not-Found device reputation.";
    public static final String ADMIN_LOCKED_OUT = "has been locked out at ";
    public static final String ADMIN_ADDED_MPOS_FACILITIES =  "has added mPOS facilities at ";
    public static final String ADMIN_REMOVED_MPOS_FACILITIES = "has removed mPOS facilities at ";
    public static final String ADMIN_HIGH_RISK_THRESHOLD = "has changed High Risk Address Threshold to ";
    public static final String ADMIN_HIGH_RISK_RETENTION = "has changed High Risk Address Retention Period to ";
    public static final String ADMIN_HIGH_RISK_ACTIVATION = "has changed High Risk Address switch to ";
    public static final String ADMIN_DEVICE_REPUTATION_ACTIVATION = "has changed device reputation for ";
    public static final String ADMIN_DEVICE_REPUTATION_THROTTLE = "has changed device reputation volume throttle percentages.";
    public static final String ADMIN_VELOCITY_TIMER = "has changed the velocity timer to ";
    public static final String ADMIN_EXTERNAL_AGENCY_FACILITIES = "has changed the list of pilot sites for ";
    public static final String ADMIN_EXTERNAL_AGENCY_FLAGS = "has changed the active and sublist flags for ";
    public static final String ADMIN_IPP_EMAILS = "has changed the IPP emails for ";
    public static final String ADMIN_EXTERNAL_AGENCY_API = "has changed the API configuration for ";
    public static final String ADMIN_AUTO_RECIPIENT_EMAILS = "has changed recipient email addresses for ";
    public static final String ADMIN_HOLDMAIL_FLAG = "has changed holdmail flow to ";
    public static final String ADMIN_IAL2_CONFIRMATION_NOTIFICATION = "has changed IAL-2 confirmation notification for ";
    public static final String ADMIN_IAL2_CONFIG_REQUIRES_IAL2 = "has changed the requires IAL-2 indicator for ";
    public static final String ADMIN_IAL2_CONFIG_OPTION1_ENABLED = "has changed the Option 1 enabled indicator for ";
    public static final String ADMIN_IAL2_CONFIG_PRIMARY_VENDOR = "has changed the primary ID validation vendor for ";
    public static final String ADMIN_IAL2_CONFIG_BACKUP_VENDOR = "has changed the backup ID validation vendor for ";
    public static final String ADMIN_IAL2_CONFIG_STRONG_ID_LIST = "has changed the list of strong IDs for ";
    public static final String ADMIN_IAL2_CONFIG_FAIR_ID_LIST = "has changed the list of fair IDs for ";
    public static final String ADMIN_IAL2_VENDOR_CONFIGURATION_URL = "has changed the IAL-2 ID validation vendor url at ";
    public static final String ADMIN_IAL2_CONFIG_ID_VALIDATION_RETRY_ATTEMPTS = "has changed the max ID validation retry attempts for "; 
    public static final String ADD_PRIMARY_ID = "has added a Primary ID at ";
    public static final String UPDATE_PRIMARY_ID = "has edited a Primary ID at ";
    public static final String DELETE_PRIMARY_ID = "has deleted the Primary ID at ";
    public static final String ADD_SECONDARY_ID = "has added a Secondary ID at ";
    public static final String UPDATE_SECONDARY_ID = "has edited a Secondary ID at ";
    public static final String DELETE_SECONDARY_ID = "has deleted the Secondary ID at ";
    public static final String ADD_APPLICATION_WORKFLOW = "has added a new application workflow at ";
    public static final String UPDATE_APPLICATION_WORKFLOW = "has edited an application workflow at ";
    public static final String DELETE_APPLICATION_WORKFLOW = "has deleted a workflow at ";
    public static final String ADD_NEW_SPONSOR = "has added a new sponsor, ";
    public static final String UPDATE_SPONSOR = "has updated sponsor with ID ";
    public static final String UPDATE_APPLICATION_MAP = "has updated the application tied to ";
    public static final String ADMIN_ACCEPTABLE_IDS = "has changed the acceptable IDs for ";
    public static final String NEW_APPLICATION = "has added a new application at ";
    public static final String UPDATED_APPLICATION = "has updated application name at ";
    public static final String DELETED_SPONSOR = "has deleted sponsor at ";
    public static final String DELETED_APPLICATION = "has deleted application at ";
    public static final String CONFIGURE_APPLICATION = "has configured an application for ";
    public static final String DELETE_APPLICATION_MAP = "has deleted an application for ";
    public static final String LIMIT_IPP_SCAN_INDICATOR = "has changed the limit IPP scans indicator for ";
    public static final String MAX_IPP_SCAN_LIMIT = "has changed the maximum number of IPP scans for ";
    public static final String ADMIN_RETAIN_PII_CHANGE = "has changed the PII retention indicator for ";

    public static final String ADMIN_MIN_AGE_CHANGE = "has changed the min age config for ";
    
    @Id
    @Column(name="ADMIN_EVENT_ID")
    private long adminEventId;

    @Column(name="ADMIN_EVENT_DESCRIPTION")
    private String adminEventDescription;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    //bi-directional many-to-one association to RpAdmin
    @OneToMany(mappedBy="refAdminEvent")
    private List<RpAdmin> rpAdmins;

    public long getAdminEventId() {
        return this.adminEventId;
    }

    public void setAdminEventId(long adminEventId) {
        this.adminEventId = adminEventId;
    }

    public String getAdminEventDescription() {
        return this.adminEventDescription;
    }

    public void setAdminEventDescription(String adminEventDescription) {
        this.adminEventDescription = adminEventDescription;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<RpAdmin> getRpAdmins() {
        return this.rpAdmins;
    }

    public void setRpAdmins(List<RpAdmin> rpAdmins) {
        this.rpAdmins = rpAdmins;
    }

    public RpAdmin addRpAdmin(RpAdmin rpAdmin) {
        getRpAdmins().add(rpAdmin);
        rpAdmin.setRefAdminEvent(this);

        return rpAdmin;
    }

    public RpAdmin removeRpAdmin(RpAdmin rpAdmin) {
        getRpAdmins().remove(rpAdmin);
        rpAdmin.setRefAdminEvent(null);

        return rpAdmin;
    }

}
