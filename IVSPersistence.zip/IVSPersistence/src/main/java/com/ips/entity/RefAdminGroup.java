package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the ref_admin_group database table.
 * 
 */
@Entity
@Table(name="ref_admin_group")
@NamedQueries({
    @NamedQuery(name="RefAdminGroup.findAll", query="SELECT a FROM RefAdminGroup a"),
    @NamedQuery(name = "RefAdminGroup.findByGroupName", query = "SELECT a FROM RefAdminGroup a WHERE a.groupName = :name")
})
public class RefAdminGroup implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    public static final String ADMIN = "Admin";

    @Id
    @Column(name="REF_ADMIN_GROUP_ID")
    private long adminGroupId;

    @Column(name="GROUP_NAME")
    private String groupName;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    public long getAdminGroupId() {
        return adminGroupId;
    }

    public void setAdminGroupId(long adminGroupId) {
        this.adminGroupId = adminGroupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (adminGroupId ^ (adminGroupId >>> 32));
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((groupName == null) ? 0 : groupName.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefAdminGroup other = (RefAdminGroup) obj;
        if (adminGroupId != other.adminGroupId)
            return false;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (groupName == null) {
            if (other.groupName != null)
                return false;
        } else if (!groupName.equals(other.groupName))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }
}
