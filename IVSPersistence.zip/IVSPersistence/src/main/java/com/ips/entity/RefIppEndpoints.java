package com.ips.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "REF_IPP_ENDPOINTS")
@NamedQuery(name = "RefIppEndpoints.findByEndpointName", query = "SELECT r FROM RefIppEndpoints r WHERE r.endpointName = :endpointName")
public class RefIppEndpoints implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="ENDPOINT_ID")
    private long endpointId;
    
    @Column(name="ENDPOINT_NAME")
    private String endpointName;

    public long getEndpointId() {
        return endpointId;
    }

    public void setEndpointId(long endpointId) {
        this.endpointId = endpointId;
    }

    public String getEndpointName() {
        return endpointName;
    }

    public void setEndpointName(String endpointName) {
        this.endpointName = endpointName;
    }
}
