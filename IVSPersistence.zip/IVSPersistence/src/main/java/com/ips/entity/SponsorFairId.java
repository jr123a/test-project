package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the sponsor_fair_ids database table.
 * 
 */
@Entity
@Table(name = "sponsor_fair_ids")
@NamedQuery(name = "SponsorFairId.findAll", query = "SELECT s FROM SponsorFairId s")
@NamedQuery(name = "SponsorFairId.findByPrimaryKey", query = "SELECT s FROM SponsorFairId s WHERE s.id.sponsorId = :sponsorId AND s.id.idType = :idType")
@NamedQuery(name = "SponsorFairId.findBySponsor", query = "SELECT s FROM SponsorFairId s WHERE s.id.sponsorId = :sponsorId")
@NamedQuery(name = "SponsorFairId.getSecondaryIdCountForSponsor", query = "SELECT COUNT(i) FROM SponsorFairId i WHERE i.id.idType = :idType")
@NamedQuery(name="SponsorFairId.findSponsorFairIdBySponsor", query="SELECT r FROM SponsorFairId r WHERE r.id.sponsorId = :sponsorId")

public class SponsorFairId implements Serializable {
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private SponsorFairIdPK id;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public SponsorFairIdPK getId() {
        return id;
    }

    public void setId(SponsorFairIdPK id) {
        this.id = id;
    }

}
