package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.List;

/**
 * The persistent class for the ref_ipp_failure_reason database table.
 * 
 */
@Entity
@Table(name = "ref_ipp_failure_reason")
@NamedQuery(name = "RefIppFailureReason.findAll", query = "SELECT r FROM RefIppFailureReason r")
public class RefIppFailureReason implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final long MAX_RETRIES_ATTEMPTED = 10L;
    public static final long FRAUD_SUSPECTED = 11L;
    @Id
    @Column(name="failure_reason_code")
    private long failureReasonCode;

    @Column(name="create_date")
    private Timestamp createDate;
    
    @Column(name="reason_code_description")
    private String reasonCodeDescription;
    
    @Column(name="update_date")
    private Timestamp updateDate;

    // bi-directional many-to-one association to IppEvent
    @OneToMany(mappedBy = "refIppFailureReason")
    private List<IppEvent> ippEvents;

    public long getFailureReasonCode() {
        return this.failureReasonCode;
    }

    public void setFailureReasonCode(long failureReasonCode) {
        this.failureReasonCode = failureReasonCode;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getReasonCodeDescription() {
        return this.reasonCodeDescription;
    }

    public void setReasonCodeDescription(String reasonCodeDescription) {
        this.reasonCodeDescription = reasonCodeDescription;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<IppEvent> getIppEvents() {
        return this.ippEvents;
    }

    public void setIppEvents(List<IppEvent> ippEvents) {
        this.ippEvents = ippEvents;
    }

    public IppEvent addIppEvent(IppEvent ippEvent) {
        getIppEvents().add(ippEvent);
        ippEvent.setRefIppFailureReason(this);

        return ippEvent;
    }

    public IppEvent removeIppEvent(IppEvent ippEvent) {
        getIppEvents().remove(ippEvent);
        ippEvent.setRefIppFailureReason(null);

        return ippEvent;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + (int) (failureReasonCode ^ (failureReasonCode >>> 32));
        result = prime * result + ((reasonCodeDescription == null) ? 0 : reasonCodeDescription.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefIppFailureReason other = (RefIppFailureReason) obj;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (failureReasonCode != other.failureReasonCode)
            return false;
        if (reasonCodeDescription == null) {
            if (other.reasonCodeDescription != null)
                return false;
        } else if (!reasonCodeDescription.equals(other.reasonCodeDescription))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }

}
