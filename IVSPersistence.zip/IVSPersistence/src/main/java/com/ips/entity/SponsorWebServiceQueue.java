package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the SponsorWebServiceQueue database table.
 * 
 */
@Entity
@Table(name = "sponsor_web_service_queue")
@NamedQuery(name = "SponsorWebServiceQueue.getQueue", query = "select i from SponsorWebServiceQueue i"
                + "        where i.enrollmentCode = :enrollmentCode") 
@NamedQuery(name = "SponsorWebServiceQueue.getQueueFalures", query = "select SUM(i.numberOfAttempts) from SponsorWebServiceQueue i "
                + "where i.numberOfAttempts IS NOT NULL "
                + "AND i.attemptDateTime >= :startDate AND i.attemptDateTime <= :endDate "
                + "AND i.refSponsor.sponsorId = :sponsorId")
@NamedQuery(name="SponsorWebServiceQueue.findSponsorWebServiceQueueBySponsor", query="SELECT r FROM SponsorWebServiceQueue r WHERE r.refSponsor.sponsorId = :sponsorId")

public class SponsorWebServiceQueue implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="sponsor_web_service_queueSeq")
    @SequenceGenerator(name="sponsor_web_service_queueSeq",sequenceName="SPONSOR_WEB_SERVICE_QUEUE_SEQ", allocationSize=1)
    @Column(name = "QUEUE_ID")
    private long queueId;

    // bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name = "SPONSOR_ID")
    private RefSponsor refSponsor;

    @Column(name = "ENROLLMENT_CODE")
    private String enrollmentCode;

    @Column(name = "ATTEMPT_DATETIME")
    private Timestamp attemptDateTime;

    @Column(name = "NUMBER_OF_ATTEMPTS")
    private int numberOfAttempts;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;

    public long getQueueId() {
        return queueId;
    }

    public void setQueueId(long queueId) {
        this.queueId = queueId;
    }

    public RefSponsor getRefSponsor() {
        return refSponsor;
    }

    public void setRefSponsor(RefSponsor refSponsor) {
        this.refSponsor = refSponsor;
    }

    public String getEnrollmentCode() {
        return enrollmentCode;
    }

    public void setEnrollmentCode(String enrollmentCode) {
        this.enrollmentCode = enrollmentCode;
    }

    public Timestamp getAttemptDateTime() {
        return attemptDateTime;
    }

    public void setAttemptDateTime(Timestamp attemptDateTime) {
        this.attemptDateTime = attemptDateTime;
    }

    public int getNumberOfAttempts() {
        return numberOfAttempts;
    }

    public void setNumberOfAttempts(int numberOfAttempts) {
        this.numberOfAttempts = numberOfAttempts;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }
}
