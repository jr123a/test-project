package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;

/**
 * The persistent class for the high_risk_addresses database table.
 * 
 */
@Entity
@Table(name="high_risk_addresses")
@NamedQueries({
    @NamedQuery(name="HighRiskAddress.findByHash", query="SELECT h FROM HighRiskAddress h WHERE h.addressHash = :hash "
            + "AND (h.removed = 'N' OR h.removed IS NULL)"),
    @NamedQuery(name="HighRiskAddress.getAllPrimary", query="SELECT h FROM HighRiskAddress h WHERE h.refHighRiskAddressType.highRiskAddressTypeId = 1L"),
    @NamedQuery(name="HighRiskAddress.findByAddress", query="SELECT h FROM HighRiskAddress h WHERE UPPER(h.address) = UPPER(:address) AND UPPER(h.city) = UPPER(:city) "
    		+ "AND UPPER(h.state) = UPPER(:state) AND h.zip = :zip")
  
})
public class HighRiskAddress implements Serializable {
    private static final long serialVersionUID = 1L;
     
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="high_risk_addressesSeq")
    @SequenceGenerator(name="high_risk_addressesSeq",sequenceName="HIGH_RISK_ADDRESSES_SEQ", allocationSize=1)
    @Column(name="high_risk_address_id")
    private long highRiskAddressId;
    
    @Column(name="address")
    private String address;
    
    @Column(name="address_line_2")
    private String addressLine2;

    @Column(name="city")
    private String city;
    
    @Column(name="state")
    private String state;

    @Column(name="zip")
    private String zip;

    @Column(name="added_datetime")
    private Timestamp addedDateTime;
    
    @Column(name="address_hash")
    private int addressHash;
    
    @Column(name="removed")
    private String removed;
    
    //many-to-one association to RefHighRiskAddressType
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="high_risk_address_type_id")
    private RefHighRiskAddressType refHighRiskAddressType;

    public long getHighRiskAddressId() {
        return highRiskAddressId;
    }

    public void setHighRiskAddressId(long highRiskAddressId) {
        this.highRiskAddressId = highRiskAddressId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public Timestamp getAddedDateTime() {
        return addedDateTime;
    }

    public void setAddedDateTime(Timestamp addedDateTime) {
        this.addedDateTime = addedDateTime;
    }

    public int getAddressHash() {
        return addressHash;
    }

    public void setAddressHash(int addressHash) {
        this.addressHash = addressHash;
    }

    public RefHighRiskAddressType getRefHighRiskAddressType() {
        return refHighRiskAddressType;
    }

    public void setRefHighRiskAddressType(RefHighRiskAddressType refHighRiskAddressType) {
        this.refHighRiskAddressType = refHighRiskAddressType;
    }

	public String getRemoved() {
		return removed;
	}

	public void setRemoved(String removed) {
		this.removed = removed;
	}
}
