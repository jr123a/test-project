package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;


import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ref_lexis_nexis_response_code database table.
 * 
 */
@Entity
@Table(name="ref_lexisnexis_response_code")
@NamedQueries({
        @NamedQuery(name="lnResponseCode.findAll", query = "Select r FROM RefLexisNexisResponseCode r"),
        @NamedQuery(name="lnResponseCode.findById", query="Select r FROM RefLexisNexisResponseCode r WHERE r.responseCode = :code"),
        @NamedQuery(name="lnResponseCode.findByDescription", query="Select r FROM RefLexisNexisResponseCode r WHERE r.responseCodeDescription = :description"),
        @NamedQuery(name="lnResponseCode.findByProductReason", query="Select r FROM RefLexisNexisResponseCode r WHERE UPPER(r.productReason) = :productReason")
        })
        
public class RefLexisNexisResponseCode implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="RESPONSE_CODE")
    private String responseCode;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="RESPONSE_CODE_DESCRIPTION")
    private String responseCodeDescription;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;
    
    @Column(name="PRODUCT_REASON")
    private String productReason;
    

    //bi-directional many-to-one association to RpLexisNexisResult
    @OneToMany(mappedBy="refLexisNexisResponseCode")
    private List<RpLexisNexisResult> rpLexisNexisResults;

    public String getResponseCode() {
        return this.responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getResponseCodeDescription() {
        return this.responseCodeDescription;
    }

    public void setResponseCodeDescription(String responseCodeDescription) {
        this.responseCodeDescription = responseCodeDescription;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<RpLexisNexisResult> getRpLexisNexisResults() {
        return this.rpLexisNexisResults;
    }

    public void setRpLexisNexisResults(List<RpLexisNexisResult> rpLexisNexisResults) {
        this.rpLexisNexisResults = rpLexisNexisResults;
    }

    public RpLexisNexisResult addRpLexisNexisResult(RpLexisNexisResult rpLexisNexisResult) {
        getRpLexisNexisResults().add(rpLexisNexisResult);
        rpLexisNexisResult.setRefLexisNexisResponseCode(this);

        return rpLexisNexisResult;
    }

    public RpLexisNexisResult removeRpLexisNexisResult(RpLexisNexisResult rpLexisNexisResult) {
        getRpLexisNexisResults().remove(rpLexisNexisResult);
        rpLexisNexisResult.setRefLexisNexisResponseCode(null);

        return rpLexisNexisResult;
    }

    public String getProductReason() {
        return productReason;
    }

    public void setProductReason(String productReason) {
        this.productReason = productReason;
    }

}
