package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the rp_phone_verifications database table.
 * 
 */
@Entity
@Table(name="rp_phone_verifications")
@NamedQueries({
    @NamedQuery(name="RpPhoneVerification.findAll", query="SELECT e FROM RpPhoneVerification e")
})

public class RpPhoneVerification implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String DECISION_PASSED = "PASS";
    public static final String DECISION_FAILED = "FAIL";
    public static final String DECISION_PENDING = "PENDING";
    public static final String DECISION_APPROVED = "APPROVE";
    public static final String DECISION_FOR_REVIEW = "REVIEW";
    public static final String DECISION_DENIED = "DENY";

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PhoneVerificationSeq")
    @SequenceGenerator(name="PhoneVerificationSeq",sequenceName="PHONE_VERIFICATION_ID_SEQ", allocationSize=1)
    @Column(name="phone_verification_id")
    private long phoneVerificationId;
    
    //bi-directional one-to-one association to RpEvent
    @OneToOne
    @JoinColumn(name="event_id")
    private RpEvent rpEvent;
    
    @Column(name="transaction_key")
    private String transactionKey;
    
    @Column(name="phone_verification_decision")
    private String phoneVerificationDecision;
    
    @Column(name="decision_datetime")
    private Timestamp decisionDateTime;

    @Column(name="mobile_phone_number")
    private String mobilePhoneNumber;
    
    //many-to-one association to RefPhoneType
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="phone_type_id")
    private RefPhoneType refPhoneType;
    
    @Column(name="number_of_submit_attempts")
    private int numberOfSubmitAttempts;
    
    @Column(name="number_of_renew_attempts")
    private int numberOfRenewAttempts;
    
    @Column(name="create_date")
    private Date createDate;
    
    @Column(name="update_date")
    private Date updateDate;
    
    @Column(name="eid_decision")
    private String eidDecision;
    
    @Column(name="overall_assessment")
    private String overallAssessment;

    public long getPhoneVerificationId() {
        return phoneVerificationId;
    }
    
    public void setPhoneVerificationId(long phoneVerificationId) {
        this.phoneVerificationId = phoneVerificationId;
    }

    public RpEvent getRpEvent() {
        return rpEvent;
    }

    public void setRpEvent(RpEvent rpEvent) {
        this.rpEvent = rpEvent;
    }

    public String getPhoneVerificationDecision() {
        return phoneVerificationDecision;
    }

    public void setPhoneVerificationDecision(String phoneVerificationDecision) {
        this.phoneVerificationDecision = phoneVerificationDecision;
    }

    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }

    public void setMobilePhoneNumber(String mobilePhoneNumber) {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }
    
    public int getNumberOfSubmitAttempts() {
        return numberOfSubmitAttempts;
    }

    public void setNumberOfSubmitAttempts(int numberOfSubmitAttempts) {
        this.numberOfSubmitAttempts = numberOfSubmitAttempts;
    }

    public int getNumberOfRenewAttempts() {
        return numberOfRenewAttempts;
    }

    public void setNumberOfRenewAttempts(int numberOfRenewAttempts) {
        this.numberOfRenewAttempts = numberOfRenewAttempts;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getTransactionKey() {
        return transactionKey;
    }

    public void setTransactionKey(String transactionKey) {
        this.transactionKey = transactionKey;
    }
    
    public Timestamp getDecisionDateTime() {
        return decisionDateTime;
    }

    public void setDecisionDateTime(Timestamp decisionDateTime) {
        this.decisionDateTime = decisionDateTime;
    }

    /**
     * Phone is only verified if EID Decision is Y, phone decision is PASS and phone type is MOBILE.  This changed to use the Equifax
     * Overall Assessment field.
     * @return
     */
    public boolean isPhoneVerified() {
    	return DECISION_PASSED.equalsIgnoreCase(phoneVerificationDecision) 
    			|| DECISION_PASSED.equalsIgnoreCase(getOverallAssessment());
    }
    
    public boolean isEquifaxIDFSPhoneVerificationPassed() {
        if (getOverallAssessment() != null) {
            return DECISION_PASSED.equalsIgnoreCase(getOverallAssessment());
          } else {
            return DECISION_PASSED.equalsIgnoreCase(phoneVerificationDecision);
        }
    }
    
    public boolean isEquifaxDITPhoneVerificationPassed() {
        if (getOverallAssessment() != null) {
            return DECISION_APPROVED.equalsIgnoreCase(getOverallAssessment());
        } 
        return false;
    }
    
    public boolean isEquifaxDITPhoneVerificationForReview() {
        if (getOverallAssessment() != null) {
             return DECISION_FOR_REVIEW.equalsIgnoreCase(getOverallAssessment());
        } 
        return false;
    }
    
    public boolean isLexisNexisPhoneVerificationPassed() {
    	return DECISION_PASSED.equalsIgnoreCase(phoneVerificationDecision);
    }
    
    public boolean isEquifaxIDFSPhoneVerificationFailed() {
        if (getOverallAssessment() != null) {
            return DECISION_FAILED.equalsIgnoreCase(getOverallAssessment());
          } else {
            return DECISION_FAILED.equalsIgnoreCase(phoneVerificationDecision);
        }
    }
    
    public boolean isEquifaxDITPhoneVerificationFailed() {
        if (getOverallAssessment() != null) {
            return DECISION_DENIED.equalsIgnoreCase(getOverallAssessment());
        } else {
            return DECISION_FAILED.equalsIgnoreCase(phoneVerificationDecision);
        }
    }
    
    public boolean isLexisNexisPhoneVerificationFailed() {
    	return DECISION_FAILED.equalsIgnoreCase(phoneVerificationDecision);
    }
    
    public boolean isExperianPhoneVerificationApproved() {
    	return DECISION_APPROVED.equalsIgnoreCase(phoneVerificationDecision);
    }
    
    public boolean isExperianPhoneVerificationForReview() {
    	return DECISION_FOR_REVIEW.equalsIgnoreCase(phoneVerificationDecision);
    }
    
    public boolean isExperianPhoneVerificationDenied() {
    	 return DECISION_DENIED.equalsIgnoreCase(phoneVerificationDecision);
    }
    
    public RefPhoneType getRefPhoneType() {
        return refPhoneType;
    }

    public void setRefPhoneType(RefPhoneType refPhoneType) {
        this.refPhoneType = refPhoneType;
    }

    public String getEidDecision() {
        return eidDecision;
    }

    public void setEidDecision(String eidDecision) {
        this.eidDecision = eidDecision;
    }
    
    public boolean isEIDDecisionPassed() {
        return "Y".equalsIgnoreCase(getEidDecision());        
    }

    public String getOverallAssessment() {
        return overallAssessment;
    }

    public void setOverallAssessment(String overallAssessment) {
        this.overallAssessment = overallAssessment;
    }

    @Override
    public String toString() {
        return "RpPhoneVerification [phoneVerificationId=" + phoneVerificationId + ", rpEvent=" + rpEvent
                + ", transactionKey=" + transactionKey + ", phoneVerificationDecision=" + phoneVerificationDecision
                + ", decisionDateTime=" + decisionDateTime + ", mobilePhoneNumber=" + mobilePhoneNumber
                + ", numberOfSubmitAttempts=" + numberOfSubmitAttempts + ", numberOfRenewAttempts="
                + numberOfRenewAttempts + ", createDate=" + createDate + ", updateDate=" + updateDate + "]";
    }

}
