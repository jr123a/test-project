package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.ips.common.common.CustomLogger;

/**
 * The persistent class for the rp_event database table.
 * 
 */
@Entity
@Table(name="rp_event")
@NamedQueries({
    @NamedQuery(name="RpEvent.findAll", query="SELECT e FROM RpEvent e"),
    
    @NamedQuery(name="RpEvent.getEventByPersonId", 
    	query="SELECT e FROM RpEvent e WHERE e.personId=:pid ORDER BY e.createDate DESC"),

    @NamedQuery(name="RpEvent.getEventBySponsorUserId", 
	query="SELECT e FROM RpEvent e WHERE e.person.sponsorUserId=:sponsorUserId ORDER BY e.createDate DESC"),

    @NamedQuery(name="RpEvent.countEventIDs", 
    	query="SELECT COUNT(e) FROM RpEvent e WHERE e.personId=:pid AND e.otpSupplierId = :supplierId " 
    			+ "AND e.createDate>=:window AND e.createDate<=:currentTime"),
    
    // For determining lockout expires for phone verification lockout (excludes pending and repeat verification)
    @NamedQuery(name="RpEvent.getRpEventsInWindow", 
    	query="SELECT e FROM RpEvent e WHERE e.personId=:pid AND e.otpSupplierId = :supplierId " 
				+ "AND e.rpPhoneVerification.phoneVerificationDecision <> 'PENDING' " 
				+ "AND e.otpTransactionId IS NULL " 
				+ "AND e.createDate>=:window AND e.createDate<=:currentTime "
				+ "ORDER BY e.createDate ASC"),
    
    @NamedQuery(name="RpEvent.countRpEvents", 
    	query="SELECT COUNT(e) FROM RpEvent e WHERE e.personId=:pid AND e.otpSupplierId = :supplierId"),
    
    // Total Taken
    @NamedQuery(name="RpEvent.ctRpEventsPerDate", 
    	query="SELECT COUNT(e) FROM RpEvent e WHERE e.createDate >= :start AND e.createDate <= :end " 
    			+ "AND e.refLoaLevel = :level AND e.questionsReturned = 'Y' " 
    			+ "AND e.person.refSponsor = :sponsor"),
            
    // Total Taken by Supplier
    @NamedQuery(name="RpEvent.getTakenBySupplier", 
    	query="SELECT COUNT(e) FROM RpEvent e WHERE e.createDate >= :start AND e.createDate <= :end " 
    			+ "AND e.refLoaLevel = :level AND e.questionsReturned = 'Y' " 
    			+ "AND e.otpSupplierId = :supplierId " 
    			+ "AND e.person.refSponsor = :sponsor"),
                    
    @NamedQuery(name="RpEvent.ctRpEventsPerDateByDecision", 
    	query="SELECT COUNT(e) FROM RpEvent e WHERE e.finalDecision = :decision " 
    			+ "AND e.createDate >= :start AND e.createDate <= :end "
    			+ "AND e.refLoaLevel = :level AND e.questionsReturned = 'Y' " 
    			+ "AND e.person.refSponsor = :sponsor"),
        
    // Total Incomplete
    @NamedQuery(name="RpEvent.ctRpEventsPerDateNoDecision", 
    	query="SELECT COUNT(e) FROM RpEvent e WHERE e.finalDecision IS NULL " 
    			+ "AND e.createDate >= :start AND e.createDate <= :end " 
    			+ "AND e.refLoaLevel = :level AND e.questionsReturned = 'Y' "
    			+ "AND e.person.refSponsor = :sponsor"),
            
    // Total Incomplete by Supplier
    @NamedQuery(name="RpEvent.getIncompleteBySupplier", 
    	query="SELECT COUNT(e) FROM RpEvent e WHERE e.finalDecision IS NULL " 
    			+ "AND e.createDate >= :start AND e.createDate <= :end "
    			+ "AND e.refLoaLevel = :level AND e.questionsReturned = 'Y' " 
    			+ "AND e.otpSupplierId = :supplierId AND e.person.refSponsor = :sponsor"),
                
    // Total Remote Proofing Events
    @NamedQuery(name="RpEvent.getTotalEventsByLevelAndSupplier", 
    	query="SELECT COUNT(e) FROM RpEvent e WHERE e.createDate >= :start "
    			+ "AND e.createDate <= :end AND e.refLoaLevel = :level "
    			+ "AND e.otpSupplierId = :supplierId AND e.person.refSponsor = :sponsor"),
                        
    // Total Remote Proofing Events
    @NamedQuery(name="RpEvent.getTotalEventsByLevel", 
    	query="SELECT COUNT(e) FROM RpEvent e WHERE e.createDate >= :start "
    			+ "AND e.createDate <= :end AND e.refLoaLevel = :level "
    			+ "AND e.person.refSponsor = :sponsor"),            
    
    @NamedQuery(name="RpEvent.getEventByTransactionId", 
    	query="SELECT e FROM RpEvent e WHERE e.otpTransactionId = :transactionId"),
    
    // Latest phone verification event
    @NamedQuery(name="RpEvent.getLatestPhoneVerificationEvent", 
    	query="SELECT e FROM RpEvent e WHERE e.personId=:personId "
    		+ "AND e.otpSupplierId = :supplierId ORDER BY e.createDate DESC"),
    
    // For phone verification velocity check (not used)
    @NamedQuery(name="RpEvent.getCountInWindow", 
    	query="SELECT COUNT(e) FROM RpEvent e WHERE e.personId=:pid "
    		+ "AND e.otpSupplierId = :supplierId " +
            "AND e.createDate>=:window AND e.createDate<=:currentTime"),
    
    // For determining lockout expires for phone verification lockout (not used)
    @NamedQuery(name="RpEvent.getPhoneEventsInWindow", 
    	query="SELECT e FROM RpEvent e WHERE e.personId=:pid AND e.otpSupplierId = :supplierId " +
            "AND e.rpPhoneVerification.phoneVerificationDecision <> 'PENDING' " +
            "AND e.createDate >=:window AND e.createDate <=:currentTime ORDER BY e.createDate ASC"),

    // For determining previous event with same mobile phone number (only used in checking repeat phone verification)
    @NamedQuery(name="RpEvent.getLatestPhoneEventsByPersonIdAndPhoneNumber", 
    	query="SELECT e FROM RpEvent e WHERE e.personId=:personId AND e.rpPhoneVerification.mobilePhoneNumber = :mobilePhoneNumber " 
    		+ "AND e.rpPhoneVerification.phoneVerificationDecision <> 'PENDING' AND e.otpTransactionId IS NULL " 
    		+ "ORDER BY e.createDate DESC"),
    @NamedQuery(name="RpEvent.getEventCountByApplicationId", query="SELECT COUNT(e) FROM RpEvent e WHERE e.transactionOriginId.appId = :appId")
})
public class RpEvent implements Serializable, Comparable<RpEvent> {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="EventSeq")
    @SequenceGenerator(name="EventSeq",sequenceName="SEQ_RP_EVENT_ID", allocationSize=1)
    @Column(name="event_id")
    private long eventId;
    
    @Column(name="person_id")
    private long personId;
    
    @Column(name="KBA_supplier_id")
    private long otpSupplierId;

    @Column(name="create_date")
    private Timestamp createDate;
    
    @Column(name="final_Decision")
    private String finalDecision;

    @Column(name="kba_Transaction_id")
    private String otpTransactionId;

    @Column(name="update_date")
    private Timestamp updateDate;
    
    @Column(name="transaction_key")
    private String transactionKey;
    
    @Column(name="initiation_datetime")
    private Timestamp initiationDatetime;
    
    @Column(name="questions_received_datetime")
    private Timestamp questionsReceivedDatetime;
    
    @Column(name="answers_submitted_datetime")
    private Timestamp answersSubmittedDatetime;
    
    @Column(name="completion_datetime")
    private Timestamp completionDatetime;
    
    @Column(name="avs_errors_datetime")
    private Timestamp avsErrorsDatetime;
    
    @Column(name="questions_returned")
    private String questionsReturned;

    //bi-directional one-to-one association to RpEquifaxResult
    @OneToOne(mappedBy="rpEvent", cascade=CascadeType.ALL)
    private RpEquifaxResult rpEquifaxResult;

    //bi-directional one-to-one association to RpLexisNexisResult
    @OneToOne(mappedBy="rpEvent", cascade=CascadeType.ALL)
    private RpLexisNexisResult rpLexisNexisResult;

    //bi-directional one-to-one association to RpLexisNexisResult
    @OneToOne(mappedBy="rpEvent", cascade=CascadeType.ALL)
    private RpExperianDecisionResult rpExperianDecisionResult;

     //bi-directional many-to-one association to RefRpDecisionCode
    @ManyToOne
    @JoinColumn(name="final_decision" , insertable = false, updatable = false )
    private RefRpDecisionCode refRpDecisionCode;

    //bi-directional many-to-one association to RefOtpSupplier
    @ManyToOne
    @JoinColumn(name="KBA_supplier_id" , insertable = false, updatable = false )
    private RefOtpSupplier refOtpSupplier;
    
    //many-to-one association to RefLoaLevel
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="proofing_level_sought")
    private RefLoaLevel refLoaLevel;

    //bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name="person_id" , insertable = false, updatable = false )
    private Person person;
       
    @OneToMany(mappedBy="rpEvent",fetch = FetchType.EAGER, cascade=CascadeType.ALL)
    private List<RpEquifaxError> rpEquifaxErrors;
    
    @OneToMany(mappedBy="rpEvent",fetch = FetchType.EAGER, cascade=CascadeType.ALL)
    private List<RpEquifaxFieldCheck> rpEquifaxFieldChecks;
    
    //bi-directional one-to-one association to RpPhoneVerification
    @OneToOne(mappedBy="rpEvent", cascade=CascadeType.ALL)
    private RpPhoneVerification rpPhoneVerification;
    
    //bi-directional one-to-one association to RpPhoneVerificationResult
    @OneToOne(mappedBy="rpEvent", cascade=CascadeType.ALL)
    private RpPhoneVerificationResult rpPhoneVerificationResult;
    
    @OneToMany(mappedBy="rpEvent",fetch = FetchType.EAGER, cascade=CascadeType.ALL)
    private List<RpOtpAttempt> otpAttempts;
    
    @OneToMany(mappedBy="rpEvent",fetch = FetchType.EAGER, cascade=CascadeType.ALL)
    private List<RpSmfaAttempt> smfaAttempts;
    
    @OneToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
    @JoinColumn(name = "transaction_origin_id")
    private RefApp transactionOriginId;

    public RpEvent() {
    }

    public long getEventId() {
        return this.eventId;
    }

    public void setEventId(long eventId) {
        this.eventId = eventId;
    }

    public long getPersonId() {
        return personId;
    }

    public void setPersonId(long personId) {
        this.personId = personId;
    }

    public long getOtpSupplierId() {
        return otpSupplierId;
    }

    public void setOtpSupplierId(long otpSupplierId) {
        this.otpSupplierId = otpSupplierId;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getFinalDecision() {
        return finalDecision;
    }

    public void setFinalDecision(String finalDecision) {
        this.finalDecision = finalDecision;
    }

    public String getOtpTransactionId() {
        return this.otpTransactionId;
    }

    public void setOtpTransactionId(String otpTransactionId) {
        this.otpTransactionId = otpTransactionId;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public RpEquifaxResult getRpEquifaxResult() {
        return this.rpEquifaxResult;
    }

    public void setRpEquifaxResult(RpEquifaxResult rpEquifaxResult) {
        this.rpEquifaxResult = rpEquifaxResult;
    }

    public RefRpDecisionCode getRefRpDecisionCode() {
        return this.refRpDecisionCode;
    }

    public void setRefRpDecisionCode(RefRpDecisionCode refRpDecisionCode) {
        this.refRpDecisionCode = refRpDecisionCode;
    }

    public RefOtpSupplier getRefOtpSupplier() {
        return this.refOtpSupplier;
    }

    public void setRefOtpSupplier(RefOtpSupplier refOtpSupplier) {
        this.refOtpSupplier = refOtpSupplier;
    }
    
    public RefLoaLevel getRefLoaLevel() {
        return refLoaLevel;
    }

    public void setRefLoaLevel(RefLoaLevel refLoaLevel) {
        this.refLoaLevel = refLoaLevel;
    }

    public Person getPerson() {
        return this.person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getTransactionKey() {
        return transactionKey;
    }

    public void setTransactionKey(String transactionKey) {
        this.transactionKey = transactionKey;
    }

    public Timestamp getInitiationDatetime() {
        return initiationDatetime;
    }

    public void setInitiationDatetime(Timestamp initiationDatetime) {
        this.initiationDatetime = initiationDatetime;
    }

    public Timestamp getQuestionsReceivedDatetime() {
        return questionsReceivedDatetime;
    }

    public void setQuestionsReceivedDatetime(Timestamp questionsReceivedDatetime) {
        this.questionsReceivedDatetime = questionsReceivedDatetime;
    }

    public Timestamp getAnswersSubmittedDatetime() {
        return answersSubmittedDatetime;
    }

    public void setAnswersSubmittedDatetime(Timestamp answersSubmittedDatetime) {
        this.answersSubmittedDatetime = answersSubmittedDatetime;
    }

    public Timestamp getCompletionDatetime() {
        return completionDatetime;
    }

    public void setCompletionDatetime(Timestamp completionDatetime) {
        this.completionDatetime = completionDatetime;
    }

    public Timestamp getAvsErrorsDatetime() {
        return avsErrorsDatetime;
    }

    public void setAvsErrorsDatetime(Timestamp avsErrorsDatetime) {
        this.avsErrorsDatetime = avsErrorsDatetime;
    }
    
    
    public RpLexisNexisResult getRpLexisNexisResult() {
        return rpLexisNexisResult;
    }

    public void setRpLexisNexisResult(RpLexisNexisResult rpLexisNexisResult) {
        this.rpLexisNexisResult = rpLexisNexisResult;
    }
    
    public RpExperianDecisionResult getRpExperianDecisionResult() {
		return rpExperianDecisionResult;
	}

	public void setRpExperianDecisionResult(RpExperianDecisionResult rpExperianDecisionResult) {
		this.rpExperianDecisionResult = rpExperianDecisionResult;
	}

	public String getQuestionsReturned() {
        return questionsReturned;
    }

    public void setQuestionsReturned(String questionsReturned) {
        this.questionsReturned = questionsReturned;
    }

    public boolean isProofingPassed() {
        return "Y".equalsIgnoreCase(this.getFinalDecision()) || "PASS".equalsIgnoreCase(this.getFinalDecision());
    }

    @Override
    public int compareTo(RpEvent o) {        
        if(this.createDate.getTime() - o.getCreateDate().getTime() > 0){
            return 1;
        } else if (this.createDate.getTime() - o.getCreateDate().getTime() < 0){
            return -1;
        } else{
            return 0;
        }
    }

    /**
     * create an equals method to mitigate a blocker issue in Sonar by
     * calling the super equals method.  This is a blocker because this 
     * method contains a custom compareTo method
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof RpEvent) {
            RpEvent rpEvent = (RpEvent) obj;
            return ((getCreateDate() != null && getCreateDate().equals(rpEvent.getCreateDate())) 
                    && (getFinalDecision() != null && getFinalDecision().equals(rpEvent.getFinalDecision())) 
                    && (getOtpTransactionId() != null && getOtpTransactionId().equals(rpEvent.getOtpTransactionId())) 
                    && (getUpdateDate() != null && getUpdateDate().equals(rpEvent.getUpdateDate()))
                    && (getTransactionKey() != null && getTransactionKey().equals(rpEvent.getTransactionKey())) 
                    && (getInitiationDatetime() != null && getInitiationDatetime().equals(rpEvent.getInitiationDatetime()))
                    && (getQuestionsReceivedDatetime() != null && getQuestionsReceivedDatetime().equals(rpEvent.getQuestionsReceivedDatetime())) 
                    && (getAnswersSubmittedDatetime() != null && getAnswersSubmittedDatetime().equals(rpEvent.getAnswersSubmittedDatetime()))
                    && (getCompletionDatetime() != null && getCompletionDatetime().equals(rpEvent.getCompletionDatetime())) 
                    && (getAvsErrorsDatetime() != null && getAvsErrorsDatetime().equals(rpEvent.getAvsErrorsDatetime())));
        }
        
        return false;
    }

    /**
     * create a hashCode to mitigate a blocker issue in Sonar by
     * adding up the hashCode() from all the atomic elements in the 
     * class that are not primitives
     */
    @Override
    public int hashCode() {
        return (getCreateDate() != null ? getCreateDate().hashCode() : 0) 
                + (getFinalDecision() != null ? getFinalDecision().hashCode() : 0) 
                + (getOtpTransactionId() != null ? getOtpTransactionId().hashCode() : 0) 
                + (getUpdateDate() != null ? getUpdateDate().hashCode() : 0)
                + (getTransactionKey() != null ? getTransactionKey().hashCode() : 0) 
                + (getInitiationDatetime() != null ? getInitiationDatetime().hashCode() : 0)
                + (getQuestionsReceivedDatetime() != null ? getQuestionsReceivedDatetime().hashCode() : 0) 
                + (getAnswersSubmittedDatetime() != null ? getAnswersSubmittedDatetime().hashCode() : 0)
                + (getCompletionDatetime() != null ? getCompletionDatetime().hashCode() : 0) 
                + (getAvsErrorsDatetime() != null ? getAvsErrorsDatetime().hashCode() : 0);
    }
    
    public List<RpEquifaxError> getRpEquifaxErrors() {
        if (rpEquifaxErrors == null) {
            rpEquifaxErrors = new ArrayList<>();
        }
        return rpEquifaxErrors;
    }

    public void setRpEquifaxErrors(List<RpEquifaxError> rpEquifaxErrors) {
        this.rpEquifaxErrors = rpEquifaxErrors;
    }

    public RpEquifaxError addEquifaxError(RpEquifaxError rpEquifaxError) {
        getRpEquifaxErrors().add(rpEquifaxError);
        rpEquifaxError.setRpEvent(this);

        return rpEquifaxError;
    }
    
    public RefApp getTransactionOriginId() {
        return transactionOriginId;
    }
    
    public void setTransactionOriginId(RefApp transactionOriginId) {
        this.transactionOriginId = transactionOriginId;
    }
    
    public List<RpEquifaxFieldCheck> getRpEquifaxFieldChecks() {
        if (rpEquifaxFieldChecks == null) {
            rpEquifaxFieldChecks = new ArrayList<>();
        }
        
        return rpEquifaxFieldChecks;
    }

    public void setRpEquifaxFieldChecks(List<RpEquifaxFieldCheck> rpEquifaxFieldChecks) {
        this.rpEquifaxFieldChecks = rpEquifaxFieldChecks;
    }

    public RpEquifaxFieldCheck addEquifaxFieldCheck(RpEquifaxFieldCheck rpEquifaxFieldCheck) {
        getRpEquifaxFieldChecks().add(rpEquifaxFieldCheck);
        rpEquifaxFieldCheck.setRpEvent(this);

        return rpEquifaxFieldCheck;
    }

    public RpPhoneVerification getRpPhoneVerification() {
        return rpPhoneVerification;
    }

    public void setRpPhoneVerification(RpPhoneVerification rpPhoneVerification) {
        this.rpPhoneVerification = rpPhoneVerification;
    }
    
    public RpPhoneVerificationResult getRpPhoneVerificationResult() {
        return rpPhoneVerificationResult;
    }

    public void setRpPhoneVerificationResult(
            RpPhoneVerificationResult rpPhoneVerificationResult) {
        this.rpPhoneVerificationResult = rpPhoneVerificationResult;
    }
    
    public List<RpOtpAttempt> getOtpAttempts() {
        if (otpAttempts == null) {
            otpAttempts = new ArrayList<>();
        }
        return otpAttempts;
    }

    public RpOtpAttempt addOtpAttempt(RpOtpAttempt otpAttempt) {
        getOtpAttempts().add(otpAttempt);
        otpAttempt.setRpEvent(this);

        return otpAttempt;
    }
    
    public RpOtpAttempt getLatestOtpAttempt() {
        RpOtpAttempt latestAttempt = null;

        List<RpOtpAttempt> attempts = getOtpAttempts();
        
        if (!attempts.isEmpty()) {
            Collections.sort(attempts, new SortRpOtpByCreateDate());
            latestAttempt = attempts.get(attempts.size()-1);
        }

        return latestAttempt;
    }
    
    public List<RpOtpAttempt> getSortedOtpAttempts(String transactionKey) {
        List<RpOtpAttempt> attempts = getOtpAttempts();
        List<RpOtpAttempt> attemptsWithSameTransactionKey = new ArrayList<>();
        
        for (RpOtpAttempt attempt: attempts) {
            if (transactionKey.equalsIgnoreCase(attempt.getTransactionKey())) {
                attemptsWithSameTransactionKey.add(attempt);
            }
        }
        
        if (!attemptsWithSameTransactionKey.isEmpty()) {
            Collections.sort(attemptsWithSameTransactionKey, new SortRpOtpByCreateDate());
        }

        return attemptsWithSameTransactionKey;
    }
    
    public List<RpSmfaAttempt> getSmfaAttempts() {
        if (smfaAttempts == null) {
        	smfaAttempts = new ArrayList<>();
        }
        return smfaAttempts;
    }

    public RpSmfaAttempt addSmfaAttempts(RpSmfaAttempt smfaAttempt) {
        getSmfaAttempts().add(smfaAttempt);
        smfaAttempt.setRpEvent(this);

        return smfaAttempt;
    }
    
    public RpSmfaAttempt getLatestSmfaAttempt() {
    	RpSmfaAttempt latestAttempt = null;

        List<RpSmfaAttempt> attempts = getSmfaAttempts();
        
        if (!attempts.isEmpty()) {
            Collections.sort(attempts, new SortRpSmfaByCreateDate());
            latestAttempt = attempts.get(attempts.size()-1);
        }

        return latestAttempt;
    }
    
    public List<RpSmfaAttempt> getSortedSmfaAttempts(String transactionKey) {
        List<RpSmfaAttempt> attempts = getSmfaAttempts();
        List<RpSmfaAttempt> attemptsWithSameTransactionKey = new ArrayList<>();
        
        for (RpSmfaAttempt attempt: attempts) {
            if (transactionKey.equalsIgnoreCase(attempt.getSessionId())) {
                attemptsWithSameTransactionKey.add(attempt);
            }
        }
        
        if (!attemptsWithSameTransactionKey.isEmpty()) {
            Collections.sort(attemptsWithSameTransactionKey, new SortRpSmfaByCreateDate());
        }

        return attemptsWithSameTransactionKey;
    }
    
    public int getSmfaAttemptCount() {
        return getSmfaAttempts().size();
    }
    
    /**
     * get last passcode attempt matched
     * @return
     */
    public boolean lastPasscodeAttemptMatched() {
        RpOtpAttempt latestAttempt = getLatestOtpAttempt();
        RefOtpMatchQuality latestMatchQuality = null;
        
        if (latestAttempt != null) {
            latestMatchQuality = latestAttempt.getRefOtpMatchQuality();
        }
        
        return latestMatchQuality != null && latestMatchQuality.isExact();
    }
    
    /**
     * get last passcode attempt expired
     * @return
     */
    public boolean lastPasscodeAttemptMismatched() {
        RpOtpAttempt latestAttempt = getLatestOtpAttempt();
        RefOtpMatchQuality latestMatchQuality = null;
        
        if (latestAttempt != null) {
            latestMatchQuality = latestAttempt.getRefOtpMatchQuality();
        }
        
        return latestMatchQuality != null && latestMatchQuality.isMismatch();
    }
    
    /**
     * get last passcode attempt expired
     * @return
     */
    public boolean lastPasscodeAttemptExpired() {
        RpOtpAttempt latestAttempt = getLatestOtpAttempt();
        RefOtpMatchQuality latestMatchQuality = null;
        
        if (latestAttempt != null) {
            latestMatchQuality = latestAttempt.getRefOtpMatchQuality();
        }
        
        return latestMatchQuality != null && latestMatchQuality.isExpired();
    }
    
    /**
     * get last passcode attempt and determine if it has been more than 30 minutes
     */
    public boolean transactionKeyHasExpired() {
        RpOtpAttempt latestAttempt = getLatestOtpAttempt();
        boolean expired = true;
        
        if (latestAttempt != null) {
            Date dateLatestAttemptCreated = latestAttempt.getCreateDate();
            CustomLogger.debug(this.getClass(), "transactionKeyHasExpired() dateLatestAttemptCreated=" + dateLatestAttemptCreated);
            Date thirtyMinutesAgo = new Date(System.currentTimeMillis()-30*60*1000);
            CustomLogger.debug(this.getClass(), "transactionKeyHasExpired() thirtyMinutesAgo="+ thirtyMinutesAgo);
            expired = (thirtyMinutesAgo.compareTo(dateLatestAttemptCreated) > 0);
            CustomLogger.debug(this.getClass(), "transactionKeyHasExpired() transactionKey has expired="+ expired);
        }
        else {
            CustomLogger.error(this.getClass(), "transactionKeyHasExpired() latestAttempt is null defaulting to expired="+ expired);
        }
        return expired;
    }
    
    /*
     * While Lexis Nexis does track when a passcode expires and will return a message indicating that, there are a 
     * couple of issues with their handling.  They only return the expired indication when the passcode submitted is the correct one.
     * A conversation is also only good for a certain amount of time and will return an error after that time elapses.
     * This method only applies to LexisNexis.
     * 
     */
    /**
     * get last passcode attempt exceeded submit
     * @return
     */
    public boolean lexisPasscodeHasExpired(long otpExpiresMinutes) {
        boolean expired = false;
    
        RpOtpAttempt latestAttempt = getLatestOtpAttempt();
        
        if (latestAttempt != null && getRefOtpSupplier().isLexisNexisPhone()) {
        	//Date fiveMinutesAgo = new Date(System.currentTimeMillis()-5*60*1000);
            Date fiveMinutesAgo = new Date(System.currentTimeMillis() - otpExpiresMinutes*60*1000);
            boolean moreThan5minutes = fiveMinutesAgo.compareTo(latestAttempt.getOtpSentDateTime()) > 0;
           
		    String productStatus = "";
            if (latestAttempt.getRefProductStatusCode() != null) {
            	 productStatus = latestAttempt.getRefProductStatusCode().getProductStatus();
            }

            // If product status is still pending and otp sent datetime is more than 5 minutes ago, the passcode has expired
            //Remove RP_LEXIS_PENDING check so it will expire or be locked out regardless of status
            //if (IPSConstants.RP_LEXIS_PENDING.equalsIgnoreCase(productStatus) && moreThan5minutes) {
            if (moreThan5minutes) {
                CustomLogger.info(this.getClass(), "lexisPasscodeHasExpired() fiveMinutesAgo: "+ fiveMinutesAgo + " passcode has expired for sponsorUserId: " + this.person.getSponsorUserId());
                expired = true;
            }
        }
        
        return expired;
    }
    
    /**
     * Checks if the pass code has expired based on the otpExpiresMinutes
     * @param otpExpiresMinutes
     * @return
     */
    public boolean hasPasscodeExpired(long otpExpiresMinutes) {
        boolean expired = false;
    
        RpOtpAttempt latestAttempt = getLatestOtpAttempt();
        
        if (latestAttempt != null) {
            Date minutesAgo = new Date(System.currentTimeMillis() - otpExpiresMinutes*60*1000);
            boolean moreThanXminutes = minutesAgo.compareTo(latestAttempt.getOtpSentDateTime()) > 0;
            
            if (moreThanXminutes) {
                CustomLogger.info(this.getClass(), "hasPasscodeExpired(): "+ minutesAgo + " passcode has expired for sponsorUserId: " + this.person.getSponsorUserId());
                expired = true;
            }
        }
        
        return expired;
    }
    
    public boolean lastPasscodeAttemptExceededSubmit() {
        RpOtpAttempt latestAttempt = getLatestOtpAttempt();
        RefOtpMatchQuality latestMatchQuality = null;
        
        if (latestAttempt != null) {
            latestMatchQuality = getLatestOtpAttempt().getRefOtpMatchQuality();
        }
        
        return latestMatchQuality != null && latestMatchQuality.isSubmitExceeded();
    }
    
    /**
     * get last passcode attempt exceeded renew
     * @return
     */
    public boolean lastPasscodeAttemptExceededRenew() {
        RpOtpAttempt latestAttempt = getLatestOtpAttempt();
        RefOtpMatchQuality latestMatchQuality = null;
        
        if (latestAttempt != null) {
            latestMatchQuality = getLatestOtpAttempt().getRefOtpMatchQuality();
        }
        
        return latestMatchQuality != null && latestMatchQuality.isRenewExceeded();
    }
    
    public int getPasscodeAttemptCount() {
        return getOtpAttempts().size();
    }
    
    /**
     * toString method to print some of the event information that is not Personally Identifiable Information (PII)
     */
    @Override
    public String toString() {
        return "RpEvent [eventId=" + eventId + ", KBA_supplier_id=" + otpSupplierId
                + ", create_date=" + createDate + ", final_Decision=" + finalDecision 
                + ", KBA_Transaction_id=" + otpTransactionId + ", update_date=" + updateDate 
                + ", transaction_key=" + transactionKey + ", initiation_datetime=" + initiationDatetime 
                + ", questions_received_datetime=" + questionsReceivedDatetime 
                + ", answers_submitted_datetime=" + answersSubmittedDatetime
                + ", completion_datetime=" + completionDatetime + ", avs_errors_datetime=" + avsErrorsDatetime
                + ", questions_returned=" + questionsReturned + ", rpEquifaxResult=" + rpEquifaxResult
                + ", refRpDecisionCode=" + refRpDecisionCode + ", refOtpSupplier=" + refOtpSupplier 
                + ", refLoaLevel=" + refLoaLevel + ", person=" + person + ", rpLexisNexisResult=" + rpLexisNexisResult 
                + ", rpExperianDecisionResult=" + rpExperianDecisionResult
                + ", rpEquifaxErrors=" + rpEquifaxErrors + ", rpEquifaxFieldChecks=" + rpEquifaxFieldChecks
                + ", rpPhoneVerification=" + rpPhoneVerification 
                + ", rpPhoneVerificationResult=" + rpPhoneVerificationResult 
                + ", otpAttempts=" + otpAttempts + "]";
    }
    
    /**
     * This is used to override the compare method for RpOtpAttempt without 
     * overriding the actual class method.
     */
    class SortRpOtpByCreateDate implements Comparator<RpOtpAttempt> {
        @Override
        public int compare(RpOtpAttempt o1, RpOtpAttempt o2) {
            if (o1.getCreateDate().getTime() - o2.getCreateDate().getTime() > 0) {
                return 1;
            } else if (o1.getCreateDate().getTime() - o2.getCreateDate().getTime() < 0) {
                return -1;
            } else {
                return 0;
            }
        }
    }
    
    /**
     * This is used to override the compare method for RpSmfaAttempt without 
     * overriding the actual class method.
     */
    class SortRpSmfaByCreateDate implements Comparator<RpSmfaAttempt> {
        @Override
        public int compare(RpSmfaAttempt o1, RpSmfaAttempt o2) {
            if (o1.getCreateDate().getTime() - o2.getCreateDate().getTime() > 0) {
                return 1;
            } else if (o1.getCreateDate().getTime() - o2.getCreateDate().getTime() < 0) {
                return -1;
            } else {
                return 0;
            }
        }
    }
}
