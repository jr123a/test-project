package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the program_online_stats database table.
 * 
 */
@Entity
@Table(name="program_online_stats")
@NamedQueries({
    @NamedQuery(name="ProgramOnlineStats.findAll", query="SELECT p FROM ProgramOnlineStats p"),
    @NamedQuery(name="ProgramOnlineStats.findBySupplier", query="SELECT p FROM ProgramOnlineStats p WHERE p.refOtpSupplier = :supplierId")
})
public class ProgramOnlineStats  implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="statistics_id")
    private long statisticsId;

    @ManyToOne
    @JoinColumn(name="kba_supplier_id")
    private RefOtpSupplier refOtpSupplier;

    @Column(name="quizzes_taken")
    private long quizzesTaken;
    
    @Column(name="quizzes_passed")
    private long quizzesPassed;
    
    @Column(name="quizzes_failed")
    private long quizzesFailed;
    
    @Column(name="quizzes_incomplete")
    private long quizzesIncomplete;
    
    @Column(name="pass_percent")
    private long passPercent;
    
    @Column(name="fail_percent")
    private long failPercent;
    
    @Column(name="end_date")
    private Timestamp endDate;

    public long getStatisticsId() {
        return statisticsId;
    }

    public void setStatisticsId(long statisticsId) {
        this.statisticsId = statisticsId;
    }

    public RefOtpSupplier getRefOtpSupplier() {
        return refOtpSupplier;
    }

    public void setRefOtpSupplier(RefOtpSupplier refOtpSupplier) {
        this.refOtpSupplier = refOtpSupplier;
    }

    public long getQuizzesTaken() {
        return quizzesTaken;
    }

    public void setQuizzesTaken(long quizzesTaken) {
        this.quizzesTaken = quizzesTaken;
    }

    public long getQuizzesPassed() {
        return quizzesPassed;
    }

    public void setQuizzesPassed(long quizzesPassed) {
        this.quizzesPassed = quizzesPassed;
    }

    public long getQuizzesFailed() {
        return quizzesFailed;
    }

    public void setQuizzesFailed(long quizzesFailed) {
        this.quizzesFailed = quizzesFailed;
    }

    public long getQuizzesIncomplete() {
        return quizzesIncomplete;
    }

    public void setQuizzesIncomplete(long quizzesIncomplete) {
        this.quizzesIncomplete = quizzesIncomplete;
    }

    public long getPassPercent() {
        return passPercent;
    }

    public void setPassPercent(long passPercent) {
        this.passPercent = passPercent;
    }

    public long getFailPercent() {
        return failPercent;
    }

    public void setFailPercent(long failPercent) {
        this.failPercent = failPercent;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
        result = prime * result + (int) (failPercent ^ (failPercent >>> 32));
        result = prime * result + (int) (passPercent ^ (passPercent >>> 32));
        result = prime * result + (int) (quizzesFailed ^ (quizzesFailed >>> 32));
        result = prime * result + (int) (quizzesIncomplete ^ (quizzesIncomplete >>> 32));
        result = prime * result + (int) (quizzesPassed ^ (quizzesPassed >>> 32));
        result = prime * result + (int) (quizzesTaken ^ (quizzesTaken >>> 32));
        result = prime * result + (int) (statisticsId ^ (statisticsId >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ProgramOnlineStats other = (ProgramOnlineStats) obj;
        if (endDate == null) {
            if (other.endDate != null)
                return false;
        } else if (!endDate.equals(other.endDate))
            return false;
        if (failPercent != other.failPercent)
            return false;
        if (passPercent != other.passPercent)
            return false;
        if (quizzesFailed != other.quizzesFailed)
            return false;
        if (quizzesIncomplete != other.quizzesIncomplete)
            return false;
        if (quizzesPassed != other.quizzesPassed)
            return false;
        if (quizzesTaken != other.quizzesTaken)
            return false;
        if (statisticsId != other.statisticsId)
            return false;
        return true;
    }
}
