package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the kba_lockout_info database table.
 * 
 */
@Embeddable
public class OtpLockoutInfoPK implements Serializable {
    //default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;

    @Column(name="PERSON_ID")
    private long personId;

    @Column(name="LOA_CODE")
    private long loaCode;

    public long getPersonId() {
        return this.personId;
    }
    public void setPersonId(long personId) {
        this.personId = personId;
    }
    public long getLoaCode() {
        return this.loaCode;
    }
    public void setLoaCode(long loaCode) {
        this.loaCode = loaCode;
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof OtpLockoutInfoPK)) {
            return false;
        }
        OtpLockoutInfoPK castOther = (OtpLockoutInfoPK)other;
        return 
            (this.personId == castOther.personId)
            && (this.loaCode == castOther.loaCode);
    }

    public int hashCode() {
        final int prime = 31;
        int hash = 17;
        hash = (int) (hash * prime + this.personId);
        hash = (int) (hash * prime + this.loaCode);
        
        return hash;
    }
}
