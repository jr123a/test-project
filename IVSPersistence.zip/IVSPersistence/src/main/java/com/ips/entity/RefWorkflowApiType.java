package com.ips.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name="ref_workflow_api_type")
@NamedQueries({
        @NamedQuery(name = "RefWorkflowApiType.findAll", query = "SELECT r FROM RefWorkflowApiType r"),
        @NamedQuery(name = "RefWorkflowApiType.findByApiTypeId", query = "SELECT r FROM RefWorkflowApiType r" +
                " WHERE r.apiTypeId = :apiTypeId")
})
public class RefWorkflowApiType implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "API_TYPE_ID")
    private Long apiTypeId;

    @Column(name = "API_TYPE_CODE")
    private String apiTypeCode;

    @Column(name = "API_TYPE_DESCRIPTION")
    private String apiTypeDescription;

    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "UPDATE_DATE")
    private Date updateDate;

    public Long getApiTypeId() {
        return apiTypeId;
    }

    public void setApiTypeId(Long apiTypeId) {
        this.apiTypeId = apiTypeId;
    }

    public String getApiTypeCode() {
        return apiTypeCode;
    }

    public void setApiTypeCode(String category_name) {
        this.apiTypeCode = category_name;
    }

    public String getApiTypeDescription() {
        return apiTypeDescription;
    }
    public void setApiTypeDescription(String apiTypeDescription) {
        this.apiTypeDescription = apiTypeDescription;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        RefWorkflowApiType that = (RefWorkflowApiType) o;
        return Objects.equals(getApiTypeId(), that.getApiTypeId()) && Objects.equals(getApiTypeCode(), that.getApiTypeCode()) && Objects.equals(getApiTypeDescription(), that.getApiTypeDescription());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getApiTypeId(), getApiTypeCode(), getApiTypeDescription());
    }

    @Override
    public String toString() {
        return "RefWorkflowApiType{" +
                "apiTypeId=" + apiTypeId +
                ", apiTypeCode='" + apiTypeCode + '\'' +
                ", apiTypeDescription='" + apiTypeDescription + '\'' +
                ", createDate=" + createDate +
                ", updateDate=" + updateDate +
                '}';
    }
}
