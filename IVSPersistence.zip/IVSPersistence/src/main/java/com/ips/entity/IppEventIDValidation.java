package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;

/**
 * The persistent class for the ipp_event_id_validation database table. Created
 * for IAL2 for information related to the strong IDs for an event.
 * 
 */
@Entity
@Table(name = "ipp_event_id_validation")
@NamedQueries({
        @NamedQuery(name = "IppEventIDValidation.getPrimaryIdUsedCountByIdValidation", query = "SELECT COUNT(i) FROM IppEventIDValidation i "
                + "WHERE i.refPrimaryIdType.idType = :idType "),
        @NamedQuery(name = "IppEventIDValidation.getByEvent", query = "SELECT i FROM IppEventIDValidation i "
                        + "WHERE i.ippEventId = :eventId "),
        @NamedQuery(name = "IppEventIDValidation.getByEventAndIdType", query = "SELECT i FROM IppEventIDValidation i "
                + "WHERE i.ippEventId = :eventId and i.refPrimaryIdType.idType = :strongIdType")

})
public class IppEventIDValidation implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ipp_event_id_validationSeq")
    @SequenceGenerator(name="ipp_event_id_validationSeq",sequenceName="IPP_EVENT_ID_VALIDATION_SEQ", allocationSize=1)
    @Column(name = "ID_VALIDATION_ID")
    private long idValidationId;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Date updateDate;

    @Column(name = "VENDOR_IDENTIFIED_FRAUD")
    private String vendorIdentifiedFraud;

    @Column(name = "VALIDATION_RESULT")
    private String validationResult;

    @Column(name = "VENDOR_FAILURE_REASON")
    private String vendorFailureReason;

    @Column(name = "AAMVA_CHECK_RESULT")
    private String aamvaCheckResult;
    
    @Column(name = "IPP_EVENT_ID")
    private long ippEventId;

    // bi-directional many-to-one association to RefPrimaryIdType
    @ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
    @JoinColumn(name = "primary_id_type")
    private RefPrimaryIdType refPrimaryIdType;

    @ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
    @JoinColumn(name = "vendor_id")
    private RefIdValidationVendor refIdValidationVendor;

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    // reference id corresponding to the value of primary id type
    public RefPrimaryIdType getRefPrimaryIdType() {
        return this.refPrimaryIdType;
    }

    public void setRefPrimaryIdType(RefPrimaryIdType refPrimaryIdType) {
        this.refPrimaryIdType = refPrimaryIdType;
    }

    public String getVendorIdentifiedFraud() {
        return vendorIdentifiedFraud;
    }

    public void setVendorIdentifiedFraud(String vendorIdentifiedFraud) {
        this.vendorIdentifiedFraud = vendorIdentifiedFraud;
    }

    public String getValidationResult() {
        return validationResult;
    }

    public void setValidationResult(String validationResult) {
        this.validationResult = validationResult;
    }

    public String getVendorFailureReason() {
        return vendorFailureReason;
    }

    public void setVendorFailureReason(String vendorFailureReason) {
        this.vendorFailureReason = vendorFailureReason;
    }

    public String getAamvaCheckResult() {
        return aamvaCheckResult;
    }

    public void setAamvaCheckResult(String aamvaCheckResult) {
        this.aamvaCheckResult = aamvaCheckResult;
    }

    public long getIppEventId() {
        return ippEventId;
    }

    public void setIppEventId(long ippEventId) {
        this.ippEventId = ippEventId;
    }

    public RefIdValidationVendor getRefIdValidationVendor() {
        return refIdValidationVendor;
    }

    public void setRefIdValidationVendor(RefIdValidationVendor refIdValidationVendor) {
        this.refIdValidationVendor = refIdValidationVendor;
    }

    public long getIdValidationId() {
        return idValidationId;
    }
}
