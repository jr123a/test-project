package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * The persistent class for the rp_phone_verification_results database table.
 * 
 */
@Entity
@Table(name="rp_phone_verification_results")
@NamedQueries({
    @NamedQuery(name="RpPhoneVerificationResult.findAll", query="SELECT e FROM RpPhoneVerificationResult e")
})
public class RpPhoneVerificationResult implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="event_id")
    private long eventId;
    
    //bi-directional one-to-one association to RpEvent
    @OneToOne
    @JoinColumn(name="event_id" , insertable = false, updatable = false )
    private RpEvent rpEvent;
        
    @Column(name="valid_number")
    private String validNumber;
        
    // many-to-one association to RefPhoneMatchQuality
    @ManyToOne
    @JoinColumn(name="phone_match_quality_id")
    private RefPhoneMatchQuality refPhoneMatchQuality;
        
    //many-to-one association to RefMatchLevel
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="match_level_id")
    private RefMatchLevel refMatchLevel;

    // many-to-one association to RefServiceStatusCode
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="status_code_id")
    private RefServiceStatusCode refServiceStatusCode;

    // many-to-one association to RefProductStatusCode
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="product_status_id")
    private RefProductStatusCode refProductStatusCode;
    
    @Column(name="create_date")
    private Date createDate;
    
    @Column(name="update_date")
    private Date updateDate;

    public long getEventId() {
        return eventId;
    }

    public void setEventId(long eventId) {
        this.eventId = eventId;
    }

    public String getValidNumber() {
        return validNumber;
    }

    public void setValidNumber(String validNumber) {
        this.validNumber = validNumber;
    }

    public RefPhoneMatchQuality getRefPhoneMatchQuality() {
        return refPhoneMatchQuality;
    }

    public void setRefPhoneMatchQuality(RefPhoneMatchQuality refPhoneMatchQuality) {
        this.refPhoneMatchQuality = refPhoneMatchQuality;
    }

    public RefMatchLevel getRefMatchLevel() {
        return refMatchLevel;
    }

    public void setRefMatchLevel(RefMatchLevel refMatchLevel) {
        this.refMatchLevel = refMatchLevel;
    }

    public RefServiceStatusCode getRefServiceStatusCode() {
        return refServiceStatusCode;
    }

    public void setRefServiceStatusCode(RefServiceStatusCode refServiceStatusCode) {
        this.refServiceStatusCode = refServiceStatusCode;
    }

    public RefProductStatusCode getRefProductStatusCode() {
        return refProductStatusCode;
    }

    public void setRefProductStatusCode(RefProductStatusCode refProductStatusCode) {
        this.refProductStatusCode = refProductStatusCode;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public RpEvent getRpEvent() {
        return rpEvent;
    }

    public void setRpEvent(RpEvent rpEvent) {
        this.rpEvent = rpEvent;
    }

    @Override
    public String toString() {
        return "RpPhoneVerificationResult [eventId=" + eventId + ", rpEvent=" + rpEvent + ", validNumber=" + validNumber
                + ", refPhoneMatchQuality=" + refPhoneMatchQuality + ", refMatchLevel=" + refMatchLevel
                + ", refServiceStatusCode=" + refServiceStatusCode + ", refProductStatusCode=" + refProductStatusCode
                + ", createDate=" + createDate + ", updateDate=" + updateDate + "]";
    }
}
