package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;

/**
 * The persistent class for the data_consent database table.
 * 
 */
@Entity
@Table(name="data_consent")
@NamedQueries({
    @NamedQuery(name="DataConsent.findAll", query="SELECT d FROM DataConsent d")
})    
public class DataConsent implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DataConsentSeq")
    @SequenceGenerator(name="DataConsentSeq",sequenceName="SEQ_DATA_CONSENT_ID", allocationSize=1)
    @Column(name="data_consent_id")
    private long dataConsentId;

    @Column(name="CONSENT_TO_SHARE_DATA")
    private String consentToShareData;
    
    @Column(name="consent_datetime")
    private Date consentDateTime;
    
    @Column(name="DATA_ATTRIBUTES_SHARED")
    private String dataAttributesShared;
    
    //many-to-one association to RefLoaLevel
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="proofing_level")
    private RefLoaLevel refLoaLevel;

    //bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name="person_id")
    private Person person;
    
    //bi-directional many-to-one association to RefRelyingParty
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
    @JoinColumn(name="relying_party")
    private RefRelyingParty refRelyingParty;

    public RefLoaLevel getRefLoaLevel() {
        return refLoaLevel;
    }

    public void setRefLoaLevel(RefLoaLevel refLoaLevel) {
        this.refLoaLevel = refLoaLevel;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getConsentToShareData() {
        return consentToShareData;
    }

    public void setConsentToShareData(String consentToShareData) {
        this.consentToShareData = consentToShareData;
    }

    public Date getConsentDateTime() {
        return consentDateTime;
    }

    public void setConsentDateTime(Date consentDateTime) {
        this.consentDateTime = consentDateTime;
    }

    public String getDataAttributesShared() {
        return dataAttributesShared;
    }

    public void setDataAttributesShared(String dataAttributesShared) {
        this.dataAttributesShared = dataAttributesShared;
    }


    public RefRelyingParty getRefRelyingParty() {
        return refRelyingParty;
    }

    public void setRefRelyingParty(RefRelyingParty refRelyingParty) {
        this.refRelyingParty = refRelyingParty;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((consentDateTime == null) ? 0 : consentDateTime.hashCode());
        result = prime * result + ((consentToShareData == null) ? 0 : consentToShareData.hashCode());
        result = prime * result + ((dataAttributesShared == null) ? 0 : dataAttributesShared.hashCode());
        result = prime * result + (int) (dataConsentId ^ (dataConsentId >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        
        if (obj == null) {
            return false;
        }
        
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        DataConsent other = (DataConsent) obj;
        
        if (consentDateTime == null) {
            if (other.consentDateTime != null) {
                return false;
            }
        } else if (!consentDateTime.equals(other.consentDateTime)) {
            return false;
        }
        
        if (consentToShareData == null) {
            if (other.consentToShareData != null) {
                return false;
            }
        } else if (!consentToShareData.equals(other.consentToShareData)) {
            return false;
        }
        
        if (dataAttributesShared == null) {
            if (other.dataAttributesShared != null) {
                return false;
            }
        } else if (!dataAttributesShared.equals(other.dataAttributesShared)) {
            return false;
        }
        
        if (dataConsentId != other.dataConsentId) {
            return false;
        }
        
        return true;
    }
}
