package com.ips.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the person_data database table.
 * 
 */
@Entity
@Table(name = "address_verification")

@NamedQuery(name = "AddressVerification.getAllData", query = "SELECT a FROM AddressVerification a order by a.createDate desc")
@NamedQuery(name = "AddressVerification.getEventsByCreateDate", query = "SELECT i FROM AddressVerification i "
		+ "WHERE i.createDate < :dayAfter and i.createDate > :dayBefore")
public class AddressVerification {

	@Id
	@Column(name = "ADDRESS_VERIFICATION_ID")
	private long addressVerificationId;
	@Column(name = "USER_ID")
	private String userId;
	@Column(name = "FIRST_NAME")
	private String firstName;
	@Column(name = "LAST_NAME")
	private String lastName;
	@Column(name = "MIDDLE_NAME")
	private String middleName;
	@Column(name = "SUFFIX")
	private String suffix;
	@Column(name = "STREET_ADDRESS")
	private String streetAddress;
	@Column(name = "CITY")
	private String city;
	@Column(name = "STATE")
	private String state;
	@Column(name = "ZIP_CODE")
	private String zipCode;
	@Column(name = "ADDRESS_SCORE")
	private Double addressScore;
	@Column(name = "ERROR_MESSAGE")
	private String errorMessage;
	@Column(name = "CREATE_DATE")
	private Timestamp createDate;
	@Column(name = "UPDATE_DATE")
	private Date updateDate;

	public long getAddressVerificationId() {
		return addressVerificationId;
	}

	public void setAddressVerificationId(long addressVerificationId) {
		this.addressVerificationId = addressVerificationId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Double getAddressScore() {
		return addressScore;
	}

	public void setAddressScore(Double addressScore) {
		this.addressScore = addressScore;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Timestamp getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

}