package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the rp_proofing_session database table.
 * 
 */
@Entity
@Table(name="rp_proofing_session")
@NamedQueries({
    @NamedQuery(name="RpProofingSession.findAll", query="SELECT p FROM RpProofingSession p"),
    @NamedQuery(name="RpProofingSession.findRpSessionByPerson", query="SELECT p FROM RpProofingSession p WHERE p.person=:person " +
                    "ORDER BY p.createDate DESC"),
    @NamedQuery(name="RpProofingSession.findSumOfTotalAttempts", query="SELECT SUM(p.totalAttempts) FROM RpProofingSession p " +
            "WHERE p.person=:person"),
})
public class RpProofingSession implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ProofingSessionSeq")
    @SequenceGenerator(name="ProofingSessionSeq",sequenceName="SEQ_RP_SESSION_ID", allocationSize=1)
    @Column(name="proofing_session_id")
    private long proofingSessionId;

    @Column(name="create_date")
    private Timestamp createDate;

    @Column(name="update_date")
    private Timestamp updateDate;
    
    @Column(name="total_attempts")
    private int totalAttempts;

    //bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name="person_id")
    private Person person;

    public long getProofingSessionId() {
        return this.proofingSessionId;
    }

    public void setProofingSessionId(long proofingSessionId) {
        this.proofingSessionId = proofingSessionId;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public Person getPerson() {
        return this.person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public int getTotalAttempts() {
        return totalAttempts;
    }

    public void setTotalAttempts(int totalAttempts) {
        this.totalAttempts = totalAttempts;
    }

}
