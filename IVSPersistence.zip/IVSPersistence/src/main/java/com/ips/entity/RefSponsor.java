package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ref_sponsor database table.
 * 
 */
@Entity
@Table(name="ref_sponsor")
@NamedQueries({
    @NamedQuery(name="RefSponsor.findAll", query="SELECT r FROM RefSponsor r"),
    @NamedQuery(name="RefSponsor.findNonExternalSponsors", query="SELECT r FROM RefSponsor r WHERE r.ippClientActive <> 'Y' OR r.ippClientActive IS NULL"),
    @NamedQuery(name="RefSponsor.findBySponsorName", query="SELECT r FROM RefSponsor r WHERE r.sponsorName = :sponsor"),
    @NamedQuery(name="RefSponsor.findBySponsorId", query="SELECT r FROM RefSponsor r WHERE r.sponsorId = :sponsorId"),
    @NamedQuery(name="RefSponsor.findSponsorReceivingReports", query="SELECT s FROM RefSponsor s WHERE s.sponsorId IN (SELECT sr.sponsor.sponsorId FROM SponsorReports sr)"),
    @NamedQuery(name="RefSponsor.getExternalClients", query = "SELECT r FROM RefSponsor r WHERE r.ippClientActive IN ('Y', 'N')"),
    @NamedQuery(name="RefSponsor.findIAL2Sponsors", query="SELECT r FROM RefSponsor r WHERE r.sponsorId IN (SELECT c.sponsorId FROM RefSponsorConfiguration c WHERE c.name = :name and c.value = 'True')"),
    @NamedQuery(name="RefSponsor.getActiveExternalClients", query = "SELECT r FROM RefSponsor r WHERE r.ippClientActive = 'Y'"),
    @NamedQuery(name="RefSponsor.getActiveInternalSponsors", query = "SELECT r FROM RefSponsor r WHERE (r.ippClientActive <> 'Y' OR r.ippClientActive IS NULL) " +
            "AND r.sponsorId  IN (SELECT a.id.sponsorId FROM RpOtpAttemptConfig a GROUP BY  a.id.sponsorId)"),
    @NamedQuery(name="RefSponsor.findAllRemoteProofingClients", query="SELECT r FROM RefSponsor r WHERE r.remoteProofingClient =  'Y' ")
})    
public class RefSponsor implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String SPONSOR_CUSTREG  = "CustomReg";
    public static final String SPONSOR_EXTERNAL = "External Agency";
    public static final String SPONSOR_OPERATION_SANTA = "Operation Santa";
    public static final String SPONSOR_CHANGE_ADDRESS = "Change of Address";
    public static final String SPONSOR_SSA = "Social Security Administration";
    public static final String SPONSOR_GSA = "General Services Administration";
    public static final String SPONSOR_CODE_OS = "OS";
    public static final String SPONSOR_CODE_COA = "COA";
    public static final String SPONSOR_CODE_CR = "CR";

    public static final long SPONSOR_ID_CUSTREG  = 1L;
    public static final long SPONSOR_ID_SANTA = 2L;
    public static final long SPONSOR_ID_SSA = 3L;
    public static final long SPONSOR_ID_GSA = 4L;

    @Id
    @Column(name="SPONSOR_ID")
    private long sponsorId;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="SPONSOR_NAME")
    private String sponsorName;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    //bi-directional many-to-one association to Person
    @OneToMany(mappedBy="refSponsor")
    private List<Person> persons;
    
    @Column(name = "IPP_CLIENT_ACTIVE")
    private String ippClientActive;
    
    @Column(name = "FACILITY_SUBLIST")
    private String facilitySublist;
    
    @Column(name = "REMOTE_PROOFING_CLIENT")
    private String remoteProofingClient;

	@Transient 
	private boolean isEditable;
	
	@Transient 
	private boolean isDeletable;
	
	@Transient 
	private boolean isNotModifiable;
	
    public long getSponsorId() {
        return this.sponsorId;
    }

    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getSponsorName() {
        return this.sponsorName;
    }

    public void setSponsorName(String sponsorName) {
        this.sponsorName = sponsorName;
    }
    
    public String getIppClientActive() {
        return ippClientActive;
    }
    
    public void setIppClientActive(String ippClientActive) {
        this.ippClientActive = ippClientActive;
    }
    
    public boolean isIppClientActive() {
        return "y".equalsIgnoreCase(this.ippClientActive);
    }
    
    public boolean isRemoteProofingClientActive() {
        return "y".equalsIgnoreCase(this.remoteProofingClient);
    }
    
    public String getFacilitySublist() {
        return facilitySublist;
    }
    
    public void setFacilitySublist(String facilitySublist) {
        this.facilitySublist = facilitySublist;
    }
    
    public String getRemoteProofingClient() {
    	return remoteProofingClient;
    }
    
    public void setRemoteProofingClient(String remoteProofingClient) {
    	this.remoteProofingClient = remoteProofingClient;
    }
    
    public boolean isClientUsingFacilitySublist() {
        return "y".equalsIgnoreCase(this.facilitySublist);
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<Person> getPersons() {
        return this.persons;
    }

    public void setPersons(List<Person> persons) {
        this.persons = persons;
    }

    public Person addPerson(Person person) {
        getPersons().add(person);
        person.setRefSponsor(this);

        return person;
    }

    public Person removePerson(Person person) {
        getPersons().remove(person);
        person.setRefSponsor(null);

        return person;
    }
    
    public boolean isCustReg(){
        return SPONSOR_CUSTREG.equalsIgnoreCase(this.sponsorName);
    }

    public boolean isOperationSanta(){
        return getSponsorId() == SPONSOR_ID_SANTA;
    }
    
    public boolean isCustomerRegistration(){
        return getSponsorId() == SPONSOR_ID_CUSTREG;
    }

    public boolean isSSA() {
    	return this.sponsorName.startsWith(SPONSOR_SSA);
    }
	public boolean isEditable() {
		return isEditable;
	}

	public void setEditable(boolean isEditable) {
		this.isEditable = isEditable;
	}

	public boolean isDeletable() {
		return isDeletable;
	}

	public void setDeletable(boolean isDeletable) {
		this.isDeletable = isDeletable;
	}

	public boolean isNotModifiable() {
		return isNotModifiable;
	}

	public void setNotModifiable(boolean isNotModifiable) {
		this.isNotModifiable = isNotModifiable;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
		result = prime * result + ((facilitySublist == null) ? 0 : facilitySublist.hashCode());
		result = prime * result + ((ippClientActive == null) ? 0 : ippClientActive.hashCode());
		result = prime * result + (int) (sponsorId ^ (sponsorId >>> 32));
		result = prime * result + ((sponsorName == null) ? 0 : sponsorName.hashCode());
		result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
		return result;
	}

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefSponsor other = (RefSponsor) obj;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (facilitySublist == null) {
            if (other.facilitySublist != null)
                return false;
        } else if (!facilitySublist.equals(other.facilitySublist))
            return false;
        if (ippClientActive == null) {
            if (other.ippClientActive != null)
                return false;
        } else if (!ippClientActive.equals(other.ippClientActive))
            return false;
        if (sponsorId != other.sponsorId)
            return false;
        if (sponsorName == null) {
            if (other.sponsorName != null)
                return false;
        } else if (!sponsorName.equals(other.sponsorName))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }
}
