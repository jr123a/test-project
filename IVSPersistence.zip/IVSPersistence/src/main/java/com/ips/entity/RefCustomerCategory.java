package com.ips.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name="ref_customer_category")
@NamedQueries({
        @NamedQuery(name = "RefCustomerCategory.findAll", query = "SELECT r FROM RefCustomerCategory r"),
        @NamedQuery(name = "RefCustomerCategory.findByCategoryId", query = "SELECT r FROM RefCustomerCategory r" +
                " WHERE r.customerCategoryId = :customerCategoryId")
})
public class RefCustomerCategory implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "CUSTOMER_CATEGORY_ID")
    private Long customerCategoryId;

    @Column(name = "CATEGORY_NAME")
    private String categoryName;

    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "UPDATE_DATE")
    private Date updateDate;

    public Long getCustomerCategoryId() {
        return customerCategoryId;
    }

    public void setCustomerCategoryId(Long customerCategoryId) {
        this.customerCategoryId = customerCategoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String category_name) {
        this.categoryName = category_name;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        RefCustomerCategory that = (RefCustomerCategory) o;
        return Objects.equals(customerCategoryId, that.customerCategoryId)
                && Objects.equals(categoryName, that.categoryName)
                && Objects.equals(createDate, that.createDate)
                && Objects.equals(updateDate, that.updateDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(customerCategoryId, categoryName, createDate, updateDate);
    }

    @Override
    public String toString() {
        return "RefCustomerCategory{" +
                "customerCategoryId=" + customerCategoryId +
                ", categoryName='" + categoryName + '\'' +
                ", createDate=" + createDate +
                ", updateDate=" + updateDate +
                '}';
    }
}
