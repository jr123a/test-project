package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="rp_experian_header_data")
@NamedQueries({
    @NamedQuery(name="RpExperianHeaderData.getAll", query="SELECT r FROM RpExperianHeaderData r"),
    @NamedQuery(name = "RpExperianHeaderData.getListByResultId", query = "SELECT r FROM RpExperianHeaderData r WHERE r.expResultId = :resultId ORDER BY r.createDate DESC"),
    @NamedQuery(name = "RpExperianHeaderData.getListByClientReferenceId", query = "SELECT r FROM RpExperianHeaderData r WHERE r.clientReferenceId = :clientReferenceId ORDER BY r.createDate DESC"),
    @NamedQuery(name = "RpExperianHeaderData.getListByResultIdRequestType", query = "SELECT r FROM RpExperianHeaderData r WHERE r.expResultId = :resultId AND r.requestType = :requestType ORDER BY r.createDate DESC")
})    
public class RpExperianHeaderData implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="rp_experian_header_dataSeq")
    @SequenceGenerator(name="rp_experian_header_dataSeq",sequenceName="RP_EXPERIAN_HEADER_DATA_SEQ", allocationSize=1)
    @Column(name="EXP_HEADER_ID")
    private long expHeaderId;
    
    @Column(name="EXP_RESULT_ID")
    private long expResultId;

	@Column(name="REQUEST_TYPE")
    private String requestType;
    
    @Column(name="CLIENT_REFERENCE_ID")
    private String clientReferenceId;

    @Column(name="EXP_REQUEST_ID")
    private String expRequestId;   
    
    @Column(name="REQUEST_HEADER")
    private String requestHeader;
    
    @Column(name="RESPONSE_HEADER")
    private String responseHeader;
    
    @Column(name="CONTACT_DATA")
    private String contactData;
    
	@Column(name = "CREATE_DATE")
    private Date createDate;
    
    @Column(name = "UPDATE_DATE")
    private Date updateDate;

	public long getExpHeaderId() {
		return expHeaderId;
	}

	public void setExpHeaderId(long expHeaderId) {
		this.expHeaderId = expHeaderId;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setExpResultId(long expResultId) {
		this.expResultId = expResultId;
	}
	
	public long getExpResultId() {
		return expResultId;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getClientReferenceId() {
		return clientReferenceId;
	}

	public void setClientReferenceId(String clientReferenceId) {
		this.clientReferenceId = clientReferenceId;
	}

	public String getExpRequestId() {
		return expRequestId;
	}

	public void setExpRequestId(String expRequestId) {
		this.expRequestId = expRequestId;
	}

	public String getRequestHeader() {
		return requestHeader;
	}

	public void setRequestHeader(String requestHeader) {
		this.requestHeader = requestHeader;
	}

	public String getResponseHeader() {
		return responseHeader;
	}

	public void setResponseHeader(String responseHeader) {
		this.responseHeader = responseHeader;
	}

	public String getContactData() {
		return contactData;
	}

	public void setContactData(String contactData) {
		this.contactData = contactData;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

}
