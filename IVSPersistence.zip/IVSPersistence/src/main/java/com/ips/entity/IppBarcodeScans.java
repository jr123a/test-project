package com.ips.entity;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ipp_barcode_scans")
@NamedQueries({ @NamedQuery(name = "IppBarcodeScans.findAll", query = "SELECT i FROM IppBarcodeScans i ") })
public class IppBarcodeScans {

	@Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ipp_barcode_scansSeq")
    @SequenceGenerator(name="ipp_barcode_scansSeq",sequenceName="IPP_BARCODE_SCANS_SEQ", allocationSize=1)
    @Column(name = "SCAN_ID")
    private long scanId;

    // many-to-one association to RefIppApplications
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
    @JoinColumn(name = "IPP_APPLICATION_ID")
    private RefIppApplications refIppApplications;

    // many-to-one association to RefDeviceTypes
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
    @JoinColumn(name = "DEVICE_TYPE_ID")
    private RefDeviceTypes refDeviceTypes;

    // many-to-one association to RefDeviceTypes
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
    @JoinColumn(name = "IPP_EVENT_ID")
    private IppEvent IppEvent;

    @Column(name = "SCAN_DATETIME")
    /**
     * The date/time the enrollment code was scanned on the application and device
     */
    private Timestamp scanDatetime;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "CLERK_ACE_ID")
    private String clerkAceId;
    
    @Column(name = "PROOFING_LOCATION") 
    private String proofingLocation;

    @Column(name = "INVALID_APPLICATION_SCAN")
    private String invalidApplicationScan;

    // bi-directional many-to-one association to RefFacFacility
    @ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
    @JoinColumn(name = "ref_facility_id")
    private RefFacFacility refFacFacility;

    /**
     * @return the invalidScanId
     */
    public long getScanId() {
        return scanId;
    }

    /**
     * @param invalidScanId
     *            the invalidScanId to set
     */
    public void setScanId(long scanId) {
        this.scanId = scanId;
    }

    /**
     * @return the refIppApplications
     */
    public RefIppApplications getRefIppApplications() {
        return refIppApplications;
    }

    /**
     * @param refIppApplications
     *            the refIppApplications to set
     */
    public void setRefIppApplications(RefIppApplications refIppApplications) {
        this.refIppApplications = refIppApplications;
    }

    /**
     * @return the refDeviceTypes
     */
    public RefDeviceTypes getRefDeviceTypes() {
        return refDeviceTypes;
    }

    /**
     * @param refDeviceTypes
     *            the refDeviceTypes to set
     */
    public void setRefDeviceTypes(RefDeviceTypes refDeviceTypes) {
        this.refDeviceTypes = refDeviceTypes;
    }

    /**
     * @return the ippEvent
     */
    public IppEvent getIppEvent() {
        return IppEvent;
    }

    /**
     * @param ippEvent
     *            the ippEvent to set
     */
    public void setIppEvent(IppEvent ippEvent) {
        IppEvent = ippEvent;
    }

    /**
     * @return the scanDatetime
     */
    public Timestamp getScanDatetime() {
        return scanDatetime;
    }

    /**
     * @param scanDatetime
     *            the scanDatetime to set
     */
    public void setScanDatetime(Timestamp scanDatetime) {
        this.scanDatetime = scanDatetime;
    }

    /**
     * @return the createDate
     */
    public Timestamp getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate
     *            the createDate to set
     */
    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public void setCreateDate() {
        this.createDate = new Timestamp(System.currentTimeMillis());
    }

    public String getClerkAceId() {
        return clerkAceId;
    }

    public void setClerkAceId(String clerkAceId) {
        this.clerkAceId = clerkAceId;
    }
    
    public String getProofingLocation() {
        return proofingLocation;
    }
    
    public void setProofingLocation(String proofingLocation) {
        this.proofingLocation = proofingLocation;
    }

    public String getInvalidApplicationScan() {
        return invalidApplicationScan;
    }

    public void setInvalidApplicationScan(String invalidApplicationScan) {
        this.invalidApplicationScan = invalidApplicationScan;
    }

    public RefFacFacility getRefFacFacility() {
        return refFacFacility;
    }

    public void setRefFacFacility(RefFacFacility refFacFacility) {
        this.refFacFacility = refFacFacility;
    }

}
