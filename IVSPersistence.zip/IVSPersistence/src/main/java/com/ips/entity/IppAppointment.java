package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the ipp_appointment database table.
 * 
 */
@Entity
@Table(name="ipp_appointment")
@NamedQueries({
    @NamedQuery(name="IppAppointment.findAll", query="SELECT i FROM IppAppointment i"),    
    @NamedQuery(name="IppAppointment.findAppointments", query="SELECT i FROM IppAppointment i WHERE " +
    "i.processStatusCode = 0 AND i.appointmentDate = :appointmentDate")
})
public class IppAppointment implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="IPP_EVENT_ID")
    private long ippEventID;

    @Column(name="ADDRESS_1")
    private String address1;

    @Column(name="ADDRESS_2")
    private String address2;

    @Temporal(TemporalType.DATE)
    @Column(name="APPOINTMENT_DATE")
    private Date appointmentDate;

    @Column(name="APPOINTMENT_TIME")
    private String appointmentTime;

    private String city;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="EMAIL_ADDRESS")
    private String emailAddress;

    @Column(name="PROCESS_STATUS_CODE")
    private int processStatusCode;

    @Column(name="RECORD_LOCATOR")
    private String recordLocator;

    private String STATE_code;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    private String zip4;

    private String zip5;

    //bi-directional one-to-one association to IppEvent
    @OneToOne
    @JoinColumn(name="IPP_Event_ID" , insertable = false, updatable = false )
    private IppEvent ippEvent;

    public long getIppEventID() {
        return this.ippEventID;
    }

    public void setIppEventID(long ippEventID) {
        this.ippEventID = ippEventID;
    }

    public String getAddress1() {
        return this.address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return this.address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public Date getAppointmentDate() {
        return this.appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getAppointmentTime() {
        return this.appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getEmailAddress() {
        return this.emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public int getProcessStatusCode() {
        return this.processStatusCode;
    }

    public void setProcessStatusCode(int processStatusCode) {
        this.processStatusCode = processStatusCode;
    }

    public String getRecordLocator() {
        return this.recordLocator;
    }

    public void setRecordLocator(String recordLocator) {
        this.recordLocator = recordLocator;
    }

    public String getSTATE_code() {
        return this.STATE_code;
    }

    public void setSTATE_code(String STATE_code) {
        this.STATE_code = STATE_code;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public String getZip4() {
        return this.zip4;
    }

    public void setZip4(String zip4) {
        this.zip4 = zip4;
    }

    public String getZip5() {
        return this.zip5;
    }

    public void setZip5(String zip5) {
        this.zip5 = zip5;
    }

    public IppEvent getIppEvent() {
        return this.ippEvent;
    }

    public void setIppEvent(IppEvent ippEvent) {
        this.ippEvent = ippEvent;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((STATE_code == null) ? 0 : STATE_code.hashCode());
        result = prime * result + ((address1 == null) ? 0 : address1.hashCode());
        result = prime * result + ((address2 == null) ? 0 : address2.hashCode());
        result = prime * result + ((appointmentDate == null) ? 0 : appointmentDate.hashCode());
        result = prime * result + ((appointmentTime == null) ? 0 : appointmentTime.hashCode());
        result = prime * result + ((city == null) ? 0 : city.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((emailAddress == null) ? 0 : emailAddress.hashCode());
        result = prime * result + (int) (ippEventID ^ (ippEventID >>> 32));
        result = prime * result + processStatusCode;
        result = prime * result + ((recordLocator == null) ? 0 : recordLocator.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        result = prime * result + ((zip4 == null) ? 0 : zip4.hashCode());
        result = prime * result + ((zip5 == null) ? 0 : zip5.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        IppAppointment other = (IppAppointment) obj;
        if (STATE_code == null) {
            if (other.STATE_code != null)
                return false;
        } else if (!STATE_code.equals(other.STATE_code))
            return false;
        if (address1 == null) {
            if (other.address1 != null)
                return false;
        } else if (!address1.equals(other.address1))
            return false;
        if (address2 == null) {
            if (other.address2 != null)
                return false;
        } else if (!address2.equals(other.address2))
            return false;
        if (appointmentDate == null) {
            if (other.appointmentDate != null)
                return false;
        } else if (!appointmentDate.equals(other.appointmentDate))
            return false;
        if (appointmentTime == null) {
            if (other.appointmentTime != null)
                return false;
        } else if (!appointmentTime.equals(other.appointmentTime))
            return false;
        if (city == null) {
            if (other.city != null)
                return false;
        } else if (!city.equals(other.city))
            return false;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (emailAddress == null) {
            if (other.emailAddress != null)
                return false;
        } else if (!emailAddress.equals(other.emailAddress))
            return false;
        if (ippEventID != other.ippEventID)
            return false;
        if (processStatusCode != other.processStatusCode)
            return false;
        if (recordLocator == null) {
            if (other.recordLocator != null)
                return false;
        } else if (!recordLocator.equals(other.recordLocator))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        if (zip4 == null) {
            if (other.zip4 != null)
                return false;
        } else if (!zip4.equals(other.zip4))
            return false;
        if (zip5 == null) {
            if (other.zip5 != null)
                return false;
        } else if (!zip5.equals(other.zip5))
            return false;
        return true;
    }

}
