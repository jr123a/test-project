package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.ips.persistence.common.PersonVo;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Objects;


/**
 * The persistent class for the person_data database table.
 * 
 */
@Entity
@Table(name="person_data")
@NamedQueries({
	@NamedQuery(name="PersonData.findAll", query="SELECT p FROM PersonData p"),
	@NamedQuery(name="PersonData.findBySponsorUserId", query="SELECT p FROM PersonData p WHERE p.person.sponsorUserId = :sponsorUserId"),
})  

public class PersonData implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="PERSON_ID")
    private long personId;
    @Column(name="ADDRESS_LINE_1")
    private String addressLine1 = "";
    @Column(name="ADDRESS_LINE_2")
    private String addressLine2 = "";
    @Column(name="ADDRESS_LINE_3")
    private String addressLine3;
    @Temporal(TemporalType.DATE)
    @Column(name="BIRTH_DATE")
    private Date birthDate;
    @Column(name="CITY")
    private String city = "";
    @Column(name="CREATE_DATE")
    private Timestamp createDate;
    @Column(name="DELETED")
    private String deleted;
    @Column(name="EMAIL_ADDRESS")
    private String emailAddress;
    @Column(name="FIRST_NAME")
    private String firstName = "";
    @Column(name="LAST_NAME")
    private String lastName = "";
    @Column(name="MIDDLE_NAME")
    private String middleName = "";
    @Column(name="PHONE_NUMBER")
    private String phoneINT;
    @Column(name="PHONE_TYPE")
    private String phoneType;
    @Column(name="POSTAL_CODE")
    private String postalCode = "";
    @Column(name="STATE_PROVINCE")
    private String stateProvince = "";
    @Column(name="UPDATE_DATE")
    private Date updateDate;
    @Column(name="COUNTRY_NAME")
    private String countryName;
    
    @Column(name="address_hash")
    private int addressHash;

    //bi-directional one-to-one association to Person
    @OneToOne
    @JoinColumn(name="person_id" , insertable = false, updatable = false )
    private Person person;
    
    @Column(name="ALTERNATE_EMAIL_ADDRESS")
    private String alternateEmailAddress;

    public long getPersonId() {
        return this.personId;
    }
    public void setPersonId(long personId) {
        this.personId = personId;
    }
    public String getAddressLine1() {
        return this.addressLine1;
    }
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }
    public String getAddressLine2() {
        return this.addressLine2;
    }
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }
    public String getAddressLine3() {
        return this.addressLine3;
    }
    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }
    public Date getBirthDate() {
        return this.birthDate;
    }
    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }
    public String getCity() {
        return this.city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public Timestamp getCreateDate() {
        return this.createDate;
    }
    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }
    public String getDeleted() {
        return this.deleted;
    }
    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }
    public String getEmailAddress() {
        return this.emailAddress;
    }
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    public String getFirstName() {
        return this.firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return this.lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getMiddleName() {
        return this.middleName;
    }
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }
    public String getPhoneINT() {
        return this.phoneINT;
    }
    public void setPhoneINT(String phoneINT) {
        this.phoneINT = phoneINT;
    }
    public String getPhoneType() {
        return this.phoneType;
    }
    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }
    public String getPostalCode() {
        return this.postalCode;
    }
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
    
    public String getStateProvince() {
        if (stateProvince == null) {
            stateProvince = "";
        }
        
        return this.stateProvince;
    }
    
    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }
    public Date getUpdateDate() {
        return this.updateDate;
    }
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    public String getCountryName() {
        return countryName;
    }
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
    public Person getPerson() {
        return this.person;
    }
    public void setPerson(Person person) {
        this.person = person;
    }
    public String getFullName() {
        return firstName + " " + lastName;
    }
    
    public String getAlternateEmailAddress() {
        return alternateEmailAddress;
    }
    public void setAlternateEmailAddress(String alternateEmailAddress) {
        this.alternateEmailAddress = alternateEmailAddress;
    }
    
    
    public int getAddressHash() {
        return addressHash;
    }
    
    public void setAddressHash(int addressHash) {
        this.addressHash = addressHash;
    }
    
    /**
     * Compares current name and address with the name and address from CustReg to determine if the profile data has changed.
     * @return
     */
    public boolean hasProfileDataChanged(PersonVo personVo) {
        // don't compare null to empty string
        switchToEmptyString(personVo);
        
        return !this.firstName.equalsIgnoreCase(personVo.getFirstName())             ||
                !this.middleName.equalsIgnoreCase(personVo.getMiddleName())         ||
                !this.lastName.equalsIgnoreCase(personVo.getLastName())             ||
                !this.addressLine1.equalsIgnoreCase(personVo.getAddressLine1())     ||
                !this.addressLine2.equalsIgnoreCase(personVo.getAddressLine2())     ||
                !this.city.equalsIgnoreCase(personVo.getCity())                     ||
                !getStateProvince().equalsIgnoreCase(personVo.getStateProvince())     ||
                !this.postalCode.equalsIgnoreCase(personVo.getPostalCode());
    }
    
    /*
     * Changes fields that can be null to empty string to prevent NullPointerExceptions and compare apples to apples
     */
    private void switchToEmptyString(PersonVo personVo) {
        if (this.middleName == null) {
            this.middleName = "";
        }
        
        if (this.addressLine2 == null) {
            this.addressLine2 = "";
        }
        
        if (personVo.getMiddleName() == null) {
            personVo.setMiddleName("");
        }
        
        if (personVo.getAddressLine2() == null) {
            personVo.setAddressLine2("");
        }
        
    }
    
    public String getMiddleInitial() {
    	if(this.middleName!=null 
    			&& !this.middleName.isEmpty() 
    			&& Objects.nonNull(this.middleName)) {
    		return this.middleName.substring(0,1);
    	}
    	return "";
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + addressHash;
        result = prime * result + ((addressLine1 == null) ? 0 : addressLine1.hashCode());
        result = prime * result + ((addressLine2 == null) ? 0 : addressLine2.hashCode());
        result = prime * result + ((addressLine3 == null) ? 0 : addressLine3.hashCode());
        result = prime * result + ((alternateEmailAddress == null) ? 0 : alternateEmailAddress.hashCode());
        result = prime * result + ((birthDate == null) ? 0 : birthDate.hashCode());
        result = prime * result + ((city == null) ? 0 : city.hashCode());
        result = prime * result + ((countryName == null) ? 0 : countryName.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((deleted == null) ? 0 : deleted.hashCode());
        result = prime * result + ((emailAddress == null) ? 0 : emailAddress.hashCode());
        result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
        result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
        result = prime * result + ((middleName == null) ? 0 : middleName.hashCode());
        result = prime * result + (int) (personId ^ (personId >>> 32));
        result = prime * result + ((phoneINT == null) ? 0 : phoneINT.hashCode());
        result = prime * result + ((phoneType == null) ? 0 : phoneType.hashCode());
        result = prime * result + ((postalCode == null) ? 0 : postalCode.hashCode());
        result = prime * result + ((stateProvince == null) ? 0 : stateProvince.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PersonData other = (PersonData) obj;
        if (addressHash != other.addressHash)
            return false;
        if (addressLine1 == null) {
            if (other.addressLine1 != null)
                return false;
        } else if (!addressLine1.equals(other.addressLine1))
            return false;
        if (addressLine2 == null) {
            if (other.addressLine2 != null)
                return false;
        } else if (!addressLine2.equals(other.addressLine2))
            return false;
        if (addressLine3 == null) {
            if (other.addressLine3 != null)
                return false;
        } else if (!addressLine3.equals(other.addressLine3))
            return false;
        if (alternateEmailAddress == null) {
            if (other.alternateEmailAddress != null)
                return false;
        } else if (!alternateEmailAddress.equals(other.alternateEmailAddress))
            return false;
        if (birthDate == null) {
            if (other.birthDate != null)
                return false;
        } else if (!birthDate.equals(other.birthDate))
            return false;
        if (city == null) {
            if (other.city != null)
                return false;
        } else if (!city.equals(other.city))
            return false;
        if (countryName == null) {
            if (other.countryName != null)
                return false;
        } else if (!countryName.equals(other.countryName))
            return false;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (deleted == null) {
            if (other.deleted != null)
                return false;
        } else if (!deleted.equals(other.deleted))
            return false;
        if (emailAddress == null) {
            if (other.emailAddress != null)
                return false;
        } else if (!emailAddress.equals(other.emailAddress))
            return false;
        if (firstName == null) {
            if (other.firstName != null)
                return false;
        } else if (!firstName.equals(other.firstName))
            return false;
        if (lastName == null) {
            if (other.lastName != null)
                return false;
        } else if (!lastName.equals(other.lastName))
            return false;
        if (middleName == null) {
            if (other.middleName != null)
                return false;
        } else if (!middleName.equals(other.middleName))
            return false;
        if (personId != other.personId)
            return false;
        if (phoneINT == null) {
            if (other.phoneINT != null)
                return false;
        } else if (!phoneINT.equals(other.phoneINT))
            return false;
        if (phoneType == null) {
            if (other.phoneType != null)
                return false;
        } else if (!phoneType.equals(other.phoneType))
            return false;
        if (postalCode == null) {
            if (other.postalCode != null)
                return false;
        } else if (!postalCode.equals(other.postalCode))
            return false;
        if (stateProvince == null) {
            if (other.stateProvince != null)
                return false;
        } else if (!stateProvince.equals(other.stateProvince))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }
    
}
