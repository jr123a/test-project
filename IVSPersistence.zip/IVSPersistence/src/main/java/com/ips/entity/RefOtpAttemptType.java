package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ref_otp_attempt_types database table.
 * 
 */
@Entity
@Table(name="ref_otp_attempt_types")
@NamedQueries({
    @NamedQuery(name="RefOtpAttemptType.findAll", query="SELECT r FROM RefOtpAttemptType r"),
    @NamedQuery(name="RefOtpAttemptType.findByAttemptType", query = "Select r FROM RefOtpAttemptType r WHERE r.attemptType = :attemptType")
})    
public class RefOtpAttemptType implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="attempt_type_id")
    private long attemptTypeId;
    
    @Column(name="attempt_type")
    private String attemptType;
    
    @Column(name="create_date")
    private Timestamp createDate;
        
    public String getAttemptType() {
        return attemptType;
    }

    public void setAttemptType(String attemptType) {
        this.attemptType = attemptType;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }
}
