package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import com.ips.common.common.ApplicationConstants;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;


/**
 * The persistent class for the person database table.
 * 
 */
@Entity
@NamedQueries({
    @NamedQuery(name="Person.findAll", query="SELECT p FROM Person p"),
    @NamedQuery(name="findExistingPerson",
            query="SELECT p FROM Person p WHERE p.refSponsor = :sponsor AND p.sponsorUserId = :id"),
    @NamedQuery(name="Person.findByUID", query="SELECT p FROM Person p WHERE p.kbaUid = :uid"),
    @NamedQuery(name="Person.getPersonCountBySponsor", query="SELECT COUNT(p) FROM Person p WHERE p.refSponsor.sponsorId = :sponsorId")
})    
public class Person implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    public static final String USER_TYPE_TEST = "T";

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PersonSeq")
    @SequenceGenerator(name="PersonSeq",sequenceName="SEQ_RP_PERSON_ID", allocationSize=1)
    @Column(name="PERSON_ID")
    private long personId;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;
    
    @Column(name="KBA_UID")
    private String kbaUid;
    
    @Column(name="LEXID")
    private String lexId;
    
    private String pin;

    @Column(name="SPONSOR_USER_ID")
    private String sponsorUserId;

    @Column(name="UPDATE_DATE")
    private Date updateDate;
    
    @Column(name="ENTERED_IVS_DATETIME")
    private Date enteredDateTime;
    
    //many-to-one association to RefLoaLevel
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="PROOFING_LEVEL_SOUGHT")
    private RefLoaLevel loaLevelSought;

    @Column(name="USER_TYPE")
    private String userType;
    
    @Column(name="TERMS_CONDITIONS_ACK_DATETIME")
    private Date termsConditionsAckDateTime;
    
    @Column(name="LOA_ACHIEVED_DATETIME")
    private Date loaAchievedDateTime;
    
    //bi-directional many-to-one association to PersonProofingStatus
    @OneToMany(mappedBy="person", fetch=FetchType.EAGER, cascade=CascadeType.ALL)
    private List<PersonProofingStatus> proofingStatuses;
    
    //many-to-one association to RefLoaLevel
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="PROOFING_LEVEL_ACHIEVED")
    private RefLoaLevel refLoaLevel;

    //bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name="SPONSOR_ID")
    private RefSponsor refSponsor;

    //bi-directional one-to-one association to PersonData
    @OneToOne(mappedBy="person", cascade=CascadeType.ALL)
    private PersonData personData;
    
    //bi-directional one-to-one association to OtpLockoutInfo
    @OneToMany(mappedBy="person",fetch = FetchType.EAGER, cascade=CascadeType.ALL)
    private List<OtpLockoutInfo> otpLockoutInfo;

    //bi-directional many-to-one association to IppEvent
    @OneToMany(mappedBy="person",fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private List<IppEvent> ippEvents;

    //bi-directional many-to-one association to RpActivity
    @OneToMany(mappedBy="person")
    private List<RpProofingSession> rpProofingSessions;

    //bi-directional many-to-one association to RpEvent
    @OneToMany(mappedBy="person",fetch = FetchType.EAGER)
    private List<RpEvent> rpEvents;
    
    //bi-directional many-to-one association to DataConsent
    @OneToMany(mappedBy="person", fetch=FetchType.EAGER, cascade=CascadeType.ALL)
    private List<DataConsent> dataConsents;

    @Override
    public String toString() {
        return "Person [personId=" + personId + ", create_date=" + createDate + ", kbaUid=" + kbaUid
                + ", sponsorUserId=" + sponsorUserId + ", update_date=" + updateDate + ", enteredDateTime="
                + enteredDateTime + ", loaLevelSought=" + loaLevelSought + ", userType=" + userType
                + ", termsConditionsAckDateTime=" + termsConditionsAckDateTime + ", loaAchievedDateTime="
                + loaAchievedDateTime + ", proofingStatuses=" + proofingStatuses + ", refLoaLevel=" + refLoaLevel
                + ", refSponsor=" + refSponsor + ", personData=" + personData + ", otpLockoutInfo=" + otpLockoutInfo
                + ", dataConsents=" + dataConsents + "]";
    }

    public long getPersonId() {
        return this.personId;
    }

    public void setPersonId(long personId) {
        this.personId = personId;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getKbaUid() {
        return this.kbaUid;
    }

    public void setKbaUid(String kbaUid) {
        this.kbaUid = kbaUid;
    }

    public String getSponsorUserId() {
        return this.sponsorUserId;
    }

    public void setSponsorUserId(String sponsorUserId) {
        this.sponsorUserId = sponsorUserId;
    }

    public Date getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public RefSponsor getRefSponsor() {
        return this.refSponsor;
    }

    public void setRefSponsor(RefSponsor refSponsor) {
        this.refSponsor = refSponsor;
    }

    public RefLoaLevel getAchievedLoaLevel() {
        return refLoaLevel;
    }

    public void setAchievedLoaLevel(RefLoaLevel refLoaLevel) {
        this.refLoaLevel = refLoaLevel;
    }
    
    public RefLoaLevel getSoughtLoaLevel() {
        return loaLevelSought;
    }

    public void setSoughtLoaLevel(RefLoaLevel refLoaLevel) {
        this.loaLevelSought = refLoaLevel;
    }

    public PersonData getPersonData() {
        return this.personData;
    }

    public void setPersonData(PersonData personData) {
        this.personData = personData;
    }

    public List<IppEvent> getIppEvents() {
        if (ippEvents == null) {
            ippEvents = new ArrayList<>();
        }
        
        return this.ippEvents;
    }

    public void setIppEvents(List<IppEvent> ippEvents) {
        this.ippEvents = ippEvents;
    }

    public IppEvent addIppEvent(IppEvent ippEvent) {
        getIppEvents().add(ippEvent);
        ippEvent.setPerson(this);

        return ippEvent;
    }

    public IppEvent removeIppEvent(IppEvent ippEvent) {
        getIppEvents().remove(ippEvent);
        ippEvent.setPerson(null);

        return ippEvent;
    }

    public List<RpProofingSession> getRpProofingSessions() {
        return this.rpProofingSessions;
    }

    public void setRpProofingSessions(List<RpProofingSession> rpProofingSessions) {
        this.rpProofingSessions = rpProofingSessions;
    }

    public RpProofingSession addRpProofingSession(RpProofingSession rpProofingSession) {
        getRpProofingSessions().add(rpProofingSession);
        rpProofingSession.setPerson(this);

        return rpProofingSession;
    }

    public RpProofingSession removeRpProofingSession(RpProofingSession rpProofingSession) {
        getRpProofingSessions().remove(rpProofingSession);
        rpProofingSession.setPerson(null);

        return rpProofingSession;
    }

    public List<RpEvent> getRpEvents() {
        return this.rpEvents;
    }

    public void setRpEvents(List<RpEvent> rpEvents) {
        this.rpEvents = rpEvents;
    }

    public RpEvent addRpEvent(RpEvent rpEvent) {
        getRpEvents().add(rpEvent);
        rpEvent.setPerson(this);

        return rpEvent;
    }

    public RpEvent removeRpEvent(RpEvent rpEvent) {
        getRpEvents().remove(rpEvent);
        rpEvent.setPerson(null);

        return rpEvent;
    }
    
    public OtpLockoutInfo addOtpLockoutInfo(OtpLockoutInfo otpLockoutInfo) {
        getOtpLockoutInfo().add(otpLockoutInfo);
        otpLockoutInfo.setPerson(this);
        
        return otpLockoutInfo;
    }

    public OtpLockoutInfo removeOtpLockoutInfo(OtpLockoutInfo otpLockoutInfo) {
        getOtpLockoutInfo().remove(otpLockoutInfo);
        otpLockoutInfo.setPerson(null);
        
        return otpLockoutInfo;
    }

    public String getLexId() {
        return lexId;
    }

    public void setLexId(String lexId) {
        this.lexId = lexId;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public List<OtpLockoutInfo> getOtpLockoutInfo() {
        return otpLockoutInfo;
    }

    public void setOtpLockoutInfo(List<OtpLockoutInfo> otpLockoutInfo) {
        this.otpLockoutInfo = otpLockoutInfo;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public Date getEnteredDateTime() {
        return enteredDateTime;
    }

    public void setEnteredDateTime(Date enteredDateTime) {
        this.enteredDateTime = enteredDateTime;
    }
    
    public Date getTermsConditionsAckDateTime() {
        return termsConditionsAckDateTime;
    }

    public void setTermsConditionsAckDateTime(Date termsConditionsAckDateTime) {
        this.termsConditionsAckDateTime = termsConditionsAckDateTime;
    }

    public Date getLoaAchievedDateTime() {
        return loaAchievedDateTime;
    }

    public void setLoaAchievedDateTime(Date loaAchievedDateTime) {
        this.loaAchievedDateTime = loaAchievedDateTime;
    }

    public boolean isTestUser(){
        return userType != null && userType.equals(USER_TYPE_TEST);
    }
    
    public List<PersonProofingStatus> getProofingStatuses() {
        if (proofingStatuses == null) {
            proofingStatuses = new ArrayList<>();
        }
        
        return this.proofingStatuses;
    }

    public PersonProofingStatus addProofingStatus(PersonProofingStatus proofingStatus) {
        // Need to also ensure that the PK is set.  This assumes that this method is only called for new proofing status records
        PersonProofingStatusPK proofingPK = new PersonProofingStatusPK();
        proofingPK.setPersonId(this.getPersonId());
        proofingPK.setProofingLevelSought(proofingStatus.getRefLoaLevel().getLoaCode());
        proofingStatus.setId(proofingPK);
        
        getProofingStatuses().add(proofingStatus);
        proofingStatus.setPerson(this);

        return proofingStatus;
    }

    public PersonProofingStatus removeProofingStatus(PersonProofingStatus proofingStatus) {
        getProofingStatuses().remove(proofingStatus);
        proofingStatus.setPerson(null);

        return proofingStatus;
    }
    
    
    /**
     * If the user has a previous event in Start status, that event is returned.
     * There should only be one such event at a time.
     * @return
     */
    public IppEvent getEventInStartStatus() {
        IppEvent foundEvent = null;
        
        for (IppEvent event: getIppEvents()) {
            if (event.getRefIppEventStatus().getEventStatusDescription().equals(IPSConstants.IPP_STATUS_STARTED)) {
                foundEvent = event;
                break;
            }
        }
        
        return foundEvent;
    }
    
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((enteredDateTime == null) ? 0 : enteredDateTime.hashCode());
        result = prime * result + ((kbaUid == null) ? 0 : kbaUid.hashCode());
        result = prime * result + ((lexId == null) ? 0 : lexId.hashCode());
        result = prime * result + ((loaAchievedDateTime == null) ? 0 : loaAchievedDateTime.hashCode());
        result = prime * result + ((loaLevelSought == null) ? 0 : loaLevelSought.hashCode());
        result = prime * result + (int) (personId ^ (personId >>> 32));
        result = prime * result + ((pin == null) ? 0 : pin.hashCode());
        result = prime * result + ((sponsorUserId == null) ? 0 : sponsorUserId.hashCode());
        result = prime * result + ((termsConditionsAckDateTime == null) ? 0 : termsConditionsAckDateTime.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        result = prime * result + ((userType == null) ? 0 : userType.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Person other = (Person) obj;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (enteredDateTime == null) {
            if (other.enteredDateTime != null)
                return false;
        } else if (!enteredDateTime.equals(other.enteredDateTime))
            return false;
        if (kbaUid == null) {
            if (other.kbaUid != null)
                return false;
        } else if (!kbaUid.equals(other.kbaUid))
            return false;
        if (lexId == null) {
            if (other.lexId != null)
                return false;
        } else if (!lexId.equals(other.lexId))
            return false;
        if (loaAchievedDateTime == null) {
            if (other.loaAchievedDateTime != null)
                return false;
        } else if (!loaAchievedDateTime.equals(other.loaAchievedDateTime))
            return false;
        if (loaLevelSought == null) {
            if (other.loaLevelSought != null)
                return false;
        } else if (!loaLevelSought.equals(other.loaLevelSought))
            return false;
        if (personId != other.personId)
            return false;
        if (pin == null) {
            if (other.pin != null)
                return false;
        } else if (!pin.equals(other.pin))
            return false;
        if (sponsorUserId == null) {
            if (other.sponsorUserId != null)
                return false;
        } else if (!sponsorUserId.equals(other.sponsorUserId))
            return false;
        if (termsConditionsAckDateTime == null) {
            if (other.termsConditionsAckDateTime != null)
                return false;
        } else if (!termsConditionsAckDateTime.equals(other.termsConditionsAckDateTime))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        if (userType == null) {
            if (other.userType != null)
                return false;
        } else if (!userType.equals(other.userType))
            return false;
        return true;
    }

    /**
     * Returns the person's proofing status for the level of assurance they are seeking.
     * loaSought is a string "1.5", "2.0", etc
     * @return
     */
    public PersonProofingStatus getStatusForLoaSought(String loaSought) {
        PersonProofingStatus status = null;
     
        for (PersonProofingStatus proofingStatus: getProofingStatuses()) {
        	   
        	   if (proofingStatus.getRefLoaLevel() != null) {
	        	   if (proofingStatus.getRefLoaLevel().getLoaLevel() == null) {
	        		   proofingStatus.getRefLoaLevel().setLoaLevel(RefLoaLevel.LOA_15);
	        		   status = proofingStatus;
	        		   break;
	               }
	        	   else {
        	         if (proofingStatus.getRefLoaLevel().getLoaLevel().equals(loaSought)) {
        	        	 status = proofingStatus;
        	                break;
        	          }
	        	   }
        	   }
        }
   
        return status;
    }
    
    /**
     * Resets all levels of assurance to reproofing if they are in a status that should be updated.  Also, resets
     * level achieved to 0 and nulls out the achieved datetime.
     * @param reproofingStatus
     * @param lastUpdateDate
     */
    public boolean resetToReproofingStatus(RefRpStatus reproofingStatus, Person person, PersonVo personVo) {
        boolean statusReset = false;
        
        Date currentDateTime = new Date();
        String existingStatus = null;
        long existingStatusCode;
        
        for (PersonProofingStatus proofingStatus: getProofingStatuses()) {
            existingStatus = proofingStatus.getStatusDescription();
            existingStatusCode = proofingStatus.getRefRpStatus().getStatusCode();
            boolean hasAchievedLoaLevel = false;
			
            if (person.getAchievedLoaLevel() != null
              		 && person.getAchievedLoaLevel().getLoaLevel() != null
              		 && ApplicationConstants.LOA_15.equals(person.getAchievedLoaLevel().getLoaLevel())) {
                    hasAchievedLoaLevel = true;
            }
            
            boolean statusIsLoaAchieved = hasAchievedLoaLevel || IPSConstants.STATUS_LOA_ACHIEVED.equalsIgnoreCase(existingStatus);
            
            //True if status requires a user to start over for reproof
            boolean statusIsStartOver = 
                    existingStatus.equals(IPSConstants.STATUS_LOA_ACHIEVED)    ||
                    existingStatus.equals(IPSConstants.STATUS_RP_PASSED)       ||
                    existingStatus.equals(IPSConstants.STATUS_IPP_PASSED)      ||
                    existingStatus.equals(IPSConstants.STATUS_PROFILE_UPDATED) ||
                    existingStatus.equals(IPSConstants.STATUS_ACTIVATION_EMAIL_SENT);
            
            //True if status code requires a user to start over for reproof.
            //Phone_verification_initiated RpStatus was added to handle scenario when user navigates to 
            //VerificationUserInfo page via breadcrumbs after changing of name and address profile data. 
            boolean statusCodeIsStartOver = 
                    existingStatusCode == RefRpStatus.RpStatus.Phone_verification_initiated.getValue() ||
                    existingStatusCode == RefRpStatus.RpStatus.Phone_verified.getValue()             ||
                    existingStatusCode == RefRpStatus.RpStatus.OTP_initiated.getValue()              ||
                    existingStatusCode == RefRpStatus.RpStatus.OTP_sent.getValue()                   ||
                    existingStatusCode == RefRpStatus.RpStatus.OTP_confirmation_initiated.getValue() ||
                    existingStatusCode == RefRpStatus.RpStatus.OTP_confirmation_failed.getValue()    ||
                    existingStatusCode == RefRpStatus.RpStatus.SMFA_initiated.getValue()             ||
                    existingStatusCode == RefRpStatus.RpStatus.SMFA_sent.getValue()                ||
                    existingStatusCode == RefRpStatus.RpStatus.SMFA_validation_failed.getValue();
            
            // Checks to see if the user's status should be reset based on the current status.  
            // If the profile update means they should reproof, these are the statuses that require the user to start over.
            // The short circuit on the OR for LOA Achieved is deliberate - we will start over if the status is LOA Achieved -
            // CustReg will only send someone to IVS if their profile was updated in a way that caused them to lose the Level of assurance
            if (statusIsLoaAchieved || (getPersonData().hasProfileDataChanged(personVo) && (statusIsStartOver || statusCodeIsStartOver))) {
                
                proofingStatus.setRefRpStatus(reproofingStatus);
                proofingStatus.setProofingStatusDatetime(currentDateTime);
                proofingStatus.setUpdateDate(currentDateTime);
                statusReset = true;
            }
        }
        
        return statusReset;
    }
    
    /**
     * Updates the credential used datetime on the proofing status for the specified loa.
     * @param loa
     */
    public void recordCredentialUsed(String loa) {
        Date currentDate = new Date();
        PersonProofingStatus status = getStatusForLoaSought(loa);
        status.setCredentialUsedDateTime(currentDate);
    }
    
    public List<DataConsent> getDataConsents() {
        if (dataConsents == null) {
            dataConsents = new ArrayList<>();
        }
        
        return this.dataConsents;
    }

    public void setDataConsents(List<DataConsent> dataConsents) {
        this.dataConsents = dataConsents;
    }

    public DataConsent addDataConsent(DataConsent dataConsent) {
        getDataConsents().add(dataConsent);
        dataConsent.setPerson(this);

        return dataConsent;
    }

    public DataConsent removeDataConsent(DataConsent dataConsent) {
        getDataConsents().remove(dataConsent);
        dataConsent.setPerson(null);

        return dataConsent;
    }
    
    /** This method determines if the person is locked out with ANY supplier for the specified LOA level.
     * 
     * @param level
     * @param verifyMethod
     * @return
     */
    public OtpLockoutInfo hasPriorLockout(RefLoaLevel level) {
        // This loop checks whether the lockout record already exists
        
        for (OtpLockoutInfo lockout: getOtpLockoutInfo()) {
            if (lockout.getRefLoaLevel().getLoaCode() == level.getLoaCode()) {
                return lockout;
            }
        }
        
        return null;
    }
    
    /** This method determines if the person is locked out for the specified LOA level and verification method.
     * 
     * @param level
     * @param verifyMethod
     * @return
     */
    public OtpLockoutInfo hasLockout(RefLoaLevel level, RefOtpSupplier verifyMethod) {
        // With the addition of phone otp, this check needs to include LOA level AND KBA supplier (KBA and phone are different suppliers)
        // This loop is just to check whether the lockout record already exists
        
        for (OtpLockoutInfo lockout: getOtpLockoutInfo()) {
            if (lockout.getRefLoaLevel().getLoaCode() == level.getLoaCode() &&
                    lockout.getRefOtpSupplier() != null && lockout.getRefOtpSupplier().getOtpSupplierId() == verifyMethod.getOtpSupplierId()) {
                return lockout;
            }
        }
        
        return null;
    }
}
