package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "sponsor_facilities")
@NamedQuery(name="SponsorFacilities.findActiveFacilitiesBySponsorId", query="SELECT f FROM SponsorFacilities f WHERE f.id.sponsorId = :sponsorId AND f.activationDate <= CURRENT_DATE")
@NamedQuery(name="SponsorFacilities.findActiveFacilitiesIdsBySponsorId", query="SELECT f.id.refFacilityId FROM SponsorFacilities f WHERE f.id.sponsorId = :sponsorId AND f.activationDate <= CURRENT_DATE")
@NamedQuery(name="SponsorFacilities.findFacilitybySponsorIdAndFacilityId", query="SELECT f FROM SponsorFacilities f WHERE f.id.sponsorId = :sponsorId AND f.id.refFacilityId = :facilityId")
@NamedQuery(name="SponsorFacilities.getActiveFacilitiesCountBySponsorId", query="SELECT COUNT(f) FROM SponsorFacilities f WHERE f.id.sponsorId = :sponsorId AND f.activationDate <= CURRENT_DATE")
@NamedQuery(name="SponsorFacilities.deactivateAll", query="UPDATE SponsorFacilities f SET f.activationDate = :activationDate")
@NamedQuery(name="SponsorFacilities.findSponsorFacilitiesBySponsor", query="SELECT r FROM SponsorFacilities r WHERE r.id.sponsorId = :sponsorId")

public class SponsorFacilities implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @EmbeddedId
    private SponsorFacilitiesPK id;
    
    @Column(name = "ACTIVATION_DATE")
    private Date activationDate;
    
    @Column(name = "CREATE_DATE")
    private Date createDate;
    
    @Column(name = "UPDATE_DATE")
    private Date updateDate;
    
    public SponsorFacilitiesPK getId() {
        return id;
    }
    public void setId(SponsorFacilitiesPK id) {
        this.id = id;
    }
    
    public Date getActivationDate() {
        return activationDate;
    }
    public void setActivationDate(Date activationDate) {
        this.activationDate = activationDate;
    }
    
    public Date getCreateDate() {
        return createDate;
    }
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
    
    public Date getUpdateDate() {
        return updateDate;
    }
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
