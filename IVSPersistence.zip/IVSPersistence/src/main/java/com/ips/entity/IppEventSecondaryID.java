package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the ipp_event_secondary_ids database table.  Created for IAL2 since there can be two
 * fair IDs (secondary IDs) for an event.
 * 
 */
@Entity
@Table(name="ipp_event_secondary_ids")
@NamedQueries({
    @NamedQuery(name = "IppEventSecondaryID.getSecondaryIdCountByEventSecondary", query = "SELECT COUNT(i) FROM IppEventSecondaryID i "
            + "WHERE i.refSecondaryIdType.idType = :idType "),
    @NamedQuery(name = "IppEventSecondaryID.getSecondaryIds", query = "SELECT i FROM IppEventSecondaryID i "
            + "WHERE i.ippEvent.ippEventId = :ippEventId ")

})
public class IppEventSecondaryID implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ipp_event_secondary_idsSeq")
    @SequenceGenerator(name="ipp_event_secondary_idsSeq",sequenceName="IPP_EVENT_SECONDARY_IDS_SEQ", allocationSize=1)
    @Column(name = "EVENT_SECONDARY_ID")
    private long eventSecondaryId;

    @Column(name="ipp_event_id")
    private long ippEventId;
    
    @Column(name="CREATE_DATE")
    private Timestamp createDate;
    
    @Column(name="UPDATE_DATE")
    private Date updateDate;
    
    //bi-directional many-to-one association to RefSecondaryIdType
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="secondary_id_type")
    private RefSecondaryIdType refSecondaryIdType;
    
  //bi-directional one-to-one association to IppEvent
    @OneToOne
    @JoinColumn(name="IPP_Event_ID" , insertable = false, updatable = false )
    private IppEvent ippEvent;
    
    public Timestamp getCreateDate() {
        return this.createDate;
    }
    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return this.updateDate;
    }
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

     //id corresponding to the value of secondary id type
    public RefSecondaryIdType getRefSecondaryIdType() {
        return this.refSecondaryIdType;
    }
    public void setRefSecondaryIdType(RefSecondaryIdType refSecondaryIdType) {
        this.refSecondaryIdType = refSecondaryIdType;
    }
	public long getIppEventId() {
		return ippEventId;
	}
	public void setIppEventId(long ippEventId) {
		this.ippEventId = ippEventId;
	}
	public IppEvent getIppEvent() {
		return ippEvent;
	}
	public void setIppEvent(IppEvent ippEvent) {
		this.ippEvent = ippEvent;
	}
}
