package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;

/**
 * The persistent class for the high_risk_address_attempts database table.
 * 
 */
@Entity
@Table(name="high_risk_address_attempts")
public class HighRiskAddressAttempt implements Serializable {
    private static final long serialVersionUID = 1L;
     
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="high_risk_address_attemptsSeq")
    @SequenceGenerator(name="high_risk_address_attemptsSeq",sequenceName="HIGH_RISK_ADDRESS_ATTEMPTS_SEQ", allocationSize=1)
    @Column(name="high_risk_attempt_id")
    private long highRiskAttemptId;
    
    //bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name="person_id")
    private Person person;

    @Column(name="attempt_datetime")
    private Timestamp attemptDateTime;
    
    @Column(name="UPDATE_DATE")
    private Date updateDate;
    
    //bi-directional one-to-one association to IppEvent
    @OneToOne
    @JoinColumn(name="ipp_event_id")
    private IppEvent ippEvent;

    //bi-directional many-to-one association to HighRiskAddressAttempt
    @ManyToOne
    @JoinColumn(name="high_risk_address_id")
    private HighRiskAddress highRiskAddress;

    public long getHighRiskAttemptId() {
        return highRiskAttemptId;
    }

    public void setHighRiskAttemptId(long highRiskAttemptId) {
        this.highRiskAttemptId = highRiskAttemptId;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Timestamp getAttemptDateTime() {
        return attemptDateTime;
    }

    public void setAttemptDateTime(Timestamp attemptDateTime) {
        this.attemptDateTime = attemptDateTime;
    }

    public IppEvent getIppEvent() {
        return ippEvent;
    }

    public void setIppEvent(IppEvent ippEvent) {
        this.ippEvent = ippEvent;
    }

    public HighRiskAddress getHighRiskAddress() {
        return highRiskAddress;
    }

    public void setHighRiskAddress(HighRiskAddress highRiskAddress) {
        this.highRiskAddress = highRiskAddress;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
