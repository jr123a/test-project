package com.ips.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the lookup_codes_env database table.
 * 
 */
@Embeddable
public class LookupCodesEnvPK  implements Serializable{
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Column(name = "ENV")
	    private String env;
	    @Column(name = "NAME")
	    private String name;
	    
	    public String getEnv() {
	        return env;
	    }

	    public void setEnv(String env) {
	        this.env = env;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }
	    
	    public boolean equals(Object other) {
	        if (this == other) {
	            return true;
	        }
	        if (!(other instanceof LookupCodesEnvPK)) {
	            return false;
	        }
	        LookupCodesEnvPK castOther = (LookupCodesEnvPK)other;
	        return 
	            (this.env == castOther.env)
	            && (this.name == castOther.name);
	    }


	    public int hashCode() {
	        final int prime = 31;
	        int hash = 17;
	        hash = hash * prime +(env == null ? 0 : env.hashCode());
	        hash = hash * prime +(name == null ? 0 : name.hashCode());
	        
	        return hash;
	    }
}
