package com.ips.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class SponsorEmailValuesPK implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "sponsor_id")
    private long sponsorId;
    
    @Column(name = "email_type")
    private long emailType;
    
    public long getSponsorId() {
        return sponsorId;
    }
    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }
    
    public long getEmailType() {
        return emailType;
    }
    public void setEmailType(long emailType) {
        this.emailType = emailType;
    }
    
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SponsorEmailValuesPK)) {
            return false;
        }
        SponsorEmailValuesPK cast = (SponsorEmailValuesPK) other;
        return this.sponsorId == cast.sponsorId && this.emailType == cast.emailType;
    }
    
    @Override
    public int hashCode() {
        final long prime = 31;
        long hash = 17;
        hash = hash * prime + this.sponsorId;
        hash = hash * prime + this.emailType;
        return (int) hash;
    }
}
