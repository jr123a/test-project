package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rp_truth_data_send_email")
    @NamedQueries({
            @NamedQuery(name = "RpTruthDataSendEmail.getAll", query = "SELECT e FROM RpTruthDataSendEmail e"),
            @NamedQuery(name = "RpTruthDataSendEmail.getPendingBlacklist", query = "SELECT e FROM RpTruthDataSendEmail e WHERE e.addedToBlacklist IS NULL")
})
    
public class RpTruthDataSendEmail implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="rp_truth_data_send_emailSeq")
    @SequenceGenerator(name="rp_truth_data_send_emailSeq",sequenceName="RP_TRUTH_DATA_SEND_EMAIL_SEQ", allocationSize=1)
    @Column(name = "truth_data_send_email_id")
    private long truthDataSendEmailId;

    @Column(name = "email_address")
    private String emailAddress;
    
    @Column(name = "sent_final_review_status")
    private String sentFinalReviewStatus;
    
    @Column(name = "added_to_blacklist")
    private String addedToBlacklist;
    
    @Column(name = "sent_date")
    private Date sentDate;
    
    @Column(name = "date_added")
    private Date dateAdded;

    @Column(name = "create_date")
    private Date createDate;
    
    @Column(name = "update_date")
    private Date updateDate;

    public long getTruthDataSendEmailId() {
        return truthDataSendEmailId;
    }

    public void setTruthDataSendEmailId(long truthDataSendEmailId) {
        this.truthDataSendEmailId = truthDataSendEmailId;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getSentFinalReviewStatus() {
        return sentFinalReviewStatus;
    }

    public void setSentFinalReviewStatus(String sentFinalReviewStatus) {
        this.sentFinalReviewStatus = sentFinalReviewStatus;
    }

    public String getAddedToBlacklist() {
        return addedToBlacklist;
    }

    public void setAddedToBlacklist(String addedToBlacklist) {
        this.addedToBlacklist = addedToBlacklist;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }

    public Date getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(Date dateAdded) {
        this.dateAdded = dateAdded;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

}
