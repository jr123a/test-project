package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the id_images database table.
 * 
 */
@Entity
@Table(name = "id_images")
@NamedQuery(name = "IdImages.findIdImagesByippEventIdandIdType", query = "SELECT i FROM IdImages i WHERE i.ippEventId = :ippEventId and i.idType=:idType and i.idNumber=:idNumber")
@NamedQuery(name = "IdImages.findIdImagesByippEventIdandIdNumber", query = "SELECT i FROM IdImages i WHERE i.ippEventId = :ippEventId and i.idNumber=:idNumber")
public class IdImages implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ID_IMAGESSEQ")
    @SequenceGenerator(name="ID_IMAGESSEQ",sequenceName="ID_IMAGES_SEQ", allocationSize=1)
	@Column(name = "FAIR_ID_IMAGE_ID")
	private long fairIdImageId;

	@Column(name = "IPP_EVENT_ID")
	private long ippEventId;

	@Column(name = "ID_TYPE")
	private Long idType;

	@Column(name = "ID_NUMBER")
	private Long idNumber;

	@Lob
	@Column(name = "ID_IMAGE_FRONT")
	private byte[] idImageFront;
	
    @Lob
	@Column(name = "ID_IMAGE_BACK")
	private byte[] idImageBack;

	@Column(name = "CREATE_DATE")
	private Date createDate;

	@Column(name = "UPDATE_DATE")
	private Date updateDate;

	public long getFairIdImageId() {
		return fairIdImageId;
	}

	public void setFairIdImageId(long fairIdImageId) {
		this.fairIdImageId = fairIdImageId;
	}

	public long getIppEventId() {
		return ippEventId;
	}

	public void setIppEventId(long ippEventId) {
		this.ippEventId = ippEventId;
	}

	public Long getIdType() {
		return idType;
	}

	public void setIdType(Long idType) {
		this.idType = idType;
	}

	public Long getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(Long idNumber) {
		this.idNumber = idNumber;
	}

	public byte[] getIdImageFront() {
		return idImageFront;
	}

	public void setIdImageFront(byte[] idImageFront) {
		this.idImageFront = idImageFront;
	}

	public byte[] getIdImageBack() {
		return idImageBack;
	}

	public void setIdImageBack(byte[] idImageBack) {
		this.idImageBack = idImageBack;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

}
