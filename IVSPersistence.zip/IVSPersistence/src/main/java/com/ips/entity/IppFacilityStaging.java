package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ipp_appointment database table.
 * 
 */
@Entity
@Table(name="ipp_facility_staging")
@NamedQueries({
    @NamedQuery(name="IppFacilityStaging.findAll", 
    	query="SELECT i FROM IppFacilityStaging i"),    
    @NamedQuery(name="IppFacilityStaging.findByPrimaryKey", 
    	query="SELECT i FROM IppFacilityStaging i WHERE i.id.facilityId = :facilityId "
    		+ "AND i.id.ufn = :ufn "),    
    @NamedQuery(name="IppFacilityStaging.findByFacilityId", 
    	query="SELECT i FROM IppFacilityStaging i WHERE i.id.facilityId = :facilityId "),
    @NamedQuery(name="IppFacilityStaging.findByUfn", 
    	query="SELECT i FROM IppFacilityStaging i WHERE i.id.ufn = :ufn "),
    @NamedQuery(name="IppFacilityStaging.deleteAll", 
    	query="DELETE FROM IppFacilityStaging")    
})

public class IppFacilityStaging implements Serializable {
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private IppFacilityStagingPK id;
    
    @Column(name="CHANNEL")
    private String channel;

    @Column(name="NODE_COUNT")
    private long nodeCount;

    @Column(name="SITENAME")
    private String siteName;
    
    @Column(name="ZIPCODE")
    private String zipCode;

    @Column(name="STATE")
    private String state;

    @Column(name="CREATE_DATE")
    private Date createDate;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((channel == null) ? 0 : channel.hashCode());
        result = prime * result + (int) nodeCount;
        result = prime * result + ((siteName == null) ? 0 : siteName.hashCode());
        result = prime * result + ((zipCode == null) ? 0 : zipCode.hashCode());
        result = prime * result + ((state == null) ? 0 : state.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        
        IppFacilityStaging other = (IppFacilityStaging) obj;

        if (channel == null) {
            if (other.channel != null)
                return false;
        } else if (!channel.equals(other.channel))
            return false;
        if (siteName == null) {
            if (other.siteName != null)
                return false;
        } else if (!siteName.equals(other.siteName))
            return false;
        if (zipCode == null) {
            if (other.zipCode != null)
                return false;
        } else if (!zipCode.equals(other.zipCode))
            return false;
        if (state == null) {
            if (other.state != null)
                return false;
        } else if (!state.equals(other.state))
            return false;

     	return (this.nodeCount == other.nodeCount);
    }

	public IppFacilityStagingPK getId() {
		return id;
	}

	public void setId(IppFacilityStagingPK id) {
		this.id = id;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public long getNodeCount() {
		return nodeCount;
	}

	public void setNodeCount(long nodeCount) {
		this.nodeCount = nodeCount;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

}
