package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the IdPersonDetails database table.
 * 
 */
@Entity
@Table(name="id_person_details")
public class IdPersonDetails implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="id_person_detailsSeq")
    @SequenceGenerator(name="id_person_detailsSeq",sequenceName="ID_PERSON_DETAILS_SEQ", allocationSize=1)
    @Column(name = "PERSON_DETAIL_ID")
    private long personDetailId;
    
    @OneToOne
    @JoinColumn(name = "DOCUMENT_DETAIL_ID")
    private IdDocumentDetails documentDetail;

    @Column(name = "DETAIL_DATA")
    private String detailData;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;
    
    @Column(name = "EYE_COLOR")
    private String eyeColor;

    public long getPersonDetailId() {
        return personDetailId;
    }

    public IdDocumentDetails getDocumentDetail() {
        return documentDetail;
    }

    public void setDocumentDetail(IdDocumentDetails detail) {
        this.documentDetail = detail;
        detail.setIdPersonDetails(this);
    }

    public String getDetailData() {
        return detailData;
    }

    public void setDetailData(String detailData) {
        this.detailData = detailData;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

	public String getEyeColor() {
		return eyeColor;
	}

	public void setEyeColor(String eyeColor) {
		this.eyeColor = eyeColor;
	}
}
