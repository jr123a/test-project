package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the ref_attribute_group database table.
 * 
 */
@Entity
@Table(name="REF_ATTRIBUTE_GROUP")
@NamedQueries({
    @NamedQuery(name="RefAttributeGroup.findAll", query="SELECT r FROM RefAttributeGroup r"),
    @NamedQuery(name="RefAttributeGroup.findByIndex", query="SELECT r FROM RefAttributeGroup r WHERE r.id.attributeIndex = :attrIndex ORDER BY r.displayOrder")
})    
public class RefAttributeGroup implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final short ATTRIBUTE_GROUP_ONE = 1;
    
    @EmbeddedId
    private RefAttributeGroupPK id;

    @Column(name="REQUIRED_INDICATOR")
    private String requiredIndicator;
    
    @Column(name="DISPLAY_ORDER")
    private short displayOrder;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;
    
    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;
        
    public RefAttributeGroupPK getId() {
        return id;
    }

    public void setId(RefAttributeGroupPK id) {
        this.id = id;
    }

    public String getRequiredIndicator() {
        return requiredIndicator;
    }

    public void setRequiredIndicator(String requiredIndicator) {
        this.requiredIndicator = requiredIndicator;
    }

    public short getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(short displayOrder) {
        this.displayOrder = displayOrder;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

}
