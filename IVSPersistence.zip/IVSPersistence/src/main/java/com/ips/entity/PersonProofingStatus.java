package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;


import java.sql.Timestamp;
import java.util.Date;

/**
 * The persistent class for the person_proofing_status database table.
 * 
 */
@Entity
@Table(name="person_proofing_status")
@NamedQueries({
    @NamedQuery(name="PersonProofingStatus.findAll", query="SELECT p FROM PersonProofingStatus p"),
    @NamedQuery(name="PersonProofingStatus.findUnusedCredentials", query="SELECT p FROM PersonProofingStatus p WHERE p.refLoaLevel = :loaLevel AND " +
            "p.person.refLoaLevel = :loaLevel AND p.person.userType IS NULL AND p.credentialUsedDateTime <= :eighteenMonthsAgo "),
   @NamedQuery(name="PersonProofingStatus.getByPersonId", query="SELECT p FROM PersonProofingStatus p WHERE p.person.personId = :personId")
})   
public class PersonProofingStatus implements Serializable {
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private PersonProofingStatusPK id;

    @Column(name="create_date")
    private Timestamp createDate;
    
    @Column(name="proofing_status_datetime")
    private Date proofingStatusDatetime;
    
    @Column(name="update_date")
    private Date updateDate;
    
    @Column(name="used_cred_datetime")
    private Date credentialUsedDateTime;
    
    @Column(name="cred_expired_datetime")
    private Date credentialExpiredDateTime;
    
    @Column(name="activation_code")
    private String activationCode;
    
    @Column(name="code_expiration_date")
    private Date codeExpirationDate;
    
    //bi-directional many-to-one association to RefRpStatus
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
    @JoinColumn(name="Proofing_status")
    private RefRpStatus refRpStatus;
    
    //many-to-one association to RefLoaLevel
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="proofing_level_sought" , insertable = false, updatable = false )
    private RefLoaLevel refLoaLevel;

    //bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name="person_id" , insertable = false, updatable = false )
    private Person person;

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Date getProofingStatusDatetime() {
        return this.proofingStatusDatetime;
    }

    public void setProofingStatusDatetime(Date proofingStatusDatetime) {
        this.proofingStatusDatetime = proofingStatusDatetime;
    }

    public Date getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public RefRpStatus getRefRpStatus() {
        return this.refRpStatus;
    }

    public void setRefRpStatus(RefRpStatus refRpStatus) {
        this.refRpStatus = refRpStatus;
        
        // Ensure that LOA achieved datetime gets set on Person
        if (refRpStatus.isLoaAchieved()) {
            Date currentDateTime = new Date();
            getPerson().setAchievedLoaLevel(refLoaLevel);
            getPerson().setLoaAchievedDateTime(currentDateTime);
        }
    }
    
    public String getStatusDescription() {
        return this.refRpStatus.getStatusDescription();
    }
    
    public Long getStatusCode() {
        return this.refRpStatus.getStatusCode();
    }

    public RefLoaLevel getRefLoaLevel() {
        return refLoaLevel;
    }

    public void setRefLoaLevel(RefLoaLevel refLoaLevel) {
        this.refLoaLevel = refLoaLevel;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
    
    public PersonProofingStatusPK getId() {
        return id;
    }

    public void setId(PersonProofingStatusPK id) {
        this.id = id;
    }

    public Date getCredentialUsedDateTime() {
        return credentialUsedDateTime;
    }

    public void setCredentialUsedDateTime(Date credentialUsedDateTime) {
        this.credentialUsedDateTime = credentialUsedDateTime;
    }

    public Date getCredentialExpiredDateTime() {
        return credentialExpiredDateTime;
    }

    public void setCredentialExpiredDateTime(Date credentialExpiredDateTime) {
        this.credentialExpiredDateTime = credentialExpiredDateTime;
    }

    public String getActivationCode() {
        return activationCode;
    }

    public void setActivationCode(String activationCode) {
        this.activationCode = activationCode;
    }

    public Date getCodeExpirationDate() {
        return codeExpirationDate;
    }

    public void setCodeExpirationDate(Date codeExpirationDate) {
        this.codeExpirationDate = codeExpirationDate;
    }

    
    public boolean isIppEmailSent() {
        return getRefRpStatus().isIppEmailSent();
    }
    
    public boolean isIppFailed() {
        return getRefRpStatus().isIppFailed();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((activationCode == null) ? 0 : activationCode.hashCode());
        result = prime * result + ((codeExpirationDate == null) ? 0 : codeExpirationDate.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((credentialExpiredDateTime == null) ? 0 : credentialExpiredDateTime.hashCode());
        result = prime * result + ((credentialUsedDateTime == null) ? 0 : credentialUsedDateTime.hashCode());
        result = prime * result + ((proofingStatusDatetime == null) ? 0 : proofingStatusDatetime.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PersonProofingStatus other = (PersonProofingStatus) obj;
        if (activationCode == null) {
            if (other.activationCode != null)
                return false;
        } else if (!activationCode.equals(other.activationCode))
            return false;
        if (codeExpirationDate == null) {
            if (other.codeExpirationDate != null)
                return false;
        } else if (!codeExpirationDate.equals(other.codeExpirationDate))
            return false;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (credentialExpiredDateTime == null) {
            if (other.credentialExpiredDateTime != null)
                return false;
        } else if (!credentialExpiredDateTime.equals(other.credentialExpiredDateTime))
            return false;
        if (credentialUsedDateTime == null) {
            if (other.credentialUsedDateTime != null)
                return false;
        } else if (!credentialUsedDateTime.equals(other.credentialUsedDateTime))
            return false;
        if (proofingStatusDatetime == null) {
            if (other.proofingStatusDatetime != null)
                return false;
        } else if (!proofingStatusDatetime.equals(other.proofingStatusDatetime))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }
}