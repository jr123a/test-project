package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the ref_secondary_id_type database table.
 * 
 */
@Entity
@Table(name="ref_secondary_id_type")
@NamedQueries({ 
    @NamedQuery(name = "RefSecondaryIdType.findAll", query = "SELECT r FROM RefSecondaryIdType r order by r.idType asc"),
    @NamedQuery(name="RefSecondaryIdType.findAvailableFairList", query="SELECT r1 FROM RefSecondaryIdType r1 WHERE r1.fairId = 'Y' AND r1.idType NOT IN (SELECT r2.idType FROM RefSecondaryIdType r2 WHERE r2.fairId = 'Y' AND r2.idType IN (SELECT s.id.idType FROM SponsorFairId s WHERE s.id.sponsorId = :sponsorId))"),
    @NamedQuery(name="RefSecondaryIdType.findSponsorFairList", query="SELECT r FROM RefSecondaryIdType r WHERE r.fairId = 'Y' AND r.idType IN (SELECT s.id.idType FROM SponsorFairId s WHERE s.id.sponsorId = :sponsorId)"),
    @NamedQuery(name = "RefSecondaryIdType.findAllByIdType", query = "SELECT r FROM RefSecondaryIdType r  WHERE r.idType = :idType"),
    @NamedQuery(name="RefSecondaryIdType.getDescription", query="SELECT r.idTypeDescription FROM RefSecondaryIdType r WHERE r.idType = :idType")
})
public class RefSecondaryIdType implements Serializable {
    
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id_type")
    private long idType;

    @Column(name = "create_date")
    private Timestamp createDate;

    @Column(name = "id_type_description")
    private String idTypeDescription;

    @Column(name = "update_date")
    private Timestamp updateDate;
    
    @Column(name = "fair_id")
    private String fairId;
    
    @Column(name = "have_name")
    private String hasName;
    
    @Column(name = "have_adress")
    private String hasAddress;
    
    @Column(name = "firstlastpage")
    private String hasFirstLastPage;
    
    @Column(name = "isstateid")
    private String isStateid;
    
    @Column(name = "capturebarcode")
    private String captureBarcode;

    
    // bi-directional many-to-one association to IppEvent
    @OneToMany(mappedBy = "refSecondaryIdType")
    private List<IppEvent> ippEvents;

    @Transient
    private boolean selected;

    public RefSecondaryIdType() {
    
    }
    
    public long getIdType() {
        return this.idType;
    }

    public void setIdType(long idType) {
        this.idType = idType;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getIdTypeDescription() {
        return this.idTypeDescription;
    }

    public void setIdTypeDescription(String idTypeDescription) {
        this.idTypeDescription = idTypeDescription;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<IppEvent> getIppEvents() {
        return this.ippEvents;
    }

    public void setIppEvents(List<IppEvent> ippEvents) {
        this.ippEvents = ippEvents;
    }

    public IppEvent addIppEvent(IppEvent ippEvent) {
        getIppEvents().add(ippEvent);
        ippEvent.setRefSecondaryIdType(this);

        return ippEvent;
    }

    public IppEvent removeIppEvent(IppEvent ippEvent) {
        getIppEvents().remove(ippEvent);
        ippEvent.setRefSecondaryIdType(null);

        return ippEvent;
    }

    public String getFairId() {
        return fairId;
    }

    public void setFairId(String fairId) {
        this.fairId = fairId;
    }
    
    public boolean isFairId() {
        return "Y".equalsIgnoreCase(getFairId());
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    
    public String getHasName() {
        return hasName;
    }

    public void setHasName(String hasName) {
        this.hasName = hasName;
    }
    
    public String getHasAddress() {
        return hasAddress;
    }

    public void setHasAddress(String hasAddress) {
        this.hasAddress = hasAddress;
    }
    public String getHasFirstLastPage() {
		return hasFirstLastPage;
	}

	public void setHasFirstLastPage(String hasFirstLastPage) {
		this.hasFirstLastPage = hasFirstLastPage;
	}

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((captureBarcode == null) ? 0 : captureBarcode.hashCode());
		result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
		result = prime * result + ((fairId == null) ? 0 : fairId.hashCode());
		result = prime * result + ((hasAddress == null) ? 0 : hasAddress.hashCode());
		result = prime * result + ((hasFirstLastPage == null) ? 0 : hasFirstLastPage.hashCode());
		result = prime * result + ((hasName == null) ? 0 : hasName.hashCode());
		result = prime * result + (int) (idType ^ (idType >>> 32));
		result = prime * result + ((idTypeDescription == null) ? 0 : idTypeDescription.hashCode());
		result = prime * result + ((ippEvents == null) ? 0 : ippEvents.hashCode());
		result = prime * result + ((isStateid == null) ? 0 : isStateid.hashCode());
		result = prime * result + (selected ? 1231 : 1237);
		result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
		return result;
	}

    @Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RefSecondaryIdType other = (RefSecondaryIdType) obj;
		if (captureBarcode == null) {
			if (other.captureBarcode != null)
				return false;
		} else if (!captureBarcode.equals(other.captureBarcode))
			return false;
		if (createDate == null) {
			if (other.createDate != null)
				return false;
		} else if (!createDate.equals(other.createDate))
			return false;
		if (fairId == null) {
			if (other.fairId != null)
				return false;
		} else if (!fairId.equals(other.fairId))
			return false;
		if (hasAddress == null) {
			if (other.hasAddress != null)
				return false;
		} else if (!hasAddress.equals(other.hasAddress))
			return false;
		if (hasFirstLastPage == null) {
			if (other.hasFirstLastPage != null)
				return false;
		} else if (!hasFirstLastPage.equals(other.hasFirstLastPage))
			return false;
		if (hasName == null) {
			if (other.hasName != null)
				return false;
		} else if (!hasName.equals(other.hasName))
			return false;
		if (idType != other.idType)
			return false;
		if (idTypeDescription == null) {
			if (other.idTypeDescription != null)
				return false;
		} else if (!idTypeDescription.equals(other.idTypeDescription))
			return false;
		if (ippEvents == null) {
			if (other.ippEvents != null)
				return false;
		} else if (!ippEvents.equals(other.ippEvents))
			return false;
		if (isStateid == null) {
			if (other.isStateid != null)
				return false;
		} else if (!isStateid.equals(other.isStateid))
			return false;
		if (selected != other.selected)
			return false;
		if (updateDate == null) {
			if (other.updateDate != null)
				return false;
		} else if (!updateDate.equals(other.updateDate))
			return false;
		return true;
	}

	public String getIsStateid() {
		return isStateid;
	}

	public void setIsStateid(String isStateid) {
		this.isStateid = isStateid;
	}

	public String getCaptureBarcode() {
		return captureBarcode;
	}

	public void setCaptureBarcode(String captureBarcode) {
		this.captureBarcode = captureBarcode;
	}
}