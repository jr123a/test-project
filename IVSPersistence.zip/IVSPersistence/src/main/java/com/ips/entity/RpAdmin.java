package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the rp_admin database table.
 * 
 */
@Entity
@Table(name="rp_admin")
@NamedQuery(name="RpAdmin.findRpAdminBySponsor", query="SELECT r FROM RpAdmin r WHERE r.sponsorId = :sponsorId")

public class RpAdmin implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="USER_ID")
    private String userId;

    @Column(name="SPONSOR_ID")
    private Long sponsorId;

    @Column(name="APP_ID")
    private Long appId;
    
    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    //bi-directional many-to-one association to RefAdminEvent
    @ManyToOne
    @JoinColumn(name="ADMIN_EVENT_ID")
    private RefAdminEvent refAdminEvent;

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Long getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(Long sponsorId) {
        this.sponsorId = sponsorId;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }
    
    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public RefAdminEvent getRefAdminEvent() {
        return this.refAdminEvent;
    }

    public void setRefAdminEvent(RefAdminEvent refAdminEvent) {
        this.refAdminEvent = refAdminEvent;
    }

}
