package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the IdVerifyServiceRequests database table.
 * 
 */
@Entity
@Table(name="id_verify_service_requests")
@NamedQuery(name = "IdVerifyServiceRequest.getByEvent", query = "SELECT i FROM IdVerifyServiceRequest i "
                    + "WHERE i.ippEventId = :eventId ")
@NamedQuery(name="IdVerifyServiceRequest.findIdVerifyServiceRequestBySponsor", query="SELECT r FROM IdVerifyServiceRequest r WHERE r.refSponsor.sponsorId = :sponsorId")

public class IdVerifyServiceRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="id_verify_service_requestsSeq")
    @SequenceGenerator(name="id_verify_service_requestsSeq",sequenceName="ID_VERIFY_SERVICE_REQUESTS_SEQ", allocationSize=1)
    @Column(name = "VERIFY_REQUEST_ID")
    private long verifyRequestId;
    
    @ManyToOne
    @JoinColumn(name = "API_ID")
    private VendorAPI vendorAPI;

    // bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name = "SPONSOR_ID")
    private RefSponsor refSponsor;

    @Column(name = "REQUEST_ID")
    private String requestId;

    @Column(name = "IPP_EVENT_ID")
    private long ippEventId;

    @Column(name = "EFX_CLIENT_CORRELATION_ID")
    private String efxClientCorrelationId;

    @Column(name = "REFERENCE_TRANSACTION_ID")
    private String referenceTransactionId;

    @Column(name = "CONSUMER_ID")
    private String consumerId;
    
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="document_type")
    private RefPrimaryIdType documentType;

    @Column(name = "CONVERSATION_ID")
    private String conversationId;

    @Column(name = "REQUEST_SENT_DATETIME")
    private Timestamp requestSentDateTime;

    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name = "STATUS_ID")
    private RefValidationStatusCode statusId;

    @Column(name = "ERROR_CODE")
    private String errorCode;

    @Column(name = "ERROR_MESSAGE")
    private String errorMessage;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;
    
    @Column(name = "JSON_REQUEST")
    private String jsonRequest;

    public RefSponsor getRefSponsor() {
        return refSponsor;
    }

    public void setRefSponsor(RefSponsor refSponsor) {
        this.refSponsor = refSponsor;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public long getIppEventId() {
        return ippEventId;
    }

    public void setIppEventId(long ippEventId) {
        this.ippEventId = ippEventId;
    }

    public Timestamp getRequestSentDateTime() {
        return requestSentDateTime;
    }

    public void setRequestSentDateTime(Timestamp requestSentDateTime) {
        this.requestSentDateTime = requestSentDateTime;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public String getJsonRequest() {
        return jsonRequest;
    }

    public void setJsonRequest(String jsonRequest) {
        this.jsonRequest = jsonRequest;
    }

    public long getVerifyRequestId() {
        return verifyRequestId;
    }

    public void setVerifyRequestId(long verifyRequestId) {
        this.verifyRequestId = verifyRequestId;
    }

    public VendorAPI getVendorAPI() {
        return vendorAPI;
    }

    public void setVendorAPI(VendorAPI vendorAPI) {
        this.vendorAPI = vendorAPI;
    }

    public String getEfxClientCorrelationId() {
        return efxClientCorrelationId;
    }

    public void setEfxClientCorrelationId(String efxClientCorrelationId) {
        this.efxClientCorrelationId = efxClientCorrelationId;
    }

    public String getReferenceTransactionId() {
        return referenceTransactionId;
    }

    public void setReferenceTransactionId(String referenceTransactionId) {
        this.referenceTransactionId = referenceTransactionId;
    }

    public String getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(String consumerId) {
        this.consumerId = consumerId;
    }

    public RefPrimaryIdType getDocumentType() {
        return documentType;
    }

    public void setDocumentType(RefPrimaryIdType documentType) {
        this.documentType = documentType;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public RefValidationStatusCode getStatusId() {
        return statusId;
    }

    public void setStatusId(RefValidationStatusCode statusId) {
        this.statusId = statusId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
