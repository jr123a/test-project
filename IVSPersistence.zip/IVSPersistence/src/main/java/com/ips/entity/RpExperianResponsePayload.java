package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="rp_experian_response_payload")
@NamedQueries({
    @NamedQuery(name="RpExperianResponsePayload.getAll", query="SELECT r FROM RpExperianResponsePayload r"),
    @NamedQuery(name = "RpExperianResponsePayload.getListByResultIdServiceName", query = "SELECT r FROM RpExperianResponsePayload r WHERE r.expResultId = :resultId AND r.serviceName = :serviceName ORDER BY r.createDate DESC"),
    @NamedQuery(name = "RpExperianResponsePayload.getListByResultIdSequenceIdServiceName", query = "SELECT r FROM RpExperianResponsePayload r WHERE r.expResultId = :resultId AND r.expSequenceId = :sequenceId AND r.serviceName = :serviceName ORDER BY r.createDate DESC")
})    
public class RpExperianResponsePayload implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="rp_experian_response_payloadSeq")
    @SequenceGenerator(name="rp_experian_response_payloadSeq",sequenceName="RP_EXPERIAN_RESPONSE_PAYLOAD_SEQ", allocationSize=1)
    @Column(name="EXP_RESPONSE_ID")
    private long expResponseId;

    @Column(name="EXP_RESULT_ID")
    private long expResultId;
    
    @Column(name="EXP_SEQUENCE_ID")
    private String expSequenceId;
    
    @Column(name="SERVICE_NAME")
    private String serviceName;  
    
    @Column(name="RESP_REFERENCE_ID")
    private String respReferenceId;

    @Column(name="RESP_CORRELATION_ID")
    private String respCorrelationId;

    @Column(name="BOKU_AUTHENTICATION_URL")
    private String bokuAuthenticationUrl;    
    
    @Column(name="ORCHESTRATION_DECISION")
    private String orchestrationDecision;
    
    @Column(name="DECISION_ELEMENTS")
    private String decisionElements;

	@Column(name = "CREATE_DATE")
    private Date createDate;
    
    @Column(name = "UPDATE_DATE")
    private Date updateDate;

	public long getExpResponseId() {
		return expResponseId;
	}

	public void setExpResponseId(long expResponseId) {
		this.expResponseId = expResponseId;
	}

	public long getExpResultId() {
		return expResultId;
	}

	public void setExpResultId(long expResultId) {
		this.expResultId = expResultId;
	}

	public String getExpSequenceId() {
		return expSequenceId;
	}

	public void setExpSequenceId(String expSequenceId) {
		this.expSequenceId = expSequenceId;
	}


	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getRespReferenceId() {
		return respReferenceId;
	}

	public void setRespReferenceId(String respReferenceId) {
		this.respReferenceId = respReferenceId;
	}

	public String getRespCorrelationId() {
		return respCorrelationId;
	}

	public void setRespCorrelationId(String respCorrelationId) {
		this.respCorrelationId = respCorrelationId;
	}

	public String getBokuAuthenticationUrl() {
		return bokuAuthenticationUrl;
	}

	public void setBokuAuthenticationUrl(String bokuAuthenticationUrl) {
		this.bokuAuthenticationUrl = bokuAuthenticationUrl;
	}

	public String getOrchestrationDecision() {
		return orchestrationDecision;
	}

	public void setOrchestrationDecision(String orchestrationDecision) {
		this.orchestrationDecision = orchestrationDecision;
	}

	public String getDecisionElements() {
		return decisionElements;
	}

	public void setDecisionElements(String decisionElements) {
		this.decisionElements = decisionElements;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

}
