package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "VENDOR_TOKENS")
@NamedQuery(name = "VendorToken.findByType", query = "SELECT v FROM VendorToken v WHERE v.tokenType = :type")
public class VendorToken implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="VENDOR_TOKENSSeq")
    @SequenceGenerator(name="VENDOR_TOKENSSeq",sequenceName="VENDOR_TOKENS_SEQ", allocationSize=1)
    @Column(name="TOKEN_ID")
    private long tokenId;
    
    @Column(name="ACCESS_TOKEN")
    private String accessToken;
     
    @ManyToOne
    @JoinColumn(name="VENDOR_ID")
    private RefIdValidationVendor vendor;
    
    @Column(name="TOKEN_TYPE")
    private String tokenType;
    
    @Column(name = "EXPIRATION_TIME")
    private Timestamp expirationTime;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;

    public RefIdValidationVendor getVendor() {
        return vendor;
    }

    public void setVendor(RefIdValidationVendor vendor) {
        this.vendor = vendor;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public Timestamp getExpirationTime() {
        return expirationTime;
    }

    public void setExpirationTime(Timestamp expirationTime) {
        this.expirationTime = expirationTime;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }
    
    public boolean hasExpired() {
    	if (getExpirationTime() == null) {
    		return false;
    	}
    	
        Date currentTime = new Date();
        Date expirationDate = new Date(getExpirationTime().getTime()); 
    
        return expirationDate.before(currentTime);
    }
    
    public void setVendorId(long id) {
        this.vendor = vendor;
    }
}
