package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ref_kba_supplier database table.
 * 
 */
@Entity
@Table(name="ref_kba_supplier")
@NamedQueries({
@NamedQuery(name="RefOtpSupplier.findBySupplierId", query="SELECT r FROM RefOtpSupplier r WHERE r.otpSupplierId = :supplierId"),
@NamedQuery(name="RefOtpSupplier.getActiveSupplierList", query="SELECT r FROM RefOtpSupplier r WHERE r.otpSupplierId IN (3,4,5,6)")
})

/** Renamed entity and properties, and retain database table name unchanged as part of KBA removal. **/
public class RefOtpSupplier implements Serializable {
    private static final long serialVersionUID = 1L;
      
    public static final String EQUIFAX_IDFS_OTP_SUPPLIER_NAME = "Equifax OTP";
    public static final String LEXISNEXIS_RDP_OTP_SUPPLIER_NAME = "Lexis Nexis OTP"; 
    public static final String EQUIFAX_DIT_SMFA_SUPPLIER_NAME = "Equifax DIT SMFA";
    public static final String EXPERIAN_CROSSCORE_SUPPLIER_NAME = "Experian CrossCore"; 
    public static final long EQUIFAX_IDFS_OTP_SUPPLIER_ID = 3L;
    public static final long LEXISNEXIS_RDP_OTP_SUPPLIER_ID = 4L;
    public static final long EQUIFAX_DIT_SMFA_SUPPLIER_ID = 5L;
    public static final long EXPERIAN_CROSSCORE_SUPPLIER_ID = 6L;
    
    @Id
    @Column(name="KBA_SUPPLIER_ID")
    private long otpSupplierId;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="KBA_SUPPLIER_NAME")
    private String otpSupplierName;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    //bi-directional many-to-one association to RpEvent
    @OneToMany(mappedBy="refOtpSupplier")
    private List<RpEvent> rpEvents;

    //bi-directional many-to-one association to RpOtpAttemptConfig
    @OneToMany(mappedBy="refOtpSupplier")
    private List<RpOtpAttemptConfig> rpOtpAttemptConfigList;
    
    //bi-directional many-to-one association to OtpLockoutInfo
    @OneToMany(mappedBy="refOtpSupplier")
    private List<OtpLockoutInfo> otpLockoutInfos;

    //bi-directional many-to-one association to RefOtpVelocity
    @OneToMany(mappedBy="refOtpSupplier")
    private List<RefOtpVelocity> refOtpVelocities;
        
    public long getOtpSupplierId() {
        return this.otpSupplierId;
    }

    public void setOtpSupplierId(long otpSupplierId) {
        this.otpSupplierId = otpSupplierId;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getOtpSupplierName() {
        return this.otpSupplierName;
    }

    public void setOtpSupplierName(String otpSupplierName) {
        this.otpSupplierName = otpSupplierName;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<RpEvent> getRpEvents() {
        return this.rpEvents;
    }

    public void setRpEvents(List<RpEvent> rpEvents) {
        this.rpEvents = rpEvents;
    }

    public RpEvent addRpEvent(RpEvent rpEvent) {
        getRpEvents().add(rpEvent);
        rpEvent.setRefOtpSupplier(this);

        return rpEvent;
    }

    public RpEvent removeRpEvent(RpEvent rpEvent) {
        getRpEvents().remove(rpEvent);
        rpEvent.setRefOtpSupplier(null);

        return rpEvent;
    }

    public RpOtpAttemptConfig addRpOtpAttemptConfig(RpOtpAttemptConfig rpOtpAttemptConfig) {
        getRpOtpAttemptConfigList().add(rpOtpAttemptConfig);
        rpOtpAttemptConfig.setRefOtpSupplier(this);

        return rpOtpAttemptConfig;
    }

    public RpOtpAttemptConfig removeRpOtpAttemptConfig(RpOtpAttemptConfig rpOtpAttemptConfig) {
        getRpOtpAttemptConfigList().remove(rpOtpAttemptConfig);
        rpOtpAttemptConfig.setRefOtpSupplier(null);

        return rpOtpAttemptConfig;
    }

    public List<RpOtpAttemptConfig> getRpOtpAttemptConfigList() {
        return rpOtpAttemptConfigList;
    }

    public void setRpOtpAttemptConfigList(List<RpOtpAttemptConfig> rpOtpAttemptConfigList) {
        this.rpOtpAttemptConfigList = rpOtpAttemptConfigList;
    }

    public List<OtpLockoutInfo> getOtpLockoutInfos() {
        return otpLockoutInfos;
    }

    public void setOtpLockoutInfos(List<OtpLockoutInfo> otpLockoutInfos) {
        this.otpLockoutInfos = otpLockoutInfos;
    }

    public List<RefOtpVelocity> getRefOtpVelocities() {
        return refOtpVelocities;
    }

    public void setRefOtpVelocities(List<RefOtpVelocity> refOtpVelocities) {
        this.refOtpVelocities = refOtpVelocities;
    }
    
    public boolean isEquifaxIDFSPhone() {
        return getOtpSupplierId() == EQUIFAX_IDFS_OTP_SUPPLIER_ID;
    }
    
    public boolean isEquifaxDITPhone() {
        return getOtpSupplierId() == EQUIFAX_DIT_SMFA_SUPPLIER_ID;
    }
    
    public boolean isLexisNexisPhone() {
        return getOtpSupplierId() == LEXISNEXIS_RDP_OTP_SUPPLIER_ID;
    }
    
    public boolean isExperianPhone() {
        return getOtpSupplierId() == EXPERIAN_CROSSCORE_SUPPLIER_ID;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + (int) (otpSupplierId ^ (otpSupplierId >>> 32));
        result = prime * result + ((otpSupplierName == null) ? 0 : otpSupplierName.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefOtpSupplier other = (RefOtpSupplier) obj;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (otpSupplierId != other.otpSupplierId)
            return false;
        if (otpSupplierName == null) {
            if (other.otpSupplierName != null)
                return false;
        } else if (!otpSupplierName.equals(other.otpSupplierName))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }
}
