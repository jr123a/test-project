package com.ips.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "VENDOR_APIS")
@NamedQuery(name = "VendorAPI.findByName", query = "SELECT v FROM VendorAPI v WHERE v.apiName = :name")
public class VendorAPI implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="API_ID")
    private long apiId;
    
    @Column(name="API_NAME")
    private String apiName;
     
    @ManyToOne
    @JoinColumn(name="VENDOR_ID")
    private RefIdValidationVendor vendor;

    public long getApiId() {
        return apiId;
    }

    public void setApiId(long apiId) {
        this.apiId = apiId;
    }

    public String getApiName() {
        return apiName;
    }

    public void setApiName(String apiName) {
        this.apiName = apiName;
    }

    public RefIdValidationVendor getVendor() {
        return vendor;
    }

    public void setVendor(RefIdValidationVendor vendor) {
        this.vendor = vendor;
    }
}
