package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "ref_device_confidence", schema = "IPS_OWN")
@NamedQueries({
    @NamedQuery(name="RefDeviceConfidence.getAll", query="SELECT r FROM RefDeviceConfidence r"),
    @NamedQuery(name="RefDeviceConfidence.getByReputationAssessment", query="Select r FROM RefDeviceConfidence r WHERE r.reputationAssessment = :reputationAssessment")
})    

public class RefDeviceConfidence implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "device_confidence_id")
    private Long deviceConfidenceId;
    
    @Column(name = "reputation_assessment")
    private String reputationAssessment;
    
    @Column(name = "review_status")
    private String reviewStatus;
    
    @Column(name = "description")
    private String description;
    
    @Column(name = "create_date")
    private Date createDate;
    
    @Column(name = "update_date")
    private Date updateDate;

    public Long getDeviceConfidenceId() {
        return deviceConfidenceId;
    }

    public void setDeviceConfidenceId(Long deviceConfidenceId) {
        this.deviceConfidenceId = deviceConfidenceId;
    }

    public String getReputationAssessment() {
        return reputationAssessment;
    }

    public void setReputationAssessment(String reputationAssessment) {
        this.reputationAssessment = reputationAssessment;
    }

    public String getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(String reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

}
