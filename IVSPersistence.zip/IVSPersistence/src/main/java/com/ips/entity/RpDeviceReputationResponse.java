package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rp_device_reputation_response")
@NamedQueries({ @NamedQuery(name = "RpDeviceReputationResponse.getAll", query = "SELECT r FROM RpDeviceReputationResponse r"),
        @NamedQuery(name = "RpDeviceReputationResponse.getByRequestId", query = "SELECT r FROM RpDeviceReputationResponse r WHERE r.requestId = :requestId"),
        @NamedQuery(name = "RpDeviceReputationResponse.getListByPersonId", query = "SELECT r FROM RpDeviceReputationResponse r WHERE r.person.personId = :personId ORDER BY r.createDate DESC")
})


public class RpDeviceReputationResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RPDEVICEREPUTATIONRESPONSESEQ")
    @SequenceGenerator(name="RPDEVICEREPUTATIONRESPONSESEQ",sequenceName="RP_DEVICE_REPUTATION_RESPONSE_SEQ", allocationSize=1)
    @Column(name = "device_reputation_response_id")
    private long deviceReputationResponseId;

    @Column(name = "request_id")
    private String requestId;

    // bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name = "person_id")
    private Person person;

	@Column(name = "request")
    private String request;
    
    @Column(name = "response")
    private String response;
    
    @Column(name = "create_date")
    private Date createDate;

    @Column(name = "update_date")
    private Date updateDate;

    public long getDeviceReputationResponseId() {
        return deviceReputationResponseId;
    }

    public void setDeviceReputationResponseId(long deviceReputationResponseId) {
        this.deviceReputationResponseId = deviceReputationResponseId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

}
