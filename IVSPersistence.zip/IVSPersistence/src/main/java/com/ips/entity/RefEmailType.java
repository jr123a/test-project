package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "ref_email_type")
@NamedQueries({
    @NamedQuery(name="RefEmailType.findAll", query="SELECT e FROM RefEmailType e"),
    @NamedQuery(name="RefEmailType.findByPK", query="SELECT e FROM RefEmailType e WHERE e.id = :id")
})
public class RefEmailType implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final long OPTIN_INITIAL = 1;
    public static final long OPTIN_REMINDER = 2;
    public static final long CONFIRMATION_PASSED = 3;
    public static final long CONFIRMATION_FAILED = 4;
    public static final long IAL2_CONFIRMATION_EMAIL = 5;
    public static final long IAL2_CONFIRMATION_PHYSICAL_LETTER = 6;    
    
    @Id
    @Column(name = "id_type")
    private Long id;
    
    @Column(name = "id_type_description")
    private String idTypeDescription;
    
    @Column(name = "create_date")
    private Date createDate;
    
    @Column(name = "update_date")
    private Date updateDate;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getIdTypeDescription() {
        return idTypeDescription;
    }
    public void setIdTypeDescription(String idTypeDescription) {
        this.idTypeDescription = idTypeDescription;
    }

    public Date getCreateDate() {
        return createDate;
    }
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public String toString() {
        return "RefEmailType{" +
                "id=" + id +
                ", idTypeDescription='" + idTypeDescription + '\'' +
                ", createDate=" + createDate +
                ", updateDate=" + updateDate +
                '}';
    }
}
