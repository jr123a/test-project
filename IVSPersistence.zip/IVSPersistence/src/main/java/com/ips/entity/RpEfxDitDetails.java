package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="rp_efx_dit_details")
@NamedQueries({
    @NamedQuery(name="RpEfxDitDetails.getAll", query="SELECT d FROM RpEfxDitDetails d"),
    @NamedQuery(name = "RpEfxDitDetails.getListByPersonId", query = "SELECT d FROM RpEfxDitDetails d WHERE d.person.personId = :personId ORDER BY d.createDate DESC")
})    
public class RpEfxDitDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RPEFXDITDETAILSSEQ")
    @SequenceGenerator(name="RPEFXDITDETAILSSEQ",sequenceName="RP_EFX_DIT_DETAILS_SEQ", allocationSize=1)
    @Column(name="IDENTITY_DETAIL_ID")
    private long identityDetailId;
    
    // bi-directional one-to-one association to RpEvent
    @OneToOne
    @JoinColumn(name = "EVENT_ID")
    private RpEvent rpEvent;
    
    // bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name = "PERSON_ID")
    private Person person;

    @Column(name="TRANSACTION_ID")
    private String transactionId;
    
    @Column(name="DECISION")
    private String decision;
    
    @Column(name="IDENTITY_TRUST")
    private String identityTrust;
    
    @Column(name="IDENTITY_VERIFICATION_REASON")
    private String identityVerificationReason;
    
    @Column(name="IDENTITY_RESOLUTION_REASON")
    private String identityResolutionReason;
    
    @Column(name="IDENTITY_RISK")
    private String identityRisk;
    
    @Column(name="IDENTITY_RISK_REASON")
    private String identityRiskReason;
    
    @Column(name="ADDRESS_TRUST")
    private String addressTrust;
    
    @Column(name="ADDRESS_VERIFICATION_REASON")
    private String addressVerificationReason;
    
    @Column(name="ADDRESS_AFFILIATION_REASON")
    private String addressAfffiliationReason;
    
    @Column(name="ADDRESS_INSIGHTS_REASON")
    private String addressInsightsReason;
    
    @Column(name="PHONE_TRUST")
    private String phoneTrust;
    
    @Column(name="PHONE_VERIFICATION_REASON")
    private String phoneVerificationReason;
    
    @Column(name="PHONE_AFFILIATION_REASON")
    private String phoneAfffiliationReason;
    
    @Column(name="PHONE_INSIGHTS_REASON")
    private String phoneInsightsReason;
    
    @Column(name = "CREATE_DATE")
    private Date createDate;
    
    @Column(name = "UPDATE_DATE")
    private Date updateDate;

	public long getIdentityDetailId() {
		return identityDetailId;
	}

	public void setIdentityDetailId(long identityDetailId) {
		this.identityDetailId = identityDetailId;
	}

	public RpEvent getRpEvent() {
		return rpEvent;
	}

	public void setRpEvent(RpEvent rpEvent) {
		this.rpEvent = rpEvent;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public String getIdentityTrust() {
		return identityTrust;
	}

	public void setIdentityTrust(String identityTrust) {
		this.identityTrust = identityTrust;
	}

	public String getIdentityVerificationReason() {
		return identityVerificationReason;
	}

	public void setIdentityVerificationReason(String identityVerificationReason) {
		this.identityVerificationReason = identityVerificationReason;
	}

	public String getIdentityResolutionReason() {
		return identityResolutionReason;
	}

	public void setIdentityResolutionReason(String identityResolutionReason) {
		this.identityResolutionReason = identityResolutionReason;
	}

	public String getIdentityRisk() {
		return identityRisk;
	}

	public void setIdentityRisk(String identityRisk) {
		this.identityRisk = identityRisk;
	}

	public String getIdentityRiskReason() {
		return identityRiskReason;
	}

	public void setIdentityRiskReason(String identityRiskReason) {
		this.identityRiskReason = identityRiskReason;
	}

	public String getAddressTrust() {
		return addressTrust;
	}

	public void setAddressTrust(String addressTrust) {
		this.addressTrust = addressTrust;
	}

	public String getAddressVerificationReason() {
		return addressVerificationReason;
	}

	public void setAddressVerificationReason(String addressVerificationReason) {
		this.addressVerificationReason = addressVerificationReason;
	}

	public String getAddressAfffiliationReason() {
		return addressAfffiliationReason;
	}

	public void setAddressAfffiliationReason(String addressAfffiliationReason) {
		this.addressAfffiliationReason = addressAfffiliationReason;
	}

	public String getAddressInsightsReason() {
		return addressInsightsReason;
	}

	public void setAddressInsightsReason(String addressInsightsReason) {
		this.addressInsightsReason = addressInsightsReason;
	}

	public String getPhoneTrust() {
		return phoneTrust;
	}

	public void setPhoneTrust(String phoneTrust) {
		this.phoneTrust = phoneTrust;
	}

	public String getPhoneVerificationReason() {
		return phoneVerificationReason;
	}

	public void setPhoneVerificationReason(String phoneVerificationReason) {
		this.phoneVerificationReason = phoneVerificationReason;
	}

	public String getPhoneAfffiliationReason() {
		return phoneAfffiliationReason;
	}

	public void setPhoneAfffiliationReason(String phoneAfffiliationReason) {
		this.phoneAfffiliationReason = phoneAfffiliationReason;
	}

	public String getPhoneInsightsReason() {
		return phoneInsightsReason;
	}

	public void setPhoneInsightsReason(String phoneInsightsReason) {
		this.phoneInsightsReason = phoneInsightsReason;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	@Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (identityDetailId ^ (identityDetailId >>> 32));
        result = prime * result + (int) (rpEvent.getEventId() ^ (rpEvent.getEventId() >>> 32));
        result = prime * result + (int) (person.getPersonId() ^ (person.getPersonId() >>> 32));
        result = prime * result + ((transactionId == null) ? 0 : transactionId.hashCode());
        result = prime * result + ((decision == null) ? 0 : decision.hashCode());
        result = prime * result + ((identityTrust == null) ? 0 : identityTrust.hashCode());
        result = prime * result + ((identityVerificationReason == null) ? 0 : identityVerificationReason.hashCode());
        result = prime * result + ((identityResolutionReason == null) ? 0 : identityResolutionReason.hashCode());
        result = prime * result + ((identityRisk == null) ? 0 : identityRisk.hashCode());
        result = prime * result + ((identityRiskReason == null) ? 0 : identityRiskReason.hashCode());
        result = prime * result + ((addressTrust == null) ? 0 : addressTrust.hashCode());
        result = prime * result + ((addressVerificationReason == null) ? 0 : addressVerificationReason.hashCode());
        result = prime * result + ((addressAfffiliationReason == null) ? 0 : addressAfffiliationReason.hashCode());
        result = prime * result + ((addressInsightsReason == null) ? 0 : addressInsightsReason.hashCode());
        result = prime * result + ((phoneTrust == null) ? 0 : phoneTrust.hashCode());
        result = prime * result + ((phoneVerificationReason == null) ? 0 : phoneVerificationReason.hashCode());
        result = prime * result + ((phoneAfffiliationReason == null) ? 0 : phoneAfffiliationReason.hashCode());
        result = prime * result + ((phoneInsightsReason == null) ? 0 : phoneInsightsReason.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RpEfxDitDetails other = (RpEfxDitDetails) obj;
        if (identityDetailId != other.identityDetailId)
            return false;
        if (rpEvent.getEventId() != other.rpEvent.getEventId())
            return false;
        if (person.getPersonId() != other.person.getPersonId())
            return false;
        if (transactionId == null) {
            if (other.transactionId != null)
                return false;
        } else if (!transactionId.equals(other.transactionId))
            return false;
        if (transactionId == null) {
            if (other.transactionId != null)
                return false;
        } else if (!transactionId.equals(other.transactionId))
            return false;
        if (decision == null) {
            if (other.decision != null)
                return false;
        } else if (!decision.equals(other.decision))
            return false;
        if (identityTrust == null) {
            if (other.identityTrust != null)
                return false;
        } else if (!identityTrust.equals(other.identityTrust))
            return false;
        if (identityVerificationReason == null) {
            if (other.identityVerificationReason != null)
                return false;
        } else if (!identityVerificationReason.equals(other.identityVerificationReason))
            return false;
        if (identityResolutionReason == null) {
            if (other.identityResolutionReason != null)
                return false;
        } else if (!identityResolutionReason.equals(other.identityResolutionReason))
            return false;
        if (identityRisk == null) {
            if (other.identityRisk != null)
                return false;
        } else if (!identityRisk.equals(other.identityRisk))
            return false;
        if (identityRiskReason == null) {
            if (other.identityRiskReason != null)
                return false;
        } else if (!identityRiskReason.equals(other.identityRiskReason))
            return false;
        if (addressTrust == null) {
            if (other.addressTrust != null)
                return false;
        } else if (!addressTrust.equals(other.addressTrust))
            return false;
        if (addressVerificationReason == null) {
            if (other.addressVerificationReason != null)
                return false;
        } else if (!addressVerificationReason.equals(other.addressVerificationReason))
            return false;
        if (addressAfffiliationReason == null) {
            if (other.addressAfffiliationReason != null)
                return false;
        } else if (!addressAfffiliationReason.equals(other.addressAfffiliationReason))
            return false;
        if (addressInsightsReason == null) {
            if (other.addressInsightsReason != null)
                return false;
        } else if (!addressInsightsReason.equals(other.addressInsightsReason))
            return false;
        if (phoneTrust == null) {
            if (other.phoneTrust != null)
                return false;
        } else if (!phoneTrust.equals(other.phoneTrust))
            return false;
        if (phoneVerificationReason == null) {
            if (other.phoneVerificationReason != null)
                return false;
        } else if (!phoneVerificationReason.equals(other.phoneVerificationReason))
            return false;
        if (phoneAfffiliationReason == null) {
            if (other.phoneAfffiliationReason != null)
                return false;
        } else if (!phoneAfffiliationReason.equals(other.phoneAfffiliationReason))
            return false;
        if (phoneInsightsReason == null) {
            if (other.phoneInsightsReason != null)
                return false;
        } else if (!phoneInsightsReason.equals(other.phoneInsightsReason))
            return false;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }
}
