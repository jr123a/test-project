package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;

/**
 * The persistent class for the sponsor_report_history database table.
 * 
 */
@Entity
@Table(name="sponsor_report_history")
@NamedQuery(name="SponsorReportHistory.findSponsorReportHistoryBySponsor", query="SELECT r FROM SponsorReportHistory r WHERE r.refSponsor.sponsorId = :sponsorId")

public class SponsorReportHistory implements Serializable {
    private static final long serialVersionUID = 1L;
     
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="sponsor_report_historySeq")
    @SequenceGenerator(name="sponsor_report_historySeq",sequenceName="SPONSOR_REPORT_HISTORY_SEQ", allocationSize=1)
    @Column(name="history_id")
    private long historyId;
    
    //bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name="SPONSOR_ID")
    private RefSponsor refSponsor;

    //bi-directional many-to-one association to RefReports
    @ManyToOne
    @JoinColumn(name="REPORT_ID")
    private RefReports refReport;
        
    @Column(name="recipient_email_addresses")
    private String recipientEmailAddresses;
    
    @Column(name="REPORT_START_DATE")
    private Timestamp reportStartDate;
    
    @Column(name="REPORT_END_DATE")
    private Timestamp reportEndDate;

    @Column(name="DATE_SENT")
    private Timestamp dateSent;

    public long getHistoryId() {
        return historyId;
    }

    public void setHistoryId(long historyId) {
        this.historyId = historyId;
    }

    public RefSponsor getRefSponsor() {
        return refSponsor;
    }

    public void setRefSponsor(RefSponsor refSponsor) {
        this.refSponsor = refSponsor;
    }

    public RefReports getRefReport() {
        return refReport;
    }

    public void setRefReport(RefReports refReport) {
        this.refReport = refReport;
    }

    public String getRecipientEmailAddresses() {
        return recipientEmailAddresses;
    }

    public void setRecipientEmailAddresses(String recipientEmailAddresses) {
        this.recipientEmailAddresses = recipientEmailAddresses;
    }

    public Timestamp getReportStartDate() {
        return reportStartDate;
    }

    public void setReportStartDate(Timestamp reportStartDate) {
        this.reportStartDate = reportStartDate;
    }

    public Timestamp getReportEndDate() {
        return reportEndDate;
    }

    public void setReportEndDate(Timestamp reportEndDate) {
        this.reportEndDate = reportEndDate;
    }

    public Timestamp getDateSent() {
        return dateSent;
    }

    public void setDateSent(Timestamp dateSent) {
        this.dateSent = dateSent;
    }
}
