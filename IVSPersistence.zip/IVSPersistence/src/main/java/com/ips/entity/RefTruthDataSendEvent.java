package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "ref_truth_data_send_event", schema = "IPS_OWN")
@NamedQueries({
    @NamedQuery(name="RefTruthDataSendEvent.getAll", query="SELECT r FROM RefTruthDataSendEvent r"),
    @NamedQuery(name="RefTruthDataSendEvent.getByEventId", query="Select r FROM RefTruthDataSendEvent r WHERE r.eventId = :eventId")
})    

public class RefTruthDataSendEvent implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final long REMOTE_PROOFING_DATA_RETURN = 1;
    public static final long IN_PERSON_PROOFING_DATA_RETURN = 2;
    public static final long FRAUD_DATA_RETURN = 3;
    public static final long UNSUBSCRIBE_DATA_RETURN = 4;
    public static final long BLACKLIST_FRAUD_DATA_RETURN = 5;
    
    @Id
    @Column(name = "event_id")
    private Long eventId;
    
    @Column(name = "event_type")
    private String eventType;
    
    @Column(name = "create_date")
    private Date createDate;
    
    @Column(name = "update_date")
    private Date updateDate;

    public Long getEventId() {
        return eventId;
    }

    public void setEventId(Long eventId) {
        this.eventId = eventId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

}
