package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "sponsor_reports")
@NamedQuery(name = "SponsorReports.getAll", query = "SELECT r FROM SponsorReports r")
@NamedQuery(name = "SponsorReports.getBySponsorAndReportIds", query = "SELECT r FROM SponsorReports r  WHERE r.sponsor.sponsorId = :sponsorId "
    + "AND  r.reports.reportId = :reportId" )
@NamedQuery(name="SponsorReports.findSponsorReportsBySponsor", query="SELECT r FROM SponsorReports r WHERE r.sponsor.sponsorId = :sponsorId")

public class SponsorReports implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="sponsor_reportsSeq")
    @SequenceGenerator(name="sponsor_reportsSeq",sequenceName="SPONSOR_REPORTS_SEQ", allocationSize=1)
    @Column(name = "report_email_id")
    private long reportEmailId;

    // bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name = "sponsor_id")
    private RefSponsor sponsor;

    // bi-directional many-to-one association to RefReports
    @ManyToOne
    @JoinColumn(name = "report_id")
    private RefReports reports;
    
    @Column(name = "recipient_email_addresses")
    private String recipientEmailAddresses;

    @Column(name = "create_date")
    private Date createDate;

    @Column(name = "update_date")
    private Date updateDate;

    public long getReportEmailId() {
        return reportEmailId;
    }

    public void setReportEmailId(long reportEmailId) {
        this.reportEmailId = reportEmailId;
    }

    public RefSponsor getSponsor() {
        return sponsor;
    }

    public void setSponsor(RefSponsor sponsor) {
        this.sponsor = sponsor;
    }

    public RefReports getReports() {
        return reports;
    }

    public void setReports(RefReports reports) {
        this.reports = reports;
    }

    public String getRecipientEmailAddresses() {
        return recipientEmailAddresses;
    }

    public void setRecipientEmailAddresses(String recipientEmailAddresses) {
        this.recipientEmailAddresses = recipientEmailAddresses;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

}
