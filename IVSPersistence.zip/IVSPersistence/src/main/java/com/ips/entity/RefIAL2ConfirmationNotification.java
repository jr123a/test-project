package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "ref_ial2_notification_types")
@NamedQueries({
    @NamedQuery(name = "RefIAL2ConfirmationNotification.findAll", query = "SELECT r FROM RefIAL2ConfirmationNotification r"),
    @NamedQuery(name = "RefIAL2ConfirmationNotification.findById", query = "SELECT r FROM RefIAL2ConfirmationNotification r WHERE r.id = :id")
})
public class RefIAL2ConfirmationNotification implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "notification_id")
    private long id;
    
    @Column(name = "notification_type")
    private String notificationType;
    
    @Column(name = "create_date")
    private Date createDate;
    
    @Column(name = "update_date")
    private Date updateDate;
    
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    
    public String getNotificationType() {
        return notificationType;
    }
    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }
    
    public Date getCreateDate() {
        return createDate;
    }
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
    
    public Date getUpdateDate() {
        return updateDate;
    }
    public void setUpdatedate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
