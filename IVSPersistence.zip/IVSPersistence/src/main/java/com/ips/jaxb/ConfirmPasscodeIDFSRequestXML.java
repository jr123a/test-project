package com.ips.jaxb;

import com.equifax.eid.soap.schema.usidentityfraudservice.v2.ObjectFactory;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.OneTimePasscodeInput;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.SubsequentRequest;
import com.ips.common.common.CustomLogger;
import com.ips.persistence.common.PersonVo;

public class ConfirmPasscodeIDFSRequestXML {

    public SubsequentRequest createConfirmPasscodeXMLSubsequentRequest(PersonVo personVo, String transactionKey) {
        CustomLogger.enter(this.getClass());
        
        ObjectFactory factory = new ObjectFactory();        
        
        SubsequentRequest request = factory.createSubsequentRequest();
        request.setTransactionKey(transactionKey);
        String passcode = personVo.getPasscode();
        
        OneTimePasscodeInput otpInput = factory.createOneTimePasscodeInput();
        otpInput.setAction("submit");
        otpInput.setPasscode(passcode);
        
        request.setOneTimePasscodeInput(otpInput);
 
        CustomLogger.debug(this.getClass(), "TransactionKey=" + request.getTransactionKey() + ", Action=" + request.getOneTimePasscodeInput().getAction());
        return request;
    }

}
