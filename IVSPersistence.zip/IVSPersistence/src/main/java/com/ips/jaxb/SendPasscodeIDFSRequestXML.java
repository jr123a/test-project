package com.ips.jaxb;

import com.ips.exception.IPSException;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.InitialRequest;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.StringBuilderPlus;

/**
 * @author X5SFN0
 *
 */
public class SendPasscodeIDFSRequestXML extends InitialIDFSRequestXML {

    public InitialRequest createSendPasscodeXMLInitialRequest(PersonVo personVo) throws IPSException {
        CustomLogger.enter(this.getClass());
        
        InitialRequest request = createXMLInitialRequest(personVo, IPSConstants.EQUIFAX_PASSCODE_ORCHESTRATION_CODE);
        
        //Changed LOG level from INFO to DEBUG for these PII logs.
        if (CustomLogger.isDebugEnabled()) {
            CustomLogger.debug(this.getClass(), "Request=" + request.toString());
            
            StringBuilderPlus sb = new StringBuilderPlus();
            sb.appendLine("Name=" + request.getIdentity().getName().getFirstName() + " " + request.getIdentity().getName().getMiddleInitial() + " " + request.getIdentity().getName().getLastName() );
            sb.appendLine("Address type=" + request.getIdentity().getAddress().get(0).getAddressType());
            sb.appendLine("Time at address in months=" + request.getIdentity().getAddress().get(0).getTimeAtAddressInMonths());
            sb.appendLine("Address line=" + request.getIdentity().getAddress().get(0).getHybridAddress().getAddressLine());
            sb.appendLine("City=" + request.getIdentity().getAddress().get(0).getHybridAddress().getCity());
            sb.appendLine("State=" + request.getIdentity().getAddress().get(0).getHybridAddress().getState());
            sb.appendLine("Zip=" + request.getIdentity().getAddress().get(0).getHybridAddress().getZIP());
            sb.appendLine("Zip4=" + request.getIdentity().getAddress().get(0).getHybridAddress().getZIP4());
            sb.appendLine("Country code=" + request.getIdentity().getAddress().get(0).getHybridAddress().getCountryCode());
            sb.appendLine("AreaCode=" + request.getIdentity().getPhoneNumber().get(0).getAreaCode() );
            sb.appendLine("Exchange=" + request.getIdentity().getPhoneNumber().get(0).getExchange() );
            sb.appendLine("Number=" + request.getIdentity().getPhoneNumber().get(0).getNumber());
            sb.appendLine("PhoneNumber=" + request.getIdentity().getPhoneNumber().get(0).getPhoneNumber());
            sb.appendLine("PhoneType=" + request.getIdentity().getPhoneNumber().get(0).getPhoneType());
            sb.appendLine("AuxiliaryData=" + request.getAuxiliaryData());
            sb.appendLine("ProcessingOptions=" + request.getProcessingOptions());    
            CustomLogger.debug(this.getClass(), sb.toString());
        }
            
        return request;
    }

    @Override
    public String toString() {
        return "SendPasscodeIDFSRequestXML [toString()=" + super.toString() + "]";
    }
}
