package com.ips.jaxb;

public class RpCancelledUserAssertion {
    
    
}
