package com.ips.jaxb;

import java.util.ArrayList;

import com.equifax.eid.soap.schema.identityfraudservice.v2.AuxiliaryData;
import com.equifax.eid.soap.schema.identityfraudservice.v2.DateOfBirth;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.Address;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.HybridAddress;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.Identity;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.InitialRequest;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.Name;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.ObjectFactory;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.PhoneNumber;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.StringBuilderPlus;
import com.ips.exception.IPSException;
import com.ips.persistence.common.PersonVo;

public class InitialIDFSRequestXML {
        
    public InitialRequest createXMLInitialRequest(PersonVo personVo, String orchestrationProperty) throws IPSException {        
        CustomLogger.enter(this.getClass());
        
        ObjectFactory factory = new ObjectFactory();        
        
        InitialRequest request = factory.createInitialRequest();
        boolean isVerifyPhoneCallingApp = "VerifyPhone".equalsIgnoreCase(personVo.getCallingMethod());
        
        request.setOrchestrationCode(orchestrationProperty);
        CustomLogger.info(this.getClass(), "OrchestrationCode="+ orchestrationProperty);
        Identity identity = factory.createIdentity();
        
        // Have to populate the request with the customer's name, address, etc
        Name name = factory.createName();
        name.setFirstName(personVo.getFirstName());
        if (personVo.getMiddleName() != null 
                && personVo.getMiddleName().length() >= 1) {
            name.setMiddleInitial(personVo.getMiddleName().substring(0, 1));
            name.setMiddleName(personVo.getMiddleName());
        }
        else {
            name.setMiddleInitial("");
            name.setMiddleName("");
        }
        name.setLastName(personVo.getLastName());
        identity.setName(name);
            
        Address address = factory.createAddress();
        address.setAddressType("current");
        address.setTimeAtAddressInMonths(24);

        HybridAddress hybrid = factory.createHybridAddress();        
        hybrid.addAddressLine(personVo.getAddressLine1());
        
        hybrid.setCity(personVo.getCity());
        hybrid.setState(personVo.getStateProvince());
        
        if (personVo.getEquifaxPostalCode() != null) {
            hybrid.setZIP(personVo.getEquifaxPostalCode());
            hybrid.setZIP4("");
        } 
        else if (personVo.getPostalCode() != null) {
            String[] tokens = personVo.getPostalCode().split("-");
            if (tokens.length > 0) {
                hybrid.setZIP(tokens[0]);
            }
            if (tokens.length > 1) {
                hybrid.setZIP4(tokens[1]);
            }
        }
        else {
            hybrid.setZIP("");
            hybrid.setZIP4("");
        }
        hybrid.setCountryCode("1");
        
        address.setHybridAddress(hybrid);
        identity.addAddress(address);
        
        
        if (personVo.getDob() != null && isVerifyPhoneCallingApp) {
            String birthDate = DateTimeUtil.getDateString(personVo.getDob(), "MMddyyyy");
            DateOfBirth dob = new DateOfBirth();
            dob.setDay(Integer.parseInt(birthDate.substring(2, 4)));
            dob.setMonth(Integer.parseInt(birthDate.substring(0, 2)));
            dob.setYear(Integer.parseInt(birthDate.substring(4)));
            identity.setDateOfBirth(dob);
        }

        //PhoneNumber Attribute Block
        PhoneNumber phone = factory.createPhoneNumber();
        phone.setPhoneType("Mobile");
        String phoneNumber = personVo.getMobileNumber();
        
        if (phoneNumber== null) {
            phoneNumber = personVo.getPhoneNumber();
        }

        if (phoneNumber == null) {
            throw new IPSException("Phone number is null or empty.");
        }
        
        phone.setPhoneNumber(phoneNumber);
        if (phoneNumber != null && phoneNumber.length() >= 3) {
            phone.setAreaCode(phoneNumber.substring(0, 3));
        }
        if (phoneNumber != null && phoneNumber.length() >= 6) {
            phone.setExchange(phoneNumber.substring(3, 6));
        }
        if (phoneNumber != null && phoneNumber.length() >= 10) {
            phone.setNumber(phoneNumber.substring(6, 10));
        }
        
        ArrayList<PhoneNumber> phoneList = new ArrayList<>();
        phoneList.add(phone);
        
        identity.setPhoneNumber(phoneList);

        request.setIdentity(identity);
        
        AuxiliaryData aux = new AuxiliaryData();
        aux.setCustomerReferenceIdentifier(personVo.getSponsorUserId());
        request.setAuxiliaryData(aux);
        
        InitialRequest.ProcessingOptions processingOptions = new InitialRequest.ProcessingOptions();
        processingOptions.setLanguage("English");
        request.setProcessingOptions(processingOptions);
        
        //Changed LOG level from INFO to DEBUG for these PII logs.
        if (CustomLogger.isDebugEnabled()) {
            CustomLogger.debug(this.getClass(), "Request=" + request.toString());
            
            StringBuilderPlus sb = new StringBuilderPlus();
            sb.appendLine("Name=" + request.getIdentity().getName().getFirstName() + " " + request.getIdentity().getName().getMiddleInitial() + " " + request.getIdentity().getName().getLastName() );
            sb.appendLine("Address type=" + request.getIdentity().getAddress().get(0).getAddressType());
            sb.appendLine("Time at address in months=" + request.getIdentity().getAddress().get(0).getTimeAtAddressInMonths());
            sb.appendLine("Address line=" + request.getIdentity().getAddress().get(0).getHybridAddress().getAddressLine().get(0));
            sb.appendLine("City=" + request.getIdentity().getAddress().get(0).getHybridAddress().getCity());
            sb.appendLine("State=" + request.getIdentity().getAddress().get(0).getHybridAddress().getState());
            sb.appendLine("Zip=" + request.getIdentity().getAddress().get(0).getHybridAddress().getZIP());
            sb.appendLine("Zip4=" + request.getIdentity().getAddress().get(0).getHybridAddress().getZIP4());
            sb.appendLine("Country code=" + request.getIdentity().getAddress().get(0).getHybridAddress().getCountryCode());
            sb.appendLine("SSN=" + request.getIdentity().getSSN());
            sb.appendLine("CustomerReferenceIdentifier=" + request.getAuxiliaryData().getCustomerReferenceIdentifier());
            sb.appendLine("OrchestrationCode=" + request.getOrchestrationCode());
            CustomLogger.debug(this.getClass(), sb.toString());
        }
        
        DateOfBirth dob = request.getIdentity().getDateOfBirth();
        if (dob != null) {
            CustomLogger.debug(this.getClass(), "DateOfBirth=" 
                     + (dob.getMonth() < 10 ? "0" + dob.getMonth() : dob.getMonth()) 
                     + (dob.getDay() < 10 ? "0" + dob.getDay() : dob.getDay())
                     + dob.getYear());
        }

        if (CustomLogger.isDebugEnabled()) {
            StringBuilderPlus sb2 = new StringBuilderPlus();
            sb2.appendLine("AreaCode=" + request.getIdentity().getPhoneNumber().get(0).getAreaCode() );
            sb2.appendLine("Exchange=" + request.getIdentity().getPhoneNumber().get(0).getExchange() );
            sb2.appendLine("Number=" + request.getIdentity().getPhoneNumber().get(0).getNumber());
            sb2.appendLine("PhoneNumber=" + request.getIdentity().getPhoneNumber().get(0).getPhoneNumber());
            sb2.appendLine("PhoneType=" + request.getIdentity().getPhoneNumber().get(0).getPhoneType());
            CustomLogger.debug(this.getClass(), sb2.toString());
        }
        
        return request;
    }
    
    @Override
    public String toString() {
        return "InitialIDFSRequestXML [toString()=" + super.toString() + "]";
    }
}
