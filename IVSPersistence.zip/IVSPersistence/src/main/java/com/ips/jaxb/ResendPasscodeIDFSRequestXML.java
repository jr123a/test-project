package com.ips.jaxb;


import com.equifax.eid.soap.schema.usidentityfraudservice.v2.ObjectFactory;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.OneTimePasscodeInput;
import com.equifax.eid.soap.schema.usidentityfraudservice.v2.SubsequentRequest;
import com.ips.common.common.CustomLogger;

public class ResendPasscodeIDFSRequestXML {

    public SubsequentRequest createResendPasscodeXMLSubsequentRequest(String transactionKey) {
        CustomLogger.enter(this.getClass());        
        ObjectFactory factory = new ObjectFactory();        
        
        SubsequentRequest request = factory.createSubsequentRequest();
        request.setTransactionKey(transactionKey);
        
        OneTimePasscodeInput otpInput = factory.createOneTimePasscodeInput();
        otpInput.setAction("renew");
        
        request.setOneTimePasscodeInput(otpInput);
 
        CustomLogger.debug(this.getClass(), "TransactionKey=" + request.getTransactionKey());
        CustomLogger.debug(this.getClass(), "Action=" + request.getOneTimePasscodeInput().getAction());
        return request;
    }


}
