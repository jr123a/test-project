package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class FraudSolutionsProductsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseIDServerModel preciseIDServer;	           
	private CustomerManagementModel customerManagement;		   

	public CustomerManagementModel getCustomerManagement() {
		return customerManagement;
	}

	public void setCustomerManagement(CustomerManagementModel customerManagement) {
		this.customerManagement = customerManagement;
	}

	public PreciseIDServerModel getPreciseIDServer() {
		return preciseIDServer;
	}
	
	public void setPreciseIDServer(PreciseIDServerModel preciseIDServer) {
		this.preciseIDServer = preciseIDServer;
	}
			
}
