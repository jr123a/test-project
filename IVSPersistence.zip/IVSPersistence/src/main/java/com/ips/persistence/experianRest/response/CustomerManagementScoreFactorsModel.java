package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class CustomerManagementScoreFactorsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ValueCodeModel scoreFactor1;	           //Max Length:8
	private ValueCodeModel scoreFactor2;	           //Max Length:8
	private ValueCodeModel scoreFactor3;	           //Max Length:8
	private ValueCodeModel scoreFactor4;	           //Max Length:8
	
	public ValueCodeModel getScoreFactor1() {
		return scoreFactor1;
	}
	
	public void setScoreFactor1(ValueCodeModel scoreFactor1) {
		this.scoreFactor1 = scoreFactor1;
	}

	public ValueCodeModel getScoreFactor2() {
		return scoreFactor2;
	}

	public void setScoreFactor2(ValueCodeModel scoreFactor2) {
		this.scoreFactor2 = scoreFactor2;
	}

	public ValueCodeModel getScoreFactor3() {
		return scoreFactor3;
	}

	public void setScoreFactor3(ValueCodeModel scoreFactor3) {
		this.scoreFactor3 = scoreFactor3;
	}

	public ValueCodeModel getScoreFactor4() {
		return scoreFactor4;
	}

	public void setScoreFactor4(ValueCodeModel scoreFactor4) {
		this.scoreFactor4 = scoreFactor4;
	}
		
}
