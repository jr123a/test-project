package com.ips.persistence.common;

import java.util.Date;

public class TotalTransactionReportVo {

    private String env;
    private Date startDate;
    private Date endDate;
    
    private Long dayPassed;
    private Long dayFailed;
    private Long dayOptIn;
    private Long dayCallFailures;
    private Long dayRetrySucceeded;
    private Long dayFailedEmails;
    
    private Long monthPassed;
    private Long monthFailed;
    private Long monthOptIn;
    private Long monthCallFailures;
    private Long monthRetrySucceeded;
    private Long monthFailedEmails;
    
    public TotalTransactionReportVo(Long dayPassed, Long dayFailed, Long monthPassed, Long monthFailed) {
        this.dayPassed = dayPassed;
        this.dayFailed = dayFailed;
        this.monthPassed = monthPassed;
        this.monthFailed = monthFailed;
    }
    
    public String getEnv() {
        return env;
    }
    public void setEnv(String env) {
        this.env = env;
    }
    
    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Long getDayTotalTransactions() {
        return getDayPassed() + getDayFailed();
    }
    
    public Long getDayPassed() {
        return dayPassed;
    }
    
    public Long getDayFailed() {
        return dayFailed;
    }
    
    public Long getDayPassRate() {
        return (long) Math.round((float) getDayPassed() / getDayTotalTransactions() * 100);
    }
    
    public Long getDayFailRate() {
        return (long) Math.round((float) getDayFailed() / getDayTotalTransactions() * 100);
    }
    
    public Long getMonthTotalTransactions() {
        return getMonthPassed() + getMonthFailed();
    }
    
    public Long getMonthPassed() {
        return monthPassed;
    }
    
    public Long getMonthFailed() {
        return monthFailed;
    }
    
    public Long getMonthPassRate() {
        return (long) Math.round((float) getMonthPassed() / getMonthTotalTransactions() * 100);
    }
    
    public Long getMonthFailRate() {
        return (long) Math.round((float) getMonthFailed() / getMonthTotalTransactions() * 100);
    }

    public Long getDayOptIn() {
        return dayOptIn;
    }

    public void setDayOptIn(Long dayOptIn) {
        this.dayOptIn = dayOptIn;
    }

    public Long getMonthOptIn() {
        return monthOptIn;
    }

    public void setMonthOptIn(Long monthOptIn) {
        this.monthOptIn = monthOptIn;
    }

    public Long getDayCallFailures() {
        return dayCallFailures;
    }

    public void setDayCallFailures(Long dayCallFailures) {
        this.dayCallFailures = dayCallFailures;
    }

    public Long getDayRetrySucceeded() {
        return dayRetrySucceeded;
    }

    public void setDayRetrySucceeded(Long dayRetrySucceeded) {
        this.dayRetrySucceeded = dayRetrySucceeded;
    }

    public Long getDayFailedEmails() {
        return dayFailedEmails;
    }

    public void setDayFailedEmails(Long dayFailedEmails) {
        this.dayFailedEmails = dayFailedEmails;
    }

    public Long getMonthCallFailures() {
        return monthCallFailures;
    }

    public void setMonthCallFailures(Long monthCallFailures) {
        this.monthCallFailures = monthCallFailures;
    }

    public Long getMonthRetrySucceeded() {
        return monthRetrySucceeded;
    }

    public void setMonthRetrySucceeded(Long monthRetrySucceeded) {
        this.monthRetrySucceeded = monthRetrySucceeded;
    }

    public Long getMonthFailedEmails() {
        return monthFailedEmails;
    }

    public void setMonthFailedEmails(Long monthFailedEmails) {
        this.monthFailedEmails = monthFailedEmails;
    }
}
