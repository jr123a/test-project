package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseIDFcraRulesModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<ValueCodeModel>  fcrarule;	           //Max Length:8

	public List<ValueCodeModel> getFcrarule() {
		return fcrarule;
	}

	public void setFcrarule(List<ValueCodeModel> fcrarule) {
		this.fcrarule = fcrarule;
	}
	
}
