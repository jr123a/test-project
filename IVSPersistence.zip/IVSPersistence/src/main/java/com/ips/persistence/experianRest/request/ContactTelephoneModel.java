package com.ips.persistence.experianRest.request;

import java.io.Serializable;

public class ContactTelephoneModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String id;	        //Mandatory:N, Max Length:40
	private String number;	//Mandatory:N, Max Length:40
    	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

}
