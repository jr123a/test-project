package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class ValueCodeModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String value;	           //Mandatory:Y, Max Length:8
	private String code;		   //Mandatory:Y, Max Length:40
	
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
		
}
