package com.ips.persistence.common;

import java.io.File;
import java.io.Serializable;
import java.util.Date;

import com.ips.common.common.CustomLogger;

//Generates Barcode 
public class GenerateBarcodeUtil implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * This method generates barcode images in JPEG
     * @param recordLocator 
     */
    public String generateBarcode(String recordLocator){
        GEN128 gen128 = GEN128.getInstance();

        gen128.setinString(recordLocator);
        gen128.setinPath(IPSConstants.COM_IPSWEB_BARCODE_PATH + recordLocator + ".JPEG");
        gen128.setinSwitch("A");
        gen128.getBarCode();

        return gen128.getinPath();
    }
    
    /**
     * This method deletes all the barcodes in the directory that were 
     * created before the given time,
     * time = current time - specified minutes  
     * @param minutes 
     */
    @SuppressWarnings("deprecation")
    public void emptyDirectory(int minutes){
        
        CustomLogger.debug(this.getClass(), "Barcode Directory: " + IPSConstants.COM_IPSWEB_BARCODE_PATH);
        
        Date today = new Date();
        today.setMinutes(today.getMinutes() - minutes);
        CustomLogger.debug(this.getClass(), "Barcode images that were created before "+today+" will be deleted");
        
        File dir = new File(IPSConstants.COM_IPSWEB_BARCODE_PATH);
        if(dir.isDirectory()){             
            if(dir.list().length>0){     
                CustomLogger.debug(this.getClass(), "Directory is not empty!");
                String[] files = dir.list();
                for(int x=0; x<files.length; x++){
                    File f = new File(dir, files[x]);
                    Date d = new Date(f.lastModified());
                    if(d.before(today)){
                        CustomLogger.debug(this.getClass(), f.getName()+", deleted");
                        f.delete();
                    } else{
                        CustomLogger.debug(this.getClass(), f.getName()+", not deleted");
                    }
                }
            }else{     
                CustomLogger.debug(this.getClass(), "Directory is empty!");     
            }     
        } else{     
            CustomLogger.debug(this.getClass(), "The directory is not valid");
        }
    }
}
