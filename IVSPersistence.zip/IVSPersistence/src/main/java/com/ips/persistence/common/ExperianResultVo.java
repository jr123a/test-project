package com.ips.persistence.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ExperianResultVo implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String firstName;
	private String lastName;
	private String middleName;
	private String nameSuffix;
	private String addressLine1;
	private String city;
	private String stateProvince;
	private String postalCode;
	private String mobileNumber;
	private String emailAddress;

	private String workflowRequestType;
	private String elementRequestType;
	private String initialRequestType;
	private String bearerToken;
    private String clientReferenceId;
    private String transactionId;
    private String expSequenceId;
    private String decisionSource;
    private String preciseIdDecision; 
    private String bokuServiceInfoDecision; 
    private String bokuServiceType;
    private String bokuScoreInfoDecision;
 	private String bokuAuthenticationUrl;
 	private String bokuPNVReqInfoDecision;
 	private String bokuPNVResInfoDecision;
	private String bokuPNVReqReferenceId;
	private String bokuPNVReqCorrelationId;
	private String silentAuthReferenceId;
	private String silentAuthCorrelationId;
	private String bokuSendOtpDecision;
	private String finalDecision;
	private String bokuCorrelationId;
	private String bokuAuthenticationKey;
	private String bokuOneTimePasscode;
	private String bokuValidateOtpDecision;
	private String urlInvocationResponse;
	private String phoneVerificationDecision;
	
	private String headerOverallDecision;	
	private String headerOverallDecisionText;	
	private String headerRequestType;	
	private String headerClientReferenceId;	
	private String headerExpRequestId;	
	private String headerResponseCode;	
	private String headerResponseMessage;
    private String headerMessageTime;
    private String warningResponseMessage;
    private String warningResponseCode;
	private String preciseIDSummaryScore;
	private String preciseIdExclusionCodes;
	
	private String crossCoreRequestJson;
	private String requestHeaderJson;
	private String responseHeaderJson;
	private String orchDecisionJson;
	private String decisionElementJson;
	private String responseJson;
	private String contactDataJson;
	private String testScenario;
	private String personId;
	private String proofingStatusCode;
	private String nextAction;
	private String proofingAction;
	private String errorMessage;
	private String failureReason;
	private String jwtUserName;
	private String jwtUserKey;
	private String pidUserName;
	private String pidUserKey;
	
	private long expResultId;
	private long expResponseId;
	private long preciseIDScore;
	private long bokuConfidenceScore;
	private int testUserIndex;
	 
	private boolean isDeviceTypeMobile;
	private boolean isInitialRequest;
	private boolean isRequestComplete;
	private boolean isCustomerDeceased;
	private boolean isCustomerFileBlocked;
	private boolean isCustomerNotFound;
	private boolean hasResponseError;
	private boolean passcodeExpired;
	private boolean createNewDecisionResult;
	private boolean bokuUrlSuccessfullyInvoked;
	private boolean testMode;
	private boolean skipProofingStatus;
	private boolean skipPhoneVelocity;
	private boolean useTargetTestUser;
	private boolean skipFirstAttemptErrorCheck;
	
	private List<String> infoMessageList = new ArrayList<>();
	private List<String> webServiceRequestList = new ArrayList<>();
	private List<String> webServiceResponseList = new ArrayList<>();
	
	private Map<String, String> orchDecisionJsonMap = new LinkedHashMap<>();
	private Map<String, String> decisionElementJsonMap = new LinkedHashMap<>();

    public static final String SERVICE_DECISION_CONTINUE = "CONTINUE";
    public static final String SERVICE_DECISION_ACCEPT = "ACCEPT";
    public static final String SERVICE_DECISION_INVESTIGATE = "INVESTIGAT";
    public static final String SERVICE_DECISION_STOP = "STOP";
    public static final String SERVICE_DECISION_REFER= "REFER";
    public static final String SERVICE_DECISION_REJECT = "REJECT";
    public static final String SERVICE_DECISION_NODECISION = "NODECISION";
    public static final String FAILURE_REASON_CODE_CUST_NOT_FOUND = "3001";
    public static final String FAILURE_REASON_CODE_CUST_DECEASED = "9001";
    public static final String FAILURE_REASON_CODE_CUST_BLOCKED = "9013";
    public static final String FAILURE_REASON_CODE_NO_MATCH = "400";
    public static final String FAILURE_REASON_CODE_ERROR_RESPONSE = "500";
    public static final String WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW = "SilentAuthFlow";
    public static final String WORKFLOW_REQUEST_TYPE_OTP_FLOW = "OTPFlow";
    public static final String WORKFLOW_REQUEST_TYPE_BOKU_OTP_FLOW = "BokuOTPFlow";
    public static final String APP_REQUEST_TYPE_PRECISEID_ONLY = "PreciseIdOnly";
    public static final String APP_REQUEST_TYPE_BOKU_SERVICE_INFO = "BokuServiceInfo";
    public static final String APP_REQUEST_TYPE_BOKU_SCORE_INFO = "BokuScoreInfo";
    public static final String APP_REQUEST_TYPE_BOKU_PNV_REQ = "BokuPNVReq";
    public static final String APP_REQUEST_TYPE_BOKU_PNV_RES = "BokuPNVRes";
    public static final String APP_REQUEST_TYPE_BOKU_SEND_OTP = "BokuSendOtp";
    public static final String APP_REQUEST_TYPE_BOKU_VALIDATE_OTP = "BokuValidateOtp";
    public static final String DEVICE_TYPE_MOBILE = "MobilePhone";
    public static final String DEVICE_TYPE_DESKTOP = "Desktop";
    public static final String BOKU_SERVICE_SUCCESS = "Success";
    
    public static final String BOKU_SERVICE_RESULT_SUCCESS = "Success";
    public static final String BOKU_SERVICE_RESULT_FAIL = "Fail";
    public static final String SERVICE_TYPE_FIELD = "serviceType";
    public static final String SERVICE_TYPE_MOBILE = "MOBILE";
    public static final String SERVICE_RESULT_PASSED = "PASSED";
    public static final String SERVICE_RESULT_FAILED = "FAILED";
    public static final String SERVICE_RESULT_FAIL = "SKIPPED";
    public static final String SERVICE_RESULT_INVESTIGATE = "INVESTIGATE";
    public static final String NEXT_ACTION_RESUME_SILENT_AUTH = "RESUME_SILENT_AUTH";
    public static final String NEXT_ACTION_RESUME_DESKTOP_OTP = "RESUME_DESKTOP_OTP";
    public static final String NEXT_ACTION_INIT_BOKU_OTP = "INITIATE_BOKU_OTP";
    public static final String NEXT_ACTION_RESUME_BOKU_OTP = "RESUME_BOKU_OTP";
    public static final String NEXT_ACTION_INVOKE_BOKU_URL = "INVOKE_BOKU_URL";
    public static final String NEXT_ACTION_SUBMIT_VALID_PHONE = "SUBMIT_VALID_PHONE";

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getNameSuffix() {
		return nameSuffix;
	}

	public void setNameSuffix(String nameSuffix) {
		this.nameSuffix = nameSuffix;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getStateProvince() {
		return stateProvince;
	}

	public void setStateProvince(String stateProvince) {
		this.stateProvince = stateProvince;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getWorkflowRequestType() {
		return workflowRequestType;
	}

	public void setWorkflowRequestType(String workflowRequestType) {
		this.workflowRequestType = workflowRequestType;
	}

	public String getElementRequestType() {
		return elementRequestType;
	}

	public void setElementRequestType(String elementRequestType) {
		this.elementRequestType = elementRequestType;
	}

	public String getInitialRequestType() {
		return initialRequestType;
	}

	public void setInitialRequestType(String initialRequestType) {
		this.initialRequestType = initialRequestType;
	}

	public String getBearerToken() {
		return bearerToken;
	}

	public void setBearerToken(String bearerToken) {
		this.bearerToken = bearerToken;
	}

	public String getClientReferenceId() {
		return clientReferenceId;
	}

	public void setClientReferenceId(String clientReferenceId) {
		this.clientReferenceId = clientReferenceId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public long getExpResponseId() {
		return expResponseId;
	}

	public void setExpResponseId(long expResponseId) {
		this.expResponseId = expResponseId;
	}

	public String getExpSequenceId() {
		return expSequenceId;
	}

	public void setExpSequenceId(String expSequenceId) {
		this.expSequenceId = expSequenceId;
	}

	public String getDecisionSource() {
		return decisionSource;
	}

	public void setDecisionSource(String decisionSource) {
		this.decisionSource = decisionSource;
	}

	public String getPreciseIdDecision() {
		return preciseIdDecision;
	}

	public void setPreciseIdDecision(String preciseIdDecision) {
		this.preciseIdDecision = preciseIdDecision;
	}

	public String getBokuServiceInfoDecision() {
		return bokuServiceInfoDecision;
	}

	public void setBokuServiceInfoDecision(String bokuServiceInfoDecision) {
		this.bokuServiceInfoDecision = bokuServiceInfoDecision;
	}

	public String getBokuServiceType() {
		return bokuServiceType;
	}

	public void setBokuServiceType(String bokuServiceType) {
		this.bokuServiceType = bokuServiceType;
	}

	public String getBokuScoreInfoDecision() {
		return bokuScoreInfoDecision;
	}

	public void setBokuScoreInfoDecision(String bokuScoreInfoDecision) {
		this.bokuScoreInfoDecision = bokuScoreInfoDecision;
	}

	public String getBokuAuthenticationUrl() {
		return bokuAuthenticationUrl;
	}

	public void setBokuAuthenticationUrl(String bokuAuthenticationUrl) {
		this.bokuAuthenticationUrl = bokuAuthenticationUrl;
	}

	public String getBokuPNVReqInfoDecision() {
		return bokuPNVReqInfoDecision;
	}

	public void setBokuPNVReqInfoDecision(String bokuPNVReqInfoDecision) {
		this.bokuPNVReqInfoDecision = bokuPNVReqInfoDecision;
	}

	public String getBokuPNVResInfoDecision() {
		return bokuPNVResInfoDecision;
	}

	public void setBokuPNVResInfoDecision(String bokuPNVResInfoDecision) {
		this.bokuPNVResInfoDecision = bokuPNVResInfoDecision;
	}

	public String getBokuPNVReqReferenceId() {
		return bokuPNVReqReferenceId;
	}

	public void setBokuPNVReqReferenceId(String bokuPNVReqReferenceId) {
		this.bokuPNVReqReferenceId = bokuPNVReqReferenceId;
	}

	public String getBokuPNVReqCorrelationId() {
		return bokuPNVReqCorrelationId;
	}

	public void setBokuPNVReqCorrelationId(String bokuPNVReqCorrelationId) {
		this.bokuPNVReqCorrelationId = bokuPNVReqCorrelationId;
	}

	public String getBokuSendOtpDecision() {
		return bokuSendOtpDecision;
	}

	public void setBokuSendOtpDecision(String bokuSendOtpDecision) {
		this.bokuSendOtpDecision = bokuSendOtpDecision;
	}

	public String getPhoneVerificationDecision() {
		return phoneVerificationDecision;
	}

	public void setPhoneVerificationDecision(String phoneVerificationDecision) {
		this.phoneVerificationDecision = phoneVerificationDecision;
	}

	public String getBokuCorrelationId() {
		return bokuCorrelationId;
	}

	public void setBokuCorrelationId(String bokuCorrelationId) {
		this.bokuCorrelationId = bokuCorrelationId;
	}

	public String getBokuAuthenticationKey() {
		return bokuAuthenticationKey;
	}

	public void setBokuAuthenticationKey(String bokuAuthenticationKey) {
		this.bokuAuthenticationKey = bokuAuthenticationKey;
	}

	public String getBokuOneTimePasscode() {
		return bokuOneTimePasscode;
	}

	public void setBokuOneTimePasscode(String bokuOneTimePasscode) {
		this.bokuOneTimePasscode = bokuOneTimePasscode;
	}

	public String getBokuValidateOtpDecision() {
		return bokuValidateOtpDecision;
	}

	public void setBokuValidateOtpDecision(String bokuValidateOtpDecision) {
		this.bokuValidateOtpDecision = bokuValidateOtpDecision;
	}

	public String getFinalDecision() {
		return finalDecision;
	}

	public void setFinalDecision(String finalDecision) {
		this.finalDecision = finalDecision;
	}

	public String getHeaderOverallDecision() {
		return headerOverallDecision;
	}

	public void setHeaderOverallDecision(String headerOverallDecision) {
		this.headerOverallDecision = headerOverallDecision;
	}

	public String getHeaderOverallDecisionText() {
		return headerOverallDecisionText;
	}

	public void setHeaderOverallDecisionText(String headerOverallDecisionText) {
		this.headerOverallDecisionText = headerOverallDecisionText;
	}

	public String getHeaderRequestType() {
		return headerRequestType;
	}

	public void setHeaderRequestType(String headerRequestType) {
		this.headerRequestType = headerRequestType;
	}

	public String getHeaderClientReferenceId() {
		return headerClientReferenceId;
	}

	public void setHeaderClientReferenceId(String headerClientReferenceId) {
		this.headerClientReferenceId = headerClientReferenceId;
	}

	public String getHeaderExpRequestId() {
		return headerExpRequestId;
	}

	public void setHeaderExpRequestId(String headerExpRequestId) {
		this.headerExpRequestId = headerExpRequestId;
	}

	public String getHeaderResponseCode() {
		return headerResponseCode;
	}

	public void setHeaderResponseCode(String headerResponseCode) {
		this.headerResponseCode = headerResponseCode;
	}

	public String getHeaderResponseMessage() {
		return headerResponseMessage;
	}

	public void setHeaderResponseMessage(String headerResponseMessage) {
		this.headerResponseMessage = headerResponseMessage;
	}

	public String getHeaderMessageTime() {
		return headerMessageTime;
	}

	public void setHeaderMessageTime(String headerMessageTime) {
		this.headerMessageTime = headerMessageTime;
	}

	public String getWarningResponseMessage() {
		return warningResponseMessage;
	}

	public void setWarningResponseMessage(String warningResponseMessage) {
		this.warningResponseMessage = warningResponseMessage;
	}

	public String getWarningResponseCode() {
		return warningResponseCode;
	}

	public void setWarningResponseCode(String warningResponseCode) {
		this.warningResponseCode = warningResponseCode;
	}

	public String getPreciseIDSummaryScore() {
		return preciseIDSummaryScore;
	}

	public void setPreciseIDSummaryScore(String preciseIDSummaryScore) {
		this.preciseIDSummaryScore = preciseIDSummaryScore;
	}

	public String getPreciseIdExclusionCodes() {
		return preciseIdExclusionCodes;
	}

	public void setPreciseIdExclusionCodes(String preciseIdExclusionCodes) {
		this.preciseIdExclusionCodes = preciseIdExclusionCodes;
	}

	public String getCrossCoreRequestJson() {
		return crossCoreRequestJson;
	}

	public void setCrossCoreRequestJson(String crossCoreRequestJson) {
		this.crossCoreRequestJson = crossCoreRequestJson;
	}
	
	public String getRequestHeaderJson() {
		return requestHeaderJson;
	}

	public void setRequestHeaderJson(String requestHeaderJson) {
		this.requestHeaderJson = requestHeaderJson;
	}

	public String getResponseHeaderJson() {
		return responseHeaderJson;
	}

	public void setResponseHeaderJson(String responseHeaderJson) {
		this.responseHeaderJson = responseHeaderJson;
	}

	public String getOrchDecisionJson() {
		return orchDecisionJson;
	}

	public void setOrchDecisionJson(String orchDecisionJson) {
		this.orchDecisionJson = orchDecisionJson;
	}

	public String getDecisionElementJson() {
		return decisionElementJson;
	}

	public void setDecisionElementJson(String decisionElementJson) {
		this.decisionElementJson = decisionElementJson;
	}

	public String getContactDataJson() {
		return contactDataJson;
	}

	public void setContactDataJson(String contactDataJson) {
		this.contactDataJson = contactDataJson;
	}

	public long getExpResultId() {
		return expResultId;
	}

	public void setExpResultId(long expResultId) {
		this.expResultId = expResultId;
	}

	public long getPreciseIDScore() {
		return preciseIDScore;
	}

	public void setPreciseIDScore(long preciseIDScore) {
		this.preciseIDScore = preciseIDScore;
	}

	public long getBokuConfidenceScore() {
		return bokuConfidenceScore;
	}

	public void setBokuConfidenceScore(long bokuConfidenceScore) {
		this.bokuConfidenceScore = bokuConfidenceScore;
	}

	public boolean isDeviceTypeMobile() {
		return isDeviceTypeMobile;
	}

	public void setDeviceTypeMobile(boolean isDeviceTypeMobile) {
		this.isDeviceTypeMobile = isDeviceTypeMobile;
	}

	public boolean isInitialRequest() {
		return isInitialRequest;
	}

	public void setInitialRequest(boolean isInitialRequest) {
		this.isInitialRequest = isInitialRequest;
	}

	public boolean isRequestComplete() {
		return isRequestComplete;
	}

	public void setRequestComplete(boolean isRequestComplete) {
		this.isRequestComplete = isRequestComplete;
	}

	public boolean isCustomerDeceased() {
		return isCustomerDeceased;
	}

	public void setCustomerDeceased(boolean isCustomerDeceased) {
		this.isCustomerDeceased = isCustomerDeceased;
	}

	public boolean isCustomerFileBlocked() {
		return isCustomerFileBlocked;
	}

	public void setCustomerFileBlocked(boolean isCustomerFileBlocked) {
		this.isCustomerFileBlocked = isCustomerFileBlocked;
	}

	public boolean isCustomerNotFound() {
		return isCustomerNotFound;
	}

	public void setCustomerNotFound(boolean isCustomerNotFound) {
		this.isCustomerNotFound = isCustomerNotFound;
	}
	
	public boolean isPasscodeExpired() {
		return passcodeExpired;
	}

	public void setPasscodeExpired(boolean passcodeExpired) {
		this.passcodeExpired = passcodeExpired;
	}

	public boolean isCreateNewDecisionResult() {
		return createNewDecisionResult;
	}

	public void setCreateNewDecisionResult(boolean createNewDecisionResult) {
		this.createNewDecisionResult = createNewDecisionResult;
	}

	public boolean isTestMode() {
		return testMode;
	}

	public void setTestMode(boolean testMode) {
		this.testMode = testMode;
	}

	public boolean isSkipProofingStatus() {
		return skipProofingStatus;
	}

	public void setSkipProofingStatus(boolean skipProofingStatus) {
		this.skipProofingStatus = skipProofingStatus;
	}

	public boolean isSkipPhoneVelocity() {
		return skipPhoneVelocity;
	}

	public void setSkipPhoneVelocity(boolean skipPhoneVelocity) {
		this.skipPhoneVelocity = skipPhoneVelocity;
	}

	public String getProofingStatusCode() {
		return proofingStatusCode;
	}

	public void setProofingStatusCode(String proofingStatusCode) {
		this.proofingStatusCode = proofingStatusCode;
	}

	public String getNextAction() {
		return nextAction;
	}

	public void setNextAction(String nextAction) {
		this.nextAction = nextAction;
	}

	public String getProofingAction() {
		return proofingAction;
	}

	public void setProofingAction(String proofingAction) {
		this.proofingAction = proofingAction;
	}
	
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public String getFailureReason() {
		return failureReason;
	}

	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}
	
	public void addInfoMessageList(String value) {
		infoMessageList.add(value);
	}

	public List<String> getInfoMessageList() {
		return infoMessageList;
	}

	public void setInfoMessageList(List<String> infoMessageList) {
		this.infoMessageList = infoMessageList;
	}

	public String getTestScenario() {
		return testScenario;
	}

	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}

	public String getPersonId() {
		return personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	public boolean isBokuUrlSuccessfullyInvoked() {
		return bokuUrlSuccessfullyInvoked;
	}

	public void setBokuUrlSuccessfullyInvoked(boolean bokuUrlSuccessfullyInvoked) {
		this.bokuUrlSuccessfullyInvoked = bokuUrlSuccessfullyInvoked;
	}

	public void addWebServiceRequestList(String value) {
		webServiceRequestList.add(value);
	}
	
	public List<String> getWebServiceRequestList() {
		return webServiceRequestList;
	}

	public void setWebServiceRequestList(List<String> webServiceRequestList) {
		this.webServiceRequestList = webServiceRequestList;
	}

	public void addWebServiceResponseList(String value) {
		webServiceResponseList.add(value);
	}
	
	public List<String> getWebServiceResponseList() {
		return webServiceResponseList;
	}

	public void setWebServiceResponseList(List<String> webServiceResponseList) {
		this.webServiceResponseList = webServiceResponseList;
	}

	public Map<String, String> getOrchDecisionJsonMap() {
		return orchDecisionJsonMap;
	}

	public void setOrchDecisionJsonMap(Map<String, String> orchDecisionJsonMap) {
		this.orchDecisionJsonMap = orchDecisionJsonMap;
	}
	
	public void putOrchDecisionJson(String key, String value) {
		orchDecisionJsonMap.put(key, value);
	}
	
	public void clearOrchDecisionJson() {
		orchDecisionJsonMap.clear();
	}

	public Map<String, String> getDecisionElementJsonMap() {
		return decisionElementJsonMap;
	}

	public void setDecisionElementJsonMap(Map<String, String> decisionElementJsonMap) {
		this.decisionElementJsonMap = decisionElementJsonMap;
	}
	
	public void putDecisionElementJson(String key, String value) {
		decisionElementJsonMap.put(key, value);
	}
	
	public void clearDecisionElementJson() {
		decisionElementJsonMap.clear();
	}

	public int getTestUserIndex() {
		return testUserIndex;
	}

	public void setTestUserIndex(int testUserIndex) {
		this.testUserIndex = testUserIndex;
	}

	public boolean isUseTargetTestUser() {
		return useTargetTestUser;
	}

	public void setUseTargetTestUser(boolean useTargetTestUser) {
		this.useTargetTestUser = useTargetTestUser;
	}

	public boolean isSkipFirstAttemptErrorCheck() {
		return skipFirstAttemptErrorCheck;
	}

	public void setSkipFirstAttemptErrorCheck(boolean skipFirstAttemptErrorCheck) {
		this.skipFirstAttemptErrorCheck = skipFirstAttemptErrorCheck;
	}

	public String getJwtUserName() {
		return jwtUserName;
	}

	public void setJwtUserName(String jwtUserName) {
		this.jwtUserName = jwtUserName;
	}

	public String getJwtUserKey() {
		return jwtUserKey;
	}

	public void setJwtUserKey(String jwtUserKey) {
		this.jwtUserKey = jwtUserKey;
	}

	public String getPidUserName() {
		return pidUserName;
	}

	public void setPidUserName(String pidUserName) {
		this.pidUserName = pidUserName;
	}

	public String getPidUserKey() {
		return pidUserKey;
	}

	public void setPidUserKey(String pidUserKey) {
		this.pidUserKey = pidUserKey;
	}

	public String getUrlInvocationResponse() {
		return urlInvocationResponse;
	}

	public void setUrlInvocationResponse(String urlInvocationResponse) {
		this.urlInvocationResponse = urlInvocationResponse;
	}

	public String getSilentAuthReferenceId() {
		return silentAuthReferenceId;
	}

	public void setSilentAuthReferenceId(String silentAuthReferenceId) {
		this.silentAuthReferenceId = silentAuthReferenceId;
	}

	public String getSilentAuthCorrelationId() {
		return silentAuthCorrelationId;
	}

	public void setSilentAuthCorrelationId(String silentAuthCorrelationId) {
		this.silentAuthCorrelationId = silentAuthCorrelationId;
	}

	public String getResponseJson() {
		return responseJson;
	}

	public void setResponseJson(String responseJson) {
		this.responseJson = responseJson;
	}

	public boolean hasResponseError() {
		return this.hasResponseError;
	}

	public void setHasResponseError(boolean hasResponseError) {
		this.hasResponseError = hasResponseError;
	}
}
