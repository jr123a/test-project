package com.ips.persistence.experianRest.request;

import java.io.Serializable;

public class CrossCoreRequestModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private RequestHeaderModel header;	       //Mandatory:Y, Max Length:8
	private RequestPayloadModel payload;	   //Mandatory:Y, Max Length:40
	
	public RequestHeaderModel getHeader() {
		return header;
	}
	
	public void setHeader(RequestHeaderModel header) {
		this.header = header;
	}

	public RequestPayloadModel getPayload() {
		return payload;
	}

	public void setPayload(RequestPayloadModel payload) {
		this.payload = payload;
	}
	
}
