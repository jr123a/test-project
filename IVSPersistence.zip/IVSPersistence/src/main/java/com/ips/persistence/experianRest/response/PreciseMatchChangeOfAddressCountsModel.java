package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchChangeOfAddressCountsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int changeOfAddressReturnCount;	           //Max Length:8

	public int getChangeOfAddressReturnCount() {
		return changeOfAddressReturnCount;
	}

	public void setChangeOfAddressReturnCount(int changeOfAddressReturnCount) {
		this.changeOfAddressReturnCount = changeOfAddressReturnCount;
	}
	
}
