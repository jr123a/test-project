package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class OverallErrorResponseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private CommonErrorResponseModel errorResponseModel;
	private int statusCode;
	private String message;
	
	public CommonErrorResponseModel getErrorResponseModel() {
		return errorResponseModel;
	}
	
	public void setErrorResponseModel(CommonErrorResponseModel errorResponseModel) {
		this.errorResponseModel = errorResponseModel;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
