package com.ips.persistence.experianRest.request;

import java.io.Serializable;

public class RequestHeaderModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String tenantId;	       
	private String requestType;		   
	private String clientReferenceId;  
	private String expRequestId;	   
	private String messageTime; 	   
	private String txnId; 	   
	private String time; 	  
	private HeaderOptionModel options; 
	
	public String getTenantId() {
		return tenantId;
	}
	
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getClientReferenceId() {
		return clientReferenceId;
	}

	public void setClientReferenceId(String clientReferenceId) {
		this.clientReferenceId = clientReferenceId;
	}

	public String getExpRequestId() {
		return expRequestId;
	}

	public void setExpRequestId(String expRequestId) {
		this.expRequestId = expRequestId;
	}

	public String getMessageTime() {
		return messageTime;
	}

	public void setMessageTime(String messageTime) {
		this.messageTime = messageTime;
	}

	public HeaderOptionModel getOptions() {
		return options;
	}

	public void setOptions(HeaderOptionModel options) {
		this.options = options;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

}
