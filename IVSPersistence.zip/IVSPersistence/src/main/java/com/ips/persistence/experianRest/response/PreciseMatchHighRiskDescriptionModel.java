package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchHighRiskDescriptionModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String highRiskDescription;	           //Mandatory:Y, Max Length:8

	public String getHighRiskDescription() {
		return highRiskDescription;
	}

	public void setHighRiskDescription(String highRiskDescription) {
		this.highRiskDescription = highRiskDescription;
	}
	
}
