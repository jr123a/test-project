package com.ips.persistence.common;

import java.io.Serializable;

public class FraudEmailVo implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private Long emailRecordId;
    private Long personId;
    private String requestId;
    private String emailAddress;
    
    public FraudEmailVo (Long emailRecordId, String emailAddress)  {
        this.emailRecordId = emailRecordId;
        this.emailAddress = emailAddress;
    }
    
    public FraudEmailVo (Long emailRecordId, Long personId, String requestId, String emailAddress)  {
        this.emailRecordId = emailRecordId;
        this.personId = personId;
        this.requestId = requestId;
        this.emailAddress = emailAddress;
    }
    
    public Long getEmailRecordId() {
        return emailRecordId;
    }
    
    public void setEmailRecordId(Long emailRecordId) {
        this.emailRecordId = emailRecordId;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

}
