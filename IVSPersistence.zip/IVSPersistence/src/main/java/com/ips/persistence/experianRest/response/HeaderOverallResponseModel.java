package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class HeaderOverallResponseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String decision;	           //Total Length:21
	private String score;	               //Total Length:13
	private String decisionText;		   //Total Length:35
	private List<String> decisionReasons;  //Total Length:41
	private List<String> recommendedNextActions;	   //Total Length:29
	private List<String> spareObjects; 	   //Total Length:18
	
	public String getDecision() {
		return decision;
	}
	
	public void setDecision(String decision) {
		this.decision = decision;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getDecisionText() {
		return decisionText;
	}

	public void setDecisionText(String decisionText) {
		this.decisionText = decisionText;
	}

	public List<String> getDecisionReasons() {
		return decisionReasons;
	}

	public void setDecisionReasons(List<String> decisionReasons) {
		this.decisionReasons = decisionReasons;
	}

	public List<String> getRecommendedNextActions() {
		return recommendedNextActions;
	}

	public void setRecommendedNextActions(List<String> recommendedNextActions) {
		this.recommendedNextActions = recommendedNextActions;
	}

	public List<String> getSpareObjects() {
		return spareObjects;
	}

	public void setSpareObjects(List<String> spareObjects) {
		this.spareObjects = spareObjects;
	}
	
}
