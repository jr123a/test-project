package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchDriverLicenseSummaryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ValueCodeModel verificationResult;	           //Max Length:8
	private ValueCodeModel formatValidation;	           //Max Length:8
	
	public ValueCodeModel getVerificationResult() {
		return verificationResult;
	}
	
	public void setVerificationResult(ValueCodeModel verificationResult) {
		this.verificationResult = verificationResult;
	}

	public ValueCodeModel getFormatValidation() {
		return formatValidation;
	}

	public void setFormatValidation(ValueCodeModel formatValidation) {
		this.formatValidation = formatValidation;
	}
	
}
