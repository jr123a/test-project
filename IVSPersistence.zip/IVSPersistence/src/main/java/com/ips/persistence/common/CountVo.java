package com.ips.persistence.common;

import java.io.Serializable;



public class CountVo implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private int attemptsAllowed;
    private int attemptsMade;
    private int attemptPeriod;
    
    public int getAttemptsAllowed() {
        return attemptsAllowed;
    }
    public void setAttemptsAllowed(int attemptsAllowed) {
        this.attemptsAllowed = attemptsAllowed;
    }
    public int getAttemptsMade() {
        return attemptsMade;
    }
    public void setAttemptsMade(int attemptsMade) {
        this.attemptsMade = attemptsMade;
    }
    public int getAttemptPeriod() {
        return attemptPeriod;
    }
    public void setAttemptPeriod(int attemptPeriod) {
        this.attemptPeriod = attemptPeriod;
    }        
}
