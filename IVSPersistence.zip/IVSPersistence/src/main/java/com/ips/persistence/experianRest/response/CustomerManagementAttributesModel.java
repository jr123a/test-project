package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class CustomerManagementAttributesModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String attributes01Day;	           //Max Length:8
	private String attributes03Day;	           //Max Length:8
	private String attributes07Day;	           //Max Length:8
	private String attributes21Day;	           //Max Length:8
	private String attributes28Day;	           //Max Length:8
	private String attributes90Day;	           //Max Length:8
	
	public String getAttributes01Day() {
		return attributes01Day;
	}
	
	public void setAttributes01Day(String attributes01Day) {
		this.attributes01Day = attributes01Day;
	}

	public String getAttributes03Day() {
		return attributes03Day;
	}

	public String getAttributes07Day() {
		return attributes07Day;
	}

	public String getAttributes21Day() {
		return attributes21Day;
	}

	public String getAttributes28Day() {
		return attributes28Day;
	}

	public String getAttributes90Day() {
		return attributes90Day;
	}

	public void setAttributes03Day(String attributes03Day) {
		this.attributes03Day = attributes03Day;
	}

	public void setAttributes07Day(String attributes07Day) {
		this.attributes07Day = attributes07Day;
	}

	public void setAttributes21Day(String attributes21Day) {
		this.attributes21Day = attributes21Day;
	}

	public void setAttributes28Day(String attributes28Day) {
		this.attributes28Day = attributes28Day;
	}

	public void setAttributes90Day(String attributes90Day) {
		this.attributes90Day = attributes90Day;
	}
	
}
