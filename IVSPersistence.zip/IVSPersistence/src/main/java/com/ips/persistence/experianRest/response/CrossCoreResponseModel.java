package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class CrossCoreResponseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ResponseHeaderModel responseHeader;	           
	private ResponsePayloadModel clientResponsePayload;	    
	private OriginalRequestDataModel originalRequestData;
	private OverallErrorResponseModel overallErrorResponse;
	private CommonErrorResponseModel commonErrorResponse;
	
	public ResponseHeaderModel getResponseHeader() {
		return responseHeader;
	}
	
	public void setResponseHeader(ResponseHeaderModel responseHeader) {
		this.responseHeader = responseHeader;
	}

	public ResponsePayloadModel getClientResponsePayload() {
		return clientResponsePayload;
	}

	public void setClientResponsePayload(ResponsePayloadModel clientResponsePayload) {
		this.clientResponsePayload = clientResponsePayload;
	}

	public OriginalRequestDataModel getOriginalRequestData() {
		return originalRequestData;
	}

	public void setOriginalRequestData(OriginalRequestDataModel originalRequestData) {
		this.originalRequestData = originalRequestData;
	}

	public OverallErrorResponseModel getOverallErrorResponse() {
		return overallErrorResponse;
	}

	public void setOverallErrorResponse(OverallErrorResponseModel overallErrorResponse) {
		this.overallErrorResponse = overallErrorResponse;
	}

	public CommonErrorResponseModel getCommonErrorResponse() {
		return commonErrorResponse;
	}

	public void setCommonErrorResponse(CommonErrorResponseModel commonErrorResponse) {
		this.commonErrorResponse = commonErrorResponse;
	}
	
}
