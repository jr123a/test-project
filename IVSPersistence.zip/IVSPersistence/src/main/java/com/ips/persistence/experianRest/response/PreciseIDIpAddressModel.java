package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseIDIpAddressModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ValueCodeModel ipAddressMatchCountry;	           //Max Length:8
	private ValueCodeModel ipAddressMatchState;	           //Max Length:8
	private ValueCodeModel ipAddressMatchCity;	           //Max Length:8
	private ValueCodeModel ipAddressMatchZipCode;	           //Max Length:8
	
	public ValueCodeModel getIpAddressMatchCountry() {
		return ipAddressMatchCountry;
	}
	
	public void setIpAddressMatchCountry(ValueCodeModel ipAddressMatchCountry) {
		this.ipAddressMatchCountry = ipAddressMatchCountry;
	}

	public ValueCodeModel getIpAddressMatchState() {
		return ipAddressMatchState;
	}

	public void setIpAddressMatchState(ValueCodeModel ipAddressMatchState) {
		this.ipAddressMatchState = ipAddressMatchState;
	}

	public ValueCodeModel getIpAddressMatchCity() {
		return ipAddressMatchCity;
	}

	public void setIpAddressMatchCity(ValueCodeModel ipAddressMatchCity) {
		this.ipAddressMatchCity = ipAddressMatchCity;
	}

	public ValueCodeModel getIpAddressMatchZipCode() {
		return ipAddressMatchZipCode;
	}

	public void setIpAddressMatchZipCode(ValueCodeModel ipAddressMatchZipCode) {
		this.ipAddressMatchZipCode = ipAddressMatchZipCode;
	}
	
}
