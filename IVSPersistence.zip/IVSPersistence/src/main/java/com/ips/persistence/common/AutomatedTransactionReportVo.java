package com.ips.persistence.common;

public class AutomatedTransactionReportVo {
    
    private long personId; 
    private String custRegId; 
    private String emailAddress;
    private String otpSupplierName;  
    private String mobilePhoneNumber;  
    private String transactionKey; 
    private String pvOutcome;
    private String finalDecision; 
    private int submitOtp; 
    private int requestNewCodes;
    private String createDate; 
    
    public long getPersonId() {
        return personId;
    }
    public void setPersonId(long personId) {
        this.personId = personId;
    }
    public String getCustRegId() {
        return custRegId;
    }
    public void setCustRegId(String custRegId) {
        this.custRegId = custRegId;
    }
    public String getEmailAddress() {
        return emailAddress;
    }
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    public String getOtpSupplierName() {
        return otpSupplierName;
    }
    public void setOtpSupplierName(String otpSupplierName) {
        this.otpSupplierName = otpSupplierName;
    }
    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }
    public void setMobilePhoneNumber(String mobilePhoneNumber) {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }
    public String getTransactionKey() {
        return transactionKey;
    }
    public void setTransactionKey(String transactionKey) {
        this.transactionKey = transactionKey;
    }
    public String getPvOutcome() {
        return pvOutcome;
    }
    public void setPvOutcome(String pvOutcome) {
        this.pvOutcome = pvOutcome;
    }
    public String getFinalDecision() {
        return finalDecision;
    }
    public void setFinalDecision(String finalDecision) {
        this.finalDecision = finalDecision;
    }
    public int getSubmitOtp() {
        return submitOtp;
    }
    public void setSubmitOtp(int submitOtp) {
        this.submitOtp = submitOtp;
    }
    public int getRequestNewCodes() {
        return requestNewCodes;
    }
    public void setRequestNewCodes(int requestNewCodes) {
        this.requestNewCodes = requestNewCodes;
    }
    public String getCreateDate() {
        return createDate;
    }
    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

}
