package com.ips.persistence.common;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Properties;

import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.mail.util.ByteArrayDataSource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.Utils;

@Service("emailer")
public class Emailer implements Serializable{
    private static final long serialVersionUID = 1L;
    private final String[] imageNames = {"Email-Logo.jpg", "driverLicense.png", "stateID.png", "UniformService.png", 
                                         "passport.png", "mortgage.png", "vehicleRegistration.png", "insurancePolicy.png"};
    private static final String SERVER_NAME_MYPC = "mypc.usps.com"; 
    private static final String SERVER_NAME_LOCALHOST = "localhost";
    
    private JavaMailSender configureMailSender() {
		JavaMailSender mailSender = new JavaMailSenderImpl();
		String smtpHost = "auth-mailrelay.usps.gov";
		((JavaMailSenderImpl) mailSender).setHost(smtpHost);
		((JavaMailSenderImpl) mailSender).setPort(Integer.parseInt("587"));
		((JavaMailSenderImpl) mailSender).setUsername("SMTP_PROD_IVS_4482"); //default to prod
		if(isNonProd()) {	 //If not prod, use nonprod username
			((JavaMailSenderImpl) mailSender).setUsername("SMTP_IVS_NONPROD");
			CustomLogger.info(this.getClass(), "Configuring non prod email");
		}
		try {
			((JavaMailSenderImpl) mailSender).setPassword(new String(Utils.getPasswordCredential("AuthMailRelayCred").getPassword()));
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred retrieving auth mail relay credentials", e);
		}

		Properties mailProps = setMailProps(smtpHost);
		((JavaMailSenderImpl) mailSender).setJavaMailProperties(mailProps);
		return mailSender;
	}

	private boolean isNonProd() {
		return !"prod".equalsIgnoreCase(Utils.getEnvironmentWithoutDot());
	}

	private Properties setMailProps(String smtpHost) {
		Properties mailProps = new Properties();
		mailProps.put("mail.debug", false);
		mailProps.put("mail.smtp.timeout", 30000);
		mailProps.put("mail.smtp.connectiontimeout", 30000);
		mailProps.put("mail.smtp.starttls.enable", true);
		mailProps.put("mail.smtp.ssl.protocols", "TLSv1.2");
		mailProps.put("mail.smtp.ssl.trust", smtpHost);
		mailProps.put("mail.email.usps.auth", true);
		return mailProps;
	}
    
    /**
     * Sends IPP Email with graphics
     * @param barcodePath
     * @param emailTo
     * @param htmlText
     * @param subject
     * @param sponsorId
     */
    public void sendIppEmail(String barcodePath, String emailTo, String htmlText, String subject, Long sponsorId) {
    	JavaMailSender mailSender = configureMailSender();
        MimeMessagePreparator prep;
                
        try {
            
            prep = mimeMessage -> {
                MimeMessageHelper helper = buildMimeMessageHelper(mimeMessage, emailTo, null, subject, htmlText);
                helper = addBarcodeToHelper(barcodePath, helper);
                
                for (String name : imageNames) {
                    helper.addInline(name.substring(0, name.lastIndexOf('.')), convertImageToDataSource(name, null));
                }
            };
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred during building of IPP email: ", e);
            throw e;
        }
        
        try {
            mailSender.send(prep);
        } catch (MailException e) {
            CustomLogger.error(this.getClass(), "MailException occurred when attempting to send IPP email: ", e);
            throw e;
        }
    }

    /**
     * Sends IPP Email without graphics
     * @param barcodePath
     * @param emailTo
     * @param htmlText
     * @param subject
     */
    public void sendEmail(String barcodePath, String emailTo, String htmlText, String subject, byte[] agencyLogo) {
    	JavaMailSender mailSender = configureMailSender();
    	MimeMessagePreparator prep;
        
        if (agencyLogo == null || agencyLogo.length == 0) {
            htmlText = htmlText.replace("<img src=\"cid:Partnership-Logo\" border=\"0\" />", "");
        }
        
        final String htmlTextEdit = htmlText;
        
        try {
            prep = mimeMessage -> {
                MimeMessageHelper helper = buildMimeMessageHelper(mimeMessage, emailTo, null, subject, htmlTextEdit);
                helper = addBarcodeToHelper(barcodePath, helper);
                for (String name : imageNames) {
                    helper.addInline(name.substring(0, name.lastIndexOf('.')), convertImageToDataSource(name, null));
                }

                if (agencyLogo != null && agencyLogo.length > 0) {
                    helper.addInline("Partnership-Logo", convertImageToDataSource(null, agencyLogo));
                }
            };
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred during building of IPP email: ", e);
            throw e;
        }

        try {
            mailSender.send(prep);
        } catch (MailException e) {
            CustomLogger.error(this.getClass(), "MailException occurred when attempting to send IPP email: ", e);
            throw e;
        }
    }

    public void sendHtmlEmail(String[] emailTo, String htmlText, String subject, boolean includeLogo, byte[] agencyLogo) {
    	JavaMailSender mailSender = configureMailSender();
    	MimeMessagePreparator prep;
        
        if (!includeLogo) {
            htmlText = htmlText.replace("<img src=\"cid:Email-Logo\" border=\"0\">", "");
        }
        if (agencyLogo == null || agencyLogo.length == 0) {
            htmlText = htmlText.replace("<img src=\"cid:Partnership-Logo\" border=\"0\" />", "");
        }
        
        final String htmlTextEdit = htmlText;

        try {
            prep = mimeMessage -> {
                MimeMessageHelper helper = buildMimeMessageHelper(mimeMessage, null, emailTo, subject, htmlTextEdit);

                if (includeLogo) {
                    helper.addInline(imageNames[0].substring(0, imageNames[0].indexOf('.')), convertImageToDataSource(imageNames[0], null));
                }
                if (agencyLogo != null && agencyLogo.length > 0) {
                    helper.addInline("Partnership-Logo", convertImageToDataSource(null, agencyLogo));
                }
            };
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred during building of IPP email: ", e);
            throw e;
        }

        try {
            mailSender.send(prep);
        } catch (MailException e) {
            CustomLogger.error(this.getClass(), "MailException occurred when attempting to send IPP email: ", e);
            throw e;
        }
    }

    public void sendHtmlEmailWithAttachment(String[] emailTo, String htmlText, String subject, String attachmentPath, String attachmentName) {
    	JavaMailSender mailSender = configureMailSender();
    	MimeMessagePreparator prep;

        try {
            prep = mimeMessage -> {
                MimeMessageHelper helper = buildMimeMessageHelper(mimeMessage, null, emailTo, subject, htmlText);
                helper.addAttachment(attachmentName, new FileDataSource(attachmentPath));
            };
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred during building of IPP email: ", e);
            throw e;
        }

        try {
            mailSender.send(prep);
        } catch (MailException e) {
            CustomLogger.error(this.getClass(), "MailException occurred when attempting to send IPP email: ", e);
            throw e;
        }
    }

    public void sendTextEmail(String[] emailTo, String text, String subject) {
    	JavaMailSender mailSender = configureMailSender();
    	MimeMessagePreparator prep;

        try {
            prep = mimeMessage -> {
                MimeMessageHelper helper = buildMimeMessageHelper(mimeMessage, null, emailTo, subject, text);
                helper.setText(text, false);
            };
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred during building of IPP email: ", e);
            throw e;
        }

        try {
            mailSender.send(prep);
        } catch (MailException e) {
            CustomLogger.error(this.getClass(), "MailException occurred when attempting to send IPP email: ", e);
            throw e;
        }
    }
    
    public void sendTextEmailWithAttachment(String[] emailTo, String text, String subject, String attachmentPath, String attachmentName) {
    	JavaMailSender mailSender = configureMailSender();

    	MimeMessagePreparator prep;

        try {
            prep = mimeMessage -> {
                MimeMessageHelper helper = buildMimeMessageHelper(mimeMessage, null, emailTo, subject, text);
                helper.setText(text, false);
                helper.addAttachment(attachmentName, new FileDataSource(attachmentPath));
            };
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred during building of IPP email: ", e);
            throw e;
        }

        try {
            mailSender.send(prep);
        } catch (MailException e) {
            CustomLogger.error(this.getClass(), "MailException occurred when attempting to send IPP email: ", e);
            throw e;
        }
    }
    
    public void sendTextEmailWithMultipleAttachments(String[] emailTo, String text, String subject, String[] attachmentPath, String[] attachmentName) {
    	JavaMailSender mailSender = configureMailSender();
    	MimeMessagePreparator prep;

        try {
            prep = mimeMessage -> {
                MimeMessageHelper helper = buildMimeMessageHelper(mimeMessage, null, emailTo, subject, text);
                helper.setText(text, false);
                
                for (int i = 0; i < attachmentPath.length; i++) {
                    helper.addAttachment(attachmentName[i], new FileDataSource(attachmentPath[i]));
                }
            };
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred during building of IPP email: ", e);
            throw e;
        }

        try {
            mailSender.send(prep);
        } catch (MailException e) {
            CustomLogger.error(this.getClass(), "MailException occurred when attempting to send IPP email: ", e);
            throw e;
        }
    }
    
    /**
     * Converts an image to a data source to be inserted into an email
     * @param imageName - send name of file if image is stored on web server under images directory
     * @param agencyLogo - send byte array of image data if image is stored in db
     * @return DataSource object to be inserted into email
     * @throws IOException
     * @throws SQLException
     */
    private DataSource convertImageToDataSource(String imageName, byte[] agencyLogo) throws IOException, SQLException {
        if (imageName != null) {
            CustomLogger.debug(this.getClass(), "URL: " + Utils.getProperty("com.ipsweb.VERIFICATION_URL") + "/../images/" + imageName);
            BufferedImage bufferedImage = ImageIO.read(new URL(Utils.getProperty("com.ipsweb.VERIFICATION_URL") + "/../images/" + imageName));
            
            try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                ImageIO.write(bufferedImage, imageName.substring(imageName.lastIndexOf('.') + 1), baos);
                baos.flush();
                return new ByteArrayDataSource(baos.toByteArray(), "image/" + (imageName.endsWith("jpg") ? "jpeg" : imageName.substring(imageName.lastIndexOf('.') + 1)));
            }
        } else if (agencyLogo != null && agencyLogo.length > 0) {
            try (ByteArrayOutputStream baos = new ByteArrayOutputStream(agencyLogo.length)) {
                baos.write(agencyLogo, 0, agencyLogo.length);
                return new ByteArrayDataSource(baos.toByteArray(), "application/octet-stream");
            }
        }
        
        return null;
    }
    
    private MimeMessageHelper buildMimeMessageHelper(MimeMessage mimeMessage, String emailTo, String[] emailToArray, String subject, String htmlText) throws MessagingException {
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
        if (StringUtils.isNotBlank(emailTo)) {
            helper.setTo(emailTo);
        } else if (emailToArray != null && emailToArray.length > 0) {
            helper.setTo(emailToArray);
        }
        helper.setSubject(subject);
        helper.setFrom(Utils.getPropertyWithoutEnvironment("emailer.sender.email.address"));
        helper.setText(htmlText, true);
        return helper;
    }

    private MimeMessageHelper addBarcodeToHelper(String barcodePath, MimeMessageHelper helper) throws MessagingException {
        DataSource barcode = new FileDataSource(barcodePath);
        helper.addInline("barcode", barcode);
        helper.addAttachment("barcode.jpg", barcode);
        return helper;
    }
    
	public boolean isLocalServer() {
		try {
			HttpServletRequest httpServletRequest = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		    String serverName = httpServletRequest.getServerName();
		    return serverName.contains(SERVER_NAME_MYPC) || serverName.contains(SERVER_NAME_LOCALHOST);
		} catch (Exception e) {
			return false;
		}
	}
}
