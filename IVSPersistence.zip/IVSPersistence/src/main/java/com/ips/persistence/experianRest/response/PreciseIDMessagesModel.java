package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseIDMessagesModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<PreciseIDMessageItemModel> message;	           //Mandatory:Y, Max Length:8
	private List<String> consumerStatement;
	
	public List<PreciseIDMessageItemModel> getMessage() {
		return message;
	}

	public void setMessage(List<PreciseIDMessageItemModel> message) {
		this.message = message;
	}

	public List<String> getConsumerStatement() {
		return consumerStatement;
	}

	public void setConsumerStatement(List<String> consumerStatement) {
		this.consumerStatement = consumerStatement;
	}
	
}
