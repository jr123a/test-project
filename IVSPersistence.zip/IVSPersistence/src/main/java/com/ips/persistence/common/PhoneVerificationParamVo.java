package com.ips.persistence.common;

import java.io.Serializable;

public class PhoneVerificationParamVo implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private String mobilePhoneNumber;
    private long velocityTimerValue;
    
    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }

    public void setMobilePhoneNumber(String mobilePhoneNumber) {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }

    public long getVelocityTimerValue() {
        return velocityTimerValue;
    }

    public void setVelocityTimerValue(long velocityTimerValue) {
        this.velocityTimerValue = velocityTimerValue;
    }
}
