package com.ips.persistence.common;

import java.io.Serializable;
import java.util.List;

public class UserVo implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private long userId;
    private String sponsorUserId;
    private String sponsor;
    private String status;
    private long statusCode = 0L;
    private String email;
    private String pin;
    private String firstName = "";
    private String lastName = "";
    private String loaSought;
    private long loaAchieved;
    private List<Object> filteredPOList;
    private boolean resendActivationEmail = true;
    private boolean activationLinkExpired = false;
    private boolean activationRetry = false;
    private boolean alreadyActivated = false;
    private boolean IPPemailSent = false;
    private long highRiskAttemptId;
    private long secondaryAttemptId;
    private boolean redirectFromCustReg = false;
    private boolean selected;
    
    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getSponsorUserId() {
        return sponsorUserId;
    }

    public void setSponsorUserId(String sponsorUserId) {
        this.sponsorUserId = sponsorUserId;
    }

    public String getSponsor() {
        return sponsor;
    }

    public void setSponsor(String sponsor) {
        this.sponsor = sponsor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public boolean isResendActivationEmail() {
        return resendActivationEmail;
    }

    public void setResendActivationEmail(boolean resendActivationEmail) {
        this.resendActivationEmail = resendActivationEmail;
    }

    public boolean isActivationLinkExpired() {
        return activationLinkExpired;
    }

    public void setActivationLinkExpired(boolean activationLinkExpired) {
        this.activationLinkExpired = activationLinkExpired;
    }

    public boolean isAlreadyActivated() {
        return alreadyActivated;
    }

    public void setAlreadyActivated(boolean alreadyActivated) {
        this.alreadyActivated = alreadyActivated;
    }

    public boolean isIPPemailSent() {
        return IPPemailSent;
    }

    public void setIPPemailSent(boolean iPPemailSent) {
        IPPemailSent = iPPemailSent;
    }

    public boolean isActivationRetry() {
        return activationRetry;
    }

    public void setActivationRetry(boolean activationRetry) {
        this.activationRetry = activationRetry;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<Object> getFilteredPOList() {
        return filteredPOList;
    }

    public void setFilteredPOList(List<Object> filteredPOList) {
        this.filteredPOList = filteredPOList;
    }

    public String getFullName() {
        if (firstName == null && lastName == null) {
            return "";
        } else {
            return firstName + " " + lastName;
        }
    }

    public String getLoaSought() {
        return loaSought;
    }

    public void setLoaSought(String loaSought) {
        this.loaSought = loaSought;
    }
    
    public long getLoaAchieved() {
        return loaAchieved;
    }

    public void setLoaAchieved(long loaAchieved) {
        this.loaAchieved = loaAchieved;
    }

    public boolean hasLevelSought(long loaSought) {
        return loaSought <= loaAchieved;
    }

    public long getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(long statusCode) {
        this.statusCode = statusCode;
    }

    public long getHighRiskAttemptId() {
        return highRiskAttemptId;
    }

    public void setHighRiskAttemptId(long highRiskAttemptId) {
        this.highRiskAttemptId = highRiskAttemptId;
    }

    public long getSecondaryAttemptId() {
        return secondaryAttemptId;
    }

    public void setSecondaryAttemptId(long secondaryAttemptId) {
        this.secondaryAttemptId = secondaryAttemptId;
    }

    public boolean isRedirectFromCustReg() {
        return redirectFromCustReg;
    }

    public void setRedirectFromCustReg(boolean redirectFromCustReg) {
        this.redirectFromCustReg = redirectFromCustReg;
    }
    
	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}
}
