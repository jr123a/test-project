package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchAddressSummaryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ValueCodeModel verificationResult;	           //Mandatory:Y, Max Length:8
	private ValueCodeModel type;		   //Mandatory:Y, Max Length:40
	private ValueCodeModel unitMismatchResult;		   //Mandatory:Y, Max Length:40
	private ValueCodeModel highRiskResult;
	private PreciseMatchAddressCountsModel counts;
	
	public ValueCodeModel getVerificationResult() {
		return verificationResult;
	}
	
	public void setVerificationResult(ValueCodeModel verificationResult) {
		this.verificationResult = verificationResult;
	}

	public ValueCodeModel getType() {
		return type;
	}

	public void setType(ValueCodeModel type) {
		this.type = type;
	}

	public ValueCodeModel getUnitMismatchResult() {
		return unitMismatchResult;
	}

	public void setUnitMismatchResult(ValueCodeModel unitMismatchResult) {
		this.unitMismatchResult = unitMismatchResult;
	}

	public ValueCodeModel getHighRiskResult() {
		return highRiskResult;
	}

	public void setHighRiskResult(ValueCodeModel highRiskResult) {
		this.highRiskResult = highRiskResult;
	}

	public PreciseMatchAddressCountsModel getCounts() {
		return counts;
	}

	public void setCounts(PreciseMatchAddressCountsModel counts) {
		this.counts = counts;
	}	
}
