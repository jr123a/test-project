package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseIDSummaryScoresReasonsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<ValueCodeModel> reason;	           //Mandatory:Y, Max Length:8

	public List<ValueCodeModel> getReason() {
		return reason;
	}

	public void setReason(List<ValueCodeModel> reason) {
		this.reason = reason;
	}
	
}
