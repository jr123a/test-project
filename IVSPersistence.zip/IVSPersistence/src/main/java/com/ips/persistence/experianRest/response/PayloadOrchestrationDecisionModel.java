package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PayloadOrchestrationDecisionModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String sequenceId;	           
	private String decisionSource;		   
	private String decision;		       
	private List<String> decisionReasons;  
	private long score;		               
	private String decisionText;		   
	private String nextAction;		       
	private String appReference;	       
	private String decisionTime;          
	
	public String getSequenceId() {
		return sequenceId;
	}
	
	public void setSequenceId(String sequenceId) {
		this.sequenceId = sequenceId;
	}

	public String getDecisionSource() {
		return decisionSource;
	}

	public void setDecisionSource(String decisionSource) {
		this.decisionSource = decisionSource;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public List<String> getDecisionReasons() {
		return decisionReasons;
	}

	public void setDecisionReasons(List<String> decisionReasons) {
		this.decisionReasons = decisionReasons;
	}

	public long getScore() {
		return score;
	}

	public void setScore(long score) {
		this.score = score;
	}

	public String getDecisionText() {
		return decisionText;
	}

	public void setDecisionText(String decisionText) {
		this.decisionText = decisionText;
	}

	public String getNextAction() {
		return nextAction;
	}

	public void setNextAction(String nextAction) {
		this.nextAction = nextAction;
	}

	public String getAppReference() {
		return appReference;
	}

	public void setAppReference(String appReference) {
		this.appReference = appReference;
	}

	public String getDecisionTime() {
		return decisionTime;
	}

	public void setDecisionTime(String decisionTime) {
		this.decisionTime = decisionTime;
	}	
	
}
