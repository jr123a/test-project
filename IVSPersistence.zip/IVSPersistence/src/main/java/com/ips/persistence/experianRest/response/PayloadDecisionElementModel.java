package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PayloadDecisionElementModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String serviceName;	           
	private String applicantId;		       
	private String decision;		       
	private int normalizedScore;		   
	private long score;		               
	private String decisionText;		   
	private String appReference;		  
	private List<DecisionElementRuleModel> rules; 
	private PayloadOtherDataModel otherData;
	private List<PayloadDecisionItemModel> decisions;

	//Excluded - for PreciseID Only (not needed in the evaluation)
	//private List<NameValueModel> matches;
	private List<PayloadDecisionScoreItemModel> scores;
	
	public String getServiceName() {
		return serviceName;
	}
	
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public int getNormalizedScore() {
		return normalizedScore;
	}

	public void setNormalizedScore(int normalizedScore) {
		this.normalizedScore = normalizedScore;
	}

	public long getScore() {
		return score;
	}

	public void setScore(long score) {
		this.score = score;
	}

	public String getDecisionText() {
		return decisionText;
	}

	public void setDecisionText(String decisionText) {
		this.decisionText = decisionText;
	}

	public String getAppReference() {
		return appReference;
	}

	public void setAppReference(String appReference) {
		this.appReference = appReference;
	}

	public List<DecisionElementRuleModel> getRules() {
		return rules;
	}

	public void setRules(List<DecisionElementRuleModel> rules) {
		this.rules = rules;
	}

	public PayloadOtherDataModel getOtherData() {
		return otherData;
	}

	public void setOtherData(PayloadOtherDataModel otherData) {
		this.otherData = otherData;
	}

	public List<PayloadDecisionItemModel> getDecisions() {
		return decisions;
	}

	public void setDecisions(List<PayloadDecisionItemModel> decisions) {
		this.decisions = decisions;
	}

	public List<PayloadDecisionScoreItemModel> getScores() {
		return scores;
	}

	public void setScores(List<PayloadDecisionScoreItemModel> scores) {
		this.scores = scores;
	}

}
