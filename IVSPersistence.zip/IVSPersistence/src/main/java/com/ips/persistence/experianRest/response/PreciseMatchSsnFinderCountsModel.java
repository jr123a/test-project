package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchSsnFinderCountsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int ssnfinderReturnCount;	           //Max Length:8

	public int getSsnfinderReturnCount() {
		return ssnfinderReturnCount;
	}

	public void setSsnfinderReturnCount(int ssnfinderReturnCount) {
		this.ssnfinderReturnCount = ssnfinderReturnCount;
	}
	
}
