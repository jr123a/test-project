package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class FraudSolutionsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private FraudSolutionsResponseModel response;	           //Mandatory:Y, Max Length:8

	public FraudSolutionsResponseModel getResponse() {
		return response;
	}

	public void setResponse(FraudSolutionsResponseModel response) {
		this.response = response;
	}
	
}
