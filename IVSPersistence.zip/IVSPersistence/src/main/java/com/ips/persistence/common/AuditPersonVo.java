package com.ips.persistence.common;
 
public class AuditPersonVo {
    
    private String personId;
    private String sponsorId;
    private String sponsorUserId;
    private String fullPersonName;
    private String emailAddress; 
    private String proofingStatus; 
    private String proofingLevel;
    private String proofingStatusDatetime;

	public String getPersonId() {
		return personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	public String getSponsorId() {
		return sponsorId;
	}

	public void setSponsorId(String sponsorId) {
		this.sponsorId = sponsorId;
	}

	public String getSponsorUserId() {
		return sponsorUserId;
	}

	public void setSponsorUserId(String sponsorUserId) {
		this.sponsorUserId = sponsorUserId;
	}

	public String getFullPersonName() {
		return fullPersonName;
	}

	public void setFullPersonName(String fullPersonName) {
		this.fullPersonName = fullPersonName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getProofingStatus() {
		return proofingStatus;
	}

	public void setProofingStatus(String proofingStatus) {
		this.proofingStatus = proofingStatus;
	}

	public String getProofingLevel() {
		return proofingLevel;
	}

	public void setProofingLevel(String proofingLevel) {
		this.proofingLevel = proofingLevel;
	}

	public String getProofingStatusDatetime() {
		return proofingStatusDatetime;
	}

	public void setProofingStatusDatetime(String proofingStatusDatetime) {
		this.proofingStatusDatetime = proofingStatusDatetime;
	}
}
