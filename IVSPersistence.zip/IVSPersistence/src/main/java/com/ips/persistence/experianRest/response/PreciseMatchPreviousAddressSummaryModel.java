package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchPreviousAddressSummaryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseMatchPreviousAddressCountsModel counts;	           //Max Length:8

	public PreciseMatchPreviousAddressCountsModel getCounts() {
		return counts;
	}

	public void setCounts(PreciseMatchPreviousAddressCountsModel counts) {
		this.counts = counts;
	}
	
}
