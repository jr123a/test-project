package com.ips.persistence.experianRest.request;

import java.io.Serializable;

public class ApplicationProductDetailModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String productType;	       //Mandatory:N, Max Length:40

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}
	
}
