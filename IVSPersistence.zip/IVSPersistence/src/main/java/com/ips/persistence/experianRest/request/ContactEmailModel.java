package com.ips.persistence.experianRest.request;

import java.io.Serializable;

public class ContactEmailModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String id;	        //Mandatory:N, Max Length:40
	private String type;	//Mandatory:N, Max Length:40
	private String email;	//Mandatory:N, Max Length:100
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
}
