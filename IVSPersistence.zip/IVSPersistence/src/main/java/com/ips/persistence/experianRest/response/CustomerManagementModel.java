package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class CustomerManagementModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String version;	           //Max Length:8
	private String reportDate;	           //Max Length:8
	private String reportTime;	           //Max Length:8
	private String transactionID;	           //Max Length:8
	private String clientTrackingID;	           //Max Length:8
	private String primaryResponseCode;	           //Max Length:8
	private String secondaryResponseCode;	           //Max Length:8
	private String responseCodeDesc;	           //Max Length:8
	private String referenceText;	           //Max Length:8
	private CustomerManagementScoreResultsModel scoreResults;	           //Max Length:8
	private CustomerManagementAttributesModel attributes;
	
	public String getVersion() {
		return version;
	}
	
	public void setVersion(String version) {
		this.version = version;
	}

	public String getReportDate() {
		return reportDate;
	}

	public String getReportTime() {
		return reportTime;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public String getClientTrackingID() {
		return clientTrackingID;
	}

	public String getPrimaryResponseCode() {
		return primaryResponseCode;
	}

	public String getSecondaryResponseCode() {
		return secondaryResponseCode;
	}

	public String getResponseCodeDesc() {
		return responseCodeDesc;
	}

	public String getReferenceText() {
		return referenceText;
	}

	public CustomerManagementScoreResultsModel getScoreResults() {
		return scoreResults;
	}

	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}

	public void setReportTime(String reportTime) {
		this.reportTime = reportTime;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public void setClientTrackingID(String clientTrackingID) {
		this.clientTrackingID = clientTrackingID;
	}

	public void setPrimaryResponseCode(String primaryResponseCode) {
		this.primaryResponseCode = primaryResponseCode;
	}

	public void setSecondaryResponseCode(String secondaryResponseCode) {
		this.secondaryResponseCode = secondaryResponseCode;
	}

	public void setResponseCodeDesc(String responseCodeDesc) {
		this.responseCodeDesc = responseCodeDesc;
	}

	public void setReferenceText(String referenceText) {
		this.referenceText = referenceText;
	}

	public void setScoreResults(CustomerManagementScoreResultsModel scoreResults) {
		this.scoreResults = scoreResults;
	}

	public CustomerManagementAttributesModel getAttributes() {
		return attributes;
	}

	public void setAttributes(CustomerManagementAttributesModel attributes) {
		this.attributes = attributes;
	}
	
}
