package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class FraudSolutionsResponseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private FraudSolutionsProductsModel products;	           

	public FraudSolutionsProductsModel getProducts() {
		return products;
	}

	public void setProducts(FraudSolutionsProductsModel products) {
		this.products = products;
	}
	
}
