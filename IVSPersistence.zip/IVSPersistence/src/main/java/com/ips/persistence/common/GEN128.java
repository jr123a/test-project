package com.ips.persistence.common;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;

import org.krysalis.barcode4j.impl.code128.Code128Bean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.output.bitmap.BitmapEncoder;
import org.krysalis.barcode4j.output.bitmap.BitmapEncoderRegistry;
import org.krysalis.barcode4j.tools.UnitConv;

import com.ips.common.common.CustomLogger;                                                                                                                                                                                                    
                                                                                                                                
public class GEN128 implements Serializable {  
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
                                                                                                                                
    private String inString      = null;
    private String inPath        = null;
    private String inSwitch      = null;
    private static GEN128 gen128 = null;                                                                             
                                                                                                                                
    public GEN128() {    // Constructor should be "private" to prevent                                                         
                          // use of "new", but for compatibility it is                                                          
                          // set as "public".  Use getInstance() instead.                                                       
    }                                                                                                                           
                                                                                                                                
                                                                                 
                                                                                                                                
    public static synchronized GEN128 getInstance() {                                                                          
        if (gen128 == null) {                                                                                                     
            gen128 =  new GEN128();                                                                                              
        }                                                                                                                       
        return gen128;                                                                                                            
    }                                                                                                                           
                                                                                                                                
    /**                                                                                                                         
     *  Sets the input string to be encoded, it should be 1 to 20 characters                                                                       
     *                                                                                                                          
     * @param  t  The input string                                                                                           
     * @return    Returns reference to the object so it can be used again                                                        
     */                                                                                                                         
    public GEN128 setinString(String t) {                                                                                         
        this.inString = (t == null) ? "" : t;                                                                                      
        return this;                                                                                                            
    }                                                                                                                           
                                                                                                                                
    /**                                                                                                                         
     *  Gets the attribute of the input string object                                                                          
     *                                                                                                                          
     * @return    The input string value                                                                                               
     */                                                                                                                         
    public String getinString() {                                                                                                  
        return this.inString;                                                                                                      
    }                                                                                                                           
                                                                                                                                
    /**                                                                                                                         
     *  Sets the path and file to be used for the output barcode jpeg                                                        
     *                                                                                                                          
     * @param  r  The path and file for ouput                                                  
     * @return    Returns refernce to the object so it can be used again                                                        
     */                                                                                                                         
    public GEN128 setinPath(String r) {                                                                                         
        this.inPath = (r == null) ? "" : r;                                                                                      
        return this;                                                                                                            
    }                                                                                                                           
                                                                                                                                
    /**                                                                                                                         
     *  Gets the attribute of the output path object                                                                         
     *                                                                                                                          
     * @return    The output path value                                                                                               
     */                                                                                                                         
    public String getinPath() {                                                                                                  
        return this.inPath;                                                                                                      
    }                                                                                                                           
          
    public GEN128 setinSwitch(String s) {                                                                                         
        this.inSwitch = (s == null) ? "" : s;                                                                                      
        return this;                                                                                                            
    }                                                                                                                           
                                                                                                                                
    /**                                                                                                                         
     *  Gets the attribute of the input switch object                                                                          
     *                                                                                                                          
     * @return    The input switch value                                                                                               
     */                                                                                                                         
    public String getinSwitch() {                                                                                                  
        return this.inSwitch;                                                                                                      
    }                                                          
    
    
    public String getBarCode() {
        return createBarCode128(this.inString, this.inPath, this.inSwitch);
    }
    
    
       
    private String createBarCode128(String inString, String inPath, String inSwitch) {
        try {

            if ("T".equals(inSwitch) || "A".equals(inSwitch)) {
                CustomLogger.debug(this.getClass(), "Logging inputString and inputPath");
                CustomLogger.debug(this.getClass(), inString);
                CustomLogger.debug(this.getClass(), inPath);
            } else {
                if ( !("N".equals(inSwitch)) ) {
                    return ("64.Third parameter not T or A or N");
                }
            }

            if (inString.length() < 1 || inString.length() > 20) {
                return ("08.Input string length is invalid");
            }

            for (int i = 0; i < inString.length(); i++) {
                char x;
                x = inString.charAt(i);
                int charValue = (int) x;

                if (charValue < 32 || charValue > 127) {
                    return ("16.Input string contains invalid character");
                }
            }

            File fTest = new File(inPath);
            if (!fTest.exists()) {
                if ("A".equals(inSwitch)) {
                    CustomLogger.debug(this.getClass(), "File does not exist but will be allocated");
                } else {
                    return ("32.Output file does not exist");
                }
            }

            Code128Bean bean = new Code128Bean();
            final int dpi = 160;

            // Configure the barcode generator
            bean.setModuleWidth(UnitConv.in2mm(2.8f / dpi));

            bean.doQuietZone(false);

            // Open output file
            File outputFile = new File(inPath);

            FileOutputStream out = new FileOutputStream(outputFile);

            BitmapCanvasProvider canvas = new BitmapCanvasProvider(dpi, BufferedImage.TYPE_BYTE_BINARY, false, 0);

            // Generate the narcode
            bean.generateBarcode(canvas, inString);

            // Signal end of generation
            canvas.finish();

            // Get generated bitmap
            BufferedImage image = canvas.getBufferedImage();

            int width = image.getWidth();
            int height = image.getHeight();

            // Add padding
            int padding = 15;
            width += 2 * padding;
            height += 2 * padding;

            BufferedImage bitmap = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_BINARY);
            Graphics2D graphics2d = (Graphics2D) bitmap.getGraphics();
            graphics2d.setBackground(Color.white);
            graphics2d.setColor(Color.black);
            graphics2d.clearRect(0, 0, bitmap.getWidth(), bitmap.getHeight());

            // Place the barcode symbol
            AffineTransform imagePlacement = new AffineTransform();
            imagePlacement.translate(padding, padding);
            graphics2d.drawRenderedImage(image, imagePlacement);

            // Encode bitmap as file
            String mime = "image/png";
            final BitmapEncoder bmEncoder = BitmapEncoderRegistry.getInstance(mime);
            bmEncoder.encode(bitmap, out, mime, dpi);

            out.close();

            if ("T".equals(inSwitch)) {
                CustomLogger.debug(this.getClass(), "Bar Code is generated successfully..");
            }
        }

        catch (IOException ex) {
            CustomLogger.error(this.getClass(), "IOException occurred when generating barcode image", ex);
        }
        return ("00.Bar Code is generated successfully...");
    }
}
            
            


                                                                                                                          
