package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class OtherDataJsonModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private FraudSolutionsModel fraudSolutions;	           //Mandatory:Y, Max Length:8

	public FraudSolutionsModel getFraudSolutions() {
		return fraudSolutions;
	}

	public void setFraudSolutions(FraudSolutionsModel fraudSolutions) {
		this.fraudSolutions = fraudSolutions;
	}
	
}
