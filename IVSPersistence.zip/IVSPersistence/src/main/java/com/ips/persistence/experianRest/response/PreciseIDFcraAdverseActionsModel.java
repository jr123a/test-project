package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseIDFcraAdverseActionsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<ValueCodeModel> adverseAction;	           //Max Length:8

	public List<ValueCodeModel> getAdverseAction() {
		return adverseAction;
	}

	public void setAdverseAction(List<ValueCodeModel> adverseAction) {
		this.adverseAction = adverseAction;
	}
	
}
