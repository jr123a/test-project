package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class CommonErrorResponseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<CommonErrorModel> errors;
	private boolean success;
	
	public List<CommonErrorModel> getErrors() {
		return errors;
	}
	
	public void setErrors(List<CommonErrorModel> errors) {
		this.errors = errors;
	}

	public boolean getSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

}
