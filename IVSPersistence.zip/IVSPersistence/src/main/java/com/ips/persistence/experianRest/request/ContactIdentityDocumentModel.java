package com.ips.persistence.experianRest.request;

import java.io.Serializable;

public class ContactIdentityDocumentModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String documentNumber;	      
	private String hashedDocumentNumber;	
	private String documentType;
	
	public String getDocumentNumber() {
		return documentNumber;
	}
	
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getHashedDocumentNumber() {
		return hashedDocumentNumber;
	}

	public void setHashedDocumentNumber(String hashedDocumentNumber) {
		this.hashedDocumentNumber = hashedDocumentNumber;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}	

}
