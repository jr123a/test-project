package com.ips.persistence.common;

import java.util.Date;

public class FacilityTransactionReportVo implements Comparable {

    private String env;
    private Date startDate;
    private Date endDate;
    
    private String area;
    private String district;
    private String facilityName;
    private long facilityId;
    private long refFacilityId;
    private long dayPassed = 0L;
    private long dayFailed = 0L;
    
    // Month Passed
    private long monthPassed = 0L;
    private long monthFailed = 0L;
    
    public FacilityTransactionReportVo() {
        //Added a nested comment to avoid throwing an UnsupportedOperationException.
    }
    
    public String getEnv() {
        return env;
    }
    public void setEnv(String env) {
        this.env = env;
    }
    
    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public void setDayPassed(long dayPassed) {
        this.dayPassed = dayPassed;
    }

    public void setDayFailed(long dayFailed) {
        this.dayFailed = dayFailed;
    }

    public void setMonthPassed(long monthPassed) {
        this.monthPassed = monthPassed;
    }

    public void setMonthFailed(long monthFailed) {
        this.monthFailed = monthFailed;
    }

    public String getArea() {
        return area == null ? "" : area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDistrict() {
        return district == null ? "" : district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getFacilityName() {
        return facilityName == null ? "" : facilityName;
    }

    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName;
    }

    public String getFacilityId() {
        return facilityId == 0L ? "" : String.valueOf(facilityId); 
    }

    public void setFacilityId(long facilityId) {
        this.facilityId = facilityId;
    }

    public long getRefFacilityId() {
        return refFacilityId;
    }

    public void setRefFacilityId(long refFacilityId) {
        this.refFacilityId = refFacilityId;
    }

    public long getDayTotalTransactions() {
        return getDayPassed() + getDayFailed();
    }
    
    public long getDayPassed() {
        return dayPassed;
    }
    
    public long getDayFailed() {
        return dayFailed;
    }
    
    public Long getDayPassRate() {
        return (long) Math.round((float) getDayPassed() / getDayTotalTransactions() * 100);
    }
    
    public Long getDayFailRate() {
        return (long) Math.round((float) getDayFailed() / getDayTotalTransactions() * 100);
    }
    
    public long getMonthTotalTransactions() {
        return getMonthPassed() + getMonthFailed();
    }
    
    public long getMonthPassed() {
        return monthPassed;
    }
    
    public long getMonthFailed() {
        return monthFailed;
    }
    
    public Long getMonthPassRate() {
        return (long) Math.round((float) getMonthPassed() / getMonthTotalTransactions() * 100);
    }
    
    public Long getMonthFailRate() {
        return (long) Math.round((float) getMonthFailed() / getMonthTotalTransactions() * 100);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        FacilityTransactionReportVo other = (FacilityTransactionReportVo) obj;
        return this.getFacilityId().equals(other.getFacilityId());
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;        
        result = prime * result + ((area == null) ? 0 : area.hashCode());
        result = prime * result + ((district == null) ? 0 : district.hashCode());
        result = prime * result + ((facilityName == null) ? 0 : facilityName.hashCode());
        result = prime * result + ((facilityId == 0) ? 0 : new Long(facilityId).hashCode());
        return result;
    }
    

    @Override
    public int compareTo(Object obj) {    
        FacilityTransactionReportVo other = (FacilityTransactionReportVo) obj;
        
        int i = this.getArea().compareTo(other.getArea());
        if (i != 0) return i;

        i = this.getDistrict().compareTo(other.getDistrict());
        if (i != 0) return i;
        
        return this.getFacilityName().compareTo(other.getFacilityName());
    }
}
