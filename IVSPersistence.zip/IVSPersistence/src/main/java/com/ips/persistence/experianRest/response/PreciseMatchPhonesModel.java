package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseMatchPhonesModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<PreciseMatchPhoneItemModel> phone;	           //Mandatory:Y, Max Length:8

	public List<PreciseMatchPhoneItemModel> getPhone() {
		return phone;
	}

	public void setPhone(List<PreciseMatchPhoneItemModel> phone) {
		this.phone = phone;
	}
	
}
