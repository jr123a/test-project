package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

import com.ips.persistence.experianRest.request.PayloadApplicationModel;
import com.ips.persistence.experianRest.request.PayloadContactModel;
import com.ips.persistence.experianRest.request.PayloadControlModel;

public class OriginalRequestDataModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<PayloadControlModel> control;	//Mandatory:N, Max Length:80
	private List<PayloadContactModel> contacts; 
	private PayloadApplicationModel application;
	
	public List<PayloadControlModel> getControl() {
		return control;
	}

	public void setControl(List<PayloadControlModel> control) {
		this.control = control;
	}

	public List<PayloadContactModel> getContacts() {
		return contacts;
	}

	public void setContacts(List<PayloadContactModel> contacts) {
		this.contacts = contacts;
	}

	public PayloadApplicationModel getApplication() {
		return application;
	}

	public void setApplication(PayloadApplicationModel application) {
		this.application = application;
	}
}
