package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseIDSummaryScoresModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String preciseIDScore;	           //Mandatory:Y, Max Length:8
	private String preciseIDScorecard;	           //Mandatory:Y, Max Length:8
	private String validationScore;	           //Mandatory:Y, Max Length:8
	private String verificationScore;	           //Mandatory:Y, Max Length:8
	private String complianceDescription;	           //Mandatory:Y, Max Length:8
	private PreciseIDSummaryScoresReasonsModel reasons;	           //Mandatory:Y, Max Length:8
	private String fpdscore;	
		
	public String getPreciseIDScore() {
		return preciseIDScore;
	}
	
	public void setPreciseIDScore(String preciseIDScore) {
		this.preciseIDScore = preciseIDScore;
	}

	public String getPreciseIDScorecard() {
		return preciseIDScorecard;
	}

	public void setPreciseIDScorecard(String preciseIDScorecard) {
		this.preciseIDScorecard = preciseIDScorecard;
	}

	public String getValidationScore() {
		return validationScore;
	}

	public void setValidationScore(String validationScore) {
		this.validationScore = validationScore;
	}

	public String getVerificationScore() {
		return verificationScore;
	}

	public void setVerificationScore(String verificationScore) {
		this.verificationScore = verificationScore;
	}

	public String getComplianceDescription() {
		return complianceDescription;
	}

	public void setComplianceDescription(String complianceDescription) {
		this.complianceDescription = complianceDescription;
	}

	public PreciseIDSummaryScoresReasonsModel getReasons() {
		return reasons;
	}

	public void setReasons(PreciseIDSummaryScoresReasonsModel reasons) {
		this.reasons = reasons;
	}

	public String getFpdscore() {
		return fpdscore;
	}

	public void setFpdscore(String fpdscore) {
		this.fpdscore = fpdscore;
	}

}
