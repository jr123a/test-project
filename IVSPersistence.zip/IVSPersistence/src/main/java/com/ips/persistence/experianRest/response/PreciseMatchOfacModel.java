package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchOfacModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseMatchOfacSummaryModel summary;	           //Max Length:8

	public PreciseMatchOfacSummaryModel getSummary() {
		return summary;
	}

	public void setSummary(PreciseMatchOfacSummaryModel summary) {
		this.summary = summary;
	}
	
}
