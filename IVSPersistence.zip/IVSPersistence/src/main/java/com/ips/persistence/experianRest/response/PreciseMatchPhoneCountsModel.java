package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchPhoneCountsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int residentialPhoneMatchCount;	           //Max Length:8
	private int residentialPhoneReturnCount;	           //Max Length:8
	private int highRiskPhoneReturnCount;	           //Max Length:8
	private int businessPhoneMatchCount;	           //Max Length:8
	private int businessPhoneReturnCount;	           //Max Length:8
	
	public int getResidentialPhoneMatchCount() {
		return residentialPhoneMatchCount;
	}

	public void setResidentialPhoneMatchCount(int residentialPhoneMatchCount) {
		this.residentialPhoneMatchCount = residentialPhoneMatchCount;
	}

	public int getResidentialPhoneReturnCount() {
		return residentialPhoneReturnCount;
	}
	
	public void setResidentialPhoneReturnCount(int residentialPhoneReturnCount) {
		this.residentialPhoneReturnCount = residentialPhoneReturnCount;
	}

	public int getHighRiskPhoneReturnCount() {
		return highRiskPhoneReturnCount;
	}

	public void setHighRiskPhoneReturnCount(int highRiskPhoneReturnCount) {
		this.highRiskPhoneReturnCount = highRiskPhoneReturnCount;
	}

	public int getBusinessPhoneMatchCount() {
		return businessPhoneMatchCount;
	}

	public void setBusinessPhoneMatchCount(int businessPhoneMatchCount) {
		this.businessPhoneMatchCount = businessPhoneMatchCount;
	}

	public int getBusinessPhoneReturnCount() {
		return businessPhoneReturnCount;
	}

	public void setBusinessPhoneReturnCount(int businessPhoneReturnCount) {
		this.businessPhoneReturnCount = businessPhoneReturnCount;
	}

}
