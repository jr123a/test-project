package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PayloadDecisionItemModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String element;	           //Mandatory:Y, Max Length:8
	private String value;		   //Mandatory:Y, Max Length:40
	private String reason;		   //Mandatory:Y, Max Length:40
	
	public String getElement() {
		return element;
	}
	
	public void setElement(String element) {
		this.element = element;
	}
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
		
}
