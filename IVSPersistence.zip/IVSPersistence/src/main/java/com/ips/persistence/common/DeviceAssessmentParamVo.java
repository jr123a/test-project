package com.ips.persistence.common;

import java.io.Serializable;
import java.util.List;

import com.ips.common.common.DeviceReviewStatusEnum;
import com.lexisnexis.ns.identity_proofing._1.RdpReasonCodeModel;

public class DeviceAssessmentParamVo implements Serializable {
	private static final long serialVersionUID = 1L;
    private DeviceReviewStatusEnum deviceReviewStatus;
    private long personId;
    private long proofingStatusCode;
    private long velocityTimerValue;
    private int deviceScore;
    private boolean highRiskAddress;
    private boolean webServiceCall;
    private boolean transactionStatusFailed;
    private boolean deviceProfilingDisabled;
    private String addressType;
    private String callingAppName;
    private String city;
    private String companyName;
    private String conversationId; 
    private String customerUniqueID;
    private String individualNotFound;
    private String ivsReferenceId;
    private String lexID;
    private String loaSought;
    private String mobilePhoneNumber;
    private String proofingStatus;
    private String reasonCode;
    private String responseMessage;
  	private String requestId;
    private String requestJson;
    private String responseJson;
    private String reviewStatus;
    private String reputationAssessment;
    private String riskRating;
  	private String sessionId;
  	private String sponsorUserId;
    private String state;
    private String streetAddress1;
    private String summaryRiskScore;
    private String transactionStatus;
    private String verified;
  	private String webSessionId;
    private String zipCode;
    private String remoteRequest;
    private RdpReasonCodeModel statusDecisionReason;

	class EmailRiskItem {
		private String itemName;
		private String itemStatus;
		private EmailRiskItemReason itemReason;
		
		public String getItemName() {
			return itemName;
		}
		
		public void setItemName(String itemName) {
			this.itemName = itemName;
		}
		
		public String getItemStatus() {
			return itemStatus;
		}
		
		public void setItemStatus(String itemStatus) {
			this.itemStatus = itemStatus;
		}

		public EmailRiskItemReason getItemReason() {
			return itemReason;
		}

		public void setItemReason(EmailRiskItemReason itemReason) {
			this.itemReason = itemReason;
		}

	}
	
	class EmailRiskItemReason {
		private String Code;
		private String Description;
		
		public String getCode() {
			return Code;
		}
		
		public void setCode(String code) {
			Code = code;
		}
		
		public String getDescription() {
			return Description;
		}
		
		public void setDescription(String description) {
			Description = description;
		}
	}
	
	class ParameterDetail {
		String name;
        List<String> valueList;
        
		public String getName() {
			return name;
		}
		
		public List<String> getValueList() {
			return valueList;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		public void setValueList(List<String> valueList) {
			this.valueList = valueList;
		}
	}
	
	public long getPersonId() {
		return personId;
	}
	
	public long getProofingStatusCode() {
		return proofingStatusCode;
	}
	
	public long getVelocityTimerValue() {
		return velocityTimerValue;
	}
	
	public int getDeviceScore() {
		return deviceScore;
	}

	public void setDeviceScore(int deviceScore) {
		this.deviceScore = deviceScore;
	}
	
	public String getCallingAppName() {
		return callingAppName;
	}
	
	public String getCity() {
		return city;
	}
	
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getConversationId() {
		return conversationId;
	}
	
	public String getCustomerUniqueID() {
		return customerUniqueID;
	}

	public String getMobilePhoneNumber() {
		return mobilePhoneNumber;
	}
	
	public String getProofingStatus() {
		return proofingStatus;
	}
	
	public String getResponseMessage() {
		return responseMessage;
	}
	
	public String getRequestId() {
		return requestId;
	}

	public String getSessionId() {
		return sessionId;
	}
	
	public String getSponsorUserId() {
		return sponsorUserId;
	}
	
	public String getState() {
		return state;
	}
	
	public String getStreetAddress1() {
		return streetAddress1;
	}
		
	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setVelocityTimerValue(long velocityTimerValue) {
        this.velocityTimerValue = velocityTimerValue;
    }

	public String getZipCode() {
		return zipCode;
	}

	public void setPersonId(long personId) {
		this.personId = personId;
	}
	
	public void setProofingStatusCode(long proofingStatusCode) {
		this.proofingStatusCode = proofingStatusCode;
	}

	public void setCallingAppName(String callingAppName) {
		this.callingAppName = callingAppName;
	}
	
	public void setCity(String city) {
		this.city = city;
	}

	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}
	
	public void setCustomerUniqueID(String customerUniqueID) {
		this.customerUniqueID = customerUniqueID;
	}
	
	public void setMobilePhoneNumber(String mobilePhoneNumber) {
		this.mobilePhoneNumber = mobilePhoneNumber;
	}
	
	public void setProofingStatus(String proofingStatus) {
		this.proofingStatus = proofingStatus;
	}
	
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	
	public String getRequestJson() {
		return requestJson;
	}

	public void setRequestJson(String requestJson) {
		this.requestJson = requestJson;
	}

	public String getResponseJson() {
		return responseJson;
	}

	public void setResponseJson(String responseJson) {
		this.responseJson = responseJson;
	}

	public String getReviewStatus() {
		return reviewStatus;
	}

	public void setReviewStatus(String reviewStatus) {
		this.reviewStatus = reviewStatus;
	}
	
	public String getReputationAssessment() {
		return reputationAssessment;
	}

	public void setReputationAssessment(String reputationAssessment) {
		this.reputationAssessment = reputationAssessment;
	}
	
	public String getRiskRating() {
		return riskRating;
	}

	public void setRiskRating(String riskRating) {
		this.riskRating = riskRating;
	}
	
	public String getSummaryRiskScore() {
		return summaryRiskScore;
	}

	public void setSummaryRiskScore(String summaryRiskScore) {
		this.summaryRiskScore = summaryRiskScore;
	}
	
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	public void setSponsorUserId(String sponsorUserId) {
		this.sponsorUserId = sponsorUserId;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	public void setStreetAddress1(String streetAddress1) {
		this.streetAddress1 = streetAddress1;
	}
	
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getIndividualNotFound() {
		return individualNotFound;
	}

	public void setIndividualNotFound(String individualNotFound) {
		this.individualNotFound = individualNotFound;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getVerified() {
		return verified;
	}

	public void setVerified(String verified) {
		this.verified = verified;
	}

	public String getWebSessionId() {
		return webSessionId;
	}

	public void setWebSessionId(String webSessionId) {
		this.webSessionId = webSessionId;
	}
	
	public String getLexID() {
		return lexID;
	}

	public void setLexID(String lexID) {
		this.lexID = lexID;
	}

	public DeviceReviewStatusEnum getDeviceReviewStatus() {
		return deviceReviewStatus;
	}

	public void setDeviceReviewStatus(DeviceReviewStatusEnum deviceReviewStatus) {
		this.deviceReviewStatus = deviceReviewStatus;
	}

	public boolean isWebServiceCall() {
		return webServiceCall;
	}

	public void setWebServiceCall(boolean webServiceCall) {
		this.webServiceCall = webServiceCall;
	}

	public boolean isTransactionStatusFailed() {
		return transactionStatusFailed;
	}

	public void setTransactionStatusFailed(boolean transactionStatusFailed) {
		this.transactionStatusFailed = transactionStatusFailed;
	}

	public boolean isHighRiskAddress() {
		return highRiskAddress;
	}

	public void setHighRiskAddress(boolean highRiskAddress) {
		this.highRiskAddress = highRiskAddress;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public RdpReasonCodeModel getStatusDecisionReason() {
		return statusDecisionReason;
	}

	public void setStatusDecisionReason(RdpReasonCodeModel statusDecisionReason) {
		this.statusDecisionReason = statusDecisionReason;
	}
	
	public String getIvsReferenceId() {
		return ivsReferenceId;
	}

	public void setIvsReferenceId(String ivsReferenceId) {
		this.ivsReferenceId = ivsReferenceId;
	}

	public boolean isDeviceProfilingDisabled() {
		return deviceProfilingDisabled;
	}

	public void setDeviceProfilingDisabled(boolean deviceProfilingDisabled) {
		this.deviceProfilingDisabled = deviceProfilingDisabled;
	}

	public String getRemoteRequest() {
		return remoteRequest;
	}

	public void setRemoteRequest(String remoteRequest) {
		this.remoteRequest = remoteRequest;
	}

	public String getLoaSought() {
		return loaSought;
	}

	public void setLoaSought(String loaSought) {
		this.loaSought = loaSought;
	}
}
