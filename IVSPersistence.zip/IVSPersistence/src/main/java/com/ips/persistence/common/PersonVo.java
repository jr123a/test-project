package com.ips.persistence.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.sql.Timestamp;
import java.util.List;

public class PersonVo implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private long id = 0L;
    private long sponsorId;
    private long appId;
    private long verificationId;
	private long statusCode = 0L;
	private String appName;
    private String sponsorUserId;
    private String sponsor;
    private String status;
    private String firstName = "";
    private String lastName = "";
    private String middleName;
    private String nameTitle;
    private String nameSuffix;
    private Date dob;
    private String phoneNumber;
    private String phoneType;
    private String phoneExtension;
    private String mobileAreaCode;
    private String mobileNumber;
    private String emailAddress;
    private String streetAddress1 = "";
    private String streetAddress2 = "";
    private String streetAddress3;
    private String city = "";
    private String zipCode = "";
    private String state = "";
    private String urbanizationCode;
    private String country;
    private String companyName;
    private String companyFEIN;
    private String ssn;
    private String kbaUid;
    private String equifaxDOB;
    private String equifaxPostalCode;
    private String phoneVerificationSupplierName;
    private String lastUpdateDate;
    private String proofingLevelSought;
    private String requestId;
    private String errorMessage;
    private String errorCode;
    private String callingMethod;
    private String callingAppName;
    private String callingAppUrl;
    private String passcode;
    private String transactionOriginAppName;
    private String deviceAssessmentStatus;
    private String trueIPAddress;
    private String webSessionID;
    private String profilingSessionID;
    private String smfaSessionId;
    private String smfaToken;
    private String smfaStatus;
    private String phoneVerificationDecision;
    private String eventFinalDecision;
    private String ditDecision;
    private String otpConfirmationStatus;
    private String phoneTrust;
    private String identityTrust;
    private String addressTrust;
    private String path;
    private String sessionId;
    private String transactionId;
    private String supplierEffectingLockout;
    private String otpExpiresMinutes;
    private String attemptType;
    private String smsUrl;
    private String targetUrl;
    private String redirectUrl;
    private String requestJson;
    private String responseJson;
    private String verifyPhoneRequestJson;
    private String sendPasscodeRequestJson;
    private String validatePasscodeRequestJson;
    private String verifyPhoneResponseJson;
    private String sendPasscodeResponseJson;
    private String validatePasscodeResponseJson;
    private String stubCaseKey;
    private String responseData;
    private String discoveryProductReasonCode;
    private String callingVelocityType;
    private Date termsConditionsAckDateTime;
    private long highRiskAttemptId = 0L;
    private long secondaryAttemptId = 0L;
    private long currentPhoneVerificationSupplierId = 0L;
    private long previousPhoneVerificationSupplierId;
    private long phoneVerificationAttemptCount;
    private long otpOrSmfaRequestAttemptCount;
    private int addressHash = 0;
    private boolean hasPreviousPhoneVerificationDecision;
    private boolean resetProofingStatus;
    private boolean lockoutStillInEffect;
    private boolean exceededPhoneLimit;
    private boolean exceededOtpOrSmfaLimit;
    private boolean passcodeExpired;
    private boolean submitAttemptsMismatched;
    private boolean transactionKeyHasExpired;
    private boolean renewAttemptsExceeded;
    private boolean passcodeSubmitExceeded;
    private boolean lexisNexisIndividualNotFound;
    private boolean experianCustomerNotOnFile;
    private boolean experianErrorResponse;
    private boolean failedEquifaxIDFSCall;
    private boolean failedEquifaxDITCall;
    private boolean failedLexisNexisRDPCall;
	private boolean failedExperianCrossCoreCall;
    private boolean otpSmsLandline;
    private boolean webServiceCall;
    private boolean deviceTypeMobile;
    private boolean renderErrorMessage;
    private boolean returnDebugData;
    private boolean hasError;
    private boolean alternateSupplierForCustNotOnFile;
    private boolean alternateSupplierForErrorResponse;
    private boolean checkHighRiskAddress;
    private boolean highRiskActivated;
    private boolean highRiskAddress;
    private Timestamp lockoutExpiresDatetime;
	List<String> infoMessageList = new ArrayList<>();
	List<String> webServiceRequestList = new ArrayList<>();
	List<String> webServiceResponseList = new ArrayList<>();

    public String otpToString() {
        return "PersonVo [id=" + id + ", sponsorUserId=" + sponsorUserId + ", sponsor=" + sponsor + ", firstName="
                + firstName + ", lastName=" + lastName + ", middleName=" + middleName + ", mobileNumber="
                + mobileNumber + ", streetAddress1=" + streetAddress1 + ", streetAddress2=" + streetAddress2
                + ", streetAddress3=" + streetAddress3 + ", city=" + city + ", zipCode=" + zipCode + ", state=" + state
                + ", equifaxPostalCode=" + equifaxPostalCode + "]";
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    
    public long getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }

    public long getAppId() {
		return appId;
	}

	public void setAppId(long appId) {
		this.appId = appId;
	}

	public String getSponsorUserId() {
        return sponsorUserId;
    }

    public void setSponsorUserId(String sponsorUserId) {
        this.sponsorUserId = sponsorUserId;
    }

    public String getSponsor() {
        return sponsor;
    }

    public void setSponsor(String sponsor) {
        this.sponsor = sponsor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getNameTitle() {
        return nameTitle;
    }

    public void setNameTitle(String nameTitle) {
        this.nameTitle = nameTitle;
    }

    public String getNameSuffix() {
        return nameSuffix;
    }

    public void setNameSuffix(String nameSuffix) {
        this.nameSuffix = nameSuffix;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getMobileAreaCode() {
		return mobileAreaCode;
	}

	public void setMobileAreaCode(String mobileAreaCode) {
		this.mobileAreaCode = mobileAreaCode;
	}

	public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public String getPhoneExtension() {
        return phoneExtension;
    }

    public void setPhoneExtension(String phoneExtension) {
        this.phoneExtension = phoneExtension;
    }

    /**
     * @return the mobile_number
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * @param mobile_number the mobile_number to set
     */
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getAddressLine1() {
        if (streetAddress1 == null) {
            streetAddress1 = "";
        }
        
        return streetAddress1;
    }

    public void setAddressLine1(String streetAddress1) {
        this.streetAddress1 = streetAddress1;
    }

    public String getAddressLine2() {
        if (streetAddress2 == null) {
            streetAddress2 = "";
        }
        
        return streetAddress2;
    }

    public void setAddressLine2(String streetAddress2) {
        this.streetAddress2 = streetAddress2;
    }

    public String getAddressLine3() {
        return streetAddress3;
    }

    public void setAddressLine3(String streetAddress3) {
        this.streetAddress3 = streetAddress3;
    }

    public String getCity() {
        if (city == null) {
            city = "";
        }
        
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        if (zipCode == null) {
            zipCode = "";
        }
        
        return zipCode;
    }

    public void setPostalCode(String zipCode) {
        this.zipCode = zipCode;
    }
    
    /**
     * Convenience method to only return the zip5 portion of the zip
     * @return
     */
    public String getZip5() {
        if (this.zipCode != null && this.zipCode.length() >= 5) {
            return zipCode.substring(0, 5);
        }
        else {
            return "";
        }
    }

    public String getStateProvince() {
        if (state == null) {
            state = "";
        }
        
        return state;
    }

    public void setStateProvince(String state) {
        this.state = state;
    }

    public String getUrbanizationCode() {
		return urbanizationCode;
	}

	public void setUrbanizationCode(String urbanizationCode) {
		this.urbanizationCode = urbanizationCode;
	}

	public String getEquifaxDOB() {
        return equifaxDOB;
    }

    public void setEquifaxDOB(String equifaxDOB) {
        this.equifaxDOB = equifaxDOB;
    }

    public String getEquifaxPostalCode() {
        return equifaxPostalCode;
    }

    public void setEquifaxPostalCode(String equifaxPostalCode) {
        this.equifaxPostalCode = equifaxPostalCode;
    }

	public String getPhoneVerificationSupplierName() {
		return phoneVerificationSupplierName;
	}

	public void setPhoneVerificationSupplierName(String phoneVerificationSupplierName) {
		this.phoneVerificationSupplierName = phoneVerificationSupplierName;
	}

	public String getKbaUid() {
        return kbaUid;
    }

    public void setKbaUid(String kbaUid) {
        this.kbaUid = kbaUid;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getProofingLevelSought() {
        return proofingLevelSought;
    }

    public void setProofingLevelSought(String proofingLevelSought) {
        this.proofingLevelSought = proofingLevelSought;
    }
    
    public boolean isProofingLevelRequiresSsn() {
        return this.proofingLevelSought != null &&
                !this.proofingLevelSought.equals(IPSConstants.LOA_15);
    }
    
    public boolean isLoa15() {
        return this.proofingLevelSought.equals(IPSConstants.LOA_15);
    }
    
    public boolean hasNoSsn() {
        return this.ssn == null || this.ssn.length() == 0;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }
    
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
    public boolean isProofingLevelRequiresTermsConditionsAcknowledgement() {
        return this.proofingLevelSought != null &&
                !this.proofingLevelSought.equals(IPSConstants.LOA_15);
    }

    public Date getTermsConditionsAckDateTime() {
        return termsConditionsAckDateTime;
    }

    public void setTermsConditionsAckDateTime(Date termsConditionsAckDateTime) {
        this.termsConditionsAckDateTime = termsConditionsAckDateTime;
    }
    
    public String remoteToString() {
        return (this.getSponsorUserId() 
                + "\n" + this.getSponsor() 
                + "\n" + this.getFirstName()
                + "\n" + this.getLastName() 
                + "\n" + this.getAddressLine1() 
                + "\n" + this.getAddressLine2() 
                + "\n" + this.getCity() 
                + "\n" + this.getStateProvince()
                + "\n" + this.getPostalCode() 
                + "\n" + this.getDob()
                + "\n" + this.getEquifaxDOB()
                + "\n" + this.getProofingLevelSought()
                + "\n" + this.getTermsConditionsAckDateTime());
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getPasscode() {
        return passcode;
    }

    public void setPasscode(String passcode) {
        this.passcode = passcode;
    }

    public String getCallingMethod() {
        return callingMethod;
    }

    public void setCallingMethod(String callingMethod) {
        this.callingMethod = callingMethod;
    }


    public long getHighRiskAttemptId() {
        return highRiskAttemptId;
    }

    public void setHighRiskAttemptId(long highRiskAttemptId) {
        this.highRiskAttemptId = highRiskAttemptId;
    }

    public long getSecondaryAttemptId() {
        return secondaryAttemptId;
    }

    public void setSecondaryAttemptId(long secondaryAttemptId) {
        this.secondaryAttemptId = secondaryAttemptId;
    }

    public String getTransactionOriginAppName() {
        return transactionOriginAppName;
    }
    
    public void setTransactionOriginAppName(String transactionOriginAppName) {
        this.transactionOriginAppName = transactionOriginAppName;
    }

    public String getDeviceAssessmentStatus() {
        return deviceAssessmentStatus;
    }

    public void setDeviceAssessmentStatus(String deviceAssessmentStatus) {
        this.deviceAssessmentStatus = deviceAssessmentStatus;
    }

    public long getCurrentPhoneVerificationSupplierId() {
		return currentPhoneVerificationSupplierId;
	}

	public void setCurrentPhoneVerificationSupplierId(long currentPhoneVerificationSupplierId) {
		this.currentPhoneVerificationSupplierId = currentPhoneVerificationSupplierId;
	}

	public long getPreviousPhoneVerificationSupplierId() {
        return previousPhoneVerificationSupplierId;
    }

    public void setPreviousPhoneVerificationSupplierId(long previousPhoneVerificationSupplierId) {
        this.previousPhoneVerificationSupplierId = previousPhoneVerificationSupplierId;
    }

    public boolean hasPreviousPhoneVerificationDecision() {
        return hasPreviousPhoneVerificationDecision;
    }

    public void setHasPreviousPhoneVerificationDecision(boolean hasPreviousPhoneVerificationDecision) {
        this.hasPreviousPhoneVerificationDecision = hasPreviousPhoneVerificationDecision;
    }

    public boolean isResetProofingStatus() {
        return resetProofingStatus;
    }

    public void setResetProofingStatus(boolean resetProofingStatus) {
        this.resetProofingStatus = resetProofingStatus;
    }

    public boolean isLockoutStillInEffect() {
		return lockoutStillInEffect;
	}

	public void setLockoutStillInEffect(boolean lockoutStillInEffect) {
		this.lockoutStillInEffect = lockoutStillInEffect;
	}
	
	public String getWebSessionID() {
		return webSessionID;
	}

	public void setWebSessionID(String webSessionID) {
		this.webSessionID = webSessionID;
	}

	public String getProfilingSessionID() {
		return profilingSessionID;
	}

	public void setProfilingSessionID(String profilingSessionID) {
		this.profilingSessionID = profilingSessionID;
	}

	public boolean isFailedEquifaxIDFSCall() {
		return failedEquifaxIDFSCall;
	}

	public void setFailedEquifaxIDFSCall(boolean failedEquifaxIDFSCall) {
		this.failedEquifaxIDFSCall = failedEquifaxIDFSCall;
	}

	public boolean isFailedEquifaxDITCall() {
		return failedEquifaxDITCall;
	}

	public void setFailedEquifaxDITCall(boolean failedEquifaxDITCall) {
		this.failedEquifaxDITCall = failedEquifaxDITCall;
	}

	public boolean isFailedLexisNexisRDPCall() {
		return failedLexisNexisRDPCall;
	}

	public void setFailedLexisNexisRDPCall(boolean failedLexisNexisRDPCall) {
		this.failedLexisNexisRDPCall = failedLexisNexisRDPCall;
	}

	public boolean isFailedExperianCrossCoreCall() {
		return failedExperianCrossCoreCall;
	}

	public void setFailedExperianCrossCoreCall(boolean failedExperianCrossCoreCall) {
		this.failedExperianCrossCoreCall = failedExperianCrossCoreCall;
	}

	public String getSmfaSessionId() {
		return smfaSessionId;
	}

	public void setSmfaSessionId(String smfaSessionId) {
		this.smfaSessionId = smfaSessionId;
	}

	public String getSmfaToken() {
		return smfaToken;
	}

	public void setSmfaToken(String smfaToken) {
		this.smfaToken = smfaToken;
	}

	public String getSmfaStatus() {
		return smfaStatus;
	}

	public void setSmfaStatus(String smfaStatus) {
		this.smfaStatus = smfaStatus;
	}

	public String getPhoneVerificationDecision() {
		return phoneVerificationDecision;
	}

	public void setPhoneVerificationDecision(String phoneVerificationDecision) {
		this.phoneVerificationDecision = phoneVerificationDecision;
	}

	public String getEventFinalDecision() {
		return eventFinalDecision;
	}

	public void setEventFinalDecision(String eventFinalDecision) {
		this.eventFinalDecision = eventFinalDecision;
	}
	
	public String getDitDecision() {
		return ditDecision;
	}

	public void setDitDecision(String ditDecision) {
		this.ditDecision = ditDecision;
	}

	public String getOtpConfirmationStatus() {
		return otpConfirmationStatus;
	}

	public void setOtpConfirmationStatus(String otpConfirmationStatus) {
		this.otpConfirmationStatus = otpConfirmationStatus;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public long getPhoneVerificationAttemptCount() {
		return phoneVerificationAttemptCount;
	}

	public void setPhoneVerificationAttemptCount(long phoneVerificationAttemptCount) {
		this.phoneVerificationAttemptCount = phoneVerificationAttemptCount;
	}

	public long getOtpOrSmfaRequestAttemptCount() {
		return otpOrSmfaRequestAttemptCount;
	}

	public void setOtpOrSmfaRequestAttemptCount(long otpOrSmfaRequestAttemptCount) {
		this.otpOrSmfaRequestAttemptCount = otpOrSmfaRequestAttemptCount;
	}

	public boolean isWebServiceCall() {
		return webServiceCall;
	}

	public void setWebServiceCall(boolean webServiceCall) {
		this.webServiceCall = webServiceCall;
	}
	
	public boolean isDeviceTypeMobile() {
		return deviceTypeMobile;
	}

	public void setDeviceTypeMobile(boolean deviceTypeMobile) {
		this.deviceTypeMobile = deviceTypeMobile;
	}

	public boolean isRenderErrorMessage() {
		return renderErrorMessage;
	}

	public void setRenderErrorMessage(boolean renderErrorMessage) {
		this.renderErrorMessage = renderErrorMessage;
	}

	public String getPhoneTrust() {
		return phoneTrust;
	}

	public void setPhoneTrust(String phoneTrust) {
		this.phoneTrust = phoneTrust;
	}

	public String getIdentityTrust() {
		return identityTrust;
	}

	public void setIdentityTrust(String identityTrust) {
		this.identityTrust = identityTrust;
	}

	public String getAddressTrust() {
		return addressTrust;
	}

	public void setAddressTrust(String addressTrust) {
		this.addressTrust = addressTrust;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	public String getSupplierEffectingLockout() {
		return supplierEffectingLockout;
	}

	public void setSupplierEffectingLockout(String supplierEffectingLockout) {
		this.supplierEffectingLockout = supplierEffectingLockout;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
	public boolean isExceededPhoneLimit() {
		return exceededPhoneLimit;
	}

	public void setExceededPhoneLimit(boolean exceededPhoneLimit) {
		this.exceededPhoneLimit = exceededPhoneLimit;
	}

	public Timestamp getLockoutExpiresDatetime() {
		return lockoutExpiresDatetime;
	}

	public void setLockoutExpiresDatetime(Timestamp lockoutExpiresDatetime) {
		this.lockoutExpiresDatetime = lockoutExpiresDatetime;
	}

	public boolean isExceededOtpOrSmfaLimit() {
		return exceededOtpOrSmfaLimit;
	}

	public void setExceededOtpOrSmfaLimit(boolean exceededOtpOrSmfaLimit) {
		this.exceededOtpOrSmfaLimit = exceededOtpOrSmfaLimit;
	}

	public String getOtpExpiresMinutes() {
		return otpExpiresMinutes;
	}

	public void setOtpExpiresMinutes(String otpExpiresMinutes) {
		this.otpExpiresMinutes = otpExpiresMinutes;
	}

	public String getAttemptType() {
		return attemptType;
	}

	public void setAttemptType(String attemptType) {
		this.attemptType = attemptType;
	}

	public String getSmsUrl() {
		return smsUrl;
	}

	public void setSmsUrl(String smsUrl) {
		this.smsUrl = smsUrl;
	}

	public String getTargetUrl() {
		return targetUrl;
	}

	public void setTargetUrl(String targetUrl) {
		this.targetUrl = targetUrl;
	}

	public String getRedirectUrl() {
		return redirectUrl;
	}

	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

	public boolean isPasscodeExpired() {
		return passcodeExpired;
	}

	public void setPasscodeExpired(boolean passcodeExpired) {
		this.passcodeExpired = passcodeExpired;
	}

	public boolean isPasscodeSubmitExceeded() {
		return passcodeSubmitExceeded;
	}

	public void setPasscodeSubmitExceeded(boolean passcodeSubmitExceeded) {
		this.passcodeSubmitExceeded = passcodeSubmitExceeded;
	}

	public boolean isLexisNexisIndividualNotFound() {
		return lexisNexisIndividualNotFound;
	}

	public void setLexisNexisIndividualNotFound(boolean lexisNexisIndividualNotFound) {
		this.lexisNexisIndividualNotFound = lexisNexisIndividualNotFound;
	}

	public boolean isExperianCustomerNotOnFile() {
		return experianCustomerNotOnFile;
	}

	public void setExperianCustomerNotOnFile(boolean experianCustomerNotOnFile) {
		this.experianCustomerNotOnFile = experianCustomerNotOnFile;
	}
	
	public boolean isExperianErrorResponse() {
		return experianErrorResponse;
	}

	public void setExperianErrorResponse(boolean experianErrorResponse) {
		this.experianErrorResponse = experianErrorResponse;
	}
	
	public boolean isOtpSmsLandline() {
		return otpSmsLandline;
	}
	
	public List<String> getInfoMessageList() {
		return infoMessageList;
	}

	public void setOtpSmsLandline(boolean otpSmsLandline) {
		this.otpSmsLandline = otpSmsLandline;
	}

	public String getErrorCode() {
		return errorCode;
	}
	
	public void setInfoMessageList(List<String> infoMessageList) {
		this.infoMessageList = infoMessageList;
	}
	
	public void addInfoMessageList(String value) {
		infoMessageList.add(value);
	}

	public void addWebServiceRequestList(String value) {
		webServiceRequestList.add(value);
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getStubCaseKey() {
		return stubCaseKey;
	}

	public void setStubCaseKey(String stubCaseKey) {
		this.stubCaseKey = stubCaseKey;
	}

	public String getResponseData() {
		return responseData;
	}

	public void setResponseData(String responseData) {
		this.responseData = responseData;
	}
	
	public List<String> getWebServiceRequestList() {
		return webServiceRequestList;
	}

	public void setWebServiceRequestList(List<String> webServiceRequestList) {
		this.webServiceRequestList = webServiceRequestList;
	}

	public void addWebServiceResponseList(String value) {
		webServiceResponseList.add(value);
	}
	
	public List<String> getWebServiceResponseList() {
		return webServiceResponseList;
	}

	public void setWebServiceResponseList(List<String> webServiceResponseList) {
		this.webServiceResponseList = webServiceResponseList;
	}

	public boolean isReturnDebugData() {
		return returnDebugData;
	}

	public void setReturnDebugData(boolean returnDebugData) {
		this.returnDebugData = returnDebugData;
	}

	public boolean hasError() {
		return this.hasError;
	}

	public void setHasError(boolean hasError) {
		this.hasError = hasError;
	}

	public boolean isAlternateSupplierForCustNotOnFile() {
		return alternateSupplierForCustNotOnFile;
	}

	public void setAlternateSupplierForCustNotOnFile(boolean alternateSupplierForCustNotOnFile) {
		this.alternateSupplierForCustNotOnFile = alternateSupplierForCustNotOnFile;
	}

	public boolean isAlternateSupplierForErrorResponse() {
		return alternateSupplierForErrorResponse;
	}

	public void setAlternateSupplierForErrorResponse(boolean alternateSupplierForErrorResponse) {
		this.alternateSupplierForErrorResponse = alternateSupplierForErrorResponse;
	}
	
	public String getDiscoveryProductReasonCode() {
		return discoveryProductReasonCode;
	}

	public void setDiscoveryProductReasonCode(String discoveryProductReasonCode) {
		this.discoveryProductReasonCode = discoveryProductReasonCode;
	}

	public long getVerificationId() {
		return verificationId;
	}

	public void setVerificationId(long verificationId) {
		this.verificationId = verificationId;
	}

    public long getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(long statusCode) {
		this.statusCode = statusCode;
	}

	public int getAddressHash() {
		return addressHash;
	}

	public void setAddressHash(int addressHash) {
		this.addressHash = addressHash;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getResponseJson() {
		return responseJson;
	}

	public void setResponseJson(String responseJson) {
		this.responseJson = responseJson;
	}

	public String getRequestJson() {
		return requestJson;
	}

	public void setRequestJson(String requestJson) {
		this.requestJson = requestJson;
	}

	public String getCallingAppUrl() {
		return callingAppUrl;
	}

	public void setCallingAppUrl(String callingAppUrl) {
		this.callingAppUrl = callingAppUrl;
	}

	public String getCallingAppName() {
		return callingAppName;
	}

	public void setCallingAppName(String callingAppName) {
		this.callingAppName = callingAppName;
	}

	public String getVerifyPhoneRequestJson() {
		return verifyPhoneRequestJson;
	}

	public void setVerifyPhoneRequestJson(String verifyPhoneRequestJson) {
		this.verifyPhoneRequestJson = verifyPhoneRequestJson;
	}

	public String getSendPasscodeRequestJson() {
		return sendPasscodeRequestJson;
	}

	public void setSendPasscodeRequestJson(String sendPasscodeRequestJson) {
		this.sendPasscodeRequestJson = sendPasscodeRequestJson;
	}

	public String getValidatePasscodeRequestJson() {
		return validatePasscodeRequestJson;
	}

	public void setValidatePasscodeRequestJson(String validatePasscodeRequestJson) {
		this.validatePasscodeRequestJson = validatePasscodeRequestJson;
	}

	public String getVerifyPhoneResponseJson() {
		return verifyPhoneResponseJson;
	}

	public void setVerifyPhoneResponseJson(String verifyPhoneResponseJson) {
		this.verifyPhoneResponseJson = verifyPhoneResponseJson;
	}

	public String getSendPasscodeResponseJson() {
		return sendPasscodeResponseJson;
	}

	public void setSendPasscodeResponseJson(String sendPasscodeResponseJson) {
		this.sendPasscodeResponseJson = sendPasscodeResponseJson;
	}

	public String getValidatePasscodeResponseJson() {
		return validatePasscodeResponseJson;
	}

	public void setValidatePasscodeResponseJson(String validatePasscodeResponseJson) {
		this.validatePasscodeResponseJson = validatePasscodeResponseJson;
	}

	public String getCallingVelocityType() {
		return callingVelocityType;
	}

	public void setCallingVelocityType(String callingVelocityType) {
		this.callingVelocityType = callingVelocityType;
	}

	public boolean isSubmitAttemptsMismatched() {
		return submitAttemptsMismatched;
	}

	public void setSubmitAttemptsMismatched(boolean submitAttemptsMismatched) {
		this.submitAttemptsMismatched = submitAttemptsMismatched;
	}

	public boolean isTransactionKeyHasExpired() {
		return transactionKeyHasExpired;
	}

	public boolean isRenewAttemptsExceeded() {
		return renewAttemptsExceeded;
	}

	public void setTransactionKeyHasExpired(boolean transactionKeyHasExpired) {
		this.transactionKeyHasExpired = transactionKeyHasExpired;
	}

	public void setRenewAttemptsExceeded(boolean renewAttemptsExceeded) {
		this.renewAttemptsExceeded = renewAttemptsExceeded;
	}

	public boolean isHighRiskActivated() {
		return highRiskActivated;
	}

	public void setHighRiskActivated(boolean highRiskActivated) {
		this.highRiskActivated = highRiskActivated;
	}

	public boolean isHighRiskAddress() {
		return highRiskAddress;
	}

	public void setHighRiskAddress(boolean highRiskAddress) {
		this.highRiskAddress = highRiskAddress;
	}

	public boolean isCheckHighRiskAddress() {
		return checkHighRiskAddress;
	}

	public void setCheckHighRiskAddress(boolean checkHighRiskAddress) {
		this.checkHighRiskAddress = checkHighRiskAddress;
	}

	public String getTrueIPAddress() {
		return trueIPAddress;
	}

	public void setTrueIPAddress(String trueIPAddress) {
		this.trueIPAddress = trueIPAddress;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyFEIN() {
		return companyFEIN;
	}

	public void setCompanyFEIN(String companyFEIN) {
		this.companyFEIN = companyFEIN;
	}
}
