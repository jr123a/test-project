package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchConsumerIDSummaryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ValueCodeModel verificationResult;	           //Max Length:8
	private ValueCodeModel deceasedResult;	           //Max Length:8
	private ValueCodeModel formatResult;	           //Max Length:8
	private ValueCodeModel issueResult;	           //Max Length:8
	private int counts;	           //Max Length:8
	
	public ValueCodeModel getVerificationResult() {
		return verificationResult;
	}
	
	public void setVerificationResult(ValueCodeModel verificationResult) {
		this.verificationResult = verificationResult;
	}

	public ValueCodeModel getDeceasedResult() {
		return deceasedResult;
	}

	public void setDeceasedResult(ValueCodeModel deceasedResult) {
		this.deceasedResult = deceasedResult;
	}

	public ValueCodeModel getFormatResult() {
		return formatResult;
	}

	public void setFormatResult(ValueCodeModel formatResult) {
		this.formatResult = formatResult;
	}

	public ValueCodeModel getIssueResult() {
		return issueResult;
	}

	public void setIssueResult(ValueCodeModel issueResult) {
		this.issueResult = issueResult;
	}

	public int getCounts() {
		return counts;
	}

	public void setCounts(int counts) {
		this.counts = counts;
	}
		
}
