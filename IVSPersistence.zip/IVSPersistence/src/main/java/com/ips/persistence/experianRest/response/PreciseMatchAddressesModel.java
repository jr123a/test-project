package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseMatchAddressesModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<PreciseMatchAddressItemModel> address;	           //Mandatory:Y, Max Length:8

	public List<PreciseMatchAddressItemModel> getAddress() {
		return address;
	}

	public void setAddress(List<PreciseMatchAddressItemModel> address) {
		this.address = address;
	}
	
}
