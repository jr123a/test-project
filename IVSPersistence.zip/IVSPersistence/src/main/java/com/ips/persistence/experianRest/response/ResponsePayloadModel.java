package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class ResponsePayloadModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<PayloadOrchestrationDecisionModel> orchestrationDecisions;	
	private List<PayloadDecisionElementModel> decisionElements;				
	
	public List<PayloadOrchestrationDecisionModel> getOrchestrationDecisions() {
		return orchestrationDecisions;
	}
	
	public void setOrchestrationDecisions(List<PayloadOrchestrationDecisionModel> orchestrationDecisions) {
		this.orchestrationDecisions = orchestrationDecisions;
	}

	public List<PayloadDecisionElementModel> getDecisionElements() {
		return decisionElements;
	}

	public void setDecisionElements(List<PayloadDecisionElementModel> decisionElements) {
		this.decisionElements = decisionElements;
	} 
	
}
