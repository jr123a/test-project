package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchPreviousAddressCountsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int previousAddressReturnCount;	           //Max Length:8

	public int getPreviousAddressReturnCount() {
		return previousAddressReturnCount;
	}

	public void setPreviousAddressReturnCount(int previousAddressReturnCount) {
		this.previousAddressReturnCount = previousAddressReturnCount;
	}
	
}
