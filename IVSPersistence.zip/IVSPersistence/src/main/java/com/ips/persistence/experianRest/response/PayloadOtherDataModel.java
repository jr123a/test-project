package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PayloadOtherDataModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private OtherDataJsonModel json;	          
	private PayloadOtherDataResponseModel response;
	private String evUrl;

	public OtherDataJsonModel getJson() {
		return json;
	}

	public void setJson(OtherDataJsonModel json) {
		this.json = json;
	}

	public PayloadOtherDataResponseModel getResponse() {
		return response;
	}

	public void setResponse(PayloadOtherDataResponseModel response) {
		this.response = response;
	}

	public String getEvUrl() {
		return evUrl;
	}

	public void setEvUrl(String evUrl) {
		this.evUrl = evUrl;
	}
	
}
