package com.ips.persistence.experianRest.request;

import java.io.Serializable;

public class PersonNameModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String id;	        //Mandatory:N, Max Length:40
	private String firstName;	//Mandatory:N, Max Length:40
	private String middleNames;	//Mandatory:N, Max Length:100
	private String surName;		//Mandatory:N, Max Length:40
	private String nameSuffix;	//Mandatory:N, Max Length:20
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleNames() {
		return middleNames;
	}

	public void setMiddleNames(String middleNames) {
		this.middleNames = middleNames;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public String getNameSuffix() {
		return nameSuffix;
	}

	public void setNameSuffix(String nameSuffix) {
		this.nameSuffix = nameSuffix;
	}
	
	
	
}
