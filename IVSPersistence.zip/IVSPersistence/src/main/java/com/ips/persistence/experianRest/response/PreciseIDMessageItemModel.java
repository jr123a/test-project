package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseIDMessageItemModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String number;	           //Mandatory:Y, Max Length:8
	private String text;		   //Mandatory:Y, Max Length:40
	private String addrMismatch;		   //Mandatory:Y, Max Length:40
	
	public String getNumber() {
		return number;
	}
	
	public void setNumber(String number) {
		this.number = number;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getAddrMismatch() {
		return addrMismatch;
	}

	public void setAddrMismatch(String addrMismatch) {
		this.addrMismatch = addrMismatch;
	}
	
}
