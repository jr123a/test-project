package com.ips.persistence.experianRest.request;

import java.io.Serializable;

public class HeaderOptionModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String version;		   
	private String customOption1;  
	
	public String getVersion() {
		return version;
	}
	
	public void setVersion(String version) {
		this.version = version;
	}
	
	public String getCustomOption1() {
		return customOption1;
	}
	
	public void setCustomOption1(String customOption1) {
		this.customOption1 = customOption1;
	}

}
