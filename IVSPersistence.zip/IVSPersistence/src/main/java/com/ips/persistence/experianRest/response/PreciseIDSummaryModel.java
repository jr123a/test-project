package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseIDSummaryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String transactionID;		//Max Length:8
	private String finalDecision;		//Max Length:8
	private PreciseIDSummaryScoresModel scores;	           //Max Length:8
	
	public String getTransactionID() {
		return transactionID;
	}
	
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public String getFinalDecision() {
		return finalDecision;
	}

	public void setFinalDecision(String finalDecision) {
		this.finalDecision = finalDecision;
	}

	public PreciseIDSummaryScoresModel getScores() {
		return scores;
	}

	public void setScores(PreciseIDSummaryScoresModel scores) {
		this.scores = scores;
	}
	
}
