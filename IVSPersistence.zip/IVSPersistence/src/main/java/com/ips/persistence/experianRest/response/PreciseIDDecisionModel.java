package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseIDDecisionModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String reportDate;	           //Mandatory:Y, Max Length:8
	private String reportTime;		   //Mandatory:Y, Max Length:40
	private String productOption;		   //Mandatory:Y, Max Length:40
	private String subcode;		   //Mandatory:Y, Max Length:40
	private String referenceNumber;		   //Mandatory:Y, Max Length:40
	
	public String getReportDate() {
		return reportDate;
	}
	
	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}

	public String getReportTime() {
		return reportTime;
	}

	public void setReportTime(String reportTime) {
		this.reportTime = reportTime;
	}

	public String getProductOption() {
		return productOption;
	}

	public void setProductOption(String productOption) {
		this.productOption = productOption;
	}

	public String getSubcode() {
		return subcode;
	}

	public void setSubcode(String subcode) {
		this.subcode = subcode;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	
}
