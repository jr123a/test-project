package com.ips.persistence.common;

import com.ips.common.common.DeviceReviewStatusEnum;

public class DeviceReputationResult {
    private DeviceReviewStatusEnum deviceReviewStatus;
    private String transactionStatus;
    private String lexID;
    private String discoveryProductStatus;
    private String discoveryProductReasonCode;
    private String velocityProductStatus;
    private String velocityProductReasonCode;
    private String deviceProductStatus;
    private String deviceProductConfigName;
    
    public static final String DISCO_FAIL_REASON_INDIVIDUAL_NOT_FOUND = "individual_not_found";
    
	public DeviceReviewStatusEnum getDeviceReviewStatus() {
		return deviceReviewStatus;
	}
	
	public void setDeviceReviewStatus(DeviceReviewStatusEnum deviceReviewStatus) {
		this.deviceReviewStatus = deviceReviewStatus;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public String getLexID() {
		return lexID;
	}

	public void setLexID(String lexID) {
		this.lexID = lexID;
	}

	public String getDiscoveryProductStatus() {
		return discoveryProductStatus;
	}

	public void setDiscoveryProductStatus(String discoveryProductStatus) {
		this.discoveryProductStatus = discoveryProductStatus;
	}

	public String getDiscoveryProductReasonCode() {
		return discoveryProductReasonCode;
	}

	public void setDiscoveryProductReasonCode(String discoveryProductReasonCode) {
		this.discoveryProductReasonCode = discoveryProductReasonCode;
	}

	public String getVelocityProductStatus() {
		return velocityProductStatus;
	}

	public void setVelocityProductStatus(String velocityProductStatus) {
		this.velocityProductStatus = velocityProductStatus;
	}

	public String getVelocityProductReasonCode() {
		return velocityProductReasonCode;
	}

	public void setVelocityProductReasonCode(String velocityProductReasonCode) {
		this.velocityProductReasonCode = velocityProductReasonCode;
	}

	public String getDeviceProductStatus() {
		return deviceProductStatus;
	}

	public void setDeviceProductStatus(String deviceProductStatus) {
		this.deviceProductStatus = deviceProductStatus;
	}

	public String getDeviceProductConfigName() {
		return deviceProductConfigName;
	}

	public void setDeviceProductConfigName(String deviceProductConfigName) {
		this.deviceProductConfigName = deviceProductConfigName;
	}

}
