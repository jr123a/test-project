package com.ips.persistence.common;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

public class IVSCookie implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String keyIndex;
    private String sessionToken;

    public IVSCookie(String cookieValue){
        keyIndex = "00";
        sessionToken = null;
        setKeyIndex(cookieValue.substring(0, 2));
        setSessionToken(cookieValue);
    }
    
    public IVSCookie(String index, String token){
        keyIndex = "00";
        sessionToken = null;
        setKeyIndex(index);
        setSessionToken(token);
    }
    
    public String getKeyIndex() {
        return keyIndex;
    }

    public void setKeyIndex(String keyIndex) {
        String keyPadded = StringUtils.leftPad(keyIndex, 2,"0");
        this.keyIndex = keyPadded.substring(0, 2);
    }

    public String getSessionToken() {
        return sessionToken;
    }

    public void setSessionToken(String sessionToken) {
        this.sessionToken = sessionToken;
    }
    
    public String getCookieValue(){
        return (new StringBuilder(String.valueOf(keyIndex))).append(sessionToken).toString();
    }

}
