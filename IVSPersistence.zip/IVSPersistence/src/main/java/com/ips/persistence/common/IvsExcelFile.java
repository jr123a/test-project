package com.ips.persistence.common;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ips.common.common.CustomLogger;

public class IvsExcelFile {
    
    protected String fileName; 
    protected static final int AREA_WIDTH = 20;
    protected static final int DISTRICT_WIDTH = 25;
    protected static final int FACILITY_NAME_WIDTH = 30;
    protected static final int FACILITY_ID_WIDTH = 10;
    protected static final int TRANSACTIONS_WIDTH = 12;
    
    public IvsExcelFile(String fileName) { 
        this.fileName = fileName; 
    }
    
    public void generateExcelFile(List<AutomatedTransactionReportVo> automatedTransactionReportVoList) throws Exception { 
        
        Workbook wbs = new XSSFWorkbook(); 
    
        Sheet sheet = wbs.createSheet("Transaction List");  
        
        this.buildAutomatedTransactionHeaderRow(sheet); 
        
        for(int rowNumber = 0; rowNumber < automatedTransactionReportVoList.size(); rowNumber++) {
 
            AutomatedTransactionReportVo automatedTransactionReportVo = automatedTransactionReportVoList.get(rowNumber); 
            Row row = sheet.createRow(rowNumber +1);
            for (int cellNumber=0; cellNumber<11; cellNumber++) { 
                Cell cell = row.createCell(cellNumber);
                switch (cellNumber) { 
                    case 0:
                        cell.setCellValue(automatedTransactionReportVo.getPersonId());
                        break; 
                    case 1:
                        cell.setCellValue(automatedTransactionReportVo.getCustRegId());
                        break;
                    case 2:
                        cell.setCellValue(automatedTransactionReportVo.getEmailAddress());
                        break; 
                    case 3:
                        cell.setCellValue(automatedTransactionReportVo.getOtpSupplierName());
                        break; 
                    case 4:
                        cell.setCellValue(automatedTransactionReportVo.getMobilePhoneNumber());
                        break; 
                    case 5: 
                        cell.setCellValue(automatedTransactionReportVo.getTransactionKey());
                        break; 
                    case 6: 
                        cell.setCellValue(automatedTransactionReportVo.getPvOutcome());
                        break;
                    case 7: 
                        cell.setCellValue(automatedTransactionReportVo.getFinalDecision());
                        break; 
                    case 8:
                        cell.setCellValue(automatedTransactionReportVo.getSubmitOtp());
                        break;
                    case 9:
                        cell.setCellValue(automatedTransactionReportVo.getRequestNewCodes());
                        break; 
                    case 10:
                        cell.setCellValue(automatedTransactionReportVo.getCreateDate());
                        break; 
                    default:
                }
                
            }
            
        }
        
        try {
            FileOutputStream out = new FileOutputStream(fileName);
            wbs.write(out);
            out.close();
        } catch(Exception e) { 
            CustomLogger.error(this.getClass(), "Exception when writing out FileOutputStream .... ", e);
        }        
    }     
    
    private void writeExcelFile() { 
         
        Workbook[] wbs = new Workbook[] { new XSSFWorkbook() };

        for(int i=0; i<wbs.length; i++) {
           Workbook wb = wbs[i];
           CreationHelper createHelper = wb.getCreationHelper();

           // create a new sheet
           Sheet s = wb.createSheet("mysheet");

           // create 2 cell styles
           CellStyle cs = wb.createCellStyle();
           CellStyle cs2 = wb.createCellStyle();
           DataFormat df = wb.createDataFormat();

           // create 2 fonts objects
           Font f = wb.createFont();
           Font f2 = wb.createFont();

           // Set font 1 to 12 point type, blue and bold
           f.setFontHeightInPoints((short) 12);
           f.setColor( IndexedColors.RED.getIndex() );

           // Set font 2 to 10 point type, red and bold
           f2.setFontHeightInPoints((short) 10);
           f2.setColor( IndexedColors.RED.getIndex() );

           // Set cell style and formatting
           cs.setFont(f);
           cs.setDataFormat(df.getFormat("#,##0.0"));

           // Set the other cell style and formatting
           cs2.setDataFormat(df.getFormat("text"));
           cs2.setFont(f2);

           // Define a few rows
           for(int rownum = 0; rownum < 30; rownum++) {
               Row r = s.createRow(rownum);
               for(int cellnum = 0; cellnum < 10; cellnum += 2) {
                   Cell c = r.createCell(cellnum);
                   Cell c2 = r.createCell(cellnum+1);
                   c.setCellValue((double)rownum + ((double)cellnum/10));
                   c2.setCellValue(
                         createHelper.createRichTextString("Hello! " + cellnum)
                   );
               }
           }

 
           // Save
           String filename = fileName; 
           if(wb instanceof XSSFWorkbook) {
             filename = filename + "x";
           }
           
           try {
               FileOutputStream out = new FileOutputStream(filename);
               wb.write(out);
               out.close();
           } catch(Exception e) { 
                CustomLogger.error(this.getClass(), "Exception when writing out FileOutputStream .... ", e);
           }
        }

    }
    
    private Row buildAutomatedTransactionHeaderRow(Sheet sheet)  {
        Row headerRow = sheet.createRow(0);      
        
        Cell personCell = headerRow.createCell(0);
        personCell.setCellValue("PERSON_ID");
        
        Cell custRedIdCell = headerRow.createCell(1);
        custRedIdCell.setCellValue("CUSTREGID");    
        
        Cell emailAddressCell = headerRow.createCell(2);
        emailAddressCell.setCellValue("EMAIL_ADDRESS");        
        
        Cell otpSupplierNameCell = headerRow.createCell(3);
        otpSupplierNameCell.setCellValue("OTP_SUPPLIER_NAME");
        
        Cell mobilePhoneNumberCell = headerRow.createCell(4);
        mobilePhoneNumberCell.setCellValue("MOBILE_PHONE_NUMBER");
        
        Cell transactionKeyCell = headerRow.createCell(5);
        transactionKeyCell.setCellValue("TRANSACTION_KEY");        
        
        Cell pvOutcomeCell = headerRow.createCell(6);
        pvOutcomeCell.setCellValue("PVOUTCOME");        
        
        Cell finalDecisionCell = headerRow.createCell(7);
        finalDecisionCell.setCellValue("FINALDECISION");
        
        Cell submitToOtpCell = headerRow.createCell(8);
        submitToOtpCell.setCellValue("SUBMITOTP");
        
        Cell requestNewCodesCell = headerRow.createCell(9);
        requestNewCodesCell.setCellValue("REQUESTNEWCODES");    
        
        Cell createDateCell = headerRow.createCell(10);
        createDateCell.setCellValue("CREATE_DATE");
        
        return headerRow; 
    }
    
    /**
     * Creates the workbook so that it can be used in the other methods to build the file.
     * @param title
     * @return
     */
    public Workbook createSheet(String title) {
        Workbook wbs = new XSSFWorkbook(); 
        wbs.createSheet(title); 
        return wbs;
    }
    
    /**
     * Generate an Excel file for the Individual Transactions report.
     * @param wbs
     * @param title
     * @param voList
     * @param headers
     * @throws Exception
     */
    public void generateExcelFile(Workbook wbs, String title, List<IndividualTransactionReportVo> voList, List<String> headers) { 
        String newStatus = "New";
        Sheet sheet = wbs.getSheetAt(0);
        
        Row titleRow = sheet.createRow(0);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue(title);
        
        // Create the header row ....
        this.builHeaderRow(sheet, headers);

        int index = sheet.getLastRowNum() + 1;
        
        CellStyle style = wbs.createCellStyle();
        style.setDataFormat(wbs.createDataFormat().getFormat("text"));
        style.setWrapText(true);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        
        CellStyle rightJustify = getRightJustifyStyle(wbs);
        
        // set column widths
        setIndividualColumnWidths(sheet);
        
        for (IndividualTransactionReportVo reportVo: voList) {
            String result = reportVo.getResult();
            Row row = sheet.createRow(index);
            
            for (int cellNumber = 0; cellNumber < headers.size(); cellNumber++) { 
                Cell cell = row.createCell(cellNumber);
                switch (cellNumber) { 
                    case 0:
                        cell.setCellValue(reportVo.getArea());
                        cell.setCellStyle(style);
                        break; 
                    case 1:
                        cell.setCellValue(reportVo.getDistrict());
                        cell.setCellStyle(style);
                        break;
                    case 2:
                        cell.setCellValue(reportVo.getFacilityName());
                        cell.setCellStyle(style);
                        break; 
                    case 3:
                        cell.setCellValue(reportVo.getFacilityId());
                        cell.setCellStyle(style);
                        break; 
                    case 4:
                        cell.setCellValue(reportVo.getAceId());
                        cell.setCellStyle(style);
                        break; 
                    case 5: 
                        cell.setCellValue(reportVo.getCustomerName());
                        cell.setCellStyle(style);
                        break; 
                    case 6: 
                        cell.setCellValue(reportVo.getCustomerStreet());
                        cell.setCellStyle(style);
                        break;
                    case 7: 
                        cell.setCellValue(reportVo.getCustomerCity());
                        cell.setCellStyle(style);
                        break; 
                    case 8:
                        cell.setCellValue(reportVo.getCustomerState());
                        cell.setCellStyle(style);
                        break;
                    case 9:
                        cell.setCellValue(reportVo.getCustomerZip());
                        cell.setCellStyle(style);
                        break; 
                    case 10:
                        cell.setCellValue(reportVo.getResult());
                        cell.setCellStyle(style);
                        break; 
                    case 11:
                        cell.setCellValue(reportVo.getEnrollmentCode());
                        cell.setCellStyle(style);
                        break; 
                    case 12:
                        cell.setCellValue(reportVo.getPrimaryType());
                        cell.setCellStyle(style);
                        break;
                    case 13:
                        cell.setCellValue(reportVo.getPrimaryDescription());
                        cell.setCellStyle(style);
                        break; 
                    case 14:
                        cell.setCellValue(reportVo.getSecondaryType());
                        cell.setCellStyle(style);
                        break; 
                    case 15:
                        cell.setCellValue(reportVo.getSecondaryDescription());
                        cell.setCellStyle(style);
                        break; 
                    case 16: 
                        cell.setCellValue(reportVo.getOptInDate());
                        cell.setCellStyle(style);
                        break; 
                    case 17: 
                        cell.setCellValue(reportVo.getTransactionEndDateTime());
                        cell.setCellStyle(style);
                        break;
                    case 18: 
                        cell.setCellValue(reportVo.getFailureReason());
                        cell.setCellStyle(style);
                        break; 
                    case 19:
                        cell.setCellValue(reportVo.getTransactionTime());
                        cell.setCellStyle(rightJustify);
                        break;
                    case 20: 
                        // Do not include web service data for New, opted in transactions
                        if (!newStatus.equalsIgnoreCase(result)) {
                            cell.setCellValue(reportVo.isResultSentSuccessfully());
                        }
                        cell.setCellStyle(style);
                        break;
                    case 21: 
                        // Do not include web service data for New, opted in transactions
                        if (!newStatus.equalsIgnoreCase(result)) {
                            cell.setCellValue(reportVo.getFailedAttempts());
                        }
                        cell.setCellStyle(style);
                        break; 
                    case 22:
                        // Do not include web service data for New, opted in transactions
                        if (!newStatus.equalsIgnoreCase(result)) {
                            cell.setCellValue(reportVo.isFailureEmailSent());
                        }
                        cell.setCellStyle(style);
                        break;
                    default:
                }
                
            }
            
            index++;
        }
    } 
    
    private CellStyle getRightJustifyStyle(Workbook wbs) {
        CellStyle rightJustify = wbs.createCellStyle();
        rightJustify.setDataFormat(wbs.createDataFormat().getFormat("text"));
        rightJustify.setAlignment(HorizontalAlignment.RIGHT);
        rightJustify.setVerticalAlignment(VerticalAlignment.TOP);
        return rightJustify;
    }
    
    /**
     * Generate an Excel file for the Total Transactions report.
     * @param wbs
     * @param title
     * @param monthTitle
     * @param reportVo
     * @param headers
     * @throws Exception
     */
    public void generateExcelFile(Workbook wbs, String title, String monthTitle, TotalTransactionReportVo reportVo, List<String> headers) { 
        
        Sheet sheet = wbs.getSheetAt(0);
        
        Row titleRow = sheet.createRow(0);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue(title);
        
        // Create the header row ....
        this.builHeaderRow(sheet, headers);
        
        CellStyle rightJustify = getRightJustifyStyle(wbs);

        // set column widths
        setTotalTxnColumnWidths(sheet);
                
        int index = sheet.getLastRowNum() + 1;
        Row dayRow = sheet.createRow(index);
            
        for (int cellNumber = 0; cellNumber < headers.size(); cellNumber++) { 
            Cell cell = dayRow.createCell(cellNumber);
            switch (cellNumber) { 
                case 0:
                    cell.setCellValue(reportVo.getDayOptIn());
                    break; 
                case 1:
                    cell.setCellValue(reportVo.getDayTotalTransactions());
                    break;
                case 2:
                    cell.setCellValue(reportVo.getDayPassed());
                    break; 
                case 3:
                    cell.setCellValue(reportVo.getDayFailed());
                    break; 
                case 4:
                    cell.setCellValue(reportVo.getDayPassRate() + "%");
                    cell.setCellStyle(rightJustify);
                    break; 
                case 5: 
                    cell.setCellValue(reportVo.getDayFailRate() + "%");
                    cell.setCellStyle(rightJustify);
                    break; 
                case 6:
                    cell.setCellValue(reportVo.getDayCallFailures());
                    break; 
                case 7:
                    cell.setCellValue(reportVo.getDayRetrySucceeded());
                    break; 
                case 8: 
                    cell.setCellValue(reportVo.getDayFailedEmails());
                    break; 
                default:
            }
        }
            
        addRowAfterBlankLine(wbs, monthTitle);
        this.builHeaderRow(sheet, headers);
        Row monthRow = sheet.createRow(sheet.getLastRowNum() + 1);
    
        for (int cellNumber = 0; cellNumber < headers.size(); cellNumber++) { 
            Cell cell = monthRow.createCell(cellNumber);
            switch (cellNumber) { 
                case 0:
                    cell.setCellValue(reportVo.getMonthOptIn());
                    break; 
                case 1:
                    cell.setCellValue(reportVo.getMonthTotalTransactions());
                    break;
                case 2:
                    cell.setCellValue(reportVo.getMonthPassed());
                    break; 
                case 3:
                    cell.setCellValue(reportVo.getMonthFailed());
                    break; 
                case 4:
                    cell.setCellValue(reportVo.getMonthPassRate() + "%");
                    cell.setCellStyle(rightJustify);
                    break; 
                case 5: 
                    cell.setCellValue(reportVo.getMonthFailRate() + "%");
                    cell.setCellStyle(rightJustify);
                    break; 
                case 6:
                    cell.setCellValue(reportVo.getMonthCallFailures());
                    break; 
                case 7:
                    cell.setCellValue(reportVo.getMonthRetrySucceeded());
                    break; 
                case 8: 
                    cell.setCellValue(reportVo.getMonthFailedEmails());
                    break; 
                default:
            }
        }
    } 
    
    /**
     * Generate an Excel file for the Transactions by Facility report.
     * @param wbs
     * @param dayTitle
     * @param monthTitle
     * @param dayList
     * @param monthList
     * @param headers
     * @throws Exception
     */
    public void generateExcelFile(Workbook wbs, String dayTitle, String monthTitle, List<FacilityTransactionReportVo> dayList, 
            List<FacilityTransactionReportVo> monthList, List<String> headers) { 
        
        Sheet sheet = wbs.getSheetAt(0);
        
        Row titleRow = sheet.createRow(0);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue(dayTitle);
        
        // Create the header row ....
        this.builHeaderRow(sheet, headers);
        
        CellStyle rightJustify = getRightJustifyStyle(wbs);
        
        // set column widths
        setFacilityTxnColumnWidths(sheet);

        int index = sheet.getLastRowNum() + 1;
        
        for (FacilityTransactionReportVo reportVo: dayList) {
            Row row = sheet.createRow(index);
            
            for (int cellNumber = 0; cellNumber < headers.size(); cellNumber++) { 
                Cell cell = row.createCell(cellNumber);
                switch (cellNumber) { 
                    case 0:
                        cell.setCellValue(reportVo.getArea());
                        break; 
                    case 1:
                        cell.setCellValue(reportVo.getDistrict());
                        break;
                    case 2:
                        cell.setCellValue(reportVo.getFacilityName());
                        break; 
                    case 3:
                        cell.setCellValue(reportVo.getFacilityId());
                        break; 
                    case 4:
                        cell.setCellValue(reportVo.getDayTotalTransactions());
                        break;
                    case 5:
                        cell.setCellValue(reportVo.getDayPassed());
                        break; 
                    case 6:
                        cell.setCellValue(reportVo.getDayFailed());
                        break; 
                    case 7:
                        cell.setCellValue(reportVo.getDayPassRate() + "%");
                        cell.setCellStyle(rightJustify);
                        break; 
                    case 8: 
                        cell.setCellValue(reportVo.getDayFailRate() + "%");
                        cell.setCellStyle(rightJustify);
                        break; 
                    default:
                }
            }
            
            index++;
        }
            
        this.addRowAfterBlankLine(wbs, monthTitle);
        this.builHeaderRow(sheet, headers);
        
        index = sheet.getLastRowNum() + 1;
        
        for (FacilityTransactionReportVo reportVo: monthList) {
            Row row = sheet.createRow(index);
            
            for (int cellNumber = 0; cellNumber < headers.size(); cellNumber++) { 
                Cell cell = row.createCell(cellNumber);
                switch (cellNumber) { 
                    case 0:
                        cell.setCellValue(reportVo.getArea());
                        break; 
                    case 1:
                        cell.setCellValue(reportVo.getDistrict());
                        break;
                    case 2:
                        cell.setCellValue(reportVo.getFacilityName());
                        break; 
                    case 3:
                        cell.setCellValue(reportVo.getFacilityId());
                        break; 
                    case 4:
                        cell.setCellValue(reportVo.getMonthTotalTransactions());
                        break;
                    case 5:
                        cell.setCellValue(reportVo.getMonthPassed());
                        break; 
                    case 6:
                        cell.setCellValue(reportVo.getMonthFailed());
                        break; 
                    case 7:
                        cell.setCellValue(reportVo.getMonthPassRate() + "%");
                        cell.setCellStyle(rightJustify);
                        break; 
                    case 8: 
                        cell.setCellValue(reportVo.getMonthFailRate() + "%");
                        cell.setCellStyle(rightJustify);
                        break; 
                    default:
                }
            }
            
            index++;
        }
    } 
    
    public void addRowAfterBlankLine(Workbook wbs, String data) {
        Sheet sheet = wbs.getSheetAt(0);
        sheet.createRow(sheet.getLastRowNum() + 1);
        Row row = sheet.createRow(sheet.getLastRowNum() + 1);
        Cell cell = row.createCell(0);
        cell.setCellValue(data); 
    }
    
    public void addBlankLine(Workbook wbs) {
        Sheet sheet = wbs.getSheetAt(0);
        sheet.createRow(sheet.getLastRowNum() + 1); 
    }
    
    private Row builHeaderRow(Sheet sheet, List<String> headers){
        Workbook wbs = sheet.getWorkbook();
        CellStyle cs = wbs.createCellStyle();
        cs.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        cs.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        cs.setWrapText(true);
        cs.setVerticalAlignment(VerticalAlignment.TOP);

        Row headerRow = sheet.createRow(sheet.getLastRowNum() + 1); 
        headerRow.setHeightInPoints((2*sheet.getDefaultRowHeightInPoints()));
        
        int index = 0;
        
        for (String header: headers) {
            Cell cell = headerRow.createCell(index);
            cell.setCellValue(header);
            cell.setCellStyle(cs);
            index++;
        }
        
        return headerRow; 
    }
    
    /**
     * Sets column widths.  The width is in units of 1/256th of a character width.
     * @param sheet
     */
    private void setIndividualColumnWidths(Sheet sheet) {
        int index = 0;
        
        // Area
        sheet.setColumnWidth(index++, AREA_WIDTH * 256);
        // District
        sheet.setColumnWidth(index++, DISTRICT_WIDTH * 256);
        // Facility Name
        sheet.setColumnWidth(index++, FACILITY_NAME_WIDTH * 256);
        // Facility ID
        sheet.setColumnWidth(index++, FACILITY_ID_WIDTH * 256);
        // ACE ID
        sheet.setColumnWidth(index++, 15 * 256);
        // Customer Name
        sheet.setColumnWidth(index++, 30 * 256);
        // Customer Street
        sheet.setColumnWidth(index++, 40 * 256);
        // Customer City
        sheet.setColumnWidth(index++, 25 * 256);
        // Customer State
        sheet.setColumnWidth(index++, 10 * 256);
        // Customer zip
        sheet.setColumnWidth(index++, 15 * 256);
        // Result
        sheet.setColumnWidth(index++, 10 * 256);
        // Enrollment code
        sheet.setColumnWidth(index++, 20 * 256);
        // Primary ID Type
        sheet.setColumnWidth(index++, 10 * 256);
        // Primary ID Description
        sheet.setColumnWidth(index++, 40 * 256);
        // Secondary ID Type
        sheet.setColumnWidth(index++, 10 * 256);
        // Secondary ID Description
        sheet.setColumnWidth(index++, 35 * 256);
        // Opt-In Date
        sheet.setColumnWidth(index++, 11 * 256);
        // Transaction Date 
        sheet.setColumnWidth(index++, 25 * 256);
        // Failure Reason  
        sheet.setColumnWidth(index++, 30 * 256);
        // Transaction time (minutes) 
        sheet.setColumnWidth(index++, 15 * 256);
        // Result Successfully Sent to Agency
        sheet.setColumnWidth(index++, 20 * 256);
        // Number of Retry Attempts 
        sheet.setColumnWidth(index++, 15 * 256);
        // Failure Email Sent Due to Retry Failure 
        sheet.setColumnWidth(index++, 20 * 256);
    }
    
    /**
     * Sets column widths.  The width is in units of 1/256th of a character width.
     * @param sheet
     */
    private void setTotalTxnColumnWidths(Sheet sheet) {
        // Transactions
        sheet.setColumnWidth(1, TRANSACTIONS_WIDTH * 256);
        // Web Service Call Failures
        sheet.setColumnWidth(6, 20 * 256);
        // Failures that Succeeded on Retry
        sheet.setColumnWidth(7, 19 * 256);
        // Failures that caused Failed Email
        sheet.setColumnWidth(8, 18 * 256);
    }
    
    /**
     * Sets column widths.  The width is in units of 1/256th of a character width.
     * @param sheet
     */
    private void setFacilityTxnColumnWidths(Sheet sheet) {
        int index = 0;
        
        // Area
        sheet.setColumnWidth(index++, AREA_WIDTH * 256);
        // District
        sheet.setColumnWidth(index++, DISTRICT_WIDTH * 256);
        // Facility Name
        sheet.setColumnWidth(index++, FACILITY_NAME_WIDTH * 256);
        // Facility ID
        sheet.setColumnWidth(index++, FACILITY_ID_WIDTH * 256);
        // Transactions
        sheet.setColumnWidth(index++, TRANSACTIONS_WIDTH * 256);
    }
    
    public void writeFile(Workbook wbs) throws Exception {
        FileOutputStream out = new FileOutputStream(fileName);
        wbs.write(out);
        out.close();    
    }
    
    public static void saveStringListToFile(String pSrcFilePath, List<String> stringList) throws Exception {
        File targetFile = new File(pSrcFilePath);
        FileWriter fw = new FileWriter(targetFile);
       
        for (String aString : stringList) {
            fw.write(aString);
            fw.write("\n");
        }
        
        fw.close();
   }
    
    public void generateHighRiskAddressExcelFile(List<HighRiskAddressVo> primaryList, List<HighRiskAddressVo> primaryIPPList, 
             List<HighRiskAddressVo> secondaryList, List<HighRiskAddressVo> secondaryNoRPPList) throws Exception { 
        Workbook wbs = new XSSFWorkbook(); 
        
        Sheet sheet1 = wbs.createSheet("Primary Report-Overview"); 
        Sheet sheet2 = wbs.createSheet("Primary Report-IPP"); 
        Sheet sheet3 = wbs.createSheet("Secondary Report"); 
        Sheet sheet4 = wbs.createSheet("Secondary Report No RP");  
        
        this.populatePrimarySheet(sheet1, primaryList);  
        this.populatePrimaryIPPSheet(sheet2, primaryIPPList);
        this.populateSecondarySheet(sheet3, secondaryList);
        this.populateSecondaryNoRPPSheet(sheet4, secondaryNoRPPList);
        
        try {
            FileOutputStream out = new FileOutputStream(fileName);
            wbs.write(out);
            out.close();
        } catch(Exception e) { 
            CustomLogger.error(this.getClass(), "Exception when creating Excel File .... ", e);
        }        
    }    
    
    private void populatePrimarySheet(Sheet sheet1, List<HighRiskAddressVo> primaryList) {      
        
        this.buildInfoRow(sheet1, "Direct to IPP for primary type High Risk Address"); 
        this.buildEmptyRow(sheet1, 1); 
        this.buildRiskAddressHeader(sheet1, "primary");         
        
        for(int rowNumber = 0; rowNumber < primaryList.size(); rowNumber++) {
             
            HighRiskAddressVo highRiskAddressVo = primaryList.get(rowNumber); 
            Row row = sheet1.createRow(rowNumber +3);
            for (int cellNumber=0; cellNumber<13; cellNumber++) { 
                Cell cell = row.createCell(cellNumber);
                switch (cellNumber) { 
                    case 0:
                        cell.setCellValue(highRiskAddressVo.getAddress());
                        break; 
                    case 1:
                        cell.setCellValue(highRiskAddressVo.getAddressLineTwo());
                        break;
                    case 2:
                        cell.setCellValue(highRiskAddressVo.getCity());
                        break; 
                    case 3:
                        cell.setCellValue(highRiskAddressVo.getState());
                        break; 
                    case 4:
                        cell.setCellValue(highRiskAddressVo.getZip());
                        break; 
                    case 5: 
                        cell.setCellValue(highRiskAddressVo.getZip11());
                        break; 
                    case 6: 
                        cell.setCellValue(highRiskAddressVo.getTimestampAddedIntoList());
                        break;
                    case 7: 
                        cell.setCellValue(highRiskAddressVo.getPersonId());
                        break; 
                    case 8:
                        cell.setCellValue(highRiskAddressVo.getCustRegId());
                        break;
                    case 9:
                        cell.setCellValue(highRiskAddressVo.getSponsor());
                        break;                        
                    case 10:
                        cell.setCellValue(highRiskAddressVo.getTimestampWhenDirectedToIPP());
                        break; 
                    case 11:
                        cell.setCellValue(highRiskAddressVo.getTimestampWhenOptInToIPP());
                        break; 
                    case 12:
                        cell.setCellValue(highRiskAddressVo.getTimestampWhenGotToPostOffice());
                        break;     
                    default:
                }
                
            }
            
        }
    }
    
    private void populatePrimaryIPPSheet(Sheet sheet2, List<HighRiskAddressVo> primaryList) { 
        
        this.buildInfoRow(sheet2, "IPP Attempt for primary type ( Go for IPP)"); 
        this.buildEmptyRow(sheet2, 1); 
        this.buildRiskAddressHeader(sheet2, "primaryIPP");             
        
        for(int rowNumber = 0; rowNumber < primaryList.size(); rowNumber++) {
             
            HighRiskAddressVo highRiskAddressVo = primaryList.get(rowNumber); 
            Row row = sheet2.createRow(rowNumber +3);
            for (int cellNumber=0; cellNumber<16; cellNumber++) { 
                Cell cell = row.createCell(cellNumber);
                switch (cellNumber) { 
                    case 0:
                        cell.setCellValue(highRiskAddressVo.getAddress());
                        break; 
                    case 1:
                        cell.setCellValue(highRiskAddressVo.getAddressLineTwo());
                        break;
                    case 2:
                        cell.setCellValue(highRiskAddressVo.getCity());
                        break; 
                    case 3:
                        cell.setCellValue(highRiskAddressVo.getState());
                        break; 
                    case 4:
                        cell.setCellValue(highRiskAddressVo.getZip());
                        break; 
                    case 5: 
                        cell.setCellValue(highRiskAddressVo.getZip11());
                        break; 
                    case 6: 
                        cell.setCellValue(highRiskAddressVo.getTimestampAddedIntoList());
                        break;
                    case 7: 
                        cell.setCellValue(highRiskAddressVo.getPersonId());
                        break; 
                    case 8:
                        cell.setCellValue(highRiskAddressVo.getCustRegId());
                        break;
                    case 9:
                        cell.setCellValue(highRiskAddressVo.getSponsor());
                        break;                         
                    case 10:
                        cell.setCellValue(highRiskAddressVo.getTimestampWhenDirectedToIPP());
                        break; 
                    case 11:
                        cell.setCellValue(highRiskAddressVo.getTimestampWhenOptInToIPP());
                        break; 
                    case 12:
                        cell.setCellValue(highRiskAddressVo.getTimestampWhenGotToPostOffice());
                        break; 
                    case 13:    
                        cell.setCellValue(highRiskAddressVo.getIppStatus());
                        break;
                    case 14:     
                        cell.setCellValue(highRiskAddressVo.getFailureReason());
                        break;
                    case 15: 
                        cell.setCellValue(highRiskAddressVo.getFraud());
                        break;     
                    default:
                }
                
            }
            
        }
    
    }
    
    private void populateSecondarySheet(Sheet sheet3, List<HighRiskAddressVo> secondaryList) { 
        
        this.buildInfoRow(sheet3, "For Secondary High Risk address ( Direct to remote proofing)"); 
        this.buildEmptyRow(sheet3, 1); 
        this.buildRiskAddressHeader(sheet3, "secondary");             
        
        for(int rowNumber = 0; rowNumber < secondaryList.size(); rowNumber++) {
             
            HighRiskAddressVo highRiskAddressVo = secondaryList.get(rowNumber); 
            Row row = sheet3.createRow(rowNumber +3);
            for (int cellNumber=0; cellNumber<15; cellNumber++) { 
                Cell cell = row.createCell(cellNumber);
                switch (cellNumber) { 
                    case 0:
                        cell.setCellValue(highRiskAddressVo.getAddress());
                        break; 
                    case 1:
                        cell.setCellValue(highRiskAddressVo.getAddressLineTwo());
                        break;
                    case 2:
                        cell.setCellValue(highRiskAddressVo.getCity());
                        break; 
                    case 3:
                        cell.setCellValue(highRiskAddressVo.getState());
                        break; 
                    case 4:
                        cell.setCellValue(highRiskAddressVo.getZip());
                        break; 
                    case 5: 
                        cell.setCellValue(highRiskAddressVo.getZip11());
                        break; 
                    case 6: 
                        cell.setCellValue(highRiskAddressVo.getTimestampAddedIntoList());
                        break;
                    case 7: 
                        cell.setCellValue(highRiskAddressVo.getPersonId());
                        break; 
                    case 8:
                        cell.setCellValue(highRiskAddressVo.getCustRegId());
                        break;
                    case 9:
                        cell.setCellValue(highRiskAddressVo.getSponsor());
                        break; 
                    case 10:
                        cell.setCellValue(highRiskAddressVo.getDateTimeTobeChecked());
                        break; 
                    case 11:
                        cell.setCellValue(highRiskAddressVo.getDateTimeToStartRemoteProofing());
                        break; 
                    case 12:
                        cell.setCellValue(highRiskAddressVo.getSupplier());
                        break; 
                    case 13:    
                        cell.setCellValue(highRiskAddressVo.getRpStatus());
                        break;
                    case 14:     
                        cell.setCellValue(highRiskAddressVo.getTransasctionKey());
                        break;    
                    default:
                }
                
            }
            
        }        
    }    
    
    private void populateSecondaryNoRPPSheet(Sheet sheet4, List<HighRiskAddressVo> secondaryNoRPPList) { 
        
        this.buildInfoRow(sheet4, "For Secondary High Risk address ( No remote proofing)"); 
        this.buildEmptyRow(sheet4, 1); 
        this.buildRiskAddressHeader(sheet4, "secondaryNoRP");             
        
        for(int rowNumber = 0; rowNumber < secondaryNoRPPList.size(); rowNumber++) {
             
            HighRiskAddressVo highRiskAddressVo = secondaryNoRPPList.get(rowNumber); 
            Row row = sheet4.createRow(rowNumber +3);
            for (int cellNumber=0; cellNumber<11; cellNumber++) { 
                Cell cell = row.createCell(cellNumber);
                switch (cellNumber) { 
                    case 0:
                        cell.setCellValue(highRiskAddressVo.getAddress());
                        break; 
                    case 1:
                        cell.setCellValue(highRiskAddressVo.getAddressLineTwo());
                        break;
                    case 2:
                        cell.setCellValue(highRiskAddressVo.getCity());
                        break; 
                    case 3:
                        cell.setCellValue(highRiskAddressVo.getState());
                        break; 
                    case 4:
                        cell.setCellValue(highRiskAddressVo.getZip());
                        break; 
                    case 5: 
                        cell.setCellValue(highRiskAddressVo.getZip11());
                        break; 
                    case 6: 
                        cell.setCellValue(highRiskAddressVo.getTimestampAddedIntoList());
                        break;
                    case 7: 
                        cell.setCellValue(highRiskAddressVo.getPersonId());
                        break; 
                    case 8:
                        cell.setCellValue(highRiskAddressVo.getCustRegId());
                        break;
                    case 9:
                        cell.setCellValue(highRiskAddressVo.getSponsor());
                        break;                         
                    case 10:
                        cell.setCellValue(highRiskAddressVo.getDateTimeTobeChecked());
                        break;         
                    default:
                }
                
            }
            
        }    
    }        
    private Row buildInfoRow(Sheet sheet, String informationData) {
        
        Workbook wbs = sheet.getWorkbook();
         CellStyle cs = wbs.createCellStyle();
         
         Font f = wbs.createFont(); 
         try {
        	 f.setBold(true);
         } catch (NumberFormatException nfe) {
             CustomLogger.error(this.getClass(), "Execption when setting font bold weight .... ", nfe);
         }
         cs.setFont(f);
             
        
        Row infoRow = sheet.createRow(0); 
        
        Cell infoCell = infoRow.createCell(0); 
        infoCell.setCellStyle(cs);
        infoCell.setCellValue(informationData);
        
        return infoRow; 
    }
    
    private Row buildEmptyRow(Sheet sheet, int rowIndex) { 
        Row emptyRow = sheet.createRow(rowIndex);
        Cell cell = emptyRow.createCell(0);
        cell.setCellValue("");         
        return emptyRow; 
    }
    
    private Row buildRiskAddressHeader(Sheet sheet, String type) { 
        
        Workbook wbs = sheet.getWorkbook(); 
        Row riskAddresHeaderRow = sheet.createRow(2);
        
        String[] headers = new String[] {};  
        
        switch (type) { 
            case "primary":
                headers = new String[] { "ADDRESS", "ADDRESS_LINE_2", "CITY", "STATE", "ZIP", "ZIP 11", "Timestamp Added into the list",
                        "PersonID", "CustRegID", "Sponsor", "When user is directed to IPP", "When user opts in to OTP", "When user visits post office"};
                break; 
            case "primaryIPP": 
                headers = new String[] { "ADDRESS", "ADDRESS_LINE_2", "CITY", "STATE", "ZIP", "ZIP 11", "Timestamp Added into the list",
                        "PersonID", "CustRegID", "Sponsor", "When user is directed to IPP", "When user opts in to OTP", "When user visits post office",
                        "IPP Status", "Failure reason (If IPP failed)", "Fraud"};                
                break; 
            case "secondary": 
                headers = new String[] { "ADDRESS", "ADDRESS_LINE_2", "CITY", "STATE", "ZIP", "ZIP 11", "Timestamp Added into the list", 
                                         "PersonID", "CustRegID", "Sponsor", "DataTimeTobeChecked", "DateTimetoStartRemoteProofing", "Supplier", "RPStatus", "TransactionKey"};                 
                break;
            case "secondaryNoRP": 
                headers = new String[] { "ADDRESS", "ADDRESS_LINE_2", "CITY", "STATE", "ZIP", "ZIP 11",    "Timestamp Added into the list", 
                                        "PersonID", "CustRegID", "Sponsor", "DataTimeTobeChecked"};                
                break;        
            default:
        }
        
        CellStyle style = wbs.createCellStyle(); 
        style.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setWrapText(true);
    
 
        for (int headerIndex=0; headerIndex<headers.length; headerIndex++) {
        
            String headerDescription = headers[headerIndex]; 
            if ("ADDRESS".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 40 * 256);
            }
            
            if ("ADDRESS_LINE_2".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 10 * 256);
            }    
            
            if ("CITY".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 15 * 256);
            }    
            
            if ("STATE".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 6 * 256);
            }    
            
            if ("ZIP".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 6 * 256);
            }    
            
            if ("ZIP 11".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 11 * 256);
            }        
            
            if ("Timestamp Added into the list".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 19 * 256);
            }    
            
            if ("PersonID".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 10 * 256);
            }    
            
            if ("CustRegID".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 11 * 256);
            }
            
            if ("Sponsor".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 15 * 256);
            }            
            
            if ("When user is directed to IPP".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 19 * 256);
            }
            
            if ("When user opts in to OTP".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 23 * 256);
            }    
            
            if ("When user visits post office".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 23 * 256);
            }
            
            if ("IPP Status".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 23 * 256);
            }                
            
            if ("Failure reason (If IPP failed)".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 23 * 256);
            }
            
            if ("Fraud".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 23 * 256); 
            }    
            
            if ("DataTimeTobeChecked".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 19 * 256); 
            }            
            
            if ("DateTimetoStartRemoteProofing".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 23 * 256); 
            }                

            if ("Supplier".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 15 * 256); 
            }                

            if ("RPStatus".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 9 * 256); 
            }    
            
            if ("TransactionKey".equalsIgnoreCase(headerDescription.trim())) { 
                sheet.setColumnWidth(headerIndex, 18 * 256); 
            }            
            
            Cell cell = riskAddresHeaderRow.createCell(headerIndex);
            cell.setCellValue(headers[headerIndex]); 
            cell.setCellStyle(style);
        }
        return riskAddresHeaderRow;  
    }        
}
