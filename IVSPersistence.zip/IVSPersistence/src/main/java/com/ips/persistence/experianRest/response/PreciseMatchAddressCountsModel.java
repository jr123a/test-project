package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchAddressCountsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int standardizedAddressReturnCount; //Max Length:8
	private int residentialAddressMatchCount; //Max Length:8
	private int residentialAddressReturnCount; //Max Length:8
	private int highRiskAddressReturnCount; //Max Length:8
	private int businessAddressMatchCount; //Max Length:8
	private int businessAddressReturnCount; //Max Length:8
	
	public int getStandardizedAddressReturnCount() {
		return standardizedAddressReturnCount;
	}
	
	public void setStandardizedAddressReturnCount(int standardizedAddressReturnCount) {
		this.standardizedAddressReturnCount = standardizedAddressReturnCount;
	}

	public int getResidentialAddressMatchCount() {
		return residentialAddressMatchCount;
	}

	public void setResidentialAddressMatchCount(int residentialAddressMatchCount) {
		this.residentialAddressMatchCount = residentialAddressMatchCount;
	}

	public int getResidentialAddressReturnCount() {
		return residentialAddressReturnCount;
	}

	public void setResidentialAddressReturnCount(int residentialAddressReturnCount) {
		this.residentialAddressReturnCount = residentialAddressReturnCount;
	}

	public int getHighRiskAddressReturnCount() {
		return highRiskAddressReturnCount;
	}

	public void setHighRiskAddressReturnCount(int highRiskAddressReturnCount) {
		this.highRiskAddressReturnCount = highRiskAddressReturnCount;
	}

	public int getBusinessAddressMatchCount() {
		return businessAddressMatchCount;
	}

	public void setBusinessAddressMatchCount(int businessAddressMatchCount) {
		this.businessAddressMatchCount = businessAddressMatchCount;
	}

	public int getBusinessAddressReturnCount() {
		return businessAddressReturnCount;
	}

	public void setBusinessAddressReturnCount(int businessAddressReturnCount) {
		this.businessAddressReturnCount = businessAddressReturnCount;
	}
}
