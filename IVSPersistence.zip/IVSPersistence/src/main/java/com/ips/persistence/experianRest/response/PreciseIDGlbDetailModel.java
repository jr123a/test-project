package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseIDGlbDetailModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseIDFraudShieldModel fraudShield;	           //Max Length:8
	private PreciseIDGlbRulesModel glbRules;

	public PreciseIDFraudShieldModel getFraudShield() {
		return fraudShield;
	}

	public void setFraudShield(PreciseIDFraudShieldModel fraudShield) {
		this.fraudShield = fraudShield;
	}

	public PreciseIDGlbRulesModel getGlbRules() {
		return glbRules;
	}

	public void setGlbRules(PreciseIDGlbRulesModel glbRules) {
		this.glbRules = glbRules;
	}
	
}
