package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchDriverLicenseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseMatchDriverLicenseSummaryModel summary;	           //Max Length:8

	public PreciseMatchDriverLicenseSummaryModel getSummary() {
		return summary;
	}

	public void setSummary(PreciseMatchDriverLicenseSummaryModel summary) {
		this.summary = summary;
	}
	
}
