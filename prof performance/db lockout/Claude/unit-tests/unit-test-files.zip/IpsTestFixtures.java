package com.ips.test;

import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpInfPvAttemptConfig;
import com.ips.entity.RpInfPvAttemptConfigPK;
import com.ips.entity.RpOtpAttemptConfig;
import com.ips.entity.RpOtpAttemptConfigPK;
import com.ips.persistence.common.PersonVo;

import java.util.ArrayList;
import java.util.List;

/**
 * Shared test fixture factory for IPS unit tests.
 *
 * All methods return fully-populated, ready-to-use test objects.
 * No DB, no Spring, no JSF context required.
 *
 * Usage:
 *   PersonVo pv = IpsTestFixtures.personVo("testUser1", 32L);
 *   RefOtpSupplier ln = IpsTestFixtures.lexisNexisSupplier();
 *   RpOtpAttemptConfig cfg = IpsTestFixtures.otpConfig(ln, 30, 60);
 */
public final class IpsTestFixtures {

    // ─── Supplier IDs (mirrors RefOtpSupplier constants) ─────────────────────
    public static final long SUPPLIER_EQUIFAX_IDFS = RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID;   // 4
    public static final long SUPPLIER_EQUIFAX_SMFA = RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID;   // 5 (DIT/SMFA)
    public static final long SUPPLIER_LEXISNEXIS   = RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID; // 6
    public static final long SUPPLIER_EXPERIAN     = RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID; // 7

    // ─── Standard sponsor/LOA IDs used in production ──────────────────────────
    public static final long SPONSOR_CUSTREG = 2L;  // CustReg/Informed Delivery
    public static final long SPONSOR_COA     = 32L; // Change of Address
    public static final long LOA_15_CODE     = RefLoaLevel.LOA15_CODE; // typically 1

    private IpsTestFixtures() { /* static factory only */ }

    // ─── PersonVo ─────────────────────────────────────────────────────────────

    /**
     * Creates a minimal PersonVo for the normal (non-INF) OTP flow.
     */
    public static PersonVo personVo(String sponsorUserId, long sponsorId) {
        PersonVo pv = new PersonVo();
        pv.setSponsorUserId(sponsorUserId);
        pv.setSponsorId(sponsorId);
        pv.setSponsor("CUSTREG");
        pv.setProofingLevelSought((int) LOA_15_CODE);
        pv.setId(1001L);
        pv.setFirstName("Test");
        pv.setLastName("User");
        pv.setMobileNumber("5551234567");
        // flags default to false — normal happy-path user
        return pv;
    }

    /**
     * Creates a PersonVo with the LexisNexis Individual-Not-Found flag set.
     */
    public static PersonVo personVoWithLexisNexisINF(String sponsorUserId, long sponsorId) {
        PersonVo pv = personVo(sponsorUserId, sponsorId);
        pv.setLexisNexisIndividualNotFound(true);
        return pv;
    }

    /**
     * Creates a PersonVo with the Experian Customer-Not-On-File flag set.
     */
    public static PersonVo personVoWithExperianCNF(String sponsorUserId, long sponsorId) {
        PersonVo pv = personVo(sponsorUserId, sponsorId);
        pv.setExperianCustomerNotOnFile(true);
        return pv;
    }

    /**
     * Creates a PersonVo with the Experian error-response flag set.
     */
    public static PersonVo personVoWithExperianError(String sponsorUserId, long sponsorId) {
        PersonVo pv = personVo(sponsorUserId, sponsorId);
        pv.setExperianErrorResponse(true);
        return pv;
    }

    // ─── RefLoaLevel ──────────────────────────────────────────────────────────

    public static RefLoaLevel loaLevel15() {
        RefLoaLevel level = new RefLoaLevel();
        level.setLoaCode(LOA_15_CODE);
        level.setLoaDescription("LOA 1.5");
        return level;
    }

    // ─── RefSponsor ───────────────────────────────────────────────────────────

    public static RefSponsor sponsor(long sponsorId, String sponsorName) {
        RefSponsor sponsor = new RefSponsor();
        sponsor.setSponsorId(sponsorId);
        sponsor.setSponsorName(sponsorName);
        return sponsor;
    }

    public static RefSponsor custRegSponsor() {
        return sponsor(SPONSOR_CUSTREG, "CUSTREG");
    }

    public static RefSponsor coaSponsor() {
        return sponsor(SPONSOR_COA, "COA");
    }

    // ─── RefOtpSupplier ───────────────────────────────────────────────────────

    public static RefOtpSupplier supplier(long id, String name) {
        RefOtpSupplier s = new RefOtpSupplier();
        s.setOtpSupplierId(id);
        s.setOtpSupplierName(name);
        // set the boolean flags that the service checks
        s.setLexisNexisPhone(id == SUPPLIER_LEXISNEXIS);
        s.setEquifaxIdfsPhone(id == SUPPLIER_EQUIFAX_IDFS);
        s.setEquifaxDITSMFA(id == SUPPLIER_EQUIFAX_SMFA);
        s.setExperianPhone(id == SUPPLIER_EXPERIAN);
        return s;
    }

    public static RefOtpSupplier lexisNexisSupplier() {
        return supplier(SUPPLIER_LEXISNEXIS, "LexisNexis RDP OTP");
    }

    public static RefOtpSupplier equifaxIdfsSupplier() {
        return supplier(SUPPLIER_EQUIFAX_IDFS, "Equifax IDFS OTP");
    }

    public static RefOtpSupplier equifaxSmfaSupplier() {
        return supplier(SUPPLIER_EQUIFAX_SMFA, "Equifax DIT SMFA");
    }

    public static RefOtpSupplier experianSupplier() {
        return supplier(SUPPLIER_EXPERIAN, "Experian CrossCore");
    }

    // ─── RpOtpAttemptConfig (rp_kba_attempts) ─────────────────────────────────

    /**
     * Creates a single OTP attempt config row for a supplier.
     *
     * @param supplier       the RefOtpSupplier entity
     * @param currentAttempts  current running attempt count
     * @param totalAttempts  the allocation percentage (e.g. 60 = 60%)
     */
    public static RpOtpAttemptConfig otpConfig(RefOtpSupplier supplier,
                                               int currentAttempts,
                                               int totalAttempts) {
        RpOtpAttemptConfigPK pk = new RpOtpAttemptConfigPK();
        pk.setSupplierId(supplier.getOtpSupplierId());
        pk.setProofingLevel(LOA_15_CODE);
        pk.setSponsorId(SPONSOR_CUSTREG);

        RpOtpAttemptConfig cfg = new RpOtpAttemptConfig();
        cfg.setId(pk);
        cfg.setAttempts(currentAttempts);
        cfg.setTotalAttempts(totalAttempts);
        cfg.setRefOtpSupplier(supplier);
        cfg.setVersion(1L);
        return cfg;
    }

    /**
     * Creates a 100%-allocation config for a single supplier
     * (means "no switching configured").
     */
    public static RpOtpAttemptConfig otpConfig100Percent(RefOtpSupplier supplier) {
        return otpConfig(supplier, 0, 100);
    }

    /**
     * Builds a sorted two-supplier list matching how getByProofingLevelSorted()
     * returns results: ORDER BY attempts ASC, supplier_id DESC.
     *
     * Caller controls the attempt counts to simulate which supplier is "winning".
     */
    public static List<RpOtpAttemptConfig> twoSupplierSortedList(
            RpOtpAttemptConfig lower, RpOtpAttemptConfig higher) {
        List<RpOtpAttemptConfig> list = new ArrayList<>();
        list.add(lower);   // lower attempts → picked first
        list.add(higher);
        return list;
    }

    // ─── RpInfPvAttemptConfig (rp_inf_pv_attempts) ────────────────────────────

    public static RpInfPvAttemptConfig infConfig(RefOtpSupplier supplier,
                                                  int currentAttempts,
                                                  int totalAttempts) {
        RpInfPvAttemptConfigPK pk = new RpInfPvAttemptConfigPK();
        pk.setSupplierId(supplier.getOtpSupplierId());
        pk.setProofingLevel(LOA_15_CODE);
        pk.setSponsorId(SPONSOR_CUSTREG);

        RpInfPvAttemptConfig cfg = new RpInfPvAttemptConfig();
        cfg.setId(pk);
        cfg.setAttempts(currentAttempts);
        cfg.setTotalAttempts(totalAttempts);
        cfg.setRefOtpSupplier(supplier);
        cfg.setVersion(1L);
        return cfg;
    }

    public static RpInfPvAttemptConfig infConfig100Percent(RefOtpSupplier supplier) {
        return infConfig(supplier, 0, 100);
    }

    // ─── RefSponsorConfiguration ──────────────────────────────────────────────

    /**
     * Creates a sponsor configuration record, e.g. for "Test.Supplier.Options".
     * value format: "Y,<infSupplierId>,<cnfSupplierId>"
     */
    public static RefSponsorConfiguration sponsorConfig(String name, String value) {
        RefSponsorConfiguration cfg = new RefSponsorConfiguration();
        cfg.setName(name);
        cfg.setValue(value);
        return cfg;
    }

    // ─── Convenience list builders ────────────────────────────────────────────

    /**
     * Builds the "all configs" list that isSwitchingConfigured() reads from
     * getByProofingLevel() — this is NOT sorted.
     */
    public static List<RpOtpAttemptConfig> allConfigs(RpOtpAttemptConfig... configs) {
        List<RpOtpAttemptConfig> list = new ArrayList<>();
        for (RpOtpAttemptConfig c : configs) list.add(c);
        return list;
    }

    public static List<RpInfPvAttemptConfig> allInfConfigs(RpInfPvAttemptConfig... configs) {
        List<RpInfPvAttemptConfig> list = new ArrayList<>();
        for (RpInfPvAttemptConfig c : configs) list.add(c);
        return list;
    }
}
