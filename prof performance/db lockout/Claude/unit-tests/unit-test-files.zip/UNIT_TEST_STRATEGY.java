// ============================================================
// FILE 1 of 5: UNIT TEST STRATEGY SUMMARY
// ============================================================
// See full analysis in comments below, then all test classes follow.
// ============================================================

/*
=======================================================================
IPS WEB — UNIT TEST ENABLEMENT PLAN
Senior Java Engineer Analysis — May 2026
=======================================================================

═══════════════════════════════════════════════════════════════════
1. TESTABILITY ASSESSMENT
═══════════════════════════════════════════════════════════════════

EASY TO UNIT TEST (no mocking needed):
  • PersonVo — plain DTO, all fields/flags
  • PhoneVerificationResponse — plain DTO with decision constants
  • RpOtpAttemptConfig / RpInfPvAttemptConfig — entities with getters/setters
  • RefOtpSupplier — entity, has useful boolean flags (isLexisNexisPhone(), isEquifaxDIT(), etc.)
  • RefLoaLevel — simple entity
  • VerificationBean.formatPhoneNumber() — pure function
  • VerificationBean.getLogInfoMapAsString() — pure function on PersonVo

TESTABLE WITH MOCKS (5 services to mock):
  • VerificationProviderServiceImpl ← HIGHEST VALUE, test this first
    - 5 @Autowired dependencies, all mockable
    - All business logic (selection, exclusion, switching check) is pure Java
    - The only side-effect is callingOTP() — which we assert is/isn't called
  • RemoteProofingServiceImpl (RemoteServices) — mockable
  • RemoteSupportServiceImpl — mockable
  • RpInfPvAttemptConfigServiceImpl — mockable
  • OtpAttemptConfigServiceImpl — mockable

HARD TO TEST (JSF context dependency):
  • VerificationUserInfoBean — @SessionScoped, calls FacesContext in init()
    Problem: loadServices() calls FacesContext.getCurrentInstance() and SpringUtil
    Solution: Extract service-loading into a package-private setter (see refactor below)
  • VerificationBean — same FacesContext wiring in every method
  • RoutingController — routeUser() fires in browser-title EL, FacesContext everywhere
  • IPSController (base class) — all session getters/setters use FacesContext or HttpSession

BETTER SUITED FOR INTEGRATION TESTS:
  • Full Spring context boot (ContextLoaderListener, JTA, EclipseLink)
  • Oracle DB connectivity
  • WebSphere J2C credential lookup
  • EntRegSessionFilter SSO validation
  • End-to-end phone verification with real LexisNexis/Equifax vendor calls

═══════════════════════════════════════════════════════════════════
2. RECOMMENDED TEST ARCHITECTURE
═══════════════════════════════════════════════════════════════════

JUnit version: JUnit 4 (NOT JUnit 5)
  Reason: build.gradle uses `testImplementation 'org.mockito:mockito-all:1.10.19'`
  mockito-all:1.10.19 is JUnit 4 era. @RunWith(MockitoJUnitRunner.class) is the correct runner.
  Although JUnit 5 engine is in the build.gradle, mixing JUnit 4 runner style with
  JUnit 5 engine causes problems. The existing SupplierAttemptTrackerTest.java already
  uses @RunWith(MockitoJUnitRunner.class) — follow that same pattern.

  If you want JUnit 5 in the future, bump mockito to 3.x or 4.x and use @ExtendWith(MockitoExtension.class).

Mockito style: Mockito 1.10.19 API (verify, when, never, times, anyList, anyLong)
  Note: anyList() in 1.10.19 does NOT take a type arg — just anyList()

Test placement:
  src/test/java/com/ips/proofing/VerificationProviderServiceImplTest.java   ← main service
  src/test/java/com/ips/proofing/IpsSwitchingLogicTest.java                ← isSwitching* helpers
  src/test/java/com/ips/proofing/InfSupplierSelectionTest.java             ← INF path
  src/test/java/com/ips/test/IpsTestFixtures.java                          ← shared helpers

Gradle test dependency to add to IVSPersistence/build.gradle:
  testImplementation 'junit:junit:4.13.2'
  testImplementation 'org.mockito:mockito-all:1.10.19'
  testImplementation 'org.apache.logging.log4j:log4j-core:2.17.1'

═══════════════════════════════════════════════════════════════════
3. SMALL PRODUCTION REFACTOR (OPTIONAL — for testability)
═══════════════════════════════════════════════════════════════════

The only class with a testability problem in the CORE flow is
VerificationUserInfoBean.loadServices() which calls:
  FacesContext.getCurrentInstance().getExternalContext().getContext()

BEFORE (untestable):
  public void loadServices() {
      ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
      personDataService = (PersonDataDataService) SpringUtil.getInstance(ctx).getBean(PERSON_DATA_DATA_SERVICE);
      ...
  }

AFTER (testable — add a package-private setter for injection in tests):
  // Keep loadServices() unchanged — do NOT break production
  // Add these package-private setters (no annotation needed):

  void injectForTest(
      PersonDataDataService personDataService,
      PersonDataService personService,
      PhoneVerificationService phoneVerificationService,
      ProofingService proofingService,
      RefOtpSupplierDataService supplierService,
      RpDeviceReputationService rpDeviceReputationService,
      RpEventDataService eventService) {
    this.personDataService = personDataService;
    this.personService = personService;
    this.phoneVerificationService = phoneVerificationService;
    this.proofingService = proofingService;
    this.supplierService = supplierService;
    this.rpDeviceReputationService = rpDeviceReputationService;
    this.eventService = eventService;
  }

This is the ONLY production change needed and it adds zero risk —
the method is package-private and has no effect on JSF at runtime.

VerificationProviderServiceImpl needs NO changes — all @Autowired fields
can be injected with Mockito @InjectMocks + @Mock cleanly.

═══════════════════════════════════════════════════════════════════
4. PHASE 1 TESTS (run in < 2 seconds each, no DB, no JSF)
═══════════════════════════════════════════════════════════════════
  VerificationProviderServiceImplTest  — 15 tests
  IpsSwitchingLogicTest               —  8 tests
  InfSupplierSelectionTest            —  7 tests

PHASE 2 TESTS (add after Phase 1 is green):
  RemoteProofingServiceTest            — pending RemoteServices analysis
  SupplierAttemptTrackerTest           — already written (concurrency)
  OtpAttemptConfigServiceTest          — callingOTP / reset behavior

═══════════════════════════════════════════════════════════════════
5. KEY PRODUCTION BEHAVIOR TO VALIDATE
═══════════════════════════════════════════════════════════════════
A. Normal split config (e.g. 60 LN / 40 EFX):
   selectSupplier() picks the one with fewest attempts
   updatePvAttempts() calls callingOTP() exactly once

B. 100% single supplier:
   selectSupplier() returns that supplier
   updatePvAttempts() detects isSwitchingConfigured=false → does NOT call callingOTP()
   THE DB IS NEVER WRITTEN for 100% configs

C. All suppliers at limit:
   selectSupplier() falls back to list.get(0) (the first sorted entry)
   reset() is called first, then callingOTP()

D. excludedSupplierId removes a supplier from the candidate list

E. INF (individualNotFound) flag routes to rpInfPvAttemptConfigService, not otpAttemptConfigService

F. ExperianCustomerNotOnFile removes Experian from the list

G. ExperianErrorResponse with single-supplier config: returns null (cannot route)

H. Empty list: returns null, sets personVo.hasError=true
*/
