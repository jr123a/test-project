package com.ips.proofing;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefSponsor;
import com.ips.entity.RpInfPvAttemptConfig;
import com.ips.entity.RpInfPvAttemptConfigPK;
import com.ips.entity.RpOtpAttemptConfig;
import com.ips.entity.RpOtpAttemptConfigPK;
import com.ips.persistence.common.PersonVo;
import com.ips.service.OtpAttemptConfigService;
import com.ips.service.RefLoaLevelService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;
import com.ips.service.RpInfPvAttemptConfigService;

/**
 * Comprehensive JUnit 4 / Mockito test suite for:
 *   1. SupplierAttemptTracker  — the new in-memory routing counter
 *   2. VerificationProviderServiceImpl — the service that drives supplier selection
 *
 * Coverage targets:
 *   - Happy path supplier selection (split config + 100% config)
 *   - Boundary conditions (0%, 100%, exact boundary counts)
 *   - Null / empty inputs
 *   - DB lock contention no longer reachable (callingOTP never called)
 *   - Cycle reset logic
 *   - INF (Individual-Not-Found) supplier exclusion paths
 *   - Experian Customer-Not-On-File exclusion
 *   - Concurrent increment correctness (Thread-safety)
 *   - Multi-sponsor isolation
 */
@RunWith(MockitoJUnitRunner.class)
public class SupplierAttemptTrackerTest {

    // -------------------------------------------------------------------------
    // Constants mirroring production supplier IDs
    // -------------------------------------------------------------------------
    private static final long EQUIFAX_IDFS_ID    = RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID;
    private static final long EQUIFAX_SMFA_ID    = RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID;
    private static final long LEXISNEXIS_ID      = RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID;
    private static final long EXPERIAN_ID        = RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID;

    private static final long SPONSOR_COA        = 32L;   // Change of Address
    private static final long SPONSOR_OPC        = 2L;    // Operations Center
    private static final long PROOFING_LEVEL     = RefLoaLevel.LOA15_CODE;

    // -------------------------------------------------------------------------
    // Mocks for VerificationProviderServiceImpl dependencies
    // -------------------------------------------------------------------------
    @Mock private RefLoaLevelService             refLoaLevelService;
    @Mock private OtpAttemptConfigService        otpAttemptConfigService;
    @Mock private RefSponsorDataService          refSponsorService;
    @Mock private RpInfPvAttemptConfigService    rpInfPvAttemptConfigService;
    @Mock private RefSponsorConfigurationService refSponsorConfigurationService;

    @InjectMocks
    private VerificationProviderServiceImpl service;

    // The tracker under test — instantiated fresh per test
    private SupplierAttemptTracker tracker;

    // Shared test fixtures
    private RefLoaLevel  loaLevel;
    private RefSponsor   sponsorCoa;
    private PersonVo     personVo;

    // -------------------------------------------------------------------------
    // Setup
    // -------------------------------------------------------------------------
    @Before
    public void setUp() {
        tracker = new SupplierAttemptTracker();

        loaLevel = new RefLoaLevel();
        loaLevel.setLoaCode(PROOFING_LEVEL);

        sponsorCoa = new RefSponsor();
        sponsorCoa.setSponsorId(SPONSOR_COA);

        personVo = new PersonVo();
        personVo.setSponsorId(SPONSOR_COA);
        personVo.setSponsor("COA");
        personVo.setProofingLevelSought((int) PROOFING_LEVEL);
        personVo.setSponsorUserId("testUser123");
    }

    // =========================================================================
    // SECTION 1: SupplierAttemptTracker — Unit Tests
    // =========================================================================

    // --- Happy Path ---

    @Test
    public void tracker_initialGet_returnsZero() {
        int count = tracker.get(SPONSOR_COA, EQUIFAX_IDFS_ID);
        assertEquals("A never-seen key should return 0", 0, count);
    }

    @Test
    public void tracker_incrementAndGet_returnsOne_onFirstCall() {
        int result = tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        assertEquals("First increment should return 1", 1, result);
    }

    @Test
    public void tracker_multipleIncrements_accumulatesCorrectly() {
        tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        int result = tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        assertEquals("Three increments should return 3", 3, result);
    }

    @Test
    public void tracker_reset_setsCountBackToZero() {
        tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        tracker.reset(SPONSOR_COA, EQUIFAX_IDFS_ID);
        assertEquals("After reset, count should be 0", 0, tracker.get(SPONSOR_COA, EQUIFAX_IDFS_ID));
    }

    @Test
    public void tracker_resetAll_resetsAllSuppliersForSponsor() {
        tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        tracker.incrementAndGet(SPONSOR_COA, LEXISNEXIS_ID);
        tracker.incrementAndGet(SPONSOR_COA, LEXISNEXIS_ID);

        List<Long> supplierIds = Arrays.asList(EQUIFAX_IDFS_ID, LEXISNEXIS_ID);
        tracker.resetAll(SPONSOR_COA, supplierIds);

        assertEquals(0, tracker.get(SPONSOR_COA, EQUIFAX_IDFS_ID));
        assertEquals(0, tracker.get(SPONSOR_COA, LEXISNEXIS_ID));
    }

    // --- Multi-Sponsor Isolation ---

    @Test
    public void tracker_differentSponsors_areTrackedIndependently() {
        tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);

        // Operations Center sponsor — same supplier ID, different sponsor
        int opcCount = tracker.get(SPONSOR_OPC, EQUIFAX_IDFS_ID);
        assertEquals("Sponsors must not share counters", 0, opcCount);
    }

    @Test
    public void tracker_reset_onOneSponsor_doesNotAffectOther() {
        tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        tracker.incrementAndGet(SPONSOR_OPC, EQUIFAX_IDFS_ID);

        tracker.reset(SPONSOR_COA, EQUIFAX_IDFS_ID);

        assertEquals("COA should be reset",       0, tracker.get(SPONSOR_COA, EQUIFAX_IDFS_ID));
        assertEquals("OPC should be unaffected",  1, tracker.get(SPONSOR_OPC, EQUIFAX_IDFS_ID));
    }

    // --- Boundary Conditions ---

    @Test
    public void tracker_get_onUnknownSupplier_returnsZero_notException() {
        // Supplier ID that was never touched
        int result = tracker.get(SPONSOR_COA, 9999L);
        assertEquals("Unknown supplier must return 0 safely", 0, result);
    }

    @Test
    public void tracker_reset_onNeverIncrementedKey_doesNotThrow() {
        // Should be a no-op, not NPE
        try {
            tracker.reset(SPONSOR_COA, 9999L);
        } catch (Exception e) {
            fail("reset() on unknown key must not throw: " + e.getMessage());
        }
    }

    @Test
    public void tracker_resetAll_withEmptyList_doesNotThrow() {
        try {
            tracker.resetAll(SPONSOR_COA, Collections.emptyList());
        } catch (Exception e) {
            fail("resetAll() with empty list must not throw: " + e.getMessage());
        }
    }

    @Test
    public void tracker_incrementAndGet_atExactBoundary_isCorrect() {
        // Simulate exactly 60 increments matching totalAttempts=60
        for (int i = 0; i < 60; i++) {
            tracker.incrementAndGet(SPONSOR_COA, LEXISNEXIS_ID);
        }
        assertEquals("Count at boundary should equal totalAttempts",
                60, tracker.get(SPONSOR_COA, LEXISNEXIS_ID));
    }

    // --- Concurrency ---

    @Test
    public void tracker_concurrentIncrements_areThreadSafe() throws InterruptedException {
        int threadCount = 50;
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch doneLatch  = new CountDownLatch(threadCount);
        ExecutorService pool = Executors.newFixedThreadPool(threadCount);

        for (int i = 0; i < threadCount; i++) {
            pool.submit(() -> {
                try {
                    startLatch.await(); // all threads start simultaneously
                    tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    doneLatch.countDown();
                }
            });
        }

        startLatch.countDown(); // release all threads at once
        boolean completed = doneLatch.await(5, TimeUnit.SECONDS);
        pool.shutdown();

        assertTrue("All threads should complete within 5 seconds", completed);
        assertEquals(
            "All 50 concurrent increments must be counted without loss",
            threadCount, tracker.get(SPONSOR_COA, EQUIFAX_IDFS_ID));
    }

    @Test
    public void tracker_concurrentIncrements_acrossMultipleSuppliers_areIndependent()
            throws InterruptedException {

        int perSupplier = 30;
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch doneLatch  = new CountDownLatch(perSupplier * 2);
        ExecutorService pool = Executors.newFixedThreadPool(perSupplier * 2);

        for (int i = 0; i < perSupplier; i++) {
            pool.submit(() -> {
                try { startLatch.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
                doneLatch.countDown();
            });
            pool.submit(() -> {
                try { startLatch.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                tracker.incrementAndGet(SPONSOR_COA, LEXISNEXIS_ID);
                doneLatch.countDown();
            });
        }

        startLatch.countDown();
        doneLatch.await(5, TimeUnit.SECONDS);
        pool.shutdown();

        assertEquals(perSupplier, tracker.get(SPONSOR_COA, EQUIFAX_IDFS_ID));
        assertEquals(perSupplier, tracker.get(SPONSOR_COA, LEXISNEXIS_ID));
    }

    @Test
    public void tracker_concurrentResetAndIncrement_doesNotThrow() throws InterruptedException {
        // Simulates the reset cycle firing mid-load: no NPE or corruption
        int threads = 20;
        CountDownLatch done = new CountDownLatch(threads);
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        AtomicInteger errors = new AtomicInteger(0);

        for (int i = 0; i < threads; i++) {
            final int idx = i;
            pool.submit(() -> {
                try {
                    if (idx % 5 == 0) {
                        tracker.reset(SPONSOR_COA, EQUIFAX_IDFS_ID); // reset every 5th thread
                    } else {
                        tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
                    }
                } catch (Exception e) {
                    errors.incrementAndGet();
                } finally {
                    done.countDown();
                }
            });
        }

        done.await(5, TimeUnit.SECONDS);
        pool.shutdown();
        assertEquals("No exceptions should occur during concurrent reset+increment", 0, errors.get());
    }

    // =========================================================================
    // SECTION 2: VerificationProviderServiceImpl — Integration with Tracker
    // The key assertion in all these tests: otpAttemptConfigService.callingOTP()
    // must NEVER be called — that's the DB UPDATE we eliminated.
    // =========================================================================

    // --- Happy Path: split config, normal flow ---

    @Test
    public void determineVerificationMethod_splitConfig_selectsEquifax_andNeverCallsCallingOTP()
            throws Exception {

        // Arrange: 60% LexisNexis (supplier 6), 40% Equifax (supplier 5)
        // LexisNexis has attempts=0, totalAttempts=60 → should be chosen first
        RpOtpAttemptConfig lexisConfig = buildOtpConfig(LEXISNEXIS_ID, 0, 60);
        RpOtpAttemptConfig equifaxConfig = buildOtpConfig(EQUIFAX_IDFS_ID, 40, 40);

        // Sorted list: ascending by attempts → LexisNexis first (0 < 40)
        List<RpOtpAttemptConfig> sortedList = Arrays.asList(lexisConfig, equifaxConfig);
        List<RpOtpAttemptConfig> allList    = Arrays.asList(lexisConfig, equifaxConfig);

        stubBasicDependencies(allList, sortedList);

        // Act
        RefOtpSupplier result = service.determineVerificationMethod(personVo);

        // Assert
        assertNotNull("Should return a supplier", result);
        assertEquals("LexisNexis should be selected (lowest attempts)",
                LEXISNEXIS_ID, result.getOtpSupplierId());

        // THE CRITICAL ASSERTION: no DB write
        verify(otpAttemptConfigService, never()).callingOTP(any(RpOtpAttemptConfig.class));
        verify(otpAttemptConfigService, never()).reset(anyLong(), anyLong());
    }

    @Test
    public void determineVerificationMethod_splitConfig_cycleReset_switchesToNextSupplier()
            throws Exception {

        // Arrange: LexisNexis has reached its limit (attempts == totalAttempts)
        RpOtpAttemptConfig lexisConfig  = buildOtpConfig(LEXISNEXIS_ID,  60, 60); // at limit
        RpOtpAttemptConfig equifaxConfig = buildOtpConfig(EQUIFAX_IDFS_ID, 38, 40); // under limit

        // Sorted: Equifax first (38 < 60)
        List<RpOtpAttemptConfig> sortedList = Arrays.asList(equifaxConfig, lexisConfig);
        List<RpOtpAttemptConfig> allList    = Arrays.asList(lexisConfig, equifaxConfig);

        stubBasicDependencies(allList, sortedList);

        RefOtpSupplier result = service.determineVerificationMethod(personVo);

        assertNotNull(result);
        assertEquals("Equifax should be selected when LexisNexis is at limit",
                EQUIFAX_IDFS_ID, result.getOtpSupplierId());
        verify(otpAttemptConfigService, never()).callingOTP(any());
    }

    // --- Happy Path: 100% config (no switching, no tracker needed) ---

    @Test
    public void determineVerificationMethod_100PercentConfig_selectsSingleSupplier_noTrackerWrite()
            throws Exception {

        // totalAttempts=100 means 100% → single supplier, no counter updates
        RpOtpAttemptConfig equifaxOnly = buildOtpConfig(EQUIFAX_IDFS_ID, 0, 100);
        List<RpOtpAttemptConfig> allList    = Collections.singletonList(equifaxOnly);
        List<RpOtpAttemptConfig> sortedList = Collections.singletonList(equifaxOnly);

        stubBasicDependencies(allList, sortedList);

        RefOtpSupplier result = service.determineVerificationMethod(personVo);

        assertNotNull(result);
        assertEquals(EQUIFAX_IDFS_ID, result.getOtpSupplierId());
        // isSwitchingConfigured returns false → updatePvAttempts exits immediately
        verify(otpAttemptConfigService, never()).callingOTP(any());
        verify(otpAttemptConfigService, never()).reset(anyLong(), anyLong());
    }

    // --- Negative: empty supplier list returns null gracefully ---

    @Test
    public void determineVerificationMethod_emptySupplierList_returnsNull_doesNotThrow()
            throws Exception {

        when(refLoaLevelService.findByLevel(anyInt())).thenReturn(loaLevel);
        when(refSponsorService.findBySponsorName(anyString())).thenReturn(sponsorCoa);
        when(otpAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
                .thenReturn(Collections.emptyList());
        when(otpAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
                .thenReturn(Collections.emptyList());

        RefOtpSupplier result = service.determineVerificationMethod(personVo);

        assertNull("Empty supplier list should return null, not throw", result);
        assertTrue("PersonVo should have error set", personVo.isHasError());
        verify(otpAttemptConfigService, never()).callingOTP(any());
    }

    // --- Negative: null PersonVo fields ---

    @Test
    public void determineVerificationMethod_nullSponsor_setsErrorAndReturnsNull() {
        personVo.setSponsor(null);
        when(refLoaLevelService.findByLevel(anyInt())).thenReturn(loaLevel);
        when(refSponsorService.findBySponsorName(null)).thenReturn(null);

        // Should not throw — top-level catch handles it
        RefOtpSupplier result = service.determineVerificationMethod(personVo);

        assertNull("Null sponsor should result in null return", result);
    }

    @Test
    public void determineVerificationMethod_nullLoaLevel_setsErrorAndReturnsNull() {
        when(refLoaLevelService.findByLevel(anyInt())).thenReturn(null);
        when(refSponsorService.findBySponsorName(anyString())).thenReturn(sponsorCoa);

        RefOtpSupplier result = service.determineVerificationMethod(personVo);

        assertNull("Null LoaLevel should be handled without unchecked exception propagation", result);
    }

    // --- Negative: excluded supplier removed from routing ---

    @Test
    public void determineVerificationMethod_withExcludedSupplierId_doesNotSelectExcluded()
            throws Exception {

        // Exclude LexisNexis — only Equifax remains
        RpOtpAttemptConfig equifaxConfig = buildOtpConfig(EQUIFAX_IDFS_ID, 0, 40);
        List<RpOtpAttemptConfig> sortedList = Collections.singletonList(equifaxConfig);
        List<RpOtpAttemptConfig> allList    = Collections.singletonList(equifaxConfig);

        when(refLoaLevelService.findByLevel(anyInt())).thenReturn(loaLevel);
        when(refSponsorService.findBySponsorName(anyString())).thenReturn(sponsorCoa);
        when(otpAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
                .thenReturn(sortedList);
        when(otpAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
                .thenReturn(allList);

        // Pass LexisNexis as excluded
        RefOtpSupplier result = service.determineVerificationMethod(personVo, LEXISNEXIS_ID);

        assertNotNull(result);
        assertNotEquals("LexisNexis must not be selected when excluded",
                LEXISNEXIS_ID, result.getOtpSupplierId());
        assertEquals(EQUIFAX_IDFS_ID, result.getOtpSupplierId());
    }

    // --- INF Path: LexisNexis Individual-Not-Found ---

    @Test
    public void determineVerificationMethod_lexisNexisIndividualNotFound_excludesLexisNexis()
            throws Exception {

        personVo.setLexisNexisIndividualNotFound(true);

        RpInfPvAttemptConfig equifaxInfConfig = buildInfConfig(EQUIFAX_IDFS_ID, 0, 40);
        List<RpInfPvAttemptConfig> infList = Collections.singletonList(equifaxInfConfig);
        List<RpInfPvAttemptConfig> allInfList = Collections.singletonList(equifaxInfConfig);

        when(refLoaLevelService.findByLevel(anyInt())).thenReturn(loaLevel);
        when(refSponsorService.findBySponsorName(anyString())).thenReturn(sponsorCoa);
        when(rpInfPvAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
                .thenReturn(infList);
        when(rpInfPvAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
                .thenReturn(allInfList);

        RefOtpSupplier result = service.determineVerificationMethod(personVo);

        assertNotNull("Should find an alternative supplier", result);
        assertNotEquals("LexisNexis must not be selected after INF flag",
                LEXISNEXIS_ID, result.getOtpSupplierId());
        // Confirm no DB writes on INF path either
        verify(rpInfPvAttemptConfigService, never()).callingOTP(any(RpInfPvAttemptConfig.class));
    }

    // --- INF Path: Experian Customer-Not-On-File ---

    @Test
    public void determineVerificationMethod_experianCustomerNotOnFile_returnsNull_ifExperianSelected()
            throws Exception {

        personVo.setExperianCustomerNotOnFile(true);

        // The only supplier in list is Experian — method should return null (can't retry same)
        RpInfPvAttemptConfig experianConfig = buildInfConfig(EXPERIAN_ID, 0, 60);
        experianConfig.getRefOtpSupplier().setExperianPhone(true); // triggers early return

        List<RpInfPvAttemptConfig> infList = Collections.singletonList(experianConfig);
        List<RpInfPvAttemptConfig> allInfList = Collections.singletonList(experianConfig);

        when(refLoaLevelService.findByLevel(anyInt())).thenReturn(loaLevel);
        when(refSponsorService.findBySponsorName(anyString())).thenReturn(sponsorCoa);
        when(rpInfPvAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
                .thenReturn(infList);
        when(rpInfPvAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
                .thenReturn(allInfList);

        RefOtpSupplier result = service.determineVerificationMethod(personVo);

        assertNull("Should return null when Experian is chosen but CNF flag is set", result);
    }

    // --- Verification that old lock-causing path no longer exists ---

    @Test
    public void verifyFix_callingOTP_isNeverInvoked_underSplitConfig() throws Exception {
        // This test is the direct proof that Problem B is fixed.
        // Under a 60/40 split with normal in-memory tracking, the DB UPDATE (callingOTP) 
        // must have ZERO invocations across multiple simulated transactions.

        RpOtpAttemptConfig lexisConfig   = buildOtpConfig(LEXISNEXIS_ID,  0, 60);
        RpOtpAttemptConfig equifaxConfig = buildOtpConfig(EQUIFAX_IDFS_ID, 0, 40);
        List<RpOtpAttemptConfig> allList    = Arrays.asList(lexisConfig, equifaxConfig);
        List<RpOtpAttemptConfig> sortedList = Arrays.asList(lexisConfig, equifaxConfig);

        stubBasicDependencies(allList, sortedList);

        // Simulate 10 transactions
        for (int i = 0; i < 10; i++) {
            service.determineVerificationMethod(personVo);
        }

        // THE PROOF: zero DB writes across all 10 calls
        verify(otpAttemptConfigService, never()).callingOTP(any(RpOtpAttemptConfig.class));
        verify(otpAttemptConfigService, never()).reset(anyLong(), anyLong());
    }

    @Test
    public void verifyFix_noOracleRowLock_under100ConcurrentRequests()
            throws InterruptedException, Exception {

        // Simulate 100 concurrent calls hitting determineVerificationMethod.
        // Before fix: all 100 would call callingOTP() → Oracle row lock → 504s.
        // After fix: callingOTP() count must remain 0.

        RpOtpAttemptConfig lexisConfig   = buildOtpConfig(LEXISNEXIS_ID,  0, 60);
        RpOtpAttemptConfig equifaxConfig = buildOtpConfig(EQUIFAX_IDFS_ID, 0, 40);
        List<RpOtpAttemptConfig> allList    = Arrays.asList(lexisConfig, equifaxConfig);
        List<RpOtpAttemptConfig> sortedList = Arrays.asList(lexisConfig, equifaxConfig);

        stubBasicDependencies(allList, sortedList);

        int threadCount = 100;
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch doneLatch  = new CountDownLatch(threadCount);
        AtomicInteger errors = new AtomicInteger(0);

        ExecutorService pool = Executors.newFixedThreadPool(threadCount);

        for (int i = 0; i < threadCount; i++) {
            pool.submit(() -> {
                try {
                    startLatch.await();
                    PersonVo threadPersonVo = new PersonVo();
                    threadPersonVo.setSponsorId(SPONSOR_COA);
                    threadPersonVo.setSponsor("COA");
                    threadPersonVo.setProofingLevelSought((int) PROOFING_LEVEL);
                    threadPersonVo.setSponsorUserId("concurrentUser");
                    service.determineVerificationMethod(threadPersonVo);
                } catch (Exception e) {
                    errors.incrementAndGet();
                } finally {
                    doneLatch.countDown();
                }
            });
        }

        startLatch.countDown();
        boolean completed = doneLatch.await(10, TimeUnit.SECONDS);
        pool.shutdown();

        assertTrue("All 100 threads should complete in time", completed);
        assertEquals("No exceptions during concurrent execution", 0, errors.get());
        // Zero DB row locks
        verify(otpAttemptConfigService, never()).callingOTP(any(RpOtpAttemptConfig.class));
    }

    // =========================================================================
    // SECTION 3: Cycle Reset Logic — Tracker-driven boundary tests
    // =========================================================================

    @Test
    public void tracker_cycleReset_afterEquifaxReachesLimit_resetsAndContinues() {
        // Equifax totalAttempts = 40. Simulate it hitting 40.
        for (int i = 0; i < 40; i++) {
            tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        }
        assertEquals(40, tracker.get(SPONSOR_COA, EQUIFAX_IDFS_ID));

        // Simulate the reset that updatePvAttempts fires when current >= totalAttempts
        tracker.reset(SPONSOR_COA, EQUIFAX_IDFS_ID);
        tracker.reset(SPONSOR_COA, LEXISNEXIS_ID);

        // After reset, both should be back to 0
        assertEquals(0, tracker.get(SPONSOR_COA, EQUIFAX_IDFS_ID));
        assertEquals(0, tracker.get(SPONSOR_COA, LEXISNEXIS_ID));

        // Immediately usable again
        int next = tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        assertEquals(1, next);
    }

    @Test
    public void tracker_oneAboveBoundary_isHandledCorrectly() {
        // attempts = totalAttempts + 1 means we're past the threshold
        for (int i = 0; i < 41; i++) {
            tracker.incrementAndGet(SPONSOR_COA, EQUIFAX_IDFS_ID);
        }
        int count = tracker.get(SPONSOR_COA, EQUIFAX_IDFS_ID);
        assertTrue("Count should be >= totalAttempts (40)", count >= 40);
    }

    // =========================================================================
    // Helpers: builder methods for test entities
    // =========================================================================

    private RpOtpAttemptConfig buildOtpConfig(long supplierId, int attempts, int totalAttempts) {
        RefOtpSupplier supplier = new RefOtpSupplier();
        supplier.setOtpSupplierId(supplierId);
        supplier.setOtpSupplierName(resolveSupplierName(supplierId));

        RpOtpAttemptConfigPK pk = new RpOtpAttemptConfigPK();
        pk.setSupplierId(supplierId);
        pk.setProofingLevel(PROOFING_LEVEL);
        pk.setSponsorId(SPONSOR_COA);

        RpOtpAttemptConfig config = new RpOtpAttemptConfig();
        config.setId(pk);
        config.setAttempts(attempts);
        config.setTotalAttempts(totalAttempts);
        config.setRefOtpSupplier(supplier);
        return config;
    }

    private RpInfPvAttemptConfig buildInfConfig(long supplierId, int attempts, int totalAttempts) {
        RefOtpSupplier supplier = new RefOtpSupplier();
        supplier.setOtpSupplierId(supplierId);
        supplier.setOtpSupplierName(resolveSupplierName(supplierId));

        RpInfPvAttemptConfigPK pk = new RpInfPvAttemptConfigPK();
        pk.setSupplierId(supplierId);
        pk.setProofingLevel(PROOFING_LEVEL);
        pk.setSponsorId(SPONSOR_COA);

        RpInfPvAttemptConfig config = new RpInfPvAttemptConfig();
        config.setId(pk);
        config.setAttempts(attempts);
        config.setTotalAttempts(totalAttempts);
        config.setRefOtpSupplier(supplier);
        return config;
    }

    private String resolveSupplierName(long supplierId) {
        if (supplierId == EQUIFAX_IDFS_ID)  return "Equifax IDFS OTP";
        if (supplierId == EQUIFAX_SMFA_ID)  return "Equifax DIT SMFA";
        if (supplierId == LEXISNEXIS_ID)    return "LexisNexis RDP OTP";
        if (supplierId == EXPERIAN_ID)      return "Experian CrossCore";
        return "Unknown Supplier";
    }

    /**
     * Stubs the minimal set of service calls needed for a standard non-INF
     * supplier selection flow with split config (totalAttempts != 100).
     */
    private void stubBasicDependencies(List<RpOtpAttemptConfig> allList,
                                       List<RpOtpAttemptConfig> sortedList) {
        when(refLoaLevelService.findByLevel(anyInt())).thenReturn(loaLevel);
        when(refSponsorService.findBySponsorName(anyString())).thenReturn(sponsorCoa);
        when(otpAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
                .thenReturn(sortedList);
        when(otpAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
                .thenReturn(allList);
    }
}
