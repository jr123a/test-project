package com.ips.proofing;

import static com.ips.test.IpsTestFixtures.*;
import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefSponsor;
import com.ips.entity.RpInfPvAttemptConfig;
import com.ips.persistence.common.PersonVo;
import com.ips.service.OtpAttemptConfigService;
import com.ips.service.RefLoaLevelService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;
import com.ips.service.RpInfPvAttemptConfigService;
import com.ips.test.IpsTestFixtures;

/**
 * Unit tests for the INF (Individual-Not-Found) and
 * CNF (Customer-Not-On-File) supplier-selection branches
 * in VerificationProviderServiceImpl.
 *
 * When LexisNexis returns INDIVIDUAL_NOT_FOUND or
 * Experian returns CUSTOMER_NOT_ON_FILE, the system
 * switches to the rpInfPvAttemptConfigService (NOT
 * the normal otpAttemptConfigService) and excludes
 * the failing supplier from the candidate list.
 *
 * These tests confirm:
 *   1. INF flag → uses INF service, removes LexisNexis
 *   2. CNF flag → uses INF service, removes Experian
 *   3. Both INF+CNF → removes both suppliers
 *   4. Experian CNF selected but is Experian → returns null (guard)
 *   5. Single INF supplier at 100% → no DB write
 *   6. Empty INF list → returns null
 *   7. Normal path (no flags) → uses OTP service, not INF
 */
@RunWith(MockitoJUnitRunner.class)
public class InfSupplierSelectionTest {

    @InjectMocks
    private VerificationProviderServiceImpl service;

    @Mock private RefLoaLevelService             refLoaLevelService;
    @Mock private OtpAttemptConfigService        otpAttemptConfigService;
    @Mock private RefSponsorDataService          refSponsorService;
    @Mock private RpInfPvAttemptConfigService    rpInfPvAttemptConfigService;
    @Mock private RefSponsorConfigurationService refSponsorConfigurationService;

    private RefLoaLevel    loa15;
    private RefSponsor     sponsorCustReg;
    private RefOtpSupplier lexisNexis;
    private RefOtpSupplier equifaxIdfs;
    private RefOtpSupplier experian;
    private RefOtpSupplier equifaxSmfa;

    @Before
    public void setUp() {
        loa15          = IpsTestFixtures.loaLevel15();
        sponsorCustReg = IpsTestFixtures.custRegSponsor();
        lexisNexis     = IpsTestFixtures.lexisNexisSupplier();
        equifaxIdfs    = IpsTestFixtures.equifaxIdfsSupplier();
        experian       = IpsTestFixtures.experianSupplier();
        equifaxSmfa    = IpsTestFixtures.equifaxSmfaSupplier();

        when(refLoaLevelService.findByLevel(anyInt())).thenReturn(loa15);
        when(refSponsorService.findBySponsorName(anyString())).thenReturn(sponsorCustReg);

        // Production code checks environment for non-PROD test overrides.
        // Return null so the test-supplier-options block is skipped (cfg == null).
        when(refSponsorConfigurationService.getConfigRecord(anyInt(), eq("Test.Supplier.Options")))
            .thenReturn(null);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 1 — LexisNexis INF: routes to INF service, removes LexisNexis
    // ═══════════════════════════════════════════════════════════════════════

    @Test
    public void determineVerificationMethod_shouldUseInfService_whenLexisNexisIndividualNotFound() {
        PersonVo pv = personVoWithLexisNexisINF("infUser", SPONSOR_CUSTREG);

        // INF switching configured: neither at 100%
        RpInfPvAttemptConfig efxInfConfig = infConfig(equifaxIdfs, 0, 60);
        when(rpInfPvAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
            .thenReturn(allInfConfigs(efxInfConfig));
        // Sorted list without LexisNexis
        when(rpInfPvAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
            .thenReturn(Arrays.asList(efxInfConfig));

        RefOtpSupplier result = service.determineVerificationMethod(pv);

        assertNotNull(result);
        assertEquals("Should select Equifax (LexisNexis excluded due to INF)",
            SUPPLIER_EQUIFAX_IDFS, result.getOtpSupplierId());

        // INF service must be called, normal OTP service must NOT be for sorted query
        verify(rpInfPvAttemptConfigService, times(1))
            .getByProofingLevelSorted(anyList(), anyLong(), anyLong());
        verify(otpAttemptConfigService, never())
            .getByProofingLevelSorted(anyList(), anyLong(), anyLong());
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 2 — Experian CNF: routes to INF service, removes Experian
    // ═══════════════════════════════════════════════════════════════════════

    @Test
    public void determineVerificationMethod_shouldUseInfService_whenExperianCustomerNotOnFile() {
        PersonVo pv = personVoWithExperianCNF("cnfUser", SPONSOR_CUSTREG);

        RpInfPvAttemptConfig lnInfConfig = infConfig(lexisNexis, 0, 60);
        when(rpInfPvAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
            .thenReturn(allInfConfigs(lnInfConfig));
        when(rpInfPvAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
            .thenReturn(Arrays.asList(lnInfConfig));

        RefOtpSupplier result = service.determineVerificationMethod(pv);

        assertNotNull(result);
        assertEquals("Should select LexisNexis (Experian excluded due to CNF)",
            SUPPLIER_LEXISNEXIS, result.getOtpSupplierId());

        verify(rpInfPvAttemptConfigService).getByProofingLevelSorted(anyList(), anyLong(), anyLong());
        verify(otpAttemptConfigService, never()).getByProofingLevelSorted(anyList(), anyLong(), anyLong());
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 3 — Both CNF and INF flags: removes both suppliers
    // ═══════════════════════════════════════════════════════════════════════

    @Test
    public void determineVerificationMethod_shouldRemoveBothSuppliers_whenBothCnfAndInfFlagsSet() {
        // Arrange: both Experian CNF and LexisNexis INF set
        PersonVo pv = personVoWithExperianCNF("bothFlags", SPONSOR_CUSTREG);
        pv.setLexisNexisIndividualNotFound(true); // also set INF

        RpInfPvAttemptConfig efxConfig = infConfig(equifaxIdfs, 0, 40);

        when(rpInfPvAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
            .thenReturn(allInfConfigs(efxConfig));
        when(rpInfPvAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
            .thenReturn(Arrays.asList(efxConfig));

        RefOtpSupplier result = service.determineVerificationMethod(pv);

        // Only Equifax IDFS remains (Experian + LexisNexis both excluded)
        assertNotNull(result);
        assertEquals(SUPPLIER_EQUIFAX_IDFS, result.getOtpSupplierId());
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 4 — CNF guard: if selected supplier is still Experian → return null
    // ═══════════════════════════════════════════════════════════════════════

    @Test
    public void determineVerificationMethod_shouldReturnNull_whenCnfAndSelectedSupplierIsStillExperian() {
        // This tests the guard:
        //   if (personVo.isExperianCustomerNotOnFile()
        //       && selectedSupplier.isExperianPhone()) return null;
        // Scenario: isSwitchingInfSupplierConfigured = false (Experian at 100%)
        //           so Experian is kept in the list and selected
        PersonVo pv = personVoWithExperianCNF("guardUser", SPONSOR_CUSTREG);

        RpInfPvAttemptConfig expConfig100 = infConfig100Percent(experian);

        // isSwitchingInfSupplierConfigured detects 100% → returns false → Experian NOT removed
        when(rpInfPvAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
            .thenReturn(allInfConfigs(expConfig100));
        when(rpInfPvAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
            .thenReturn(Arrays.asList(expConfig100));

        RefOtpSupplier result = service.determineVerificationMethod(pv);

        // Post-selection guard: selectedSupplier.isExperianPhone() is true + CNF → null
        assertNull("Guard must return null when selected supplier is still Experian with CNF", result);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 5 — Single INF supplier at 100%: no DB write
    // ═══════════════════════════════════════════════════════════════════════

    @Test
    public void determineVerificationMethod_shouldNotCallInfCallingOTP_whenInfSupplierAt100Percent() {
        PersonVo pv = personVoWithLexisNexisINF("infUser100", SPONSOR_CUSTREG);

        RpInfPvAttemptConfig efxConfig100 = infConfig100Percent(equifaxIdfs);

        // isSwitchingInfSupplierConfigured → 100% found → false
        when(rpInfPvAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
            .thenReturn(allInfConfigs(efxConfig100));
        when(rpInfPvAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
            .thenReturn(Arrays.asList(efxConfig100));

        RefOtpSupplier result = service.determineVerificationMethod(pv);

        assertNotNull(result);
        assertEquals(SUPPLIER_EQUIFAX_IDFS, result.getOtpSupplierId());

        // No DB write for 100% single-supplier INF config either
        verify(rpInfPvAttemptConfigService, never()).callingOTP(any(RpInfPvAttemptConfig.class));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 6 — Empty INF list: returns null
    // ═══════════════════════════════════════════════════════════════════════

    @Test
    public void determineVerificationMethod_shouldReturnNull_whenInfListIsEmpty() {
        PersonVo pv = personVoWithLexisNexisINF("emptyInfUser", SPONSOR_CUSTREG);

        when(rpInfPvAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
            .thenReturn(allInfConfigs());
        when(rpInfPvAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
            .thenReturn(Collections.emptyList());

        RefOtpSupplier result = service.determineVerificationMethod(pv);

        assertNull("Empty INF list → null", result);
        verify(rpInfPvAttemptConfigService, never()).callingOTP(any(RpInfPvAttemptConfig.class));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 7 — Normal flag-free path: uses OTP service, NOT INF service
    // ═══════════════════════════════════════════════════════════════════════

    @Test
    public void determineVerificationMethod_shouldUseOtpService_whenNoInfOrCnfFlagsSet() {
        // Normal user, no flags
        PersonVo pv = IpsTestFixtures.personVo("normalUser", SPONSOR_CUSTREG);

        RpOtpAttemptConfig lnConfig = otpConfig100Percent(lexisNexis);
        when(otpAttemptConfigService.getByProofingLevel(anyLong(), anyLong()))
            .thenReturn(allConfigs(lnConfig));
        when(otpAttemptConfigService.getByProofingLevelSorted(anyList(), anyLong(), anyLong()))
            .thenReturn(Arrays.asList(lnConfig));

        service.determineVerificationMethod(pv);

        // INF service must NEVER be called for a normal user
        verify(rpInfPvAttemptConfigService, never())
            .getByProofingLevelSorted(anyList(), anyLong(), anyLong());
        verify(rpInfPvAttemptConfigService, never())
            .getByProofingLevel(anyLong(), anyLong());

        // OTP service must be called
        verify(otpAttemptConfigService, times(1))
            .getByProofingLevelSorted(anyList(), anyLong(), anyLong());
    }
}
