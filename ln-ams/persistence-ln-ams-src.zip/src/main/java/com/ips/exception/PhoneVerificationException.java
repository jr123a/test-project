package com.ips.exception;

public class PhoneVerificationException extends Exception {

    private static final long serialVersionUID = 1L;
    private final String message;
    
    public PhoneVerificationException(String message){
        this.message = message;
    }

    @Override
    public String getMessage() {        
        return message;
    }
}
