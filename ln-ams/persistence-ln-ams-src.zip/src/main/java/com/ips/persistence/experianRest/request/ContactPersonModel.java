package com.ips.persistence.experianRest.request;

import java.io.Serializable;
import java.util.List;

public class ContactPersonModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String typeOfPerson;	        //Mandatory:N, Max Length:40
	private String personIdentifier;	//Mandatory:N, Max Length:40
	private List<PersonNameModel> names;	//Mandatory:N, Max Length:100

	public String getTypeOfPerson() {
		return typeOfPerson;
	}
	
	public void setTypeOfPerson(String typeOfPerson) {
		this.typeOfPerson = typeOfPerson;
	}

	public String getPersonIdentifier() {
		return personIdentifier;
	}

	public void setPersonIdentifier(String personIdentifier) {
		this.personIdentifier = personIdentifier;
	}

	public List<PersonNameModel> getNames() {
		return names;
	}

	public void setNames(List<PersonNameModel> names) {
		this.names = names;
	}
	
}
