package com.ips.persistence.experianRest.request;

import java.io.Serializable;

public class ApplicationApplicantModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String id;	      
	private String contactId;	      
	private String applicantType;	  
	private String consentId;	  
	private String consentTimeStamp;	  
    	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getContactId() {
		return contactId;
	}
	
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public String getApplicantType() {
		return applicantType;
	}

	public void setApplicantType(String applicantType) {
		this.applicantType = applicantType;
	}

	public String getConsentId() {
		return consentId;
	}

	public String getConsentTimeStamp() {
		return consentTimeStamp;
	}

	public void setConsentId(String consentId) {
		this.consentId = consentId;
	}

	public void setConsentTimeStamp(String consentTimeStamp) {
		this.consentTimeStamp = consentTimeStamp;
	}
		
}
