package com.ips.persistence.common;

import java.io.Serializable;

public class OAuthResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String access_token; 
	private long expires_in_secs; 
	private String scope;
	private String efxErrorCode;
	private String description;
		   
	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public long getExpires_in_secs() {
		return expires_in_secs;
	}

	public void setExpires_in_secs(long expires_in_secs) {
		this.expires_in_secs = expires_in_secs;
	}

	public String getScope() {
		return scope;
	}
	
	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getEfxErrorCode() {
		return efxErrorCode;
	}

	public void setEfxErrorCode(String efxErrorCode) {
		this.efxErrorCode = efxErrorCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
