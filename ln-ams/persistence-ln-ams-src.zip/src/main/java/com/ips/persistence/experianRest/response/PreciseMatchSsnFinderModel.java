package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchSsnFinderModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseMatchSsnFinderSummaryModel summary;	           //Max Length:8

	public PreciseMatchSsnFinderSummaryModel getSummary() {
		return summary;
	}

	public void setSummary(PreciseMatchSsnFinderSummaryModel summary) {
		this.summary = summary;
	}
	
}
