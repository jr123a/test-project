package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchAddressItemModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseMatchAddressSummaryModel summary;	           //Mandatory:Y, Max Length:8
	private PreciseMatchAddressDetailModel detail;
	
	public PreciseMatchAddressSummaryModel getSummary() {
		return summary;
	}
	
	public void setSummary(PreciseMatchAddressSummaryModel summary) {
		this.summary = summary;
	}

	public PreciseMatchAddressDetailModel getDetail() {
		return detail;
	}

	public void setDetail(PreciseMatchAddressDetailModel detail) {
		this.detail = detail;
	}
	
}
