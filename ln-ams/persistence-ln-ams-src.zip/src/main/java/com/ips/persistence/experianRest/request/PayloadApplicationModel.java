package com.ips.persistence.experianRest.request;

import java.io.Serializable;
import java.util.List;

public class PayloadApplicationModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ApplicationProductDetailModel productDetails;
	private String oneTimePasscode;	       
	private List<ApplicationApplicantModel> applicants;	       
	
	public ApplicationProductDetailModel getProductDetails() {
		return productDetails;
	}

	public void setProductDetails(ApplicationProductDetailModel productDetails) {
		this.productDetails = productDetails;
	}
	
	public String getOneTimePasscode() {
		return oneTimePasscode;
	}

	public void setOneTimePasscode(String oneTimePasscode) {
		this.oneTimePasscode = oneTimePasscode;
	}

	public List<ApplicationApplicantModel> getApplicants() {
		return applicants;
	}

	public void setApplicants(List<ApplicationApplicantModel> applicants) {
		this.applicants = applicants;
	}
		
}
