package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchPhoneItemModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseMatchPhoneSummaryModel summary;	           //Max Length:8
	private PreciseMatchPhoneDetailModel detail;
	
	public PreciseMatchPhoneSummaryModel getSummary() {
		return summary;
	}
	
	public void setSummary(PreciseMatchPhoneSummaryModel summary) {
		this.summary = summary;
	}
	
	public PreciseMatchPhoneDetailModel getDetail() {
		return detail;
	}
	
	public void setDetail(PreciseMatchPhoneDetailModel detail) {
		this.detail = detail;
	}
	
}
