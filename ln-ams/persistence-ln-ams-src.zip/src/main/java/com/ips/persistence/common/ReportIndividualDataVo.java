package com.ips.persistence.common;

import java.util.List;

import com.ibm.json.java.JSONObject;
import com.ips.common.common.CustomLogger;

public class ReportIndividualDataVo {

    private int highRiskAddrReviewVol = 0;
    private int highRiskAddrErrorVol = 0;
    private int highRiskAddrTotalReviewVol = 0;
    private int highRiskAddrFailVol = 0;
    private int highRiskAddrTotalVol = 0;
     
    private int tmxDevRepInitPassVol = 0;
	private int tmxDevRepRepeatPassVol = 0;
    private int tmxDevRepTotalPassVol = 0;
    private int tmxDevRepInitReviewVol = 0;
    private int tmxDevRepRepeatReviewVol = 0;
    private int tmxDevRepIndNotFoundVol = 0;
    private int tmxDevRepProfilingDisabledVol = 0;
    private int tmxDevRepErrorVol = 0;
    private int tmxDevRepTotalReviewVol = 0;
    private int tmxDevRepInitFailVol = 0;
    private int tmxDevRepRepeatFailVol = 0;
    private int tmxDevRepTotalFailVol = 0;
    private int tmxDevRepTotalVol = 0;
 
    private int pvLexisNexisInitReviewVol = 0;
    private int pvLexisNexisRepeatReviewVol = 0;
    private int pvLexisNexisTotalReviewVol = 0;
    private int pvLexisNexisInitFailVol = 0;
    private int pvLexisNexisRepeatFailVol = 0;
    private int pvLexisNexisAbandonedVol = 0;
    private int pvLexisNexisErrorVol = 0;
    private int pvLexisNexisTotalFailVol = 0;
    private int pvLexisNexisTotalVol = 0;
    
    private int pvExperianInitPassVol = 0;
    private int pvExperianRepeatPassVol = 0;
    private int pvExperianTotalPassVol = 0;
    private int pvExperianInitReviewVol = 0;
    private int pvExperianRepeatReviewVol = 0;
    private int pvExperianTotalReviewVol = 0;
    private int pvExperianInitFailVol = 0;
    private int pvExperianRepeatFailVol = 0;
    private int pvExperianAbandonedVol = 0;
    private int pvExperianErrorVol = 0;
    private int pvExperianTotalFailVol = 0;
    private int pvExperianTotalVol = 0;
    
    private int pvEquifaxDitInitPassVol = 0;
    private int pvEquifaxDitRepeatPassVol = 0;
    private int pvEquifaxDitTotalPassVol = 0;
    private int pvEquifaxDitInitReviewVol = 0;
    private int pvEquifaxDitRepeatReviewVol = 0;
    private int pvEquifaxDitTotalReviewVol = 0;
    private int pvEquifaxDitInitFailVol = 0;
    private int pvEquifaxDitRepeatFailVol = 0;
    private int pvEquifaxDitAbandonedVol = 0;
    private int pvEquifaxDitErrorVol = 0;
    private int pvEquifaxDitTotalFailVol = 0;
    private int pvEquifaxDitTotalVol = 0;
    
    private int otpLexisNexisPassVol = 0;
    private int otpLexisNexisFailVol = 0;
    private int otpLexisNexisAbandonedVol = 0;
    private int otpLexisNexisErrorVol = 0;
    private int otpLexisNexisTotalFailVol = 0;
    private int otpLexisNexisTotalVol = 0;
    
    private int otpExperianPassVol = 0;
    private int otpExperianFailVol = 0;
    private int otpExperianAbandonedVol = 0;
    private int otpExperianErrorVol = 0;
    private int otpExperianTotalFailVol = 0;
    private int otpExperianTotalVol = 0;
    
    private int mfaEquifaxPassVol = 0;
    private int mfaEquifaxFailVol = 0;
    private int mfaEquifaxAbandonedVol = 0;
    private int mfaEquifaxErrorVol = 0;
    private int mfaEquifaxTotalFailVol = 0;
    private int mfaEquifaxTotalVol = 0;
    
    private List<WorkflowApiDecisionVo> wkflowApiDecisionVoList;

    public void loadData(List<WorkflowApiDecisionVo> wkflowApiDecisionVoList) {
    	/*
    	for (WorkflowApiDecisionVo vo : wkflowApiDecisionVoList) {
			CustomLogger.info(this.getClass(), "ReportIndividualDataVo loadData getRecordKey:" + vo.getRecordKey() + " => getKbaSupplierId:" 
    		+ vo.getKbaSupplierId() + " => getWorkflowApiTypeId:" + vo.getWorkflowApiTypeId() + " => getDecision:" + vo.getDecision() 
    		+ " => getDecisionSource:" + vo.getDecisionSource() 	+ " => getTransactionOriginId:" 
    		+ vo.getTransactionOriginId() + " => getCountSum:" + vo.getCountSum());
    	}
    	*/
		setWkflowApiDecisionVoList(wkflowApiDecisionVoList);
	}
    
    private WorkflowApiDecisionVo getWorkflowApiDecisionVo (String recKey) {
    	WorkflowApiDecisionVo wkflowApiDecisionVo = this.wkflowApiDecisionVoList.stream().filter(decisionVo -> recKey.equalsIgnoreCase(decisionVo.getRecordKey()))
                 .findFirst().orElse(null);

    	return wkflowApiDecisionVo;
 	}
    
    public JSONObject getHighRiskAddrDataJSONObject(String key, String transactionOriginId) {
    	JSONObject resultJSON = new JSONObject();
     	int workflowTypeId = 2; 

    	switch(key) {
    		case "highRiskAddrReview": 
	    		resultJSON.put("volume", getHighRiskAddrReviewVol(getRecordKey(transactionOriginId, workflowTypeId, "REVIEW", "APIResult")));
	        	resultJSON.put("description", "Primary address is low risk. Could proceed to TMX device reputation assessment. Volume should be equal to TMX Assessment total.");
	        	break;
    		case "highRiskAddrError": 
	    		resultJSON.put("volume", getHighRiskAddrErrorVol(getRecordKey(transactionOriginId, workflowTypeId, "REVIEW", "Error")));
	        	resultJSON.put("description", "Error occurred in high risk risk assessment. Could proceed to TMX device reputation assessment for further verification.");
	        	break;
    		case "highRiskAddrTotalReview": 
	    		resultJSON.put("volume", getHighRiskAddrTotalReviewVol());
	        	resultJSON.put("description", "Total volume passed high-risk address verification.");
	        	break;
    		case "highRiskAddrFail": 
	    		resultJSON.put("volume", getHighRiskAddrFailVol(getRecordKey(transactionOriginId, workflowTypeId, "FAIL","APIResult")));
	        	resultJSON.put("description", "Primary address is high risk. Could proceed to IPP opt-in.");
	        	break;
    		case "highRiskAddrTotal": 
	    		resultJSON.put("volume", getHighRiskAddrTotalVol());
	        	resultJSON.put("description", "Total volume started remote proofing. Sum of TotalPass and Fail volume.");
	        	break;
    		default:    
    	}
       	
    	return resultJSON;
	}
    
    public JSONObject getTmxDevRepDataJSONObject(String key, String appIdStr) {
    	JSONObject resultJSON = new JSONObject();
    	int workflowTypeId = 3; 
      	
    	switch(key) {
    		case "tmxDevRepInitPass": 
	    		resultJSON.put("volume", getTmxDevRepInitPassVol(getRecordKey(appIdStr, workflowTypeId, "PASS","APIResult")));
	        	resultJSON.put("description", "Received high confidence in TMX device reputation assessment. Achieved LOA 1.5. No further identity verification.");
	        	break;
    		case "tmxDevRepRepeatPass": 
	    		resultJSON.put("volume", getTmxDevRepRepeatPassVol(getRecordKey(appIdStr, workflowTypeId, "PASS","PreviousResult")));
	        	resultJSON.put("description", "Previously received high confidence in TMX device reputation assessment. Achieved LOA 1.5. No further identity verification.");
	        	break;
    		case "tmxDevRepTotalPass": 
	    		resultJSON.put("volume", getTmxDevRepTotalPassVol());
	        	resultJSON.put("description", "Total volume achived LOA. Sum of TmxPass and RepeatPass volume.");
	        	break;
    		case "tmxDevRepInitReview": 
	    		resultJSON.put("volume", getTmxDevRepInitReviewVol(getRecordKey(appIdStr, workflowTypeId, "REVIEW","APIResult")));
	        	resultJSON.put("description", "TMX device reputation assessment recommended further review. Could proceed to phone verification.");
	        	break;
    		case "tmxDevRepRepeatReview": 
	    		resultJSON.put("volume", getTmxDevRepRepeatReviewVol(getRecordKey(appIdStr, workflowTypeId, "REVIEW","PreviousResult")));
	        	resultJSON.put("description", "Previously got review status. Could proceed to phone verification.");
	        	break;
    		case "tmxDevRepIndNotFound": 
	    		resultJSON.put("volume", getTmxDevRepIndNotFoundVol(getRecordKey(appIdStr, workflowTypeId, "REVIEW","IndNotFound")));
	        	resultJSON.put("description", "TMX returned a failed reason code of individual_not_found. TMX device reputation assessment needs alternate verification. Could proceed to phone verification.");
	        	break;
    		case "tmxDevRepProfilingDisabled": 
	    		resultJSON.put("volume", getTmxDevRepProfilingDisabledVol(getRecordKey(appIdStr, workflowTypeId, "REVIEW","ProfilingDisabled")));
	        	resultJSON.put("description", "TMX user profiling was disabled as per IVS configuration. Could proceed to phone verification.");
	        	break;
    		case "tmxDevRepError": 
   	    		resultJSON.put("volume", getTmxDevRepErrorVol(getRecordKey(appIdStr, workflowTypeId, "REVIEW","Error")));
	        	resultJSON.put("description", "Error occurred at either TMX or IVS side (i.e. communication network error). Could proceed to phone verification.");
	        	break;
    		case "tmxDevRepTotalReview": 
	    		resultJSON.put("volume", getTmxDevRepTotalReviewVol());
	        	resultJSON.put("description", "Total volume assigned a 'Review' status. Sum of all above 'Review' decision volume.");
	        	break;
    		case "tmxDevRepInitFail": 
	    		resultJSON.put("volume", getTmxDevRepInitFailVol(getRecordKey(appIdStr, workflowTypeId, "FAIL","APIResult")));
	        	resultJSON.put("description", "TMX device reputation assessment returned reject status. Could proceed to IPP opt-in.");
	        	break;
    		case "tmxDevRepRepeatFail": 
	    		resultJSON.put("volume", getTmxDevRepRepeatFailVol(getRecordKey(appIdStr, workflowTypeId, "FAIL","PreviousResult")));
	        	resultJSON.put("description", "Previously got reject status. Could proceed to IPP opt-in.");
	        	break;
    		case "tmxDevRepTotalFail": 
	    		resultJSON.put("volume", getTmxDevRepTotalFailVol());
	        	resultJSON.put("description", "Total volume failed TMX device reputation assessment. Sum of TmxReject and RepeatReject volume.");
	        	break;
    		case "tmxDevRepTotal": 
	    		resultJSON.put("volume", getTmxDevRepTotalVol());
	        	resultJSON.put("description", "Total volume started TMX assessment. Sum of TotalTmxPass, TotalReview and TotalFail volume.");
	        	break;
    		default:    
    	}
       	
    	return resultJSON;
	}
    
    public JSONObject getPvLexisNexisDataJSONObject(String key, String appIdStr) {
    	JSONObject resultJSON = new JSONObject();
    	int supplierId = 4; 
    	int workflowTypeId = 4; 
    	
    	switch(key) {
    		case "pvLexisNexisInitReview": 
	    		resultJSON.put("volume", getPvLexisNexisInitReviewVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "REVIEW","APIResult")));
	        	resultJSON.put("description", "Passed LexisNexis phone verification. Could proceed to OTP validation.");
	        	break;
    		case "pvLexisNexisRepeatReview": 
	    		resultJSON.put("volume", getPvLexisNexisRepeatReviewVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "REVIEW","PreviousResult")));
	        	resultJSON.put("description", "Previously passed LexisNexis phone verification. Could proceed to OTP validation.");
	        	break;
    		case "pvLexisNexisTotalReview": 
	    		resultJSON.put("volume", getPvLexisNexisTotalReviewVol());
	        	resultJSON.put("description", "Total volume passed LexisNexis phone verification. Sum of LexisNexisPass and LexisNexisRepeatPass volume.");
	        	break;
    		case "pvLexisNexisInitFail": 
	    		resultJSON.put("volume", getPvLexisNexisInitFailVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","APIResult")));
	        	resultJSON.put("description", "Failed LexisNexis phone verification. Could proceed to IPP opt-in.");
	        	break;
    		case "pvLexisNexisRepeatFail": 
	    		resultJSON.put("volume", getPvLexisNexisRepeatFailVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","PreviousResult")));
	        	resultJSON.put("description", "Previously failed LexisNexis phone verification. Could proceed to OTP validation.");
	        	break;
	        case "pvLexisNexisAbandoned": 
	    		resultJSON.put("volume", getPvLexisNexisAbandonedVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Abandoned")));
	        	resultJSON.put("description", "User abandoned the transaction with LexisNexis (i.e. User did not clicked on the 'Continue' button in phone verification page). Could proceed to IPP opt-in.");
	        	break;
	        case "pvLexisNexisError": 
	    		resultJSON.put("volume", getPvLexisNexisErrorVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Error")));
	        	resultJSON.put("description", "Error occurred at LexisNexis or IVS side (i.e. communication network error, database error). Retry would be attempted. Could proceed to IPP opt-in.");
	        	break;
	        case "pvLexisNexisTotalFail": 
	    		resultJSON.put("volume", getPvLexisNexisTotalFailVol());
	    		resultJSON.put("description", "Total volume failed LexisNexis phone verification. Sum of all above 'Fail' decision volume.");
	        	break;
	        case "pvLexisNexisTotal": 
	    		resultJSON.put("volume", getPvLexisNexisTotalVol());
	    		resultJSON.put("description", "Total volume started LexisNexis phone verification. Sum of TotalPass and TotalFail volume.");
	        	break;
	        default:    
    	}
       	
    	return resultJSON;
	}
    
    public JSONObject getPvExperianDataJSONObject(String key, String appIdStr) {
    	JSONObject resultJSON = new JSONObject();
    	int supplierId = 6; 
    	int workflowTypeId = 4; 
     	
    	switch(key) {
  	        case "pvExperianInitPass": 
	    		resultJSON.put("volume", getPvExperianInitPassVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "PASS","APIResult")));
	    		resultJSON.put("description", "Passed Experian-Twilio silent authentication (SA). Achieved LOA 1.5. No further identity verification.");
	        	break;
	        case "pvExperianRepeatPass": 
	    		resultJSON.put("volume", getPvExperianRepeatPassVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "PASS","PreviousResult")));
	    		resultJSON.put("description", "Previously passed Experian-Twilio silent authentication. Achieved LOA 1.5. No further identity verification.");
	        	break;
	        case "pvExperianTotalPass": 
	    		resultJSON.put("volume", getPvExperianTotalPassVol());
	    		resultJSON.put("description", "Total volume approved with Experian-Twilio silent authentication. Sum of ExperianSA and RepeatExperianSAvolume.");
	        	break;
	        case "pvExperianInitReview": 
	    		resultJSON.put("volume", getPvExperianInitReviewVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "REVIEW","APIResult")));
	    		resultJSON.put("description", "Passed Experian phone verification. Could proceed to OTP validation.");
	        	break;
	        case "pvExperianRepeatReview": 
	    		resultJSON.put("volume", getPvExperianRepeatReviewVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "REVIEW","PreviousResult")));
	    		resultJSON.put("description", "Previously passed Experian phone verification. Could proceed to OTP validation.");
	        	break;
	        case "pvExperianTotalReview": 
	    		resultJSON.put("volume", getPvExperianTotalReviewVol());
	    		resultJSON.put("description", "Total volume passed Experian phone verification. Sum of ExperianPass and ExperianRepeatPass volume.");
	        	break;
	        case "pvExperianInitFail": 
	    		resultJSON.put("volume", getPvExperianInitFailVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","APIResult")));
	    		resultJSON.put("description", "Failed Experian phone verification. Could proceed to IPP opt-in.");
	        	break;
	        case "pvExperianRepeatFail": 
	    		resultJSON.put("volume", getPvExperianRepeatFailVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","PreviousResult")));
	    		resultJSON.put("description", "Previously failed Experian phone verification. Could proceed to OTP validation.");
	        	break;
	        case "pvExperianAbandoned": 
	    		resultJSON.put("volume", getPvExperianAbandonedVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Abandoned")));
	    		resultJSON.put("description", "User abandoned the transaction (i.e. User did not clicked on the 'Continue' button in phone verification page). Could proceed to IPP opt-in.");
	        	break;
	        case "pvExperianError": 
	    		resultJSON.put("volume", getPvExperianErrorVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Error")));
	    		resultJSON.put("description", "Error occurred at Experian or IVS side (i.e. communication network error, database error). Retry would be attempted. Could proceed to IPP opt-in.");
	        	break;
	        case "pvExperianTotalFail": 
	    		resultJSON.put("volume", getPvExperianTotalFailVol());
	    		resultJSON.put("description", "Total volume failed LexisNexis phone verification. Sum of all above 'Fail' decision volume.");
	        	break;
	        case "pvExperianTotal": 
	    		resultJSON.put("volume", getPvExperianTotalVol());
	    		resultJSON.put("description", "Total volume started Experian phone verification. Sum of TotalExperianApprove, TotalExperianPass and TotalExperianFail volume.");
	        	break;
	        default:    
    	}
       	
    	return resultJSON;
	}
    
    public JSONObject getPvEquifaxDitDataJSONObject(String key, String appIdStr) {
    	JSONObject resultJSON = new JSONObject();
    	int supplierId = 5; 
    	int workflowTypeId = 4; 
     	
    	switch(key) {
 	        case "pvEquifaxDitInitPass": 
	    		resultJSON.put("volume", getPvEquifaxDitInitPassVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "PASS","APIResult")));
	    		resultJSON.put("description", "Passed Equifax DIT. Phone, Identity and Address trusts are all positive. Achieved LOA 1.5. No further identity verification.");
	        	break;
	        case "pvEquifaxDitRepeatPass": 
	    		resultJSON.put("volume", getPvEquifaxDitRepeatPassVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "PASS","PreviousResult")));
	    		resultJSON.put("description", "Previously passed Equifax DIT. . Achieved LOA 1.5. No further identity verification.");
	        	break;
	        case "pvEquifaxDitTotalPass": 
	    		resultJSON.put("volume", getPvEquifaxDitTotalPassVol());
	    		resultJSON.put("description", "Total volume approved with Equifax DIT. Sum of EquifaxApprove and RepeatEquifaxApprove volume.");
	        	break;
	        case "pvEquifaxDitInitReview": 
	    		resultJSON.put("volume", getPvEquifaxDitInitReviewVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "REVIEW","APIResult")));
	    		resultJSON.put("description", "Equifax DIT assessment needed further SMFA link validation. Could proceed to SMFA link validation.");
	        	break;
	        case "pvEquifaxDitRepeatReview": 
	    		resultJSON.put("volume", getPvEquifaxDitRepeatReviewVol("4REVIEWPreviousResult"));
	    		resultJSON.put("description", "Previously got Equifax review. Could proceed to SMFA link validation.");
	        	break;
	        case "pvEquifaxDitTotalReview": 
	    		resultJSON.put("volume", getPvEquifaxDitTotalReviewVol());
	    		resultJSON.put("description", "Total volume got Equifax review decision. Sum of EquifaxReview and RepeatEquifaxReview volume.");
	        	break;
	        case "pvEquifaxDitInitFail": 
	    		resultJSON.put("volume", getPvEquifaxDitInitFailVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","APIResult")));
	    		resultJSON.put("description", "Failed Equifax phone verification. Could proceed to IPP opt-in.");
	        	break;
	        case "pvEquifaxDitRepeatFail": 
	    		resultJSON.put("volume", getPvEquifaxDitRepeatFailVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","PreviousResult")));
	    		resultJSON.put("description", "Previously failed Equifax DIT phone verification. Could proceed to OTP validation.");
	        	break;
	        case "pvEquifaxDitAbandoned": 
	    		resultJSON.put("volume", getPvEquifaxDitAbandonedVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Abandoned")));
	    		resultJSON.put("description", "User abandoned the transaction (i.e. User did not clicked on the 'Continue' button in phone verification page). Could proceed to IPP opt-in.");
	        	break;
	        case "pvEquifaxDitError": 
	    		resultJSON.put("volume", getPvEquifaxDitErrorVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Error")));
	    		resultJSON.put("description", "Error occurred at Equifax or IVS side (i.e. communication network error, database error). Retry would be attempted. Could proceed to IPP opt-in.");
	        	break;
	        case "pvEquifaxDitTotalFail": 
	    		resultJSON.put("volume", getPvEquifaxDitTotalFailVol());
	    		resultJSON.put("description", "Total volume failed Equifax phone verification. Sum of all above 'Fail' decision volume.");
	        	break;
	        case "pvEquifaxDitTotal": 
	    		resultJSON.put("volume", getPvEquifaxDitTotalVol());
	    		resultJSON.put("description", "Total volume started Equifax DIT phone verification. Sum of above TotalEquifaxDITApprove, TotalEquifaxDITReview and TotalEquifaxDITFail volume.");
	        	break;
	        default:    
    	}
       	
    	return resultJSON;
	}
    
    public JSONObject getOtpLexisNexisDataJSONObject(String key, String appIdStr) {
    	JSONObject resultJSON = new JSONObject();
    	int supplierId = 4; 
    	int workflowTypeId = 5; 
     	
    	switch(key) {
 	        case "otpLexisNexisPass": 
	    		resultJSON.put("volume", getOtpLexisNexisPassVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "PASS","APIResult")));
	    		resultJSON.put("description", "Passed LexisNexis OTP validation. Achieved LOA 1.5.");
	        	break;
	        case "otpLexisNexisFail": 
	    		resultJSON.put("volume", getOtpLexisNexisFailVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","APIResult")));
	    		resultJSON.put("description", "Failed LexisNexis OTP validation. Could proceed to IPP opt-in.");
	        	break;
	        case "otpLexisNexisAbandoned": 
	    		resultJSON.put("volume", getOtpLexisNexisAbandonedVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Abandoned")));
	    		resultJSON.put("description", "User abandoned the transaction with LexisNexis (i.e. User did not enter the OTP and click on 'Validate' button). Could proceed to IPP opt-in.");
	        	break;
	        case "otpLexisNexisError": 
	    		resultJSON.put("volume", getOtpLexisNexisErrorVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Error")));
	    		resultJSON.put("description", "Error occurred at LexisNexis or IVS side (i.e. communication network error, database error). Could proceed to IPP opt-in. Retry would be attempted requesting new OTP.");
	        	break;
	        case "otpLexisNexisTotalFail": 
	    		resultJSON.put("volume", getOtpLexisNexisTotalFailVol());
	    		resultJSON.put("description", "Total volume started OTP validation with LexisNexis. Sum of all above 'Fail' decision volume.");
	        	break;
	        case "otpLexisNexisTotal": 
	    		resultJSON.put("volume", getOtpLexisNexisTotalVol());
	    		resultJSON.put("description", "Total volume started LexisNexis OTP validation. Sum of above LexisNexisPass and TotalLexisNexisFail volume.");
	        	break;
	        default:    
    	}
       	
    	return resultJSON;
	}
    
    public JSONObject getOtpExperianDataJSONObject(String key, String appIdStr) {
    	JSONObject resultJSON = new JSONObject();
    	int supplierId = 6; 
    	int workflowTypeId = 5; 
     	
    	switch(key) {
 	        case "otpExperianPass": 
	    		resultJSON.put("volume", getOtpExperianPassVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "PASS","APIResult")));
	    		resultJSON.put("description", "Passed Experian OTP validation. Achieved LOA 1.5.");
	        	break;
	        case "otpExperianFail": 
	    		resultJSON.put("volume", getOtpExperianFailVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","APIResult")));
	    		resultJSON.put("description", "Failed Experian OTP validation. Could proceed to IPP opt-in.");
	        	break;
	        case "otpExperianAbandoned": 
	    		resultJSON.put("volume", getOtpExperianAbandonedVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Abandoned")));
	    		resultJSON.put("description", "User abandoned the transaction with Experian (i.e. User did not enter the OTP and click on 'Validate' button). Could proceed to IPP opt-in.");
	        	break;
	        case "otpExperianError": 
	    		resultJSON.put("volume", getOtpExperianErrorVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Error")));
	    		resultJSON.put("description", "Error occurred at Experian or IVS side (i.e. communication network error, database error). Could proceed to IPP opt-in. Retry would be attempted requesting new OTP.");
	        	break;
	        case "otpExperianTotalFail": 
	    		resultJSON.put("volume", getOtpExperianTotalFailVol());
	    		resultJSON.put("description", "Total volume started OTP validation with Experian. Sum of all above 'Fail' decision volume.");
	        	break;
	        case "otpExperianTotal": 
	    		resultJSON.put("volume", getOtpExperianTotalVol());
	    		resultJSON.put("description", "Total volume started Experian OTP validation. Sum of above ExperianPass and TotalExperianFail volume.");
	        	break;
	        default:    
    	}
       	
    	return resultJSON;
	}
    
    public JSONObject getMfaEquifaxDataJSONObject(String key, String appIdStr) {
    	JSONObject resultJSON = new JSONObject();
    	int supplierId = 5; 
    	int workflowTypeId = 6; 
     	
    	switch(key) {
 	        case "mfaEquifaxPass": 
	    		resultJSON.put("volume", getMfaEquifaxPassVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "PASS","APIResult")));
	    		resultJSON.put("description", "Passed Equifax SMFA validation. Achieved LOA 1.5.");
	        	break;
	        case "mfaEquifaxFail": 
	    		resultJSON.put("volume", getMfaEquifaxFailVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","APIResult")));
	    		resultJSON.put("description", "Failed Equifax SMFA validation. Could proceed to IPP opt-in.");
	        	break;
	        case "mfaEquifaxAbandoned": 
	    		resultJSON.put("volume", getMfaEquifaxAbandonedVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Abandoned")));
	    		resultJSON.put("description", "User abandoned the transaction (i.e. User did not enter the OTP and click on 'Validate' button). Could proceed to IPP opt-in.");
	        	break;
	        case "mfaEquifaxError": 
	    		resultJSON.put("volume", getMfaEquifaxErrorVol(getRecordKey(appIdStr, workflowTypeId, supplierId, "FAIL","Error")));
	    		resultJSON.put("description", "Error occurred at Equifax or IVS side (i.e. communication network error, database error). Could proceed to IPP opt-in. Retry would be attempted requesting new OTP.");
	        	break;
	        case "mfaEquifaxTotalFail": 
	    		resultJSON.put("volume", getMfaEquifaxTotalFailVol());
	    		resultJSON.put("description", "Total volume started OTP validation with Equifax. Sum of all above \"Fail\" decision volume.");
	        	break;
	        case "mfaEquifaxTotal": 
	    		resultJSON.put("volume", getMfaEquifaxTotalVol());
	    		resultJSON.put("description", "Total volume started Equifax SMFA validation. Sum of above EquifaxPass and TotalEquifaxFail volume.");
	        	break;	        

    		default:    
    	}
       	
    	return resultJSON;
	}
    
    private String getRecordKey(String transactionOriginId, int workflowTypeId, String decision, String decisionSource) {
     	return String.format("%s%s%s%s", transactionOriginId, workflowTypeId, decision, decisionSource);
    }
    
    private String getRecordKey(String transactionOriginId, int workflowTypeId, int suppierId, String decision, String decisionSource) {
     	return String.format("%s%s%s%s%s", transactionOriginId, workflowTypeId, suppierId, decision, decisionSource);
    }
    
    public int getVolume(String recKey) {
     	WorkflowApiDecisionVo vo = getWorkflowApiDecisionVo(recKey);
    	String countSum = vo != null ? vo.getCountSum() : "0";
    	int volume = Integer.parseInt(countSum);
		return volume;
	}
    
    public int getHighRiskAddrReviewVol(String recKey) {
    	highRiskAddrReviewVol = getVolume(recKey);
		return highRiskAddrReviewVol;
	}
	
    public void setHighRiskAddrReviewVol(int highRiskAddrReviewVol) {
		this.highRiskAddrReviewVol = highRiskAddrReviewVol;
	}
    
    public int getHighRiskAddrErrorVol(String recKey) {
    	highRiskAddrErrorVol = getVolume(recKey);
		return highRiskAddrErrorVol;
	}

	public void setHighRiskAddrErrorVol(int highRiskAddrErrorVol) {
		this.highRiskAddrErrorVol = highRiskAddrErrorVol;
	}

	public int getHighRiskAddrTotalReviewVol() {
		highRiskAddrTotalReviewVol = highRiskAddrReviewVol + highRiskAddrErrorVol;
		return highRiskAddrTotalReviewVol;
	}

	public void setHighRiskAddrTotalReviewVol(int highRiskAddrTotalReviewVol) {
		this.highRiskAddrTotalReviewVol = highRiskAddrTotalReviewVol;
	}
	
	public int getHighRiskAddrFailVol(String recKey) {
		highRiskAddrFailVol = getVolume(recKey);
		return highRiskAddrFailVol;
	}

	public void setHighRiskAddrFailVol(int highRiskAddrFailVol) {
		this.highRiskAddrFailVol = highRiskAddrFailVol;
	}

	public int getHighRiskAddrTotalVol() {
		highRiskAddrTotalVol = highRiskAddrTotalReviewVol + highRiskAddrFailVol;
		return highRiskAddrTotalVol;
	}

	public void setHighRiskAddrTotalVol(int highRiskAddrTotalVol) {
		this.highRiskAddrTotalVol = highRiskAddrTotalVol;
	}

	public int getTmxDevRepInitPassVol(String recKey) {
		tmxDevRepInitPassVol = getVolume(recKey);
		return tmxDevRepInitPassVol;
	}

	public void setTmxDevRepInitPassVol(int tmxDevRepInitPassVol) {
		this.tmxDevRepInitPassVol = tmxDevRepInitPassVol;
	}

	public int getTmxDevRepRepeatPassVol(String recKey) {
		tmxDevRepRepeatPassVol = getVolume(recKey);
		return tmxDevRepRepeatPassVol;
	}

	public void setTmxDevRepRepeatPassVol(int tmxDevRepRepeatPassVol) {
		this.tmxDevRepRepeatPassVol = tmxDevRepRepeatPassVol;
	}

	public int getTmxDevRepTotalPassVol() {
		tmxDevRepTotalPassVol = tmxDevRepInitPassVol + tmxDevRepRepeatPassVol;
		return tmxDevRepTotalPassVol;
	}

	public void setTmxDevRepTotalPassVol(int tmxDevRepTotalPassVol) {
		this.tmxDevRepTotalPassVol = tmxDevRepTotalPassVol;
	}

	public int getTmxDevRepInitReviewVol(String recKey) {
		tmxDevRepInitReviewVol = getVolume(recKey);
		return tmxDevRepInitReviewVol;
	}

	public void setTmxDevRepInitReviewVol(int tmxDevRepInitReviewVol) {
		this.tmxDevRepInitReviewVol = tmxDevRepInitReviewVol;
	}

	public int getTmxDevRepRepeatReviewVol(String recKey) {
		tmxDevRepRepeatReviewVol = getVolume(recKey);
		return tmxDevRepRepeatReviewVol;
	}

	public void setTmxDevRepRepeatReviewVol(int tmxDevRepRepeatReviewVol) {
		this.tmxDevRepRepeatReviewVol = tmxDevRepRepeatReviewVol;
	}

	public int getTmxDevRepIndNotFoundVol(String recKey) {
		tmxDevRepIndNotFoundVol = getVolume(recKey);
		return tmxDevRepIndNotFoundVol;
	}

	public void setTmxDevRepIndNotFoundVol(int tmxDevRepIndNotFoundVol) {
		this.tmxDevRepIndNotFoundVol = tmxDevRepIndNotFoundVol;
	}

	public int getTmxDevRepProfilingDisabledVol(String recKey) {
		tmxDevRepProfilingDisabledVol = getVolume(recKey);
		return tmxDevRepProfilingDisabledVol;
	}

	public void setTmxDevRepProfilingDisabledVol(int tmxDevRepProfilingDisabledVol) {
		this.tmxDevRepProfilingDisabledVol = tmxDevRepProfilingDisabledVol;
	}

	public int getTmxDevRepErrorVol(String recKey) {
		tmxDevRepErrorVol = getVolume(recKey);
		return tmxDevRepErrorVol;
	}

	public void setTmxDevRepErrorVol(int tmxDevRepErrorVol) {
		this.tmxDevRepErrorVol = tmxDevRepErrorVol;
	}

	public int getTmxDevRepTotalReviewVol() {
		tmxDevRepTotalReviewVol = tmxDevRepInitReviewVol + tmxDevRepRepeatReviewVol+ tmxDevRepIndNotFoundVol + tmxDevRepProfilingDisabledVol+ tmxDevRepErrorVol;
		return tmxDevRepTotalReviewVol;
	}

	public void setTmxDevRepTotalReviewVol(int tmxDevRepTotalReviewVol) {
		this.tmxDevRepTotalReviewVol = tmxDevRepTotalReviewVol;
	}

	public int getTmxDevRepInitFailVol(String recKey) {
		tmxDevRepInitFailVol = getVolume(recKey);
		return tmxDevRepInitFailVol;
	}

	public void setTmxDevRepInitFailVol(int tmxDevRepInitFailVol) {
		this.tmxDevRepInitFailVol = tmxDevRepInitFailVol;
	}

	public int getTmxDevRepRepeatFailVol(String recKey) {
		tmxDevRepRepeatFailVol = getVolume(recKey);
		return tmxDevRepRepeatFailVol;
	}

	public void setTmxDevRepRepeatFailVol(int tmxDevRepRepeatFailVol) {
		this.tmxDevRepRepeatFailVol = tmxDevRepRepeatFailVol;
	}

	public int getTmxDevRepTotalFailVol() {
		tmxDevRepTotalFailVol = tmxDevRepInitFailVol + tmxDevRepRepeatFailVol;
		return tmxDevRepTotalFailVol;
	}

	public void setTmxDevRepTotalFailVol(int tmxDevRepTotalFailVol) {
		this.tmxDevRepTotalFailVol = tmxDevRepTotalFailVol;
	}

	public int getTmxDevRepTotalVol() {
		tmxDevRepTotalVol = tmxDevRepTotalPassVol + tmxDevRepTotalReviewVol + tmxDevRepTotalFailVol;
		return tmxDevRepTotalVol;
	}

	public void setTmxDevRepTotalVol(int tmxDevRepTotalVol) {
		this.tmxDevRepTotalVol = tmxDevRepTotalVol;
	}

	public int getPvLexisNexisInitReviewVol(String recKey) {
		pvLexisNexisInitReviewVol = getVolume(recKey);
		return pvLexisNexisInitReviewVol;
	}

	public void setPvLexisNexisInitReviewVol(int pvLexisNexisInitReviewVol) {
		this.pvLexisNexisInitReviewVol = pvLexisNexisInitReviewVol;
	}

	public int getPvLexisNexisRepeatReviewVol(String recKey) {
		pvLexisNexisRepeatReviewVol = getVolume(recKey);
		return pvLexisNexisRepeatReviewVol;
	}

	public void setPvLexisNexisRepeatReviewVol(int pvLexisNexisRepeatReviewVol) {
		this.pvLexisNexisRepeatReviewVol = pvLexisNexisRepeatReviewVol;
	}

	public int getPvLexisNexisTotalReviewVol() {
		pvLexisNexisTotalReviewVol = pvLexisNexisInitReviewVol + pvLexisNexisRepeatReviewVol;
		return pvLexisNexisTotalReviewVol;
	}

	public void setPvLexisNexisTotalReviewVol(int pvLexisNexisTotalReviewVol) {
		this.pvLexisNexisTotalReviewVol = pvLexisNexisTotalReviewVol;
	}

	public int getPvLexisNexisInitFailVol(String recKey) {
		pvLexisNexisInitFailVol = getVolume(recKey);
		return pvLexisNexisInitFailVol;
	}

	public void setPvLexisNexisInitFailVol(int pvLexisNexisInitFailVol) {
		this.pvLexisNexisInitFailVol = pvLexisNexisInitFailVol;
	}

	public int getPvLexisNexisRepeatFailVol(String recKey) {
		pvLexisNexisRepeatFailVol = getVolume(recKey);
		return pvLexisNexisRepeatFailVol;
	}

	public void setPvLexisNexisRepeatFailVol(int pvLexisNexisRepeatFailVol) {
		this.pvLexisNexisRepeatFailVol = pvLexisNexisRepeatFailVol;
	}

	public int getPvLexisNexisAbandonedVol(String recKey) {
		pvLexisNexisAbandonedVol = getVolume(recKey);
		return pvLexisNexisAbandonedVol;
	}

	public void setPvLexisNexisAbandonedVol(int pvLexisNexisAbandonedVol) {
		this.pvLexisNexisAbandonedVol = pvLexisNexisAbandonedVol;
	}

	public int getPvLexisNexisErrorVol(String recKey) {
		pvLexisNexisErrorVol = getVolume(recKey);
		return pvLexisNexisErrorVol;
	}

	public void setPvLexisNexisErrorVol(int pvLexisNexisErrorVol) {
		this.pvLexisNexisErrorVol = pvLexisNexisErrorVol;
	}

	public int getPvLexisNexisTotalFailVol() {
		pvLexisNexisTotalFailVol = pvLexisNexisInitFailVol + pvLexisNexisRepeatFailVol+ pvLexisNexisErrorVol + pvLexisNexisAbandonedVol;
		return pvLexisNexisTotalFailVol;
	}

	public void setPvLexisNexisTotalFailVol(int pvLexisNexisTotalFailVol) {
		this.pvLexisNexisTotalFailVol = pvLexisNexisTotalFailVol;
	}

	public int getPvLexisNexisTotalVol() {
		pvLexisNexisTotalVol = pvLexisNexisTotalReviewVol + pvLexisNexisTotalFailVol;
		return pvLexisNexisTotalVol;
	}

	public void setPvLexisNexisTotalVol(int pvLexisNexisTotalVol) {
		this.pvLexisNexisTotalVol = pvLexisNexisTotalVol;
	}

	public int getPvExperianInitPassVol(String recKey) {
		pvExperianInitPassVol = getVolume(recKey);
		return pvExperianInitPassVol;
	}

	public void setPvExperianInitPassVol(int pvExperianInitPassVol) {
		this.pvExperianInitPassVol = pvExperianInitPassVol;
	}

	public int getPvExperianRepeatPassVol(String recKey) {
		pvExperianRepeatPassVol = getVolume(recKey);
		return pvExperianRepeatPassVol;
	}

	public void setPvExperianRepeatPassVol(int pvExperianRepeatPassVol) {
		this.pvExperianRepeatPassVol = pvExperianRepeatPassVol;
	}

	public int getPvExperianTotalPassVol() {
		pvExperianTotalPassVol = pvExperianInitPassVol + pvExperianRepeatPassVol;
		return pvExperianTotalPassVol;
	}

	public void setPvExperianTotalPassVol(int pvExperianTotalPassVol) {
		this.pvExperianTotalPassVol = pvExperianTotalPassVol;
	}

	public int getPvExperianInitReviewVol(String recKey) {
		pvExperianInitReviewVol = getVolume(recKey);
		return pvExperianInitReviewVol;
	}

	public void setPvExperianInitReviewVol(int pvExperianInitReviewVol) {
		this.pvExperianInitReviewVol = pvExperianInitReviewVol;
	}

	public int getPvExperianRepeatReviewVol(String recKey) {
		pvExperianRepeatReviewVol = getVolume(recKey);
		return pvExperianRepeatReviewVol;
	}

	public void setPvExperianRepeatReviewVol(int pvExperianRepeatReviewVol) {
		this.pvExperianRepeatReviewVol = pvExperianRepeatReviewVol;
	}

	public int getPvExperianTotalReviewVol() {
		pvExperianTotalReviewVol = pvExperianInitReviewVol + pvExperianRepeatReviewVol;
		return pvExperianTotalReviewVol;
	}

	public void setPvExperianTotalReviewVol(int pvExperianTotalReviewVol) {
		this.pvExperianTotalReviewVol = pvExperianTotalReviewVol;
	}

	public int getPvExperianInitFailVol(String recKey) {
		pvExperianInitFailVol = getVolume(recKey);
		return pvExperianInitFailVol;
	}

	public void setPvExperianInitFailVol(int pvExperianInitFailVol) {
		this.pvExperianInitFailVol = pvExperianInitFailVol;
	}

	public int getPvExperianRepeatFailVol(String recKey) {
		pvExperianRepeatFailVol = getVolume(recKey);
		return pvExperianRepeatFailVol;
	}

	public void setPvExperianRepeatFailVol(int pvExperianRepeatFailVol) {
		this.pvExperianRepeatFailVol = pvExperianRepeatFailVol;
	}

	public int getPvExperianAbandonedVol(String recKey) {
		pvExperianAbandonedVol = getVolume(recKey);
		return pvExperianAbandonedVol;
	}

	public void setPvExperianAbandonedVol(int pvExperianAbandonedVol) {
		this.pvExperianAbandonedVol = pvExperianAbandonedVol;
	}

	public int getPvExperianErrorVol(String recKey) {
		pvExperianErrorVol = getVolume(recKey);
		return pvExperianErrorVol;
	}

	public void setPvExperianErrorVol(int pvExperianErrorVol) {
		this.pvExperianErrorVol = pvExperianErrorVol;
	}

	public int getPvExperianTotalFailVol() {
		pvExperianTotalFailVol = pvExperianInitFailVol + pvExperianRepeatFailVol + pvExperianErrorVol + pvExperianAbandonedVol;
		return pvExperianTotalFailVol;
	}

	public void setPvExperianTotalFailVol(int pvExperianTotalFailVol) {
		this.pvExperianTotalFailVol = pvExperianTotalFailVol;
	}

	public int getPvExperianTotalVol() {
		pvExperianTotalVol = pvExperianTotalPassVol + pvExperianTotalReviewVol + pvExperianTotalFailVol;
		return pvExperianTotalVol;
	}

	public void setPvExperianTotalVol(int pvExperianTotalVol) {
		this.pvExperianTotalVol = pvExperianTotalVol;
	}

	public int getPvEquifaxDitInitPassVol(String recKey) {
		pvEquifaxDitInitPassVol = getVolume(recKey);
		return pvEquifaxDitInitPassVol;
	}

	public void setPvEquifaxDitInitPassVol(int pvEquifaxDitInitPassVol) {
		this.pvEquifaxDitInitPassVol = pvEquifaxDitInitPassVol;
	}

	public int getPvEquifaxDitRepeatPassVol(String recKey) {
		pvEquifaxDitRepeatPassVol = getVolume(recKey);
		return pvEquifaxDitRepeatPassVol;
	}

	public void setPvEquifaxDitRepeatPassVol(int pvEquifaxDitRepeatPassVol) {
		this.pvEquifaxDitRepeatPassVol = pvEquifaxDitRepeatPassVol;
	}

	public int getPvEquifaxDitTotalPassVol() {
		pvEquifaxDitTotalPassVol = pvEquifaxDitInitPassVol + pvEquifaxDitRepeatPassVol;
		return pvEquifaxDitTotalPassVol;
	}

	public void setPvEquifaxDitTotalPassVol(int pvEquifaxDitTotalPassVol) {
		this.pvEquifaxDitTotalPassVol = pvEquifaxDitTotalPassVol;
	}

	public int getPvEquifaxDitInitReviewVol(String recKey) {
		pvEquifaxDitInitReviewVol = getVolume(recKey);
		return pvEquifaxDitInitReviewVol;
	}

	public void setPvEquifaxDitInitReviewVol(int pvEquifaxDitInitReviewVol) {
		this.pvEquifaxDitInitReviewVol = pvEquifaxDitInitReviewVol;
	}

	public int getPvEquifaxDitRepeatReviewVol(String recKey) {
		pvEquifaxDitRepeatReviewVol = getVolume(recKey);
		return pvEquifaxDitRepeatReviewVol;
	}

	public void setPvEquifaxDitRepeatReviewVol(int pvEquifaxDitRepeatReviewVol) {
		this.pvEquifaxDitRepeatReviewVol = pvEquifaxDitRepeatReviewVol;
	}

	public int getPvEquifaxDitTotalReviewVol() {
		pvEquifaxDitTotalReviewVol = pvEquifaxDitInitReviewVol + pvEquifaxDitRepeatReviewVol;
		return pvEquifaxDitTotalReviewVol;
	}

	public void setPvEquifaxDitTotalReviewVol(int pvEquifaxDitTotalReviewVol) {
		this.pvEquifaxDitTotalReviewVol = pvEquifaxDitTotalReviewVol;
	}

	public int getPvEquifaxDitInitFailVol(String recKey) {
		pvEquifaxDitInitFailVol = getVolume(recKey);
		return pvEquifaxDitInitFailVol;
	}

	public void setPvEquifaxDitInitFailVol(int pvEquifaxDitInitFailVol) {
		this.pvEquifaxDitInitFailVol = pvEquifaxDitInitFailVol;
	}

	public int getPvEquifaxDitRepeatFailVol(String recKey) {
		pvEquifaxDitRepeatFailVol = getVolume(recKey);
		return pvEquifaxDitRepeatFailVol;
	}

	public void setPvEquifaxDitTotalFailVol(int pvEquifaxDitTotalFailVol) {
		this.pvEquifaxDitTotalFailVol = pvEquifaxDitTotalFailVol;
	}
	
	public int getPvEquifaxDitTotalFailVol() {
		pvEquifaxDitTotalFailVol = pvEquifaxDitInitFailVol + pvEquifaxDitRepeatFailVol + pvEquifaxDitAbandonedVol + pvEquifaxDitErrorVol;
		return pvEquifaxDitTotalFailVol;
	}

	public int getPvEquifaxDitAbandonedVol(String recKey) {
		pvEquifaxDitAbandonedVol = getVolume(recKey);
		return pvEquifaxDitAbandonedVol;
	}

	public void setPvEquifaxDitAbandonedVol(int pvEquifaxDitAbandonedVol) {
		this.pvEquifaxDitAbandonedVol = pvEquifaxDitAbandonedVol;
	}

	public int getPvEquifaxDitErrorVol(String recKey) {
		pvEquifaxDitErrorVol = getVolume(recKey);
		return pvEquifaxDitErrorVol;
	}

	public void setPvEquifaxDitErrorVol(int pvEquifaxDitErrorVol) {
		this.pvEquifaxDitErrorVol = pvEquifaxDitErrorVol;
	}

	public int getPvEquifaxDitTotalVol() {
		pvEquifaxDitTotalVol = pvEquifaxDitTotalPassVol + pvEquifaxDitTotalReviewVol + pvEquifaxDitTotalFailVol;
		return pvEquifaxDitTotalVol;
	}

	public void setPvEquifaxDitRepeatFailVol(int pvEquifaxDitRepeatFailVol) {
		this.pvEquifaxDitRepeatFailVol = pvEquifaxDitRepeatFailVol;
	}
		
	public int getOtpLexisNexisPassVol(String recKey) {
		otpLexisNexisPassVol = getVolume(recKey);
		return otpLexisNexisPassVol;
	}

	public void setOtpLexisNexisPassVol(int otpLexisNexisPassVol) {
		this.otpLexisNexisPassVol = otpLexisNexisPassVol;
	}

	public int getOtpLexisNexisFailVol(String recKey) {
		otpLexisNexisFailVol = getVolume(recKey);
		return otpLexisNexisFailVol;
	}

	public void setOtpLexisNexisFailVol(int otpLexisNexisFailVol) {
		this.otpLexisNexisFailVol = otpLexisNexisFailVol;
	}

	public int getOtpLexisNexisAbandonedVol(String recKey) {
		otpLexisNexisAbandonedVol = getVolume(recKey);
		return otpLexisNexisAbandonedVol;
	}

	public void setOtpLexisNexisAbandonedVol(int otpLexisNexisAbandonedVol) {
		this.otpLexisNexisAbandonedVol = otpLexisNexisAbandonedVol;
	}

	public int getOtpLexisNexisErrorVol(String recKey) {
		otpLexisNexisErrorVol = getVolume(recKey);
		return otpLexisNexisErrorVol;
	}

	public void setOtpLexisNexisErrorVol(int otpLexisNexisErrorVol) {
		this.otpLexisNexisErrorVol = otpLexisNexisErrorVol;
	}

	public int getOtpLexisNexisTotalFailVol() {
		otpLexisNexisTotalFailVol = otpLexisNexisFailVol + otpLexisNexisAbandonedVol + otpLexisNexisErrorVol;
		return otpLexisNexisTotalFailVol;
	}

	public void setOtpLexisNexisTotalFailVol(int otpLexisNexisTotalFailVol) {
		this.otpLexisNexisTotalFailVol = otpLexisNexisTotalFailVol;
	}

	public int getOtpLexisNexisTotalVol() {
		otpLexisNexisTotalVol = otpLexisNexisPassVol + otpLexisNexisTotalFailVol;
		return otpLexisNexisTotalVol;
	}

	public void setOtpLexisNexisTotalVol(int otpLexisNexisTotalVol) {
		this.otpLexisNexisTotalVol = otpLexisNexisTotalVol;
	}

	public int getOtpExperianPassVol(String recKey) {
		otpExperianPassVol = getVolume(recKey);
		return otpExperianPassVol;
	}

	public void setOtpExperianPassVol(int otpExperianPassVol) {
		this.otpExperianPassVol = otpExperianPassVol;
	}

	public int getOtpExperianFailVol(String recKey) {
		otpExperianFailVol = getVolume(recKey);
		return otpExperianFailVol;
	}

	public void setOtpExperianFailVol(int otpExperianFailVol) {
		this.otpExperianFailVol = otpExperianFailVol;
	}

	public int getOtpExperianAbandonedVol(String recKey) {
		otpExperianAbandonedVol = getVolume(recKey);
		return otpExperianAbandonedVol;
	}

	public void setOtpExperianAbandonedVol(int otpExperianAbandonedVol) {
		this.otpExperianAbandonedVol = otpExperianAbandonedVol;
	}

	public int getOtpExperianErrorVol(String recKey) {
		otpExperianErrorVol = getVolume(recKey);
		return otpExperianErrorVol;
	}

	public void setOtpExperianErrorVol(int otpExperianErrorVol) {
		this.otpExperianErrorVol = otpExperianErrorVol;
	}

	public int getOtpExperianTotalFailVol() {
		otpExperianTotalFailVol = otpExperianFailVol + otpExperianAbandonedVol + otpExperianErrorVol;
		return otpExperianTotalFailVol;
	}

	public void setOtpExperianTotalFailVol(int otpExperianTotalFailVol) {
		this.otpExperianTotalFailVol = otpExperianTotalFailVol;
	}

	public int getOtpExperianTotalVol() {
		otpExperianTotalVol = otpExperianPassVol + otpExperianTotalFailVol;
		return otpExperianTotalVol;
	}

	public void setOtpExperianTotalVol(int otpExperianTotalVol) {
		this.otpExperianTotalVol = otpExperianTotalVol;
	}
	
	public int getMfaEquifaxPassVol(String recKey) {
		mfaEquifaxPassVol = getVolume(recKey);
		return mfaEquifaxPassVol;
	}

	public void setMfaEquifaxPassVol(int mfaEquifaxPassVol) {
		this.mfaEquifaxPassVol = mfaEquifaxPassVol;
	}

	public int getMfaEquifaxFailVol(String recKey) {
		mfaEquifaxFailVol = getVolume(recKey);
		return mfaEquifaxFailVol;
	}

	public void setMfaEquifaxFailVol(int mfaEquifaxFailVol) {
		this.mfaEquifaxFailVol = mfaEquifaxFailVol;
	}

	public int getMfaEquifaxAbandonedVol(String recKey) {
		mfaEquifaxAbandonedVol = getVolume(recKey);
		return mfaEquifaxAbandonedVol;
	}

	public void setMfaEquifaxAbandonedVol(int mfaEquifaxAbandonedVol) {
		this.mfaEquifaxAbandonedVol = mfaEquifaxAbandonedVol;
	}

	public int getMfaEquifaxErrorVol(String recKey) {
		mfaEquifaxErrorVol = getVolume(recKey);
		return mfaEquifaxErrorVol;
	}

	public void setMfaEquifaxErrorVol(int mfaEquifaxErrorVol) {
		this.mfaEquifaxErrorVol = mfaEquifaxErrorVol;
	}

	public int getMfaEquifaxTotalFailVol() {
		mfaEquifaxTotalFailVol = mfaEquifaxFailVol + mfaEquifaxAbandonedVol + mfaEquifaxErrorVol;
		return mfaEquifaxTotalFailVol;
	}

	public void setMfaEquifaxTotalFailVol(int mfaEquifaxTotalFailVol) {
		this.mfaEquifaxTotalFailVol = mfaEquifaxTotalFailVol;
	}

	public int getMfaEquifaxTotalVol() {
		mfaEquifaxTotalVol = mfaEquifaxPassVol + mfaEquifaxTotalFailVol;
		return mfaEquifaxTotalVol;
	}

	public void setMfaEquifaxTotalVol(int mfaEquifaxTotalVol) {
		this.mfaEquifaxTotalVol = mfaEquifaxTotalVol;
	}

	public List<WorkflowApiDecisionVo> getWkflowApiDecisionVoList() {
		return wkflowApiDecisionVoList;
	}

	public void setWkflowApiDecisionVoList(List<WorkflowApiDecisionVo> wkflowApiDecisionVoList) {
		this.wkflowApiDecisionVoList = wkflowApiDecisionVoList;
	}

}
