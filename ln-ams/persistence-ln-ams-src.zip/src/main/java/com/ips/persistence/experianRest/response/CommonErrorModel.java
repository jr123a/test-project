package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class CommonErrorModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String errorType;
	private String message;
	
	public String getErrorType() {
		return errorType;
	}
	
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
