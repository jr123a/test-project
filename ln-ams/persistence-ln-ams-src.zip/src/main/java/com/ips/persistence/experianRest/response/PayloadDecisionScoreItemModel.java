package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PayloadDecisionScoreItemModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String name;	   
	private int score;		  
	private String type;		  
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScore() {
		return score;
	}
	
	public void setScore(int score) {
		this.score = score;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
