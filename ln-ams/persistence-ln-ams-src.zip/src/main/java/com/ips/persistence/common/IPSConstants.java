package com.ips.persistence.common;

import java.io.Serializable;

import com.ips.common.common.Utils;

public class IPSConstants implements Serializable {

    private static final long serialVersionUID = 1L;
    
    public static final String ENVIRONMENT = Utils.getEnvironment();
    
    public static final String USER_KEY        = "USER";
    public static final String PERSON_KEY      = "PERSON";
    public static final String USER_ID_KEY     = "CUSTREG_USER_ID";
    public static final String LOA_LEVEL_KEY   = "LOA_LEVEL";
    public static final String ADMIN_USER_KEY  = "ADMIN_USER";
    public static final String CALLING_APP_ID_KEY = "CALLING_APP_ID";
    public static final String CALLING_APP_URL_KEY = "CALLING_APP_URL";
    public static final String CALLING_APP_NAME_KEY = "CALLING_APP_NAME";
 	public static final String DEVICE_ASSESSMT_PARAM_VO = "DEVICE_ASSESSMT_PARAM_VO";
    public static final String APPOINTMENT_KEY = "APPOINTMENT";
    public static final String SESSION_TIMEOUT_KEY  = "SESSION_TIMEOUT";
    public static final String FILTERED_PO_LIST_KEY = "FILTERED_PO_LIST";
    public static final String REDIRECT_PAGE_URL_KEY      = "NEXT_PAGE_URL";
    public static final String DEV_PROFILING_ENABLED_KEY  = "DEVICE_PROFILING_ENABLED";
    public static final String DEV_CUSTOMER_IP_ADDRESS_KEY  = "DEVICE_CUSTOMER_IP_ADDRESS_KEY";
    public static final String DEV_PROFILING_SESSIONID_KEY  = "DEVICE_PROFILING_SESSIONID_KEY";
    public static final String LOCKOUT_EXPIRES_DATE_KEY  = "LOCKOUT_EXPIRES_DATE_KEY";
    public static final String VERIFY_PHONE_ERROR_KEY  = "VERIFY_PHONE_ERROR_KEY";
    public static final String OTP_SMFA_ATTEMPTS_KEY  = "OTP_SMFA_ATTEMPTS_KEY";
    public static final String STATUS_DEVICE_REPUTATION_STARTED = "Started device reputation";
    public static final String CLIENT_IP       = "clientip";
    public static final String NS_CLIENT_IP    = "NS-Client-IP";
    public static final String CLIENT_IP_ADDR  = "CLIENT_IP_ADDR";

    public static final String SPONSOR_CUSTREG  = "CustomReg";
    public static final String SPONSOR_OP_SANTA  = "Operation Santa";
    public static final String SPONSOR_EXTERNAL_ID = "2";
    public static final String HOLD_MAIL = "HoldMail";

    public static final String ENV_PREPROD = "preprod";
	public static final String ENV_CAT = "cat";
	public static final String ENV_PROD = "prod";
	
    public static final String STATUS_NEW_TO_IPS = "New to IPS, No Proofing Events";
    public static final String STATUS_RP_FAILED = "Remote Proofing Failed";
    public static final String STATUS_RP_PASSED = "Remote Proofing Passed";
    public static final String STATUS_IPP_OPT_IN = "Opted-in for in-person proofing";
    public static final String STATUS_IPP_EMAIL_SENT = "In-person email sent";
    public static final String STATUS_IPP_AT_RESIDENCE_SCHEDULED = "IPP at residence scheduled";
    public static final String STATUS_RP_CANCELLED = "Remote proofing cancelled";
    public static final String STATUS_IPP_FAILED = "In-person proofing failed";
    public static final String STATUS_IPP_PASSED = "In-person proofing passed";
    public static final String STATUS_LOA_ACHIEVED = "LOA level achieved";
    public static final String STATUS_ACTIVATION_EMAIL_SENT = "Activation email sent";
    public static final String STATUS_REPROOFING = "Reproofing due to attribute change";
    public static final String STATUS_PROFILE_UPDATED = "Profile updated";
    public static final String STATUS_RP_STARTED = "Started remote proofing";
    public static final String IPP_RESIDENCE_SCHEDULED = "IPP at residence scheduled";
    public static final String IPP_RESIDENCE_OPT_IN = "Opted-in for In-person Proofing at Residence";
    public static final String HIGH_RISK_ATTEMPT = "Identity attempt using high risk address";
    public static final String LOW_CONFIDENCE_ATTEMPT = "Attempt to verify identity with Low Confidence device reputation";
    public static final String DEVICE_REPUTATION_REPEAT_ASSESSMENT = "DEVICE_REPUTATION_REPEAT_ASSESSMENT";
    public static final String FLAG_YES = "Y";
    public static final String FLAG_NO = "N";
    public static final String CONFIG_VALUE_Y = "Y";
    public static final String CONFIG_VALUE_N = "N";
    public static final String VALUE_PASS = "PASS";
    public static final String VALUE_FAIL = "FAIL";
    public static final String VALUE_REVIEW = "REVIEW";
    
    public static final String STATUS_ERROR = "Error";
    public static final String REDIRECT_TO_STATUS_ERROR_PAGE ="Redirecting to System Error Page: ";
    
    /**
     * TODO These IPP_Status are probably used for the same purposes as Status_IPP above,
     * maybe remove them later if that is the case    
     */
    public static final String IPP_STATUS_STARTED  = "Start In-person event";
    public static final String IPP_STATUS_FAILED   = "In-person failed";
    public static final String IPP_STATUS_PASSED   = "In-person passed";
    public static final String IPP_STATUS_RP_RETRY = "Retried remote proofing";
    public static final String IPP_STATUS_EXPIRED  = "Expired";
    public static final String IPP_STATUS_PROOFING_AT_PO_STARTED  = "Proofing at post office started";
    public static final String IPP_STATUS_MAX_SCANS  = "Blocked because max scans exceeded";
    
    public static final String IPP_TYPE_FACILITY    = "F";
    public static final String IPP_TYPE_RESIDENCE   = "R";
    public static final String IPP_APP_ACRONYMN_IVS = "IVS-IPP";
    public static final String IPP_APP_ACRONYMN_RSS = "RSS";
    public static final String IPP_APP_ACRONYMN_EBIS = "EBIS";
    public static final String IPP_APP_ACRONYMN_MDD = "MDD";
    public static final String LOA_15 = "1.5";
    
    public static final int CURRENT_YEAR = 2015;
    public static final String MAX_VALID_DATE = "31/12/2099";
    public static final String DDMMYYYY_FMT   = "dd/MM/yyyy";
    public static final String MMDDYYYY_FMT_REGEX = "^((0|1)[0-9]{1})((0|1|2|3)[0-9]{1})([0-9]{4})$";

    public static final String ASSERT_RC = "Y";
    
    public static final String UNKNOWN = "Unknown";
    
    public static final String IPS_PROPERTIES = "/ips.properties";
    public static final String REG_PREF = "com.usps.ips.CUSTREG_PREFERENCES_URL";
    public static final String REG_LOGIN = "com.usps.custreg.LOGIN";
    public static final String FAILURE_REDIRECT_REG_PAGE = "com.usps.ips.FAILURE_REDIRECT_REG_PAGE_URL";
    public static final String CODE_VIA_MAIL_REG_PAGE = "com.usps.ips.ID_CODE_VIA_MAIL_REQUEST_REG_PAGE_URL";
    public static final String ID_SUCCESS_PAGE = "com.usps.ips.ID_CROSS_SELL_SUCCESS_PAGE_URL";
    public static final String RP_EQUIFAX_PASSED = "Y";
    public static final String RP_EQUIFAX_FAILED = "N";
    public static final String RP_EQUIFAX_REVIEW = "R";
    public static final String RP_LEXIS_PASSED   = "PASS";
    public static final String RP_LEXIS_FAILED   = "FAIL";
    public static final String RP_LEXIS_PENDING  = "PENDING";
    public static final String RP_LEXIS_ERROR    = "ERROR";
    public static final String RP_EXPERIAN_ERROR = "ERROR";
    public static final String RP_EXPERIAN_PASS  = "PASS";
    public static final String RP_EXPERIAN_CONTINUE = "CONTINUE";
    public static final String RP_EXPERIAN_INVESTIGAT = "INVESTIGAT";
    public static final String RP_EXPERIAN_STOP = "STOP";
    public static final String RP_EXPERIAN_NODECISION = "NODECISION";
    public static final String RP_LEXIS_PROD_TYPE_DISCOVERY    = "Discovery";
    public static final String RP_LEXIS_PROD_TYPE_VELOCITY     = "Velocity";
    public static final String RP_LEXIS_PROD_TYPE_VERIFICATION = "Verification";
    public static final String RP_LEXIS_PROD_TYPE_IIDQA = "IIDQA";
    public static final String RP_LEXIS_PROD_TYPE_OTP   = "OTP";
    
    public static final String RP_LEXIS_PASSCODE_EXPIRED_RESPONSE = "otp_fail_expired_passcode_returned_after_timeout";
    public static final String PASSCODE_NOT_SENT_MSG = "The passcode was not sent. Please try again.";  
    public static final String PASSCODE_EXPIRED_MSG = "The passcode you have entered has expired. ";  
    public static final String TRANSACTION_EXPIRED_MSG = "The transaction has expired. Please logout and login back.";  
    public static final String PASSCODE_INVALID_NUMBER_MSG = "Enter the passcode which was sent to your mobile phone number. ";
    public static final String PASSCODE_INVALID_LENGTH_MSG = "The passcode you have entered has invalid length. "; 
    public static final String PASSCODE_EMPTY_MSG = "Enter the passcode which was sent to your mobile phone number. ";
    public static final String PASSCODE_INCORRECT_MSG = "Error: Incorrect Passcode. %s attempts remaining.";
    public static final String SEND_NEW_CODE_NOW_MSG = "Select the \"Send a new code now\" option below.";
    public static final String ERROR_RESPONSE_MSG = "The response has error.";  
    public static final String UNABLE_TO_VERIFY_LANDLINE_MSG = "We were not able to verify your identity with the information you entered. Landline numbers are not supported.<br/>"
    		+ "Please enter a valid mobile phone number or select alternative verification below.";
    public static final String EXCEEDED_PASSCODE_REQUESTS_MSG = "You have exceeded the maximum number of passcode entries.  ";
    public static final String EXCEEDED_LINK_REQUESTS_MSG = "You have exceeded the maximum number of send link requests.";
    public static final String UNABLE_TO_VERIFY_PHONE_MSG = "We were not able to verify your identity with the information you entered.<br/>"
            + "Please enter a valid mobile phone number or select alternative verification below.";
    public static final String ALL_SUPPLIERS = "All Suppliers";

    public static final long ONE_TIME_PASSCODE_SUPPLIER_ID = 3L;
    public static final long ONE_TIME_PASSCODE_LEXISNEXIS_SUPPLIER_ID = 4L;

    public static final String VELOCITY_TYPE_PASSCODE   = "PASSCODE";
    public static final String VELOCITY_TYPE_PHONE      = "PHONE";
    public static final String VELOCITY_TYPE_SMFA   = "SMFA";
    public static final String OTP_ATTEMPT_TYPE_INITIAL = "Initial";
    public static final String OTP_ATTEMPT_TYPE_RENEW   = "Renew";
    public static final String OTP_ATTEMPT_TYPE_CONFIRM = "Confirm";
    
    public static final String WEBTOOLS_VERIFY_URL = "web.tools.API.Verify";
    public static final String USPS_PROXY_HOST = "proxy.usps.gov";
    public static final String USPS_PROXY_PORT = "8080";
    
    public static final String ENCRYPT = "Encrypt";
    
    public static final String ENT_REG_APP = "EntRegApp";
    
    public static final String LOA_ID_510 = "510";
    public static final String LOA_RP_ID  = "520";
    public static final Short  LOA_RP_520 = 520;
    public static final Short  LOA_RP_525 = 525;
    public static final Short  LOA_RP_526 = 526;
    public static final String LOA_IP_ID  = "600";
    public static final String LOA_IP_515 = "515";
        
    public static final String LOA_FLAG_ACHIEVED = "Y";
    public static final String LOA_FLAG_NOT_ACHIEVED = "N";
    
    public static final String PROOFING_STATUS_INITIATED   = "INITIATION";
    public static final String PROOFING_STATUS_IN_PROGRESS = "IN PROGRESS";
    public static final String PROOFING_STATUS_PENDING     = "ACTIVATION PENDING";
    public static final String PROOFING_STATUS_COMPLETE    = "COMPLETE";
    public static final String PROOFING_STATUS_CANCELLED   = "CANCELLED";
    public static final String PROOFING_STATUS_PHONE_VERIFIED     = "PHONE VERIFIED";
    public static final String PROOFING_STATUS_PHONE_NOT_VERIFIED = "PHONE NOT VERIFIED";

    public static final String PROOFING_RESULT_PASSED = "Passed";
    public static final String PROOFING_RESULT_FAILED = "Failed";
    public static final String TRANSACTION_STATUS_PASSED = "passed";
    public static final String TRANSACTION_STATUS_FAILED = "failed";
    public static final String EVENT_TAG_CHALLENGE_INIT = "challenge_init";
    public static final String EVENT_TAG_CHALLENGE_FAIL = "challenge_fail";
    public static final String EVENT_TAG_CHALLENGE_PASS = "challenge_pass";
    public static final String EVENT_TAG_FRAUD_CONFIRMED = "fraud_confirmed";
    public static final String EVENT_TAG_TRUSTED_CONFIRMED = "trusted_confirmed";
    public static final String EVENT_TAG_FRAUD_PROBABLY = "fraud_probably";
    public static final String ACTION_ADD_BLACK_LIST = "add_black_list";
    public static final String ACTION_ADD_SAFE_LIST = "add_safe_list";
    public static final String ACTION_ADD_WATCH_LIST = "add_watch_list";
    public static final String ACTION_REMOVE_BLACK_LIST = "remove_black_list";
    public static final String ACTION_REMOVE_SAFE_LIST = "remove_safe_list";
    public static final String ACTION_REMOVE_WATCH_LIST = "remove_watch_list";

    public static final String LOA_RP_NAME = "Online KBA - NIST";
    public static final String LOA_IP_NAME = "In-person - Retail";
    public static final String LOA_RP_OTP_NAME = "Online Phone OTP - NIST";
    public static final String LOA_RP_LN_PV_NAME = "Online Phone LN PV - NIST";
    public static final String LOA_RP_LN_OTP_NAME = "Online Phone LN OTP - NIST";
     public static final String LOA_RP_EX_PID_NAME = "Online Phone EX PID - NIST";
    public static final String LOA_RP_EX_SA_NAME = "Online Phone EX SA - NIST";
    public static final String LOA_RP_EX_OTP_NAME = "Online Phone EX OTP - NIST";
    public static final String LOA_RP_EQ_PV_NAME = "Online Phone EQ PV - NIST";
    public static final String LOA_RP_EQ_OTP_NAME = "Online Phone EQ OTP - NIST";
    public static final String LOA_RP_EQ_DIT_NAME = "Online Phone EQ DIT - NIST";
    public static final String LOA_RP_EQ_SMFA_NAME = "Online Phone EQ SMFA - NIST";
     
    public static final String LEXIS_NEXIS_J2C_ALIAS     = "LexisNexis";
    public static final String LEXIS_NEXIS_RDP_J2C_ALIAS = "LexisNexisRDP";
    public static final String TMX_API_J2C_ALIAS = "TMXAPIKey";
    public static final String EQUIFAX_J2C_ALIAS      = "Equifax";
    public static final String EQUIFAX_J2C_ALIAS_XML  = "EquifaxXML";
    public static final String EQUIFAX_J2C_ALIAS_IDFS = "EquifaxIDFS";
    public static final String WEB_TOOLS_ALIAS = "AMS";
    public static final String PEM_J2C_ALIAS     = "Env_Cert";
    
    public static final String EQUIFAX_ORGANIZATION_CODE = "ips";
    public static final String EQUIFAX_ORCHESTRATION_CODE_1_5 = "mypost";
    public static final String EQUIFAX_ORCHESTRATION_CODE_2_0 = "idproofing";
    public static final String WEB_TOOLS_API_POLOCATOR_RADIUS = "50";
    public static final String WEB_TOOLS_API_POLOCATOR_MAXLOCATIONS = "200";
    public static final String WEB_TOOLS_API_POLOCATOR_FACILITYTYPE = "PO";
    public static final String WEB_TOOLS_API_POLOCATOR_SERVICE = "PICKUPHOLDMAIL";
    public static final String WEB_TOOLS_API_GETADDRESS = "com.usps.ips.WEB_TOOLS_API_GETADDRESS";
    public static final String WEB_TOOLS_API_POLOCATOR = "com.usps.ips.WEB_TOOLS_API_POLOCATOR";
    public static final String WEB_TOOLS_API_GEOCODE_SERVER = "com.ipsweb.GeocodeServer";
    
    public static final String RP_DECISION_PASSED = "PASSED";
    public static final String RP_DECISION_FAILED = "FAILED";
    public static final String VALUE_PASSED = "Passed";
    public static final String VALUE_FAILED = "Failed";
    public static final String RP_EQUIFAX_IDMS_OTP_PASS = "PASS";
    public static final String RP_EQUIFAX_IDMS_OTP_COMPLETED = "COMPLETED";
    public static final String RP_EQUIFAX_IDMS_OTP_EXACT = "EXACT";
    public static final String RP_EQUIFAX_IDMS_OTP_MISMATCH = "MISMATCH";
    public static final long RP_ATTEMPTS_ALLOWED = 3L; 
    public static final long RP_ATTEMPT_PERIOD = 72L;
    
    public static final String CUSTREG_ACTION_REDIRECT = "?appURL=";
    public static final String MYUSPS_COM_URL = "https://my.usps.com";
    
    public static final String COM_IPSWEB_BARCODE_PATH = "C:\\opt\\WebSphere\\ipsimages\\";
    public static final String COM_IPSWEB_PEM_FILE_PATH = "/opt/WebSphere/ips/";
    
    public static final String EQUIFAX_VERIFY_PHONE_ORCHESTRATION_CODE = "eidphone";
    public static final String EQUIFAX_PASSCODE_ORCHESTRATION_CODE = "otponly";
    
    public static final String EMAILER_SMTP_HOST = "mailrelay.usps.gov";
    public static final String EMAILER_SMTP_PORT = "25";
    public static final String EMAILER_SENDER_EMAIL_ADDRESS = "uspsidservices@usps.gov";
    
    public static final String HASH_ALGORITH = "PBKDF2WithHmacSHA256";
    public static final int SALT_BYTE_SIZE = 8;
    public static final int DERIVED_KEY_LENGTH = 256;
    public static final int NUM_ITERATIONS = 20000;
    public static final String IVSPERSISTENCE_MOD_FP = "04-24-2023-1";

    //REGEX formatting
    public static final String ALPHA_NUMERIC = "^[a-zA-Z0-9]+$";
    public static final String NUMERIC = "[0-9]+";
    public static final String ALPHA = "[a-zA-Z]+";
    public static final String ALPHA_WITH_SPACE = "[a-zA-Z ]+";
    public static final String NUMERIC_WITH_HYPHEN = "[0-9-]+";
    public static final String NUMERIC_WITH_HYPHEN_COMMA = "[0-9,.-]+";
    public static final String ALPHA_WITH_HYPHEN_APOSTROPHE_SPACE = "[a-zA-Z' -]+";
    public static final String ALPHA_NUMERIC_WITH_HYPHEN_APOSTROPHE_SPACE = "^[a-zA-Z0-9' -]+$";
    public static final String ALPHA_NUMERIC_WITH_HYPHEN = "^[a-zA-Z0-9-]+$";
    public static final String ABBREVIATED_STATE = "^[A-Za-z]{2}$";
    public static final String PHONE_NUMBER_10_DIGIT = "^[0-9]{10}$";
    public static final String NUMERIC_6_DIGIT = "^[0-9]{6}$";
    public static final String NUMERIC_9_DIGIT = "^[0-9]{9}$";
    public static final String NUMERIC_4_6_DIGIT = "^[0-9]{4,6}$";
	public static final String NUMERIC_WITH_DOT = "^[0-9.]+$";
	public static final String IP_V6_V4_DUALV6 = "^(((\\s*(::|(([a-fA-F0-9]{1,4}):){5}(([a-fA-F0-9]{1,4}))|(:(:([a-fA-F0-9]{1,4})){1,6})|((([a-fA-F0-9]{1,4}):){1,6}:)|((([a-fA-F0-9]{1,4}):)(:([a-fA-F0-9]{1,4})){1,6})|((([a-fA-F0-9]{1,4}):){2}(:([a-fA-F0-9]{1,4})){1,5})|((([a-fA-F0-9]{1,4}):){3}(:([a-fA-F0-9]{1,4})){1,4})|((([a-fA-F0-9]{1,4}):){4}(:([a-fA-F0-9]{1,4})){1,3})|((([a-fA-F0-9]{1,4}):){5}(:([a-fA-F0-9]{1,4})){1,2})):((([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]))\\s*))|(\\s*((([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]))\\s*)|(\\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:)))(%.+)?\\s*))$";
	public static final String ALPHA_NUMERIC_WITH_HYPHEN_UNDERSCORE = "^[a-zA-Z0-9-_]+$";
    public static final String COMPANY_NAME_REGEX = "^[A-Za-z0-9\\-\\.'_,\"&()?#/+@\\s]*$";
    public static final String EMAIL_ADDRESS_REGEX = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,20}$";

    public static final String FIRSTNAME_LASTNAME_REGEX = "^[\\sA-Za-z\\.'\\-]*$";
    public static final String STREET_ADDRESS_REGEX = "^[0-9A-Za-z'\\-\\._\",&()?#/+@\\s]*$";
    public static final String CITY_REGEX = "^[A-Za-z'\\-\\.\\s]*$";
    public static final String URBANIZATION_CODE_REGEX = "^[0-9A-Za-z'\\-\\._\",&()?#/+@\\s]*$";
    public static final String ZIP_CODE_REGEX = "^[0-9\\-\\.'\\sA-Za-z\"_&(),?#/+@]*$";

    public static final int IPP_EVENT_PASSED = 3;
    public static final int IPP_EVENT_FAILED = 2;
    
    private IPSConstants() {
        
    }
}
