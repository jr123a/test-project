package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchOfacSummaryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ValueCodeModel verificationResult;	           //Mandatory:Y, Max Length:8
	private PreciseMatchOfacCountsModel counts;
	
	public ValueCodeModel getVerificationResult() {
		return verificationResult;
	}
	
	public void setVerificationResult(ValueCodeModel verificationResult) {
		this.verificationResult = verificationResult;
	}

	public PreciseMatchOfacCountsModel getCounts() {
		return counts;
	}

	public void setCounts(PreciseMatchOfacCountsModel counts) {
		this.counts = counts;
	}
	
}
