package com.ips.persistence.experianRest.request;

import java.io.Serializable;

public class ContactAddressModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String id;	        		//Mandatory:N, Max Length:40, Total Length:50
	private String addressType;		    //Mandatory:N, Max Length:20, Total Length:40
	private String poBoxNumber;			//Mandatory:N, Max Length:40, Total Length:60
	private String street;				//Mandatory:N, Max Length:50, Total Length:65
	private String street2;	    		//Mandatory:N, Max Length:50, Total Length:65
	private String postTown;			//Mandatory:N, Max Length:40, Total Length:55
	private String postal;	    		//Mandatory:N, Max Length:10, Total Length:25
	private String stateProvinceCode;	//Mandatory:N, Max Length:4, Total Length:30
	

	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public String getPoBoxNumber() {
		return poBoxNumber;
	}

	public void setPoBoxNumber(String poBoxNumber) {
		this.poBoxNumber = poBoxNumber;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getStreet2() {
		return street2;
	}

	public void setStreet2(String street2) {
		this.street2 = street2;
	}

	public String getPostTown() {
		return postTown;
	}

	public void setPostTown(String postTown) {
		this.postTown = postTown;
	}

	public String getPostal() {
		return postal;
	}

	public void setPostal(String postal) {
		this.postal = postal;
	}

	public String getStateProvinceCode() {
		return stateProvinceCode;
	}

	public void setStateProvinceCode(String stateProvinceCode) {
		this.stateProvinceCode = stateProvinceCode;
	}

	
}
