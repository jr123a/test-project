package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseMatchPhoneDetailModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<String> residentialPhoneRcd;	           //Max Length:8
	private List<String> phoneHighRiskRcd;	           //Max Length:8
	private List<PreciseMatchHighRiskDescriptionModel> highRiskPhoneDescription; 
	private List<String> businessPhoneRcd;	           //Max Length:8
	
	public List<String> getResidentialPhoneRcd() {
		return residentialPhoneRcd;
	}
	
	public void setResidentialPhoneRcd(List<String> residentialPhoneRcd) {
		this.residentialPhoneRcd = residentialPhoneRcd;
	}

	public List<String> getPhoneHighRiskRcd() {
		return phoneHighRiskRcd;
	}

	public void setPhoneHighRiskRcd(List<String> phoneHighRiskRcd) {
		this.phoneHighRiskRcd = phoneHighRiskRcd;
	}

	public List<PreciseMatchHighRiskDescriptionModel> getHighRiskPhoneDescription() {
		return highRiskPhoneDescription;
	}

	public void setHighRiskPhoneDescription(List<PreciseMatchHighRiskDescriptionModel> highRiskPhoneDescription) {
		this.highRiskPhoneDescription = highRiskPhoneDescription;
	}

	public List<String> getBusinessPhoneRcd() {
		return businessPhoneRcd;
	}

	public void setBusinessPhoneRcd(List<String> businessPhoneRcd) {
		this.businessPhoneRcd = businessPhoneRcd;
	}
	
}
