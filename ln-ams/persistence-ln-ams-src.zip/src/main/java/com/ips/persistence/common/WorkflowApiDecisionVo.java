package com.ips.persistence.common;


public class WorkflowApiDecisionVo {
    private String countSum;
    private String workflowApiTypeId;
    private String decision;
    private String decisionSource;
    private String kbaSupplierId;
    private String transactionOriginId;
    private String customerCategoryId;
    private String recordKey;
    
	public String getCountSum() {
		return countSum != null ? countSum : "0";
	}
	
	public void setCountSum(String countSum) {
		this.countSum = countSum;
	}

	public String getWorkflowApiTypeId() {
		return workflowApiTypeId;
	}

	public void setWorkflowApiTypeId(String workflowApiTypeId) {
		this.workflowApiTypeId = workflowApiTypeId;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public String getDecisionSource() {
		return decisionSource;
	}

	public void setDecisionSource(String decisionSource) {
		this.decisionSource = decisionSource;
	}
   
	public String getKbaSupplierId() {
		return kbaSupplierId;
	}

	public void setKbaSupplierId(String kbaSupplierId) {
		this.kbaSupplierId = kbaSupplierId;
	}

	public String getTransactionOriginId() {
		return transactionOriginId;
	}

	public void setTransactionOriginId(String transactionOriginId) {
		this.transactionOriginId = transactionOriginId;
	}

	public String getCustomerCategoryId() {
		return customerCategoryId;
	}

	public void setCustomerCategoryId(String customerCategoryId) {
		this.customerCategoryId = customerCategoryId;
	}

	public String getRecordKey() {
		return recordKey;
	}

	public void setRecordKey(String recordKey) {
		this.recordKey = recordKey;
	}
}
