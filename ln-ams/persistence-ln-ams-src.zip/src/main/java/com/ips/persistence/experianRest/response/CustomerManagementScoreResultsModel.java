package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class CustomerManagementScoreResultsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String score;	           //Max Length:8
	private CustomerManagementScoreFactorsModel scoreFactors;		   //Max Length:40
	
	public String getScore() {
		return score;
	}
	
	public void setScore(String score) {
		this.score = score;
	}

	public CustomerManagementScoreFactorsModel getScoreFactors() {
		return scoreFactors;
	}

	public void setScoreFactors(CustomerManagementScoreFactorsModel scoreFactors) {
		this.scoreFactors = scoreFactors;
	}
	
}
