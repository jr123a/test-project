package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchConsumerIDModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseMatchConsumerIDSummaryModel summary;	           //Max Length:8

	public PreciseMatchConsumerIDSummaryModel getSummary() {
		return summary;
	}

	public void setSummary(PreciseMatchConsumerIDSummaryModel summary) {
		this.summary = summary;
	}
	
}
