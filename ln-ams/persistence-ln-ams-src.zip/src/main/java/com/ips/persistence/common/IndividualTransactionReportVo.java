package com.ips.persistence.common;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;

public class IndividualTransactionReportVo {

    private String env;
    private Date startDate;
    private Date endDate;
    
    private String area;
    private String district;
    private String facilityName;
    private long facilityId;
    private String customerName;
    private String result;
    private String enrollmentCode;
    private long primaryType;
    private String primaryDescription;
    private long secondaryType;
    private String secondaryDescription;
    private String failureReason;
    private String aceId;
    private String customerStreet;
    private String customerCity;
    private String customerState;
    private String customerZip;
    private Timestamp optInDate;
    private Timestamp transactionEndDateTime;
    private String transactionTime;
    private String requestSuccess;
    private String finalSuccess;
    private long failedAttempts;
    private boolean failureEmailSent;
    private long numberOfAttempts;
    
    public IndividualTransactionReportVo() {
    }
    
    public String getEnv() {
        return env;
    }
    public void setEnv(String env) {
        this.env = env;
    }
    
    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getArea() {
        return area == null ? "" : area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDistrict() {
        return district == null ? "" : district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getFacilityName() {
        return facilityName == null ? "" : facilityName;
    }

    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName;
    }

    public String getFacilityId() {
        return facilityId == 0L ? "" : String.valueOf(facilityId);
    }

    public void setFacilityId(long facilityId) {
        this.facilityId = facilityId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getEnrollmentCode() {
        return enrollmentCode;
    }

    public void setEnrollmentCode(String enrollmentCode) {
        this.enrollmentCode = enrollmentCode;
    }

    public String getPrimaryType() {
        return primaryType == 0L ? "" : String.valueOf(primaryType);
    }

    public void setPrimaryType(long primaryType) {
        this.primaryType = primaryType;
    }

    public String getPrimaryDescription() {
        return primaryDescription == null ? "" : primaryDescription;
    }

    public void setPrimaryDescription(String primaryDescription) {
        this.primaryDescription = primaryDescription;
    }

    public String getSecondaryType() {
        return secondaryType == 0L ? "" : String.valueOf(secondaryType);
    }

    public void setSecondaryType(long secondaryType) {
        this.secondaryType = secondaryType;
    }

    public String getSecondaryDescription() {
        return secondaryDescription == null ? "" : secondaryDescription;
    }

    public void setSecondaryDescription(String secondaryDescription) {
        this.secondaryDescription = secondaryDescription;
    }

    public String getFailureReason() {
        return failureReason == null ? "" : failureReason;
    }

    public void setFailureReason(String failureReason) {
        this.failureReason = failureReason;
    }

    public String getAceId() {
        return aceId == null ? "" : aceId;
    }

    public void setAceId(String aceId) {
        this.aceId = aceId;
    }

    public String getCustomerStreet() {
        return customerStreet;
    }

    public void setCustomerStreet(String customerStreet) {
        this.customerStreet = customerStreet;
    }

    public String getCustomerCity() {
        return customerCity;
    }

    public void setCustomerCity(String customerCity) {
        this.customerCity = customerCity;
    }

    public String getCustomerState() {
        return customerState;
    }

    public void setCustomerState(String customerState) {
        this.customerState = customerState;
    }

    public String getCustomerZip() {
        return customerZip;
    }

    public void setCustomerZip(String customerZip) {
        this.customerZip = customerZip;
    }
    
    public String getOptInDate() {
        SimpleDateFormat sdf = new SimpleDateFormat(DateTimeUtil.DATE_FORMAT);
        return optInDate == null ? "" : sdf.format(optInDate);
    }

    public void setOptInDate(Timestamp optInDate) {
        this.optInDate = optInDate;
    }

    public String getTransactionEndDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
        return transactionEndDateTime == null ? "" : sdf.format(transactionEndDateTime);
    }

    public void setTransactionEndDateTime(Timestamp transactionEndDateTime) {
        this.transactionEndDateTime = transactionEndDateTime;
    }

    public String getTransactionTime() {
        // Only return the MM:SS portion of the time +000000000 00:00:28.000000
        if (transactionTime != null) {
            int startIndex = transactionTime.indexOf(':') + 1;
            int endIndex = startIndex + 5;
            return transactionTime.substring(startIndex, endIndex);
        }
        else {
            return "";
        }
    }
    
    public int getTxnTimeInSeconds() {
        String txnTime = getTransactionTime();
        if (txnTime == null) {
            return 0;
        }
        else {
            String[] fragments = txnTime.split(":");
            int minutes = Integer.parseInt(fragments[0]);
            int seconds = Integer.parseInt(fragments[1]);
            CustomLogger.debug(this.getClass(), "Time: " + txnTime + " Minutes: " + minutes + " Seconds: " + seconds);
            int txnSeconds = minutes * 60 + seconds;
            CustomLogger.debug(this.getClass(), "Txn Seconds: " + txnSeconds);
            return txnSeconds;
        }
    }

    public void setTransactionTime(String transactionTime) {
        this.transactionTime = transactionTime;
    }

    public void setRequestSuccess(String requestSuccess) {
        this.requestSuccess = requestSuccess;
    }

    public void setFinalSuccess(String finalSuccess) {
        this.finalSuccess = finalSuccess;
    }

    public String getFinalSuccess() {
        return finalSuccess;
    }
    
    public long getFailedAttempts() {
        return failedAttempts;
    }

    public void setFailedAttempts(long failedAttempts) {
        this.failedAttempts = failedAttempts;
    }

    public boolean isResultSentSuccessfully() {
        return "Y".equalsIgnoreCase(this.requestSuccess) || "Y".equalsIgnoreCase(this.finalSuccess);
    }

    public boolean isFailureEmailSent() {
        return failureEmailSent;
    }

    public void setFailureEmailSent(boolean failureEmailSent) {
        this.failureEmailSent = failureEmailSent;
    }

    public long getNumberOfAttempts() {
        return numberOfAttempts;
    }

    public void setNumberOfAttempts(long numberOfAttempts) {
        this.numberOfAttempts = numberOfAttempts;
    }
}
