package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchAddressModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String serviceName;	           //Mandatory:Y, Max Length:8

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
}
