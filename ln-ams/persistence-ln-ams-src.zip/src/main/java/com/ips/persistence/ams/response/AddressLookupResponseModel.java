package com.ips.persistence.ams.response;

import java.io.Serializable;
import java.util.List;

public class AddressLookupResponseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<AddressLookupResultModel> addressLookupResultList;

	public List<AddressLookupResultModel> getAddressLookupResultList() {
		return addressLookupResultList;
	}

	public void setAddressLookupResultList(List<AddressLookupResultModel> addressLookupResultList) {
		this.addressLookupResultList = addressLookupResultList;
	}	           
	
}
