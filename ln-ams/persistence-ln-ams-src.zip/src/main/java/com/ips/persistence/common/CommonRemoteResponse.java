package com.ips.persistence.common;

import java.io.Serializable;

public class CommonRemoteResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    private String transactionID;
    private String sessionID;
    private String conversationID;
    private String reference;
    private String identityVerified;
    private String phoneVerified;
    private String phoneVerificationDecision;
    private String passcodeSent;
    private String passcodeExpired;
    private String transactionExpired;
    private String passcodeSubmitExceeded;
    private String smfaLinkSent;
    private String reviewStatus;
    private String smfaStatus;
    private String reasonCode;
    private String lockoutExpiresDateTime;
    private String lockoutStillInEffect;
    private String supplierEffectingLockout;
    private String phoneAttemptLimitReached;
    private String passcodeAttemptLimitReached;
    private String smfaLinkAttemptLimitReached;
    private String individualNotFound;
    private String responseMessage;
    private String responseData;
    private String redirectUrl;
    private Long phoneAttemptsIn72Hours;
    private Long passcodeAttemptsIn180Hours;
    private Long smfaLinkAttemptsIn180Hours;

    public String getTransactionID() {
        return transactionID;
    }
	
    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }
	
    public String getConversationID() {
		return conversationID;
	}
	
	public void setConversationID(String conversationID) {
		this.conversationID = conversationID;
	}
	
	public String getSessionID() {
		return sessionID;
	}
	
	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
	
	public String getIdentityVerified() {
        return identityVerified;
    }
	
    public void setIdentityVerified(String identityVerified) {
        this.identityVerified = identityVerified;
    }
	
    public String getPhoneVerified() {
        return phoneVerified;
    }
	
    public void setPhoneVerified(String phoneVerified) {
        this.phoneVerified = phoneVerified;
    }
	
    public String getPhoneVerificationDecision() {
		return phoneVerificationDecision;
	}
	
	public void setPhoneVerificationDecision(String phoneVerificationDecision) {
		this.phoneVerificationDecision = phoneVerificationDecision;
	}
	
	public String getPasscodeSent() {
        return passcodeSent;
    }
	
    public void setPasscodeSent(String passcodeSent) {
        this.passcodeSent = passcodeSent;
    }
	
    public String getPasscodeExpired() {
        return passcodeExpired;
    }
	
    public void setPasscodeExpired(String passcodeExpired) {
        this.passcodeExpired = passcodeExpired;
    }
	
    public String getSmfaLinkSent() {
		return smfaLinkSent;
	}
	
	public void setSmfaLinkSent(String smfaLinkSent) {
		this.smfaLinkSent = smfaLinkSent;
	}
	
	public String getReviewStatus() {
		return reviewStatus;
	}
	
	public void setReviewStatus(String reviewStatus) {
		this.reviewStatus = reviewStatus;
	}
	
	public String getSmfaStatus() {
		return smfaStatus;
	}
	
	public void setSmfaStatus(String smfaStatus) {
		this.smfaStatus = smfaStatus;
	}
	
	public String getReasonCode() {
		return reasonCode;
	}
	
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	
	public String getLockoutExpiresDateTime() {
        return lockoutExpiresDateTime;
    }
	
    public void setLockoutExpiresDateTime(String lockoutExpiresDateTime) {
        this.lockoutExpiresDateTime = lockoutExpiresDateTime;
    }
	
    public String getResponseMessage() {
        return responseMessage;
    }
	
    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public Long getPhoneAttemptsIn72Hours() {
        return phoneAttemptsIn72Hours;
    }
	
    public void setPhoneAttemptsIn72Hours(Long phoneAttemptsIn72Hours) {
        this.phoneAttemptsIn72Hours = phoneAttemptsIn72Hours;
    }
	
    public Long getPasscodeAttemptsIn180Hours() {
        return passcodeAttemptsIn180Hours;
    }
	
    public void setPasscodeAttemptsIn180Hours(Long passcodeAttemptsIn180Hours) {
        this.passcodeAttemptsIn180Hours = passcodeAttemptsIn180Hours;
    }

	public Long getSmfaLinkAttemptsIn180Hours() {
		return smfaLinkAttemptsIn180Hours;
	}

	public void setSmfaLinkAttemptsIn180Hours(Long smfaLinkAttemptsIn180Hours) {
		this.smfaLinkAttemptsIn180Hours = smfaLinkAttemptsIn180Hours;
	}

	public String getLockoutStillInEffect() {
		return lockoutStillInEffect;
	}

	public void setLockoutStillInEffect(String lockoutStillInEffect) {
		this.lockoutStillInEffect = lockoutStillInEffect;
	}

	public String getSupplierEffectingLockout() {
		return supplierEffectingLockout;
	}

	public void setSupplierEffectingLockout(String supplierEffectingLockout) {
		this.supplierEffectingLockout = supplierEffectingLockout;
	}

	public String getPhoneAttemptLimitReached() {
		return phoneAttemptLimitReached;
	}

	public void setPhoneAttemptLimitReached(String phoneAttemptLimitReached) {
		this.phoneAttemptLimitReached = phoneAttemptLimitReached;
	}

	public String getPasscodeAttemptLimitReached() {
		return passcodeAttemptLimitReached;
	}

	public void setPasscodeAttemptLimitReached(String passcodeAttemptLimitReached) {
		this.passcodeAttemptLimitReached = passcodeAttemptLimitReached;
	}

	public String getSmfaLinkAttemptLimitReached() {
		return smfaLinkAttemptLimitReached;
	}

	public void setSmfaLinkAttemptLimitReached(String smfaLinkAttemptLimitReached) {
		this.smfaLinkAttemptLimitReached = smfaLinkAttemptLimitReached;
	}

	public String getRedirectUrl() {
		return redirectUrl;
	}

	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

	public String getTransactionExpired() {
		return transactionExpired;
	}

	public void setTransactionExpired(String transactionExpired) {
		this.transactionExpired = transactionExpired;
	}

	public String getPasscodeSubmitExceeded() {
		return passcodeSubmitExceeded;
	}

	public void setPasscodeSubmitExceeded(String passcodeSubmitExceeded) {
		this.passcodeSubmitExceeded = passcodeSubmitExceeded;
	}

	public String getResponseData() {
		return responseData;
	}

	public void setResponseData(String responseData) {
		this.responseData = responseData;
	}

	public String getIndividualNotFound() {
		return individualNotFound;
	}

	public void setIndividualNotFound(String individualNotFound) {
		this.individualNotFound = individualNotFound;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}
}
