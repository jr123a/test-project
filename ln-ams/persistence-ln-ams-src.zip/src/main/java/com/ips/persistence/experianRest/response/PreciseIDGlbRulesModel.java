package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseIDGlbRulesModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<ValueCodeModel> glbRule;	           //Max Length:8

	public List<ValueCodeModel> getGlbRule() {
		return glbRule;
	}

	public void setGlbRule(List<ValueCodeModel> glbRule) {
		this.glbRule = glbRule;
	}
	
}
