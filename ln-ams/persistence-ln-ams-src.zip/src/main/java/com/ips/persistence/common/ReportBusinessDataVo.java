package com.ips.persistence.common;

import java.util.List;

import com.ibm.json.java.JSONObject;
import com.ips.common.common.CustomLogger;

public class ReportBusinessDataVo {

    private int deviceEmailRiskPassVol = 0;
    private int deviceEmailRiskFailVol = 0;
    private int deviceEmailRiskErrorVol = 0;
    private int deviceEmailRiskTotalVol = 0;
     
    private int businessInstantIdPassVol = 0;
    private int businessInstantIdFailVol = 0;
    private int businessInstantIdErrorVol = 0;
    private int businessInstantIdTotalVol = 0;
    
    private int amsAddressCheckPassVol = 0;
    private int amsAddressCheckFailVol = 0;
    private int amsAddressCheckErrorVol = 0;
    private int amsAddressCheckTotalVol = 0;

    
    private List<WorkflowApiDecisionVo> wkflowApiDecisionVoList;

    public void loadData(List<WorkflowApiDecisionVo> wkflowApiDecisionVoList) {
    	/*
    	for (WorkflowApiDecisionVo vo : wkflowApiDecisionVoList) {
			CustomLogger.info(this.getClass(), "ReportIndividualDataVo loadData getRecordKey:" + vo.getRecordKey() + " => getKbaSupplierId:" 
    		+ vo.getKbaSupplierId() + " => getWorkflowApiTypeId:" + vo.getWorkflowApiTypeId() + " => getDecision:" + vo.getDecision() 
    		+ " => getDecisionSource:" + vo.getDecisionSource() 	+ " => getTransactionOriginId:" 
    		+ vo.getTransactionOriginId() + " => getCountSum:" + vo.getCountSum());
    	}
    	*/
		setWkflowApiDecisionVoList(wkflowApiDecisionVoList);
	}
    
    private WorkflowApiDecisionVo getWorkflowApiDecisionVo (String recKey) {
    	WorkflowApiDecisionVo wkflowApiDecisionVo = this.wkflowApiDecisionVoList.stream().filter(decisionVo -> recKey.equalsIgnoreCase(decisionVo.getRecordKey()))
                 .findFirst().orElse(null);

    	return wkflowApiDecisionVo;
 	}
    
    public JSONObject getDeviceEmailRiskDataJSONObject(String key) {
    	JSONObject resultJSON = new JSONObject();
     	int workflowTypeId = 7; 
     	
    	switch(key) {
    		case "deviceEmailRiskPass": 
	    		resultJSON.put("volume", getDeviceEmailRiskPassVol(getRecordKey(workflowTypeId, "PASS", "APIResult")));
	        	resultJSON.put("description", "Transaction passed DeviceEmailRisk API call.");
	        	break;
    		case "deviceEmailRiskFail": 
	    		resultJSON.put("volume", getDeviceEmailRiskFailVol(getRecordKey(workflowTypeId, "FAIL", "APIResult")));
	        	resultJSON.put("description", "Transaction failed DeviceEmailRisk API call.");
	        	break;
    		case "deviceEmailRiskError": 
	    		resultJSON.put("volume", getDeviceEmailRiskErrorVol(getRecordKey(workflowTypeId, "FAIL", "Error")));
	        	resultJSON.put("description", "Error occurred during DeviceEmailRisk API call.");
	        	break;
    		case "deviceEmailRiskTotal": 
    			resultJSON.put("volume", getDeviceEmailRiskTotalVol());
	        	resultJSON.put("description", "Total transactions calling DeviceEmailRisk API.");
	        	break;
    		default:    
    	}

    	return resultJSON;
	}
    
    public JSONObject getBusinessInstantIdDataJSONObject(String key) {
    	JSONObject resultJSON = new JSONObject();
     	int workflowTypeId = 8; 
     	
    	switch(key) {
    		case "businessInstantIdPass": 
	    		resultJSON.put("volume", getBusinessInstantIdPassVol(getRecordKey(workflowTypeId, "PASS", "APIResult")));
	        	resultJSON.put("description", "Transaction passed BusinessInstantId API call.");
	        	break;
    		case "businessInstantIdFail": 
	    		resultJSON.put("volume", getBusinessInstantIdFailVol(getRecordKey(workflowTypeId, "FAIL", "APIResult")));
	        	resultJSON.put("description", "Transaction failed BusinessInstantId API call.");
	        	break;
    		case "businessInstantIdError": 
	    		resultJSON.put("volume", getBusinessInstantIdErrorVol(getRecordKey(workflowTypeId, "FAIL", "Error")));
	        	resultJSON.put("description", "Error occurred during BusinessInstantId API call.");
	        	break;
    		case "businessInstantIdTotal": 
    			resultJSON.put("volume", getBusinessInstantIdTotalVol());
	        	resultJSON.put("description", "Total transactions calling BusinessInstantId API.");
	        	break;
    		default:    
    	}

    	return resultJSON;
	}
       
    public JSONObject getAmsAddressCheckDataJSONObject(String key) {
    	JSONObject resultJSON = new JSONObject();
     	int workflowTypeId = 9; 
     	
    	switch(key) {
    		case "amsAddressCheckPass": 
	    		resultJSON.put("volume", getAmsAddressCheckPassVol(getRecordKey(workflowTypeId, "PASS", "APIResult")));
	        	resultJSON.put("description", "Transaction passed AmsAddressCheck API call.");
	        	break;
    		case "amsAddressCheckFail": 
	    		resultJSON.put("volume", getAmsAddressCheckFailVol(getRecordKey(workflowTypeId, "FAIL", "APIResult")));
	        	resultJSON.put("description", "Transaction failed AmsAddressCheck API call.");
	        	break;
    		case "amsAddressCheckError": 
	    		resultJSON.put("volume", getAmsAddressCheckErrorVol(getRecordKey(workflowTypeId, "FAIL", "Error")));
	        	resultJSON.put("description", "Error occurred during AmsAddressCheck API call.");
	        	break;
    		case "amsAddressCheckTotal": 
    			resultJSON.put("volume", getAmsAddressCheckTotalVol());
	        	resultJSON.put("description", "Total transactions calling AmsAddressCheck API.");
	        	break;
    		default:    
    	}

    	return resultJSON;
	}

    private String getRecordKey(int workflowTypeId, String decision, String decisionSource) {
     	return String.format("%s%s%s", workflowTypeId, decision, decisionSource);
    }
    
    private String getRecordKey(int suppierId, int workflowTypeId, String decision, String decisionSource) {
     	return String.format("%s%s%s%s", suppierId, workflowTypeId, decision, decisionSource);
    }
    
    public int getVolume(String recKey) {
     	WorkflowApiDecisionVo vo = getWorkflowApiDecisionVo(recKey);
    	String countSum = vo != null ? vo.getCountSum() : "0";
    	int volume = Integer.parseInt(countSum);
		return volume;
	}
    
	public int getDeviceEmailRiskPassVol(String recKey) {
		deviceEmailRiskPassVol = getVolume(recKey);
		return deviceEmailRiskPassVol;
	}

	public void setDeviceEmailRiskPassVol(int deviceEmailRiskPassVol) {
		this.deviceEmailRiskPassVol = deviceEmailRiskPassVol;
	}

	public int getDeviceEmailRiskFailVol(String recKey) {
		deviceEmailRiskFailVol = getVolume(recKey);
		return deviceEmailRiskFailVol;
	}

	public void setDeviceEmailRiskFailVol(int deviceEmailRiskFailVol) {
		this.deviceEmailRiskFailVol = deviceEmailRiskFailVol;
	}

	public int getDeviceEmailRiskErrorVol(String recKey) {
		deviceEmailRiskErrorVol = getVolume(recKey);
		return deviceEmailRiskErrorVol;
	}

	public void setDeviceEmailRiskErrorVol(int deviceEmailRiskErrorVol) {
		this.deviceEmailRiskErrorVol = deviceEmailRiskErrorVol;
	}

	public int getDeviceEmailRiskTotalVol() {
		deviceEmailRiskTotalVol = deviceEmailRiskPassVol + deviceEmailRiskFailVol + deviceEmailRiskErrorVol;
		return deviceEmailRiskTotalVol;
	}

	public void setDeviceEmailRiskTotalVol(int deviceEmailRiskTotalVol) {
		this.deviceEmailRiskTotalVol = deviceEmailRiskTotalVol;
	}

	public int getBusinessInstantIdPassVol(String recKey) {
		businessInstantIdPassVol = getVolume(recKey);
		return businessInstantIdPassVol;
	}

	public void setBusinessInstantIdPassVol(int businessInstantIdPassVol) {
		this.businessInstantIdPassVol = businessInstantIdPassVol;
	}

	public int getBusinessInstantIdFailVol(String recKey) {
		businessInstantIdFailVol = getVolume(recKey);
		return businessInstantIdFailVol;
	}

	public void setBusinessInstantIdFailVol(int businessInstantIdFailVol) {
		this.businessInstantIdFailVol = businessInstantIdFailVol;
	}

	public int getBusinessInstantIdErrorVol(String recKey) {
		businessInstantIdErrorVol = getVolume(recKey);
		return businessInstantIdErrorVol;
	}

	public void setBusinessInstantIdErrorVol(int businessInstantIdErrorVol) {
		this.businessInstantIdErrorVol = businessInstantIdErrorVol;
	}

	public int getBusinessInstantIdTotalVol() {
		businessInstantIdTotalVol = businessInstantIdPassVol + businessInstantIdFailVol + businessInstantIdErrorVol;
		return businessInstantIdTotalVol;
	}

	public void setBusinessInstantIdTotalVol(int businessInstantIdTotalVol) {
		this.businessInstantIdTotalVol = businessInstantIdTotalVol;
	}

	public int getAmsAddressCheckPassVol(String recKey) {
		amsAddressCheckPassVol = getVolume(recKey);
		return amsAddressCheckPassVol;
	}

	public void setAmsAddressCheckPassVol(int amsAddressCheckPassVol) {
		this.amsAddressCheckPassVol = amsAddressCheckPassVol;
	}

	public int getAmsAddressCheckFailVol(String recKey) {
		amsAddressCheckFailVol = getVolume(recKey);
		return amsAddressCheckFailVol;
	}

	public void setAmsAddressCheckFailVol(int amsAddressCheckFailVol) {
		this.amsAddressCheckFailVol = amsAddressCheckFailVol;
	}

	public int getAmsAddressCheckErrorVol(String recKey) {
		amsAddressCheckErrorVol = getVolume(recKey);
		return amsAddressCheckErrorVol;
	}

	public void setAmsAddressCheckErrorVol(int amsAddressCheckErrorVol) {
		this.amsAddressCheckErrorVol = amsAddressCheckErrorVol;
	}

	public int getAmsAddressCheckTotalVol() {
		amsAddressCheckTotalVol = amsAddressCheckPassVol + amsAddressCheckFailVol + amsAddressCheckErrorVol;
		return amsAddressCheckTotalVol;
	}

	public void setAmsAddressCheckTotalVol(int amsAddressCheckTotalVol) {
		this.amsAddressCheckTotalVol = amsAddressCheckTotalVol;
	}

	public List<WorkflowApiDecisionVo> getWkflowApiDecisionVoList() {
		return wkflowApiDecisionVoList;
	}

	public void setWkflowApiDecisionVoList(List<WorkflowApiDecisionVo> wkflowApiDecisionVoList) {
		this.wkflowApiDecisionVoList = wkflowApiDecisionVoList;
	}
    
   
}
