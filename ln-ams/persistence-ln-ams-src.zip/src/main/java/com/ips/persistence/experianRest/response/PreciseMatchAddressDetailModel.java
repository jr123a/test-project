package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseMatchAddressDetailModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseMatchStandardizedAddressRcdModel  standardizedAddressRcd;	           //Mandatory:Y, Max Length:8
	private List<String> residentialAddressRcd;
	private List<String> highRiskAddressRcd;
	private List<PreciseMatchHighRiskDescriptionModel> highRiskAddressDescription;
	private List<String> businessAddressRcd;
	
	public PreciseMatchStandardizedAddressRcdModel getStandardizedAddressRcd() {
		return standardizedAddressRcd;
	}

	public void setStandardizedAddressRcd(PreciseMatchStandardizedAddressRcdModel standardizedAddressRcd) {
		this.standardizedAddressRcd = standardizedAddressRcd;
	}

	public List<String> getResidentialAddressRcd() {
		return residentialAddressRcd;
	}

	public void setResidentialAddressRcd(List<String> residentialAddressRcd) {
		this.residentialAddressRcd = residentialAddressRcd;
	}

	public List<String> getHighRiskAddressRcd() {
		return highRiskAddressRcd;
	}

	public void setHighRiskAddressRcd(List<String> highRiskAddressRcd) {
		this.highRiskAddressRcd = highRiskAddressRcd;
	}

	public List<PreciseMatchHighRiskDescriptionModel> getHighRiskAddressDescription() {
		return highRiskAddressDescription;
	}

	public void setHighRiskAddressDescription(List<PreciseMatchHighRiskDescriptionModel> highRiskAddressDescription) {
		this.highRiskAddressDescription = highRiskAddressDescription;
	}

	public List<String> getBusinessAddressRcd() {
		return businessAddressRcd;
	}

	public void setBusinessAddressRcd(List<String> businessAddressRcd) {
		this.businessAddressRcd = businessAddressRcd;
	}
	
}
