package com.ips.persistence.experianRest.request;

import java.io.Serializable;
import java.util.List;

public class PayloadContactModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String id;	       					    
	private ContactPersonModel person;		        
	private List<ContactAddressModel> addresses;	
	private List<ContactEmailModel> emails;		    
	private List<ContactTelephoneModel> telephones;	
	private List<ContactIdentityDocumentModel> identityDocuments;	
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public ContactPersonModel getPerson() {
		return person;
	}

	public void setPerson(ContactPersonModel person) {
		this.person = person;
	}

	public List<ContactAddressModel> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<ContactAddressModel> addresses) {
		this.addresses = addresses;
	}

	public List<ContactEmailModel> getEmails() {
		return emails;
	}

	public void setEmails(List<ContactEmailModel> emails) {
		this.emails = emails;
	}

	public List<ContactTelephoneModel> getTelephones() {
		return telephones;
	}

	public void setTelephones(List<ContactTelephoneModel> telephones) {
		this.telephones = telephones;
	}

	public List<ContactIdentityDocumentModel> getIdentityDocuments() {
		return identityDocuments;
	}

	public void setIdentityDocuments(List<ContactIdentityDocumentModel> identityDocuments) {
		this.identityDocuments = identityDocuments;
	}
	
}
