package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseIDErrorModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String reportDate;	            //Max Length:8, dataFormat:Numeric
	private String reportTime;		  		//Max Length:6, dataFormat:Numeric
	private String transactionID;		  	//Max Length:64, dataFormat:Alphanumeric
	private String surname;		  		//Max Length:32, dataFormat:Alphanumeric
	private String firstName;		  		//Max Length:32, dataFormat:Alphanumeric
	private String errorCode;		  		//Max Length:3, dataFormat:Numeric
	private String errorDescription;		//Max Length:300, dataFormat:Alphanumeric
	private PreciseIDErrorActionIndicatorModel actionIndicator;	//Max Length:91
	private String referenceNumber;		//Max Length:30, dataFormat:Alphanumeric
	
	public String getReportDate() {
		return reportDate;
	}
	
	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}

	public String getReportTime() {
		return reportTime;
	}

	public void setReportTime(String reportTime) {
		this.reportTime = reportTime;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public PreciseIDErrorActionIndicatorModel getActionIndicator() {
		return actionIndicator;
	}

	public void setActionIndicator(PreciseIDErrorActionIndicatorModel actionIndicator) {
		this.actionIndicator = actionIndicator;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

}
