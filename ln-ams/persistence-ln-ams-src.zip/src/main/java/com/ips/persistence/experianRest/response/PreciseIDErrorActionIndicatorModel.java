package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseIDErrorActionIndicatorModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ValueCodeModel actionIndicator;	//Max Length:91

	public ValueCodeModel getActionIndicator() {
		return actionIndicator;
	}

	public void setActionIndicator(ValueCodeModel actionIndicator) {
		this.actionIndicator = actionIndicator;
	}
			
}
