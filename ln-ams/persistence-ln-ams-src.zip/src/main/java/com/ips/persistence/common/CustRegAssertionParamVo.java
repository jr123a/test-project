package com.ips.persistence.common;

import java.io.Serializable;

public class CustRegAssertionParamVo implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String loaSought;
    private String loaFlag;
    private String loaName;
    private String verificationDecision;
    private String verificationMatchQuality;
    private String verificationMatchLevel;
    private String productStatus;
    private String proofingStatus;
    private String mobilePhone;
    private String transactionKey;
    private String avsErrorsDatetime;
    private String phoneTrust;
    private String identityTrust;
    private String addressTrust;
    private String path;
    private String sessionId;
    private String transactionId;
    private long rpStatusCode;
    private long verificationSentDatetime;
    private long verificationDecisionDatetime;
    private long totalSubmitAttempts;
    private long totalRenewAttempts;
    private long attemptsAllowed;
    private long attemptsMade;
    private long attemptsPeriod;
    private long totalIPSAttempts; 
    private long totalEIDAttempts;
    private long supplierId;
    
	public String getLoaSought() {
		return loaSought;
	}
	
	public void setLoaSought(String loaSought) {
		this.loaSought = loaSought;
	}

	public String getLoaFlag() {
		return loaFlag;
	}

	public void setLoaFlag(String loaFlag) {
		this.loaFlag = loaFlag;
	}

	public String getLoaName() {
		return loaName;
	}

	public void setLoaName(String loaName) {
		this.loaName = loaName;
	}
	
	public String getVerificationDecision() {
		return verificationDecision;
	}

	public void setVerificationDecision(String verificationDecision) {
		this.verificationDecision = verificationDecision;
	}

	public String getVerificationMatchQuality() {
		return verificationMatchQuality;
	}

	public void setVerificationMatchQuality(String verificationMatchQuality) {
		this.verificationMatchQuality = verificationMatchQuality;
	}

	public String getVerificationMatchLevel() {
		return verificationMatchLevel;
	}

	public void setVerificationMatchLevel(String verificationMatchLevel) {
		this.verificationMatchLevel = verificationMatchLevel;
	}

	public String getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	public String getProofingStatus() {
		return proofingStatus;
	}

	public void setProofingStatus(String proofingStatus) {
		this.proofingStatus = proofingStatus;
	}

	public long getRpStatusCode() {
		return rpStatusCode;
	}

	public void setRpStatusCode(long rpStatusCode) {
		this.rpStatusCode = rpStatusCode;
	}

	public long getVerificationSentDatetime() {
		return verificationSentDatetime;
	}

	public void setVerificationSentDatetime(long verificationSentDatetime) {
		this.verificationSentDatetime = verificationSentDatetime;
	}

	public long getVerificationDecisionDatetime() {
		return verificationDecisionDatetime;
	}

	public void setVerificationDecisionDatetime(long verificationDecisionDatetime) {
		this.verificationDecisionDatetime = verificationDecisionDatetime;
	}

	public long getTotalSubmitAttempts() {
		return totalSubmitAttempts;
	}

	public void setTotalSubmitAttempts(long totalSubmitAttempts) {
		this.totalSubmitAttempts = totalSubmitAttempts;
	}

	public long getTotalRenewAttempts() {
		return totalRenewAttempts;
	}

	public void setTotalRenewAttempts(long totalRenewAttempts) {
		this.totalRenewAttempts = totalRenewAttempts;
	}

	public long getAttemptsAllowed() {
		return attemptsAllowed;
	}

	public void setAttemptsAllowed(long attemptsAllowed) {
		this.attemptsAllowed = attemptsAllowed;
	}

	public long getAttemptsMade() {
		return attemptsMade;
	}

	public void setAttemptsMade(long attemptsMade) {
		this.attemptsMade = attemptsMade;
	}

	public long getAttemptsPeriod() {
		return attemptsPeriod;
	}

	public void setAttemptsPeriod(long attemptsPeriod) {
		this.attemptsPeriod = attemptsPeriod;
	}

	public long getTotalIPSAttempts() {
		return totalIPSAttempts;
	}

	public void setTotalIPSAttempts(long totalIPSAttempts) {
		this.totalIPSAttempts = totalIPSAttempts;
	}

	public long getTotalEIDAttempts() {
		return totalEIDAttempts;
	}

	public void setTotalEIDAttempts(long totalEIDAttempts) {
		this.totalEIDAttempts = totalEIDAttempts;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getTransactionKey() {
		return transactionKey;
	}

	public void setTransactionKey(String transactionKey) {
		this.transactionKey = transactionKey;
	}

	public String getAvsErrorsDatetime() {
		return avsErrorsDatetime;
	}

	public void setAvsErrorsDatetime(String avsErrorsDatetime) {
		this.avsErrorsDatetime = avsErrorsDatetime;
	}

	public String getPhoneTrust() {
		return phoneTrust;
	}

	public void setPhoneTrust(String phoneTrust) {
		this.phoneTrust = phoneTrust;
	}

	public String getIdentityTrust() {
		return identityTrust;
	}

	public void setIdentityTrust(String identityTrust) {
		this.identityTrust = identityTrust;
	}

	public String getAddressTrust() {
		return addressTrust;
	}

	public void setAddressTrust(String addressTrust) {
		this.addressTrust = addressTrust;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public long getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(long supplierId) {
		this.supplierId = supplierId;
	}
 
}
