package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchSsnFinderSummaryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseMatchSsnFinderCountsModel counts;	           //Max Length:8

	public PreciseMatchSsnFinderCountsModel getCounts() {
		return counts;
	}

	public void setCounts(PreciseMatchSsnFinderCountsModel counts) {
		this.counts = counts;
	}
	
}
