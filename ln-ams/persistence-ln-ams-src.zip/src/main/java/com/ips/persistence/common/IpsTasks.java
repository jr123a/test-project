package com.ips.persistence.common;


import java.io.BufferedReader;
import java.io.File;
import java.io.Serializable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import com.ips.polocator.common.AppointmentVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.Utils;
import com.ips.entity.IppAppointment;
import com.ips.entity.PersonData;
import com.ips.entity.ReportExecuted;
import com.ips.proofing.VerifyAddressService;
import com.ips.service.IppAppoinmentService;
import com.ips.service.IppEventService;
import com.ips.service.OtpAttemptConfigService;
import com.ips.service.RefIppEventStatusService;
import com.ips.service.ReportService;
import com.ips.service.RpEventDataService;

public class IpsTasks implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private IppEventService ippEventService;
    @Autowired
    private IppAppoinmentService ippAppointmentService;
    @Autowired
    private Emailer emailer;
    @Autowired
    private VerifyAddressService verifyAddressService;
    @Autowired
    private RpEventDataService rpEventService;
    @Autowired
    private RefIppEventStatusService refIppEventStatusService;
    @Autowired
    private ReportService reportService;
    @Autowired
    private OtpAttemptConfigService otpAttemptConfigService;
    
    public static final String TOTAL = "TOTAL";
    public static final String REGION_DAILY_TOTAL = "All - Daily Total";
    private static final String FACILITY_COORDINATES = "Facility Coordinates";
	private static String OS = System.getProperty("os.name").toLowerCase();

    public IppEventService getIppEventService() {
        return ippEventService;
    }

    public void setIppEventService(IppEventService ippEventService) {
        this.ippEventService = ippEventService;
    }

    public IppAppoinmentService getIppAppointmentService() {
        return ippAppointmentService;
    }

    public void setIppAppointmentService(IppAppoinmentService ippAppointmentService) {
        this.ippAppointmentService = ippAppointmentService;
    }

    public Emailer getEmailer() {
        return emailer;
    }

    public void setEmailer(Emailer emailer) {
        this.emailer = emailer;
    }
    public VerifyAddressService getVerifyAddressService() {
        return verifyAddressService;
    }

    public void setVerifyAddressService(VerifyAddressService verifyAddressService) {
        this.verifyAddressService = verifyAddressService;
    }    

    public RpEventDataService getRpEventService() {
        return rpEventService;
    }

    public void setRpEventService(RpEventDataService rpEventService) {
        this.rpEventService = rpEventService;
    }    

    public RefIppEventStatusService getRefIppEventStatusService() {
        return refIppEventStatusService;
    }

    public void setRefIppEventStatusService(
            RefIppEventStatusService refIppEventStatusService) {
        this.refIppEventStatusService = refIppEventStatusService;
    }

	@PostConstruct
	public void init(){
		CustomLogger.debug(this.getClass(), "Validation Query: "+ippEventService.validationQuery());
	}
	
    public static boolean isWindows() {
        return OS.contains("win");
    }
    
	/**

     * This method empties the directory where the barcodes are located and 
     * sends IPP at residence reminder emails
     */
	public void sendReminderEmail(){
		// all the barcodes will be deleted in the directory
		GenerateBarcodeUtil barcodeUtil = new GenerateBarcodeUtil();
		barcodeUtil.emptyDirectory(30);
		
		// IPP at Residence reminder email will be sent
		CustomLogger.debug(this.getClass(), "Sending Reminder Emails at "+ new Date());
		Date appointmentDate = DateTimeUtil.getCurrentDate();
		
		CustomLogger.debug(this.getClass(), "Appointment: "+appointmentDate);
		List<IppAppointment> appts = ippAppointmentService.findAppointments(appointmentDate);
		for(int x=0; x<appts.size(); x++){
			PersonData personData = appts.get(x).getIppEvent().getPerson().getPersonData();
			CustomLogger.debug(this.getClass(), "Sending Reminder Email to User with sponsorUserId:" + appts.get(x).getIppEvent().getPerson().getSponsorUserId());
			
			//Set appointment date and time, and complete address to AppointmentVo
			AppointmentVo appt = new AppointmentVo();
			CustomLogger.debug(this.getClass(), "Appointment Date: "+appts.get(x).getAppointmentDate());
			appt.setScheduledDate(appts.get(x).getAppointmentDate());
			appt.setScheduledTime(appts.get(x).getAppointmentTime());
			appt.setAddress1(appts.get(x).getIppEvent().getPerson().getPersonData().getAddressLine1());
			String address2 = appts.get(x).getIppEvent().getPerson().getPersonData().getAddressLine2();
			if(address2 == null){
				appt.setAddress2("");
			} else if(address2 != null){
				appt.setAddress2(", "+address2);
			}
			appt.setCity(appts.get(x).getIppEvent().getPerson().getPersonData().getCity());
			appt.setState(appts.get(x).getIppEvent().getPerson().getPersonData().getStateProvince());
			appt.setZip4(appts.get(x).getIppEvent().getPerson().getPersonData().getPostalCode());
			
			//Generate barcode
			GenerateBarcodeUtil barcode = new GenerateBarcodeUtil();
			String barcodeFile = barcode.generateBarcode(appts.get(x).getRecordLocator());
			
			//Send reminder email
			try {
				emailer.sendIppEmail(barcodeFile, appts.get(x).getEmailAddress(), EmailText.getHTMLTextIPPResidence(appt, true), EmailText.IPP_SUBJECT, appts.get(x).getIppEvent().getPerson().getRefSponsor().getSponsorId());
				File file = new File(barcodeFile);
				file.delete();
				CustomLogger.debug(this.getClass(), "Reminder Email Sent to User with sponsorUserId: "+appts.get(x).getIppEvent().getPerson().getSponsorUserId() + " " + personData.getFullName()
						+", Barcode Deleted!");
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "IPP Email could not be sent to User with sponsorUserId:" + appts.get(x).getIppEvent().getPerson().getSponsorUserId(),e);
			}
		}
		CustomLogger.debug(this.getClass(), "Reminder Emails Sent at " + new Date());
	}
	

	/**
     * This method checks the DiskSpace on the AppServers and emails IVS if the used DiskSpace exceeds 80%..
     * 	If you are testing locally, make sure you change the quartz time to local time in ips.properties,
     *  and run b all to deploy it to the server.  
	 *  Your server has to be started and the application published before the start time otherwise it won't fire off.
	*/
	public void checkDiskSpace() {

		try {
			
			CustomLogger.info(this.getClass(), "Invoking checkDiskSpace... " + "OS: " + OS.toString());

			Process p = null;
			if (isWindows()) {
				p = Runtime.getRuntime().exec("c:\\windows\\system32\\cmd.exe /c dir c:\\Documents\\test");
			} else {
				// Get the environment to figure our which Unix Command to run.
			   	String env = Utils.getEnvironment();
			   	String envUnixCommand = "cd /ips/pips/a00/scripts; /ips/pips/a00/scripts/CHECK_DISK_SPACE.ksh pips"; //Default
		        if ("dev.".equalsIgnoreCase(env)) {
		        	envUnixCommand = "cd /ips/dips/a00/scripts; /ips/dips/a00/scripts/CHECK_DISK_SPACE.ksh dips";
		        }
		        else if ("sit.".equalsIgnoreCase(env)) {
		        	envUnixCommand = "cd /ips/tips/a00/scripts; /ips/tips/a00/scripts/CHECK_DISK_SPACE.ksh tips";
		        }
		        else if ("cat.".equalsIgnoreCase(env)) {
		        	envUnixCommand = "cd /ips/qips/a00/scripts; /ips/qips/a00/scripts/CHECK_DISK_SPACE.ksh qips";
		        }
		        else if ("prod.".equalsIgnoreCase(env)) {
		        	envUnixCommand = "cd /ips/pips/a00/scripts; /ips/pips/a00/scripts/CHECK_DISK_SPACE.ksh pips";
		        }
			   	
				p = Runtime.getRuntime().exec(new String[]{"/usr/bin/sh","-c",envUnixCommand});
				
			}
			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line = null;
		    while ((line = in.readLine()) != null) {
			  CustomLogger.info(this.getClass(), line );
		    }

			CustomLogger.info(this.getClass(), "Completed checkDiskSpace: " + new Date());
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			CustomLogger.info(this.getClass(), "An ERROR occured in checkDiskSpace()." );
			e.printStackTrace();
		}

	    
	}


	
	/**
     * This method resets the number of attempts in the rp_kba_attempts table, if needed.
     */
    public void resetOtpAttemptConfigList() {
        // Lock the rp_kba_attempts table so only one server will fire
        int rowsUpdated = otpAttemptConfigService.resetAttempts();
        
        CustomLogger.debug(this.getClass(), rowsUpdated + " rows in the OTP attempts config table had the number of attempts reset to 0 on " + new Date());
    }
    
    
    
    /**
     * This job checks the facility table for facilities that are missing coordinates (latitude and longitude).
     * If any are found, a call is made to PO Locator for each facility to retrieve the coordinates
     * and the facility is updated.  
     */
    public void updateFacilityCoordinates() {
        Date executionDate = new Date();
        Date previousRun = DateTimeUtil.getStartDate(DateTimeUtil.getDateMinusDays(executionDate, 1));
        
        // Lock the report_executed table so only one server will fire
        List<ReportExecuted> reports = reportService.findReports(FACILITY_COORDINATES, previousRun);
                
        if ( !(reports.isEmpty()) ) {
            CustomLogger.debug(this.getClass(), "Executing facility coordinates update...");
            
            // Update facilities that are missing coordinates
            verifyAddressService.populateGeocoordinates();
            
            CustomLogger.debug(this.getClass(), "Facility coordinates update complete...");
        }
        else {
            CustomLogger.debug(this.getClass(), "No " + FACILITY_COORDINATES + " record returned.  Job will not execute on this server.");
        }
    }
}

