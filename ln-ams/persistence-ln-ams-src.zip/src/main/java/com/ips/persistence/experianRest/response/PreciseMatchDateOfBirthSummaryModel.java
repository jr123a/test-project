package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchDateOfBirthSummaryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ValueCodeModel matchResult;	           //Max Length:8

	public ValueCodeModel getMatchResult() {
		return matchResult;
	}

	public void setMatchResult(ValueCodeModel matchResult) {
		this.matchResult = matchResult;
	}
	
}
