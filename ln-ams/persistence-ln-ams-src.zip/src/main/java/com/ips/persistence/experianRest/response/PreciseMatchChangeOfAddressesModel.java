package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseMatchChangeOfAddressesModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<PreciseMatchChangeOfAddressSummaryModel> changeOfAddress;	           //Max Length:8

	public List<PreciseMatchChangeOfAddressSummaryModel> getChangeOfAddress() {
		return changeOfAddress;
	}

	public void setChangeOfAddress(List<PreciseMatchChangeOfAddressSummaryModel> changeOfAddress) {
		this.changeOfAddress = changeOfAddress;
	}
	
}
