package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchChangeOfAddressSummaryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ValueCodeModel verificationResult;	           //Max Length:8
	private PreciseMatchChangeOfAddressCountsModel counts;
	
	public ValueCodeModel getVerificationResult() {
		return verificationResult;
	}
	
	public void setVerificationResult(ValueCodeModel verificationResult) {
		this.verificationResult = verificationResult;
	}

	public PreciseMatchChangeOfAddressCountsModel getCounts() {
		return counts;
	}

	public void setCounts(PreciseMatchChangeOfAddressCountsModel counts) {
		this.counts = counts;
	} 
	
}
