package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PayloadOtherDataResponseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String correlationId;	        
	private String referenceId;	        
	private String authenticationKey;	        
	private String evurl;
    	
	public String getCorrelationId() {
		return correlationId;
	}
	
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
	
	public String getReferenceId() {
		return referenceId;
	}
	
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
	
	public String getEvurl() {
		return evurl;
	}
	
	public void setEvurl(String evurl) {
		this.evurl = evurl;
	}

	public String getAuthenticationKey() {
		return authenticationKey;
	}

	public void setAuthenticationKey(String authenticationKey) {
		this.authenticationKey = authenticationKey;
	}	        

}
