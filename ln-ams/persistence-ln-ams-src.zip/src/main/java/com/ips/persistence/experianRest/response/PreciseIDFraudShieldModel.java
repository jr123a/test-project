package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseIDFraudShieldModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<ValueCodeModel> indicator;	           //Max Length:8

	public List<ValueCodeModel> getIndicator() {
		return indicator;
	}

	public void setIndicator(List<ValueCodeModel> indicator) {
		this.indicator = indicator;
	}

}
