package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchOfacCountsModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int ofacReturnCount;	           //Max Length:8

	public int getOfacReturnCount() {
		return ofacReturnCount;
	}

	public void setOfacReturnCount(int ofacReturnCount) {
		this.ofacReturnCount = ofacReturnCount;
	}
	
}
