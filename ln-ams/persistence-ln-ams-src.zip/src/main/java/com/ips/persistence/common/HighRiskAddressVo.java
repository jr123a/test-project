package com.ips.persistence.common;
 
public class HighRiskAddressVo {
    
    private String address;
    private String addressLineTwo;
    private String city;
    private String state;
    private String zip;
    private String zip11; 
    private String timestampAddedIntoList; 
    private String personId;
    private String custRegId;
    private String timestampWhenDirectedToIPP;
    private String timestampWhenOptInToIPP;
    private String timestampWhenGotToPostOffice;
    private String ippStatus; 
    private String failureReason;
    private String fraud; 
    private String dateTimeTobeChecked;
    private String dateTimeToStartRemoteProofing; 
    private String supplier; 
    private String rpStatus; 
    private String transasctionKey;     
    private String sponsor; 
    
    
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getAddressLineTwo() {
        return addressLineTwo;
    }
    public void setAddressLineTwo(String addressLineTwo) {
        this.addressLineTwo = addressLineTwo;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getZip() {
        return zip;
    }
    public void setZip(String zip) {
        this.zip = zip;
    }
    public String getZip11() {
        return zip11;
    }
    public void setZip11(String zip11) {
        this.zip11 = zip11;
    }
    public String getTimestampAddedIntoList() {
        return timestampAddedIntoList;
    }
    public void setTimestampAddedIntoList(String timestampAddedIntoList) {
        this.timestampAddedIntoList = timestampAddedIntoList;
    }
    public String getPersonId() {
        return personId;
    }
    public void setPersonId(String personId) {
        this.personId = personId;
    }
    public String getCustRegId() {
        return custRegId;
    }
    public void setCustRegId(String custRegId) {
        this.custRegId = custRegId;
    }
    public String getTimestampWhenDirectedToIPP() {
        return timestampWhenDirectedToIPP;
    }
    public void setTimestampWhenDirectedToIPP(String timestampWhenDirectedToIPP) {
        this.timestampWhenDirectedToIPP = timestampWhenDirectedToIPP;
    }
    public String getTimestampWhenOptInToIPP() {
        return timestampWhenOptInToIPP;
    }
    public void setTimestampWhenOptInToIPP(String timestampWhenOptInToIPP) {
        this.timestampWhenOptInToIPP = timestampWhenOptInToIPP;
    }
    public String getTimestampWhenGotToPostOffice() {
        return timestampWhenGotToPostOffice;
    }
    public void setTimestampWhenGotToPostOffice(String timestampWhenGotToPostOffice) {
        this.timestampWhenGotToPostOffice = timestampWhenGotToPostOffice;
    }
    public String getIppStatus() {
        return ippStatus;
    }
    public void setIppStatus(String ippStatus) {
        this.ippStatus = ippStatus;
    }
    public String getFailureReason() {
        return failureReason;
    }
    public void setFailureReason(String failureReason) {
        this.failureReason = failureReason;
    }
    public String getFraud() {
        return fraud;
    }
    public void setFraud(String fraud) {
        this.fraud = fraud;
    }
    public String getDateTimeTobeChecked() {
        return dateTimeTobeChecked;
    }
    public void setDateTimeTobeChecked(String dateTimeTobeChecked) {
        this.dateTimeTobeChecked = dateTimeTobeChecked;
    }
    public String getDateTimeToStartRemoteProofing() {
        return dateTimeToStartRemoteProofing;
    }
    public void setDateTimeToStartRemoteProofing(String dateTimeToStartRemoteProofing) {
        this.dateTimeToStartRemoteProofing = dateTimeToStartRemoteProofing;
    }
    public String getSupplier() {
        return supplier;
    }
    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }
    public String getRpStatus() {
        return rpStatus;
    }
    public void setRpStatus(String rpStatus) {
        this.rpStatus = rpStatus;
    }
    public String getTransasctionKey() {
        return transasctionKey;
    }
    public void setTransasctionKey(String transasctionKey) {
        this.transasctionKey = transasctionKey;
    }
	public String getSponsor() {
		return sponsor;
	}
	public void setSponsor(String sponsor) {
		this.sponsor = sponsor;
	}
}
