package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class NameValueModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String name;	           //Mandatory:Y, Max Length:8
	private String value;		   //Mandatory:Y, Max Length:40
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
