package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchPhoneSummaryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private ValueCodeModel verificationResult;	           //Max Length:8
	private ValueCodeModel classification;	           //Max Length:8
	private ValueCodeModel highRiskResult;	           //Max Length:8
	private PreciseMatchPhoneCountsModel counts;
	
	public ValueCodeModel getVerificationResult() {
		return verificationResult;
	}
	
	public void setVerificationResult(ValueCodeModel verificationResult) {
		this.verificationResult = verificationResult;
	}

	public ValueCodeModel getClassification() {
		return classification;
	}

	public void setClassification(ValueCodeModel classification) {
		this.classification = classification;
	}

	public ValueCodeModel getHighRiskResult() {
		return highRiskResult;
	}

	public void setHighRiskResult(ValueCodeModel highRiskResult) {
		this.highRiskResult = highRiskResult;
	}

	public PreciseMatchPhoneCountsModel getCounts() {
		return counts;
	}

	public void setCounts(PreciseMatchPhoneCountsModel counts) {
		this.counts = counts;
	}
	
}
