package com.ips.persistence.common;

public class DeviceReputationVo {
    private String personId;
    private String sponsorUserId;
    private String firstName;
    private String lastName;
    private String deviceConfidenceId;
    private String reputationAssessment;
    private String reviewStatus;
    private String riskScore;
    private String highRiskAttemptId;
    private String rpEventId;
    private String ippEventId;
    private String appId;
    private String proofingStatus;
    private String statusDescription;
    private String personUpdateDate;
    
    public String getPersonId() {
        return personId;
    }
    
    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public String getSponsorUserId() {
        return sponsorUserId;
    }

    public void setSponsorUserId(String sponsorUserId) {
        this.sponsorUserId = sponsorUserId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDeviceConfidenceId() {
        return deviceConfidenceId;
    }

    public void setDeviceConfidenceId(String deviceConfidenceId) {
        this.deviceConfidenceId = deviceConfidenceId;
    }

    public String getReputationAssessment() {
        return reputationAssessment;
    }

    public void setReputationAssessment(String reputationAssessment) {
        this.reputationAssessment = reputationAssessment;
    }

    public String getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(String reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getRiskScore() {
        return riskScore;
    }

    public void setRiskScore(String riskScore) {
        this.riskScore = riskScore;
    }

    public String getHighRiskAttemptId() {
        return highRiskAttemptId;
    }

    public void setHighRiskAttemptId(String highRiskAttemptId) {
        this.highRiskAttemptId = highRiskAttemptId;
    }

    public String getRpEventId() {
        return rpEventId;
    }

    public void setRpEventId(String rpEventId) {
        this.rpEventId = rpEventId;
    }

    public String getIppEventId() {
        return ippEventId;
    }

    public void setIppEventId(String ippEventId) {
        this.ippEventId = ippEventId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getProofingStatus() {
        return proofingStatus;
    }

    public void setProofingStatus(String proofingStatus) {
        this.proofingStatus = proofingStatus;
    }

    public String getStatusDescription() {
        return statusDescription;
    }

    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }

    public String getPersonUpdateDate() {
        return personUpdateDate;
    }

    public void setPersonUpdateDate(String personUpdateDate) {
        this.personUpdateDate = personUpdateDate;
    }
}
