package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseIDServerModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String sessionID;	           
	private PreciseIDHeaderModel header;		   
	private PreciseIDMessagesModel messages;
	private PreciseIDSummaryModel summary;
	private PreciseIDIpAddressModel ipAddress;
	private PreciseIDErrorModel error;

	private PreciseIDPreciseMatchModel preciseMatch;
	private String pidxmlversion;
	private PreciseIDFrcaDetailModel fcraDetail;
	private PreciseIDGlbDetailModel glbDetail;
		
	public String getSessionID() {
		return sessionID;
	}
	
	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	public PreciseIDHeaderModel getHeader() {
		return header;
	}

	public void setHeader(PreciseIDHeaderModel header) {
		this.header = header;
	}

	public PreciseIDMessagesModel getMessages() {
		return messages;
	}

	public void setMessages(PreciseIDMessagesModel messages) {
		this.messages = messages;
	}

	public PreciseIDSummaryModel getSummary() {
		return summary;
	}

	public void setSummary(PreciseIDSummaryModel summary) {
		this.summary = summary;
	}

	public PreciseIDIpAddressModel getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(PreciseIDIpAddressModel ipAddress) {
		this.ipAddress = ipAddress;
	}

	public PreciseIDErrorModel getError() {
		return error;
	}

	public void setError(PreciseIDErrorModel error) {
		this.error = error;
	}

	public PreciseIDPreciseMatchModel getPreciseMatch() {
		return preciseMatch;
	}

	public void setPreciseMatch(PreciseIDPreciseMatchModel preciseMatch) {
		this.preciseMatch = preciseMatch;
	}

	public String getPidxmlversion() {
		return pidxmlversion;
	}

	public void setPidxmlversion(String pidxmlversion) {
		this.pidxmlversion = pidxmlversion;
	}

	public PreciseIDFrcaDetailModel getFcraDetail() {
		return fcraDetail;
	}

	public void setFcraDetail(PreciseIDFrcaDetailModel fcraDetail) {
		this.fcraDetail = fcraDetail;
	}

	public PreciseIDGlbDetailModel getGlbDetail() {
		return glbDetail;
	}

	public void setGlbDetail(PreciseIDGlbDetailModel glbDetail) {
		this.glbDetail = glbDetail;
	}
		
}
