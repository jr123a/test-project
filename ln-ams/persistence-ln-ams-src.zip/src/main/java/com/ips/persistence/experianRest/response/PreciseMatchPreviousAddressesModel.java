package com.ips.persistence.experianRest.response;

import java.io.Serializable;
import java.util.List;

public class PreciseMatchPreviousAddressesModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<PreciseMatchPreviousAddressCountsModel> previousAddress;	           //Max Length:8

	public List<PreciseMatchPreviousAddressCountsModel> getPreviousAddress() {
		return previousAddress;
	}

	public void setPreviousAddress(List<PreciseMatchPreviousAddressCountsModel> previousAddress) {
		this.previousAddress = previousAddress;
	}
	
}
