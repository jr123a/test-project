package com.ips.persistence.common;

import java.io.Serializable;

public class SponsorConfigurationResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long secondsBeforeResendLink;
    private Long secondsBetweenPolling;
    private Long pollingMinutes;
    private String responseMessage;

	public Long getSecondsBeforeResendLink() {
		return secondsBeforeResendLink;
	}
	public void setSecondsBeforeResendLink(Long secondsBeforeResendLink) {
		this.secondsBeforeResendLink = secondsBeforeResendLink;
	}
	public Long getSecondsBetweenPolling() {
		return secondsBetweenPolling;
	}
	public void setSecondsBetweenPolling(Long secondsBetweenPolling) {
		this.secondsBetweenPolling = secondsBetweenPolling;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public Long getPollingMinutes() {
		return pollingMinutes;
	}
	public void setPollingMinutes(Long pollingMinutes) {
		this.pollingMinutes = pollingMinutes;
	}
}
