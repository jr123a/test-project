package com.ips.persistence.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.ips.polocator.common.AppointmentVo;
import com.ips.common.common.CustomLogger;
import com.ips.polocator.common.IppVo;
import com.ips.polocator.common.LocationVo;
import com.ips.common.common.Utils;
import com.ips.entity.ApplicationWorkflows;
import com.ips.entity.IvsAdminUser;
import com.ips.entity.Person;
import com.ips.entity.RefApp;
import com.ips.entity.RefFacFacility;
import com.ips.entity.RefPrimaryIdType;
import com.ips.entity.RefSecondaryIdType;
import com.ips.entity.RefSponsor;
import com.ips.entity.SponsorApplicationMap;
import com.ips.entity.SponsorEmailValues;

public class EmailText implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String IPP_SUBJECT = "United States Postal Service In-Person Verification";
    public static final String STATUS_REPORT_SUBJECT = "IVS LOA 1.5 Remote Proofing Status Report";
    public static final String IPP_STATUS_REPORT_SUBJECT = "IVS In-Person Proofing Status Report";
    public static final String IPP_SUMMARY_REPORT_SUBJECT = "IVS In-Person Proofing Summary Report";
    private static final String ADMIN_NOTIFICATION_SUBJECT = "IVS Admin Activity Notification";
    public static final String VALIDATE_ID_FAILURE_SUBJECT = "Validate ID Failed";
    
    public static final String REMOTE_ENTERED_HEADING = "Entered IVS";
    public static final String REMOTE_TAKEN_HEADING = "Taken";
    public static final String REMOTE_PASSED_HEADING = "Passed";
    public static final String REMOTE_FAILED_HEADING = "Failed";
    public static final String REMOTE_INCOMPLETE_HEADING = "Incomplete";
    public static final String REMOTE_LOCKOUT_HEADING = "Locked Out by IVS";
    public static final String REMOTE_PATTERN_HEADING = "Pattern Recognition";
    public static final String REMOTE_ERRORS_HEADING = "Equifax Errors";
    public static final String REMOTE_FIELD_CHECK_HEADING = "Field Check Errors";
    public static final String REMOTE_NO_QUESTIONS_HEADING = "No Questions";
    public static final String REMOTE_SUPPLIER_HEADING = "OTP Supplier";
    public static final String REMOTE_ALL_SUPPLIERS = "All Suppliers";
    public static final String REMOTE_VELOCITY_HEADING = "Velocity Check";
    public static final String REMOTE_LEXIS_ERRORS_HEADING = "Lexis Nexis Errors";
    public static final String REMOTE_LEXIS_VERIFY_HEADING = "Lexis Nexis Verification Failures";
    public static final String REMOTE_PASS_RATE_HEADING = "Pass Rate";
    public static final String REMOTE_FAIL_RATE_HEADING = "Fail Rate";
    
    public static final String IPP_REGION_HEADING = "Region";
    public static final String IPP_DISTRICT_HEADING = "District";
    public static final String IPP_FACILITY_HEADING = "Postal Facility";
    public static final String IPP_OPTIN_HEADING = "Opted-In";
    public static final String IPP_PASSED_HEADING = "Passed";
    public static final String IPP_FAILED_HEADING = "Failed";
    public static final String IPP_FRAUD_HEADING = "Flagged as Fraud";
    
    private static final String CHOSEN_MESSAGE = "You have chosen ";
    private static final String REMINDER_MESSAGE = "This is a reminder ";
    private static final String PATTERN_MMDDYYYY = "MM/dd/yyyy";
    private static final String PATTERN_DDMMMYY_HHMM = "dd-MMM-yy hh:mm a";
    
    public static String convertLocsToHtml(List<LocationVo> locs, boolean poListError) {
        StringBuilder locHtml = new StringBuilder();
        
        if (locs.isEmpty() && poListError) {
            locHtml.append("<font face=\"verdana,arial,helvetica,sans-serif\" style=\"color: #EB0F0E; font-weight: bold;\" size=\"2\">");
            locHtml.append("Unable to find USPS In-Person Identity Verification locations based on the address/Zip Code provided.</font>");
        } else if (locs.isEmpty() && !poListError) {
            locHtml.append("<font face=\"verdana,arial,helvetica,sans-serif\" style=\"color: #EB0F0E; font-weight: bold;\" size=\"2\">");
            locHtml.append("There are no USPS In-Person Identity Verification locations near the address/Zip Code.</font>");
        } else {
            for (LocationVo loc : locs) {
                locHtml.append("<a href=\"" + createLink(loc) + "\">");
                locHtml.append("<font face=\"verdana,arial,helvetica,sans-serif\" size=\"2\">" + loc.getLocationName() + "</font><br></a>");
                locHtml.append(loc.getAddress2() + "<br>" + loc.getCity() + ", " + loc.getState() + " " + loc.getZip5() + "-" + loc.getZip4() + "<br>");
                locHtml.append(loc.getParking() + " Parking Available");
                locHtml.append("<br>Distance: " + loc.getDistance() + " mi<br>");
                locHtml.append("<br>Mon-Fri " + checkIfNull(loc.getWeekdayHours()));

                if (loc.getSatHours() != null && loc.getSatHours().equalsIgnoreCase(loc.getSunHours())) {
                    locHtml.append("<br>Sat-Sun " + checkIfNull(loc.getSatHours()) + "<br>");
                } else if ("Closed".equalsIgnoreCase(loc.getSatHours()) && "Closed".equalsIgnoreCase(loc.getSunHours())) {
                    locHtml.append("<br>Sat-Sun Closed<br>");
                } else {
                    locHtml.append("<br>Sat " + checkIfNull(loc.getSatHours()) + "<br>Sun " + checkIfNull(loc.getSunHours()) + "<br>");
                }
                
                locHtml.append("<br>Phone " + loc.getPhoneData().getPhone() + "<br><br>");
            }
        }
        
        return locHtml.toString();
    }
    
    private static String createLink(LocationVo attributes) {
        return "https://tools.usps.com/find-location.htm?" + 
               "locationType=" + attributes.getLocationType() + "&" +
               "address=" + attributes.getZip5()+"-"+attributes.getZip4()+ "&" + //search parameter, might be the zipcode                
               "searchRadius=1&" + //search parameter
               "locationType=" + attributes.getLocationType() + "&" + 
               "fdbid=" + attributes.getLocationID() ;
    }
    
    
    /**
     * Builds the initial or reminder opt-in email for an external agency.
     * @param barcodeValidDays - Number of days the barcode is valid for
     * @param locationHTMLText - The HTML text for the facility locations
     * @param reminder - Sending the initial or reminder opt-in email. Also used to determine number of days left barcode is valid for
     * @param clientAddress - IppVo object containing the address of the customer
     * @param sev
     * @param person - Only needed if customer's first name and/or last name will be in the email. Requires a PersonData object to be tied to it.
     * @return HTML String containing the entire email text
     * @throws IOException 
     * @throws Exception
     */
    public static String getHTMLOptinSponsorText(Integer barcodeValidDays, String locationHTMLText, IppVo clientAddress, SponsorEmailValues sev, 
            Person person, Timestamp ippEventCreateDate, String enrollmentCode) throws IOException {
        String emailText = "";
        
        LocalDate barcodeExpirationDate = null;
        Integer daysUntilExpirationDate = null;
        if (barcodeValidDays != null && ippEventCreateDate != null) {
            barcodeExpirationDate = ippEventCreateDate.toLocalDateTime().toLocalDate().plusDays(barcodeValidDays);
            daysUntilExpirationDate = (int) LocalDate.now(ZoneId.systemDefault()).until(barcodeExpirationDate, ChronoUnit.DAYS);
        }
        
        if (sev != null) {
            emailText = getEmailTemplate("IppOptinSponsorEmailTemplate.html").replace("~EMAIL BODY~", checkIfNull(sev.getEmailBody()));
            emailText = emailText.replace("~BARCODE~", "<img src=\"cid:barcode\" />").replace("~BARCODE VALIDATION DAYS~", checkIfNull(daysUntilExpirationDate))
                                 .replace("~LOCATIONS~", checkIfNull(locationHTMLText)).replace("~STREET~", checkIfNull(clientAddress != null ? clientAddress.getStreetAddressLines() : ""))
                                 .replace("~TOWN STATE ZIP~", checkIfNull(clientAddress != null ? clientAddress.getCityStateLine() : ""))
                                 .replace("~LOGO~", "<img src=\"cid:Partnership-Logo\" border=\"0\" />").replace("~USPS LOGO~", "<img src=\"cid:Email-Logo\" border=\"0\">")
                                 .replace("~ENROLLMENT CODE~", checkIfNull(enrollmentCode));
            
            for (int i = 1; i <= 11; i++) {
                emailText = emailText.replace("~PRIMARY ID" + i + "~", getIdImageAndDescHTML(i, false, false));
                emailText = emailText.replace("~PRIMARY ID" + i + " DESC~", getIdImageAndDescHTML(i, true, false));
                emailText = emailText.replace("~SECONDARY ID" + i + "~", getIdImageAndDescHTML(i, false, true));
                emailText = emailText.replace("~SECONDARY ID" + i + " DESC~", getIdImageAndDescHTML(i, true, true));
            }
            
            if (barcodeExpirationDate != null) {
                emailText = emailText.replace("~BARCODE EXPIRATION DATE~", DateTimeFormatter.ofPattern(PATTERN_MMDDYYYY).format(barcodeExpirationDate));
            }
            if (person != null && person.getPersonData() != null) {
                emailText = emailText.replace("~FIRST NAME~", checkIfNull(person.getPersonData().getFirstName())).replace("~LAST NAME~", checkIfNull(person.getPersonData().getLastName()));
            }
        }
        
        return emailText;
    }
    
    /**
     * Returns an empty string if Object is null. Else returns value as String.
     * @param value
     * @return
     */
    private static String checkIfNull(Object value) {
        return value == null ? "" : String.valueOf(value);
    }
    
    /**
     * Returns the HTML for a primary or secondary ID
     * @param numberIdentifier - specifies which ID the HTML is needed for.
     * @param isOnlyDesc - specifies if only the description is needed.
     * @return
     */
    private static String getIdImageAndDescHTML(int numberIdentifier, boolean isOnlyDesc, boolean isSecondaryId) {
        String width = "";
        String height = "";
        String desc = "";
        String imageSrc = "";
        switch (numberIdentifier) {
            case 1:
                width = isSecondaryId ? "125" : "140";
                height = isSecondaryId ? "120" : "90";
                imageSrc = isSecondaryId ? "mortgage" : "driverLicense";
                desc = isSecondaryId ? "Lease, Mortgage, or Deed of Trust" : "State Driver's License";
                break;
            case 2:
                width = isSecondaryId ? "125" : "140";
                height = isSecondaryId ? "120" : "90";
                imageSrc = isSecondaryId ? "vehicleRegistration" : "stateID";
                desc = isSecondaryId ? "Voter or Vehicle Registration Card" : "State Non-Driver's Identification Card";
                break;
            case 3:
                width = isSecondaryId ? "175" : "140";
                height = isSecondaryId ? "100" : "90";
                imageSrc = isSecondaryId ? "insurancePolicy" : "UniformService";
                desc = isSecondaryId ? "Home or Vehicle Insurance Policy" : "Uniformed Services Identification Card";
                break;
            case 4:
                width = isSecondaryId ? "" : "100";
                height = isSecondaryId ? "" : "120";
                imageSrc = isSecondaryId ? "" : "passport";
                desc = isSecondaryId ? "Current Lease" : "US Passport (always requires secondary form of ID)";
                break;
            case 5:
                desc = isSecondaryId ? "Deed of Trust" : "Alien Registration Card";
                break;
            case 6:
                desc = isSecondaryId ? "Home Insurance Policy" : "Certification of Naturalization";
                break;
            case 7:
                desc = isSecondaryId ? "Mortgage" : "Government Identification Card";
                break;
            case 8:
                desc = isSecondaryId ? "Vehicle Insurance Policy" : "Passport Card";
                break;
            case 9:
                desc = isSecondaryId ? "Vehicle Registration Card" : "Recognized Corporate Identification Card";
                break;
            case 10:
                desc = isSecondaryId ? "Voter Registration Card" : "University Identification Card";
                break;
            case 11:
                desc = isSecondaryId ? "PS Form 1093" : "";
                break;
            default:
                break;
        }
        
        if (isOnlyDesc) {
            return desc;
        } else if (StringUtils.isNotBlank(imageSrc) && StringUtils.isNotBlank(height) && StringUtils.isNotBlank(width)) {
            return "<img width=\"" + width + "\" height=\"" + height + "\" src=\"cid:" + imageSrc + "\" /><br/>" + desc;
        } else {
            return "";
        }
    }
    
    /**
     * Reads the HTML template file and replaces the variables in them with the respective values based on the RefSponsor
     * @param address - IppVo object containing the user's address information
     * @param locText - the HTML text for the facilities placed at the bottom of the email
     * @param reminder - boolean determining if this is a reminder email being sent or not
     * @param days - number of the days the email/barcode is valid for
     * @param sponsorId - the sponsor id that the IPP is being performed under
     * @return The HTML text for sending the IPP email
     * @throws Exception
     */
    public static String getHTMLTextIPPFacility(IppVo address, String locText, boolean reminder, Integer days) throws IOException {
        return getEmailTemplate("IppEmailTemplate.xhtml").replace("~DAYS~", checkIfNull(days))
                                                         .replace("~CHOSEN OR REMINDER~", reminder ? REMINDER_MESSAGE : CHOSEN_MESSAGE)
                                                         .replace("~STREET~", checkIfNull(address != null ? address.getStreetAddressLines() : ""))
                                                         .replace("~TOWN STATE ZIP~", checkIfNull(address != null ? address.getCityStateLine() : ""))
                                                         .replace("~LOCATIONS~", checkIfNull(locText))
                                                         .replace("~ENROLLMENT CODE~", checkIfNull(address != null ?address.getRecordLocator():""));
    }
    
    public static String getHTMLTextIPPResidence(AppointmentVo appointment, boolean reminder) throws IOException {
        final String reminderText = reminder ? "<br/><br/><b>We are sending this email as a reminder for your upcoming appointment for identity verification at your residence.</b><br/><br/>" : "";
        return getEmailTemplate("IppResidenceEmailTemplate.html").replace("~APPOINTMENT DATE~", DateTimeFormatter.ofPattern("MMMM dd, yyyy").format(appointment.getScheduledDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()))
                                                                 .replace("~APPOINTMENT TIME~", checkIfNull(appointment.getScheduledTime()))
                                                                 .replace("~APPOINTMENT ADDRESS 1 AND 2~", checkIfNull(appointment.getAddress1()) + " " + checkIfNull(appointment.getAddress2()))
                                                                 .replace("~CITY~", checkIfNull(appointment.getCity())).replace("~STATE~", checkIfNull(appointment.getState()))
                                                                 .replace("~ZIP4~", checkIfNull(appointment.getZip4())).replace("~REMINDER~", reminderText);
    }
    
    public static String getTemporaryPinText(String temporaryPin) {
        return "New PIN: " + temporaryPin + "\n\n" + "Your USPS.com identity verification PIN has been reset.  Please continue the Forgot PIN process with this temporary PIN.";
    }
    
    /**
     * Build the email body for the Passed or Failed confirmation email. Replaces the following email variables:<br>
     * ~FIRST NAME~, ~LAST NAME~, ~ACTIVATION CODE~, ~ACTIVATION CODE VALIDATION DAYS~, ~ACTIVATION CODE EXPIRATION DATE~
     * @param sev - Saved email values for sponsor and email type
     * @param activationCode
     * @param activationCodeValidDays - Number of days activation code is valid for
     * @param person - Only needed if customer's first name and/or last name will be in the email body. Person object must have PersonData object tied to it.
     * @return
     * @throws IOException 
     * @throws Exception
     */
    public static String getSponsorPassedOrFailedIppEmailTemplate(SponsorEmailValues sev, String activationCode, Integer activationCodeValidDays, Person person, 
            Date activationCodeExpirationDate, Timestamp transactionTimestamp, String enrollmentCode, String facilityName, String facilityCityState) throws IOException {
        String emailText = null;
        
        if (sev != null) {
            String fullText = checkIfNull(sev.getGreeting()) + checkIfNull(sev.getEmailBody()) + checkIfNull(sev.getClosing()) + checkIfNull(sev.getPostscript());
            emailText = getEmailTemplate("IppConfirmationSponsorEmailTemplate.html").replace("~EMAIL BODY~", fullText);
            emailText = emailText.replace("~ACTIVATION CODE~", checkIfNull(activationCode)).replace("~ACTIVATION CODE VALIDATION DAYS~", checkIfNull(activationCodeValidDays))
                                 .replace("~LOGO~", "<img src=\"cid:Partnership-Logo\" border=\"0\" />").replace("~USPS LOGO~", "<img src=\"cid:Email-Logo\" border=\"0\">")
                                 .replace("~ENROLLMENT CODE~", checkIfNull(enrollmentCode)).replace("~TRANSACTION DATE~", checkIfNull(DateTimeFormatter.ofPattern(PATTERN_MMDDYYYY).format(transactionTimestamp.toLocalDateTime())))
                                 .replace("~FACILITY NAME~", checkIfNull(facilityName)).replace("~FACILITY CITY STATE~", checkIfNull(facilityCityState));
            if (activationCodeExpirationDate != null) {
                emailText = emailText.replace("~ACTIVATION CODE EXPIRATION DATE~", new SimpleDateFormat(PATTERN_MMDDYYYY).format(activationCodeExpirationDate));
            }
            if (person != null && person.getPersonData() != null) {
                emailText = emailText.replace("~FIRST NAME~", checkIfNull(person.getPersonData().getFirstName())).replace("~LAST NAME~", checkIfNull(person.getPersonData().getLastName()));
            }
        }
        
        return emailText;
    }
    
    public static String getPassedOrFailedIppEmail(String confirmationNumber, boolean isIppPassed) throws IOException {
        final String passed = "Congratulations!  Your identity has been successfully verified.  You now have the Informed Delivery service and will start receiving mail notifications within 3 to 5 business days.";
        final String failed = "Unfortunately, our system could not validate your identity, so we cannot grant you authorization right now. Please check that the information in your account profile exactly matches the information on the photo id used for in-person verification.  If you have any questions, please contact us at 800-ASK-USPS&#174; (800-275-8777).<br>";
        
        return getEmailTemplate("IppPassedOrFailedEmailTemplate.html").replace("~CONFIRMATION NUMBER~", checkIfNull(confirmationNumber))
                                                                      .replace("~PASS OR FAIL~", isIppPassed ? passed : failed);
    }
    
    public static String getAddedFacilityText(IvsAdminUser user, Timestamp dateAdded, RefFacFacility facility) {
        return user.getFirstName() + " " + user.getLastName() + " added the following IPP facility to the configured area at "
               + DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(dateAdded.toLocalDateTime()) + ".\n\n" + facility.getFacilityName() + "\n"
               + facility.getAddrPhyAddress1() + "\n" + facility.getAddrPhyCityName() + ", " + facility.getAddrPhyStateCode() + "  "
               + facility.getAddrPhyZipcode().subSequence(0, 5) + "-" + facility.getAddrPhyZipcode().substring(5);
    }
    
    public static String getAddedFacilitiesText(IvsAdminUser user, Timestamp dateAdded, int nbrFacs) {
        return user.getFirstName() + " " + user.getLastName() + " added " + nbrFacs + " IPP facilities to the configured area at " 
               + DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(dateAdded.toLocalDateTime()) + ".  Please review the attached file for the list of facilities added.";
    }
    
    public static String getAddedAllFacilitiesText(IvsAdminUser user, Timestamp dateAdded) {
        return user.getFirstName() + " " + user.getLastName() + " added all IPP facilities to the configured area at "
               + DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(dateAdded.toLocalDateTime()) + ".";
    }
    
    public static String getExternalAgencyFacilitiesText(IvsAdminUser user, Timestamp transactionTime, List<RefFacFacility> refFacFacilities, RefSponsor sponsor, boolean isAdd) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ").append(user.getLastName()).append(isAdd ? " added " : " removed ").append(refFacFacilities.size()).append(" IPP facilities for ")
          .append(sponsor.getSponsorName()).append(" at ").append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(transactionTime.toLocalDateTime())).append(".\n");
        
        if (refFacFacilities.size() == 1) {
            RefFacFacility fac = refFacFacilities.get(0);
            sb.append("\n").append(fac.getFacilityName()).append("\n").append(fac.getAddrPhyAddress1()).append("\n").append(fac.getAddrPhyCityName())
              .append(", ").append(fac.getAddrPhyStateCode()).append(" ").append(fac.getAddrPhyZipcode().substring(0, 5)).append("-")
              .append(fac.getAddrPhyZipcode().substring(5));
        } else {
            sb.append("Please review the attached file for the list of facilities ").append(isAdd ? "added." : "removed.");
        }
        
        return sb.toString();
    }
    
    public static String getExternalAgencyFlagsText(IvsAdminUser user, Timestamp transactionTime, RefSponsor sponsor) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ").append(user.getLastName()).append(" changed the sublist flag to ").append(sponsor.isClientUsingFacilitySublist() ? "Y" : "N").append(" for ").append(sponsor.getSponsorName()).append(" at ")
          .append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(transactionTime.toLocalDateTime()));
        
        return sb.toString();
    }
    
    public static String getRemovedFacilityText(IvsAdminUser user, Timestamp dateAdded, RefFacFacility facility) {
        return user.getFirstName() + " " + user.getLastName() + " removed the following IPP facility from the configured area at " 
               + DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(dateAdded.toLocalDateTime()) + ".\n\n" + facility.getFacilityName() + "\n"
               + facility.getAddrPhyAddress1() + "\n" + facility.getAddrPhyCityName() + ", " + facility.getAddrPhyStateCode() + "  " 
               + facility.getAddrPhyZipcode().substring(0, 5) + "-" + facility.getAddrPhyZipcode().substring(5);
    }
    
    public static String getRemovedFacilitiesText(IvsAdminUser user, Timestamp dateRemoved, int nbrFacs) {
        return user.getFirstName() + " " + user.getLastName() + " removed " + nbrFacs + " IPP facilities from the configured area at " 
               + DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(dateRemoved.toLocalDateTime()) + ".  Please review the attached file for the list of facilities removed.";
    }
    
    public static String getRemovedAllFacilitiesText(IvsAdminUser user, Timestamp dateRemoved) {
        return user.getFirstName() + " " + user.getLastName() + " removed all IPP facilities from the configured area at "
               + DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(dateRemoved.toLocalDateTime()) + ".";
    }
    
    public static String getAdminNotificationSubject() {
        String env = Utils.getEnvironment();
        return ADMIN_NOTIFICATION_SUBJECT + " - " + env.substring(0, env.indexOf('.')).toUpperCase() + " Environment";
    }
    
    public static String getActivationText(String activationCode, String confirmationNumber) throws IOException {
        return getEmailTemplate("ActivationTextEmailTemplate.html").replace("~ACTIVATION CODE~", checkIfNull(activationCode)).replace("~CONFIRMATION CODE~", checkIfNull(confirmationNumber));
    }
    
    public static String getIppEmailsAdminNotificationText(IvsAdminUser user, Timestamp transactionTime, String actionPerformed, String newValue, RefSponsor sponsor) {
        StringBuilder sb = new StringBuilder();
        
        sb.append(user.getFirstName() + " " + user.getLastName());
        
        switch (actionPerformed) {
            case "optinLogo":
                sb.append(" has changed the opt-in email logo");
                break;
            case "confirmationLogo":
                sb.append(" has changed the confirmation email logo");
                break;
            case "ial2EmailLogo":
                sb.append(" has changed the IAL-2 confirmation email logo");
                break;
            case "ial2LetterLogo":
                sb.append(" has changed the IAL-2 confirmation letter logo and/or include USPS logo and include agency logo flags");
                break;
            case "optinInitial":
                sb.append(" has changed the opt-in initial email body and/or subject");
                break;
            case "optinReminder":
                sb.append(" has changed the opt-in reminder email body and/or subject");
                break;
            case "confirmationPassed":
                sb.append(" has changed the confirmation passed email body and/or subject");
                break;
            case "confirmationFailed":
                sb.append(" has changed the confirmation failed email body and/or subject");
                break;
            case "barcodeExpiration":
                sb.append(" has changed the opt-in barcode expiration value ");
                break;
            case "activationExpiration":
                sb.append(" has changed the activation code expiration value ");
                break;
            case "sendEmailOptin":
                sb.append(" has changed the opt-in send email flag ");
                break;
            case "sendEmailConfirmation":
                sb.append(" has changed the confirmation send email flag ");
                break;
            case "ial2ConfirmationEmail":
                sb.append(" has changed the IAL-2 confirmation email");
                break;
            case "ial2ConfirmationLetter":
                sb.append(" has changed the IAL-2 confirmation letter");
                break;
            default: break;
        }
        
        sb.append(newValue).append(" for ").append(sponsor.getSponsorName()).append(" at ").append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(transactionTime.toLocalDateTime()));
        
        return sb.toString();
    }
    
    public static String getExternalAgencyApiText(IvsAdminUser user, Timestamp transactionTime, String sponsorName, boolean callAgencyService, String retryAttempts, String retryInterval, String serviceCallWaitTime) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ").append(user.getLastName()).append(" has changed the API configuration for ").append(sponsorName).append(" at ")
          .append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(transactionTime.toLocalDateTime())).append(".\nCall Agency Service: ").append(callAgencyService ? "True" : "False")
          .append("\nRetry Attempts: ").append(retryAttempts).append(" Attempts\nRetry Interval: ").append(retryInterval).append(" Seconds").append("\nService Call Wait Time: ")
          .append(serviceCallWaitTime).append(" Seconds");
          return sb.toString();
    }
    
    public static String getIAL2ConfirmationNotificationText(IvsAdminUser user, Timestamp transactionTime, String sponsorName, String notifType) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ").append(user.getLastName()).append(" has changed the IAL-2 Confirmation Notification to ")
          .append(notifType).append(" for ").append(sponsorName).append(" at ").append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(transactionTime.toLocalDateTime()));
        return sb.toString();
    }
    
    public static String getRetainPIINotificationText(IvsAdminUser user, Timestamp transactionTime, String sponsorName, String notifType, String newValue) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ").append(user.getLastName()).append(" ")
          .append(notifType).append(sponsorName).append(" to ").append(newValue).append(" at ").append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(transactionTime.toLocalDateTime()));
        return sb.toString();
    }
    
    public static String getMinAgeNotificationText(IvsAdminUser user, Timestamp updateTime, String sponsorName, String notifType, String minAgeReq, String minAge) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ")
          .append(user.getLastName()).append(" ")
          .append(notifType).append("sponsor:").append(sponsorName)
          .append(" to:").append("0".equals(minAgeReq) ? false : true).append(" min age:").append(minAge)
          .append(" at ").append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(updateTime.toLocalDateTime()));
        return sb.toString();
    }
    
    private static String getEmailTemplate(String emailTemplateName) throws IOException {
        StringBuilder emailBodyText = new StringBuilder();
        CustomLogger.debug(EmailText.class.getClass(), "Email Template URL: " + Utils.getProperty("com.ipsweb.VERIFICATION_URL") + "/../templates/" + emailTemplateName);
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new URL(Utils.getProperty("com.ipsweb.VERIFICATION_URL") + "/../templates/" + emailTemplateName).openStream()))) {
            String htmlLine;
            while ((htmlLine = br.readLine()) != null) {
                emailBodyText.append(htmlLine);
            }
        } catch (MalformedURLException e) {
            CustomLogger.error(EmailText.class.getClass(), "MalformedURLException occurred when attempting to form URL to email template", e);
            throw e;
        } catch (IOException e) {
            CustomLogger.error(EmailText.class.getClass(), "IOException occurred while reading email HTML template", e);
            throw e;
        } catch (Exception e) {
            CustomLogger.error(EmailText.class.getClass(), "Exception occurred when attempting to retrieve email template", e);
            throw e;
        }
        
        return emailBodyText.toString();
    }
    
    public static String getIAL2ConfigChangeNotificationText(IvsAdminUser user, Timestamp transactionTime, String eventDesc,  String sponsorName, String configValue) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ").append(user.getLastName()).append(" ")
            .append(eventDesc)
            .append(sponsorName).append(" to ")
            .append(configValue).append(" at ")
            .append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(transactionTime.toLocalDateTime()));
        return sb.toString();
    }

    public static String getPrimaryIdNotifications(String emailText, RefPrimaryIdType ids) {
        StringBuilder sb = new StringBuilder();
        CustomLogger.debug(EmailText.class.getClass(), "Notifications for primary Ids " + emailText);
        sb.append(emailText)
        .append(" \nPrimary ID: ").append(ids.getIdTypeDescription())
        .append(".")
        .append(" \nStrong ID: ").append(ids.getStrongId());
        CustomLogger.debug(EmailText.class.getClass(), sb.toString());
        return sb.toString();
    }

    public static String getSecondaryIdNotifications(String emailText, RefSecondaryIdType refSecondaryIdType) {
        StringBuilder sb = new StringBuilder();
        CustomLogger.debug(EmailText.class.getClass(), "Notifications for secondary Ids " + emailText);
        sb.append(emailText)
        .append(" \nSecondary ID: ").append(refSecondaryIdType.getIdTypeDescription())
        .append(". \nFair ID: ").append(refSecondaryIdType.getFairId());
        CustomLogger.debug(EmailText.class.getClass(), sb.toString());
        return sb.toString();
    }

    public static String getApplicationWorkflowNotifications(String emailText, ApplicationWorkflows apps) {
        StringBuilder sb = new StringBuilder();
        CustomLogger.debug(EmailText.class.getClass(), "Notifications for secondary Ids " + emailText);
        sb.append(emailText)
        .append(" \nIPP Application: ").append(apps.getRefIppApplications().getApplicationAcronym())
        .append(". \nDevice Type: ").append(apps.getRefDeviceTypes().getDescription())
        .append(". \nSponsor: ").append(apps.getRefSponsor().getSponsorName())
        .append(". \nAuthorized Workflow: ").append(apps.getRefIppWorkflows().getDescription());
        CustomLogger.debug(EmailText.class.getClass(), sb.toString());
        return sb.toString();
    }
    
    public static String getAddSponsorNotificationText(IvsAdminUser user, String sponsorName, Timestamp tStamp) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ").append(user.getLastName()).append(" has added a new sponsor, ").append(sponsorName)
          .append(", at ").append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(tStamp.toLocalDateTime()));
        return sb.toString();
    }
    
    public static String getUpdatedSponsorNotificationText(IvsAdminUser user, RefSponsor sponsor, Timestamp tStamp) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ").append(user.getLastName()).append(" has updated sponsor with ID ").append(sponsor.getSponsorId())
        .append(" to ").append(sponsor.getSponsorName()).append(" with External IPP client indicator ").append(StringUtils.isNotBlank(sponsor.getIppClientActive()) ? sponsor.getIppClientActive().toUpperCase() : "N")
        .append(" and Remote Proofing Client indicator ").append(StringUtils.isNotBlank(sponsor.getRemoteProofingClient()) ? sponsor.getRemoteProofingClient().toUpperCase() : "N")
        .append(" at ").append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(tStamp.toLocalDateTime()));
        return sb.toString();
    }
    
    public static String getRemoveSponsorNotificationText(IvsAdminUser user, RefSponsor sponsor, Timestamp tStamp) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ").append(user.getLastName()).append(" has deleted sponsor at ")
          .append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(tStamp.toLocalDateTime())).append("\n\nSponsor ID: ").append(sponsor.getSponsorId())
          .append("\nSponsor Name: ").append(sponsor.getSponsorName());
        return sb.toString();
    }
    
    public static String getApplicationNotificationText(IvsAdminUser user, RefApp app, Timestamp tStamp, String action) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ").append(user.getLastName()).append(" has ").append(action).append(" an application at ")
          .append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(tStamp.toLocalDateTime())).append("\n\nApplication ID: ").append(app.getAppId())
          .append("\nApplication Name: ").append(app.getAppName());
        return sb.toString();
    }
    
    public static String getSponsorApplicationNotificationText(IvsAdminUser user, SponsorApplicationMap map, Timestamp tStamp, String action) {
        StringBuilder sb = new StringBuilder();
        sb.append(user.getFirstName()).append(" ").append(user.getLastName()).append(" has ").append(action).append(" an application tied to ")
          .append(map.getSponsor().getSponsorName()).append(" at ").append(DateTimeFormatter.ofPattern(PATTERN_DDMMMYY_HHMM).format(tStamp.toLocalDateTime()))
          .append("\n\nApplication: ").append(map.getApp().getAppName()).append("\nApplication ID: ").append(map.getApp().getAppId())
          .append("\nEnable On: ").append(DateTimeFormatter.ofPattern(PATTERN_MMDDYYYY).format(new Timestamp(map.getActivationDate().getTime()).toLocalDateTime()))
          .append("\nDisable On: ").append(map.getDeactivationDate() != null ? DateTimeFormatter.ofPattern(PATTERN_MMDDYYYY).format(new Timestamp(map.getDeactivationDate().getTime()).toLocalDateTime()) : "");
        return sb.toString();
    }
    
    public static String getValidateIdVendorFailureTest(String recordLocator, int retries) {
    	StringBuilder sb = new StringBuilder();
    	sb.append("Validation of ID failed contacting primary and backup vendors for ");
    	sb.append(recordLocator);
    	sb.append(" after " + retries +" atempts." );
    	return sb.toString();
    }

}
