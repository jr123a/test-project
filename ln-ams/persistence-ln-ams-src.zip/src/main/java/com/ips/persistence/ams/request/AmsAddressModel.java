package com.ips.persistence.ams.request;

import java.io.Serializable;

public class AmsAddressModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String FirmName;	      
	private String Address1;
	private String Address2;
	private String Urbanization;	  
	private String City;	  
	private String State;	
	private String Zip5;	
	private String Zip4;	
	private String BusinessVerify;
	
	public String getFirmName() {
		return FirmName;
	}
	
	public void setFirmName(String firmName) {
		FirmName = firmName;
	}

	public String getAddress1() {
		return Address1;
	}

	public void setAddress1(String address1) {
		Address1 = address1;
	}

	public String getAddress2() {
		return Address2;
	}

	public void setAddress2(String address2) {
		Address2 = address2;
	}

	public String getUrbanization() {
		return Urbanization;
	}

	public void setUrbanization(String urbanization) {
		Urbanization = urbanization;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}
	
	public String getZip5() {
		return Zip5;
	}

	public void setZip5(String zip5) {
		Zip5 = zip5;
	}

	public String getZip4() {
		return Zip4;
	}

	public void setZip4(String zip4) {
		Zip4 = zip4;
	}

	public String getBusinessVerify() {
		return BusinessVerify;
	}

	public void setBusinessVerify(String businessVerify) {
		BusinessVerify = businessVerify;
	}	
    	
			
}
