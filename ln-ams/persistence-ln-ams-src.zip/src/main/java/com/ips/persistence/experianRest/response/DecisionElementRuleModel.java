package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class DecisionElementRuleModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String ruleId;	           //Mandatory:Y, Max Length:200, Total Length:215
	private String ruleName;		   //Mandatory:Y, Max Length:200, Total Length:215
	private String ruleText;		   //Mandatory:Y, Max Length:200, Total Length:215
	private String ruleScore;          //Mandatory:Y, Max Length:10, Total Length:25
	
	public String getRuleId() {
		return ruleId;
	}
	
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRuleText() {
		return ruleText;
	}

	public void setRuleText(String ruleText) {
		this.ruleText = ruleText;
	}

	public String getRuleScore() {
		return ruleScore;
	}

	public void setRuleScore(String ruleScore) {
		this.ruleScore = ruleScore;
	}
		
}
