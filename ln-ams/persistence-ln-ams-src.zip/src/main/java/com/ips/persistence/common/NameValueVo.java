package com.ips.persistence.common;

import java.io.Serializable;

public class NameValueVo implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String name;
    private String stringValue;
    private long longValue;
    private int intValue;
    private boolean booleanValue;
    
    public NameValueVo() {
    	//Empty constructor
    }
    
    public NameValueVo(String name, String stringValue) {
    	this.name = name;
        this.stringValue = stringValue;
    }
    
    public NameValueVo(String name, long longValue) {
    	this.name = name;
        this.longValue = longValue;
    }
    
    public NameValueVo(String name, int intValue) {
    	this.name = name;
        this.intValue = intValue;
    }
    
    public NameValueVo(String name, boolean booleanValue) {
    	this.name = name;
        this.booleanValue = booleanValue;
    }
    
    public NameValueVo(int intValue, String name, String stringValue) {
    	this.intValue = intValue;
    	this.name = name;
    	this.stringValue = stringValue;
    }
    
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getStringValue() {
		return stringValue;
	}

	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}

	public long getLongValue() {
		return longValue;
	}

	public void setLongValue(long longValue) {
		this.longValue = longValue;
	}

	public int getIntValue() {
		return intValue;
	}

	public void setIntValue(int intValue) {
		this.intValue = intValue;
	}

	public boolean isBooleanValue() {
		return booleanValue;
	}

	public void setBooleanValue(boolean booleanValue) {
		this.booleanValue = booleanValue;
	}
    
}
