package com.ips.persistence.ams.response;

import java.io.Serializable;
import java.util.List;

public class AddressLookupResultModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String FirmName;	      
	private String Address1;
	private String Address2;
	private String Address1Abbreviation;
	private String City;	
	private String CityAbbreviation;	
	private String State;	
	private String Urbanization;	
	private String Zip5;	
	private String Zip4;	
	private String DeliveryPoint;
	private String ReturnText;
	private String CarrierRoute;
	private String CountyName;
	private String Footnotes;
	private String DPVConfirmation;
	private String DPVFalseConfirmation;
	private String DPVCMRA;
	private String DPVFootnotes;
	private String Business;
	private String UsageCode;
	private String CentralDeliveryPoint;
	private String Vacant;
	private String RecordType;
	private String SecondaryInfo;
	private String ReturnCode;
	private String errorCode;
	private String errorMessage;
	private List<String> Geocodes;
	
	public String getFirmName() {
		return FirmName;
	}
	
	public void setFirmName(String firmName) {
		FirmName = firmName;
	}

	public String getAddress1() {
		return Address1;
	}

	public void setAddress1(String address1) {
		Address1 = address1;
	}

	public String getAddress2() {
		return Address2;
	}

	public void setAddress2(String address2) {
		Address2 = address2;
	}

	public String getAddress1Abbreviation() {
		return Address1Abbreviation;
	}

	public void setAddress1Abbreviation(String address1Abbreviation) {
		Address1Abbreviation = address1Abbreviation;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getCityAbbreviation() {
		return CityAbbreviation;
	}

	public void setCityAbbreviation(String cityAbbreviation) {
		CityAbbreviation = cityAbbreviation;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public String getUrbanization() {
		return Urbanization;
	}

	public void setUrbanization(String urbanization) {
		Urbanization = urbanization;
	}

	public String getZip5() {
		return Zip5;
	}

	public void setZip5(String zip5) {
		Zip5 = zip5;
	}

	public String getZip4() {
		return Zip4;
	}

	public void setZip4(String zip4) {
		Zip4 = zip4;
	}

	public String getDeliveryPoint() {
		return DeliveryPoint;
	}

	public void setDeliveryPoint(String deliveryPoint) {
		DeliveryPoint = deliveryPoint;
	}

	public String getReturnText() {
		return ReturnText;
	}

	public void setReturnText(String returnText) {
		ReturnText = returnText;
	}

	public String getCarrierRoute() {
		return CarrierRoute;
	}

	public void setCarrierRoute(String carrierRoute) {
		CarrierRoute = carrierRoute;
	}

	public String getCountyName() {
		return CountyName;
	}

	public void setCountyName(String countyName) {
		CountyName = countyName;
	}

	public String getFootnotes() {
		return Footnotes;
	}

	public void setFootnotes(String footnotes) {
		Footnotes = footnotes;
	}

	public String getDPVConfirmation() {
		return DPVConfirmation;
	}

	public void setDPVConfirmation(String dPVConfirmation) {
		DPVConfirmation = dPVConfirmation;
	}

	public String getDPVFalseConfirmation() {
		return DPVFalseConfirmation;
	}

	public void setDPVFalseConfirmation(String dPVFalseConfirmation) {
		DPVFalseConfirmation = dPVFalseConfirmation;
	}

	public String getDPVCMRA() {
		return DPVCMRA;
	}

	public void setDPVCMRA(String dPVCMRA) {
		DPVCMRA = dPVCMRA;
	}

	public String getDPVFootnotes() {
		return DPVFootnotes;
	}

	public void setDPVFootnotes(String dPVFootnotes) {
		DPVFootnotes = dPVFootnotes;
	}

	public String getBusiness() {
		return Business;
	}

	public void setBusiness(String business) {
		Business = business;
	}

	public String getUsageCode() {
		return UsageCode;
	}

	public void setUsageCode(String usageCode) {
		UsageCode = usageCode;
	}

	public String getCentralDeliveryPoint() {
		return CentralDeliveryPoint;
	}

	public void setCentralDeliveryPoint(String centralDeliveryPoint) {
		CentralDeliveryPoint = centralDeliveryPoint;
	}

	public String getVacant() {
		return Vacant;
	}

	public void setVacant(String vacant) {
		Vacant = vacant;
	}

	public String getRecordType() {
		return RecordType;
	}

	public void setRecordType(String recordType) {
		RecordType = recordType;
	}

	public String getSecondaryInfo() {
		return SecondaryInfo;
	}

	public void setSecondaryInfo(String secondaryInfo) {
		SecondaryInfo = secondaryInfo;
	}

	public String getReturnCode() {
		return ReturnCode;
	}

	public void setReturnCode(String returnCode) {
		ReturnCode = returnCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<String> getGeocodes() {
		return Geocodes;
	}

	public void setGeocodes(List<String> geocodes) {
		Geocodes = geocodes;
	}
	
}
