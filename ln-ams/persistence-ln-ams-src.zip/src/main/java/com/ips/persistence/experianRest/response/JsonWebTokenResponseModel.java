package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class JsonWebTokenResponseModel implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String issued_at; 
	private String expires_in;
	private String token_type;
	private String access_token;
	private String refresh_token;
	private CommonErrorResponseModel commonErrorResponse;

	/*
	 * {
   "issued_at": "1665682845",
   "expires_in": "1800",
   "token_type": "Bearer",
   "access_token": "eyJraWQiOiJGSmpTMXJQQjdJODBHWjgybmNsSlZPQkF3V3B3ZTVYblNKZUdSZHdpcEY2IiwidHlwIjoiSldUIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJjcm9zc2NvcmUyLnRlc3RAdXNwcy5nb3YiLCJFbWFpbCI6bnVsbCwiRmlyc3ROYW1lIjpudWxsLCJpc3MiOiJFWFBFUklBTiIsIkxhc3ROYW1lIjpudWxsLCJleHAiOjE2NjU2ODQ2NDUsImlhdCI6MTY2NTY4Mjg0NSwianRpIjoiZWUzNjI3YTgtMWE1MS00MGIzLTljY2ItZGMzNTI0YzdjYmIzIn0.jmKF4fLncZO-LXwaqVl6Btt_mY73VGU0yOoeAxTtAhzdJSZ2akQgyXkH65zaiL8_I5czVehRi3jWijJTNTu3jlgKHOcK4AvrZtYdze9YYXFOjs4NH-M3YhE7AE4g05daEM9Dx9mOjnDHkz1ZwEZkjHO2vD7Nu8h40uMCKaRR_-FoYSS5AMYUZG-Uv-Mqae7h6l31QnpzzD8hyJ1FPf6DJca_46mtmJm-rcjJWrRDeMYaRsSJGSST08LMlwPVIbbdwBXcv4sFlG7qochB6JT1axcl8PIp2VubDRRuNZhEPmJsqP0XnO4PCnSx7YBtIXr0M4_gaNExhxbBpJp2_GMgeg",
   "refresh_token": "IQGAD2alzMmOAqAuiqAUbWsFsNz6wVhv"
}
	 * ==========================
	 * 
	 */
	public String getIssued_at() {
		return issued_at;
	}
	
	public void setIssued_at(String issued_at) {
		this.issued_at = issued_at;
	}

	public String getExpires_in() {
		return expires_in;
	}

	public void setExpires_in(String expires_in) {
		this.expires_in = expires_in;
	}

	public String getToken_type() {
		return token_type;
	}

	public void setToken_type(String token_type) {
		this.token_type = token_type;
	}

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public String getRefresh_token() {
		return refresh_token;
	}

	public void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}

	public CommonErrorResponseModel getCommonErrorResponse() {
		return commonErrorResponse;
	}

	public void setCommonErrorResponse(CommonErrorResponseModel commonErrorResponse) {
		this.commonErrorResponse = commonErrorResponse;
	}
		
}
