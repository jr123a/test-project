package com.ips.persistence.common;

import java.io.Serializable;

import com.ips.entity.RefOtpSupplier;

public class PhoneVerificationResponse implements Serializable {

    private static final long serialVersionUID = 1L;
    
    public static final String PV_DECISION_PASS = "PASS";
    public static final String PV_DECISION_APPROVE = "APPROVE";
    public static final String PV_DECISION_REVIEW = "REVIEW";
    public static final String PV_DECISION_FAIL = "FAIL";
    public static final String PV_DECISION_DENY = "DENY";
    public static final String PV_DECISION_PENDING = "PENDING";
    public static final String FAILURE_REASON_CODE_ERROR_RESPONSE = "500";
  
    private String phoneVerificationSupplierName;
    private Long phoneVerificationSupplierId;
    private String phoneVerificationDecision;
    private String eventFinalDecision;
    private String failureReason;
    private String nextAction;
    private Long recordId;
    private boolean isSupplierEquifaxIDFS;
    private boolean isSupplierEquifaxDIT;
    private boolean isSupplierLexisNexisRDP;
     
    public PhoneVerificationResponse (Long phoneVerificationSupplierId, String phoneVerificationSupplierName, 
    		String phoneVerificationDecision, String eventFinalDecision)  {
        setPhoneVerificationSupplierId(phoneVerificationSupplierId);
        setPhoneVerificationSupplierName(phoneVerificationSupplierName);
        setPhoneVerificationDecision(phoneVerificationDecision);
        setEventFinalDecision(eventFinalDecision);
    }

    public PhoneVerificationResponse ()  {
        //Empty constructor
    }

	public String getPhoneVerificationSupplierName() {
		return phoneVerificationSupplierName;
	}

	public void setPhoneVerificationSupplierName(String phoneVerificationSupplierName) {
		this.phoneVerificationSupplierName = phoneVerificationSupplierName;
	}

	public Long getPhoneVerificationSupplierId() {
		return phoneVerificationSupplierId;
	}
	
	public void setPhoneVerificationSupplierId(Long phoneVerificationSupplierId) {
		this.phoneVerificationSupplierId = phoneVerificationSupplierId;
	}

	public String getPhoneVerificationDecision() {
		return phoneVerificationDecision;
	}

	public void setPhoneVerificationDecision(String phoneVerificationDecision) {
		this.phoneVerificationDecision = phoneVerificationDecision;
	}

	public String getEventFinalDecision() {
		return eventFinalDecision;
	}

	public void setEventFinalDecision(String eventFinalDecision) {
		this.eventFinalDecision = eventFinalDecision;
	}
	
	public String getFailureReason() {
		return failureReason;
	}

	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}

	public String getNextAction() {
		return nextAction;
	}

	public void setNextAction(String nextAction) {
		this.nextAction = nextAction;
	}

	public Long getRecordId() {
		return recordId;
	}

	public void setRecordId(Long recordId) {
		this.recordId = recordId;
	}

	public boolean isSupplierEquifaxIDFS() {
		isSupplierEquifaxIDFS = RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_NAME.equalsIgnoreCase(phoneVerificationSupplierName);
		return isSupplierEquifaxIDFS;
	}


	public void setSupplierEquifaxIDFS(boolean isSupplierEquifaxIDFS) {
		this.isSupplierEquifaxIDFS = isSupplierEquifaxIDFS;
	}

	public boolean isSupplierEquifaxDIT() {
		isSupplierEquifaxDIT = RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME.equalsIgnoreCase(phoneVerificationSupplierName);
		return isSupplierEquifaxDIT;
	}

	public void setSupplierEquifaxDIT(boolean isSupplierEquifaxDIT) {
		this.isSupplierEquifaxDIT = isSupplierEquifaxDIT;
	}

	public boolean isSupplierLexisNexisRDP() {
		isSupplierLexisNexisRDP = RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_NAME.equalsIgnoreCase(phoneVerificationSupplierName);
		return isSupplierLexisNexisRDP;
	}

	public void setSupplierLexisNexisRDP(boolean isSupplierLexisNexisRDP) {
		this.isSupplierLexisNexisRDP = isSupplierLexisNexisRDP;
	}
}
