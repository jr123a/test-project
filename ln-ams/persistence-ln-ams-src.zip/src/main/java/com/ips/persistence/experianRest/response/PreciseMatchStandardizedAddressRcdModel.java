package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchStandardizedAddressRcdModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String surname; 	//Max Length:8
	private String firstName; 	//Max Length:8
	private String middle; 	//Max Length:8
	private String address; 	//Max Length:8
	private String city; 	//Max Length:8
	private String state; 	//Max Length:8
	private String zipCode; 	//Max Length:8
	private String zipPlus4; 	//Max Length:8
	
	public String getSurname() {
		return surname;
	}
	
	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddle() {
		return middle;
	}

	public void setMiddle(String middle) {
		this.middle = middle;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	public String getZipCode() {
		return zipCode;
	}

	public String getZipPlus4() {
		return zipPlus4;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public void setZipPlus4(String zipPlus4) {
		this.zipPlus4 = zipPlus4;
	}
}
