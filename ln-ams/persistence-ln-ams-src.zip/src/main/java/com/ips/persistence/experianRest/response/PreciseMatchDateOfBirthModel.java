package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseMatchDateOfBirthModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseMatchDateOfBirthSummaryModel summary;	           //Max Length:8

	public PreciseMatchDateOfBirthSummaryModel getSummary() {
		return summary;
	}

	public void setSummary(PreciseMatchDateOfBirthSummaryModel summary) {
		this.summary = summary;
	}
	
}
