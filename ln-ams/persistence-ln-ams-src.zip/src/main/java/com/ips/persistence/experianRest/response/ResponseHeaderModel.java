package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class ResponseHeaderModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String requestType;	            
	private String clientReferenceId;		
	private String expRequestId;            
	private String messageTime;	            
	private String responseCode; 	        
	private String responseType; 	   	    
	private String responseMessage; 	   
	private String tenantID; 	   			
	private HeaderOverallResponseModel overallResponse; 	   
	
	public String getRequestType() {
		return requestType;
	}
	
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
	public String getClientReferenceId() {
		return clientReferenceId;
	}
	
	public void setClientReferenceId(String clientReferenceId) {
		this.clientReferenceId = clientReferenceId;
	}

	public String getExpRequestId() {
		return expRequestId;
	}

	public void setExpRequestId(String expRequestId) {
		this.expRequestId = expRequestId;
	}

	public String getMessageTime() {
		return messageTime;
	}

	public void setMessageTime(String messageTime) {
		this.messageTime = messageTime;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseType() {
		return responseType;
	}

	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getTenantID() {
		return tenantID;
	}

	public void setTenantID(String tenantID) {
		this.tenantID = tenantID;
	}

	public HeaderOverallResponseModel getOverallResponse() {
		return overallResponse;
	}

	public void setOverallResponse(HeaderOverallResponseModel overallResponse) {
		this.overallResponse = overallResponse;
	}
	
}
