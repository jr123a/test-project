package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseIDPreciseMatchModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String version;	           //Mandatory:Y, Max Length:8
	private ValueCodeModel responseStatusCode;		   //Mandatory:Y, Max Length:40
	private String preciseMatchTransactionID;		   //Mandatory:Y, Max Length:40
	private String preciseMatchScore;		   //Mandatory:Y, Max Length:40
	private ValueCodeModel preciseMatchDecision;		   //Mandatory:Y, Max Length:40
	private PreciseMatchAddressesModel addresses;
	private PreciseMatchPhonesModel phones;
	private PreciseMatchConsumerIDModel  consumerID;
	private PreciseMatchDateOfBirthSummaryModel dateOfBirth;
	private PreciseMatchDriverLicenseModel driverLicense;
	private PreciseMatchChangeOfAddressesModel changeOfAddresses;
	private PreciseMatchOfacModel ofac;
	private PreciseMatchPreviousAddressesModel previousAddresses;
	private PreciseMatchSsnFinderModel ssnfinder;
	
	public String getVersion() {
		return version;
	}
	
	public String getPreciseMatchTransactionID() {
		return preciseMatchTransactionID;
	}

	public String getPreciseMatchScore() {
		return preciseMatchScore;
	}

	public ValueCodeModel getPreciseMatchDecision() {
		return preciseMatchDecision;
	}

	public PreciseMatchAddressesModel getAddresses() {
		return addresses;
	}

	public PreciseMatchPhonesModel getPhones() {
		return phones;
	}

	public PreciseMatchConsumerIDModel getConsumerID() {
		return consumerID;
	}

	public PreciseMatchDateOfBirthSummaryModel getDateOfBirth() {
		return dateOfBirth;
	}

	public PreciseMatchDriverLicenseModel getDriverLicense() {
		return driverLicense;
	}

	public PreciseMatchChangeOfAddressesModel getChangeOfAddresses() {
		return changeOfAddresses;
	}

	public PreciseMatchOfacModel getOfac() {
		return ofac;
	}

	public PreciseMatchPreviousAddressesModel getPreviousAddresses() {
		return previousAddresses;
	}

	public PreciseMatchSsnFinderModel getSsnfinder() {
		return ssnfinder;
	}

	public void setPreciseMatchTransactionID(String preciseMatchTransactionID) {
		this.preciseMatchTransactionID = preciseMatchTransactionID;
	}

	public void setPreciseMatchScore(String preciseMatchScore) {
		this.preciseMatchScore = preciseMatchScore;
	}

	public void setPreciseMatchDecision(ValueCodeModel preciseMatchDecision) {
		this.preciseMatchDecision = preciseMatchDecision;
	}

	public void setAddresses(PreciseMatchAddressesModel addresses) {
		this.addresses = addresses;
	}

	public void setPhones(PreciseMatchPhonesModel phones) {
		this.phones = phones;
	}

	public void setConsumerID(PreciseMatchConsumerIDModel consumerID) {
		this.consumerID = consumerID;
	}

	public void setDateOfBirth(PreciseMatchDateOfBirthSummaryModel dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setDriverLicense(PreciseMatchDriverLicenseModel driverLicense) {
		this.driverLicense = driverLicense;
	}

	public void setChangeOfAddresses(PreciseMatchChangeOfAddressesModel changeOfAddresses) {
		this.changeOfAddresses = changeOfAddresses;
	}

	public void setOfac(PreciseMatchOfacModel ofac) {
		this.ofac = ofac;
	}

	public void setPreviousAddresses(PreciseMatchPreviousAddressesModel previousAddresses) {
		this.previousAddresses = previousAddresses;
	}

	public void setSsnfinder(PreciseMatchSsnFinderModel ssnfinder) {
		this.ssnfinder = ssnfinder;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public ValueCodeModel getResponseStatusCode() {
		return responseStatusCode;
	}

	public void setResponseStatusCode(ValueCodeModel responseStatusCode) {
		this.responseStatusCode = responseStatusCode;
	}

}
