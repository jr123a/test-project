package com.ips.persistence.experianRest.response;

import java.io.Serializable;

public class PreciseIDFrcaDetailModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private PreciseIDFraudShieldModel fraudShield;	           //Max Length:8
	private PreciseIDFcraAdverseActionsModel adverseActions;
	private PreciseIDFcraRulesModel fcrarules;

	public PreciseIDFraudShieldModel getFraudShield() {
		return fraudShield;
	}

	public void setFraudShield(PreciseIDFraudShieldModel fraudShield) {
		this.fraudShield = fraudShield;
	}

	public PreciseIDFcraAdverseActionsModel getAdverseActions() {
		return adverseActions;
	}

	public void setAdverseActions(PreciseIDFcraAdverseActionsModel adverseActions) {
		this.adverseActions = adverseActions;
	}

	public PreciseIDFcraRulesModel getFcrarules() {
		return fcrarules;
	}

	public void setFcrarules(PreciseIDFcraRulesModel fcrarules) {
		this.fcrarules = fcrarules;
	}
	
}
