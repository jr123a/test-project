package com.ips.persistence.ams.request;

import java.io.Serializable;
import java.util.List;

public class AddressLookupRequestModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String UserID;
	private String Revision;
	private List<AmsAddressModel> Address;
	
	public String getUserID() {
		return UserID;
	}
	
	public void setUserID(String userID) {
		UserID = userID;
	}

	public String getRevision() {
		return Revision;
	}

	public void setRevision(String revision) {
		Revision = revision;
	}

	public List<AmsAddressModel> getAddress() {
		return Address;
	}

	public void setAddress(List<AmsAddressModel> address) {
		Address = address;
	}
  

}
