package com.ips.proofing;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.wink.client.Resource;

import com.equifax.dit.request.InitiateDITRequestModel;
import com.equifax.dit.response.InitiateDITResponseModel;
import com.equifax.smfa.request.InitiateSMFARequestModel;
import com.equifax.smfa.request.StatusSMFARequestModel;
import com.equifax.smfa.response.InitiateSMFAResponseModel;
import com.equifax.smfa.response.StatusSMFAResponseModel;
import com.ibm.json.java.JSONObject;
import com.ips.common.common.AliasVo;
import com.ips.entity.VendorToken;
import com.ips.exception.IPSException;
import com.ips.persistence.common.ExperianResultVo;
import com.ips.persistence.common.NameValueVo;
import com.ips.persistence.common.OAuthResponse;
import com.ips.persistence.common.PersonVo;

public interface CommonRestService {

	String getOAuthToken(String serviceName, String clientIdAlias, String clientSecretAlias, String grantType, String scope, 
			String tokenType, boolean obtainNewToken) throws IPSException, IOException;
	String getOAuthRequestText(String clientIdAlias, String clientSecretAlias, String scope, String grantType) throws IPSException;
	String getServiceURL(String service);
	AliasVo getJ2CInfo(String aliasName) throws IPSException;
	String getIpsPropertyValue(String propertyName);
	String getClientIpAddress(HttpServletRequest request);
	OAuthResponse sendOAuthRequest(String serviceName, String clientIdAlias, String clientSecretAlias, String scope, String grantType) throws IPSException, IOException;
	InitiateDITResponseModel sendInitiateDITRequest(PersonVo personVo, String bearerToken, InitiateDITRequestModel initiateRequest);
	InitiateSMFAResponseModel sendInitiateSMFARequest(String bearerToken, InitiateSMFARequestModel initiateRequest) throws IOException;
	StatusSMFAResponseModel sendStatusSMFARequest(String bearerToken, String smfaSessionId, StatusSMFARequestModel statusRequest) throws IOException;
 	JSONObject getCrossCoreResponse(ExperianResultVo resultVo, Resource resource, String bearerToken, String requestJsonStr);
 	JSONObject getCommonErrorResponse(String errorType, String message);
 	Resource getClientResource(String inputUrl);
	void saveToken(VendorToken token, String accessToken, String type, Timestamp expirationTime);
	String getUserAgent(HttpServletRequest request);
	JSONObject getJsonWebTokenResponse(String webServiceURL, List<NameValueVo> headerList, ExperianResultVo resultVo);
	String getJsonWebTokenHttpClientResponse(String webServiceURL, List<NameValueVo> headerList, ExperianResultVo resultVo);
    Map<String, String> getAppNameCodeMap();

}
