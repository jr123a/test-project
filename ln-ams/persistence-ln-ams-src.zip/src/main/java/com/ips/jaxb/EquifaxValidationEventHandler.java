package com.ips.jaxb;

import javax.xml.bind.ValidationEvent; 
import javax.xml.bind.ValidationEventHandler; 

import com.ips.common.common.CustomLogger;
import com.ips.common.common.StringBuilderPlus;

public class EquifaxValidationEventHandler implements ValidationEventHandler {
    
    public boolean handleEvent(ValidationEvent event) { 
        
        if (CustomLogger.isDebugEnabled()) {
            StringBuilderPlus sb = new StringBuilderPlus();
            sb.appendLine("EVENT"); 
            sb.appendLine("SEVERITY: " + event.getSeverity()); 
            sb.appendLine("MESSAGE: " + event.getMessage()); 
            sb.appendLine("LINKED EXCEPTION: " + event.getLinkedException()); 
            sb.appendLine("LOCATOR"); 
            sb.appendLine(" LINE NUMBER: " + event.getLocator().getLineNumber()); 
            sb.appendLine(" COLUMN NUMBER: " + event.getLocator().getColumnNumber()); 
            sb.appendLine(" OFFSET: " + event.getLocator().getOffset()); 
            sb.appendLine(" OBJECT: " + event.getLocator().getObject()); 
            sb.appendLine(" NODE: " + event.getLocator().getNode()); 
            sb.appendLine(" URL: " + event.getLocator().getURL()); 
            
            CustomLogger.enter(this.getClass(), sb.toString());
        }

        return true;    
    }

}
