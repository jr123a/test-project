package com.ips.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefRpDecisionCodeDao;
import com.ips.entity.RefRpDecisionCode;

@Repository
public class RefRpDecisionCodeDaoImpl extends GenericJPADAO<RefRpDecisionCode, Long> implements
		RefRpDecisionCodeDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public RefRpDecisionCode findByDecisionCode(String decisionCode) {
        Query query = em.createNamedQuery("RefRpDecisionCode.findByDecisionCode");
        query.setParameter("decisionCode", decisionCode);
        List<RefRpDecisionCode> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
     }

}
