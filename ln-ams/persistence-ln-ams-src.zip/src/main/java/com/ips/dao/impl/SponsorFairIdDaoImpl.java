package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.SponsorFairIdDao;
import com.ips.entity.SponsorFairId;
import com.ips.entity.SponsorFairIdPK;

@Repository
@SuppressWarnings("unchecked")
public class SponsorFairIdDaoImpl extends GenericJPADAO<SponsorFairId, SponsorFairIdPK> implements
        SponsorFairIdDao, Serializable  {

    private static final long serialVersionUID = 1L;

    @Override
    public Collection<SponsorFairId> getAll() {        
        Query query = em.createNamedQuery("SponsorFairId.findAll");
        return query.getResultList();
    }

    @Override
    public Collection<SponsorFairId> getListBySponsorId(Long sponsorId) {        
        Query query = em.createNamedQuery("SponsorFairId.findBySponsor").setParameter("sponsorId", sponsorId);
        return query.getResultList();
    }
    
    @Override
    public SponsorFairId create(SponsorFairId entity) {
        super.save(entity);
        return entity;
    }
    
    @Override
    public void remove(Long sponsorId, Long idType) {
        SponsorFairId entity = getByPK(sponsorId, idType);
        super.delete(entity);
    }
    
    @Override
    public void delete(SponsorFairId entity) {
        super.delete(entity);
    }
    
    private SponsorFairId getByPK(Long sponsorId, Long idType) {
        Query query = em.createNamedQuery("SponsorFairId.findByPrimaryKey");
            query.setParameter("sponsorId", sponsorId);
            query.setParameter("idType", idType);
            
            if (query.getResultList() != null) {
                return (SponsorFairId) query.getResultList().get(0);
            }
        return null;
    }
    
    @Override
    public long getSecondaryIdCountForSponsor(long idType) {
        Query query = em.createNamedQuery("SponsorFairId.getSecondaryIdCountForSponsor");
        query.setParameter("idType", idType);
        List<Long> results = query.getResultList();
        if (results.isEmpty()) {
            return 0L;
        } else {
            return  results.get(0);
        }
    }
    
    @Override
    public List<SponsorFairId> findSponsorFairIdBySponsor(long sponsorId) {
 		List<SponsorFairId> list = em.createNamedQuery("SponsorFairId.findSponsorFairIdBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
    
}
