package com.ips.dao;

import java.util.List;

import com.ips.entity.PhysicalLetterData;

public interface PhysicalLetterDataDao {

    void save(PhysicalLetterData ph);
    void update(PhysicalLetterData ph);
    void delete(PhysicalLetterData ph);
    PhysicalLetterData getById(long e);
    List<PhysicalLetterData> findPhysicalLetterDataBySponsor(long sponsorId);

}
