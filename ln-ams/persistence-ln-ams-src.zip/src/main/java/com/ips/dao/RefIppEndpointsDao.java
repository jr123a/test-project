package com.ips.dao;

import com.ips.entity.RefIppEndpoints;

public interface RefIppEndpointsDao {
    public RefIppEndpoints findByEndpointName(String endpointName);
}
