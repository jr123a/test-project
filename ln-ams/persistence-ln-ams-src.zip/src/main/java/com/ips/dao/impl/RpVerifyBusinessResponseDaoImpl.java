package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpVerifyBusinessResponseDao;
import com.ips.entity.RpVerifyBusinessResponse;

@Repository
@Transactional
public class RpVerifyBusinessResponseDaoImpl extends GenericJPADAO<RpVerifyBusinessResponse, Long> implements RpVerifyBusinessResponseDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpVerifyBusinessResponse> getAll() {        
        Query query = em.createNamedQuery("RpVerifyBusinessResponse.getAll");
        return query.getResultList();
    }

    @Override
    public RpVerifyBusinessResponse getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpVerifyBusinessResponse entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpVerifyBusinessResponse entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpVerifyBusinessResponse entity) {
        super.save(entity);
    }
    

    @SuppressWarnings("unchecked")
    @Override
    public List<RpVerifyBusinessResponse> getListByPersonId(long personId) {
        Query query = em.createNamedQuery("RpVerifyBusinessResponse.getListByPersonId");
        query.setParameter("personId", personId);
       
        return query.getResultList();    
    }
    
    @Override
    public RpVerifyBusinessResponse getByPersonId(long personId) {
        List<RpVerifyBusinessResponse> results = getListByPersonId(personId);
        
        return results.isEmpty()? null : results.get(0);    
    }

}
