package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpDeviceReputationResponseDao;
import com.ips.entity.RpDeviceReputationResponse;

@Repository
@Transactional
public class RpDeviceReputationResponseDaoImpl extends GenericJPADAO<RpDeviceReputationResponse, Long> implements RpDeviceReputationResponseDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpDeviceReputationResponse> getAll() {        
        Query query = em.createNamedQuery("RpDeviceReputationResponse.getAll");
        return query.getResultList();
    }

    @Override
    public RpDeviceReputationResponse getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpDeviceReputationResponse entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpDeviceReputationResponse entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpDeviceReputationResponse entity) {
        super.save(entity);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpDeviceReputationResponse getByRequestId(String id) {
        Query query = em.createNamedQuery("RpDeviceReputationResponse.getByRequestId");
        query.setParameter("requestId", id);
        List<RpDeviceReputationResponse> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);    
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RpDeviceReputationResponse> getListByPersonId(long personId) {
        Query query = em.createNamedQuery("RpDeviceReputationResponse.getListByPersonId");
        query.setParameter("personId", personId);
       
        return query.getResultList();    
    }
    
    @Override
    public RpDeviceReputationResponse getByPersonId(long personId) {
        List<RpDeviceReputationResponse> results = getListByPersonId(personId);
        
        return results.isEmpty()? null : results.get(0);    
    }
    
    @Override
    public boolean isIndividualNotFound(long personId) {
    	List<RpDeviceReputationResponse> dpResponseList = getListByPersonId(personId);
       
    	RpDeviceReputationResponse latestDrResponse = dpResponseList.isEmpty()? null : dpResponseList.get(0); 
		
    	if(latestDrResponse != null) {
    		String response = latestDrResponse.getResponse();
    		
    		if (response.contains("individual_not_found")) {
    			return true;
    		}
		}
    	
    	return false;
    	
    }
}
