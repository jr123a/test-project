package com.ips.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.PhysicalLetterDataDao;
import com.ips.entity.PhysicalLetterData;

@Repository
public class PhysicalLetterDataDaoImpl extends GenericJPADAO<PhysicalLetterData, Long>
        implements PhysicalLetterDataDao, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Override
    public PhysicalLetterData getById(long e) {

        Query query = em.createNamedQuery("PhysicalLetterData.getByEventId");

        query.setParameter("eventId", e);

        @SuppressWarnings("unchecked")
        List<PhysicalLetterData> results = query.getResultList();

        if (results.isEmpty()) {
            return null;
        } else {
            return results.get(0);
        }

    }

    @Override
    public void update(PhysicalLetterData ph) {
        super.merge(ph);
    }
    
    @Override
    public void delete(PhysicalLetterData ph) {
        super.delete(ph);
    }
    
    @Override
    public List<PhysicalLetterData> findPhysicalLetterDataBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<PhysicalLetterData> list = em.createNamedQuery("PhysicalLetterData.findPhysicalLetterDataBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
}
