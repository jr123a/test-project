package com.ips.dao;

import com.ips.entity.LookupCodesEnv;

public interface LookupCodesEnvDao {

    LookupCodesEnv getValueByEnvironment(String env, String name);
    void updateEnvValueByEnvironment(String env, String selectedVendorName, String urlValue, String userId);

}
