package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpAmsResponseDao;
import com.ips.entity.RpAmsResponse;


@Repository
@Transactional
public class RpAmsResponseDaoImpl extends GenericJPADAO<RpAmsResponse, Long> implements RpAmsResponseDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpAmsResponse> getAll() {        
        Query query = em.createNamedQuery("RpAmsResponse.getAll");
        return query.getResultList();
    }

    @Override
    public RpAmsResponse getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpAmsResponse entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpAmsResponse entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpAmsResponse entity) {
        super.save(entity);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RpAmsResponse> getListByPersonId(long personId) {
        Query query = em.createNamedQuery("RpAmsResponse.getListByPersonId");
        query.setParameter("personId", personId);
       
        return query.getResultList();    
    }
    
    @Override
    public RpAmsResponse getByPersonId(long personId) {
        List<RpAmsResponse> results = getListByPersonId(personId);
        
        return results.isEmpty()? null : results.get(0);    
    }
    
}
