package com.ips.dao;

import com.ips.entity.RefCustomerCategory;

public interface RefCustomerCategoryDao {
	RefCustomerCategory findByCategoryId(long id);
	RefCustomerCategory findByCategoryName(String name);
	void create(RefCustomerCategory entity);
}
