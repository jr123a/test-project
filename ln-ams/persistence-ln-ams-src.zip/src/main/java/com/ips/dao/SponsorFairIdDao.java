package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.SponsorFairId;

public interface SponsorFairIdDao {
    Collection<SponsorFairId> getAll();
    Collection<SponsorFairId> getListBySponsorId(Long sponsorId);
    SponsorFairId create(SponsorFairId entity);
    void remove(Long sponsorId, Long idType);
    void delete(SponsorFairId entity);
    long getSecondaryIdCountForSponsor(long idType);
    List<SponsorFairId> findSponsorFairIdBySponsor(long sponsorId);
}
