package com.ips.dao;

import com.ips.entity.RefOtpReasonCode;


public interface RefOtpReasonCodeDao {

	RefOtpReasonCode findByReasonCode(String reasonCode);
}
