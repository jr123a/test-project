package com.ips.dao;

import com.ips.entity.SponsorApplicationMap;
import java.util.List;

public interface SponsorApplicationMapDao {
    List<SponsorApplicationMap> getRelationsBySponsor(long sponsorId);
    List<SponsorApplicationMap> getRelationsByApplication(long appId);
    SponsorApplicationMap getRelationBySponsorAndApplication(long sponsorId, long appId);
    void create(SponsorApplicationMap entity);
    void update(SponsorApplicationMap entity);
    void delete(SponsorApplicationMap entity);
    List<SponsorApplicationMap> getAllRelations();
}
