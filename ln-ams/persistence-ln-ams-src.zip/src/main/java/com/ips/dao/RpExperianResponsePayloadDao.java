package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpExperianResponsePayload;



public interface RpExperianResponsePayloadDao {

    Collection<RpExperianResponsePayload> getAll();    
    RpExperianResponsePayload getById(Long id);
    void create(RpExperianResponsePayload entity);
    void update(RpExperianResponsePayload entity);
    List<RpExperianResponsePayload> getListByResultIdServiceName(long resultId, String serviceName);
    List<RpExperianResponsePayload> getListByResultIdSequenceIdServiceName(long resultId, String sequenceId, String serviceName);
    RpExperianResponsePayload getByResultIdServiceName(long resultId, String serviceName);

}
