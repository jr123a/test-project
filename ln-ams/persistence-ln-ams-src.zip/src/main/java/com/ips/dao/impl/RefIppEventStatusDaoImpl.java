package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefIppEventStatusDao;
import com.ips.entity.RefIppEventStatus;

@Repository
public class RefIppEventStatusDaoImpl extends GenericJPADAO<RefIppEventStatus, Long> implements
        RefIppEventStatusDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefIppEventStatus> getAll() {        
        Query query = em.createNamedQuery("RefIppEventStatus.findAll");
        return query.getResultList();
    }

    @Override
    public RefIppEventStatus getById(Long id) {        
        return super.getById(id);
    }

    @Override
    public void save(RefIppEventStatus status) {        
        super.save(status);
    }

    @Override
    public void update(RefIppEventStatus status) {        
        super.merge(status);
    }

    @Override
    public void delete(RefIppEventStatus status) {
        super.delete(status);
    }

    @Override
    public RefIppEventStatus findByDescription(String newIpEvent) {
        Query query = em.createNamedQuery("RefIppEventStatus.findByDesc").setParameter("status", newIpEvent);
        @SuppressWarnings("unchecked")
        List<RefIppEventStatus> results = query.getResultList();    
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }

}
