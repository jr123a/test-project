package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefOtpMatchQuality;

public interface OtpMatchQualityDao {
    Collection<RefOtpMatchQuality> getAll();    
    RefOtpMatchQuality getById(Long id);
    void save(RefOtpMatchQuality entity);
    void update(RefOtpMatchQuality entity);
    void delete(RefOtpMatchQuality entity);
    RefOtpMatchQuality getQualityByName(String name);
}
