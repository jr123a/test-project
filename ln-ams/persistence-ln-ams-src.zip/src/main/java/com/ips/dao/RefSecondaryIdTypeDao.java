package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefSecondaryIdType;


public interface RefSecondaryIdTypeDao {

    Collection<RefSecondaryIdType> getAll();    
    Collection<RefSecondaryIdType> getAvailableFairList(Long sponsorId);
    Collection<RefSecondaryIdType> getSponsorFairList(Long sponsorId);
    RefSecondaryIdType getById(Long id);
    void save(RefSecondaryIdType entity);
    void update(RefSecondaryIdType entity);
    void delete(RefSecondaryIdType entity);
    String getDescription(int idType);
}
