package com.ips.dao;

import java.util.Collection;

import com.ips.entity.ProgramOnlineStats;
import com.ips.entity.RefOtpSupplier;


public interface ProgramOnlineStatsDao {
    Collection<ProgramOnlineStats> getAll();
    ProgramOnlineStats getById(Long id);
    ProgramOnlineStats getByOtpSupplier(RefOtpSupplier otpSupplier);
    void update(ProgramOnlineStats programOnlineStats);
    void save(ProgramOnlineStats programOnlineStats);
    void delete(ProgramOnlineStats programOnlineStats);
}
