package com.ips.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefOtpReasonCodeDao;
import com.ips.dao.RefRpDecisionCodeDao;
import com.ips.entity.RefOtpReasonCode;
import com.ips.entity.RefRpDecisionCode;

@Repository
public class RefOtpReasonCodeDaoImpl extends GenericJPADAO<RefOtpReasonCode, Long> implements
		RefOtpReasonCodeDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public RefOtpReasonCode findByReasonCode(String reasonCode) {
        Query query = em.createNamedQuery("RefOtpReasonCode.findByReasonCode");
        query.setParameter("reasonCode", reasonCode);
        List<RefOtpReasonCode> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
     }

}
