package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RefOtpReasonCode;


public interface RefEquifaxReasonCodeDao {
    
    Collection<RefOtpReasonCode> retrieveLNCodes(List<String> list);    
}
