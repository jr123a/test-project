package com.ips.dao;

import java.util.List;

import com.ips.entity.RefSponsorConfiguration;

public interface RefSponsorConfigurationDao {
    List<RefSponsorConfiguration> getConfiguration();
    List<RefSponsorConfiguration> findConfigRecordByName(String name);
    RefSponsorConfiguration getConfigRecord(int sponsorId, String name);
    void update(RefSponsorConfiguration refSponsorConfig);
    Long getConfigRecordCount(int sponsorId, String name);
    long getMaxConfigId();
    void create(RefSponsorConfiguration entity);
    void delete(RefSponsorConfiguration entity);
    List<RefSponsorConfiguration> findConfigRecordsBySponsor(long sponsorId);
}
