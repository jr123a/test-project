package com.ips.dao;

import com.ips.entity.PersonProofingStatus;

public interface PersonProofingStatusDao {
	PersonProofingStatus getByPersonId(int personId);
    void update(PersonProofingStatus personProofingStatus);
    Long getPersonProofingStatusCodeByPersonId(int personId);
}
