package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefProductStatusCode;

public interface PhoneProductStatusDao {
    Collection<RefProductStatusCode> getAll();    
    RefProductStatusCode getById(Long id);
    void save(RefProductStatusCode entity);
    void update(RefProductStatusCode entity);
    void delete(RefProductStatusCode entity);
    RefProductStatusCode getProductStatusByName(String name);
}
