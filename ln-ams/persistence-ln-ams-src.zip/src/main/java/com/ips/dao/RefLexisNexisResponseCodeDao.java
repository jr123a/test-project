package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefLexisNexisResponseCode;

public interface RefLexisNexisResponseCodeDao {
    Collection<RefLexisNexisResponseCode> getAll();    
    RefLexisNexisResponseCode getById(Long id);
    void save(RefLexisNexisResponseCode responseCode);
    void update(RefLexisNexisResponseCode responseCode);
    void delete(RefLexisNexisResponseCode responseCode);
    RefLexisNexisResponseCode getById(String code);
    RefLexisNexisResponseCode getByDescription(String description);
    RefLexisNexisResponseCode getByProductReason(String productReason);
}
