package com.ips.dao;


import java.util.Collection;

import com.ips.entity.RefState;

public interface RefStateDao {

    Collection<RefState> getAllActiveStates();

    void save(RefState entity);

    void delete(RefState entity);

    void update(RefState entity);

    Collection<RefState> getAll();

    RefState findByStateCode(String stateCode);

}
