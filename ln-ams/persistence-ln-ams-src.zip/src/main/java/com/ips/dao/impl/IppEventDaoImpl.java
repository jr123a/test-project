package com.ips.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.persistence.common.FacilityTransactionReportVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.IndividualTransactionReportVo;
import com.ips.dao.IppEventDao;
import com.ips.entity.IppEvent;
import com.ips.entity.Person;
import com.ips.entity.RefIppApplications;
import com.ips.entity.RefIppEventStatus;
import com.ips.entity.RefIppFailureReason;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefSponsor;

@Repository
public class IppEventDaoImpl extends GenericJPADAO<IppEvent, Long> implements IppEventDao {

    private static final String START_DATE = "startDate";
    private static final String END_DATE = "endDate";
    private static final String IPP_EVENT_STATUS = "ippEventStatus";
    private static final String SPONSOR_ID = "sponsorId";
    private static final String DAY_BEFORE = "dayBefore";
    private static final String DAY_AFTER = "dayAfter";
    private static final String RECORD_LOCATOR = "recordLocator";
    private static final String PERSON_ID = "personId";
    private static final String IN_PERSON_PROOFING_TYPE = "inPersonProofingType";
    private static final String APPOINTMENT_DATE = "appointmentDate";
    private static final String LEVEL = "level";
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection<IppEvent> getAll() {
        Query query = em.createNamedQuery("IppEvent.findAll");
        return query.getResultList();
    }
    
    @Override
    public IppEvent getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void update(IppEvent ippEvent) {
        super.merge(ippEvent);
        em.flush();
    }

    @SuppressWarnings("unchecked")
    @Override
    public IppEvent findByRecordLocator(String recordLocator) {
        Query query = em.createNamedQuery("IppEvent.findByRecordLocator");
        query.setParameter(RECORD_LOCATOR, recordLocator);
        List<IppEvent> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
        
    }

    @SuppressWarnings("unchecked")
    @Override
    public IppEvent findConfirmationNumber(RefIppEventStatus ippEventStatus,
            Person person) {
        Query query = em.createNamedQuery("IppEvent.findConfirmationNumber");
        query.setParameter(IPP_EVENT_STATUS, ippEventStatus).setParameter("person", person);
        List<IppEvent> results = query.getResultList();
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public IppEvent findAppointment(RefIppEventStatus ippEventStatus, long personId) {
        Query query = em.createNamedQuery("IppEvent.findAppointment");
        query.setParameter(IPP_EVENT_STATUS, ippEventStatus).setParameter(PERSON_ID, personId);
        List<IppEvent> results = query.getResultList();
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public IppEvent findByStatus(RefIppEventStatus ippEventStatus,
            Person person) {
        Query query = em.createNamedQuery("IppEvent.findByStatus");
        query.setParameter(IPP_EVENT_STATUS, ippEventStatus).setParameter("person", person);
        List<IppEvent> results = query.getResultList();
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<IppEvent> findIppEventsByPersonId(long personId) {
        Query query = em.createNamedQuery("IppEvent.findIppEventsByPersonId");
        query.setParameter("personId", personId);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<IppEvent> findAllIppEventsAtResidence(String inPersonProofingType, Date appointmentDate) {
        Query query = em.createNamedQuery("IppEvent.findAllIppEventsAtResidence");
        query.setParameter(IN_PERSON_PROOFING_TYPE, inPersonProofingType).setParameter(APPOINTMENT_DATE, appointmentDate);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<IppEvent> validationQuery() {
        Query query = em.createNativeQuery("select 0 from dual");
        return query.getResultList();
    }
    
    
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * If a user opts in more than once on a particular day, this query will count every time they opt in.
     * @param start
     * @param end
     * @return
     */
    public Long getIPPOptInCount(Date start, Date end) {
        Query query = em.createNativeQuery("SELECT COUNT(*) FROM audit_person " +
                "WHERE proofing_status = 'Opted-in for in-person proofing' " +
                "AND person_id IN (SELECT person_id FROM person WHERE user_type IS NULL) " +
                "AND proofing_status_datetime >= ? AND proofing_status_datetime <= ? ");
        
        query.setParameter(1, start);
        query.setParameter(2, end);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<IppEvent> findEventsWithNoFacilityByMonth(Date start, Date end, int firstResult, int maxResults) {
        Query query = em.createNamedQuery("IppEvent.findEventsWithNoFacilityByMonth");
        query.setParameter(START_DATE, start);
        query.setParameter(END_DATE, end);
        query.setFirstResult(firstResult);
        query.setMaxResults(maxResults);
        return query.getResultList();
    }
    
    @Override
    public Long getEventsWithNoFacilityCountByMonth(Date start, Date end) {
        Query query = em.createNamedQuery("IppEvent.getEventsWithNoFacilityCountByMonth");
        query.setParameter(START_DATE, start);
        query.setParameter(END_DATE, end);
        return (Long)query.getSingleResult();
    }
    
    public Long getIPPStatusCount(RefIppEventStatus ippEventStatus, Date start, Date end) {
        Query query = em.createNamedQuery("IppEvent.getIPPStatusCount");
        
        query.setParameter(IPP_EVENT_STATUS, ippEventStatus);
        query.setParameter(START_DATE, start);
        query.setParameter(END_DATE, end);
        
        @SuppressWarnings("unchecked")
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getIPPFlaggedAsFraudCount(Date start, Date end) {
        Query query = em.createNamedQuery("IppEvent.getIPPFlaggedAsFraudCount").setParameter(START_DATE, start).setParameter(END_DATE, end);
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Retrieves the list of facilities that have events with the specified status in the timeframe.
     * @param start
     * @param end
     * @return
     */
    public List<BigDecimal> getFacilityIdsForCompletedEvents(Date start, Date end) {
    
        Query query = em.createNativeQuery("SELECT DISTINCT e.facility_id " +
                "FROM ipp_event e " +
                "WHERE ipp_event_status in (2,3) " +
                "AND in_person_proofing_type = 'F' " +
                "AND transaction_end_datetime >= ? AND transaction_end_datetime <= ? ");
        
        query.setParameter(1, start);
        query.setParameter(2, end);
        
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getIPPStatusCountByLevel(RefIppEventStatus ippEventStatus, Date start, Date end, RefLoaLevel loa) {
        Query query = em.createNamedQuery("IppEvent.getIPPStatusCountByLevel");
        
        query.setParameter(IPP_EVENT_STATUS, ippEventStatus);
        query.setParameter(START_DATE, start);
        query.setParameter(END_DATE, end);
        query.setParameter(LEVEL, loa);
        
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getIPPFlaggedAsFraudCountByLevel(Date start, Date end, RefLoaLevel loa) {
        Query query = em.createNamedQuery("IppEvent.getIPPFlaggedAsFraudCountByLevel").setParameter(START_DATE, start).setParameter(END_DATE, end).setParameter("level", loa);
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Retrieves the IPP failure reasons in the timeframe.
     * @param start
     * @param end
     * @return
     */
    public List<RefIppFailureReason> getIppFailureReasons(Date start, Date end, RefLoaLevel loa) {
    
        Query query = em.createNativeQuery(
                "SELECT r.failure_reason_code, r.reason_code_description, r.create_date, r.update_date " +
                "FROM ipp_event e, ref_ipp_failure_reason r " +
                "WHERE e.failure_reason_code = r.failure_reason_code " +
                "AND e.proofing_level_sought = ? " +
                "AND e.transaction_end_datetime >= ? " +
                "AND e.transaction_end_datetime <= ? ", RefIppFailureReason.class);
        
        query.setParameter(1, loa.getLoaCode());
        query.setParameter(2, start);
        query.setParameter(3, end);
        
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getReasonCodeCount(Date start, Date end, String reasonCode, RefLoaLevel loa) {
        Query query = em.createNativeQuery(
                "SELECT count(e.ipp_event_id) " +
                "FROM ipp_event e " +
                "WHERE e.failure_reason_code = ? " +
                "AND e.proofing_level_sought = ? " +
                "AND e.transaction_end_datetime >= ? " +
                "AND e.transaction_end_datetime <= ? ");
        
        query.setParameter(1, reasonCode);
        query.setParameter(2, loa.getLoaCode());
        query.setParameter(3, start);
        query.setParameter(4, end);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * If a user opts in more than once on a particular day, this query will count every time they opt in.
     * @param start
     * @param end
     * @return
     */
    public Long getIPPOptInCountByLevel(Date start, Date end, String loaLevel) {
        Query query = em.createNativeQuery("SELECT COUNT(*) FROM audit_person " +
                "WHERE proofing_status = 'Opted-in for in-person proofing' " +
                "AND proofing_level = ? " +
                "AND person_id IN (SELECT person_id FROM person WHERE user_type IS NULL) " +
                "AND proofing_status_datetime >= ? AND proofing_status_datetime <= ? ");
        
        query.setParameter(1, loaLevel);
        query.setParameter(2, start);
        query.setParameter(3, end);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<IppEvent> getReminderEvents(RefSponsor sponsor, RefIppEventStatus ippEventStatus, Date start, Date end) {
        Query query = em.createNamedQuery("IppEvent.getReminderEvents");
        
        query.setParameter(SPONSOR_ID, sponsor);
        query.setParameter(IPP_EVENT_STATUS, ippEventStatus);
        query.setParameter(START_DATE, start);
        query.setParameter(END_DATE, end);
        
        return query.getResultList();
    }
    
    @Override
    public  RefIppApplications findByApplicationAcronym(String appAcronym) {
        Query query = em.createNamedQuery("RefIppApplications.findByApplicationAcronym")
                .setParameter("appAcronym", appAcronym);
        RefIppApplications app = null;
        @SuppressWarnings("unchecked")
        List<RefIppApplications> list = query.getResultList(); 
        Optional<RefIppApplications> result = list.stream().findFirst();
        
        if (result.isPresent()) {
            app = result.get();
        }

        return app;
    }
    
    @SuppressWarnings("unchecked")
    public List<String> findMonthsForEventsWithNoFacility() {
        Query query = em.createNativeQuery(
                "SELECT distinct to_char(transaction_end_datetime, 'YYYY-MM') yearmonth " +
                    "FROM ipp_event e " + 
                    "WHERE e.ref_facility_Id = 0 " +
                    "AND in_person_proofing_location <> '0.000000,0.000000' " + 
                    "AND in_Person_Proofing_Type = 'F' " +
                    "ORDER BY yearmonth ");
        
        return query.getResultList();
    }
    
    public Long getIPPStatusCountBySponsor(RefIppEventStatus ippEventStatus, Date start, Date end, RefSponsor sponsor) {
        Query query = em.createNamedQuery("IppEvent.getIPPStatusCountBySponsor");
        
        query.setParameter(IPP_EVENT_STATUS, ippEventStatus);
        query.setParameter(START_DATE, start);
        query.setParameter(END_DATE, end);
        query.setParameter(SPONSOR_ID, sponsor);
        
        @SuppressWarnings("unchecked")
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    public void getIPPFacilityTransactionCounts(long sponsorId, Date start, Date end, boolean daily, List<FacilityTransactionReportVo> list) {
        
        Query query = em.createNativeQuery("select NVL(area_name,'Area not found') Area, NVL(district_name,'District not found') District, facility_name, f.facility_id, agency_policy_proofing_result, count(*) " +
                "from ipp_event e, ref_area a, ref_district d, ref_fac_facility f, person p " +
                "WHERE ipp_event_status in (2, 3) " +
                "and p.sponsor_id = ? " +
                "AND e.transaction_end_datetime >= ? " +
                "AND e.transaction_end_datetime <= ? " +
                "and e.ref_facility_id = f.ref_facility_id " +
                "and f.area_id = a.area_id(+) " +
                "and f.district_id = d.district_id(+) " +
                "and e.person_id = p.person_id " +
                "group by area_name, district_name, facility_name, f.facility_id, agency_policy_proofing_result " +
                "order by area_name, district_name, facility_name, facility_id ");
        
        query.setParameter(1, sponsorId);
        query.setParameter(2, start);
        query.setParameter(3, end);
        
        List<Object[]> results = query.getResultList();
        
        if (!results.isEmpty()) {
            BigDecimal prevFacilityID = new BigDecimal(0);
            FacilityTransactionReportVo vo = new FacilityTransactionReportVo();
            
            FacilityTransactionReportVo facilityNotFoundVo = null; 
            
            for (Object[] row: results) {
                BigDecimal facilityID = (BigDecimal)row[3];
                
                if (facilityID.compareTo(BigDecimal.ZERO) == 0) {
                    if (facilityNotFoundVo == null) { 
                        facilityNotFoundVo = new FacilityTransactionReportVo(); 
                        list.add(facilityNotFoundVo); 
                    }
 
                    this.setFacilityTransactionReportVoProperties(facilityNotFoundVo, row, facilityID, daily);
                    continue; 
                                  
                }
 
                if (!prevFacilityID.equals(facilityID)) {
                    vo = new FacilityTransactionReportVo();
                    list.add(vo);
                }
            
                setFacilityTransactionReportVoProperties(vo, row, facilityID, daily); 
                
                prevFacilityID = facilityID;
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<IndividualTransactionReportVo> getIPPIndividualTransactions(long sponsorId, Date start, Date end) {
            
        Query query = em.createNativeQuery("select area_name, district_name, facility_name, f.facility_id, id_proofer_user_id, "+
                "first_name, last_name, address_line_1, pd.city, pd.state_province, pd.postal_code, " +
                "s.event_status_description, record_locator, " +
                "e.primary_id_type, pt.id_type_description, e.secondary_id_type, st.id_type_description, " +
                "e.create_date, transaction_end_datetime, " +
                "reason_code_description, " +
                "to_char(transaction_end_datetime - transaction_start_datetime, 'HH:MI:SS'), " +
                "hist.transaction_success, failed_attempts, number_of_attempts " +
                "from ipp_event e, person p, person_data pd, ref_ipp_event_status s, ref_area a, ref_district d, ref_fac_facility f, " +
                "ref_ipp_failure_reason r, ref_primary_id_type pt, ref_secondary_id_type st, " +
                "sponsor_web_service_history hist, sponsor_web_service_queue q " +
                "WHERE e.ipp_event_status in (2, 3, 12) " +
                "AND e.transaction_end_datetime >= ? " +
                "AND e.transaction_end_datetime <= ? " +
                "and e.person_id = p.person_id " +
                "and e.person_id = pd.person_id(+) " +
                "and p.sponsor_id = ? " +
                "and e.agency_policy_proofing_result = s.ipp_event_status " +
                "and e.ref_facility_id = f.ref_facility_id " +
                "and f.area_id = a.area_id(+) " +
                "and f.district_id = d.district_id(+) " +
                "and e.failure_reason_code = r.failure_reason_code(+) " +
                "and e.primary_id_type = pt.id_type " +
                "and e.secondary_id_type = st.id_type(+) " +
                "and record_locator = hist.enrollment_code(+) " +
                "and record_locator = q.enrollment_code(+) " +
                "order by area_name, district_name, facility_name, facility_id, transaction_start_datetime ");
        
        query.setParameter(1, start);
        query.setParameter(2, end);
        query.setParameter(3, sponsorId);
        
        List<Object[]> results = query.getResultList();
        List<IndividualTransactionReportVo> list = new ArrayList<>();
        
        if (!results.isEmpty()) {
            for (Object[] row: results) {
                IndividualTransactionReportVo vo = new IndividualTransactionReportVo();
                int i = 0;
                
                vo.setArea((String)row[i++]);
                vo.setDistrict((String)row[i++]);
                vo.setFacilityName((String)row[i++]);
                vo.setFacilityId(((BigDecimal)row[i++]).longValue());
                vo.setAceId((String)row[i++]);
                vo.setCustomerName((String)row[i++] + " " + (String)row[i++]);
                vo.setCustomerStreet((String)row[i++]);
                vo.setCustomerCity((String)row[i++]);
                vo.setCustomerState((String)row[i++]);
                vo.setCustomerZip((String)row[i++]);
                
                String eventStatus = (String)row[i++];
                
                if (eventStatus.equalsIgnoreCase(IPSConstants.IPP_STATUS_PASSED)) {
                    eventStatus = "Pass";
                }
                else if (eventStatus.equalsIgnoreCase(IPSConstants.IPP_STATUS_FAILED)) {
                    eventStatus = "Fail";
                }
                
                vo.setResult(eventStatus);
                vo.setEnrollmentCode((String)row[i++]);
                vo.setPrimaryType(((BigDecimal)row[i++]).longValue());
                vo.setPrimaryDescription((String)row[i++]);
                
                BigDecimal secondaryIdType = (BigDecimal)row[i++];
                
                if (secondaryIdType != null) {
                    vo.setSecondaryType(secondaryIdType.longValue());
                }
                
                vo.setSecondaryDescription((String)row[i++]);
                vo.setOptInDate((Timestamp)row[i++]);
                vo.setTransactionEndDateTime((Timestamp)row[i++]);
                vo.setFailureReason((String)row[i++]);
                
                vo.setTransactionTime((String)row[i++]);
                vo.setFinalSuccess((String)row[i++]);
                
                BigDecimal failedAttempts = (BigDecimal)row[i++];
                
                if (failedAttempts == null) {
                    vo.setFailedAttempts(0);
                }
                else {
                    vo.setFailedAttempts(failedAttempts.longValue());
                }
                
                BigDecimal nbrOfAttempts = (BigDecimal)row[i++];
                
                if (nbrOfAttempts == null) {
                    vo.setNumberOfAttempts(0);
                }
                else {
                    vo.setNumberOfAttempts(nbrOfAttempts.longValue());
                }
                
                list.add(vo);
            }
        }
        
        return list;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<IppEvent> findNewEventsForSponsor(Date start, Date end, RefSponsor sponsor, RefIppEventStatus ippEventStatus) {
        Query query = em.createNamedQuery("IppEvent.findNewEventsBySponsor");
        query.setParameter(START_DATE, start);
        query.setParameter(END_DATE, end);
        query.setParameter(SPONSOR_ID, sponsor);
        query.setParameter(IPP_EVENT_STATUS, ippEventStatus);
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Retrieve the number of opt-ins for the sponsor in the date range.
     * @param sponsor
     * @param start
     * @param end
     * @return
     */
    public Long getOptInCountBySponsor(RefSponsor sponsor, Date start, Date end) {
        Query query = em.createNamedQuery("IppEvent.getOptInCountBySponsor");
        query.setParameter(START_DATE, start);
        query.setParameter(END_DATE, end);
        query.setParameter(SPONSOR_ID, sponsor);
        
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    /**
     * Get the count of IPP events that have a particular agency policy proofing result.
     * @param ippEventStatus
     * @param start
     * @param end
     * @param sponsor
     * @return
     */
    public Long getPolicyResultCountBySponsor(RefIppEventStatus proofingResult, RefSponsor sponsor, Date start, Date end) {
        Query query = em.createNamedQuery("IppEvent.getPolicyResultCountBySponsor");
        
        query.setParameter("proofingResult", proofingResult);
        query.setParameter(START_DATE, start);
        query.setParameter(END_DATE, end);
        query.setParameter(SPONSOR_ID, sponsor);
        
        @SuppressWarnings("unchecked")
        List<Long> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            return results.get(0);
        }
    }
    
    private void setFacilityTransactionReportVoProperties(FacilityTransactionReportVo facilityTransactionReportVo, Object[] row, BigDecimal facilityID, boolean daily) { 
        facilityTransactionReportVo.setArea((String)row[0]);
        facilityTransactionReportVo.setDistrict((String)row[1]);
        facilityTransactionReportVo.setFacilityName((String)row[2]);
        facilityTransactionReportVo.setFacilityId(facilityID.longValue());
        
        BigDecimal policyResult = (BigDecimal)row[4];
        BigDecimal count = (BigDecimal)row[5];
        
        if (policyResult.intValue() == IPSConstants.IPP_EVENT_PASSED) {
            if (daily) {
                facilityTransactionReportVo.setDayPassed(count.longValue());
            }
            else {
                facilityTransactionReportVo.setMonthPassed(count.longValue());
            }
        }
        else if (policyResult.intValue() == IPSConstants.IPP_EVENT_FAILED) {
            if (daily) {
                facilityTransactionReportVo.setDayFailed(count.longValue());
            }
            else {
                facilityTransactionReportVo.setMonthFailed(count.longValue());
            }
        }        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getPrimaryIdUsedCountByIdType(long idType) {
        Query query = em.createNamedQuery("IppEvent.getPrimaryIdUsedCountByIdType");
        query.setParameter("idType", idType);

        List<Long> results = query.getResultList();

        if (results.isEmpty()) {
            return 0L;
        } else {
            return results.get(0);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public Long getSecondaryIdUsedCountByIdType(long idType) {
        Query query = em.createNamedQuery("IppEvent.getSecondaryIdUsedCountByIdType");

        query.setParameter("idType", idType);

        List<Long> results = query.getResultList();

        if (results.isEmpty()) {
            return 0L;
        } else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public int getEventCountByApplicationId(long appId) {
        List<Long> results = em.createNamedQuery("IppEvent.getEventCountByApplicationId").setParameter("appId", appId).getResultList();
        if (results == null || results.isEmpty()) {
            return -1;
        } else {
            return results.get(0).intValue();
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public int getEventCountWithStartStatusBySponsor(long sponsorId) {
        List<Long> results = em.createNamedQuery("IppEvent.getEventCountWithStartStatusBySponsor").setParameter(SPONSOR_ID, sponsorId).getResultList();
        if (results == null || results.isEmpty()) {
            return -1;
        } else {
            return results.get(0).intValue();
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<IppEvent> getEventsByTransactionEndDate(Timestamp beforeDate, Timestamp afterDate) {
        Query query = em.createNamedQuery("IppEvent.getEventsByTransactionEndDate");
        query.setParameter(DAY_BEFORE, beforeDate);
        query.setParameter(DAY_AFTER, afterDate);
        return query.getResultList();
    }
}
