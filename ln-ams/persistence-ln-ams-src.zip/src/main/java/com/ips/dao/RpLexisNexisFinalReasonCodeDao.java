package com.ips.dao;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.ips.entity.RefOtpReasonCode;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RpLexisNexisFinalReasonCode;

public interface RpLexisNexisFinalReasonCodeDao {

    RpLexisNexisFinalReasonCode getById(Long id);
    void save(RpLexisNexisFinalReasonCode reasonCode);
    void update(RpLexisNexisFinalReasonCode reasonCode);
    void delete(RpLexisNexisFinalReasonCode reasonCode);
    Collection<RefOtpReasonCode> getLexisNegativeReasons(Date start, Date end, RefLoaLevel loa);
    Long getReasonCodeCount(Date start, Date end, String reasonCode, RefLoaLevel loa);
    List<RpLexisNexisFinalReasonCode> getReasonCodesByEvent(long eventId);
}
