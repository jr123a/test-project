package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefMatchLevel;

public interface PhoneMatchLevelDao {
    Collection<RefMatchLevel> getAll();    
    RefMatchLevel getById(Long id);
    void save(RefMatchLevel entity);
    void update(RefMatchLevel entity);
    void delete(RefMatchLevel entity);
    RefMatchLevel getMatchLevelByName(String name);
}
