package com.ips.dao.impl;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.LookupCodesEnvDao;
import com.ips.entity.LookupCodesEnv;
import com.ips.entity.LookupCodesEnvPK;

@Repository
public class LookupCodesEnvDaoImpl extends GenericJPADAO<LookupCodesEnv, String> implements LookupCodesEnvDao {

    @SuppressWarnings("unchecked")
    @Override
    public LookupCodesEnv getValueByEnvironment(String env, String name) {
        Query query = em.createNativeQuery("Select * from lookup_codes_env where ENV=? AND NAME=?");
        query.setParameter(1, env);
        query.setParameter(2, name);
        List<Object[]> codes = query.getResultList();

        if (codes.isEmpty()) {
            return null;
        } else {
            LookupCodesEnv lookup = new LookupCodesEnv();
            
            Object[] obj = codes.get(0);
            
            LookupCodesEnvPK id = new LookupCodesEnvPK();
            id.setEnv(obj[0] != null ? (String) obj[0] : "");
            id.setName(obj[1] != null ? (String) obj[1] : "");
            lookup.setId(id);
            lookup.setValue(obj[2] != null ? (String) obj[2] : "");
            lookup.setCreateDate(obj[4] != null ? (Timestamp) obj[4] : null);
            lookup.setUpdateDate(obj[5] != null ? (Timestamp) obj[5] : null);
            lookup.setCreateUser(obj[6] != null ? (String) obj[6] : "");
            lookup.setUpdateUser(obj[7] != null ? (String) obj[7] : "");
            return lookup;
        }
    }

    @Override
    public void updateEnvValueByEnvironment(String env, String selectedVendorName, String urlValue,String userId) {

        Query query = em.createNativeQuery("Update lookup_codes_env set value=? , update_user=? where ENV=? AND NAME=?");
        query.setParameter(1, urlValue);
        query.setParameter(2, userId);
        query.setParameter(3, env);
        query.setParameter(4, selectedVendorName);
        query.executeUpdate();
    }

}
