package com.ips.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.common.common.CustomLogger;
import com.ips.dao.ApplicationWorkflowsDao;
import com.ips.entity.ApplicationWorkflows;

@Repository
public class ApplicationWorkflowsDaoImpl extends GenericJPADAO<ApplicationWorkflows, Long>
        implements ApplicationWorkflowsDao,Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public List<ApplicationWorkflows> list() {
        List<ApplicationWorkflows> list = null;
        try {
            Query query = em.createNamedQuery("ApplicationWorkflows.findAll");

            list = query.getResultList();
            if (list == null) {
                list = new ArrayList<>();
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception getting ApplicationWorkflows data", e);
        }

        return list;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ApplicationWorkflows> getWorkflowCombo(long acr, long device, long sponsor, long workflow) {
        List<ApplicationWorkflows> list = null;
        try {
            Query query = em.createNamedQuery("ApplicationWorkflows.findWorkflow");
            query.setParameter("acr", acr);
            query.setParameter("device", device);
            query.setParameter("sponsor", sponsor);
            query.setParameter("workflow", workflow);
            
            list = query.getResultList();
            if (list == null) {
                list = new ArrayList<>();
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception getting getWorkflowCombo data", e);
        }

        return list;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ApplicationWorkflows> getWorkflowsByAppDeviceLoaCodeSponsor(long appID, long deviceID, long loaCode, long sponsorId) {
        Query query = em.createNamedQuery("ApplicationWorkflows.findByApplicationDeviceLoaCodeSponsor");
        query.setParameter("appID", appID);
        query.setParameter("device", deviceID);
        query.setParameter("loaCode", loaCode);
        query.setParameter("sponsorId", sponsorId);
        
        List<ApplicationWorkflows> results= query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } else {
            return results;
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public ApplicationWorkflows getWorkflowFromId(long workflowId) {
        List<ApplicationWorkflows> list = new ArrayList<>();
        try {
            Query query = em.createNamedQuery("ApplicationWorkflows.findById");
            query.setParameter("id", workflowId);
            list = query.getResultList();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception getting getWorkflowFromId data", e);
        }

        return list.get(0);
    }

    @Override
    public ApplicationWorkflows merge(ApplicationWorkflows apps) {
        super.merge(apps);
        return apps;
        
    }
    
    @Override
    public void delete(ApplicationWorkflows apps) {
        super.delete(apps);
    }
    
    @Override
    public List<ApplicationWorkflows> findApplicationWorkflowsBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<ApplicationWorkflows> list = em.createNamedQuery("ApplicationWorkflows.findApplicationWorkflowsBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }

}
