package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpAmsResponse;


public interface RpAmsResponseDao {

    Collection<RpAmsResponse> getAll();    
    RpAmsResponse getById(Long id);
    void create(RpAmsResponse entity);
    void update(RpAmsResponse entity);
    List<RpAmsResponse> getListByPersonId(long personId);
    RpAmsResponse getByPersonId(long personId);
 }
