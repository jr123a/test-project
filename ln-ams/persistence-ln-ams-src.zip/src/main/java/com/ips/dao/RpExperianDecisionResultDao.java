package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpExperianDecisionResult;

public interface RpExperianDecisionResultDao {

    Collection<RpExperianDecisionResult> getAll();    
    RpExperianDecisionResult getById(Long id);
    void create(RpExperianDecisionResult entity);
    void update(RpExperianDecisionResult entity);
    List<RpExperianDecisionResult> getListByPersonId(long personId);
    List<RpExperianDecisionResult> getListByEventId(long eventId);
    RpExperianDecisionResult getByPersonId(long personId);
    RpExperianDecisionResult getByEventId(long eventId);
}
