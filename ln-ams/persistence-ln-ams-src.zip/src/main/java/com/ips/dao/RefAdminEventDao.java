package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefAdminEvent;

public interface RefAdminEventDao {

    Collection<RefAdminEvent> getAll();    
    RefAdminEvent getById(Long id);
    void save(RefAdminEvent refAdminEvent);
    void update(RefAdminEvent refAdminEvent);
    void delete(RefAdminEvent refAdminEvent);
    RefAdminEvent getByDescription(String eventDescription);
}
