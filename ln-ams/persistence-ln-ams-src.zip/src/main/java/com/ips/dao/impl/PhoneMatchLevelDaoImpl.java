package com.ips.dao.impl;

import java.util.Collection;

import javax.persistence.Query;
import org.springframework.stereotype.Repository;

import com.ips.dao.PhoneMatchLevelDao;
import com.ips.entity.RefMatchLevel;

@Repository
public class PhoneMatchLevelDaoImpl extends GenericJPADAO<RefMatchLevel,String> implements PhoneMatchLevelDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefMatchLevel> getAll() {
        Query query = em.createNamedQuery("RefMatchLevel.findAll");
        return query.getResultList();
    }

    @Override
    public RefMatchLevel getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void save(RefMatchLevel entity) {
        super.save(entity);
    }

    @Override
    public void update(RefMatchLevel entity) {
        super.merge(entity);
        em.flush();
    }

    @Override
    public void delete(RefMatchLevel entity) {
        super.delete(entity);
    }

    @Override
    public RefMatchLevel getMatchLevelByName(String name) {
        Query query = em.createNamedQuery("RefMatchLevel.findByName");
        query.setParameter("name", name);
        
        if (query.getResultList() == null || query.getResultList().isEmpty()) {
            return null;
        } else {
            return (RefMatchLevel) query.getResultList().get(0);
        }
    }

}
