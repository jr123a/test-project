package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpAllVerificationResults;


public interface RpAllVerificationResultsDao {

    Collection<RpAllVerificationResults> getAll();    
    RpAllVerificationResults getById(Long id);
    void create(RpAllVerificationResults entity);
    void update(RpAllVerificationResults entity);
    List<RpAllVerificationResults> getListByBypersonId(long personId);
    RpAllVerificationResults getByPersonId(long personId);

}
