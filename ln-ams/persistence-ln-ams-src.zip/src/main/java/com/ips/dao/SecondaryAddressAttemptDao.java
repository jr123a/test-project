package com.ips.dao;

import com.ips.entity.SecondaryAddressAttempt;

public interface SecondaryAddressAttemptDao {

    void save(SecondaryAddressAttempt attempt);
    void update(SecondaryAddressAttempt attempt);
    SecondaryAddressAttempt getById(Long id);
}
