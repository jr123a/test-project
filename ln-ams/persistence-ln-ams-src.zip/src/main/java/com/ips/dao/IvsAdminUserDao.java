package com.ips.dao;

import java.util.Collection;

import com.ips.entity.IvsAdminUser;

public interface IvsAdminUserDao {
    
    Collection<IvsAdminUser> getAll();
    IvsAdminUser getByUserId(String userId);
    void save(IvsAdminUser user);
    void update(IvsAdminUser user);
    void delete(IvsAdminUser user);
    Collection<IvsAdminUser> getOtherAdmins(String userId);
}
