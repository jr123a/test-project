package com.ips.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.VendorAPIDao;
import com.ips.entity.VendorAPI;


@Repository
public class VendorAPIDaoImpl extends GenericJPADAO<VendorAPI, Long> implements
    VendorAPIDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Override
    public void update(VendorAPI app) {
        super.merge(app);
    }

    @SuppressWarnings("unchecked")
    @Override
    public VendorAPI getByName(String name) {
        Query query = em.createNamedQuery("VendorAPI.findByName");
        query.setParameter("name", name);
        List<VendorAPI> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }        
    }

}

