package com.ips.dao;

import java.sql.Timestamp;
import java.util.List;

import com.ips.entity.RpSmfaAttempt;


public interface RpSmfaAttemptDao {

    List<RpSmfaAttempt> getSmfaAttemptsListInWindow(long personId, Timestamp window, Timestamp currentTime, long smfaSupplierId, long rpEventId);
    List<RpSmfaAttempt> getSmfaAttemptsListInWindow(long personId, long supplierId, int attemptWindow, long rpEventId);
    List<RpSmfaAttempt> getSmfaAttemptsInTransaction(long personId, long smfaSupplierId, String transactionKey);
    RpSmfaAttempt getSmfaAttemptBySessionId(String sessionId);
}
