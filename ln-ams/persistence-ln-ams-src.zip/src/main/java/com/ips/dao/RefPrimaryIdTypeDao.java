package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RefPrimaryIdType;
import com.ips.entity.RefSecondaryIdType;


public interface RefPrimaryIdTypeDao {

    Collection<RefPrimaryIdType> getAll();    
    Collection<RefPrimaryIdType> getAvailableStrongList(Long sponsorId);
    Collection<RefPrimaryIdType> getSponsorStrongList(Long sponsorId);
    Collection<RefPrimaryIdType> getAllStrongList();
    RefPrimaryIdType getById(Long id);
    void save(RefPrimaryIdType entity);
    void update(RefPrimaryIdType entity);
    void delete(RefPrimaryIdType entity);
    String getDescription(int idType);
    List<RefPrimaryIdType> getAvailableIdList(String value);
    List<RefPrimaryIdType> getSponsorAcceptedIdTypeList(String value);    
    List<RefSecondaryIdType> getAvailableSecondaryIdList(String value);
    List<RefSecondaryIdType> getSponsorAcceptedSecondaryIdTypeList(String value);
}
