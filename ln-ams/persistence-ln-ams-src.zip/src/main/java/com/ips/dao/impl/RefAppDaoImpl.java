package com.ips.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;

import javax.persistence.NamedQuery;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefAppDao;
import com.ips.entity.RefApp;


@Repository
public class RefAppDaoImpl extends GenericJPADAO<RefApp, Long> implements
        RefAppDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefApp> getAll() {        
        Query query = em.createNamedQuery("RefApp.findAll");
        return query.getResultList();
    }
    
    @Override
    public RefApp getById(Long id) {        
        return super.getById(id);
    }

    @Override
    public void update(RefApp app) {
        super.merge(app);
        em.flush();
    }

    @SuppressWarnings("unchecked")
    @Override
    public RefApp getByAppName(String appName) {
        Query query = em.createNamedQuery("RefApp.findByAppName");
        query.setParameter("appName", appName);
        List<RefApp> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RefApp getByAppId(Long appId) {
        Query query = em.createNamedQuery("RefApp.findByAppId");
        query.setParameter("appId", appId);
        List<RefApp> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefApp> getAppListByIdList(List<Long> appIdList) { 
        Query query = em.createNamedQuery("RefApp.findByAppIdList");
        query.setParameter("appIdList", appIdList);
         
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefApp> getAppListByCustomerCategoryId(long customerCategoryId) { 
        Query query = em.createNamedQuery("RefApp.getAppListByCustomerCategoryId");
        query.setParameter("customerCategoryId", customerCategoryId);
         
        return query.getResultList();
    }
    
	@SuppressWarnings("unchecked")
	@Override
	public Collection<RefApp> getModifiableList() {
		String sql = "select ra.app_id from ips_own.ref_app ra where ra.app_id > 3 "
				+ "and ra.app_id not in (select distinct am.app_id from ips_own.sponsor_application_map am) "
				+ "and ra.app_id not in (select distinct ip.transaction_origin_id from ips_own.ipp_event ip where ip.transaction_origin_id > 3) "
				+ "and ra.app_id not in (select distinct rp.transaction_origin_id from ips_own.rp_event rp where rp.transaction_origin_id > 3)";
		
		Query query = em.createNativeQuery(sql, RefApp.class);

		return query.getResultList();
	}
	
	@Override
    public boolean applicationModifiable(Long appId) {
		
		 if (applicationNotRegularApp(appId) && applicationNotReferencedInSponsorAppMap(appId) && 
				 applicationNotReferencedInIppEvent(appId) && applicationNotReferencedInRpEvent(appId)) {
			 return true;
		 }
		 
		 return false;
	}
	
	@Override
    public boolean applicationNotRegularApp(Long appId) {
        Query query = em.createNativeQuery("SELECT COUNT(ra.app_id) FROM ips_own.ref_app ra WHERE ra.app_id > 3 AND ra.app_id = ?");
        query.setParameter(1, appId);
          
        @SuppressWarnings("unchecked")
		List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return false;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue() > 0L;
        }
    }
	
	@Override
    public boolean applicationNotReferencedInSponsorAppMap(Long appId) {
        Query query = em.createNativeQuery("SELECT COUNT(ra.app_id) FROM ips_own.ref_app ra " +
        		"WHERE ra.app_id NOT IN (SELECT DISTINCT am.app_id FROM ips_own.sponsor_application_map am) AND ra.app_id = ?");
        query.setParameter(1, appId);
          
        @SuppressWarnings("unchecked")
		List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return false;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue() > 0L;
        }
    }
    
	@SuppressWarnings("unchecked")
	@Override
    public boolean applicationNotReferencedInIppEvent(Long appId) {
        Query query = em.createNativeQuery("SELECT COUNT(ra.app_id) FROM ips_own.ref_app ra " +
        		"WHERE ra.app_id not in (SELECT DISTINCT ip.transaction_origin_id FROM ips_own.ipp_event ip WHERE ip.transaction_origin_id > 3) AND ra.app_id = ?");
        query.setParameter(1, appId);
          
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return false;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue() > 0L;
        }
    }
    
	@SuppressWarnings("unchecked")
	@Override
    public boolean applicationNotReferencedInRpEvent(Long appId) {
        Query query = em.createNativeQuery("SELECT COUNT(ra.app_id) FROM ips_own.ref_app ra " +
        		"WHERE ra.app_id not in (SELECT DISTINCT rp.transaction_origin_id FROM ips_own.rp_event rp WHERE rp.transaction_origin_id > 3) AND ra.app_id = ?");
        query.setParameter(1, appId);
          
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return false;
        } 
        else {
            BigDecimal count = results.get(0);
            return count.longValue() > 0L;
        }
    }

}

