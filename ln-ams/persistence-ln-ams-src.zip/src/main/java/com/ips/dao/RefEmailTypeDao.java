package com.ips.dao;

import java.util.List;

import com.ips.entity.RefEmailType;

public interface RefEmailTypeDao {
    public List<RefEmailType> getAllTypes();
    public RefEmailType getByPK(Long id);
}
