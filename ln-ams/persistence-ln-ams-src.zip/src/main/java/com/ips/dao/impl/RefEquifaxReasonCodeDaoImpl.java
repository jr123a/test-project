package com.ips.dao.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefEquifaxReasonCodeDao;
import com.ips.entity.RefOtpReasonCode;

@Repository
public class RefEquifaxReasonCodeDaoImpl extends GenericJPADAO<RefOtpReasonCode, String> implements
        RefEquifaxReasonCodeDao {

    @Override
    public Collection<RefOtpReasonCode> retrieveLNCodes(
            List<String> list) {
        List<RefOtpReasonCode> results = new ArrayList<RefOtpReasonCode>();
        for(int i = 0; i < list.size(); i++){
            results.add(getById(list.get(i)));
        }
        return results;
    }


}
