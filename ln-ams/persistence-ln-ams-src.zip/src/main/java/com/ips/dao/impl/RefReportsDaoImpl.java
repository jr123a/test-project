package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefReportsDao;
import com.ips.entity.RefReports;

@Repository
public class RefReportsDaoImpl extends GenericJPADAO<RefReports, Long> implements RefReportsDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefReports> getAll() {        
        Query query = em.createNamedQuery("RefReports.findAll");
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RefReports> findBySponsor(long sponsorId) {        
        Query query = em.createNamedQuery("RefReports.findBySponsor");
        query.setParameter("sponsorId", sponsorId);
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
	@Override
    public List<RefReports> findForIppClientActiveSponsor() {        
        Query query = em.createNamedQuery("RefReports.findForIppClientActiveSponsor");
         return query.getResultList();
    }
    
    @Override
    public RefReports getById(Long id) {        
        return super.getById(id);
    }

    @Override
    public void update(RefReports entity) {
        super.merge(entity);
    }

}
