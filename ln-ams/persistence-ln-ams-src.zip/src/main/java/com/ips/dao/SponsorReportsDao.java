package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.SponsorReports;

public interface SponsorReportsDao {

    Collection<SponsorReports> getAll();    
    SponsorReports getById(Long id);
    SponsorReports getBySponsorAndReportIds(long sponsorId, long reportId);
    void create(SponsorReports entity);
    void update(SponsorReports entity);
    void delete(SponsorReports entity);
    List<SponsorReports> findSponsorReportsBySponsor(long sponsorId);
}
