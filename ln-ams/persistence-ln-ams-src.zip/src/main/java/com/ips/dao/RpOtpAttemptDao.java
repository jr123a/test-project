package com.ips.dao;

import java.sql.Timestamp;
import java.util.List;

import com.ips.entity.RpOtpAttempt;

public interface RpOtpAttemptDao {

    List<RpOtpAttempt> getOtpAttemptListInWindow(long personId, Timestamp window, Timestamp currentTime,
            long otpSupplierId, long rpEventId, String attemptType);  
    List<RpOtpAttempt> getOtpRequestAndConfirmAttemptListInWindow(long personId, Timestamp window, Timestamp currentTime,
            long otpSupplierId, long rpEventId);
    List<RpOtpAttempt> getOtpAttemptInTransaction(long personId, long otpSupplierId, String transactionKey, String attemptType);
    List<RpOtpAttempt> getOtpAttemptListInWindow(long personId, long supplierId, int attemptWindow, long rpEventId);
    RpOtpAttempt getLatestOtpConfirmAttempt(long personId, long otpSupplierId, long rpEventId);
    RpOtpAttempt getLatestOtpAttempt(long personId, long otpSupplierId, long rpEventId);
    RpOtpAttempt getLatestOtpRequestAttempt(long personId, long otpSupplierId, long rpEventId);
    RpOtpAttempt getLatestOtpAttemptByEventId(long rpEventId);
 
}
