package com.ips.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpWorkflowApiDecisionDao;
import com.ips.entity.RpWorkflowApiDecision;
import com.ips.persistence.common.DeviceReputationVo;
import com.ips.persistence.common.WorkflowApiDecisionVo;

@Repository
@Transactional
public class RpWorkflowApiDecisionDaoImpl extends GenericJPADAO<RpWorkflowApiDecision, Long> implements RpWorkflowApiDecisionDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpWorkflowApiDecision> getAll() {        
        Query query = em.createNamedQuery("RpWorkflowApiDecision.getAll");
        return query.getResultList();
    }

    @Override
    public RpWorkflowApiDecision getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpWorkflowApiDecision entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpWorkflowApiDecision entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpWorkflowApiDecision entity) {
        super.save(entity);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpWorkflowApiDecision getByWorkflowApiTypeId(long workflowApiTypeId) {
        Query query = em.createNamedQuery("RpWorkflowApiDecision.getByWorkflowApiTypeId");
        query.setParameter("workflowApiTypeId", workflowApiTypeId);
        List<RpWorkflowApiDecision> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);    
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RpWorkflowApiDecision> getListByEventId(long eventId) {
        Query query = em.createNamedQuery("RpWorkflowApiDecision.getListByEventId");
        query.setParameter("eventId", eventId);
       
        return query.getResultList();    
    }

    @Transactional
    @Override
	public boolean executeCreateNativeQuery(String nativeQuery)  {
		try {
			Query updateQuery = em.createNativeQuery(nativeQuery);
			updateQuery.executeUpdate();
				
			Query commitQuery = em.createNativeQuery("COMMIT");
			commitQuery.executeUpdate();
			

			return true;
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Database error occurred during createNativeQuery update execution.", e);
			return false;
		}
	}
    
    @Override
	public List<WorkflowApiDecisionVo>  getWorkflowApiDecisionList(String startDate, String endDate, String countType)  {
       	String nativeSql = "";
 
       	if ("ByEvent".equalsIgnoreCase(countType)) {
       		nativeSql = "SELECT SUM(EVENT_COUNT) AS COUNT_SUM,  WORKFLOW_API_TYPE_ID, DECISION, DECISION_SOURCE, "
       				+ "KBA_SUPPLIER_ID, TRANSACTION_ORIGIN_ID FROM ("
       				+ "SELECT COUNT(d.EVENT_ID) as EVENT_COUNT, d.EVENT_ID, d.WORKFLOW_API_TYPE_ID, d.DECISION, d.DECISION_SOURCE, "
       				+ "e.KBA_SUPPLIER_ID, e.TRANSACTION_ORIGIN_ID FROM IPS_OWN.RP_WORKFLOW_API_DECISION d "
       				+ "LEFT JOIN IPS_OWN.RP_EVENT e ON e.EVENT_ID = d.EVENT_ID WHERE d.CREATE_DATE BETWEEN TO_DATE(?, 'dd-mon-yyyy hh24:mi:ss') "
       				+ "AND TO_DATE(?,'dd-mon-yyyy hh24:mi:ss') "
       				+ "GROUP BY d.EVENT_ID, d.DECISION, d.WORKFLOW_API_TYPE_ID, d.DECISION, d.DECISION_SOURCE, "
       				+ "e.KBA_SUPPLIER_ID, e.TRANSACTION_ORIGIN_ID) "
       				+ "GROUP BY WORKFLOW_API_TYPE_ID, DECISION, DECISION_SOURCE, KBA_SUPPLIER_ID, TRANSACTION_ORIGIN_ID "
       				+ "ORDER BY TRANSACTION_ORIGIN_ID, WORKFLOW_API_TYPE_ID, DECISION, DECISION_SOURCE, KBA_SUPPLIER_ID ";
       	} else if ("ByPerson".equalsIgnoreCase(countType)) {
       		nativeSql = "SELECT SUM(PERSON_COUNT) AS COUNT_SUM, WORKFLOW_API_TYPE_ID, DECISION, DECISION_SOURCE, "
       				+ "KBA_SUPPLIER_ID, TRANSACTION_ORIGIN_ID FROM (SELECT COUNT(e.PERSON_ID) as PERSON_COUNT, e.PERSON_ID, d.WORKFLOW_API_TYPE_ID, d.DECISION, " 
       				+ "d.DECISION_SOURCE, e.KBA_SUPPLIER_ID, e.TRANSACTION_ORIGIN_ID FROM IPS_OWN.RP_WORKFLOW_API_DECISION d LEFT JOIN RP_EVENT e on e.EVENT_ID = d.EVENT_ID "
       				+ "WHERE d.CREATE_DATE BETWEEN TO_DATE(?, 'dd-mon-yyyy hh24:mi:ss') "
       				+ "AND TO_DATE(?,'dd-mon-yyyy hh24:mi:ss') "
       				+ "GROUP BY e.PERSON_ID, d.WORKFLOW_API_TYPE_ID, d.DECISION, d.DECISION_SOURCE, e.KBA_SUPPLIER_ID, e.TRANSACTION_ORIGIN_ID) "
       				+ "GROUP BY WORKFLOW_API_TYPE_ID, DECISION, DECISION, DECISION_SOURCE, KBA_SUPPLIER_ID, TRANSACTION_ORIGIN_ID "
       				+ "ORDER BY TRANSACTION_ORIGIN_ID, WORKFLOW_API_TYPE_ID, DECISION, DECISION_SOURCE";
       		
       	} else {
       		return null;
       	}

       	ArrayList<WorkflowApiDecisionVo> list = new ArrayList<>();
       	
		try {
			Query query = em.createNativeQuery(nativeSql)
			.setParameter(1, startDate)
			.setParameter(2, endDate);
			
				
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = query.getResultList();

            for (Object[] item : resultList) {
            	WorkflowApiDecisionVo vo = new WorkflowApiDecisionVo();
            	String countSumStr = String.valueOf((BigDecimal) item[0]);
            	String workflowApiTypeIdStr = String.valueOf((BigDecimal) item[1]);
            	String decisionStr = ((String) item[2]);
            	String decisionSourceStr = ((String) item[3]);
            	String kbaSupplierIdStr = String.valueOf((BigDecimal) item[4]);
            	String transactioOriginIdStr = String.valueOf((BigDecimal) item[5]);
             	
            	String recordKeyStr = "";
            	if ("2".equals(workflowApiTypeIdStr) || "3".equals(workflowApiTypeIdStr) || "7".equals(workflowApiTypeIdStr) 
            			|| "8".equals(workflowApiTypeIdStr) || "9".equals(workflowApiTypeIdStr)) {
            		recordKeyStr = String.format("%s%s%s%s", transactioOriginIdStr, workflowApiTypeIdStr, decisionStr, decisionSourceStr );
            	} else {
            		recordKeyStr = String.format("%s%s%s%s%s", transactioOriginIdStr, workflowApiTypeIdStr, kbaSupplierIdStr, decisionStr, decisionSourceStr );
            	}
            	
            	vo.setCountSum(countSumStr);
            	vo.setWorkflowApiTypeId(workflowApiTypeIdStr);
            	vo.setDecision(decisionStr);
            	vo.setDecisionSource(decisionSourceStr);
            	vo.setRecordKey(recordKeyStr);
            	
                list.add(vo);
            }
   
       } catch (Exception ex) {
           CustomLogger.error(this.getClass(), "Error in getting  WorkflowApiDecisionVo item list.",ex);
       } 
       
       return list;
	}

}
