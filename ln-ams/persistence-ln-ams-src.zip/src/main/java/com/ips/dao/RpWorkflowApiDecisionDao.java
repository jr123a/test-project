package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpWorkflowApiDecision;
import com.ips.persistence.common.WorkflowApiDecisionVo;

public interface RpWorkflowApiDecisionDao {

    Collection<RpWorkflowApiDecision> getAll();    
    RpWorkflowApiDecision getById(Long id);
    RpWorkflowApiDecision getByWorkflowApiTypeId(long workflowApiTypeId);
    void create(RpWorkflowApiDecision entity);
    void update(RpWorkflowApiDecision entity);
    List<RpWorkflowApiDecision> getListByEventId(long eventId);
    boolean executeCreateNativeQuery(String nativeQuery);
	List<WorkflowApiDecisionVo>  getWorkflowApiDecisionList(String startDate, String endDate, String countType);

}
