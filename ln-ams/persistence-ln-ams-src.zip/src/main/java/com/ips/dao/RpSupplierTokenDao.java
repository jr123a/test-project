package com.ips.dao;

import com.ips.entity.RpSupplierToken;

public interface RpSupplierTokenDao {
    void save(RpSupplierToken token);
    void update(RpSupplierToken token);
    void delete(RpSupplierToken token);
    RpSupplierToken getByCode(String code);
    RpSupplierToken getByType(String type);
    RpSupplierToken getByCodeAndType(String code, String type);
}
