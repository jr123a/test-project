package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RefApp;

public interface RefAppDao {

    Collection<RefApp> getAll();    
	Collection<RefApp> getModifiableList();
    Collection<RefApp> getAppListByIdList(List<Long> appIdList);
    Collection<RefApp> getAppListByCustomerCategoryId(long customerCategoryId);
    RefApp getById(Long id);
    void save(RefApp app);
    void update(RefApp app);
    void delete(RefApp app);
    RefApp getByAppName(String appName);
	RefApp getByAppId(Long appId);
    boolean applicationModifiable(Long appId);
    boolean applicationNotRegularApp(Long appId);
    boolean applicationNotReferencedInSponsorAppMap(Long appId);
    boolean applicationNotReferencedInIppEvent(Long appId);
    boolean applicationNotReferencedInRpEvent(Long appId);
}
