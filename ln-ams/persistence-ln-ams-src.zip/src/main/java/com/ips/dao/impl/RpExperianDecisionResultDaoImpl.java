package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpExperianDecisionResultDao;
import com.ips.entity.RpExperianDecisionResult;

@Repository
public class RpExperianDecisionResultDaoImpl extends GenericJPADAO<RpExperianDecisionResult, Long> implements RpExperianDecisionResultDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpExperianDecisionResult> getAll() {        
        Query query = em.createNamedQuery("RpExperianDecisionResult.getAll");
        return query.getResultList();
    }

    @Override
    public RpExperianDecisionResult getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpExperianDecisionResult entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpExperianDecisionResult entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpExperianDecisionResult entity) {
        super.persist(entity);        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpExperianDecisionResult> getListByPersonId(long personId) {
        Query query = em.createNamedQuery("RpExperianDecisionResult.getListByPersonId");
        query.setParameter("personId", personId);
        
        return query.getResultList();   
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpExperianDecisionResult> getListByEventId(long eventId) {
        Query query = em.createNamedQuery("RpExperianDecisionResult.getListByEventId");
        query.setParameter("eventId", eventId);
        
        return query.getResultList();   
    }
    
    @Override
    public RpExperianDecisionResult getByPersonId(long personId) {
        List<RpExperianDecisionResult> results = getListByPersonId(personId);
        
        return results.isEmpty()? null : results.get(0);    
    }
    
    @Override
    public RpExperianDecisionResult getByEventId(long eventId) {
        List<RpExperianDecisionResult> results = getListByEventId(eventId);
        
        return results.isEmpty()? null : results.get(0);    
    }
}
