package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.ips.dao.RefSecondaryIdTypeDao;
import com.ips.entity.RefSecondaryIdType;

@Repository
public class RefSecondaryIdTypeDaoImpl extends GenericJPADAO<RefSecondaryIdType, Long> implements
        RefSecondaryIdTypeDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefSecondaryIdType> getAll() {
        Query query = em.createNamedQuery("RefSecondaryIdType.findAll");
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefSecondaryIdType> getAvailableFairList(Long sponsorId) {        
        Query query = em.createNamedQuery("RefSecondaryIdType.findAvailableFairList").setParameter("sponsorId", sponsorId);
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefSecondaryIdType> getSponsorFairList(Long sponsorId) {        
        Query query = em.createNamedQuery("RefSecondaryIdType.findSponsorFairList").setParameter("sponsorId", sponsorId);
        return query.getResultList();
    }
    
    @Override
    public RefSecondaryIdType getById(Long id) {        
        return super.getById(id);
    }

    @Override
    public void update(RefSecondaryIdType entity) {
        super.merge(entity);
    }

    @SuppressWarnings("unchecked")
    @Override
    public String getDescription(int idType) {
        Query query = em.createNamedQuery("RefSecondaryIdType.getDescription");
        query.setParameter("idType", idType);
        List<String> result =  query.getResultList();
        if(!result.isEmpty()) {
            return result.get(0);
        }
        return StringUtils.EMPTY;
    }
}
