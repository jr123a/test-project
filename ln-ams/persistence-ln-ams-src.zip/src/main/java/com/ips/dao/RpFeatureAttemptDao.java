package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RpFeatureAttempt;

public interface RpFeatureAttemptDao {
    RpFeatureAttempt getById(long id);
    void create(RpFeatureAttempt featureAttempt);
    void update(RpFeatureAttempt featureAttempt);
    void delete(RpFeatureAttempt featureAttempt);
    Collection<RpFeatureAttempt> getListBySponsorId(long sponsorId);
    Collection<RpFeatureAttempt> getListByAppId(long appId);
    Collection<RpFeatureAttempt> getBySponsorAndAppId(long sponsorId, long appId);
    RpFeatureAttempt findBySponsorIdAndFeatureName(long sponsorId, String featureName);
    RpFeatureAttempt findByAppIdAndFeatureName(long appId, String featureName);
    long getMaxConfigId();
 }
