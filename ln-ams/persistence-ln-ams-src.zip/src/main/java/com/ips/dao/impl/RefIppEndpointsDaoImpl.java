package com.ips.dao.impl;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefIppEndpointsDao;
import com.ips.entity.RefIppEndpoints;

import java.util.List;

@Repository
public class RefIppEndpointsDaoImpl extends GenericJPADAO<RefIppEndpoints, Long> implements RefIppEndpointsDao {
    @SuppressWarnings("unchecked")
    @Override
    public RefIppEndpoints findByEndpointName(String endpointName) {
        List<RefIppEndpoints> endpoint = em.createNamedQuery("RefIppEndpoints.findByEndpointName")
                                           .setParameter("endpointName", endpointName).getResultList();
        return endpoint.isEmpty() ? null : endpoint.get(0);
    }
}
