package com.ips.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.HighRiskAddressDao;
import com.ips.entity.HighRiskAddress;
import com.ips.entity.RefHighRiskAddressType;
import com.ips.persistence.common.HighRiskAddressVo;

@Repository
public class HighRiskAddressDaoImpl extends GenericJPADAO<HighRiskAddress, Long> implements HighRiskAddressDao {    
    
    public static final int ADDRESS = 0;
    public static final int ADDRESS_LINE_2 = 1;
    public static final int CITY = 2;
    public static final int STATE = 3;
    public static final int ZIP = 4;
    public static final int ZIP_11 = 5;
    public static final int DATE_TIME_ADDED_INTO_LIST = 6;
    public static final int PERSON_ID = 7;
    public static final int CRID = 8;
    public static final int SPONSOR = 9; 
    
    public static final int DATE_TIME_TO_DIRECT_IPP = 10;
    public static final int DATE_TIME_TO_BE_CHECKED = 10;

    public static final int DATE_TIME_TO_OPT_IN_IPP = 11;
    public static final int DATE_TIME_TO_START_REMOTE_PROOFING = 11; 
     
    public static final int DATE_TIME_TO_GO_TO_POST_OFFICE = 12;
    public static final int SUPPLIER = 12; 
     
    public static final int STATUS = 13; 
    public static final int RP_STATUS = 13;
    
    public static final int FAILURE_REASON_IF_FAILED = 14;
    public static final int TRANSACTION_KEY = 14; 
    
    public static final int IS_FRAUD = 15;    
    
    private static final String BIG_DECIMAL = "BigDecimal"; 
    private static final String DDMMYYYY_HHMMSS_A = "dd-MMM-yyyy hh:mm:ss a";

    @SuppressWarnings("unchecked")
    public HighRiskAddress findHighRiskAddress(int addressHash) {
        Query query = em.createNamedQuery("HighRiskAddress.findByHash").setParameter("hash", addressHash);
        List<HighRiskAddress> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }

    @SuppressWarnings("unchecked")
    public HighRiskAddress findHighRiskAddressByAddress(String address, String city, String state, String zip) {
        Query query = em.createNamedQuery("HighRiskAddress.findByAddress")
        	.setParameter("address", address)
            .setParameter("city", city)
            .setParameter("state", state)
            .setParameter("zip", zip);
        List<HighRiskAddress> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    public RefHighRiskAddressType findRefHighRiskAddressTypeByTypeId(long typeId) {
        Query query = em.createNamedQuery("RefHighRiskAddressType.findByTypeId")
        	.setParameter("typeId", typeId);

        List<RefHighRiskAddressType> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }
    
    @Transactional
    @Override
    public void update(HighRiskAddress highRiskAddress) {
         try {
            super.merge(highRiskAddress);
            em.flush();
         } catch (PersistenceException pe) {
             CustomLogger.error(this.getClass(), "Error in merging HighRiskAddress entity.  ", pe);
        }
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<HighRiskAddress> getAllPrimary() {
        Query query = em.createNamedQuery("HighRiskAddress.getAllPrimary");
           
        return query.getResultList();  
    }
  
    @SuppressWarnings("unchecked")
    @Override
    public List<HighRiskAddressVo> getPrimaryReport(long sponsorId) { 
        StringBuilder sqlSb =  new StringBuilder();
        sqlSb.append("SELECT b.ADDRESS,b.ADDRESS_LINE_2,b.CITY,b.STATE,b.ZIP,b.ZIP_11, TO_CHAR(b.ADDED_DATETIME, 'YYYY-MM-DD HH.MI.SS') DateTimeAddedintoList, "); 
        sqlSb.append("a.PERSON_ID,c.SPONSOR_USER_ID CRID, e.sponsor_name SPONSOR, TO_CHAR(a.Attempt_datetime, 'YYYY-MM-DD HH.MI.SS') DateTimeToDirectIPP,d.CREATE_DATE DateTimeToOptinIPP, ");
        sqlSb.append("d.TRANSACTION_START_DATETIME DateTimeToGoToPostOffice ");
        sqlSb.append("FROM IPS_OWN.HIGH_RISK_ADDRESS_ATTEMPTS a, IPS_OWN.HIGH_RISK_ADDRESSES b, IPS_OWN.PERSON c, IPS_OWN.IPP_EVENT d, IPS_OWN.REF_SPONSOR e ");
        sqlSb.append("WHERE a.High_risk_address_id=b.High_risk_address_id AND a.person_id=c.person_id AND c.sponsor_id = e.sponsor_id AND a.ipp_event_id=d.ipp_event_id (+) ");
        sqlSb.append("ORDER BY a.Attempt_datetime");     
          
        Query query = em.createNativeQuery(sqlSb.toString());             
            
            List<Object[]> results = query.getResultList();
            List<HighRiskAddressVo> list = new ArrayList<>();
            
            if (!results.isEmpty()) {
                for (Object[] row: results) {
                    HighRiskAddressVo highRiskAddressvo = new HighRiskAddressVo(); 
                    
                    for (int columnIndex=0; columnIndex<13; columnIndex++) { 
                        switch (columnIndex) { 
                        case ADDRESS:
                            highRiskAddressvo.setAddress((String)row[0]);
                            break; 
                        case ADDRESS_LINE_2:
                            highRiskAddressvo.setAddressLineTwo((String)row[1]); 
                            break;         
                        case CITY:
                            highRiskAddressvo.setCity((String)row[2]);
                            break; 
                        case STATE:
                            highRiskAddressvo.setState((String)row[3]);
                            break; 
                        case ZIP:
                            highRiskAddressvo.setZip((String)row[4]);
                            break; 
                        case ZIP_11:
                            highRiskAddressvo.setZip11((String)row[5]);
                            break; 
                        case DATE_TIME_ADDED_INTO_LIST:
                            //ORACLE DATE 
                            highRiskAddressvo.setTimestampAddedIntoList((String)row[6]);
                            break; 
                        case PERSON_ID:
                            if (validateSQLObjectValue(BIG_DECIMAL, row[columnIndex])) { 
                                long personIdLongValue = ((BigDecimal)row[7]).longValue(); 
                                highRiskAddressvo.setPersonId(Long.toString(personIdLongValue));
                            }                            
                            break; 
                        case CRID: 
                            highRiskAddressvo.setCustRegId((String)row[8]);
                            break; 
                        case SPONSOR:
                        	highRiskAddressvo.setSponsor((String)row[9]);
                        	break; 
                        case DATE_TIME_TO_DIRECT_IPP:
                            //ORACLE DATE  
                            highRiskAddressvo.setTimestampWhenDirectedToIPP((String)row[10]);
                            break; 
                        case DATE_TIME_TO_OPT_IN_IPP:
                            //ORACLE TIMESTAMP 
                            Timestamp optInTimestamp = (Timestamp)row[11]; 
                            if (optInTimestamp != null) { 
                                LocalDateTime optInldt = optInTimestamp.toLocalDateTime();
                                DateTimeFormatter optInformatter = DateTimeFormatter.ofPattern(DDMMYYYY_HHMMSS_A);
                                String optInString = optInldt.format(optInformatter);   
                                highRiskAddressvo.setTimestampWhenOptInToIPP(optInString);
                            }     
                            break; 
                        case DATE_TIME_TO_GO_TO_POST_OFFICE:
                            //ORACLE TIMESTAMP 
                            Timestamp goToPostOfficeTimestamp = (Timestamp)row[12]; 
                            if (goToPostOfficeTimestamp != null) {
                                LocalDateTime goToPostOfficeLdt = goToPostOfficeTimestamp.toLocalDateTime();
                                DateTimeFormatter goToPostOfficeFormatter = DateTimeFormatter.ofPattern(DDMMYYYY_HHMMSS_A);
                                String goToPostOfficeDateString = goToPostOfficeLdt.format(goToPostOfficeFormatter);                 
                                highRiskAddressvo.setTimestampWhenGotToPostOffice(goToPostOfficeDateString);
                            }     
                            break;     
                        default:
                            break; 
                        }
                              
                    }
                    
                    list.add(highRiskAddressvo);
                }
            }
            
            return list;
    
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<HighRiskAddressVo> getPrimaryReportIPP(long sponsorId) {  
        StringBuilder sqlSb =  new StringBuilder();
        sqlSb.append("SELECT b.ADDRESS, b.ADDRESS_LINE_2, b.CITY, b.STATE, b.ZIP, b.ZIP_11, TO_CHAR(b.ADDED_DATETIME, 'YYYY-MM-DD HH.MI.SS') DateTimeAddedintoList, ");
        sqlSb.append("a.PERSON_ID, c.SPONSOR_USER_ID CRID, g.sponsor_name SPONSOR, TO_CHAR(a.Attempt_datetime, 'YYYY-MM-DD HH.MI.SS') DateTimeToDirectIPP, d.CREATE_DATE DateTimeToOptinIPP, ");
        sqlSb.append("d.TRANSACTION_START_DATETIME DateTimeToGoToPostOffice, e.EVENT_STATUS_DESCRIPTION Status, ");
        sqlSb.append("f.REASON_CODE_DESCRIPTION FailureReasonIffailed, d.FRAUD_SUSPECTED IsFraud ");
        sqlSb.append("FROM IPS_OWN.HIGH_RISK_ADDRESS_ATTEMPTS a, IPS_OWN.HIGH_RISK_ADDRESSES b, IPS_OWN.PERSON c, IPS_OWN.REF_SPONSOR g, ");
        sqlSb.append("IPS_OWN.IPP_EVENT d, IPS_OWN.REF_IPP_EVENT_STATUS e, IPS_OWN.REF_IPP_FAILURE_REASON f ");
        sqlSb.append("WHERE a.High_risk_address_id=b.High_risk_address_id AND a.person_id=c.person_id AND c.SPONSOR_ID=g.sponsor_id AND ");
        sqlSb.append("a.ipp_event_id=d.ipp_event_id (+) AND d.IPP_EVENT_STATUS=e.IPP_EVENT_STATUS (+) AND d.FAILURE_REASON_CODE=f.FAILURE_REASON_CODE(+) ");
        sqlSb.append("ORDER BY a.Attempt_datetime"); 
        
        Query query = em.createNativeQuery(sqlSb.toString()); 
            
            List<Object[]> results = query.getResultList();
            List<HighRiskAddressVo> list = new ArrayList<>();
            
            if (!results.isEmpty()) {
                for (Object[] row: results) {
                    HighRiskAddressVo highRiskAddressvo = new HighRiskAddressVo(); 
                    
                    for (int columnIndex=0; columnIndex<16; columnIndex++) { 
                        switch (columnIndex) { 
                        case ADDRESS:
                            highRiskAddressvo.setAddress((String)row[0]);
                            break; 
                        case ADDRESS_LINE_2:
                            highRiskAddressvo.setAddressLineTwo((String)row[1]); 
                            break;         
                        case CITY:
                            highRiskAddressvo.setCity((String)row[2]);
                            break; 
                        case STATE:
                            highRiskAddressvo.setState((String)row[3]);
                            break; 
                        case ZIP:
                            highRiskAddressvo.setZip((String)row[4]);
                            break; 
                        case ZIP_11:
                            highRiskAddressvo.setZip11((String)row[5]);
                            break; 
                        case DATE_TIME_ADDED_INTO_LIST:
                            //ORACLE DATE 
                            highRiskAddressvo.setTimestampAddedIntoList((String)row[6]);
                            break; 
                        case PERSON_ID:
                            if (validateSQLObjectValue(BIG_DECIMAL, row[columnIndex])) { 
                                long personIdLongValue = ((BigDecimal)row[7]).longValue(); 
                                highRiskAddressvo.setPersonId(Long.toString(personIdLongValue));
                            }                            
                            break; 
                        case CRID: 
                            highRiskAddressvo.setCustRegId((String)row[8]);
                            break; 
                        case SPONSOR:
                        	highRiskAddressvo.setSponsor((String)row[9]);
                        	break;                            
                        case DATE_TIME_TO_DIRECT_IPP:
                            //ORACLE DATE  
                            highRiskAddressvo.setTimestampWhenDirectedToIPP((String)row[10]);
                            break; 
                        case DATE_TIME_TO_OPT_IN_IPP:
                            //ORACLE TIMESTAMP 
                            Timestamp optInTimestamp = (Timestamp)row[11]; 
                            if (optInTimestamp != null) { 
                                LocalDateTime optInldt = optInTimestamp.toLocalDateTime();
                                DateTimeFormatter optInformatter = DateTimeFormatter.ofPattern(DDMMYYYY_HHMMSS_A);
                                String optInString = optInldt.format(optInformatter);   
                                highRiskAddressvo.setTimestampWhenOptInToIPP(optInString);
                            }     
                            break; 
                        case DATE_TIME_TO_GO_TO_POST_OFFICE:
                            //ORACLE TIMESTAMP 
                            Timestamp goToPostOfficeTimestamp = (Timestamp)row[12]; 
                            if (goToPostOfficeTimestamp != null) {
                                LocalDateTime goToPostOfficeLdt = goToPostOfficeTimestamp.toLocalDateTime();
                                DateTimeFormatter goToPostOfficeFormatter = DateTimeFormatter.ofPattern(DDMMYYYY_HHMMSS_A);
                                String goToPostOfficeDateString = goToPostOfficeLdt.format(goToPostOfficeFormatter);                 
                                highRiskAddressvo.setTimestampWhenGotToPostOffice(goToPostOfficeDateString);
                            }     
                            break; 
                        case STATUS: 
                            highRiskAddressvo.setIppStatus((String)row[13]); 
                            break; 
                        case FAILURE_REASON_IF_FAILED: 
                            highRiskAddressvo.setFailureReason((String)row[14]);
                            break;
                        case IS_FRAUD: 
                            highRiskAddressvo.setFraud((String)row[15]);
                            break;                             
                        default:
                            break; 
                        }
                              
                    }
                    
                    list.add(highRiskAddressvo);
                    
                }
            }
            
            return list;
    
    }    
    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<HighRiskAddressVo> getSecondaryReport(long sponsorId) {  
        StringBuilder sqlSb =  new StringBuilder();
        sqlSb.append("SELECT b.ADDRESS,b.ADDRESS_LINE_2,b.CITY,b.STATE,b.ZIP,b.ZIP_11, TO_CHAR(b.ADDED_DATETIME, 'YYYY-MM-DD HH.MI.SS') DateTimeAddedintoList, ");
        sqlSb.append("a.PERSON_ID,c.SPONSOR_USER_ID CRID, g.sponsor_name SPONSOR, TO_CHAR(a.Attempt_datetime, 'YYYY-MM-DD HH.MI.SS') DataTimeTobeChecked, ");
        sqlSb.append("d.create_date StartRP, f.KBA_SUPPLIER_NAME SUPPLIER,d.Final_DECISION RPStatus,e.TRANSACTION_KEY ");
        sqlSb.append("FROM IPS_OWN.SECONDARY_ADDRESS_ATTEMPTS a, IPS_OWN.HIGH_RISK_ADDRESSES b, IPS_OWN.PERSON c, ");
        sqlSb.append("IPS_OWN.RP_EVENT d, ips_own.ref_kba_supplier f, IPS_OWN.RP_OTP_ATTEMPTS e, IPS_OWN.REF_SPONSOR g ");
        sqlSb.append("WHERE a.High_risk_address_id=b.High_risk_address_id AND a.person_id=c.person_id AND c.sponsor_id=g.sponsor_id AND ");
        sqlSb.append("a.event_id=d.event_id (+) AND d.kba_supplier_id = f.kba_supplier_id AND a.event_id = e.event_id (+) "); 
        
        Query query = em.createNativeQuery(sqlSb.toString()); 
            
            List<Object[]> results = query.getResultList();
            List<HighRiskAddressVo> list = new ArrayList<>();
            
            if (!results.isEmpty()) {
                for (Object[] row: results) {
                    HighRiskAddressVo highRiskAddressvo = new HighRiskAddressVo(); 
                    
                    for (int columnIndex=0; columnIndex<15; columnIndex++) { 
                        switch (columnIndex) { 
                        case ADDRESS:
                            highRiskAddressvo.setAddress((String)row[0]);
                            break; 
                        case ADDRESS_LINE_2:
                            highRiskAddressvo.setAddressLineTwo((String)row[1]); 
                            break;         
                        case CITY:
                            highRiskAddressvo.setCity((String)row[2]);
                            break; 
                        case STATE:
                            highRiskAddressvo.setState((String)row[3]);
                            break; 
                        case ZIP:
                            highRiskAddressvo.setZip((String)row[4]);
                            break; 
                        case ZIP_11:
                            highRiskAddressvo.setZip11((String)row[5]);
                            break; 
                        case DATE_TIME_ADDED_INTO_LIST:
                            //ORACLE DATE 
                            highRiskAddressvo.setTimestampAddedIntoList((String)row[6]);
                            break; 
                        case PERSON_ID:
                            if (validateSQLObjectValue(BIG_DECIMAL, row[columnIndex])) { 
                                long personIdLongValue = ((BigDecimal)row[7]).longValue(); 
                                highRiskAddressvo.setPersonId(Long.toString(personIdLongValue));
                            }                            
                            break; 
                        case CRID: 
                            highRiskAddressvo.setCustRegId((String)row[8]);
                            break; 
                        case SPONSOR:
                        	highRiskAddressvo.setSponsor((String)row[9]);
                        	break;                               
                        case DATE_TIME_TO_BE_CHECKED:
                            //ORACLE DATE  
                            highRiskAddressvo.setDateTimeTobeChecked((String)row[10]);
                            break; 
                        case DATE_TIME_TO_START_REMOTE_PROOFING:  
                            //ORACLE TIMESTAMP 
                            Timestamp startRPTimestamp = (Timestamp)row[11]; 
                            if (startRPTimestamp != null) { 
                                LocalDateTime startRPldt = startRPTimestamp.toLocalDateTime();
                                DateTimeFormatter startRPformatter = DateTimeFormatter.ofPattern(DDMMYYYY_HHMMSS_A);
                                String startRPString = startRPldt.format(startRPformatter);   
                                highRiskAddressvo.setDateTimeToStartRemoteProofing(startRPString);
                                
                            }     
                            break; 
                        case SUPPLIER:
                            highRiskAddressvo.setSupplier((String)row[12]);  
                            break;                             
                        case RP_STATUS: 
                            highRiskAddressvo.setRpStatus((String)row[13]); 
                            break; 
                        case TRANSACTION_KEY: 
                            highRiskAddressvo.setTransasctionKey((String)row[14]);
                            break;
                        default:
                            break; 
                        }
                              
                    }
                    
                    list.add(highRiskAddressvo);
                    
                }
            }
            
            return list;
    
    }    
    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<HighRiskAddressVo> getSecondaryNoRPPReport(long sponsorId) {  
        
        Query query = em.createNativeQuery("select b.ADDRESS,b.ADDRESS_LINE_2,b.CITY,b.STATE,b.ZIP,b.ZIP_11, " + 
                                           "TO_CHAR(b.ADDED_DATETIME, 'YYYY-MM-DD HH.MI.SS') DateTimeAddedintoList, " +
                                           "a.PERSON_ID,c.SPONSOR_USER_ID CRID, d.sponsor_name, "+ 
                                           "TO_CHAR(a.ATTEMPT_DATETIME, 'YYYY-MM-DD HH.MI.SS') DataTimeTobeChecked " +
                                           "from IPS_OWN.SECONDARY_ADDRESS_ATTEMPTS a, " + 
                                           "IPS_OWN.HIGH_RISK_ADDRESSES b, " + 
                                           "IPS_OWN.PERSON c, IPS_OWN.REF_SPONSOR d " + 
                                           "WHERE a.High_risk_address_id=b.High_risk_address_id and " + 
                                           "a.person_id=c.person_id and " + 
                                           "c.sponsor_id=d.sponsor_id and " +
                                           "a.event_id is null"); 
            
            List<Object[]> results = query.getResultList();
            List<HighRiskAddressVo> list = new ArrayList<>();
            
            if (!results.isEmpty()) {
                for (Object[] row: results) {
                    HighRiskAddressVo highRiskAddressvo = new HighRiskAddressVo(); 
                    
                    for (int columnIndex=0; columnIndex<11; columnIndex++) { 
                        switch (columnIndex) { 
                        case ADDRESS:
                            highRiskAddressvo.setAddress((String)row[0]);
                            break; 
                        case ADDRESS_LINE_2:
                            highRiskAddressvo.setAddressLineTwo((String)row[1]); 
                            break;         
                        case CITY:
                            highRiskAddressvo.setCity((String)row[2]);
                            break; 
                        case STATE:
                            highRiskAddressvo.setState((String)row[3]);
                            break; 
                        case ZIP:
                            highRiskAddressvo.setZip((String)row[4]);
                            break; 
                        case ZIP_11:
                            highRiskAddressvo.setZip11((String)row[5]);
                            break; 
                        case DATE_TIME_ADDED_INTO_LIST:
                            //ORACLE DATE 
                            highRiskAddressvo.setTimestampAddedIntoList((String)row[6]);
                            break; 
                        case PERSON_ID:
                            if (validateSQLObjectValue(BIG_DECIMAL, row[columnIndex])) { 
                                long personIdLongValue = ((BigDecimal)row[7]).longValue(); 
                                highRiskAddressvo.setPersonId(Long.toString(personIdLongValue));
                            }                            
                            break; 
                        case CRID: 
                            highRiskAddressvo.setCustRegId((String)row[8]);
                            break;
                        case SPONSOR:
                        	highRiskAddressvo.setSponsor((String)row[9]);
                        	break;                             
                        case DATE_TIME_TO_BE_CHECKED:
                            //ORACLE DATE  
                            highRiskAddressvo.setDateTimeTobeChecked((String)row[10]);
                            break;                         
                        default:
                            break; 
                        }
                              
                    }
                    
                    list.add(highRiskAddressvo);
                    
                }
            }
            
            return list;
    
    }        
    
    private boolean validateSQLObjectValue(String dataType, Object o) { 
        try { 
            if (BIG_DECIMAL.equalsIgnoreCase(dataType) && (BigDecimal)o == null) {
                return false;
            }
        } catch(ClassCastException cce) { 
            return false; 
        }
        return true; 
    }    
}
