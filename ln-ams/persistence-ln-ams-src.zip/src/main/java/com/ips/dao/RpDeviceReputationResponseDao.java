package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpDeviceReputationResponse;

public interface RpDeviceReputationResponseDao {

    Collection<RpDeviceReputationResponse> getAll();    
    RpDeviceReputationResponse getById(Long id);
    RpDeviceReputationResponse getByRequestId(String id);
    void create(RpDeviceReputationResponse entity);
    void update(RpDeviceReputationResponse entity);
    List<RpDeviceReputationResponse> getListByPersonId(long personId);
    RpDeviceReputationResponse getByPersonId(long personId);
    boolean isIndividualNotFound(long personId);
}
