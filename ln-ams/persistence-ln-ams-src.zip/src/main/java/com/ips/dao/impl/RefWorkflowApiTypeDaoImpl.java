package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RefWorkflowApiTypeDao;
import com.ips.entity.RefWorkflowApiType;

@Repository
public class RefWorkflowApiTypeDaoImpl extends GenericJPADAO<RefWorkflowApiType, Long> implements RefWorkflowApiTypeDao {

	 @SuppressWarnings("unchecked")
    @Override
    public Collection<RefWorkflowApiType> getAll() {        
        Query query = em.createNamedQuery("RefWorkflowApiType.getAll");
        return query.getResultList();
    }

	 
    @SuppressWarnings("unchecked")
	@Override
    public RefWorkflowApiType findApiTypeId(long id) {
        Query query = em.createNamedQuery("RefWorkflowApiType.findApiTypeId");
        query.setParameter("apiTypeId", id);
  		List<RefWorkflowApiType> results = query.getResultList();
        
 		return results.isEmpty() ? null : results.get(0);
     }
    
    @SuppressWarnings("unchecked")
   	@Override
       public RefWorkflowApiType findByApiTypeCode(String apiTypeCode) {
           Query query = em.createNamedQuery("RefWorkflowApiType.findByApiTypeCode");
           query.setParameter("apiTypeCode", apiTypeCode);
     		List<RefWorkflowApiType> results = query.getResultList();
           
    		return results.isEmpty() ? null : results.get(0);
        }
    
    @Override
    @Transactional
    public void update(RefWorkflowApiType entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RefWorkflowApiType entity.  ", pe);
        }
    }
    
    @Override
    public void create(RefWorkflowApiType entity) {
        super.save(entity);
    }
    
}
