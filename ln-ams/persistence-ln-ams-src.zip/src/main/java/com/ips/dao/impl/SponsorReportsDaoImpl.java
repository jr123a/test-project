package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.SponsorReportsDao;
import com.ips.entity.SponsorReports;

@Repository
public class SponsorReportsDaoImpl extends GenericJPADAO<SponsorReports, Long> implements SponsorReportsDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<SponsorReports> getAll() {        
        Query query = em.createNamedQuery("SponsorReports.getAll");
        return query.getResultList();
    }

    @Override
    public SponsorReports getById(Long id) {        
        return super.getById(id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public SponsorReports getBySponsorAndReportIds(long sponsorId, long reportId) {        
        Query query = em.createNamedQuery("SponsorReports.getBySponsorAndReportIds");
        query.setParameter("sponsorId", sponsorId);
        query.setParameter("reportId", reportId);
        List<SponsorReports> results = query.getResultList();
        return results.isEmpty()? null : results.get(0);    
    }
    
    @Override
    @Transactional
    public void update(SponsorReports entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging SponsorReports entity.  ", pe);
        }
    }
    
    @Override
    @Transactional
    public void create(SponsorReports entity) {
        try {
            super.persist(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in creating SponsorReports entity.  ", pe);
        }
                
    }

    @Override
    public void delete(SponsorReports entity) {
        super.delete(entity);
    }
    
    @Override
    public List<SponsorReports> findSponsorReportsBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<SponsorReports> list = em.createNamedQuery("SponsorReports.findSponsorReportsBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
     
}

