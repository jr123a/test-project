package com.ips.dao;

import java.util.Collection;
import java.util.Date;

import com.ips.entity.RefLexisNexisResponseCode;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RpEvent;
import com.ips.entity.RpLexisNexisResult;

public interface RpLexisNexisResultDao {
    Collection<RpLexisNexisResult> getAll();    
    RpLexisNexisResult getById(Long id);
    void save(RpLexisNexisResult rpLexisNexisResult);
    void update(RpLexisNexisResult rpLexisNexisResult);
    void delete(RpLexisNexisResult rpLexisNexisResult);
    RpLexisNexisResult findByEvent(RpEvent rpEvent);
    RpLexisNexisResult findByEventId(long eventId);
    Collection<RefLexisNexisResponseCode> getLexisResponseCodes(Date start, Date end, RefLoaLevel loa);
    Long getResponseCodeCount(Date start, Date end, String responseCode);
}
