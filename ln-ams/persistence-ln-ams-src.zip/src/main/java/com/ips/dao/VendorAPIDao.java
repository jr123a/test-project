package com.ips.dao;

import com.ips.entity.VendorAPI;

public interface VendorAPIDao {
    void update(VendorAPI api);
    VendorAPI getByName(String name);
}
