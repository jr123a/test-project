package com.ips.dao;

import java.util.List;

import com.ips.entity.SponsorWebServicePending;

public interface SponsorWebServicePendingDao {
    void save(SponsorWebServicePending pending);
    void delete(SponsorWebServicePending pending);
    SponsorWebServicePending getPending(String enrollmentCode);
    List<SponsorWebServicePending> findSponsorWebServicePendingBySponsor(long sponsorId);
}
