package com.ips.dao;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.ips.entity.IppAppointment;

public interface IppAppointmentDao {
    
    Collection<IppAppointment> getAll();    
    IppAppointment getById(Long id);
    void save(IppAppointment ippAppointment);
    void update(IppAppointment ippAppointment);
    void delete(IppAppointment ippAppointment);
    List<IppAppointment> findAppointments(Date appointmentDate);
}
