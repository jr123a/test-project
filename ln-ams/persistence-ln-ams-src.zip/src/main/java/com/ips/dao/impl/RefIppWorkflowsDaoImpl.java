package com.ips.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RefIppWorkflowsDao;
import com.ips.entity.RefIppWorkflows;

@Repository
public class RefIppWorkflowsDaoImpl extends GenericJPADAO<RefIppWorkflows, Long> implements RefIppWorkflowsDao {

    @SuppressWarnings("unchecked")
    @Override
    public List<RefIppWorkflows> list() {
        List<RefIppWorkflows> list = null;
        try {
            Query query = em.createNamedQuery("RefIppWorkflows.findAll");

            list = query.getResultList();
            if (list == null) {
                list = new ArrayList<>();
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception getting Ref_Ipp_Workflow data", e);
        }

        return list;
    }
    
    @Override
    public RefIppWorkflows getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    public void update(RefIppWorkflows entity) {
        super.merge(entity);
    }
}
