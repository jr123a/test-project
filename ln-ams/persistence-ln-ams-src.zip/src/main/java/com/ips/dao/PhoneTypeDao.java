package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefPhoneType;

public interface PhoneTypeDao {
    Collection<RefPhoneType> getAll();    
    RefPhoneType getById(Long id);
    void save(RefPhoneType entity);
    void update(RefPhoneType entity);
    void delete(RefPhoneType entity);
    RefPhoneType getPhoneTypeByName(String name);
}
