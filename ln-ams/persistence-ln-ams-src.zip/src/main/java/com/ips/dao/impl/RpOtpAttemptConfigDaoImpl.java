package com.ips.dao.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RpOtpAttemptConfigDao;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RpOtpAttemptConfig;
import com.ips.entity.RpOtpAttemptConfigPK;

@Repository
public class RpOtpAttemptConfigDaoImpl extends GenericJPADAO<RpOtpAttemptConfig, Long> implements
        RpOtpAttemptConfigDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpOtpAttemptConfig> getAll() {
        Query query = em.createNamedQuery("RpOtpAttemptConfig.findAll");
        return query.getResultList();
    }

    @Override
    public RpOtpAttemptConfig getById(RpOtpAttemptConfigPK id) {
        return super.getById(id);
    }

    @Override
    public void save(RpOtpAttemptConfig otpAttemptConfig) {
        super.save(otpAttemptConfig);
    }
    
    @Override
    public void update(RpOtpAttemptConfig otpAttemptConfig) {
        super.merge(otpAttemptConfig);
        em.flush();
    }
    
    @Override
    public void delete(RpOtpAttemptConfig otpAttemptConfig) {
        super.delete(otpAttemptConfig);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RpOtpAttemptConfig> getByProofingLevel(long proofingLevel, long sponsorId) {
        List<Long> otpSupplierIds = new ArrayList<>();
        otpSupplierIds.add(RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID);
        otpSupplierIds.add(RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID);
        otpSupplierIds.add(RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID);
        otpSupplierIds.add(RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID);
        
        Query query = em.createNamedQuery("RpOtpAttemptConfig.findByProofingLevel");
        query.setParameter("proofingLevel", proofingLevel);
        query.setParameter("sponsorId", sponsorId);
        query.setParameter("otpSupplierIds", otpSupplierIds);
        
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpOtpAttemptConfig> getByProofingLevelSorted(List<Long> otpSupplierIds, long proofingLevel, long sponsorId) {
    	em.flush();
    	
        Query query = em.createNamedQuery("RpOtpAttemptConfig.findByProofingLevelSorted");
        query.setParameter("proofingLevel", proofingLevel);
        query.setParameter("sponsorId", sponsorId);
        query.setParameter("otpSupplierIds", otpSupplierIds);
        
        query.setHint("javax.persistence.cache.storeMode", "REFRESH");
		query.setHint("javax.persistence.cache.retrieveMode", "BYPASS");
		
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpOtpAttemptConfig> findRowsForReset() {
        Query query = em.createNativeQuery("SELECT * FROM rp_kba_attempts WHERE attempts >= total_attempts * 2 " +
                "AND attempts <> 0 FOR UPDATE", 
                RpOtpAttemptConfig.class);
    
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public RpOtpAttemptConfig findByPrimaryKey(long proofingLevel, long sponsorId, long otpSupplierId) {
         
        Query query = em.createNamedQuery("RpOtpAttemptConfig.findByPrimaryKey");
        query.setParameter("proofingLevel", proofingLevel);
        query.setParameter("sponsorId", sponsorId);
        query.setParameter("otpSupplierId", otpSupplierId);
        
        List<RpOtpAttemptConfig> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);
    }

}
