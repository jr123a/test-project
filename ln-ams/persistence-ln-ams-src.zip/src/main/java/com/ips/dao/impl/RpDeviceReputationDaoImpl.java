package com.ips.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpDeviceReputationDao;
import com.ips.entity.RpDeviceReputation;
import com.ips.persistence.common.DeviceReputationVo;

@Repository
public class RpDeviceReputationDaoImpl extends GenericJPADAO<RpDeviceReputation, Long> implements RpDeviceReputationDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpDeviceReputation> getAll() {        
        Query query = em.createNamedQuery("RpDeviceReputation.getAll");
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpDeviceReputation> getListByPersonId(long personId) {
        Query query = em.createNamedQuery("RpDeviceReputation.getListByPersonId");
        query.setParameter("personId", personId);
         
        return query.getResultList();  
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpDeviceReputation> getListByPersonAndAppId(long personId, long appId) {
        Query query = em.createNamedQuery("RpDeviceReputation.getListByPersonAndAppId");
        query.setParameter("personId", personId);
        query.setParameter("appId", appId);
         
        return query.getResultList();  
    }
    
    @Override
    public RpDeviceReputation getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpDeviceReputation entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpDeviceReputation entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpDeviceReputation entity) {
        super.persist(entity);        
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpDeviceReputation getByRequestId(String id) {
        Query query = em.createNamedQuery("RpDeviceReputation.getByRequestId");
        query.setParameter("requestId", id);
        List<RpDeviceReputation> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);    
    }

    @Override
    public RpDeviceReputation getByPersonId(long personId) {
        List<RpDeviceReputation> results = getListByPersonId(personId);

        return results.isEmpty()? null : results.get(0);    
    }
    
    @Override
    public RpDeviceReputation getByPersonAndAppId(long personId, long appId) {
        List<RpDeviceReputation> results = getListByPersonAndAppId(personId, appId);

        return results.isEmpty()? null : results.get(0);    
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpDeviceReputation getBySessionId(String sessionId) {
        Query query = em.createNamedQuery("RpDeviceReputation.getBySessionId");
        query.setParameter("sessionId", sessionId);
         List<RpDeviceReputation> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);    
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpDeviceReputation getByPersonIdSessionIdPhoneNumber(String sessionId, String mobilePhoneNumber, long personId) {
        Query query = em.createNamedQuery("RpDeviceReputation.getByPersonIdSessionIdPhoneNumber");
        query.setParameter("sessionId", sessionId);
        query.setParameter("mobilePhoneNumber", mobilePhoneNumber);
        query.setParameter("personId", personId);
         List<RpDeviceReputation> results = query.getResultList();
        
        return results.isEmpty()? null : results.get(0);    
    }
        
    @SuppressWarnings("unchecked")
    @Override
    public List<DeviceReputationVo> getDeviceReputationReport(Date runDate) {

            ArrayList<DeviceReputationVo> list = new ArrayList<>();
        try {        
             String sql = getDeviceReputationAttemptQuery(runDate);
             Query q = em.createNativeQuery(sql);
             List<Object[]> resultList = q.getResultList();

             for (Object[] item : resultList) {
                 DeviceReputationVo rep = new DeviceReputationVo();
                 rep.setPersonId(String.valueOf((BigDecimal) item[0]));
                 rep.setSponsorUserId((String) item[1]);
                 rep.setFirstName((String) item[2]);
                 rep.setLastName((String) item[3]);
                 rep.setDeviceConfidenceId(String.valueOf((BigDecimal) item[4]));
                 rep.setReputationAssessment((String) item[5]);
                 rep.setReviewStatus((String) item[6]);
                 rep.setRiskScore(String.valueOf((BigDecimal) item[7]));
                 rep.setHighRiskAttemptId(String.valueOf((BigDecimal) item[8]));
                 rep.setRpEventId(String.valueOf((BigDecimal) item[9]));
                 rep.setIppEventId(String.valueOf((BigDecimal) item[10]));
                 rep.setAppId(String.valueOf((BigDecimal) item[11]));
                 rep.setProofingStatus(String.valueOf((BigDecimal) item[12]));
                 rep.setStatusDescription((String) item[13]);
                 Date updateDate = (Date) item[14];
                 rep.setPersonUpdateDate(updateDate != null ? updateDate.toString() : "");
                 list.add(rep);
             }
    
        } catch (Exception ex) {
            CustomLogger.error(this.getClass(), "Error in getting  DeviceReputationVo item list.",ex);
        } 
        
        return list;
    }
    
    private String getDeviceReputationAttemptQuery(Date runDate) {
        StringBuilder sqlSb = new StringBuilder();
        
        String[] runDateArr = String.valueOf(runDate).split(" ");
        String runDateStr = runDateArr[1] + " " + runDateArr[2] + ", " + runDateArr[5];

        String runDateFmt = String.format("'%s', 'MONTH DD, YYYY'", runDateStr);
        sqlSb.append("SELECT p.person_id as personId, p.sponsor_user_id as sponsorUserId, d.first_name as firstName, d.last_name as lastName, "
            + "r.device_confidence_id as deviceConfidenceId, c.reputation_assessment as reputationAssessment, c.review_status as reviewStatus, "
            + "r.risk_score as riskScore, a.high_risk_attempt_id as highRiskAttemptId, e.event_id as rpEventId, i.ipp_event_id as ippEventId, "
            + "r.app_id as appId, s.proofing_status as proofingStatus, case when s.proofing_status = 25 then 'Attempt to verify ID with Low Confidence' " 
            + "else rs.status_description end as statusDescription, p.update_date as personUpdateDate ");
        sqlSb.append("FROM ips_own.person p, ips_own.person_data d, ips_own.rp_device_reputation r, ips_own.ref_device_confidence c, "
            + "ips_own.high_risk_address_attempts a, ips_own.rp_event e, ips_own.ipp_event i, ips_own.person_proofing_status s, ips_own.ref_rp_status rs ");
        sqlSb.append("WHERE p.person_id = d.person_id AND p.person_id = r.person_id (+) AND r.device_confidence_id = c.device_confidence_id (+) "
            + "AND p.person_id = a.person_id (+) AND p.person_id = e.person_id (+) AND p.person_id = i.person_id (+) "
            + "AND p.person_id = s.person_id (+) AND s.proofing_status = rs.status_code " 
            + "AND p.update_date >= TO_DATE(" + runDateFmt + ") AND p.update_date < TO_DATE(" + runDateFmt + ") + 1 ");
        sqlSb.append("ORDER BY p.update_date DESC ");

        return sqlSb.toString();
    }
}
