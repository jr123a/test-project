package com.ips.dao.impl;

import java.util.Collection;

import javax.persistence.Query;
import org.springframework.stereotype.Repository;

import com.ips.dao.PhoneProductStatusDao;
import com.ips.entity.RefProductStatusCode;

@Repository
public class PhoneProductStatusDaoImpl extends GenericJPADAO<RefProductStatusCode,String> implements PhoneProductStatusDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefProductStatusCode> getAll() {
        Query query = em.createNamedQuery("RefProductStatusCode.findAll");
        return query.getResultList();
    }
    
    @Override
    public RefProductStatusCode getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void save(RefProductStatusCode entity) {
        super.save(entity);
    }

    @Override
    public void update(RefProductStatusCode entity) {
        super.merge(entity);
        em.flush();
    }

    @Override
    public void delete(RefProductStatusCode entity) {
        super.delete(entity);
    }

    @Override
    public RefProductStatusCode getProductStatusByName(String name) {
        Query query = em.createNamedQuery("RefProductStatusCode.findByName");
        query.setParameter("name", name);
        
        if (query.getResultList() == null || query.getResultList().isEmpty()) {
            return null;
        } else {
            return (RefProductStatusCode) query.getResultList().get(0);
        }
    }

}
