package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefAdminEventDao;
import com.ips.entity.RefAdminEvent;

@Repository
public class RefAdminEventDaoImpl extends GenericJPADAO<RefAdminEvent, Long> implements
        RefAdminEventDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefAdminEvent> getAll() {
        Query query = em.createNamedQuery("RefAdminEvent.findAll");
        return query.getResultList();
    }

    @Override
    public RefAdminEvent getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void update(RefAdminEvent refAdminEvent) {
        super.merge(refAdminEvent);
    }

    @Override
    public RefAdminEvent getByDescription(String eventDescription) {
        Query query = em.createNamedQuery("RefAdminEvent.findByDescription");
        query.setParameter("description", eventDescription);
        @SuppressWarnings("unchecked")
        List<RefAdminEvent> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }
    }

}
