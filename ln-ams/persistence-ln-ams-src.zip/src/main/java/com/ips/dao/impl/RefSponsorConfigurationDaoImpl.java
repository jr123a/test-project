package com.ips.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.SynchronizationType;
import javax.persistence.criteria.CriteriaQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.RefSponsorConfigurationDao;
import com.ips.entity.RefSponsorConfiguration;

@Repository
@Transactional
public class RefSponsorConfigurationDaoImpl extends GenericJPADAO<RefSponsorConfiguration, String>
		implements RefSponsorConfigurationDao, Serializable {
	private static final long serialVersionUID = 1L;


	@Override
	public List<RefSponsorConfiguration> getConfiguration() {
		CriteriaQuery<RefSponsorConfiguration> cq = em.getCriteriaBuilder().createQuery(RefSponsorConfiguration.class);
		return em.createQuery(cq).getResultList();
	}

	@Override
	public List<RefSponsorConfiguration> findConfigRecordByName(String name) {
		return em.createNamedQuery("RefSponsorConfiguration.findConfigRecordByName", RefSponsorConfiguration.class)
				.setParameter("name", name).getResultList();
	}

	@Override
	@Transactional
	public void delete(RefSponsorConfiguration entity) {
		super.delete(entity);
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * Changed from using getSingleResult. getSingleResult will return an exception
	 * if no record is returned. There are cases where a row will not exist in the
	 * table.
	 */
	public RefSponsorConfiguration getConfigRecord(int sponsorId, String name) {

		Query query = em.createNamedQuery("RefSponsorConfiguration.getConfigRecord", RefSponsorConfiguration.class)
				.setParameter("sponsorId", sponsorId).setParameter("name", name);
		List<RefSponsorConfiguration> results = query.getResultList();

		if (results.isEmpty()) {
			return null;
		} else {
			return results.get(0);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Long getConfigRecordCount(int sponsorId, String name) {

		Query query = em.createNamedQuery("RefSponsorConfiguration.getConfigRecord", RefSponsorConfiguration.class)
				.setParameter("sponsorId", sponsorId).setParameter("name", name);
		List<RefSponsorConfiguration> results = query.getResultList();

		if (results.isEmpty()) {
			return 0L;
		} else {
			return (long) results.size();
		}
	}

	@Override
	@Transactional
	public void update(RefSponsorConfiguration refSponsorConfig) {
		super.merge(refSponsorConfig);
	}

	@Override
	public long getMaxConfigId() {
		return (long) em.createNamedQuery("RefSponsorConfiguration.getMaxConfigId").getSingleResult();
	}

	@Override
	@Transactional
	public void create(RefSponsorConfiguration entity) {
		super.save(entity);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RefSponsorConfiguration> findConfigRecordsBySponsor(long sponsorId) {
		List<RefSponsorConfiguration> list = em.createNamedQuery("RefSponsorConfiguration.findConfigRecordsBySponsor")
				.setParameter("sponsorId", sponsorId).getResultList();
		return list == null || list.isEmpty() ? null : list;
	}
}
