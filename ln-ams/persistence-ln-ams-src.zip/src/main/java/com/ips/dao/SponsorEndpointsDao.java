package com.ips.dao;

import java.util.List;

import com.ips.entity.SponsorEndpoints;

public interface SponsorEndpointsDao {
    SponsorEndpoints getSponsorEndpointByEnv(String env);
    List<SponsorEndpoints> findSponsorEndpointsBySponsor(long sponsorId);
    void save(SponsorEndpoints endpoint);
    void delete(SponsorEndpoints endpoint);
}
