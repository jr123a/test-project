package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefOtpVelocityDao;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefOtpVelocity;

@Repository
public class RefOtpVelocityDaoImpl extends GenericJPADAO<RefOtpVelocity, Long>
        implements RefOtpVelocityDao, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefOtpVelocity> getAll() {
        Query query = em.createNamedQuery("RefOtpVelocity.findAll");
        return query.getResultList();
    }

    @Override
    public RefOtpVelocity getById(Long id) {
        return super.getById(id);
    }    

    @Override
    public void update(RefOtpVelocity refOtpVelocity) {
        super.merge(refOtpVelocity);
        em.flush();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefOtpVelocity> findAllByOtpSupplier(
            RefOtpSupplier supplier) {
        Query query = em.createNamedQuery("RefOtpVelocity.findAllByOtpSupplier").setParameter("supplier", supplier);
        return query.getResultList();
    }
    
    @Override
    public RefOtpVelocity findByVelocityType(RefOtpSupplier supplier, String velocityType) {
    	if (supplier != null) {
    		return findByIdAndVelocityType(supplier.getOtpSupplierId(), velocityType);
    	}
    	
    	return null;
    }    
    
    @Override
    public RefOtpVelocity findByIdAndVelocityType(long supplierId, String velocityType) {
          Query query = em.createNamedQuery("RefOtpVelocity.findByVelocityType")
                .setParameter("supplierId", supplierId)
                .setParameter("velocityType", velocityType);
        RefOtpVelocity velocity = null;
        @SuppressWarnings("unchecked")
        List<RefOtpVelocity> list = query.getResultList();    
        Optional<RefOtpVelocity> result = list.stream().findFirst();
        
        if (result.isPresent()) {
            velocity= result.get();
        }

        return velocity;
    }    
}
