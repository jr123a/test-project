package com.ips.dao;

import java.util.List;

import com.ips.entity.IdDocumentDetails;

public interface IdDocumentDetailsDao {
    public void save(IdDocumentDetails request);
    public void update(IdDocumentDetails request);
    List<IdDocumentDetails> getDocumentDetailsForEvent(long eventId);
}
