package com.ips.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefLexisNexisReasonCodeMapDao;
import com.ips.entity.RefLexisNexisReasonCodeMap;

@Repository
public class RefLexisNexisReasonCodeDaoImpl extends GenericJPADAO<RefLexisNexisReasonCodeMap, Long>
        implements RefLexisNexisReasonCodeMapDao {

    @Override
    public RefLexisNexisReasonCodeMap retireveByValue(String column,
            String value) {
        @SuppressWarnings("unchecked")
        List<RefLexisNexisReasonCodeMap> list  =  (List<RefLexisNexisReasonCodeMap>) em.createNamedQuery("lnReasonCodeMap.getByValue")
        .setParameter("column", column)
        .setParameter("value", value)
        .getResultList();
        if(list.isEmpty()){
            return null;
        } else{
            return list.get(0);
        }
    }

}
