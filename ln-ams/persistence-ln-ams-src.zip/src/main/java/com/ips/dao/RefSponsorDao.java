package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RefSponsor;

public interface RefSponsorDao {
    Collection<RefSponsor> getAll();
    List<RefSponsor> getNonExternalSponsors();
    List<RefSponsor> getAllRemoteProofingClients();
    RefSponsor getById(Long id);
    void save(RefSponsor sponsor);
    void update(RefSponsor sponsor);
    void delete(RefSponsor sponsor);
    RefSponsor getBySponsorName(String sponsor);
    List<RefSponsor> getExternalClients();
    List<RefSponsor> findSponsorReceivingReports();
    List<RefSponsor> getIAL2Sponsors(String name);
    List<RefSponsor> getActiveExternalSponsorList();
    List<RefSponsor> getActiveInternalSponsorList();
	Collection<RefSponsor> getEditableList();
	Collection<RefSponsor> getDeletableList();
	Collection<RefSponsor> getNotModifiableList();
	boolean isSponsorEditable(Long sponsorId);
	boolean isSponsorDeletable(Long sponsorId);
	boolean isSponsorNotRegular(Long sponsorId);
	boolean isSponsorNotReferencedInSponsorAppMap(Long sponsorId);
	boolean isSponsorNotReferencedInPerson(Long sponsorId);
}
