package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpSmfaValidateResponseDao;
import com.ips.entity.RpSmfaValidateResponse;


@Repository
public class RpSmfaValidateResponseDaoImpl extends GenericJPADAO<RpSmfaValidateResponse, Long> implements RpSmfaValidateResponseDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpSmfaValidateResponse> getAll() {        
        Query query = em.createNamedQuery("RpDitResponse.getAll");
        return query.getResultList();
    }

    @Override
    public RpSmfaValidateResponse getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpSmfaValidateResponse entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpSmfaValidateResponse entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpSmfaValidateResponse entity) {
        super.persist(entity);        
    }
    
    @Override
    public RpSmfaValidateResponse getByPersonId(long personId) {
         List<RpSmfaValidateResponse> results = getListByPersonId(personId);
        
        return results.isEmpty()? null : results.get(0);    
    }
    
    @Override
    public RpSmfaValidateResponse getByPersonIdAndSessionId(long personId, String sessionId) {
         List<RpSmfaValidateResponse> results = getListByPersonIdAndSessionId(personId, sessionId);
        
        return results.isEmpty()? null : results.get(0);    
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpSmfaValidateResponse> getListByPersonId(long personId) {
        Query query = em.createNamedQuery("RpSmfaValidateResponse.getListByPersonId");
        query.setParameter("personId", personId);
        
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
	private List<RpSmfaValidateResponse> getListByPersonIdAndSessionId(long personId, String sessionId) {
        Query query = em.createNamedQuery("RpSmfaValidateResponse.getListByPersonIdAndSessionId");
        query.setParameter("personId", personId);
        query.setParameter("sessionId", sessionId);
        
        return query.getResultList();   
    }
}
