package com.ips.dao;

import java.util.Collection;
import java.util.Date;

import com.ips.entity.RefOtpReasonCode;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RpEquifaxFinalReasonCode;

public interface RpEquifaxFinalReasonCodesDao {

    Collection<RpEquifaxFinalReasonCode> getAll();
    RpEquifaxFinalReasonCode getById(Long id);
    void save(RpEquifaxFinalReasonCode rpEquifaxFinalReasonCode);
    void update(RpEquifaxFinalReasonCode rpEquifaxFinalReasonCode);
    void delete(RpEquifaxFinalReasonCode rpEquifaxFinalReasonCode);
    Collection<RefOtpReasonCode> getEquifaxNegativeReasons(Date start, Date end, RefLoaLevel loa);
    Long getReasonCodeCount(Date start, Date end, String reasonCode, RefLoaLevel loa);
}
