package com.ips.dao;

import java.util.List;

import com.ips.entity.SponsorReportHistory;

public interface SponsorReportHistoryDao {

    void save(SponsorReportHistory history);
    void update(SponsorReportHistory history);
    void delete(SponsorReportHistory history);
    SponsorReportHistory getById(Long id);
    List<SponsorReportHistory> findSponsorReportHistoryBySponsor(long sponsorId);
}
