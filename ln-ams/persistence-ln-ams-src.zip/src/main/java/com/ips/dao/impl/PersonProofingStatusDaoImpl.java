package com.ips.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.SynchronizationType;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.PersonProofingStatusDao;
import com.ips.entity.PersonProofingStatus;

@Repository
public class PersonProofingStatusDaoImpl extends GenericJPADAO<PersonProofingStatus, String>
		implements PersonProofingStatusDao, Serializable {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	@Override
	public PersonProofingStatus getByPersonId(int personId) {

		em.flush();
		Query query = em.createNamedQuery("PersonProofingStatus.getByPersonId", PersonProofingStatus.class)
				.setParameter("personId", personId);
		
		query.setHint("javax.persistence.cache.storeMode", "REFRESH");
		query.setHint("javax.persistence.cache.retrieveMode", "BYPASS");
		query.setHint("eclipselink.refresh", true);

		List<PersonProofingStatus> results = query.getResultList();

		if (results.isEmpty()) {
			return null;
		} else {
			return (PersonProofingStatus) results.get(0);
		}
	}

	@Override
	@Transactional
	public void update(PersonProofingStatus personProofingStatus) {
		super.merge(personProofingStatus);
		em.flush();
	}
	
	@Override
	public Long getPersonProofingStatusCodeByPersonId(int personId)  {
		try {
			Query query = em.createNativeQuery("SELECT PROOFING_STATUS FROM IPS_OWN.PERSON_PROOFING_STATUS WHERE PERSON_ID = ?1 AND PROOFING_LEVEL_SOUGHT = ?2 ")
			.setParameter(1, personId)
			.setParameter(2, 1L);
			
			return Long.parseLong((String.valueOf((BigDecimal) query.getSingleResult())));
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Database error occurred during authentication.", e);
			return 0L;
		}
	}

}
