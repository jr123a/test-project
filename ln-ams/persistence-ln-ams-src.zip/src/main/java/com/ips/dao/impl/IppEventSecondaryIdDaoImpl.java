package com.ips.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.IppEventSecondaryIdDao;
import com.ips.entity.IppEventSecondaryID;

@Repository
public class IppEventSecondaryIdDaoImpl extends GenericJPADAO<IppEventSecondaryID, Long>
implements IppEventSecondaryIdDao {

    @SuppressWarnings("unchecked")
    @Override
    public long getSecondaryIdCountByEventSecondary(long idType) {

        Query query = em.createNamedQuery("IppEventSecondaryID.getSecondaryIdCountByEventSecondary");
        query.setParameter("idType", idType);
        List<Long> results = query.getResultList();
        if (results.isEmpty()) {
            return 0L;
        } else {
            return results.get(0);
        }

    }
    
    @Override
    public void delete(IppEventSecondaryID ids) {
    	super.delete(ids);
    }

}
