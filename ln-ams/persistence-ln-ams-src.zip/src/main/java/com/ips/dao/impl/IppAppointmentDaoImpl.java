package com.ips.dao.impl;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.IppAppointmentDao;
import com.ips.entity.IppAppointment;

@Repository
public class IppAppointmentDaoImpl extends GenericJPADAO<IppAppointment, Long> implements IppAppointmentDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<IppAppointment> getAll() {
        Query query = em.createNamedQuery("IppAppointment.findAll");
        return query.getResultList();
    }

    @Override
    public IppAppointment getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void update(IppAppointment ippAppointment) {
        super.merge(ippAppointment);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<IppAppointment> findAppointments(Date appointmentDate) {
        Query query = em.createNativeQuery("SELECT * FROM Ipp_Appointment WHERE process_status_code = 0 AND " +
                "Appointment_Date = ? FOR UPDATE", IppAppointment.class);
        query.setParameter(1, appointmentDate);
        return query.getResultList();
    }

}
