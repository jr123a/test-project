package com.ips.dao;

import java.util.Date;
import java.util.List;

import com.ips.entity.SponsorTokens;

public interface SponsorTokensDao {

    void update(SponsorTokens token);
    void save(SponsorTokens token);
    void delete(SponsorTokens token);
    String getToken(Long sponsorId);
    Date getExpiration(Long sponsorId);
    List<SponsorTokens> findSponsorTokensBySponsor(long sponsorId);

}
