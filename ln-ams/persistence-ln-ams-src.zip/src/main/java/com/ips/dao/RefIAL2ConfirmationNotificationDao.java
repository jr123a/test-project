package com.ips.dao;

import java.util.List;

import com.ips.entity.RefIAL2ConfirmationNotification;

public interface RefIAL2ConfirmationNotificationDao {
    public List<RefIAL2ConfirmationNotification> findAll();
    public RefIAL2ConfirmationNotification findById(long id);
}
