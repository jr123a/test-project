package com.ips.dao.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.RpEquifaxFinalReasonCodesDao;
import com.ips.entity.RefOtpReasonCode;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefSponsor;
import com.ips.entity.RpEquifaxFinalReasonCode;

@Transactional
@Repository
public class RpEquifaxFinalReasonCodesDaoImpl extends
        GenericJPADAO<RpEquifaxFinalReasonCode, Long> implements Serializable,
        RpEquifaxFinalReasonCodesDao {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpEquifaxFinalReasonCode> getAll() {
        Query query = em.createNamedQuery("RpEquifaxFinalReasonCode.findAll");
        return query.getResultList();
    }

    @Override
    public RpEquifaxFinalReasonCode getById(Long id) {        
        return super.getById(id);
    }

    @Override
    public void update(RpEquifaxFinalReasonCode rpEquifaxFinalReasonCode) {
        super.merge(rpEquifaxFinalReasonCode);     
        em.flush();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    /**
     * Retrieves the Equifax negative reason codes in the timeframe.
     * @param start
     * @param end
     * @return
     */
    public List<RefOtpReasonCode> getEquifaxNegativeReasons(Date start, Date end, RefLoaLevel loa) {
    
        Query query = em.createNativeQuery(
                "SELECT k.reason_code, k.assert_flag, k.create_date, k.kba_supplier_id, " +
                "k.reason_code_description, k.update_date " +
                "FROM rp_event e, rp_equifax_final_reason_codes r, ref_kba_reason_code k, person p " +
                "WHERE e.event_id = r.event_id " +
                "AND r.reason_code = k.reason_code " +
                "AND e.person_id = p.person_id " +
                "AND e.proofing_level_sought = ? " +
                "AND k.negative_reason = 'Y' " +
                "AND e.initiation_datetime >= ? " +
                "AND e.initiation_datetime <= ? " +
                "AND p.sponsor_id = ?", RefOtpReasonCode.class);
        
        query.setParameter(1, loa.getLoaCode());
        query.setParameter(2, start);
        query.setParameter(3, end);
        query.setParameter(4, RefSponsor.SPONSOR_ID_CUSTREG);
        
        return query.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Long getReasonCodeCount(Date start, Date end, String reasonCode,  RefLoaLevel loa) {
        Query query = em.createNativeQuery(
                "SELECT count(distinct e.event_id) " +
                "FROM rp_event e, rp_equifax_final_reason_codes r, person p " +
                "WHERE e.event_id = r.event_id " +
                "AND e.person_id = p.person_id " +
                "AND r.reason_code = ? " +
                "AND e.proofing_level_sought = ? " +
                "AND e.initiation_datetime >= ? " +
                "AND e.initiation_datetime <= ? " +
                "AND p.sponsor_id = ?");
        
        query.setParameter(1, reasonCode);
        query.setParameter(2, loa.getLoaCode());
        query.setParameter(3, start);
        query.setParameter(4, end);
        query.setParameter(5, RefSponsor.SPONSOR_ID_CUSTREG);
        
        List<BigDecimal> results = query.getResultList();
        
        if (results.isEmpty()) {
            return 0L;
        } 
        else {
            BigDecimal count = results.get(0);
            return new Long(count.longValue());
        }
    }
}
