package com.ips.dao;

import com.ips.entity.VendorToken;

public interface VendorTokenDao {
    void save(VendorToken token);
    void update(VendorToken token);
    VendorToken getByType(String type);
}
