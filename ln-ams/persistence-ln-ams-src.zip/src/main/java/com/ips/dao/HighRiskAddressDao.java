package com.ips.dao;

import com.ips.entity.HighRiskAddress;
import com.ips.entity.RefHighRiskAddressType;

import java.util.List;
import com.ips.persistence.common.HighRiskAddressVo;

public interface HighRiskAddressDao {

    void update(HighRiskAddress highRiskAddress);
    HighRiskAddress findHighRiskAddress(int addressHash);
    HighRiskAddress findHighRiskAddressByAddress(String address, String city, String state, String zip);
    List<HighRiskAddress> getAllPrimary();
    List<HighRiskAddressVo> getPrimaryReport(long sponsorId);
    List<HighRiskAddressVo> getPrimaryReportIPP(long sponsorId);
    List<HighRiskAddressVo> getSecondaryReport(long sponsorId);
    List<HighRiskAddressVo> getSecondaryNoRPPReport(long sponsorId);   
    RefHighRiskAddressType findRefHighRiskAddressTypeByTypeId(long typeId);

}
