package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefFieldCheck;

public interface RefFieldCheckDao {
    Collection<RefFieldCheck> getAll();    
    RefFieldCheck getById(Long id);
    void save(RefFieldCheck status);
    void update(RefFieldCheck status);
    void delete(RefFieldCheck status);
    RefFieldCheck getByName(String name);
}
