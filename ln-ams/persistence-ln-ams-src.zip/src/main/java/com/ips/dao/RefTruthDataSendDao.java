package com.ips.dao;

import com.ips.entity.RefTruthDataSendEvent;

public interface RefTruthDataSendDao {

    RefTruthDataSendEvent getById(Long id);
}
