package com.ips.dao.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.NamedQuery;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.RpEquifaxResultDao;
import com.ips.entity.RpEquifaxResult;
import com.ips.entity.RpEvent;

@Transactional
@Repository
public class RpEquifaxResultDaoImpl extends GenericJPADAO<RpEquifaxResult, Long> implements Serializable, RpEquifaxResultDao{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpEquifaxResult> getAll() {
        Query query = em.createNamedQuery("RpEquifaxResult.findAll");
        return query.getResultList();
    }

    @Override
    public RpEquifaxResult getById(Long id) {        
        return super.getById(id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RpEquifaxResult findByEventId(long eventId) {
        Query query = em.createNamedQuery("RpEquifaxResult.findByEventId")
        		.setParameter("eventId", eventId);

        List<RpEquifaxResult> list = (List<RpEquifaxResult>) query.getResultList();
        return list.isEmpty() ? null : list.get(0);
    }
 
    @Override
    public void update(RpEquifaxResult rpEquifaxResult) {
        super.merge(rpEquifaxResult);  
        em.flush();
    }
}
