package com.ips.dao.impl;

import java.io.Serializable;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefTruthDataSendDao;
import com.ips.entity.RefTruthDataSendEvent;

@Repository
public class RefTruthDataSendDaoImpl extends GenericJPADAO<RefTruthDataSendEvent, Long> implements
    RefTruthDataSendDao,Serializable  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Override
    public RefTruthDataSendEvent getById(Long id) {        
        return super.getById(id);
    }
    
}
