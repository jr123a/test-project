package com.ips.dao;

import java.util.List;

import com.ips.entity.SponsorWebServiceRequests;

public interface SponsorWebServiceRequestDao {
    void save(SponsorWebServiceRequests requests);
    void update(SponsorWebServiceRequests request);
    void delete(SponsorWebServiceRequests request);
    String getSuccessForEnrollmentCode(String enrollmentCode);
    SponsorWebServiceRequests findRequestByEnrollmentCode(String enrollmentCode);
    List<SponsorWebServiceRequests> findSponsorWebServiceRequestsBySponsor(long sponsorId);
}
