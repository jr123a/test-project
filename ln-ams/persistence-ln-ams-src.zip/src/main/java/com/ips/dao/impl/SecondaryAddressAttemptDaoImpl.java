package com.ips.dao.impl;

import java.io.Serializable;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.SecondaryAddressAttemptDao;
import com.ips.entity.SecondaryAddressAttempt;

@Transactional
@Repository
public class SecondaryAddressAttemptDaoImpl extends GenericJPADAO<SecondaryAddressAttempt, Long> implements Serializable, SecondaryAddressAttemptDao{    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Override
    public void update(SecondaryAddressAttempt attempt) {
        super.merge(attempt);        
    }
    
    @Override
    public SecondaryAddressAttempt getById(Long id) {
        return super.getById(id);
    }
}
