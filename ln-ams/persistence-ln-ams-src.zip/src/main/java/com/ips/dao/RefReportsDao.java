package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RefReports;

public interface RefReportsDao {

    Collection<RefReports> getAll();    
    List<RefReports> findBySponsor(long sponsorId);
    List<RefReports> findForIppClientActiveSponsor();
    RefReports getById(Long id);
    void save(RefReports entity);
    void update(RefReports entity);
    void delete(RefReports entity);
}
