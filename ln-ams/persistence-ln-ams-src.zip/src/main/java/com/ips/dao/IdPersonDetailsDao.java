package com.ips.dao;

import com.ips.entity.IdPersonDetails;

public interface IdPersonDetailsDao {
    public void save(IdPersonDetails request);
    public void update(IdPersonDetails request);
    String getDetailData(long personDetailId);
}
