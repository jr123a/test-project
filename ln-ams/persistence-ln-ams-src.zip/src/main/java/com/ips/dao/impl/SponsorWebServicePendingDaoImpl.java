package com.ips.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.SponsorWebServicePendingDao;
import com.ips.entity.SponsorWebServicePending;

@Repository
public class SponsorWebServicePendingDaoImpl extends GenericJPADAO<SponsorWebServicePending, Long> implements SponsorWebServicePendingDao{

    @Override
    public void save(SponsorWebServicePending pending) {
        super.save(pending);
    }
    
    @Override
    public void delete(SponsorWebServicePending pending) {
        super.delete(pending);
    }

    @SuppressWarnings("unchecked")
    @Override
    public SponsorWebServicePending getPending(String enrollmentCode) {
        Query query = em.createNamedQuery("SponsorWebServicePending.getPending");
        query.setParameter("enrollmentCode", enrollmentCode);
        List<SponsorWebServicePending> results = query.getResultList();

        if (results.isEmpty()) {
            return null;
        } else {
            return results.get(0);
        }
    }
    
    @Override
    public List<SponsorWebServicePending> findSponsorWebServicePendingBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<SponsorWebServicePending> list = em.createNamedQuery("SponsorWebServicePending.findSponsorWebServicePendingBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
    
}
