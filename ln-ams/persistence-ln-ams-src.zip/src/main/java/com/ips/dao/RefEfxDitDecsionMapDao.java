package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefEfxDitDecisionMap;

public interface RefEfxDitDecsionMapDao {

    Collection<RefEfxDitDecisionMap> getAll();    

}
