package com.ips.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.RefCustomerCategoryDao;
import com.ips.entity.RefCustomerCategory;
import com.ips.entity.RefSponsorConfiguration;

@Repository
public class RefCustomerCategoryDaoImpl extends GenericJPADAO<RefCustomerCategory, Long> implements RefCustomerCategoryDao {

    @SuppressWarnings("unchecked")
	@Override
    public RefCustomerCategory findByCategoryId(long id) {
        Query query = em.createNamedQuery("RefCustomerCategory.findByCategoryId");
        query.setParameter("customerCategoryId", id);
  		List<RefCustomerCategory> results = query.getResultList();
        
 		return results.isEmpty() ? null : results.get(0);
     }
    
    @SuppressWarnings("unchecked")
   	@Override
    public RefCustomerCategory findByCategoryName(String name) {
       Query query = em.createNamedQuery("RefCustomerCategory.findByCategoryName");
       query.setParameter("categoryName", name);
 		List<RefCustomerCategory> results = query.getResultList();
       
		return results.isEmpty() ? null : results.get(0);
    }
    
    @Override
	@Transactional
	public void create(RefCustomerCategory entity) {
		super.save(entity);
	}
}
