package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefIdValidationVendor;

public interface RefIdValidationVendorDao {
    Collection<RefIdValidationVendor> getAll();
    RefIdValidationVendor getById(Long id);
    void save(RefIdValidationVendor vendor);
    void update(RefIdValidationVendor vendor);
    void delete(RefIdValidationVendor vendor);

}
