package com.ips.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.IppEventIDValidationDao;
import com.ips.entity.IppEventIDValidation;

@Repository
public class IppEventIDValidationDaoImpl extends GenericJPADAO<IppEventIDValidation, Long>
        implements IppEventIDValidationDao {

    @SuppressWarnings("unchecked")
    @Override
    public long getPrimaryIdUsedCountByIdValidation(long idType) {

        Query query = em.createNamedQuery("IppEventIDValidation.getPrimaryIdUsedCountByIdValidation");
        query.setParameter("idType", idType);
        List<Long> results = query.getResultList();
        if (results.isEmpty()) {
            return 0L;
        } else {
            return results.get(0);
        }

    }

    @Override
    public void save(IppEventIDValidation validation) {
        super.save(validation);
    }
    
    @Override
    public void update(IppEventIDValidation validation) {
        super.merge(validation);
        em.flush();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<IppEventIDValidation> getValidationsForEvent(long eventId) {
        List<IppEventIDValidation> validations = new ArrayList<>();
        Query query = em.createNamedQuery("IppEventIDValidation.getByEvent");
        query.setParameter("eventId", eventId);
        List<IppEventIDValidation> results = query.getResultList();
        // Create a mutable list so it can be sorted
        validations.addAll(results);
        return validations;
    }

	@SuppressWarnings("unchecked")
	@Override
	public List<IppEventIDValidation> getValidationsForEventAndIdType(long eventId, long strongIdType) {
		List<IppEventIDValidation> validations = new ArrayList<>();
        Query query = em.createNamedQuery("IppEventIDValidation.getByEventAndIdType");
        query.setParameter("eventId", eventId);
        query.setParameter("strongIdType", strongIdType);
        List<IppEventIDValidation> results = query.getResultList();
        // Create a mutable list so it can be sorted
        validations.addAll(results);
        return validations;
	}
}
