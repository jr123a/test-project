package com.ips.dao.impl;

import java.util.Collection;

import javax.persistence.Query;
import org.springframework.stereotype.Repository;

import com.ips.dao.PhoneServiceStatusDao;
import com.ips.entity.RefServiceStatusCode;

@Repository
public class PhoneServiceStatusDaoImpl extends GenericJPADAO<RefServiceStatusCode,String> implements PhoneServiceStatusDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefServiceStatusCode> getAll() {
        Query query = em.createNamedQuery("RefServiceStatusCode.findAll");
        return query.getResultList();
    }

    @Override
    public RefServiceStatusCode getById(Long id) {
        return super.getById(id);
    }

    @Override
    public void save(RefServiceStatusCode entity) {
        super.save(entity);
    }

    @Override
    public void update(RefServiceStatusCode entity) {
        super.merge(entity);
        em.flush();
    }

    @Override
    public void delete(RefServiceStatusCode entity) {
        super.delete(entity);
    }

    @Override
    public RefServiceStatusCode getServiceStatusByName(String name) {
        Query query = em.createNamedQuery("RefServiceStatusCode.findByName");
        query.setParameter("name", name);
        
        if (query.getResultList() == null || query.getResultList().isEmpty()) {
            return null;
        } else {
            return (RefServiceStatusCode) query.getResultList().get(0);
        }
    }

}
