package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpAllVerificationResultsDao;
import com.ips.entity.RpAllVerificationResults;

@Repository
public class RpAllVerificationResultsDaoImpl extends GenericJPADAO<RpAllVerificationResults, Long> implements RpAllVerificationResultsDao  {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpAllVerificationResults> getAll() {        
        Query query = em.createNamedQuery("RpAllVerificationResults.getAll");
        return query.getResultList();
    }

    @Override
    public RpAllVerificationResults getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpAllVerificationResults entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpAllVerificationResults entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpAllVerificationResults entity) {
    	 try {
     	        super.persist(entity);          
    	 } catch (PersistenceException pe) {
             CustomLogger.error(this.getClass(), "Error in persisting RpAllVerificationResults entity.  ", pe);
         }
       
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RpAllVerificationResults> getListByBypersonId(long personId) {
        Query query = em.createNamedQuery("RpAllVerificationResults.getListBypersonId");
        query.setParameter("personId", personId);
        
        return query.getResultList();   
    }

    @Override
    public RpAllVerificationResults getByPersonId(long personId) {
        List<RpAllVerificationResults> results = getListByBypersonId(personId);
        
        return results.isEmpty()? null : results.get(0);    
    }    
}
