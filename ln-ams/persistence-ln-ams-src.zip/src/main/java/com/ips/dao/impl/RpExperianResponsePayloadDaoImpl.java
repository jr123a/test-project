package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RpExperianResponsePayloadDao;
import com.ips.entity.RpExperianResponsePayload;

@Repository
public class RpExperianResponsePayloadDaoImpl extends GenericJPADAO<RpExperianResponsePayload, Long> implements RpExperianResponsePayloadDao  {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RpExperianResponsePayload> getAll() {        
        Query query = em.createNamedQuery("RpExperianResponsePayload.getAll");
        return query.getResultList();
    }

    @Override
    public RpExperianResponsePayload getById(Long id) {        
        return super.getById(id);
    }
    
    @Override
    @Transactional
    public void update(RpExperianResponsePayload entity) {
        try {
            super.merge(entity);
            em.flush();
        } catch (PersistenceException pe) {
            CustomLogger.error(this.getClass(), "Error in merging RpExperianResponsePayload entity.  ", pe);
        }
    }
    
    @Override
    public void create(RpExperianResponsePayload entity) {
    	 try {
     	        super.persist(entity);          
    	 } catch (PersistenceException pe) {
             CustomLogger.error(this.getClass(), "Error in persisting RpExperianResponsePayload entity.  ", pe);
         }
       
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RpExperianResponsePayload> getListByResultIdServiceName(long resultId, String serviceName) {
        Query query = em.createNamedQuery("RpExperianResponsePayload.getListByResultIdServiceName");
        query.setParameter("resultId", resultId);
        query.setParameter("serviceName", serviceName);
        
        return query.getResultList();   
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RpExperianResponsePayload> getListByResultIdSequenceIdServiceName(long resultId, String sequenceId, String serviceName) {
        Query query = em.createNamedQuery("RpExperianResponsePayload.getListByResultIdSequenceIdServiceName");
        query.setParameter("resultId", resultId);
        query.setParameter("sequenceId", sequenceId);
        query.setParameter("serviceName", serviceName);
       
        
        return query.getResultList();   
    }
    
    @Override
    public RpExperianResponsePayload getByResultIdServiceName(long resultId, String serviceName) {
        List<RpExperianResponsePayload> results = getListByResultIdServiceName(resultId, serviceName);
        
        return results.isEmpty()? null : results.get(0);    
    }    
}
