package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefIppEventStatus;


public interface RefIppEventStatusDao {
    Collection<RefIppEventStatus> getAll();    
    RefIppEventStatus getById(Long id);
    void save(RefIppEventStatus status);
    void update(RefIppEventStatus status);
    void delete(RefIppEventStatus status);
    RefIppEventStatus findByDescription(String newIpEvent);
}
