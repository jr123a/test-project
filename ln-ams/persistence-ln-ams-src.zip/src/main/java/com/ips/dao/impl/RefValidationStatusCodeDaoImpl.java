package com.ips.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefValidationStatusCodeDao;
import com.ips.entity.RefValidationStatusCode;


@Repository
public class RefValidationStatusCodeDaoImpl extends GenericJPADAO<RefValidationStatusCode, Long> implements
    RefValidationStatusCodeDao,Serializable  {


    private static final long serialVersionUID = 1L;

    @Override
    public void update(RefValidationStatusCode app) {
        super.merge(app);
        em.flush();
    }

    @SuppressWarnings("unchecked")
    @Override
    public RefValidationStatusCode getByName(String name) {
        Query query = em.createNamedQuery("RefValidationStatusCode.findByCode");
        query.setParameter("code", name);
        List<RefValidationStatusCode> results = query.getResultList();
        
        if (results.isEmpty()) {
            return null;
        } 
        else {
            return results.get(0);
        }        
    }

}

