package com.ips.dao;

import java.util.List;

import com.ips.entity.IppBarcodeScans;

public interface IppBarcodeScansDao {

    List<IppBarcodeScans> list();

    IppBarcodeScans getInvalidScanFromId(long invalidScanId);

    void save(IppBarcodeScans invalidScan);

    IppBarcodeScans merge(IppBarcodeScans invalidScan);

    void delete(IppBarcodeScans invalidScan);

}
