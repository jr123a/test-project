package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.Person;
import com.ips.entity.RpProofingSession;

public interface RpProofingSessionDao {
    
    Collection<RpProofingSession> getAll();    
    RpProofingSession getById(Long id);
    void create(RpProofingSession proofingSession);
    void update(RpProofingSession proofingSession);
    void delete(RpProofingSession proofingSession);
    List<RpProofingSession> findRpSessionByPerson(Person person);
    List<Long> findSumOfTotalAttempts(Person person);
}
