package com.ips.dao;

import com.ips.entity.RefRpDecisionCode;


public interface RefRpDecisionCodeDao {

	RefRpDecisionCode findByDecisionCode(String decisionCode);
}
