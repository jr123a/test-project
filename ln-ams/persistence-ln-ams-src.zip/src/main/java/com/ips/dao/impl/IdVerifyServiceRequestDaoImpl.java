package com.ips.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.IdVerifyServiceRequestDao;
import com.ips.entity.IdVerifyServiceRequest;

@Repository
public class IdVerifyServiceRequestDaoImpl extends GenericJPADAO<IdVerifyServiceRequest, Long> implements IdVerifyServiceRequestDao{
    
    @Override
    public void save(IdVerifyServiceRequest request) {
        super.save(request);
    }
    
    @Override
    public void update(IdVerifyServiceRequest request) {
        super.merge(request);
        
    }
    
    @Override
    public void delete(IdVerifyServiceRequest request) {
        super.delete(request);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<IdVerifyServiceRequest> getServiceRequestsForEvent(long eventId) {
        List<IdVerifyServiceRequest> list = new ArrayList<IdVerifyServiceRequest>();
        Query query = em.createNamedQuery("IdVerifyServiceRequest.getByEvent");
        query.setParameter("eventId", eventId);
        List<IdVerifyServiceRequest> results = query.getResultList();
        // Create a mutable list so it can be sorted
        list.addAll(results);
        return list;
    }
    
    @Override
    public List<IdVerifyServiceRequest> findIdVerifyServiceRequestBySponsor(long sponsorId) {
        @SuppressWarnings("unchecked")
		List<IdVerifyServiceRequest> list = em.createNamedQuery("IdVerifyServiceRequest.findIdVerifyServiceRequestBySponsor").setParameter("sponsorId", sponsorId).getResultList();
        return list == null || list.isEmpty() ? null : list;
    }
}
