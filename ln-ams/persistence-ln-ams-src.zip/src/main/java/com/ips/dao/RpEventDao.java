package com.ips.dao;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefSponsor;
import com.ips.entity.RpDeviceReputationResponse;
import com.ips.entity.RpEvent;
import com.ips.persistence.common.AuditPersonVo;
import com.ips.persistence.common.AutomatedTransactionReportVo;
import java.time.LocalDateTime;

public interface RpEventDao {

    Collection<RpEvent> getAll();
    RpEvent getById(Long id);
    void create(RpEvent entity);
    void update(RpEvent rpEvent);
    void delete(RpEvent rpEvent);
    List<RpEvent> getEventByPersonId(long personId);
    List<RpEvent> getEventBySponsorUserId(String sponsorUserId);
    List<Long> countEventIds(long personId, long supplierId, Timestamp window, Timestamp current);
    RpEvent getRpEventById(long eventId);
    List<RpEvent> getRpEventsInWindow(long personId, long supplierId, Timestamp window, Timestamp current);
    List<Long> countRpEvents(long personId, long supplierId);
    List<Long> ctRpEventsPerDate(Date start, Date end, RefLoaLevel loaLevel, RefSponsor refSponsor);
    List<Long> ctRpEventsPerDateByDecision(String decision, Date start, Date end, RefLoaLevel loaLevel, RefSponsor refSponsor);
    List<Long> ctRpEventsPerDateNoDecision(Date start, Date end, RefLoaLevel loaLevel, RefSponsor refSponsor);
    Long getEnteredIVSCount(Date start, Date end);
    Long getIVSLockoutCount(Date start, Date end);
    Long getPatternRecognitionCount(Date start, Date end);
    Long getEquifaxErrorsCount(Date start, Date end);
    Long getFieldCheckErrorsCount(Date start, Date end);
    Long getNoQuestionsCount(Date start, Date end);
    Long getTakenBySupplier(Date start, Date end, RefLoaLevel loaLevel, long supplierId, RefSponsor refSponsor);
    Long getIncompleteBySupplier(Date start, Date end, RefLoaLevel loaLevel, long supplierId, RefSponsor refSponsor);
    Long getLexisVelocityCount(Date start, Date end);
    Long getLexisErrorsCount(Date start, Date end);
    Long getVerifyFailureCount(Date start, Date end);
    Long getTotalEventsByLevelAndSupplier(Date start, Date end, RefLoaLevel loaLevel, long supplierId, RefSponsor refSponsor);
    Long getTotalEventsByLevel(Date start, Date end, RefLoaLevel loaLevel, RefSponsor refSponsor);
    RpEvent getEventByTransactionId(String transactionId);
    RpEvent findLatestEventByPersonId(long personId);
    RpEvent getLatestPhoneVerification(long personId, long supplierId);
    RpEvent getLatestPhoneEventsByPersonIdAndPhoneNumber(long personId, String mobilePhoneNumber);
    Long getCountInWindow(long personId, long supplierId, Timestamp window, Timestamp current);
    Long getPhoneCountInWindow(long personId, long supplierId, int attemptWindow);
    Long getRepeatPhoneAssessmentCountInWindow(long personId, long supplierId, int attemptWindow);
    List<RpEvent> getPhoneEventsInWindow(long personId, long supplierId, Timestamp window, Timestamp current);
    List<RpEvent> getEventsInWindow(Date startTime, Date endDate);
    List<AutomatedTransactionReportVo> getAutomatedTransactions(long sponsorId, LocalDateTime start, LocalDateTime end); 
    int getEventCountByApplicationId(long appId);
    List<AuditPersonVo> getAuditPersonList(long sponsorId, String sponsorUserId);
}
