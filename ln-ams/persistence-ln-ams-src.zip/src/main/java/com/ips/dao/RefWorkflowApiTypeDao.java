package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefWorkflowApiType;

public interface RefWorkflowApiTypeDao {
	Collection<RefWorkflowApiType> getAll();
	RefWorkflowApiType findApiTypeId(long id);
	RefWorkflowApiType findByApiTypeCode(String apiTypeCode);
	void update(RefWorkflowApiType entity);
	void create(RefWorkflowApiType entity);
}
