package com.ips.dao;

import java.util.Collection;
import java.util.List;

import com.ips.entity.RpVerifyBusinessResponse;


public interface RpVerifyBusinessResponseDao {

    Collection<RpVerifyBusinessResponse> getAll();    
    RpVerifyBusinessResponse getById(Long id);
    void create(RpVerifyBusinessResponse entity);
    void update(RpVerifyBusinessResponse entity);
    List<RpVerifyBusinessResponse> getListByPersonId(long personId);
    RpVerifyBusinessResponse getByPersonId(long personId);
 }
