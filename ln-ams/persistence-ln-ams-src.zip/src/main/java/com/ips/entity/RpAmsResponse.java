package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rp_ams_response")
@NamedQueries({
		@NamedQuery(name = "RpAmsResponse.getAll", query = "SELECT r FROM RpAmsResponse r"),
        @NamedQuery(name = "RpAmsResponse.getListByPersonId", query = "SELECT r FROM RpAmsResponse r WHERE r.person.personId = :personId ORDER BY r.createDate DESC")
})

public class RpAmsResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RPAMSRESPONSESEQ")
    @SequenceGenerator(name="RPAMSRESPONSESEQ",sequenceName="RP_AMS_RESPONSE_SEQ", allocationSize=1)
    
    @Column(name = "AMS_RESPONSE_ID")
    private long amsResponseId;

    // bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name = "PERSON_ID")
    private Person person;

	@Column(name = "REQUEST")
    private String request;
    
    @Column(name = "RESPONSE")
    private String response;
    
    @Column(name = "TRANSACTION_ORIGIN_ID", insertable = false, updatable = false)
    private long transactionOriginId;
    
    //bi-directional many-to-one association to RefApp
    @ManyToOne
    @JoinColumn(name="TRANSACTION_ORIGIN_ID")
    private RefApp refApp;
       
    @Column(name = "DECISION")
    private String decision;
    
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "UPDATE_DATE")
    private Date updateDate;

   

    public long getAmsResponseId() {
		return amsResponseId;
	}

	public void setAmsResponseId(long amsResponseId) {
		this.amsResponseId = amsResponseId;
	}

	public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public long getTransactionOriginId() {
		return transactionOriginId;
	}

	public RefApp getRefApp() {
		return refApp;
	}

	public void setRefApp(RefApp refApp) {
		this.refApp = refApp;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

}
