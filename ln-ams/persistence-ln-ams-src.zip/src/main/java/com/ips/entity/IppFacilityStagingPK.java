package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the rp_kba_attempts database table.
 * 
 */
@Embeddable
public class IppFacilityStagingPK implements Serializable {
   
    private static final long serialVersionUID = 1L;

    @Column(name="FACILITY_ID")
    private long facilityId;
    
    @Column(name="UFN")
    private String ufn;
   

    public long getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(long facilityId) {
		this.facilityId = facilityId;
	}

	public String getUfn() {
		return ufn;
	}

	public void setUfn(String ufn) {
		this.ufn = ufn;
	}

	public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof IppFacilityStagingPK)) {
            return false;
        }
        IppFacilityStagingPK castOther = (IppFacilityStagingPK)other;
        return 
            (this.facilityId == castOther.facilityId)
            && (this.ufn.equals(castOther.ufn));
    }

    public int hashCode() {
        final long prime = 31;
        long hash = 17;
        hash = hash * prime + this.facilityId;
        hash = hash * prime + (this.ufn == null ? 0 : this.ufn.hashCode());
         
        return (int) hash;
    }
}
