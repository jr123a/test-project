package com.ips.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the ref_device_types database table.
 * 
 */
@Entity
@Table(name = "ref_device_types")
@NamedQueries({ 
    @NamedQuery(name = "RefDeviceTypes.findAll", query = "SELECT i FROM RefDeviceTypes i "),
    @NamedQuery(name = "RefDeviceTypes.findByDeviceId", query = "SELECT i FROM RefDeviceTypes i WHERE i.deviceTypeId = :device")
    })
public class RefDeviceTypes implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "DEVICE_TYPE_ID")
    private long deviceTypeId;

    @Column(name = "DESCRIPTION")
    private String description;

    public long getDeviceTypeId() {
        return deviceTypeId;
    }

    public void setDeviceTypeId(long deviceTypeId) {
        this.deviceTypeId = deviceTypeId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
