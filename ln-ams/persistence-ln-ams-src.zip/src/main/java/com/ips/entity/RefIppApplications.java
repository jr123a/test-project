package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ref_ipp_applications database table.
 * 
 */
@Entity
@Table(name="ref_ipp_applications")
@NamedQueries({
    @NamedQuery(name="RefIppApplications.findByApplicationAcronym", query = "Select r FROM RefIppApplications r WHERE r.applicationAcronym = :appAcronym"),
    @NamedQuery(name="RefIppApplications.findAll", query = "Select r FROM RefIppApplications r "),
    @NamedQuery(name="RefIppApplications.findByApplicationId", query = "SELECT r FROM RefIppApplications r WHERE r.ippApplicationId = :appId")
})    
public class RefIppApplications implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="IPP_APPLICATION_ID")
    private long ippApplicationId;
    
    @Column(name="APPLICATION_ACRONYM")
    private String applicationAcronym;
    
    @Column(name="CREATE_DATE")
    private Date createDate;
            
    public long getIppApplicationId() {
        return ippApplicationId;
    }

    public void setIppApplicationId(long ippApplicationId) {
        this.ippApplicationId = ippApplicationId;
    }

    public String getApplicationAcronym() {
        return applicationAcronym;
    }

    public void setApplicationAcronym(String applicationAcronym) {
        this.applicationAcronym = applicationAcronym;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((applicationAcronym == null) ? 0 : applicationAcronym.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + (int) (ippApplicationId ^ (ippApplicationId >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefIppApplications other = (RefIppApplications) obj;
        if (applicationAcronym == null) {
            if (other.applicationAcronym != null)
                return false;
        } else if (!applicationAcronym.equals(other.applicationAcronym))
            return false;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (ippApplicationId != other.ippApplicationId)
            return false;
        return true;
    }
}
