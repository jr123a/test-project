package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the rp_kba_attempts database table.
 * 
 */
@Embeddable
public class RpOtpAttemptConfigPK implements Serializable {
    //default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;

    @Column(name="PROOFING_LEVEL")
    private long proofingLevel;
    
    @Column(name="SPONSOR_ID")
    private long sponsorId;
    
    @Column(name="KBA_SUPPLIER_ID")
    private long otpSupplierId;

    public long getProofingLevel() {
        return proofingLevel;
    }

    public void setProofingLevel(long proofingLevel) {
        this.proofingLevel = proofingLevel;
    }

    public long getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }
    
    public long getOtpSupplierId() {
        return this.otpSupplierId;
    }
    public void setOtpSupplierId(long otpSupplierId) {
        this.otpSupplierId = otpSupplierId;
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RpOtpAttemptConfigPK)) {
            return false;
        }
        RpOtpAttemptConfigPK castOther = (RpOtpAttemptConfigPK)other;
        return 
            (this.proofingLevel == castOther.proofingLevel)
            && (this.otpSupplierId == castOther.otpSupplierId);
    }

    public int hashCode() {
        final long prime = 31;
        long hash = 17;
        hash = hash * prime + this.proofingLevel;
        hash = hash * prime + this.otpSupplierId;
        
        return (int) hash;
    }
}
