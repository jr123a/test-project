package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rp_truth_data_send_response")
@NamedQueries({ @NamedQuery(name = "RpTruthDataSendResponse.getAll", query = "SELECT r FROM RpTruthDataSendResponse r"),
        @NamedQuery(name = "RpTruthDataSendResponse.getByRequestId", query = "SELECT r FROM RpTruthDataSendResponse r WHERE r.requestId = :requestId"),
        @NamedQuery(name = "RpTruthDataSendResponse.getListByPersonId", query = "SELECT r FROM RpTruthDataSendResponse r WHERE r.person.personId = :personId ORDER BY r.createDate DESC"),
        @NamedQuery(name = "RpTruthDataSendResponse.getByEventId", query = "SELECT r FROM RpTruthDataSendResponse r WHERE r.refTruthDataSendEvent.eventId = :eventId ORDER BY r.createDate DESC")
})


public class RpTruthDataSendResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="rp_truth_data_send_responseSeq")
    @SequenceGenerator(name="rp_truth_data_send_responseSeq",sequenceName="RP_TRUTH_DATA_SEND_RESPONSE_SEQ", allocationSize=1)
    @Column(name = "truth_data_send_response_id")
    private long truthDataSendResponseId;

    @Column(name = "request_id")
    private String requestId;

    // bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name = "person_id")
    private Person person;

    // bi-directional many-to-one association to RpDeviceReputation
    @ManyToOne
    @JoinColumn(name = "event_type")
    private RefTruthDataSendEvent refTruthDataSendEvent;
    
    @Column(name = "response")
    private String response;
    
    @Column(name = "create_date")
    private Date createDate;

    @Column(name = "update_date")
    private Date updateDate;

    public long getTruthDataSendResponseId() {
        return truthDataSendResponseId;
    }

    public void setTruthDataSendResponseId(long truthDataSendResponseId) {
        this.truthDataSendResponseId = truthDataSendResponseId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public RefTruthDataSendEvent getRefTruthDataSendEvent() {
        return refTruthDataSendEvent;
    }

    public void setRefTruthDataSendEvent(RefTruthDataSendEvent refTruthDataSendEvent) {
        this.refTruthDataSendEvent = refTruthDataSendEvent;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

}
