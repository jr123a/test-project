package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ref_phone_match_qualities database table.
 * 
 */
@Entity
@Table(name="ref_phone_match_qualities")
@NamedQueries({
    @NamedQuery(name="RefPhoneMatchQuality.findAll", query="SELECT r FROM RefPhoneMatchQuality r"),
    @NamedQuery(name="RefPhoneMatchQuality.findByName", query="Select r FROM RefPhoneMatchQuality r WHERE r.matchQuality = :name")
})    
public class RefPhoneMatchQuality implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="phone_match_quality_id")
    private long matchQualityId;
    
    @Column(name="match_quality")
    private String matchQuality;
    
    @Column(name="description")
    private String description;
    
    @Column(name="create_date")
    private Timestamp createDate;
        
    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public long getMatchQualityId() {
        return matchQualityId;
    }

    public void setMatchQualityId(long matchQualityId) {
        this.matchQualityId = matchQualityId;
    }

    public String getMatchQuality() {
        return matchQuality;
    }

    public void setMatchQuality(String matchQuality) {
        this.matchQuality = matchQuality;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
