package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the rp_kba_attempts database table.
 * 
 */
@Entity
@Table(name="rp_kba_attempts")
@NamedQueries({
    @NamedQuery(name="RpOtpAttemptConfig.findAll", query="SELECT a FROM RpOtpAttemptConfig a"),

    @NamedQuery(name="RpOtpAttemptConfig.findByProofingLevel", 
    query="SELECT a FROM RpOtpAttemptConfig a WHERE a.id.proofingLevel = :proofingLevel " + 
            "AND a.id.sponsorId = :sponsorId " +
            "AND a.refOtpSupplier.otpSupplierId IN :otpSupplierIds " +
            "ORDER BY a.refOtpSupplier.otpSupplierName ASC"),

    @NamedQuery(name="RpOtpAttemptConfig.findByPrimaryKey", 
    query="SELECT a FROM RpOtpAttemptConfig a WHERE a.id.proofingLevel = :proofingLevel " + 
            "AND a.id.sponsorId = :sponsorId " +
            "AND a.refOtpSupplier.otpSupplierId = :otpSupplierId " +
            "ORDER BY a.refOtpSupplier.otpSupplierName ASC"),

    // findByProofingLevelSorted is the query that retrieves the supplier to call based on the
    // configured percentages.  It MUST ONLY return rows where total_attempts is not 0.  If total_attempts
    // is 0, then the supplier should never be called.
    @NamedQuery(name="RpOtpAttemptConfig.findByProofingLevelSorted", 
    query="SELECT a FROM RpOtpAttemptConfig a " +
        "WHERE a.id.proofingLevel = :proofingLevel " +
        "AND a.id.sponsorId = :sponsorId " +
        "AND a.refOtpSupplier.otpSupplierId IN :otpSupplierIds " +
        "AND a.totalAttempts <> 0 " +
        "ORDER BY a.attempts ASC, a.refOtpSupplier.otpSupplierId DESC")
})
public class RpOtpAttemptConfig implements Serializable {
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private RpOtpAttemptConfigPK id;

    private int attempts;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="MODIFY_CONFIGURATION_TIME")
    private Timestamp modifyConfigurationTime;

    @Column(name="MODIFY_CONFIGURATION_USERID")
    private String modifyConfigurationUserid;

    @Column(name="TOTAL_ATTEMPTS")
    private int totalAttempts;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    private long version;

    //bi-directional many-to-one association to RefOtpSupplier
    @ManyToOne
    @JoinColumn(name="KBA_SUPPLIER_ID", insertable = false, updatable = false)
    private RefOtpSupplier refOtpSupplier;

    public RpOtpAttemptConfigPK getId() {
        return id;
    }
    
    public void setId(RpOtpAttemptConfigPK id) {
        this.id = id;
    }

    public int getAttempts() {
        return this.attempts;
    }

    public void setAttempts(int attempts) {
        this.attempts = attempts;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getModifyConfigurationTime() {
        return this.modifyConfigurationTime;
    }

    public void setModifyConfigurationTime(Timestamp modifyConfigurationTime) {
        this.modifyConfigurationTime = modifyConfigurationTime;
    }

    public String getModifyConfigurationUserid() {
        return this.modifyConfigurationUserid;
    }

    public void setModifyConfigurationUserid(String modifyConfigurationUserid) {
        this.modifyConfigurationUserid = modifyConfigurationUserid;
    }

    public int getTotalAttempts() {
        return this.totalAttempts;
    }

    public void setTotalAttempts(int totalAttempts) {
        this.totalAttempts = totalAttempts;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public long getVersion() {
        return this.version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

}
