package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the ref_attribute_group database table.
 * 
 */
@Embeddable
public class RefAttributeGroupPK implements Serializable {
    //default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;

    @Column(name="ATTRIBUTE_INDEX")
    private short attributeIndex;
    
    @Column(name="ATTRIBUTE_NAME")
    private String attributeName;

    public short getAttributeIndex() {
        return attributeIndex;
    }

    public void setAttributeIndex(short attributeIndex) {
        this.attributeIndex = attributeIndex;
    }

    public String getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RefAttributeGroupPK)) {
            return false;
        }
        RefAttributeGroupPK castOther = (RefAttributeGroupPK)other;
        return 
            (this.attributeIndex == castOther.attributeIndex)
            && (this.attributeName.equals(castOther.attributeName));
    }

    @Override
    public int hashCode() {
        final int prime = 37;
        int hash = 15;
        hash = (int) (hash * prime + this.attributeIndex);
        hash = (int) (hash * prime + this.attributeName.hashCode());
        
        return hash;
    }
}
