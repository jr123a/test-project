package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the application_workflows database table.
 * 
 */
@Entity
@Table(name = "ips_own.application_workflows")
@NamedQuery(name = "ApplicationWorkflows.findAll", query = "SELECT i FROM ApplicationWorkflows i order by i.createDate desc")
@NamedQuery(name = "ApplicationWorkflows.findWorkflow", query = "SELECT r FROM ApplicationWorkflows r where r.refIppApplications.ippApplicationId = :acr"
                + " and r.refDeviceTypes.deviceTypeId = :device and r.refSponsor.sponsorId = :sponsor and r.refIppWorkflows.workflowId = :workflow")
@NamedQuery(name = "ApplicationWorkflows.findById", query = "SELECT i FROM ApplicationWorkflows i where i.applicationWorkflowId = :id")
@NamedQuery(name = "ApplicationWorkflows.findByApplicationDeviceLoaCodeSponsor", query = "SELECT r FROM ApplicationWorkflows r"
                + " WHERE r.refIppApplications.ippApplicationId = :appID"
                + " AND r.refDeviceTypes.deviceTypeId = :device"
                + " AND r.refIppWorkflows.refLoaLevel.loaCode = :loaCode"
                + " AND r.refSponsor.sponsorId = :sponsorId")
@NamedQuery(name="ApplicationWorkflows.findApplicationWorkflowsBySponsor", query="SELECT r FROM ApplicationWorkflows r WHERE r.refSponsor.sponsorId = :sponsorId")


public class ApplicationWorkflows implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="application_workflowsSeq")
    @SequenceGenerator(name="application_workflowsSeq",sequenceName="APPLICATION_WORKFLOWS_SEQ", allocationSize=1)
    @Column(name = "APPLICATION_WORKFLOW_ID")
    private long applicationWorkflowId;

    // many-to-one association to RefIppApplications
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
    @JoinColumn(name = "IPP_APPLICATION_ID")
    private RefIppApplications refIppApplications;

    // many-to-one association to RefDeviceTypes
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
    @JoinColumn(name = "DEVICE_TYPE_ID")
    private RefDeviceTypes refDeviceTypes;

    // many-to-one association to RefSponsor
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
    @JoinColumn(name = "SPONSOR_ID")
    private RefSponsor refSponsor;

    // many-to-one association to RefSponsor
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
    @JoinColumn(name = "WORKFLOW_ID")
    private RefIppWorkflows refIppWorkflows;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    public long getApplicationWorkflowId() {
        return applicationWorkflowId;
    }

    public void setApplicationWorkflowId(long applicationWorkflowId) {
        this.applicationWorkflowId = applicationWorkflowId;
    }

    public RefIppApplications getRefIppApplications() {
        return refIppApplications;
    }

    public void setRefIppApplications(RefIppApplications refIppApplications) {
        this.refIppApplications = refIppApplications;
    }

    public RefDeviceTypes getRefDeviceTypes() {
        return refDeviceTypes;
    }

    public void setRefDeviceTypes(RefDeviceTypes refDeviceTypes) {
        this.refDeviceTypes = refDeviceTypes;
    }

    public RefSponsor getRefSponsor() {
        return refSponsor;
    }

    public void setRefSponsor(RefSponsor refSponsor) {
        this.refSponsor = refSponsor;
    }

    public RefIppWorkflows getRefIppWorkflows() {
        return refIppWorkflows;
    }

    public void setRefIppWorkflows(RefIppWorkflows workflowId) {
        this.refIppWorkflows = workflowId;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

}
