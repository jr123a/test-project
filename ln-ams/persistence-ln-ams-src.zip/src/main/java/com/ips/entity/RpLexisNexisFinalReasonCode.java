package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the rp_lexis_nexis_final_reason_codes database table.
 * 
 */
@Entity
@Table(name="rp_lexisnexis_finalreason_code")
@NamedQueries({
    @NamedQuery(name="RpLexisNexisFinalReasonCode.getReasonCodeByEventId", query="SELECT e FROM RpLexisNexisFinalReasonCode e WHERE e.eventId = :eventId")
})
public class RpLexisNexisFinalReasonCode implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="LNRCSeq")
    @SequenceGenerator(name="LNRCSeq",sequenceName="SEQ_LEXISNEXIS_RC_ID", allocationSize=1)
    @Column(name="LEXISNEXIS_RC_ID")
    private long lexisNexisRCId;

    @Column(name="EVENT_ID")
    private long eventId;
    
    @Column(name="REASON_CODE")
    private String reasonCode;
    
    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    //bi-directional many-to-one association to RefOtpReasonCode
    @ManyToOne
    @JoinColumn(name="REASON_CODE", insertable=false, updatable=false)
    private RefOtpReasonCode refOtpReasonCode;
    
    //bi-directional many-to-one association to RpLexisNexisResult
    @ManyToOne
    @JoinColumn(name="EVENT_ID", insertable=false, updatable=false)
    private RpLexisNexisResult rpLexisNexisResult;

    public long getLexisNexisRCId() {
        return this.lexisNexisRCId;
    }

    public void setLexisNexisRCId(long lexisNexisRCId) {
        this.lexisNexisRCId = lexisNexisRCId;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public RefOtpReasonCode getRefOtpReasonCode() {
        return this.refOtpReasonCode;
    }

    public void setRefOtpReasonCode(RefOtpReasonCode refOtpReasonCode) {
        this.refOtpReasonCode = refOtpReasonCode;
    }

    public long getEventId() {
        return eventId;
    }

    public void setEventId(long eventId) {
        this.eventId = eventId;
    }

    public RpLexisNexisResult getRpLexisNexisResult() {
        return rpLexisNexisResult;
    }

    public void setRpLexisNexisResult(RpLexisNexisResult rpLexisNexisResult) {
        this.rpLexisNexisResult = rpLexisNexisResult;
    }

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

}
