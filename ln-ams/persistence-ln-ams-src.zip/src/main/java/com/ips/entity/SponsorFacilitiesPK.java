package com.ips.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class SponsorFacilitiesPK implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Column(name = "SPONSOR_ID")
    private long sponsorId;
    
    @Column(name = "REF_FACILITY_ID")
    private long refFacilityId;
    
    public long getSponsorId() {
        return sponsorId;
    }
    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }
    
    public long getRefFacilityId() {
        return refFacilityId;
    }
    public void setRefFacilityId(long refFacilityId) {
        this.refFacilityId = refFacilityId;
    }
    
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SponsorFacilitiesPK)) {
            return false;
        }
        SponsorFacilitiesPK cast = (SponsorFacilitiesPK) other;
        return this.sponsorId == cast.sponsorId && this.refFacilityId == cast.refFacilityId;
    }
    
    @Override
    public int hashCode() {
        final long prime = 31;
        long hash = 17;
        hash = hash * prime + this.sponsorId;
        hash = hash * prime + this.refFacilityId;
        return (int) hash;
    }
}
