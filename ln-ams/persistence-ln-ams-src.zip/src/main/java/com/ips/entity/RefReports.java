package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the ref_reports database table.
 * 
 */
@Entity
@Table(name="ref_reports")
@NamedQueries({
    @NamedQuery(name="RefReports.findAll", query="SELECT r FROM RefReports r"),
    @NamedQuery(name="RefReports.findBySponsor", query="SELECT r FROM RefReports r WHERE r.reportId IN (SELECT sr.reports.reportId FROM SponsorReports sr WHERE sr.sponsor.sponsorId = :sponsorId)"),
    @NamedQuery(name="RefReports.findForIppClientActiveSponsor", query="SELECT r FROM RefReports r WHERE r.reportId IN (1,2,3)")
})    
public class RefReports implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="REPORT_ID")
    private long reportId;

    @Column(name="NAME")
    private String name;
    
    @Column(name="DATE_RANGE_LIMIT")
    private long dateRangeLimit;
    
    @Column(name="CREATE_DATE")
    private Date createDate;
    
    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    public long getReportId() {
        return reportId;
    }

    public void setReportId(long reportId) {
        this.reportId = reportId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getDateRangeLimit() {
        return dateRangeLimit;
    }

    public void setDateRangeLimit(long dateRangeLimit) {
        this.dateRangeLimit = dateRangeLimit;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }


}
