package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "sponsor_email_values")
@NamedQuery(name="SponsorEmailValues.getEmailBySponsorIdAndEmailType", query="SELECT s FROM SponsorEmailValues s WHERE s.id.sponsorId = :sponsorId AND s.id.emailType = :emailType")
@NamedQuery(name="SponsorEmailValues.findSponsorEmailValuesBySponsor", query="SELECT r FROM SponsorEmailValues r WHERE r.id.sponsorId = :sponsorId")

public class SponsorEmailValues implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @EmbeddedId
    private SponsorEmailValuesPK id;
    
    @Lob
    @Column(name = "logo")
    private byte[] logo;
    
    @Column(name = "greeting")
    private String greeting;
    
    @Column(name = "email_body")
    private String emailBody;
    
    @Column(name = "closing")
    private String closing;
    
    @Column(name = "postscript")
    private String postscript;
    
    @Column(name = "subject")
    private String subject;
    
    @Column(name = "create_date")
    private Date createDate;
    
    @Column(name = "update_date")
    private Date updateDate;
    
    @Column(name = "include_usps_logo")
    private String includeUSPSLogo;
    
    @Column(name = "include_agency_logo")
    private String includeAgencyLogo;
    
    public SponsorEmailValuesPK getId() {
        return id;
    }
    public void setId(SponsorEmailValuesPK id) {
        this.id = id;
    }
    
    public byte[] getLogo() {
        return logo;
    }
    public void setLogo(byte[] logo) {
        this.logo = logo;
    }

    public String getEmailBody() {
        return emailBody;
    }
    public void setEmailBody(String emailBody) {
        this.emailBody = emailBody;
    }
    
    public String getGreeting() {
        return greeting;
    }
    public void setGreeting(String greeting) {
        this.greeting = greeting;
    }
    
    public String getClosing() {
        return closing;
    }
    public void setClosing(String closing) {
        this.closing = closing;
    }
    
    public String getPostscript() {
        return postscript;
    }
    public void setPostscript(String postscript) {
        this.postscript = postscript;
    }
    
    public String getSubject() {
        return subject;
    }
    public void setSubject(String subject) {
        this.subject = subject;
    }
    
    public Date getCreateDate() {
        return createDate;
    }
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
    
    public Date getUpdateDate() {
        return updateDate;
    }
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    
    public String getIncludeUSPSLogo() {
        return includeUSPSLogo;
    }
    public void setIncludeUSPSLogo(String includeUSPSLogo) {
        this.includeUSPSLogo = includeUSPSLogo;
    }
    
    public String getIncludeAgencyLogo() {
        return includeAgencyLogo;
    }
    public void setIncludeAgencyLogo(String includeAgencyLogo) {
        this.includeAgencyLogo = includeAgencyLogo;
    }
}
