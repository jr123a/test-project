package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.ips.persistence.common.IPSConstants;

import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ref_ipp_event_status database table.
 * 
 */
@Entity
@Table(name="ref_ipp_event_status")
@NamedQueries({
    @NamedQuery(name="RefIppEventStatus.findAll", query="SELECT r FROM RefIppEventStatus r"),
    @NamedQuery(name = "RefIppEventStatus.findByDesc", query = "SELECT s FROM RefIppEventStatus s WHERE s.eventStatusDescription = :status")
})    

public class RefIppEventStatus implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="ipp_event_status")
    private long ippEventStatus;

    @Column(name="create_date")
    private Timestamp createDate;
    
    @Column(name="event_status_description")
    private String eventStatusDescription;
    
    @Column(name="update_date")
    private Timestamp updateDate;

    //bi-directional many-to-one association to IppEvent
    @OneToMany(mappedBy="refIppEventStatus")
    private List<IppEvent> ippEvents;

    public long getIppEventStatus() {
        return this.ippEventStatus;
    }

    public void setIppEventStatus(long ippEventStatus) {
        this.ippEventStatus = ippEventStatus;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getEventStatusDescription() {
        return this.eventStatusDescription;
    }

    public void setEventStatusDescription(String eventStatusDescription) {
        this.eventStatusDescription = eventStatusDescription;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<IppEvent> getIppEvents() {
        return this.ippEvents;
    }

    public void setIppEvents(List<IppEvent> ippEvents) {
        this.ippEvents = ippEvents;
    }

    public IppEvent addIppEvent(IppEvent ippEvent) {
        getIppEvents().add(ippEvent);
        ippEvent.setRefIppEventStatus(this);

        return ippEvent;
    }

    public IppEvent removeIppEvent(IppEvent ippEvent) {
        getIppEvents().remove(ippEvent);
        ippEvent.setRefIppEventStatus(null);

        return ippEvent;
    }

    public boolean isIppFailed() {
        return IPSConstants.IPP_STATUS_FAILED.equalsIgnoreCase(this.getEventStatusDescription());
    }
    
    public boolean isIppPassed() {
        return IPSConstants.IPP_STATUS_PASSED.equalsIgnoreCase(this.getEventStatusDescription());
    }
    
    public boolean isIppNew(){
        return IPSConstants.IPP_STATUS_STARTED.equalsIgnoreCase(this.getEventStatusDescription());
    }

    public boolean isIppExpired() {
        return IPSConstants.IPP_STATUS_EXPIRED.equalsIgnoreCase(this.getEventStatusDescription());
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((eventStatusDescription == null) ? 0 : eventStatusDescription.hashCode());
        result = prime * result + (int) (ippEventStatus ^ (ippEventStatus >>> 32));
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefIppEventStatus other = (RefIppEventStatus) obj;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (eventStatusDescription == null) {
            if (other.eventStatusDescription != null)
                return false;
        } else if (!eventStatusDescription.equals(other.eventStatusDescription))
            return false;
        if (ippEventStatus != other.ippEventStatus)
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }
    
}
