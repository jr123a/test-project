package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "RP_SUPPLIER_TOKEN")
@NamedQueries({
    @NamedQuery(name="RpSupplierToken.findByCode", query = "SELECT r FROM RpSupplierToken r WHERE r.tokenCode =:code"),
    @NamedQuery(name="RpSupplierToken.findByType", query = "SELECT r FROM RpSupplierToken r WHERE r.tokenType =:type"),
    @NamedQuery(name="RpSupplierToken.findByCodeAndType", query = "SELECT r FROM RpSupplierToken r WHERE r.tokenCode =:code"
    		+ " AND r.tokenType =:type ORDER BY r.updateDate DESC"),
})  

public class RpSupplierToken implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RP_SUPPLIER_TOKENSeq")
    @SequenceGenerator(name="RP_SUPPLIER_TOKENSeq",sequenceName="RP_SUPPLIER_TOKEN_SEQ", allocationSize=1)
    @Column(name="TOKEN_ID")
    private long tokenId;

    @Column(name="TOKEN_CODE")
    private String tokenCode;
    
    @Column(name="TOKEN_TYPE")
    private String tokenType;
    
    @Column(name="ACCESS_TOKEN")
    private String accessToken;
     
    @Column(name="EXPIRES_IN")
    private long expiresIn;
    
    @Column(name = "ISSUE_TIME")
    private Timestamp issueTime;
    
    @Column(name = "EXPIRATION_TIME")
    private Timestamp expirationTime;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;

	public long getTokenId() {
		return tokenId;
	}

	public void setTokenId(long tokenId) {
		this.tokenId = tokenId;
	}

	public String getTokenCode() {
		return tokenCode;
	}

	public void setTokenCode(String tokenCode) {
		this.tokenCode = tokenCode;
	}

	public String getTokenType() {
		return tokenType;
	}

	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public long getExpiresIn() {
		return expiresIn;
	}

	public void setExpiresIn(long expiresIn) {
		this.expiresIn = expiresIn;
	}

	public Timestamp getIssueTime() {
		return issueTime;
	}

	public void setIssueTime(Timestamp issueTime) {
		this.issueTime = issueTime;
	}

	public Timestamp getExpirationTime() {
		return expirationTime;
	}

	public void setExpirationTime(Timestamp expirationTime) {
		this.expirationTime = expirationTime;
	}

	public Timestamp getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public Timestamp getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}
	
    public boolean hasExpired() {
    	if (getExpirationTime() == null) {
    		return false;
    	}
    	
        Date currentTime = new Date();
        Date expirationDate = new Date(getExpirationTime().getTime()); 
    
        return expirationDate.before(currentTime);
    }

}
