package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="rp_dit_response")
@NamedQueries({
    @NamedQuery(name="RpDitResponse.getAll", query="SELECT r FROM RpDitResponse r"),
    @NamedQuery(name = "RpDitResponse.getListByPersonId", query = "SELECT r FROM RpDitResponse r WHERE r.person.personId = :personId ORDER BY r.createDate DESC")
})    
public class RpDitResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="rp_dit_responseSeq")
    @SequenceGenerator(name="rp_dit_responseSeq",sequenceName="RP_DIT_RESPONSE_SEQ", allocationSize=1)
    @Column(name="DIT_RESPONSE_ID")
    private long ditResponseId;
    
    // bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name = "PERSON_ID")
    private Person person;

    @Column(name="TRANSACTION_ID")
    private String transactionId;
    
    @Column(name="REQUEST")
    private String request;
    
    @Column(name="RESPONSE")
    private String response;
    
    @Column(name = "CREATE_DATE")
    private Date createDate;
    
    @Column(name = "UPDATE_DATE")
    private Date updateDate;

	
	public long getDitResponseId() {
		return ditResponseId;
	}

	public void setDitResponseId(long ditResponseId) {
		this.ditResponseId = ditResponseId;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	@Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (ditResponseId ^ (ditResponseId >>> 32));
        result = prime * result + (int) (person.getPersonId() ^ (person.getPersonId() >>> 32));
        result = prime * result + ((transactionId == null) ? 0 : transactionId.hashCode());
        result = prime * result + ((response == null) ? 0 : response.hashCode());
        result = prime * result + ((request == null) ? 0 : request.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RpDitResponse other = (RpDitResponse) obj;
        if (ditResponseId != other.ditResponseId)
            return false;
        if (person.getPersonId() != other.person.getPersonId())
            return false;
        if (transactionId == null) {
            if (other.transactionId != null)
                return false;
        } else if (!transactionId.equals(other.transactionId))
            return false;
        if (response == null) {
            if (other.response != null)
                return false;
        } else if (!response.equals(other.response))
            return false;
        if (request == null) {
            if (other.request != null)
                return false;
        } else if (!request.equals(other.request))
            return false;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }

}
