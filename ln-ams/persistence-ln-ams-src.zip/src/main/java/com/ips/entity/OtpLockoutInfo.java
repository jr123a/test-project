package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.ips.common.common.DateTimeUtil;

import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the kba_lockout_info database table.
 * 
 */
@Entity
@NamedQueries({
    
    @NamedQuery(name="OtpLockoutInfo.findByPersonID", query="SELECT k FROM OtpLockoutInfo k WHERE k.person.personId = :personid ORDER BY k.updateDate DESC"),
    @NamedQuery(name="OtpLockoutInfo.findCurrentLockoutForSupplier", 
        query="SELECT k FROM OtpLockoutInfo k WHERE k.person.personId = :personid " +
            " AND k.refOtpSupplier = :supplier AND k.refLoaLevel = :loaLevel AND k.lockoutFlag = 'Y'")
})    

@Table(name="kba_lockout_info")
public class OtpLockoutInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final String LOCKOUT_FLAG_ON = "Y";
    public static final String LOCKOUT_FLAG_OFF ="N";
    
    @EmbeddedId
    private OtpLockoutInfoPK id;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="LOCKOUT_EXPIRES_DATETIME")
    private Timestamp lockoutExpiresDatetime;

    @Column(name="LOCKOUT_FLAG")
    private String lockoutFlag;

    @Column(name="LOCKOUT_WINDOW")
    private int lockoutWindow;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;
    
    @Column(name="ivs_lockout_datetime")
    private Date ivsLockoutDateTime;
    
    @Column(name="kba_supplier_lockout_datetime")
    private Date otpLockoutDateTime;

    //bi-directional many-to-one association to RefOtpSupplier
    @ManyToOne
    @JoinColumn(name="KBA_Supplier_Id")
    private RefOtpSupplier refOtpSupplier;

    //bi-directional one-to-one association to Person
    @OneToOne
    @JoinColumn(name="Person_Id", insertable = false, updatable = false)
    private Person person;
    
    //many-to-one association to RefLoaLevel
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="LOA_CODE")
    private RefLoaLevel refLoaLevel;
    
    public OtpLockoutInfoPK getId() {
        return this.id;
    }

    public void setId(OtpLockoutInfoPK id) {
        this.id = id;
    }
	
	public RefLoaLevel getRefLoaLevel() {
		return refLoaLevel;
	}
	
	public void setRefLoaLevel(RefLoaLevel refLoaLevel) {
		this.refLoaLevel = refLoaLevel;
	}
	
	public Person getPerson() {
		return person;
	}
	
	public void setPerson(Person person) {
		this.person = person;
	}
	
    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getLockoutExpiresDatetime() {
        return this.lockoutExpiresDatetime;
    }

    public void setLockoutExpiresDatetime(Timestamp lockoutExpiresDatetime) {
        this.lockoutExpiresDatetime = lockoutExpiresDatetime;
    }

    public String getLockoutFlag() {
        return this.lockoutFlag;
    }

    public void setLockoutFlag(String lockoutFlag) {
        this.lockoutFlag = lockoutFlag;
    }

    public int getLockoutWindow() {
        return this.lockoutWindow;
    }

    public void setLockoutWindow(int lockoutWindow) {
        this.lockoutWindow = lockoutWindow;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public RefOtpSupplier getRefOtpSupplier() {
        return this.refOtpSupplier;
    }

    public void setRefOtpSupplier(RefOtpSupplier refOtpSupplier) {
        this.refOtpSupplier = refOtpSupplier;
    }

    public Date getIvsLockoutDateTime() {
        return ivsLockoutDateTime;
    }

    public void setIvsLockoutDateTime(Date ivsLockoutDateTime) {
        this.ivsLockoutDateTime = ivsLockoutDateTime;
    }

    public Date getOtpLockoutDateTime() {
        return otpLockoutDateTime;
    }

    public void setOtpLockoutDateTime(Date otpLockoutDateTime) {
        this.otpLockoutDateTime = otpLockoutDateTime;
    }
    
    public boolean stillInEffect() {
       	if (getLockoutExpiresDatetime() == null) {
       		return false;
       	}
       	
       	if (getLockoutFlag() == null) {
       		return false;
       	}

        return LOCKOUT_FLAG_ON.equals(getLockoutFlag()) && DateTimeUtil.getCurrentTime().before(getLockoutExpiresDatetime());
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((ivsLockoutDateTime == null) ? 0 : ivsLockoutDateTime.hashCode());
        result = prime * result + ((lockoutExpiresDatetime == null) ? 0 : lockoutExpiresDatetime.hashCode());
        result = prime * result + ((lockoutFlag == null) ? 0 : lockoutFlag.hashCode());
        result = prime * result + lockoutWindow;
        result = prime * result + ((otpLockoutDateTime == null) ? 0 : otpLockoutDateTime.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OtpLockoutInfo other = (OtpLockoutInfo) obj;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (ivsLockoutDateTime == null) {
            if (other.ivsLockoutDateTime != null)
                return false;
        } else if (!ivsLockoutDateTime.equals(other.ivsLockoutDateTime))
            return false;
        if (lockoutExpiresDatetime == null) {
            if (other.lockoutExpiresDatetime != null)
                return false;
        } else if (!lockoutExpiresDatetime.equals(other.lockoutExpiresDatetime))
            return false;
        if (lockoutFlag == null) {
            if (other.lockoutFlag != null)
                return false;
        } else if (!lockoutFlag.equals(other.lockoutFlag))
            return false;
        if (lockoutWindow != other.lockoutWindow)
            return false;
        if (otpLockoutDateTime == null) {
            if (other.otpLockoutDateTime != null)
                return false;
        } else if (!otpLockoutDateTime.equals(other.otpLockoutDateTime))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }
}
