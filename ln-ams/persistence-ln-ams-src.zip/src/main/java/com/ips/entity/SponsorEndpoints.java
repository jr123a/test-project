package com.ips.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="sponsor_endpoints")
@NamedQuery(name = "SponsorEndpoints.findByEnvironment", query = "SELECT i FROM SponsorEndpoints i WHERE i.environment = :env")
@NamedQuery(name="SponsorEndpoints.findSponsorEndpointsBySponsor", query="SELECT r FROM SponsorEndpoints r WHERE r.refSponsor.sponsorId = :sponsorId")

public class SponsorEndpoints implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ENDPOINT_ID")
    private long endpointId;

    // bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name = "SPONSOR_ID")
    private RefSponsor refSponsor;

    @Column(name = "ENVIRONMENT")
    private String environment;

    @Column(name = "ENDPOINT_URL")
    private String endpointURL;

    public long getEndpointId() {
        return endpointId;
    }

    public void setEndpointId(long endpointId) {
        this.endpointId = endpointId;
    }

    public RefSponsor getRefSponsor() {
        return refSponsor;
    }

    public void setRefSponsor(RefSponsor refSponsor) {
        this.refSponsor = refSponsor;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getEndpointURL() {
        return endpointURL;
    }

    public void setEndpointURL(String endpointURL) {
        this.endpointURL = endpointURL;
    }
}
