package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the rp_equifax_error database table.
 * 
 */
@Entity
@Table(name="rp_equifax_errors")
public class RpEquifaxError implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String NO_ERROR_MESSAGE_RETURNED = "No error message returned from supplier";
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="EFXErrorSeq")
    @SequenceGenerator(name="EFXErrorSeq",sequenceName="SEQ_EQUIFAX_ERROR_ID", allocationSize=1)
    @Column(name="EQUIFAX_ERROR_ID")
    private long equifaxErrorId;
    
    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;
    
    @Column(name="ERROR_CODE")
    private String errorCode;
    
    @Column(name="ERROR_MESSAGE")
    private String errorMessage;

    //bi-directional many-to-one association to RpEvent
    @ManyToOne
    @JoinColumn(name="EVENT_ID")
    private RpEvent rpEvent;

    public long getEquifaxErrorId() {
        return equifaxErrorId;
    }

    public void setEquifaxErrorId(long equifaxErrorId) {
        this.equifaxErrorId = equifaxErrorId;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public RpEvent getRpEvent() {
        return rpEvent;
    }

    public void setRpEvent(RpEvent rpEvent) {
        this.rpEvent = rpEvent;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

}
