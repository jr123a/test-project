package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the SponsorWebServicePending database table.
 * 
 */
@Entity
@Table(name = "sponsor_web_service_pending")
@NamedQuery(name = "SponsorWebServicePending.getPending", query = "select i from SponsorWebServicePending i"
                + "        where i.enrollmentCode = :enrollmentCode") 
@NamedQuery(name="SponsorWebServicePending.findSponsorWebServicePendingBySponsor", query="SELECT r FROM SponsorWebServicePending r WHERE r.refSponsor.sponsorId = :sponsorId")

public class SponsorWebServicePending implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SPONSOR_WEB_SERVICE_PENDINGSEQ")
    @SequenceGenerator(name="SPONSOR_WEB_SERVICE_PENDINGSEQ",sequenceName="SPONSOR_WEB_SERVICE_PENDING_SEQ", allocationSize=1)
    @Column(name = "QUEUE_ID")
    private long queueId;

    // bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name = "SPONSOR_ID")
    private RefSponsor refSponsor;

    @Column(name = "ENROLLMENT_CODE")
    private String enrollmentCode;

    @Column(name = "IPP_TRANSACTION_DATETIME")
    private Timestamp ippTransactionDatetime;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;

    public long getQueueId() {
        return queueId;
    }

    public void setQueueId(long queueId) {
        this.queueId = queueId;
    }

    public RefSponsor getRefSponsor() {
        return refSponsor;
    }

    public void setRefSponsor(RefSponsor refSponsor) {
        this.refSponsor = refSponsor;
    }

    public String getEnrollmentCode() {
        return enrollmentCode;
    }

    public void setEnrollmentCode(String enrollmentCode) {
        this.enrollmentCode = enrollmentCode;
    }

    public Timestamp getIppTransactionDatetime() {
        return ippTransactionDatetime;
    }

    public void setIppTransactionDatetime(Timestamp ippTransactionDatetime) {
        this.ippTransactionDatetime = ippTransactionDatetime;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

}
