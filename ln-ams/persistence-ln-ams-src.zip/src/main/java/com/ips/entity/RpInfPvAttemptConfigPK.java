package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the rp_inf_pv_attempts database table.
 * 
 */
@Embeddable
public class RpInfPvAttemptConfigPK implements Serializable {
    //default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;

    @Column(name="PROOFING_LEVEL")
    private long proofingLevel;
    
    @Column(name="SPONSOR_ID")
    private long sponsorId;
    
    @Column(name="SUPPLIER_ID")
    private long supplierId;

    public long getProofingLevel() {
        return proofingLevel;
    }

    public void setProofingLevel(long proofingLevel) {
        this.proofingLevel = proofingLevel;
    }

    public long getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }
    
    public long getSupplierId() {
        return this.supplierId;
    }
    public void setSupplierId(long supplierId) {
        this.supplierId = supplierId;
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RpInfPvAttemptConfigPK)) {
            return false;
        }
        RpInfPvAttemptConfigPK castOther = (RpInfPvAttemptConfigPK)other;
        return 
            (this.proofingLevel == castOther.proofingLevel)
            && (this.supplierId == castOther.supplierId);
    }

    public int hashCode() {
        final long prime = 31;
        long hash = 17;
        hash = hash * prime + this.proofingLevel;
        hash = hash * prime + this.supplierId;
        
        return (int) hash;
    }
}
