package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ref_phone_types database table.
 * 
 */
@Entity
@Table(name="ref_phone_types")
@NamedQueries({
    @NamedQuery(name="RefPhoneType.findAll", query="SELECT r FROM RefPhoneType r"),
    @NamedQuery(name="RefPhoneType.findByName", query="Select r FROM RefPhoneType r WHERE r.phoneType = :name")
})    
public class RefPhoneType implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String MOBILE_PHONE_TYPE = "MOBILE";
    
    @Id
    @Column(name="phone_type_id")
    private long phoneTypeId;
    
    @Column(name="phone_type")
    private String phoneType;
    
    @Column(name="create_date")
    private Timestamp createDate;
        
    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public long getPhoneTypeId() {
        return phoneTypeId;
    }

    public void setPhoneTypeId(long phoneTypeId) {
        this.phoneTypeId = phoneTypeId;
    }

    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }
    
    public boolean isMobile() {
        return getPhoneType().equalsIgnoreCase(MOBILE_PHONE_TYPE);
    }
}
