package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="rp_experian_decision_result")
@NamedQueries({
    @NamedQuery(name="RpExperianDecisionResult.getAll", query="SELECT r FROM RpExperianDecisionResult r"),
    @NamedQuery(name = "RpExperianDecisionResult.getListByPersonId", query = "SELECT r FROM RpExperianDecisionResult r WHERE r.rpEvent.personId = :personId ORDER BY r.createDate DESC"),
    @NamedQuery(name = "RpExperianDecisionResult.getListByEventId", query = "SELECT r FROM RpExperianDecisionResult r WHERE r.rpEvent.eventId = :eventId ORDER BY r.createDate DESC")
})    
public class RpExperianDecisionResult implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="rp_experian_decision_resultSeq")
    @SequenceGenerator(name="rp_experian_decision_resultSeq",sequenceName="RP_EXPERIAN_DECISION_RESULT_SEQ", allocationSize=1)
    @Column(name="EXP_RESULT_ID")
    private long expResultId;
    
    // bi-directional one-to-one association to RpEvent
    @OneToOne
    @JoinColumn(name = "EVENT_ID")
    private RpEvent rpEvent;
    
    @Column(name="CLIENT_REFERENCE_ID")
    private String clientReferenceId;
    
    @Column(name="CORRELATION_ID")
    private String correlationId;

    @Column(name="AUTHENTICATION_KEY")
    private String authenticationKey;   
    
    @Column(name="PRECISEID_TRANSACTION_ID")
    private String preciseIdTransactionId;
    
    @Column(name="PRECISEID_EXCLUSION_CODES")
    private String preciseIdExclusionCodes;
    
    @Column(name="PRECISEID_DECISION")
    private String preciseIdDecision;
    
    @Column(name="SERVICE_INFO_DECISION")
    private String serviceInfoDecision;
    
    @Column(name="BOKU_SCORE_DECISION")
    private String bokuScoreDecision;
    
    @Column(name="PNV_REQ_DECISION")
    private String pnvReqDecision;

    @Column(name="PNV_RES_DECISION")
    private String pnvResDecision;

    @Column(name="SEND_OTP_DECISION")
    private String sendOtpDecision;

    @Column(name="VALIDATE_OTP_DECISION")
    private String validateOtpDecision;

    @Column(name="FINAL_DECISION")
    private String finalDecision;

    @Column(name = "CREATE_DATE")
    private Date createDate;
    
    @Column(name = "UPDATE_DATE")
    private Date updateDate;

    @Transient
    private String bokuServiceType;
     
    
	public long getExpResultId() {
		return expResultId;
	}

	public void setExpResultId(long expResultId) {
		this.expResultId = expResultId;
	}

	public RpEvent getRpEvent() {
		return rpEvent;
	}

	public void setRpEvent(RpEvent rpEvent) {
		this.rpEvent = rpEvent;
	}

	public String getClientReferenceId() {
		return clientReferenceId;
	}

	public void setClientReferenceId(String clientReferenceId) {
		this.clientReferenceId = clientReferenceId;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getAuthenticationKey() {
		return authenticationKey;
	}

	public void setAuthenticationKey(String authenticationKey) {
		this.authenticationKey = authenticationKey;
	}

	public String getPreciseIdTransactionId() {
		return preciseIdTransactionId;
	}

	public void setPreciseIdTransactionId(String preciseIdTransactionId) {
		this.preciseIdTransactionId = preciseIdTransactionId;
	}

	public String getPreciseIdExclusionCodes() {
		return preciseIdExclusionCodes;
	}

	public void setPreciseIdExclusionCodes(String preciseIdExclusionCodes) {
		this.preciseIdExclusionCodes = preciseIdExclusionCodes;
	}

	public String getPreciseIdDecision() {
		return preciseIdDecision;
	}

	public void setPreciseIdDecision(String preciseIdDecision) {
		this.preciseIdDecision = preciseIdDecision;
	}

	public String getServiceInfoDecision() {
		return serviceInfoDecision;
	}

	public void setServiceInfoDecision(String serviceInfoDecision) {
		this.serviceInfoDecision = serviceInfoDecision;
	}

	public String getBokuScoreDecision() {
		return bokuScoreDecision;
	}

	public void setBokuScoreDecision(String bokuScoreDecision) {
		this.bokuScoreDecision = bokuScoreDecision;
	}

	public String getPnvReqDecision() {
		return pnvReqDecision;
	}

	public void setPnvReqDecision(String pnvReqDecision) {
		this.pnvReqDecision = pnvReqDecision;
	}

	public String getPnvResDecision() {
		return pnvResDecision;
	}

	public void setPnvResDecision(String pnvResDecision) {
		this.pnvResDecision = pnvResDecision;
	}

	public String getSendOtpDecision() {
		return sendOtpDecision;
	}

	public void setSendOtpDecision(String sendOtpDecision) {
		this.sendOtpDecision = sendOtpDecision;
	}

	public String getValidateOtpDecision() {
		return validateOtpDecision;
	}

	public void setValidateOtpDecision(String validateOtpDecision) {
		this.validateOtpDecision = validateOtpDecision;
	}

	public String getFinalDecision() {
		return finalDecision;
	}

	public void setFinalDecision(String finalDecision) {
		this.finalDecision = finalDecision;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	public String getBokuServiceType() {
		return bokuServiceType;
	}

	public void setBokuServiceType(String bokuServiceType) {
		this.bokuServiceType = bokuServiceType;
	}
	

}
