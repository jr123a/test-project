package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the lookup_codes_env database table.
 * 
 */
@Entity
@Table(name = "lookup_codes_env")
@NamedQuery(name = "LookupCodesEnv.getValueByEnvironmentForHoldMail", query = "SELECT i FROM LookupCodesEnv i where i.id.env = :env AND i.id.name = :name")
public class LookupCodesEnv implements Serializable {
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private LookupCodesEnvPK id;
       
    @Column(name = "VALUE")
    private String value;
    
    @Column(name = "OPT_LOCK")
    private Long optLock;
    
    @Column(name = "CREATE_DATE")
    private Timestamp createDate;
    
    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;
    
    @Column(name = "CREATE_USER")
    private String createUser;
    
    @Column(name = "UPDATE_USER")
    private String updateUser;

	public LookupCodesEnvPK getId() {
		return id;
	}

	public void setId(LookupCodesEnvPK id) {
		this.id = id;
	}
	
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public long getOptLock() {
        return optLock;
    }

    public void setOptLock(long optLock) {
        this.optLock = optLock;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

}
