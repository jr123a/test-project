package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the rp_equifax_final_reason_codes database table.
 * 
 */
@Entity
@Table(name="rp_equifax_final_reason_codes")
@NamedQuery(name="RpEquifaxFinalReasonCode.findAll", query="SELECT t FROM RpEquifaxFinalReasonCode t")
public class RpEquifaxFinalReasonCode implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RcSeq")
    @SequenceGenerator(name="RcSeq",sequenceName="SEQ_RP_EQUIFAX_RC_ID", allocationSize=1)
    @Column(name="EQUIFAX_RC_ID")
    private long equifaxRcId;    
        
    @Column(name="CREATE_DATE")
    private Timestamp createDate;
    
    @Column(name="REASON_CODE", insertable = false, updatable = false)
    private String reasonCode;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    //bi-directional many-to-one association to RpEquifaxResult
    @ManyToOne
    @JoinColumn(name="EVENT_ID")
    private RpEquifaxResult rpEquifaxResult;

    //bi-directional many-to-one association to RefEquifaxReasonCode
    @ManyToOne(cascade=CascadeType.MERGE, fetch=FetchType.EAGER)
    @JoinColumn(name="REASON_CODE")
    private RefOtpReasonCode refOtpReasonCode;

    public long getEquifaxRcId() {
        return this.equifaxRcId;
    }

    public void setEquifaxRcId(long equifaxRcId) {
        this.equifaxRcId = equifaxRcId;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public RpEquifaxResult getRpEquifaxResult() {
        return this.rpEquifaxResult;
    }

    public void setRpEquifaxResult(RpEquifaxResult rpEquifaxResult) {
        this.rpEquifaxResult = rpEquifaxResult;
    }

    public RefOtpReasonCode getRefOtpReasonCode() {
        return refOtpReasonCode;
    }

    public void setRefOtpReasonCode(RefOtpReasonCode refOtpReasonCode) {
        this.refOtpReasonCode = refOtpReasonCode;
    }
}
