package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the person_proofing_status database table.
 * 
 */
@Embeddable
public class PersonProofingStatusPK implements Serializable {
    //default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;

    @Column(name="PERSON_ID", insertable = false, updatable = false)
    private long personId;
    
    @Column(name="PROOFING_LEVEL_SOUGHT", insertable = false, updatable = false)
    private long proofingLevelSought = 0L;

    public long getPersonId() {
        return personId;
    }

    public void setPersonId(long personId) {
        this.personId = personId;
    }

    public long getProofingLevelSought() {
		return proofingLevelSought;
	}

	public void setProofingLevelSought(long proofingLevelSought) {
		this.proofingLevelSought = proofingLevelSought;
	}

	public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof PersonProofingStatusPK)) {
            return false;
        }
        PersonProofingStatusPK castOther = (PersonProofingStatusPK)other;
        return 
            (this.proofingLevelSought == castOther.proofingLevelSought)
            && (this.personId == castOther.personId);
    }

    public int hashCode() {
        final long prime = 31;
        long hash = 17;
        hash = hash * prime + this.proofingLevelSought;
        hash = hash * prime + this.personId;
        
        return (int) hash;
    }
}