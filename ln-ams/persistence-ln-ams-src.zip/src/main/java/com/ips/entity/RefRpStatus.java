package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.ips.persistence.common.IPSConstants;

import java.sql.Timestamp;


/**
 * The persistent class for the ref_rp_status database table.
 * 
 */
@Entity
@Table(name="ref_rp_status")
@NamedQueries({
    @NamedQuery(name="RefRpStatus.findAll", query="SELECT r FROM RefRpStatus r"),
    @NamedQuery(name="RefRpStatus.findByDescription", query="SELECT r FROM RefRpStatus r WHERE r.statusDescription = :statusDesc"),
    @NamedQuery(name="RefRpStatus.findByStatusCode", query="SELECT r FROM RefRpStatus r WHERE r.statusCode = :statusCode")
})    
public class RefRpStatus implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="status_code")
    private long statusCode;

    @Column(name="create_date")
    private Timestamp createDate;

    @Column(name="status_description")
    private String statusDescription;

    @Column(name="update_date")
    private Timestamp updateDate;
    
    public enum RpStatus {
        New_to_IPS_No_Proofing_Events(1L),    
        Remote_Proofing_Failed(2L),    
        Remote_Proofing_Passed(3L),    
        Opted_in_for_in_person_proofing(4L),    
        In_person_email_sent(5L),    
        Activation_email_sent(6L),    
        Remote_proofing_cancelled(7L),    
        In_person_proofing_failed(8L),    
        In_person_proofing_passed(9L),    
        LOA_level_achieved(10L),    
        Started_remote_proofing(11L),    
        Reproofing_due_to_attribute_change(12L),    
        IPP_at_residence_scheduled(13L),
        Opted_in_for_In_person_Proofing_at_Residence(14L),
        Profile_updated(15L),    
        LOA_2_0_expired(16L),    
        Phone_verification_initiated(17L),    
        Phone_verification_failed(18L),    
        Phone_verified(19L),    
        OTP_initiated(20L),    
        OTP_sent(21L),    
        OTP_confirmation_initiated(22L),    
        OTP_confirmation_failed(23L),    
        Identity_attempt_using_high_risk_address(24L),
        Attempt_with_Low_Confidence_device_reputation(25L),
        Started_device_reputation(26L),
    	SMFA_initiated(27L),
    	SMFA_sent(28L),
    	SMFA_validation_initiated(29L),
    	SMFA_validation_failed(30L),
       	Identity_verification_initiated(31L),
       	Identity_verification_passed(32L),
   	    Identity_verification_failed(33L),
  	    Silent_Authentication_initiated(34L),
  	    Silent_Authentication_passed(35L),
  	    Silent_Authentication_failed(36L),
  	    Device_email_assessment_initiated(37L),
  	    Device_email_assessment_passed(38L),
  	    Device_email_assessment_failed(39L),
    	AMS_address_check_initiated(40L),
    	AMS_address_check_passed(41L),
    	AMS_address_check_failed(42L),
    	BIID_verification_initiated(43L),
    	BIID_verification_passed(44L),
    	BIID_verification_failed(45L);
         
        private long value;
        
        private RpStatus(long value) {
            this.value = value;
        }
        
        public Long getValue() {
            return value;
        }
    }

    public String otpToString() {
        return "RefRpStatus [statusCode=" + statusCode + ", create_date=" + createDate + ", status_description="
                + statusDescription + ", update_date=" + updateDate + "]";
    }
    
    public long getStatusCode() {
        return this.statusCode;
    }

    public void setStatusCode(long statusCode) {
        this.statusCode = statusCode;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getStatusDescription() {
        return this.statusDescription;
    }

    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }
    
    public boolean isNew() {
        return IPSConstants.STATUS_NEW_TO_IPS.equalsIgnoreCase(this.getStatusDescription());
    }
    
    public boolean isRpFailed() {
        return IPSConstants.STATUS_RP_FAILED.equalsIgnoreCase(this.getStatusDescription());
    }
    
    public boolean isRpPassed() {
        return IPSConstants.STATUS_RP_PASSED.equalsIgnoreCase(this.getStatusDescription());
    }
    
    public boolean isIppOptIn() {
        return IPSConstants.STATUS_IPP_OPT_IN.equalsIgnoreCase(this.getStatusDescription());
    }
    
    public boolean isIppEmailSent() {
        return IPSConstants.STATUS_IPP_EMAIL_SENT.equalsIgnoreCase(this.getStatusDescription());
    }
    
    public boolean isRpCancelled() {
        return IPSConstants.STATUS_RP_CANCELLED.equalsIgnoreCase(this.getStatusDescription());
    }
    
    public boolean isIppFailed() {
        return IPSConstants.STATUS_IPP_FAILED.equalsIgnoreCase(this.getStatusDescription());
    }
    
    public boolean isIppPassed() {
        return IPSConstants.STATUS_IPP_PASSED.equalsIgnoreCase(this.getStatusDescription());
    }
    
    public boolean isLoaAchieved() {
        return IPSConstants.STATUS_LOA_ACHIEVED.equalsIgnoreCase(this.getStatusDescription());
    }
    
    public boolean isActivationEmailSent() {
        return IPSConstants.STATUS_ACTIVATION_EMAIL_SENT.equalsIgnoreCase(this.getStatusDescription());
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + (int) (statusCode ^ (statusCode >>> 32));
        result = prime * result + ((statusDescription == null) ? 0 : statusDescription.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefRpStatus other = (RefRpStatus) obj;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (statusCode != other.statusCode)
            return false;
        if (statusDescription == null) {
            if (other.statusDescription != null)
                return false;
        } else if (!statusDescription.equals(other.statusDescription))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }
}
