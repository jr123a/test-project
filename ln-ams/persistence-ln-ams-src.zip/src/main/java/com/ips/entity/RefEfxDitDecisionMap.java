package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ref_efx_dit_decision_map database table.
 * 
 */
@Entity
@Table(name="ref_efx_dit_decision_map")
@NamedQueries({ 
    @NamedQuery(name="RefEfxDitDecisionMap.findAll", query="SELECT r FROM RefEfxDitDecisionMap r order by r.decision")
})
public class RefEfxDitDecisionMap implements Serializable {
    private static final long serialVersionUID = 1L;
   
    public static final String DIT_DECISION_APPROVED = "APPROVE";
    public static final String DIT_DECISION_REVIEW= "REVIEW";
    public static final String DIT_DECISION_DENIED = "DENY";

    @Id
    @Column(name = "decision_map_id")
    private long decisionMapId;

    @Column(name = "identity_trust")
    private String identityTrust;

	@Column(name = "address_trust")
    private String addressTrust;

    @Column(name = "phone_trust")
    private String phoneTrust;
    
    @Column(name = "decision")
    private String decision;
    
    @Column(name = "create_date")
    private Date createDate;
    
    @Column(name = "update_date")
    private Date updateDate;

	public long getDecisionMapId() {
		return decisionMapId;
	}

	public void setDecisionMapId(long decisionMapId) {
		this.decisionMapId = decisionMapId;
	}

	public String getIdentityTrust() {
		return identityTrust;
	}

	public void setIdentityTrust(String identityTrust) {
		this.identityTrust = identityTrust;
	}

	public String getAddressTrust() {
		return addressTrust;
	}

	public void setAddressTrust(String addressTrust) {
		this.addressTrust = addressTrust;
	}

	public String getPhoneTrust() {
		return phoneTrust;
	}

	public void setPhoneTrust(String phoneTrust) {
		this.phoneTrust = phoneTrust;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

   
}
