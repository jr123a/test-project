package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the SponsorWebServiceRequests database table.
 * 
 */
@Entity
@Table(name="sponsor_web_service_requests")
@NamedQuery(name = "SponsorWebServiceRequests.findRequestByEnrollmentCode", query = "select i from SponsorWebServiceRequests i" + 
        "        where i.enrollmentCode = :enrollmentCode order by i.createDate desc")
@NamedQuery(name = "SponsorWebServiceRequests.getSuccessForEnrollmentCode", query = "select i.transactionSuccess from SponsorWebServiceRequests i " + 
                "where i.enrollmentCode = :enrollmentCode and i.transactionSuccess = 'Y'")
@NamedQuery(name="SponsorWebServiceRequests.findSponsorWebServiceRequestsBySponsor", query="SELECT r FROM SponsorWebServiceRequests r WHERE r.refSponsor.sponsorId = :sponsorId")

public class SponsorWebServiceRequests implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="sponsor_web_service_requestsSeq")
    @SequenceGenerator(name="sponsor_web_service_requestsSeq",sequenceName="SPONSOR_WEB_SERVICE_REQUESTS_SEQ", allocationSize=1)
    @Column(name = "SERVICE_REQUEST_ID")
    private long serviceRequestId;

    // bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name = "SPONSOR_ID")
    private RefSponsor refSponsor;

    @Column(name = "REQUEST_ID")
    private String requestId;

    // bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name = "ENDPOINT_ID")
    private SponsorEndpoints endpointId;

    // bi-directional one-to-one association to IppEvent
    @OneToOne
    @JoinColumn(name = "IPP_EVENT_ID")
    private IppEvent ippEvent;

    @Column(name = "ACTIVATION_CODE")
    private String activationCode;

    @Column(name = "ENROLLMENT_CODE")
    private String enrollmentCode;

    @Column(name = "PROOFING_LOCATION")
    private String proofingLocation;

    @Column(name = "TRANSACTION_DATETIME")
    private Timestamp transactionDateTime;

    @Column(name = "REQUEST_SENT_DATETIME")
    private Timestamp requestSentDateTime;

    @Column(name = "TRANSACTION_SUCCESS")
    private String transactionSuccess;

    @Column(name = "ERROR_TYPE")
    private String errorType;

    @Column(name = "ERROR_CODE")
    private String errorCode;

    @Column(name = "MESSAGE")
    private String message;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;
    
    @Column(name = "JSON_REQUEST")
    private String jsonRequest;
    

    public long getServiceRequestId() {
        return serviceRequestId;
    }

    public void setServiceRequestId(long serviceRequestId) {
        this.serviceRequestId = serviceRequestId;
    }

    public RefSponsor getRefSponsor() {
        return refSponsor;
    }

    public void setRefSponsor(RefSponsor refSponsor) {
        this.refSponsor = refSponsor;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public SponsorEndpoints getEndpointId() {
        return endpointId;
    }

    public void setEndpointId(SponsorEndpoints endpointId) {
        this.endpointId = endpointId;
    }

    public IppEvent getIppEvent() {
        return ippEvent;
    }

    public void setIppEvent(IppEvent ippEvent) {
        this.ippEvent = ippEvent;
    }

    public String getActivationCode() {
        return activationCode;
    }

    public void setActivationCode(String activationCode) {
        this.activationCode = activationCode;
    }

    public String getEnrollmentCode() {
        return enrollmentCode;
    }

    public void setEnrollmentCode(String enrollmentCode) {
        this.enrollmentCode = enrollmentCode;
    }

    public String getProofingLocation() {
        return proofingLocation;
    }

    public void setProofingLocation(String proofingLocaiton) {
        this.proofingLocation = proofingLocaiton;
    }

    public Timestamp getTransactionDateTime() {
        return transactionDateTime;
    }

    public void setTransactionDateTime(Timestamp transactionDateTime) {
        this.transactionDateTime = transactionDateTime;
    }

    public Timestamp getRequestSentDateTime() {
        return requestSentDateTime;
    }

    public void setRequestSentDateTime(Timestamp requestSentDateTime) {
        this.requestSentDateTime = requestSentDateTime;
    }

    public String getTransactionSuccess() {
        return transactionSuccess;
    }

    public void setTransactionSuccess(String transactionSuccess) {
        this.transactionSuccess = transactionSuccess;
    }

    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public String getJsonRequest() {
        return jsonRequest;
    }

    public void setJsonRequest(String jsonRequest) {
        this.jsonRequest = jsonRequest;
    }

}
