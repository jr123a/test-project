package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the rp_features_a_attempts database table.
 * 
 */
@Entity
@Table(name="rp_features_attempts")
@NamedQueries({
    @NamedQuery(name="RpFeatureAttempt.findAll", query="SELECT a FROM RpFeatureAttempt a"),
    @NamedQuery(name="RpFeatureAttempt.findBySponsorId", query="SELECT a FROM RpFeatureAttempt a WHERE a.refSponsor.sponsorId = :sponsorId ORDER BY a.featureId ASC"),
    @NamedQuery(name="RpFeatureAttempt.findByAppId", query="SELECT a FROM RpFeatureAttempt a WHERE a.refApp.appId = :appId ORDER BY a.featureId ASC"),
    @NamedQuery(name="RpFeatureAttempt.findBySponsorAndAppId", query="SELECT a FROM RpFeatureAttempt a WHERE a.refSponsor.sponsorId = :sponsorId AND a.refApp.appId = :appId ORDER BY a.featureId ASC"),
    @NamedQuery(name="RpFeatureAttempt.findBySponsorIdAndFeatureName", query="SELECT a FROM RpFeatureAttempt a WHERE a.refSponsor.sponsorId = :sponsorId AND a.featureName = :featureName ORDER BY a.featureId ASC"),
    @NamedQuery(name="RpFeatureAttempt.findByAppIdAndFeatureName", query="SELECT a FROM RpFeatureAttempt a WHERE a.refApp.appId = :appId AND a.featureName = :featureName ORDER BY a.featureId ASC"),
    @NamedQuery(name="RpFeatureAttempt.getMaxConfigId", query="SELECT MAX(a.featureId) FROM RpFeatureAttempt a"),
})
public class RpFeatureAttempt implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="fEATURE_ID")
    private long featureId;

    @Column(name="FEATURE_NAME")
    private String featureName;
    
    @Column(name="TOTAL_ATTEMPTS")
    private int totalAttempts;
    
    @Column(name="ATTEMPTS")
    private int attempts;
    
    @Column(name="MODIFY_CONFIGURATION_USERID")
    private String modifyConfigurationUserid;
    
    @Column(name="MODIFY_CONFIGURATION_TIME")
    private Timestamp modifyConfigurationTime;
    
    @Column(name = "CREATE_DATE")
    private Date createDate;
    
    @Column(name = "UPDATE_DATE")
    private Date updateDate;
    
    private long version;
    
    @Column(name="PROOFING_LEVEL")
    private long proofingLevel;
    
    //bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name="SPONSOR_ID")
    private RefSponsor refSponsor;

    //bi-directional many-to-one association to RefApp
    @ManyToOne
    @JoinColumn(name="APP_ID")
    private RefApp refApp;
    
    public RefApp getRefApp() {
		return refApp;
	}

	public void setRefApp(RefApp refApp) {
		this.refApp = refApp;
	}

	@Transient
    private int newTotalAttempts;
    
    @Transient
    private boolean active;

    public long getFeatureId() {
        return featureId;
    }

    public void setFeatureId(long featureId) {
        this.featureId = featureId;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public int getTotalAttempts() {
        return totalAttempts;
    }

    public void setTotalAttempts(int totalAttempts) {
        this.totalAttempts = totalAttempts;
    }

    public int getAttempts() {
        return attempts;
    }

    public void setAttempts(int attempts) {
        this.attempts = attempts;
    }

    public String getModifyConfigurationUserid() {
        return modifyConfigurationUserid;
    }

    public void setModifyConfigurationUserid(String modifyConfigurationUserid) {
        this.modifyConfigurationUserid = modifyConfigurationUserid;
    }

    public Timestamp getModifyConfigurationTime() {
        return modifyConfigurationTime;
    }

    public void setModifyConfigurationTime(Timestamp modifyConfigurationTime) {
        this.modifyConfigurationTime = modifyConfigurationTime;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    public long getProofingLevel() {
        return proofingLevel;
    }

    public void setProofingLevel(long proofingLevel) {
        this.proofingLevel = proofingLevel;
    }
    
	public int getNewTotalAttempts() {
        return newTotalAttempts;
    }

    public void setNewTotalAttempts(int newTotalAttempts) {
        this.newTotalAttempts = newTotalAttempts;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

	public RefSponsor getRefSponsor() {
		return refSponsor;
	}

	public void setRefSponsor(RefSponsor refSponsor) {
		this.refSponsor = refSponsor;
	}
    
}
