package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;

/**
 * The persistent class for the secondary_address_attempts database table.
 * 
 */
@Entity
@Table(name="secondary_address_attempts")
@NamedQueries({
    @NamedQuery(name="SecondaryAddressAttempt.findAll", query="SELECT e FROM SecondaryAddressAttempt e")
})
public class SecondaryAddressAttempt implements Serializable {
    private static final long serialVersionUID = 1L;
     
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="secondary_address_attemptsSeq")
    @SequenceGenerator(name="secondary_address_attemptsSeq",sequenceName="SECONDARY_ADDRESS_ATTEMPTS_SEQ", allocationSize=1)
    @Column(name="secondary_attempt_id")
    private long secondaryAttemptId;
    
    //bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name="person_id")
    private Person person;

    @Column(name="attempt_datetime")
    private Timestamp attemptDateTime;
    
    //bi-directional one-to-one association to RpEvent
    @OneToOne
    @JoinColumn(name="event_id")
    private RpEvent rpEvent;

    //bi-directional many-to-one association to HighRiskAddressAttempt
    @ManyToOne
    @JoinColumn(name="high_risk_address_id")
    private HighRiskAddress highRiskAddress;
    
    @Column(name="update_date")
    private Date updateDate;

    public long getSecondaryAttemptId() {
        return secondaryAttemptId;
    }

    public void setSecondaryAttemptId(long secondaryAttemptId) {
        this.secondaryAttemptId = secondaryAttemptId;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Timestamp getAttemptDateTime() {
        return attemptDateTime;
    }

    public void setAttemptDateTime(Timestamp attemptDateTime) {
        this.attemptDateTime = attemptDateTime;
    }

    public RpEvent getRpEvent() {
        return rpEvent;
    }

    public void setRpEvent(RpEvent rpEvent) {
        this.rpEvent = rpEvent;
    }

    public HighRiskAddress getHighRiskAddress() {
        return highRiskAddress;
    }

    public void setHighRiskAddress(HighRiskAddress highRiskAddress) {
        this.highRiskAddress = highRiskAddress;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
