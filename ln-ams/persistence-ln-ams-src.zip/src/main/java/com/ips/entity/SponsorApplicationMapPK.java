package com.ips.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class SponsorApplicationMapPK implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Column(name = "sponsor_id")
    private long sponsorId;
    
    @Column(name = "app_id")
    private long appId;
    
    public long getSponsorId() {
        return sponsorId;
    }
    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }
    
    public long getAppId() {
        return appId;
    }
    public void setAppId(long appId) {
        this.appId = appId;
    }
    
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SponsorApplicationMapPK)) {
            return false;
        }
        SponsorApplicationMapPK cast = (SponsorApplicationMapPK) other;
        return this.sponsorId == cast.sponsorId && this.appId == cast.appId;
    }
    
    @Override
    public int hashCode() {
        final long prime = 31;
        long hash = 17;
        hash = hash * prime + this.sponsorId;
        hash = hash * prime + this.appId;
        return (int) hash;
    }
}
