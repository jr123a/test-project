package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the sponsor_fair_ids database table.
 * 
 */
@Embeddable
public class SponsorFairIdPK implements Serializable {
    //default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;

    @Column(name = "SPONSOR_ID")
    private long sponsorId;
    
    @Column(name = "ID_TYPE")
    private long idType;
    

    public long getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }

    public long getIdType() {
        return idType;
    }

    public void setIdType(long idType) {
        this.idType = idType;
    }
    
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SponsorFairIdPK)) {
            return false;
        }
        SponsorFairIdPK cast = (SponsorFairIdPK) other;
        return this.sponsorId == cast.sponsorId && this.idType == cast.idType;
    }
    
    @Override
    public int hashCode() {
        final long prime = 31;
        long hash = 17;
        hash = hash * prime + this.sponsorId;
        hash = hash * prime + this.idType;
        return (int) hash;
    }

}
