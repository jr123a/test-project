package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rp_verify_business_response")
@NamedQueries({ 
	@NamedQuery(name = "RpVerifyBusinessResponse.getAll", query = "SELECT r FROM RpVerifyBusinessResponse r"),
    @NamedQuery(name = "RpVerifyBusinessResponse.getListByPersonId", query = "SELECT r FROM RpVerifyBusinessResponse r WHERE r.person.personId = :personId ORDER BY r.createDate DESC")
})

public class RpVerifyBusinessResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RPVERIFYBUSINESSRESPONSESEQ")
    @SequenceGenerator(name="RPVERIFYBUSINESSRESPONSESEQ",sequenceName="RP_VERIFY_BUSINESS_RESPONSE_SEQ", allocationSize=1)
    
    @Column(name = "BV_RESPONSE_ID")
    private long bvResponseId;

    // bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name = "PERSON_ID")
    private Person person;

	@Column(name = "REQUEST")
    private String request;
    
    @Column(name = "RESPONSE")
    private String response;
    
    @Column(name = "TRANSACTION_ORIGIN_ID", insertable = false, updatable = false)
    private long transactionOriginId;
    
    //bi-directional many-to-one association to RefApp
    @ManyToOne
    @JoinColumn(name="TRANSACTION_ORIGIN_ID")
    private RefApp refApp;
    
    @Column(name = "WORKFLOW_API_TYPE_ID", insertable = false, updatable = false)
    private long workflowApiTypeId;
     
    //bi-directional many-to-one association to RefWorkflowApiType
    @ManyToOne
    @JoinColumn(name="WORKFLOW_API_TYPE_ID")
    private RefWorkflowApiType refWorkflowApiType;
       
    @Column(name = "OVERALL_DECISION")
    private String overallDecision;
    
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "UPDATE_DATE")
    private Date updateDate;

   

    public long getBvResponseId() {
		return bvResponseId;
	}

	public void setBvResponseId(long bvResponseId) {
		this.bvResponseId = bvResponseId;
	}

	public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public long getTransactionOriginId() {
		return transactionOriginId;
	}

	public RefApp getRefApp() {
		return refApp;
	}

	public void setRefApp(RefApp refApp) {
		this.refApp = refApp;
	}

	public RefWorkflowApiType getRefWorkflowApiType() {
		return refWorkflowApiType;
	}

	public void setRefWorkflowApiType(RefWorkflowApiType refWorkflowApiType) {
		this.refWorkflowApiType = refWorkflowApiType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public long getWorkflowApiTypeId() {
		return workflowApiTypeId;
	}

	public String getOverallDecision() {
		return overallDecision;
	}

	public void setOverallDecision(String overallDecision) {
		this.overallDecision = overallDecision;
	}

	public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

}
