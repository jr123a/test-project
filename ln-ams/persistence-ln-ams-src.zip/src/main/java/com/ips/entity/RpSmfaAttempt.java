package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="rp_smfa_attempts")
@NamedQueries({
    @NamedQuery(name="RpSmfaAttempt.findAll", query="SELECT e FROM RpSmfaAttempt e"),
    
    // For SMFA sent velocity check
    @NamedQuery(name="RpSmfaAttempt.getSmfaAttemptsListInWindow", query="SELECT e FROM RpSmfaAttempt e " 
             + "WHERE e.rpEvent.personId=:personId "
    		 + "AND e.rpEvent.refOtpSupplier.otpSupplierId =:smfaSupplierId "
    		 + "AND e.rpEvent.eventId =:rpEventId "
             + "AND e.createDate>=:window AND e.createDate<=:currentTime "
             + "ORDER BY e.createDate "),
    
    @NamedQuery(name="RpSmfaAttempt.getSmfaAttemptsInTransaction", query="SELECT e FROM RpSmfaAttempt e " 
             + "WHERE e.rpEvent.personId=:personId AND e.rpEvent.refOtpSupplier.otpSupplierId =:smfaSupplierId "
             + "AND e.rpEvent.transactionKey =:transactionKey  "),
    
    @NamedQuery(name="RpSmfaAttempt.getSmfaAttemptsBySessionId", query="SELECT e FROM RpSmfaAttempt e " 
            + "WHERE UPPER(e.sessionId) = UPPER(:sessionId) ") 
})  
public class RpSmfaAttempt implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="rp_smfa_attemptsSeq")
    @SequenceGenerator(name="rp_smfa_attemptsSeq",sequenceName="RP_SMFA_ATTEMPTS_SEQ", allocationSize=1)
    @Column(name="MFA_ATTEMPT_ID")
    private long mfaAttempId;
    
    //bi-directional one-to-one association to RpEvent
    @OneToOne
    @JoinColumn(name="EVENT_ID")
    private RpEvent rpEvent;
    
    @Column(name="SESSION_ID")
    private String sessionId;
    
    @Column(name="ERROR_CODE")
    private String errorCode;
    
    @Column(name="ERROR_MESSAGE")
    private String errorMessage;
    
    @Column(name="MFA_COLOR")
    private String mfaColor;
    
    @Column(name="MFA_DECISION")
    private String mfaDecision;
    
    @Column(name = "MFA_SENT_DATETIME")
    private Date mfaSentDatetime;
    
    @Column(name = "MFA_COLOR_RECEIVED_DATETIME")
    private Date mfaColorReceivedDatetime;
       
    @Column(name = "CREATE_DATE")
    private Date createDate;
    
    @Column(name = "UPDATE_DATE")
    private Date updateDate;


	public long getMfaAttempId() {
		return mfaAttempId;
	}

	public void setMfaAttempId(long mfaAttempId) {
		this.mfaAttempId = mfaAttempId;
	}

	public RpEvent getRpEvent() {
		return rpEvent;
	}

	public void setRpEvent(RpEvent rpEvent) {
		this.rpEvent = rpEvent;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getMfaColor() {
		return mfaColor;
	}

	public void setMfaColor(String mfaColor) {
		this.mfaColor = mfaColor;
	}

	public String getMfaDecision() {
		return mfaDecision;
	}

	public void setMfaDecision(String mfaDecision) {
		this.mfaDecision = mfaDecision;
	}

	public Date getMfaSentDatetime() {
		return mfaSentDatetime;
	}

	public void setMfaSentDatetime(Date mfaSentDatetime) {
		this.mfaSentDatetime = mfaSentDatetime;
	}

	public Date getMfaColorReceivedDatetime() {
		return mfaColorReceivedDatetime;
	}

	public void setMfaColorReceivedDatetime(Date mfaColorReceivedDatetime) {
		this.mfaColorReceivedDatetime = mfaColorReceivedDatetime;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	@Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (mfaAttempId ^ (mfaAttempId >>> 32));
        result = prime * result + (int) (rpEvent.getEventId() ^ (rpEvent.getEventId() >>> 32));
        result = prime * result + ((sessionId == null) ? 0 : sessionId.hashCode());
        result = prime * result + ((errorCode == null) ? 0 : errorCode.hashCode());
        result = prime * result + ((errorMessage == null) ? 0 : errorMessage.hashCode());
        result = prime * result + ((mfaColor == null) ? 0 : mfaColor.hashCode());
        result = prime * result + ((mfaDecision == null) ? 0 : mfaDecision.hashCode());
        result = prime * result + ((mfaSentDatetime == null) ? 0 : mfaSentDatetime.hashCode());
        result = prime * result + ((mfaColorReceivedDatetime == null) ? 0 : createDate.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RpSmfaAttempt other = (RpSmfaAttempt) obj;
        if (mfaAttempId != other.mfaAttempId)
            return false;
        if (rpEvent.getEventId() != other.rpEvent.getEventId())
            return false;
        if (sessionId == null) {
            if (other.sessionId != null)
                return false;
        } else if (!sessionId.equals(other.sessionId))
            return false;
        if (errorCode == null) {
            if (other.errorCode != null)
                return false;
        } else if (!errorCode.equals(other.errorCode))
            return false;
        if (errorMessage == null) {
            if (other.errorMessage != null)
                return false;
        } else if (!errorMessage.equals(other.errorMessage))
            return false;
        if (mfaColor == null) {
            if (other.mfaColor != null)
                return false;
        } else if (!mfaColor.equals(other.mfaColor))
            return false;
        if (mfaDecision == null) {
            if (other.mfaDecision != null)
                return false;
        } else if (!mfaDecision.equals(other.mfaDecision))
            return false;
        if (mfaSentDatetime == null) {
            if (other.mfaSentDatetime != null)
                return false;
        } else if (!mfaSentDatetime.equals(other.mfaSentDatetime))
            return false;
        if (mfaColorReceivedDatetime == null) {
            if (other.mfaColorReceivedDatetime != null)
                return false;
        } else if (!mfaColorReceivedDatetime.equals(other.mfaColorReceivedDatetime))
            return false;
        if (createDate == null) {
        	if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }

}
