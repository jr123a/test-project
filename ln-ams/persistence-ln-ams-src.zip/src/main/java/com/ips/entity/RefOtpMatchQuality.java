package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the ref_otp_match_qualities database table.
 * 
 */
@Entity
@Table(name="ref_otp_match_qualities")
@NamedQueries({
    @NamedQuery(name="RefOtpMatchQuality.findAll", query="SELECT r FROM RefOtpMatchQuality r"),
    @NamedQuery(name="RefOtpMatchQuality.findByName", query="Select r FROM RefOtpMatchQuality r WHERE r.matchQuality = :name")
})    
public class RefOtpMatchQuality implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String MISMATCH = "MISMATCH";
    public static final String TIMEOUT = "TIMEOUT";
    public static final String SUBMIT_EXCEEDED = "TOO_MANY_SUBMIT_ATTEMPTS";
    public static final String RENEW_EXCEEDED = "TOO_MANY_RENEW_ATTEMPTS";
    public static final String EXACT = "EXACT";
    
    @Id
    @Column(name="otp_match_quality_id")
    private long otpMatchQualityId;
    
    @Column(name="match_quality")
    private String matchQuality;
    
    @Column(name="create_date")
    private Timestamp createDate;

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getMatchQuality() {
        return matchQuality;
    }

    public void setMatchQuality(String matchQuality) {
        this.matchQuality = matchQuality;
    }
    
    public boolean isExact() {
        return getMatchQuality().equals(EXACT);
    }
    
    public boolean isMismatch() {
        return getMatchQuality().equals(MISMATCH);
    }
    
    public boolean isExpired() {
        return getMatchQuality().equals(TIMEOUT);
    }
    
    public boolean isSubmitExceeded() {
        return getMatchQuality().equals(SUBMIT_EXCEEDED);
    }
    
    public boolean isRenewExceeded() {
        return getMatchQuality().equals(RENEW_EXCEEDED);
    }
}
