package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the ref_lexis_nexis_reason_code_map database table.
 * 
 */
@Entity
@Table(name="ref_lexisnexis_reason_code_map")
@NamedQueries({
    @NamedQuery(name="lnReasonCodeMap.getByValue", query="SELECT c FROM RefLexisNexisReasonCodeMap c WHERE c.checkItems = UPPER(:column) AND c.value = UPPER(:value) ")
})
public class RefLexisNexisReasonCodeMap implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="LN_MAPPING_ID")
    private long lnMappingId;

    @Column(name="CHECK_ITEMS")
    private String checkItems;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    private String value;

    //bi-directional many-to-one association to RefOtpReasonCode
    @ManyToOne
    @JoinColumn(name="Reason_Code")
    private RefOtpReasonCode refOtpReasonCode;

    public long getLnMappingId() {
        return lnMappingId;
    }

    public void setLnMappingId(long lnMappingId) {
        this.lnMappingId = lnMappingId;
    }

    public String getCheckItems() {
        return this.checkItems;
    }

    public void setCheckItems(String checkItems) {
        this.checkItems = checkItems;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public String getValue() {
        return this.value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public RefOtpReasonCode getRefOtpReasonCode() {
        return this.refOtpReasonCode;
    }

    public void setRefOtpReasonCode(RefOtpReasonCode refOtpReasonCode) {
        this.refOtpReasonCode = refOtpReasonCode;
    }

}
