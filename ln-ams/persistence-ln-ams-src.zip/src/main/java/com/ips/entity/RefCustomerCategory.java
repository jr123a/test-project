package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ref_kba_supplier database table.
 * 
 */
@Entity
@Table(name="ref_customer_category")
@NamedQueries({
@NamedQuery(name="RefCustomerCategory.findByCategoryId", query="SELECT r FROM RefCustomerCategory r WHERE r.customerCategoryId = :customerCategoryId"),
@NamedQuery(name="RefCustomerCategory.findByCategoryName", query="SELECT r FROM RefCustomerCategory r WHERE r.categoryName = :categoryName")
})

/** Renamed entity and properties, and retain database table name unchanged as part of KBA removal. **/
public class RefCustomerCategory implements Serializable {
    private static final long serialVersionUID = 1L;
      
    public static final String CUSTOMER_CATEGORY_NAME_UNKNOWN = "Unknown";
    public static final String CUSTOMER_CATEGORY_NAME_INDIVIDUAL = "Individual"; 
    public static final String CUSTOMER_CATEGORY_NAME_BUSINESS = "Business";
    public static final String CUSTOMER_CATEGORY_NAME_GOVERNMENT = "Government"; 
    public static final long CUSTOMER_CATEGORY_ID_UNKNOWN = 0L;
    public static final long CUSTOMER_CATEGORY_ID_INDIVIDUAL = 1L;
    public static final long CUSTOMER_CATEGORY_ID_BUSINESS = 2L;
    public static final long CUSTOMER_CATEGORY_ID_GOVERNMENT = 3L;
    
    @Id
    @Column(name="CUSTOMER_CATEGORY_ID")
    private long customerCategoryId;

    @Column(name="CATEGORY_NAME")
    private String categoryName;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;
    
	public long getCustomerCategoryId() {
		return customerCategoryId;
	}

	public void setCustomerCategoryId(long customerCategoryId) {
		this.customerCategoryId = customerCategoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

}
