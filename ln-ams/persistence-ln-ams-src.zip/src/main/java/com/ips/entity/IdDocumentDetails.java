package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the IdDocumentDetails database table.
 * 
 */
@Entity
@Table(name="id_document_details")
@NamedQueries({
    @NamedQuery(name = "IdDocumentDetails.getByEvent", query = "SELECT i FROM IdDocumentDetails i "
                    + "WHERE i.ippEventId = :eventId ")

})
public class IdDocumentDetails implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ID_DOCUMENT_DETAILSSEQ")
    @SequenceGenerator(name="ID_DOCUMENT_DETAILSSEQ",sequenceName="ID_DOCUMENT_DETAILS_SEQ", allocationSize=1)
    @Column(name = "DOCUMENT_DETAIL_ID")
    private long documentDetailId;

    @Column(name = "IPP_EVENT_ID")
    private long ippEventId;
    
    @Column(name="DOCUMENT_TYPE")
    private String documentType;

    @Column(name = "DOCUMENT_NAME")
    private String documentName;

    @Column(name = "DOCUMENT_NUMBER")
    private String documentNumber;
    
    @ManyToOne
    @JoinColumn(name = "ISSUER")
    private RefState issuer;

    @Column(name = "ISSUE_DATE")
    private String issueDate;

    @Column(name = "EXPIRATION_DATE")
    private String expirationDate;
    
    @Column(name = "ADDRESS_LINE1")
    private String addressLine1;
    
    @Column(name = "ADDRESS_LINE2")
    private String addressLine2;

    @Column(name = "CITY")
    private String city;

    @ManyToOne
    @JoinColumn(name = "STATE")
    private RefState state;

    @Column(name = "ZIP_CODE")
    private String zipCode;
    
    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;
    
    @OneToOne(mappedBy="documentDetail", cascade=CascadeType.ALL)
    private IdPersonDetails idPersonDetails;

    public long getIppEventId() {
        return ippEventId;
    }

    public void setIppEventId(long ippEventId) {
        this.ippEventId = ippEventId;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public long getDocumentDetailId() {
        return documentDetailId;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public RefState getIssuer() {
        return issuer;
    }

    public void setIssuer(RefState issuer) {
        this.issuer = issuer;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public RefState getState() {
        return state;
    }

    public void setState(RefState state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public IdPersonDetails getIdPersonDetails() {
        return idPersonDetails;
    }

    public void setIdPersonDetails(IdPersonDetails idPersonDetails) {
        this.idPersonDetails = idPersonDetails;
    }
}
