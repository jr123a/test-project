package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rp_device_reputation")
@NamedQueries({ @NamedQuery(name = "RpDeviceReputation.getAll", query = "SELECT r FROM RpDeviceReputation r"),
        @NamedQuery(name = "RpDeviceReputation.getByRequestId", query = "SELECT r FROM RpDeviceReputation r WHERE r.requestId = :requestId"),
        @NamedQuery(name = "RpDeviceReputation.getListByPersonId", query = "SELECT r FROM RpDeviceReputation r WHERE r.person.personId = :personId ORDER BY r.createDate DESC"),
        @NamedQuery(name = "RpDeviceReputation.getListByPersonAndAppId", query = "SELECT r FROM RpDeviceReputation r WHERE r.person.personId = :personId AND r.refApp.appId = :appId ORDER BY r.createDate DESC"),
        @NamedQuery(name = "RpDeviceReputation.getBySessionId", query = "SELECT r FROM RpDeviceReputation r WHERE r.sessionId = :sessionId ORDER BY r.createDate DESC"),    
        @NamedQuery(name = "RpDeviceReputation.getByPersonIdSessionIdPhoneNumber", query = "Select r FROM RpDeviceReputation r WHERE r.sessionId = :sessionId " 
                + "AND r.mobilePhoneNumber = :mobilePhoneNumber AND r.person.personId = :personId ORDER BY r.createDate DESC")

})


public class RpDeviceReputation implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="rp_device_reputationSeq")
    @SequenceGenerator(name="rp_device_reputationSeq",sequenceName="RP_DEVICE_REPUTATION_SEQ", allocationSize=1)
    @Column(name = "device_reputation_id")
    private long deviceReputationId;

    @Column(name = "session_id")
    private String sessionId;

    // bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name = "person_id")
    private Person person;

    @Column(name = "conversation_id")
    private String conversationId;

    @Column(name = "request_id")
    private String requestId;

    @Column(name = "risk_score")
    private Integer riskScore;

    // bi-directional many-to-one association to RpDeviceReputation
    @ManyToOne
    @JoinColumn(name = "device_confidence_id")
    private RefDeviceConfidence refDeviceConfidence;

    @Column(name = "repeat_assessment_attempts")
    private int repeatAssessmentAttempts;
    
    @Column(name = "mobile_phone_number")
    private String mobilePhoneNumber;
    
    @Column(name = "create_date")
    private Date createDate;

    @Column(name = "received_response_date")
    private Timestamp receivedResponseDate;

    @Column(name = "update_date")
    private Date updateDate;

    // bi-directional one-to-one association to RpEvent
    @OneToOne
    @JoinColumn(name = "event_id")
    private RpEvent rpEvent;

    // bi-directional one-to-one association to IppEvent
    @OneToOne
    @JoinColumn(name = "ipp_event_id")
    private IppEvent ippEvent;

    // bi-directional many-to-one association to RefApp
    @ManyToOne
    @JoinColumn(name = "app_id")
    private RefApp refApp;

    public Long getDeviceReputationId() {
        return deviceReputationId;
    }

    public void setDeviceReputationId(Long deviceReputationId) {
        this.deviceReputationId = deviceReputationId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Integer getRiskScore() {
        return riskScore;
    }

    public void setRiskScore(Integer riskScore) {
        this.riskScore = riskScore;
    }

    public RefDeviceConfidence getRefDeviceConfidence() {
        return refDeviceConfidence;
    }

    public void setRefDeviceConfidence(RefDeviceConfidence refDeviceConfidence) {
        this.refDeviceConfidence = refDeviceConfidence;
    }

    public int getRepeatAssessmentAttempts() {
        return repeatAssessmentAttempts;
    }

    public void setRepeatAssessmentAttempts(int repeatAssessmentAttempts) {
        this.repeatAssessmentAttempts = repeatAssessmentAttempts;
    }

    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }

    public void setMobilePhoneNumber(String mobilePhoneNumber) {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Timestamp getReceivedResponseDate() {
        return receivedResponseDate;
    }

    public void setReceivedResponseDate(Timestamp receivedResponseDate) {
        this.receivedResponseDate = receivedResponseDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public RpEvent getRpEvent() {
        return rpEvent;
    }

    public void setRpEvent(RpEvent rpEvent) {
        this.rpEvent = rpEvent;
    }

    public IppEvent getIppEvent() {
        return ippEvent;
    }

    public void setIppEvent(IppEvent ippEvent) {
        this.ippEvent = ippEvent;
    }

    public RefApp getRefApp() {
        return refApp;
    }

    public void setRefApp(RefApp refApp) {
        this.refApp = refApp;
    }

}
