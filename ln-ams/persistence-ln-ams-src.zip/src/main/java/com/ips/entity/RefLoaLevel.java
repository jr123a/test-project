package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the ref_loa_level database table.
 * 
 */
@Entity
@Table(name="ref_loa_level")
@NamedQueries({
    @NamedQuery(name="RefLoaLevel.findAll", query="SELECT r FROM RefLoaLevel r"),
    @NamedQuery(name="RefLoaLevel.findByLevel", query="SELECT r FROM RefLoaLevel r WHERE r.loaLevel = :level"),
    @NamedQuery(name="RefLoaLevel.findByCode", query="SELECT r FROM RefLoaLevel r WHERE r.loaCode = :code")
})    
public class RefLoaLevel implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String LOA_15 = "1.5";
    public static final String IAL2 = "2.0";
    public static final long NO_LEVEL_CODE = 0L;
    public static final long LOA15_CODE = 1L;
    public static final long IAL2_CODE = 2L;


    @Id
    @Column(name="loa_code")
    private long loaCode;

    @Column(name="create_date")
    private Timestamp createDate;

    @Column(name="loa_level")
    private String loaLevel;
    
    @Column(name="loa_level_description")
    private String loaLevelDescription;

    @Column(name="update_date")
    private Timestamp updateDate;
    
    @Column(name="credential_expiration_period")
    private long credExpirationPeriod;
        
    public long getLoaCode() {
        return this.loaCode;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getLoaLevel() {
        return loaLevel;
    }

    public void setLoaLevel(String loaLevel) {
        this.loaLevel = loaLevel;
    }

    public String getLoaLevelDescription() {
        return loaLevelDescription;
    }

    public void setLoaLevelDescription(String loaLevelDescription) {
        this.loaLevelDescription = loaLevelDescription;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public void setLoaCode(long loaCode) {
        this.loaCode = loaCode;
    }
    
    public boolean isLoa15() {
        return LOA_15.equalsIgnoreCase(this.getLoaLevel());
    }
    
    public boolean isIAL2() {
        return IAL2.equalsIgnoreCase(this.getLoaLevel());
    }
    
    public static long convertStringToCode(String loaString) {
        long code = 0L;
        
        if (loaString.equals(LOA_15)) {
            code = LOA15_CODE;
        }
        else if (loaString.equals(IAL2)) {
            code = IAL2_CODE;
        }
        
        return code;
    }

    public long getCredExpirationPeriod() {
        return credExpirationPeriod;
    }

    public void setCredExpirationPeriod(long credExpirationPeriod) {
        this.credExpirationPeriod = credExpirationPeriod;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + (int) (credExpirationPeriod ^ (credExpirationPeriod >>> 32));
        result = prime * result + (int) (loaCode ^ (loaCode >>> 32));
        result = prime * result + ((loaLevel == null) ? 0 : loaLevel.hashCode());
        result = prime * result + ((loaLevelDescription == null) ? 0 : loaLevelDescription.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefLoaLevel other = (RefLoaLevel) obj;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        if (credExpirationPeriod != other.credExpirationPeriod)
            return false;
        if (loaCode != other.loaCode)
            return false;
        if (loaLevel == null) {
            if (other.loaLevel != null)
                return false;
        } else if (!loaLevel.equals(other.loaLevel))
            return false;
        if (loaLevelDescription == null) {
            if (other.loaLevelDescription != null)
                return false;
        } else if (!loaLevelDescription.equals(other.loaLevelDescription))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }

}
