package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the rp_otp_attempts database table.
 * 
 */
@Entity
@Table(name="rp_otp_attempts")
@NamedQueries({
    @NamedQuery(name="RpOtpAttempt.findAll", query="SELECT e FROM RpOtpAttempt e"),
    
    // For OTP request velocity check
    @NamedQuery(name="RpOtpAttempt.getOtpRequestAttemptListInWindow", query="SELECT e FROM RpOtpAttempt e " 
             + "WHERE e.rpEvent.personId=:personId "
    		 +  "AND e.rpEvent.refOtpSupplier.otpSupplierId =:otpSupplierId "
             + "AND e.rpEvent.eventId =:rpEventId "
             + "AND e.refOtpAttemptType.attemptTypeId <> 2  " 
             + "AND e.createDate>=:window AND e.createDate<=:currentTime "
             + "ORDER BY e.createDate "),
    
    @NamedQuery(name="RpOtpAttempt.getOtpConfirmAttemptListInWindow", query="SELECT e FROM RpOtpAttempt e " 
            + "WHERE e.rpEvent.personId=:personId "
   		    +  "AND e.rpEvent.refOtpSupplier.otpSupplierId =:otpSupplierId "
            + "AND e.rpEvent.eventId =:rpEventId "
            + "AND e.refOtpAttemptType.attemptTypeId = 2  " 
            + "AND e.createDate>=:window AND e.createDate<=:currentTime "
            + "ORDER BY e.createDate "),
    
    @NamedQuery(name="RpOtpAttempt.getOtpRequestAndConfirmAttemptListInWindow", query="SELECT e FROM RpOtpAttempt e " 
            + "WHERE e.rpEvent.personId=:personId "
   		    +  "AND e.rpEvent.refOtpSupplier.otpSupplierId =:otpSupplierId "
            + "AND e.rpEvent.eventId =:rpEventId "
            + "AND e.createDate>=:window AND e.createDate<=:currentTime "
            + "ORDER BY e.createDate "),
    
    @NamedQuery(name="RpOtpAttempt.getOtpRequestAndConfirmAttemptList", query="SELECT e FROM RpOtpAttempt e " 
            + "WHERE e.rpEvent.personId=:personId "
   		    +  "AND e.rpEvent.refOtpSupplier.otpSupplierId =:otpSupplierId "
            + "AND e.rpEvent.eventId =:rpEventId "
            + "ORDER BY e.createDate DESC"),

    @NamedQuery(name="RpOtpAttempt.getOtpRequestAttemptList", query="SELECT e FROM RpOtpAttempt e " 
            + "WHERE e.rpEvent.personId=:personId "
   		 +  "AND e.rpEvent.refOtpSupplier.otpSupplierId =:otpSupplierId "
            + "AND e.rpEvent.eventId =:rpEventId "
            + "AND e.refOtpAttemptType.attemptTypeId <> 2  " 
            + "ORDER BY e.createDate DESC"),
    
    @NamedQuery(name="RpOtpAttempt.getOtpConfirmAttemptList", query="SELECT e FROM RpOtpAttempt e " 
            + "WHERE e.rpEvent.personId=:personId "
   		    +  "AND e.rpEvent.refOtpSupplier.otpSupplierId =:otpSupplierId "
            + "AND e.rpEvent.eventId =:rpEventId "
            + "AND e.refOtpAttemptType.attemptTypeId = 2  "
            + "ORDER BY e.createDate DESC"),
    
    @NamedQuery(name="RpOtpAttempt.getLatestOtpAttemptByEventId", query="SELECT e FROM RpOtpAttempt e " 
            + "WHERE e.rpEvent.eventId =:rpEventId ORDER BY e.createDate DESC"),
    
    @NamedQuery(name="RpOtpAttempt.getOtpAttemptInTransaction", query="SELECT e FROM RpOtpAttempt e " 
             + "WHERE e.rpEvent.personId=:personId "
    		 + "AND e.rpEvent.refOtpSupplier.otpSupplierId =:otpSupplierId "
             + "AND e.transactionKey =:transactionKey  " 
             + "AND e.refOtpAttemptType.attemptType =:attemptType "), 
})

public class RpOtpAttempt implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="OtpAttemptSeq")
    @SequenceGenerator(name="OtpAttemptSeq",sequenceName="OTP_ATTEMPT_ID_SEQ", allocationSize=1)
    @Column(name="otp_attempt_id")
    private long otpAttemptId;
    
    //bi-directional one-to-one association to RpEvent
    @OneToOne
    @JoinColumn(name="event_id")
    private RpEvent rpEvent;
    
    @Column(name="transaction_key")
    private String transactionKey;
    
    @Column(name="otp_sent_datetime")
    private Timestamp otpSentDateTime;
    
    @Column(name="otp_decision")
    private String otpDecision;
    
    @Column(name="otp_decision_received_datetime")
    private Timestamp otpDecisionReceivedDatetime;
    
    @Column(name="confirm_datetime")
    private Timestamp confirmDatetime;
    
    // many-to-one association to RefProductStatusCode
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="product_status_id")
    private RefProductStatusCode refProductStatusCode;
    
    // many-to-one association to RefOtpAttemptType
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="attempt_type_id")
    private RefOtpAttemptType refOtpAttemptType;
    
    // many-to-one association to RefOtpMatchQuality
    @ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.REFRESH)
    @JoinColumn(name="otp_match_quality_id")
    private RefOtpMatchQuality refOtpMatchQuality;
        
    @Column(name="create_date")
    private Date createDate;
    
    @Column(name="update_date")
    private Date updateDate;

    public RpEvent getRpEvent() {
        return rpEvent;
    }
    public void setRpEvent(RpEvent rpEvent) {
        this.rpEvent = rpEvent;
    }
    
    public String getOtpDecision() {
        return otpDecision;
    }
    public void setOtpDecision(String otpDecision) {
        this.otpDecision = otpDecision;
    }

    public Date getCreateDate() {
        return createDate;
    }
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getTransactionKey() {
        return transactionKey;
    }
    public void setTransactionKey(String transactionKey) {
        this.transactionKey = transactionKey;
    }

    public RefProductStatusCode getRefProductStatusCode() {
        return refProductStatusCode;
    }
    public void setRefProductStatusCode(RefProductStatusCode refProductStatusCode) {
        this.refProductStatusCode = refProductStatusCode;
    }

    public RefOtpAttemptType getRefOtpAttemptType() {
        return refOtpAttemptType;
    }
    public void setRefOtpAttemptType(RefOtpAttemptType refOtpAttemptType) {
        this.refOtpAttemptType = refOtpAttemptType;
    }

    public Timestamp getOtpDecisionReceivedDatetime() {
        return otpDecisionReceivedDatetime;
    }
    public void setOtpDecisionReceivedDatetime(Timestamp otpDecisionReceivedDatetime) {
        this.otpDecisionReceivedDatetime = otpDecisionReceivedDatetime;
    }
    
    public Timestamp getOtpSentDateTime() {
        return otpSentDateTime;
    }
    public void setOtpSentDateTime(Timestamp otpSentDateTime) {
        this.otpSentDateTime = otpSentDateTime;
    }

    public RefOtpMatchQuality getRefOtpMatchQuality() {
        return refOtpMatchQuality;
    }
    public void setRefOtpMatchQuality(RefOtpMatchQuality refOtpMatchQuality) {
        this.refOtpMatchQuality = refOtpMatchQuality;
    }

    public Timestamp getConfirmDatetime() {
        return confirmDatetime;
    }
    public void setConfirmDatetime(Timestamp confirmDatetime) {
        this.confirmDatetime = confirmDatetime;
    }
	public long getOtpAttemptId() {
		return otpAttemptId;
	}
	public void setOtpAttemptId(long otpAttemptId) {
		this.otpAttemptId = otpAttemptId;
	}
}
