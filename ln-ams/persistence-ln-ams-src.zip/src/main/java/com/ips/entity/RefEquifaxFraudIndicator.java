package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ref_equifax_fraud_indicator database table.
 * 
 */
@Entity
@Table(name="ref_equifax_fraud_indicator")
public class RefEquifaxFraudIndicator implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="fraud_indicator_code")
    private String fraudIndicatorCode;

    @Column(name="create_date")
    private Timestamp createDate;
    
    @Column(name="fraud_indicator")
    private String fraudIndicator;
    
    @Column(name="update_date")
    private Timestamp updateDate;

    //bi-directional many-to-one association to RpEquifaxResult
    @OneToMany(mappedBy="refEquifaxFraudIndicator")
    private List<RpEquifaxResult> rpEquifaxResults;

    public String getFraudIndicatorCode() {
        return this.fraudIndicatorCode;
    }

    public void setFraudIndicatorCode(String fraudIndicatorCode) {
        this.fraudIndicatorCode = fraudIndicatorCode;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getFraudIndicator() {
        return this.fraudIndicator;
    }

    public void setFraudIndicator(String fraudIndicator) {
        this.fraudIndicator = fraudIndicator;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<RpEquifaxResult> getRpEquifaxResults() {
        return this.rpEquifaxResults;
    }

    public void setRpEquifaxResults(List<RpEquifaxResult> rpEquifaxResults) {
        this.rpEquifaxResults = rpEquifaxResults;
    }

    public RpEquifaxResult addRpEquifaxResult(RpEquifaxResult rpEquifaxResult) {
        getRpEquifaxResults().add(rpEquifaxResult);
        rpEquifaxResult.setFraudIndicatorCode(this.getFraudIndicatorCode()); 

        return rpEquifaxResult;
    }

    public RpEquifaxResult removeRpEquifaxResult(RpEquifaxResult rpEquifaxResult) {
        getRpEquifaxResults().remove(rpEquifaxResult);
        rpEquifaxResult.setFraudIndicatorCode(null);

        return rpEquifaxResult;
    }

}
