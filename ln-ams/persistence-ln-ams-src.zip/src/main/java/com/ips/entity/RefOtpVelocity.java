package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the ref_kba_velocity database table.
 * 
 */
@Entity
@Table(name="ref_kba_velocity")
@NamedQueries({
    @NamedQuery(name="RefOtpVelocity.findAll", query="SELECT p FROM RefOtpVelocity p"),
    @NamedQuery(name="RefOtpVelocity.findAllByKbaSupplier", query="SELECT v FROM RefOtpVelocity v WHERE v.refOtpSupplier=:supplier " 
        + "ORDER BY v.attemptWindow DESC"),
    @NamedQuery(name="RefOtpVelocity.findByVelocityType", query="SELECT v FROM RefOtpVelocity v WHERE v.refOtpSupplier.otpSupplierId =:supplierId " 
        + "AND v.velocityType=:velocityType"),
})    
public class RefOtpVelocity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="VELOCITY_ID")
    private long velocityId;

    @Column(name="ATTEMPT_WINDOW")
    private int attemptWindow;
    
    @Column(name="ATTEMPTS_ALLOWED")
    private int attemptsAllowed;
    
    @Column(name="VELOCITY_TYPE")
    private String velocityType;
    
    @Column(name="CREATE_DATE")
    private Timestamp createDate;
    
    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    //bi-directional many-to-one association to RefOtpSupplier
    @ManyToOne
    @JoinColumn(name="KBA_SUPPLIER_ID")
    private RefOtpSupplier refOtpSupplier;

    @Transient
    private Timestamp lockoutDatetime;
    @Transient
    private Timestamp lockoutExpiresDatetime;
    @Transient
    private boolean exceedPhoneVerificationLimit;
    @Transient
    private boolean lockoutStillInEffect;
    @Transient
    private boolean exceedPhoneRepeatAssessmentLimit;
    
    public long getVelocityId() {
        return this.velocityId;
    }

    public void setVelocityId(long velocityId) {
        this.velocityId = velocityId;
    }

    public int getAttemptWindow() {
        return this.attemptWindow;
    }

    public void setAttemptWindow(int attemptWindow) {
        this.attemptWindow = attemptWindow;
    }

    public int getAttemptsAllowed() {
        return this.attemptsAllowed;
    }

    public void setAttemptsAllowed(int attemptsAllowed) {
        this.attemptsAllowed = attemptsAllowed;
    }

    public String getVelocityType() {
        return velocityType;
    }

    public void setVelocityType(String velocityType) {
        this.velocityType = velocityType;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public RefOtpSupplier getRefOtpSupplier() {
        return this.refOtpSupplier;
    }

    public void setRefOtpSupplier(RefOtpSupplier refOtpSupplier) {
        this.refOtpSupplier = refOtpSupplier;
    }

    public Timestamp getLockoutDatetime() {
        return lockoutDatetime;
    }

    public void setLockoutDatetime(Timestamp lockoutDatetime) {
        this.lockoutDatetime = lockoutDatetime;
    }

    public Timestamp getLockoutExpiresDatetime() {
        return lockoutExpiresDatetime;
    }

    public void setLockoutExpiresDatetime(Timestamp lockoutExpiresDatetime) {
        this.lockoutExpiresDatetime = lockoutExpiresDatetime;
    }

	public boolean isExceedPhoneVerificationLimit() {
		return exceedPhoneVerificationLimit;
	}

	public void setExceedPhoneVerificationLimit(boolean exceedPhoneVerificationLimit) {
		this.exceedPhoneVerificationLimit = exceedPhoneVerificationLimit;
	}

	public boolean isLockoutStillInEffect() {
		return lockoutStillInEffect;
	}

	public void setLockoutStillInEffect(boolean lockoutStillInEffect) {
		this.lockoutStillInEffect = lockoutStillInEffect;
	}

	public boolean isExceedPhoneRepeatAssessmentLimit() {
		return exceedPhoneRepeatAssessmentLimit;
	}

	public void setExceedPhoneRepeatAssessmentLimit(boolean exceedPhoneRepeatAssessmentLimit) {
		this.exceedPhoneRepeatAssessmentLimit = exceedPhoneRepeatAssessmentLimit;
	}

}
