package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "SPONSOR_INCOMING_REQUESTS")
@NamedQuery(name = "SponsorIncomingRequests.findBySponsorAndRequestId", query = "SELECT s FROM SponsorIncomingRequests s WHERE s.refSponsor.sponsorId = :sponsorId AND s.requestId = :requestId")
@NamedQuery(name = "SponsorIncomingRequests.findCountBySponsorIdAndRequestIdAndEndpointName", query = "SELECT s FROM SponsorIncomingRequests s WHERE s.refSponsor.sponsorId = :sponsorId AND s.requestId = :requestId AND s.endpointId.endpointName = :endpointName")
@NamedQuery(name="SponsorIncomingRequests.findSponsorIncomingRequestsBySponsor", query="SELECT r FROM SponsorIncomingRequests r WHERE r.refSponsor.sponsorId = :sponsorId")

public class SponsorIncomingRequests implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SPONSOR_INCOMING_REQUESTSSeq")
    @SequenceGenerator(name="SPONSOR_INCOMING_REQUESTSSeq",sequenceName="SPONSOR_INCOMING_REQUESTS_SEQ", allocationSize=1)
    @Column(name = "SERVICE_REQUEST_ID")
    private long serviceRequestId;

    // bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name = "SPONSOR_ID")
    private RefSponsor refSponsor;

    @Column(name = "REQUEST_ID")
    private String requestId;

    // bi-directional many-to-one association to RefIppEndpoints
    @ManyToOne
    @JoinColumn(name = "ENDPOINT_ID")
    private RefIppEndpoints endpointId;

    @Column(name = "REQUEST_DATETIME")
    private Date requestDateTime;

    @Column(name = "TRANSACTION_SUCCESS")
    private String transactionSuccess;

    @Column(name = "RESPONSE_CODE")
    private String responseCode;

    @Column(name = "RESPONSE_MESSAGE")
    private String responseMessage;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;

    public long getServiceRequestId() {
        return serviceRequestId;
    }

    public void setServiceRequestId(long serviceRequestId) {
        this.serviceRequestId = serviceRequestId;
    }

    public RefSponsor getRefSponsor() {
        return refSponsor;
    }

    public void setRefSponsor(RefSponsor refSponsor) {
        this.refSponsor = refSponsor;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public RefIppEndpoints getEndpointId() {
        return endpointId;
    }

    public void setEndpointId(RefIppEndpoints endpointId) {
        this.endpointId = endpointId;
    }

    public Date getRequestDateTime() {
        return requestDateTime;
    }

    public void setRequestDateTime(Date requestDateTime) {
        this.requestDateTime = requestDateTime;
    }

    public String getTransactionSuccess() {
        return transactionSuccess;
    }

    public void setTransactionSuccess(String transactionSuccess) {
        this.transactionSuccess = transactionSuccess;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

}
