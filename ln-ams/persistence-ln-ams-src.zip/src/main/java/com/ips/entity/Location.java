package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 * The persistent class for the Locations database table.
 * 
 */
@Entity
@Table(name="locations")
@NamedQueries({
    @NamedQuery(name="Location.findAll", query="SELECT l FROM Location l"),
    @NamedQuery(name="Location.findByFacilityId", query="SELECT l FROM Location l WHERE l.facilityId = :id"),
    @NamedQuery(name="Location.findALLByFacilityId", query="SELECT l FROM Location l WHERE l.activationDate <= (:sysDate) AND l.facilityId IN :facilityId ORDER BY l.facilityId ASC"),
    })    

@XmlRootElement
public class Location implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="LocationSeq")
    @SequenceGenerator(name="LocationSeq",sequenceName="LOCS_ID_SEQ", allocationSize=1)
    @Column(name="location_id")
    private Long locationId;
    
    @Column(name="location_name")
    private String locationName;
    @Column(name="address")
    private String address;
    @Column(name="city")
    private String city;
    @Column(name="state_code")
    private String stateCode;
    @Column(name="zip_code")
    private String zipCode;
    @Column(name="facility_id")
    private long facilityId;
    @Column(name="activation_date")
    private Date activationDate;
    @Column(name="phone")
    private String phone;
    @Column(name="parking")
    private String parking;
    @Column(name="hours")
    private String hours;
    @Column(name="latitude")
    private String latitude;
    @Column(name="longitude")
    private String longitude;
    /**
     * @return the locationId
     */
    @XmlTransient
    public Long getLocationId() {
        return locationId;
    }
    /**
     * @param locationId the locationId to set
     */
    public void setLocationId(long locationId) {
        this.locationId = locationId;
    }
    /**
     * @return the locationName
     */
    public String getLocationName() {
        return locationName;
    }
    /**
     * @param locationName the locationName to set
     */
    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }
    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }
    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }
    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }
    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }
    /**
     * @return the stateCode
     */
    public String getStateCode() {
        return stateCode;
    }
    /**
     * @param stateCode the stateCode to set
     */
    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }
    /**
     * @return the zipCode
     */
    public String getZipCode() {
        return zipCode;
    }
    /**
     * @param zipCode the zipCode to set
     */
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
    /**
     * @return the facilityId
     */
    public long getFacilityId() {
        return facilityId;
    }
    /**
     * @param facilityId the facilityId to set
     */
    public void setFacilityId(long facilityId) {
        this.facilityId = facilityId;
    }
    /**
     * @return the activationdate
     */
    public Date getActivationDate() {
        return activationDate;
    }
    /**
     * @param activationDate the activationDate to set
     */
    public void setActivationDate(Date activationDate) {
        this.activationDate = activationDate;
    }
    /**
     * @return the phone number
     */
    public String getPhone() {
        return phone;
    }
    /**
     * @param phone number set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }
    /**
     * @return the parking
     */
    public String getParking() {
        return parking;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((activationDate == null) ? 0 : activationDate.hashCode());
        result = prime * result + ((address == null) ? 0 : address.hashCode());
        result = prime * result + ((city == null) ? 0 : city.hashCode());
        result = prime * result + (int) (facilityId ^ (facilityId >>> 32));
        result = prime * result + ((hours == null) ? 0 : hours.hashCode());
        result = prime * result + ((latitude == null) ? 0 : latitude.hashCode());
        result = prime * result + ((locationId == null) ? 0 : locationId.hashCode());
        result = prime * result + ((locationName == null) ? 0 : locationName.hashCode());
        result = prime * result + ((longitude == null) ? 0 : longitude.hashCode());
        result = prime * result + ((parking == null) ? 0 : parking.hashCode());
        result = prime * result + ((phone == null) ? 0 : phone.hashCode());
        result = prime * result + ((stateCode == null) ? 0 : stateCode.hashCode());
        result = prime * result + ((zipCode == null) ? 0 : zipCode.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Location other = (Location) obj;
        if (activationDate == null) {
            if (other.activationDate != null)
                return false;
        } else if (!activationDate.equals(other.activationDate))
            return false;
        if (address == null) {
            if (other.address != null)
                return false;
        } else if (!address.equals(other.address))
            return false;
        if (city == null) {
            if (other.city != null)
                return false;
        } else if (!city.equals(other.city))
            return false;
        if (facilityId != other.facilityId)
            return false;
        if (hours == null) {
            if (other.hours != null)
                return false;
        } else if (!hours.equals(other.hours))
            return false;
        if (latitude == null) {
            if (other.latitude != null)
                return false;
        } else if (!latitude.equals(other.latitude))
            return false;
        if (locationId == null) {
            if (other.locationId != null)
                return false;
        } else if (!locationId.equals(other.locationId))
            return false;
        if (locationName == null) {
            if (other.locationName != null)
                return false;
        } else if (!locationName.equals(other.locationName))
            return false;
        if (longitude == null) {
            if (other.longitude != null)
                return false;
        } else if (!longitude.equals(other.longitude))
            return false;
        if (parking == null) {
            if (other.parking != null)
                return false;
        } else if (!parking.equals(other.parking))
            return false;
        if (phone == null) {
            if (other.phone != null)
                return false;
        } else if (!phone.equals(other.phone))
            return false;
        if (stateCode == null) {
            if (other.stateCode != null)
                return false;
        } else if (!stateCode.equals(other.stateCode))
            return false;
        if (zipCode == null) {
            if (other.zipCode != null)
                return false;
        } else if (!zipCode.equals(other.zipCode))
            return false;
        return true;
    }
    /**
     * @param Parking the Parking to set
     */
    public void setParking(String parking) {
        this.parking = parking;
    }
    /**
     * @return the hours
     */
    public String getHours() {
        return hours;
    }
    /**
     * @param Hours set
     */
    public void setHours(String hours) {
        this.hours = hours;
    }
    /**
     * @return the latitude
     */
    public String getLatitude() {
        return latitude;
    }
    /**
     * @param latitude set
     */
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
    /**
     * @return the longitude
     */
    public String getLongitude() {
        return longitude;
    }
    /**
     * @param longitude set
     */
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
    
}