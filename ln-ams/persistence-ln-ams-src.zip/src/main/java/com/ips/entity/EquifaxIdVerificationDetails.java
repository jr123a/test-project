package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the EquifaxIdVerificationDetails database table.
 * 
 */
@Entity
@Table(name="efx_id_verification_details")
@NamedQueries({
	@NamedQuery(name="EquifaxIdVerificationDetails.getVerificationDetailsByEvent", query="SELECT e FROM EquifaxIdVerificationDetails e WHERE e.ippEventId=:eventId")
})
public class EquifaxIdVerificationDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="efx_id_verification_detailsSeq")
    @SequenceGenerator(name="efx_id_verification_detailsSeq",sequenceName="EFX_ID_VERIFICATION_DETAILS_SEQ", allocationSize=1)
	@Column(name = "VERIFICATION_DETAIL_ID")
	private long verificationDetailId;

	@Column(name = "IPP_EVENT_ID")
	private long ippEventId;

	@Column(name = "REFERENCE_TRANSACTION_ID")
	private String referenceTransactionId;

	@Column(name = "CONSUMER_ID")
	private String consumerId;
	
	@Column(name = "DOCUMENT_VERIFICATION_TRUST")
	private String documentVerificationTrust;
	
	@Column(name = "DOC_VERIFICATION_TRUST_REASON")
	private String docVerificationTrustReason;
	
	@Column(name = "DOCUMENT_FRONT_SCAN")
	private String documentFrontScan;
	
	@Column(name = "DOCUMENT_FRONT_SCAN_REASONS")
	private String documentFrontScanReasons;
	
	@Column(name = "DOCUMENT_BACK_SCAN")
	private String documentBackScan;
	
	@Column(name = "DOCUMENT_BACK_SCAN_REASONS")
	private String documentBackScanReasons;
	
	@Column(name = "FACE_SCAN")
	private String faceScan;
	
	@Column(name = "FACE_SCAN_REASONS")
	private String faceScanReasons;
	
	@Column(name = "DEVICE_TRUST")
	private String deviceTrust;
	
	@Column(name = "CREATE_DATE")
	private Timestamp createDate;

	@Column(name = "UPDATE_DATE")
	private Timestamp updateDate;
	
	// Not a column but needed for processing
	@Transient
	private RefValidationStatusCode status;

	public long getVerificationDetailId() {
		return verificationDetailId;
	}

	public void setVerificationDetailId(long verificationDetailId) {
		this.verificationDetailId = verificationDetailId;
	}

	public long getIppEventId() {
		return ippEventId;
	}

	public void setIppEventId(long ippEventId) {
		this.ippEventId = ippEventId;
	}

	public Timestamp getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public Timestamp getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	public String getReferenceTransactionId() {
		return referenceTransactionId;
	}

	public void setReferenceTransactionId(String referenceTransactionId) {
		this.referenceTransactionId = referenceTransactionId;
	}

	public String getConsumerId() {
		return consumerId;
	}

	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}

	public String getDocumentVerificationTrust() {
		return documentVerificationTrust;
	}

	public void setDocumentVerificationTrust(String documentVerificationTrust) {
		this.documentVerificationTrust = documentVerificationTrust;
	}

	public String getDocVerificationTrustReason() {
		return docVerificationTrustReason;
	}

	public void setDocVerificationTrustReason(String docVerificationTrustReason) {
		this.docVerificationTrustReason = docVerificationTrustReason;
	}

	public String getDocumentFrontScan() {
		return documentFrontScan;
	}

	public void setDocumentFrontScan(String documentFrontScan) {
		this.documentFrontScan = documentFrontScan;
	}

	public String getDocumentFrontScanReasons() {
		return documentFrontScanReasons;
	}

	public void setDocumentFrontScanReasons(String documentFrontScanReasons) {
		this.documentFrontScanReasons = documentFrontScanReasons;
	}

	public String getDocumentBackScan() {
		return documentBackScan;
	}

	public void setDocumentBackScan(String documentBackScan) {
		this.documentBackScan = documentBackScan;
	}

	public String getDocumentBackScanReasons() {
		return documentBackScanReasons;
	}

	public void setDocumentBackScanReasons(String documentBackScanReasons) {
		this.documentBackScanReasons = documentBackScanReasons;
	}

	public String getFaceScan() {
		return faceScan;
	}

	public void setFaceScan(String faceScan) {
		this.faceScan = faceScan;
	}

	public String getFaceScanReasons() {
		return faceScanReasons;
	}

	public void setFaceScanReasons(String faceScanReasons) {
		this.faceScanReasons = faceScanReasons;
	}

	public String getDeviceTrust() {
		return deviceTrust;
	}

	public void setDeviceTrust(String deviceTrust) {
		this.deviceTrust = deviceTrust;
	}
	
	public RefValidationStatusCode getStatus() {
		return status;
	}

	public void setStatus(RefValidationStatusCode status) {
		this.status = status;
	}

	public boolean shouldRecapture() {
		if("Y".equalsIgnoreCase(this.documentVerificationTrust)) {
			return false;
		}else {
			return "N".equalsIgnoreCase(this.documentVerificationTrust)||
					this.docVerificationTrustReason.contains("docPhotoNotVisible") || 
					this.docVerificationTrustReason.contains("documentBadImageQuality") ||
					this.docVerificationTrustReason.contains("documentBarcodeNotReadable");
		}
	}

}
