package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="ref_sponsor_configuration", schema="IPS_OWN")
@NamedQueries({
    @NamedQuery(name="RefSponsorConfiguration.getConfigRecord", query="SELECT c FROM RefSponsorConfiguration c WHERE c.sponsorId = :sponsorId AND c.name = :name"),
    @NamedQuery(name="RefSponsorConfiguration.findConfigRecordByName", query="SELECT c FROM RefSponsorConfiguration c WHERE c.name = :name"),
    @NamedQuery(name="RefSponsorConfiguration.getMaxConfigId", query="SELECT MAX(c.configurationId) FROM RefSponsorConfiguration c"),
    @NamedQuery(name="RefSponsorConfiguration.findConfigRecordsBySponsor", query="SELECT c FROM RefSponsorConfiguration c WHERE c.sponsorId = :sponsorId")
})    
public class RefSponsorConfiguration implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String ASSERT_TO_CUSTREG = "Assert.to.CustReg";
    public static final String PERSIST_ADDRESS = "Persist.Address";
    public static final String HIGH_RISK_THRESHOLD = "High.Risk.Threshold";
    public static final String RISK_ADDRESS_RETENTION_PERIOD = "Risk.Address.Retention.Period";
    public static final String DEVICE_REPUTATION_ACTIVATION = "Device.Reputation.Activation";
    public static final String DEVICE_ASSESSMENT_VELOCITY_TIMER = "Device.Assessment.Velocity.Timer";
    public static final String HIGH_RISK_ACTIVATION = "Risk.Address.Activation";
    public static final String IPP_OPTIN_EXPIRATION = "Ipp.optin.expiration";
    public static final String AGE_CHECK_REQUIRED = "Age.check.required";
    public static final String MINIMUM_AGE = "Minimum.age";
    public static final String IPP_ACTIVATION_EXPIRATION = "Ipp.activation.expiration";
    public static final String IPP_CALL_AGENCY_SERVICE = "Ipp.call.agency.service";
    public static final String IPP_AGENCY_PRIMARY_IDS = "Agency.accepted.primary.ids";
    public static final String IPP_AGENCY_SECONDARY_IDS = "Agency.accepted.secondary.ids";
    public static final String AGENCY_SERVICE_ATTEMPTS = "Agency.service.attempts";
    public static final String AGENCY_SERVICE_INTERVAL = "Service.call.interval";
    public static final String AGENCY_SERVICE_CALL_WAIT = "Service.call.wait";
    public static final String IAL2_REQUIRED = "IAL2.required";
    public static final String IAL2_OPTION1_ENABLED = "IAL2.Option1.enabled";
    public static final String PRIMARY_ID_VALIDATOR = "Primary.id.validation.vendor";
    public static final String BACKUP_ID_VALIDATOR = "Backup.id.validation.vendor";
    public static final String IAL2_CONFIRMATION_NOTIFICATION = "IAL2.confirmation.notification";
    public static final String SEND_OPTIN_EMAILS = "Send.optin.emails";
    public static final String SEND_CONFIRMATION_EMAILS = "Send.confirmation.emails";
    public static final String HOLDMAIL_FLOW_FLAG = "Ivs.holdmail.flow.flag";
    public static final String BATCH_REPORT_TOTAL_TRANSACTIONS = "Batch.Report.TotalTransactions";
    public static final String BATCH1_REPORT_INDIVIDUAL_TRANSACTIONS = "Batch1.Report.IndividualTransactions";
    public static final String BATCH1_REPORT_TOTAL_TRANSACTIONS = "Batch1.Report.TotalTransactions";
    public static final String BATCH1_REPORT_TRANSACTIONS_BY_FACILITY = "Batch1.Report.TransactionsByFacility";
    public static final String BUSINESS_ADDRESS_USAGE_CODES = "Business.Address.Usage.Codes";
    public static final String LIMIT_IPP_SCANS = "Limit.IPP.Scans";
    public static final String IPP_SCAN_LIMIT = "IPP.Scan.limit";
    public static final String IAL2_COMFIRMATION_NOTIFICATION = "IAL2.confirmation.notification";
    public static final String DEVICE_VELOCITY_TIMER = "Device.Assessment.Velocity.Timer";
    public static final String ID_VALIDATION_RETRY_ATTEMPTS = "ID.validation.retry.attempts";
    public static final String EQUIFAX_SECONDS_BETWEEN_POLLING = "Equifax.SecondsBetweenPolling";
    public static final String EQUIFAX_SECONDS_BEFORE_RESEND_LINK = "Equifax.SecondsBeforeResendLink";
    public static final String EQUIFAX_POLLING_MINUTES = "Equifax.PollingMinutes";
    
    @Id
    @Column(name = "configuration_id")
    private Long configurationId;
    
    @Column(name = "sponsor_id")
    private Integer sponsorId;
    
    @Column(name = "name")
    private String name;
    
    @Column(name = "value")
    private String value;
    
    @Column(name = "create_date")
    private Date createDate;
    
    @Column(name = "update_date")
    private Date updateDate;
    
    public Long getConfigurationId() {
        return configurationId;
    }
    public void setConfigurationId(Long configurationId) {
        this.configurationId = configurationId;
    }
    
    public Integer getSponsorId() {
        return sponsorId;
    }
    public void setSponsorId(Integer sponsorId) {
        this.sponsorId = sponsorId;
    }
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public String getValue() {
        return value == null ? "" :value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    
    public Date getCreateDate() {
        return createDate;
    }
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
    
    public Date getUpdateDate() {
        return updateDate;
    }
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
