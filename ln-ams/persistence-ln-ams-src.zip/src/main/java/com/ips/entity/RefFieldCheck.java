package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the ref_field_checks database table.
 * 
 */
@Entity
@Table(name="ref_field_checks")
@NamedQueries({
        @NamedQuery(name="refFieldCheck.findAll", query = "Select r FROM RefFieldCheck r"),
        @NamedQuery(name="refFieldCheck.findByName", query="Select r FROM RefFieldCheck r WHERE r.fieldName = :name")
        })
        
public class RefFieldCheck implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String FIELD_CHECK_ERROR_CODE = "01";
    public static final String ADDRESS = "Address";
    public static final String MIDDLE_INITIAL = "MiddleInitial";
    public static final String FIRST_NAME = "FirstName";
    public static final String LAST_NAME = "LastName";
    public static final String EMAIL = "Email";
    public static final String PHONE_NUMBER = "PhoneNumber";
    public static final String SUFFIX = "Suffix";


    @Id
    @Column(name="REF_FIELD_CHECK_ID")
    private long refFieldCheckId;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="FIELD_NAME")
    private String fieldName;

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }
}
