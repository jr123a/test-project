package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ref_workflow_api_type database table.
 * 
 */
@Entity
@Table(name="ref_workflow_api_type")
@NamedQueries({ 
	@NamedQuery(name = "RefWorkflowApiType.getAll", query = "SELECT r FROM RefWorkflowApiType r"),
	@NamedQuery(name="RefWorkflowApiType.findApiTypeId", query="SELECT r FROM RefWorkflowApiType r WHERE r.apiTypeId = :apiTypeId"),
	@NamedQuery(name="RefWorkflowApiType.findByApiTypeCode", query="SELECT r FROM RefWorkflowApiType r WHERE r.apiTypeCode = :apiTypeCode")
})

public class RefWorkflowApiType implements Serializable {
    private static final long serialVersionUID = 1L;
      
    public static final String API_TYPE_CODE_MDL = "MDL";
    public static final String API_TYPE_CODE_HRA = "HRA";
    public static final String API_TYPE_CODE_LN_DA = "LN-DA";
    public static final String API_TYPE_CODE_LN_PV = "PV";
    public static final String API_TYPE_CODE_LN_OTP = "OTP";
    public static final String API_TYPE_CODE_MFA = "MFA";
    public static final String API_TYPE_CODE_LN_DERA = "LN-DERA";
    public static final String API_TYPE_CODE_LN_BIID = "LN-BIID";
    public static final String API_TYPE_CODE_AMS = "AMS";
    public static final String API_TYPE_CODE_EFX_BV = "EFX-BV";
    
    public static final String DECISION_PASS = "PASS"; 
    public static final String DECISION_REVIEW = "REVIEW"; 
    public static final String DECISION_FAIL = "FAIL"; 
    
    public static final String DECISION_SRC_API_RESULT = "APIResult"; 
    public static final String DECISION_SRC_PREV_RESULT = "PreviousResult";
    public static final String DECISION_SRC_VALIDATION = "Validation"; 
    public static final String DECISION_SRC_VELOCITY = "Velocity"; 
    public static final String DECISION_SRC_ABANDONED = "Abandoned";  
    public static final String DECISION_SRC_ERROR = "Error";      
    public static final String DECISION_SRC_PROFILING_DISABLED = "ProfilingDisabled"; 
    public static final String DECISION_SRC_IND_NOT_FOUND = "IndNotFound"; 
        
    public static final long API_TYPE_ID_DA = 1L;
    public static final long API_TYPE_ID_PV_DIT = 2L;
    public static final long API_TYPE_ID_OTP_MFA = 3L;
    public static final long API_TYPE_ID_DERA = 4L;
    public static final long API_TYPE_ID_BIID = 5L;
    public static final long API_TYPE_ID_AMS = 6L;
    
    
    @Id
    @Column(name="API_TYPE_ID")
    private long apiTypeId;

    @Column(name="API_TYPE_CODE")
    private String apiTypeCode;
    
    @Column(name="API_TYPE_DESCRIPTION")
    private String apiTypeDescription;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

	public long getApiTypeId() {
		return apiTypeId;
	}

	public void setApiTypeId(long apiTypeId) {
		this.apiTypeId = apiTypeId;
	}

	public String getApiTypeCode() {
		return apiTypeCode;
	}

	public void setApiTypeCode(String apiTypeCode) {
		this.apiTypeCode = apiTypeCode;
	}

	public String getApiTypeDescription() {
		return apiTypeDescription;
	}

	public void setApiTypeDescription(String apiTypeDescription) {
		this.apiTypeDescription = apiTypeDescription;
	}
	
	public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

}
