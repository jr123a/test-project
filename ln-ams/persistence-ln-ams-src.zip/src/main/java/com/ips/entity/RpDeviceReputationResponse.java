package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rp_device_reputation_response")
@NamedQueries({ @NamedQuery(name = "RpDeviceReputationResponse.getAll", query = "SELECT r FROM RpDeviceReputationResponse r"),
        @NamedQuery(name = "RpDeviceReputationResponse.getByRequestId", query = "SELECT r FROM RpDeviceReputationResponse r WHERE r.requestId = :requestId"),
        @NamedQuery(name = "RpDeviceReputationResponse.getListByPersonId", query = "SELECT r FROM RpDeviceReputationResponse r WHERE r.person.personId = :personId ORDER BY r.createDate DESC")
})

public class RpDeviceReputationResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RPDEVICEREPUTATIONRESPONSESEQ")
    @SequenceGenerator(name="RPDEVICEREPUTATIONRESPONSESEQ",sequenceName="RP_DEVICE_REPUTATION_RESPONSE_SEQ", allocationSize=1)

	@Column(name = "DEVICE_REPUTATION_RESPONSE_ID")
    private long deviceReputationResponseId;

    @Column(name = "REQUEST_ID")
    private String requestId;

    // bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name = "PERSON_ID")
    private Person person;

	@Column(name = "REQUEST")
    private String request;
    
    @Column(name = "RESPONSE")
    private String response;
    
    @Column(name = "TRANSACTION_ORIGIN_ID", insertable = false, updatable = false)
    private long transactionOriginId;
    
    //bi-directional many-to-one association to RefApp
    @ManyToOne
    @JoinColumn(name="TRANSACTION_ORIGIN_ID")
    private RefApp refApp;
    
    @Column(name = "WORKFLOW_API_TYPE_ID", insertable = false, updatable = false)
    private long workflowApiTypeId;
     
    //bi-directional many-to-one association to RefWorkflowApiType
    @ManyToOne
    @JoinColumn(name="WORKFLOW_API_TYPE_ID")
    private RefWorkflowApiType refWorkflowApiType;
    
    @Column(name = "CUSTOMER_CATEGORY_ID", insertable = false, updatable = false)
    private long customerCategoryId;
     
    //bi-directional many-to-one association to RefWorkflowApiType
    @ManyToOne
    @JoinColumn(name="CUSTOMER_CATEGORY_ID")
    private RefCustomerCategory refCustomerCategory;
       
    @Column(name = "OVERALL_DECISION")
    private String overallDecision;
    
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "UPDATE_DATE")
    private Date updateDate;

    public long getDeviceReputationResponseId() {
        return deviceReputationResponseId;
    }

    public void setDeviceReputationResponseId(long deviceReputationResponseId) {
        this.deviceReputationResponseId = deviceReputationResponseId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public long getTransactionOriginId() {
		return transactionOriginId;
	}

	public RefApp getRefApp() {
		return refApp;
	}

	public void setRefApp(RefApp refApp) {
		this.refApp = refApp;
	}

	public RefWorkflowApiType getRefWorkflowApiType() {
		return refWorkflowApiType;
	}

	public void setRefWorkflowApiType(RefWorkflowApiType refWorkflowApiType) {
		this.refWorkflowApiType = refWorkflowApiType;
	}

	public RefCustomerCategory getRefCustomerCategory() {
		return refCustomerCategory;
	}

	public void setRefCustomerCategory(RefCustomerCategory refCustomerCategory) {
		this.refCustomerCategory = refCustomerCategory;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public long getWorkflowApiTypeId() {
		return workflowApiTypeId;
	}

	public long getCustomerCategoryId() {
		return customerCategoryId;
	}

	public String getOverallDecision() {
		return overallDecision;
	}

	public void setOverallDecision(String overallDecision) {
		this.overallDecision = overallDecision;
	}

	public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

}
