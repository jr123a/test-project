package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the rp_workflow_api_decision database table.
 * 
 */
@Entity
@Table(name = "rp_workflow_api_decision")
@NamedQueries({ @NamedQuery(name = "RpWorkflowApiDecision.getAll", query = "SELECT r FROM RpWorkflowApiDecision r"),
        @NamedQuery(name = "RpWorkflowApiDecision.getByWorkflowApiTypeId", query = "SELECT r FROM RpWorkflowApiDecision r WHERE r.workflowApiTypeId = :workflowApiTypeId ORDER BY r.createDate DESC"),
        @NamedQuery(name = "RpWorkflowApiDecision.getListByEventId", query = "SELECT r FROM RpWorkflowApiDecision r WHERE r.rpEvent.eventId = :eventId ORDER BY r.createDate DESC")
})


public class RpWorkflowApiDecision implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final String EXPERIAN_CROSSCORE_SUPPLIER_NAME = "Experian CrossCore"; 
    public static final String LOW_RISK_JSON_KEY = "LowRisk"; 
    
    public static final String HIGH_RISK_ADDR_LOW_RISK_DATA_KEY = "highRiskAddrLowRisk"; 

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RPWORKFLOWAPIDECISIONSEQ")
    @SequenceGenerator(name="RPWORKFLOWAPIDECISIONSEQ",sequenceName="RP_WORKFLOW_API_DECISION_SEQ", allocationSize=1)
    @Column(name = "API_DECISION_ID")
    private long apiDecisionId;

    @Column(name = "WORKFLOW_API_TYPE_ID")
    private long workflowApiTypeId;
 
	@Column(name = "DECISION")
    private String decision;
	
	@Column(name = "DECISION_SOURCE")
    private String decisionSource;
    
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "UPDATE_DATE")
    private Date updateDate;

    // bi-directional many-to-one association to RpEvent
    @ManyToOne
    @JoinColumn(name = "EVENT_ID")
    private RpEvent rpEvent;
    
	public long getApiDecisionId() {
		return apiDecisionId;
	}

	public void setApiDecisionId(long apiDecisionId) {
		this.apiDecisionId = apiDecisionId;
	}

	public long getWorkflowApiTypeId() {
		return workflowApiTypeId;
	}

	public void setWorkflowApiTypeId(long workflowApiTypeId) {
		this.workflowApiTypeId = workflowApiTypeId;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public String getDecisionSource() {
		return decisionSource;
	}

	public void setDecisionSource(String decisionSource) {
		this.decisionSource = decisionSource;
	}

	public RpEvent getRpEvent() {
		return rpEvent;
	}

	public void setRpEvent(RpEvent rpEvent) {
		this.rpEvent = rpEvent;
	}

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

}
