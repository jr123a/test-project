package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;


/**
 * The persistent class for the rp_equifax_result database table.
 * 
 */
@Entity
@Table(name="rp_equifax_result")
@NamedQueries({
	@NamedQuery(name="RpEquifaxResult.findAll", query="SELECT t FROM RpEquifaxResult t"),
    @NamedQuery(name="RpEquifaxResult.findByEventId", query = "Select t FROM RpEquifaxResult t WHERE t.eventId = :eventId" ),
    @NamedQuery(name="RpEquifaxResult.getCount", query="SELECT COUNT(t) FROM RpEquifaxResult t WHERE t.finalResponseTimestamp <= :currentTime"),    
})
public class RpEquifaxResult implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id    
    @Column(name="EVENT_ID")
    private long eventId;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="FINAL_RESPONSE_TIMESTAMP")
    private Timestamp finalResponseTimestamp;
    
    @Column(name="FRAUD_INDICATOR_CODE")
    private String fraudIndicatorCode;

    @Column(name="IDENTITY_SCORE")
    private int identityScore;

    @Column(name="INTERACTIVE_QUERY_SCORE")
    private int interactiveQueryScore;
    
    @Column(name="MATCH_ASSESSMENT_CODE")
    private String matchAssessmentCode;

    @Column(name="OVERALL_SCORE")
    private int overallScore;

    @Column(name="RISK_STRATEGY_COMPONENT_USPF")
    private String riskStrategyComponentUSPF;

    @Column(name="RISK_STRATEGY_COMPONENT_USPR")
    private String riskStrategyComponentUSPR;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;

    //bi-directional many-to-one association to RpEquifaxFinalReasonCode
    @OneToMany(mappedBy="rpEquifaxResult", cascade=CascadeType.MERGE, fetch=FetchType.EAGER)
    private List<RpEquifaxFinalReasonCode> rpEquifaxFinalReasonCodes;

    //bi-directional one-to-one association to RpEvent
    @OneToOne
    @JoinColumn(name="EVENT_ID", insertable = false, updatable = false)
    private RpEvent rpEvent;

    //bi-directional many-to-one association to RefEquifaxFraudIndicator
    @ManyToOne
    @JoinColumn(name="FRAUD_INDICATOR_CODE", insertable = false, updatable = false)
    private RefEquifaxFraudIndicator refEquifaxFraudIndicator;

    //bi-directional many-to-one association to RefEquifaxMatchAssessment
    @ManyToOne
    @JoinColumn(name="MATCH_ASSESSMENT_CODE", insertable = false, updatable = false)
    private RefEquifaxMatchAssessment refEquifaxMatchAssessment;

    public long getEventId() {
        return this.eventId;
    }

    public void setEventId(long eventId) {
        this.eventId = eventId;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getFinalResponseTimestamp() {
        return this.finalResponseTimestamp;
    }

    public void setFinalResponseTimestamp(Timestamp finalResponseTimestamp) {
        this.finalResponseTimestamp = finalResponseTimestamp;
    }

    public String getFraudIndicatorCode() {
        return fraudIndicatorCode;
    }

    public void setFraudIndicatorCode(String fraudIndicatorCode) {
        this.fraudIndicatorCode = fraudIndicatorCode;
    }

    public int getIdentityScore() {
        return this.identityScore;
    }

    public void setIdentityScore(int identityScore) {
        this.identityScore = identityScore;
    }

    public int getInteractiveQueryScore() {
        return this.interactiveQueryScore;
    }

    public void setInteractiveQueryScore(int interactiveQueryScore) {
        this.interactiveQueryScore = interactiveQueryScore;
    }

    public String getMatchAssessmentCode() {
        return matchAssessmentCode;
    }

    public void setMatchAssessmentCode(String matchAssessmentCode) {
        this.matchAssessmentCode = matchAssessmentCode;
    }

    public int getOverallScore() {
        return this.overallScore;
    }

    public void setOverallScore(int overallScore) {
        this.overallScore = overallScore;
    }

    public String getRiskStrategyComponentUSPF() {
        return this.riskStrategyComponentUSPF;
    }

    public void setRiskStrategyComponentUSPF(String riskStrategyComponentUSPF) {
        this.riskStrategyComponentUSPF = riskStrategyComponentUSPF;
    }

    public String getRiskStrategyComponentUSPR() {
        return this.riskStrategyComponentUSPR;
    }

    public void setRiskStrategyComponentUSPR(String riskStrategyComponentUSPR) {
        this.riskStrategyComponentUSPR = riskStrategyComponentUSPR;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public List<RpEquifaxFinalReasonCode> getRpEquifaxFinalReasonCodes() {
        if (rpEquifaxFinalReasonCodes == null) {
            rpEquifaxFinalReasonCodes = new ArrayList<>();
        }
        
        return rpEquifaxFinalReasonCodes;
    }

    public void setRpEquifaxFinalReasonCodes(List<RpEquifaxFinalReasonCode> rpEquifaxFinalReasonCodes) {
        this.rpEquifaxFinalReasonCodes = rpEquifaxFinalReasonCodes;
    }

    public RpEquifaxFinalReasonCode addRpEquifaxFinalReasonCode(RpEquifaxFinalReasonCode rpEquifaxFinalReasonCode) {
        getRpEquifaxFinalReasonCodes().add(rpEquifaxFinalReasonCode);
        rpEquifaxFinalReasonCode.setRpEquifaxResult(this);

        return rpEquifaxFinalReasonCode;
    }

    public RpEquifaxFinalReasonCode removeRpEquifaxFinalReasonCode(RpEquifaxFinalReasonCode rpEquifaxFinalReasonCode) {
        getRpEquifaxFinalReasonCodes().remove(rpEquifaxFinalReasonCode);
        rpEquifaxFinalReasonCode.setRpEquifaxResult(null);

        return rpEquifaxFinalReasonCode;
    }


}
