package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "physical_letter_data")

@NamedQuery(name = "PhysicalLetterData.getByEventId", query = "SELECT i FROM PhysicalLetterData i where i.ippEvent.ippEventId = :eventId") 
@NamedQuery(name="PhysicalLetterData.findPhysicalLetterDataBySponsor", query="SELECT r FROM PhysicalLetterData r WHERE r.refSponsor.sponsorId = :sponsorId")

public class PhysicalLetterData implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="physical_letter_dataSeq")
    @SequenceGenerator(name="physical_letter_dataSeq",sequenceName="PHYSICAL_LETTER_DATA_SEQ", allocationSize=1)
    @Column(name = "PHYSICAL_LETTER_ID")
    private long physicalLetterId;

    // bi-directional many-to-one association to IppEvent
    @ManyToOne
    @JoinColumn(name = "ipp_event_id")
    private IppEvent ippEvent;

    @Column(name = "ENROLLMENT_CODE")
    private String enrollmentCode;

    @Column(name = "DATE_SENT")
    private Timestamp dateSent;

    @Column(name = "CUSTOMER_ADDRESS_1")
    private String customerAddress1;

    @Column(name = "CUSTOMER_CITY")
    private String customerCity;

    @Column(name = "CUSTOMER_STATE")
    private String customerState;

    @Column(name = "CUSTOMER_ZIP")
    private String customerZip;

    @Column(name = "FIRST_NAME")
    private String firstName;

    @Column(name = "MIDDLE_NAME")
    private String middleName;

    @Column(name = "LAST_NAME")
    private String lastName;

    @Column(name = "USPS_LOGO_REFERENCE_ID")
    private long uspsLogoReferenceId;

    // bi-directional many-to-one association to RefSponsor
    @ManyToOne
    @JoinColumn(name = "SPONSOR_ID")
    private RefSponsor refSponsor;

    @Column(name = "GREETING")
    private String greeting;

    @Column(name = "PARAGRAPH_1")
    private String paragraph1;

    @Column(name = "PARAGRAPH_2")
    private String paragraph2;

    @Column(name = "PARAGRAPH_3")
    private String paragraph3;

    @Column(name = "PARAGRAPH_4")
    private String paragraph4;

    @Column(name = "PARAGRAPH_5")
    private String paragraph5;

    @Column(name = "CLOSING")
    private String closing;

    @Column(name = "POSTSCRIPT")
    private String postScript;

    @Column(name = "CREATE_DATE")
    private Timestamp createDate;

    @Column(name = "UPDATE_DATE")
    private Timestamp updateDate;

    public long getPhysicalLetterId() {
        return physicalLetterId;
    }

    public void setPhysicalLetterId(long physicalLetterId) {
        this.physicalLetterId = physicalLetterId;
    }

    public IppEvent getIppEvent() {
        return ippEvent;
    }

    public void setIppEvent(IppEvent ippEvent) {
        this.ippEvent = ippEvent;
    }

    public String getEnrollmentCode() {
        return enrollmentCode;
    }

    public void setEnrollmentCode(String enrollmentCode) {
        this.enrollmentCode = enrollmentCode;
    }

    public Timestamp getDateSent() {
        return dateSent;
    }

    public void setDateSent(Timestamp dateSent) {
        this.dateSent = dateSent;
    }

    public String getCustomerAddress1() {
        return customerAddress1;
    }

    public void setCustomerAddress1(String customerAddress1) {
        this.customerAddress1 = customerAddress1;
    }

    public String getCustomerCity() {
        return customerCity;
    }

    public void setCustomerCity(String customerCity) {
        this.customerCity = customerCity;
    }

    public String getCustomerState() {
        return customerState;
    }

    public void setCustomerState(String customerState) {
        this.customerState = customerState;
    }

    public String getCustomerZip() {
        return customerZip;
    }

    public void setCustomerZip(String customerZip) {
        this.customerZip = customerZip;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public long getUspsLogoReferenceId() {
        return uspsLogoReferenceId;
    }

    public void setUspsLogoReferenceId(long uspsLogoReferenceId) {
        this.uspsLogoReferenceId = uspsLogoReferenceId;
    }

    public RefSponsor getRefSponsor() {
        return refSponsor;
    }

    public void setRefSponsor(RefSponsor refSponsor) {
        this.refSponsor = refSponsor;
    }

    public String getParagraph1() {
        return paragraph1;
    }

    public void setParagraph1(String paragraph1) {
        this.paragraph1 = paragraph1;
    }

    public String getParagraph2() {
        return paragraph2;
    }

    public void setParagraph2(String paragraph2) {
        this.paragraph2 = paragraph2;
    }

    public String getParagraph3() {
        return paragraph3;
    }

    public void setParagraph3(String paragraph3) {
        this.paragraph3 = paragraph3;
    }

    public String getParagraph4() {
        return paragraph4;
    }

    public void setParagraph4(String paragraph4) {
        this.paragraph4 = paragraph4;
    }

    public String getParagraph5() {
        return paragraph5;
    }

    public void setParagraph5(String paragraph5) {
        this.paragraph5 = paragraph5;
    }

    public String getClosing() {
        return closing;
    }

    public void setClosing(String closing) {
        this.closing = closing;
    }

    public String getPostScript() {
        return postScript;
    }

    public void setPostScript(String postScript) {
        this.postScript = postScript;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public String getGreeting() {
        return greeting;
    }

    public void setGreeting(String greeting) {
        this.greeting = greeting;
    }

}
