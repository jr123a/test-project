package com.ips.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ref_product_status_codes database table.
 * 
 */
@Entity
@Table(name="ref_product_status_codes")
@NamedQueries({
    @NamedQuery(name="RefProductStatusCode.findAll", query="SELECT r FROM RefServiceStatusCode r"),
    @NamedQuery(name="RefProductStatusCode.findByName", query="Select r FROM RefProductStatusCode r WHERE r.productStatus = :name")
})    
public class RefProductStatusCode implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String PRODUCT_STATUS_PASS = "PASS";
    public static final String PRODUCT_STATUS_COMPLETED = "COMPLETED";
    public static final String PRODUCT_STATUS_PENDING = "PENDING";
    public static final String PRODUCT_STATUS_ERROR = "ERROR";
        
    @Id
    @Column(name="product_status_id")
    private long productStatusId;
        
    @Column(name="product_status")
    private String productStatus;
    
    @Column(name="create_date")
    private Timestamp createDate;

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getProductStatus() {
        return productStatus;
    }

    public void setProductStatus(String productStatus) {
        this.productStatus = productStatus;
    }
    
    public boolean isError() {
        return getProductStatus().equals(PRODUCT_STATUS_ERROR);
    }
}
