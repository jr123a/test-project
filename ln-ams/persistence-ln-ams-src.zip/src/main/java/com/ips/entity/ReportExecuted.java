package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

/**
 * The persistent class for the report_executed database table.
 * 
 */
@Entity
@Table(name="report_executed")
@NamedQueries({
    @NamedQuery(name="ReportExecuted.findAll", query="SELECT r FROM ReportExecuted r")
})
public class ReportExecuted implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="REPORT_NAME")
    private String reportName;

    @Temporal(TemporalType.DATE)
    @Column(name="LAST_DATE_EXECUTED")
    private Date lastDateExecuted;

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public Date getLastDateExecuted() {
        return lastDateExecuted;
    }

    public void setLastDateExecuted(Date lastDateExecuted) {
        this.lastDateExecuted = lastDateExecuted;
    }
}
