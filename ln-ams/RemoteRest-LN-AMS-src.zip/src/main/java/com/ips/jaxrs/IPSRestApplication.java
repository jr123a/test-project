package com.ips.jaxrs;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ibm.websphere.jaxrs.providers.json4j.JSON4JObjectProvider;

@ApplicationPath("resources")
public class IPSRestApplication extends Application implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private static final Logger LOG = LogManager.getLogger(IPSRestApplication.class.getName()); 
    
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<Class<?>>();
        classes.add(JSON4JObjectProvider.class);
        classes.add(RemoteRestResource.class);
        LOG.debug("IPSRestApplication REST Classes:"+classes);
        return classes;
    }
}
