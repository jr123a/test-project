package com.ips.validation;

import java.io.Serializable;

public enum ErrorMessage implements Serializable {
	MISSING_REQUIRED_FIELDS (402, "Required fields not provided: %s"),
	MISSING_REQUIRED_FIELD  (402, "%s is required but field is missing"),
	EMPTY_REQUIRED_FIELD    (402, "%s is required but value is empty"),
	INVALID_FORMAT_FIELDS 	(401, "%s contains invalid characters or formatting is invalid."),
	INVALID_FIELD_LENGTH 	(401, "%s must not be %s than %s characters"),
	INVALID_FORMATTING   	(400, "%s contains invalid characters or formatting is invalid"),
    SAME_DIGITS             (400, "%s contains same digits"),
    INVALID_2_LETTER_CODE   (400, "%s 2-Letter code is invalid"),
    INVALID_3_LETTER_CODE   (400, "%s 3-Letter code is invalid"),
    INVALID_CODE            (400, "%s for %s code cannot be found"),
    SPONSOR_APP_DISABLED    (400, "Web service calls for %s are disabled"),
	INVALID_INPUT_DATA      (400, "%s has invalid input data. Reason: %s"),
    SPONSOR_ID_NOT_FOUND    (400, "Sponsor for sponsorID %s not found"),
    MISSING_ANSWER          (400, "Answers must be provided for all questions"),
    INVALID_STRING_LENGTH   (400, "%s must not be %s than %s characters"),
    INTERNAL_ERROR          (500, "An internal error occurred processing the request"),
    INVALID_TRANSACTION     (400, "TransactionID does not map to an existing record"),
    INVALID_BARCODE_FORMA   (400, "Barcode format is invalid"),
    INVALID_PARSE_REQUEST   (400, "Error occurred while parsing barcode"),
    CUST_REG_BAD_RESPONSE   (500, "Could not retrieve cust reg info"), 
    AUTHENTICATION_FAILED   (405, "Authentication failed"),
    BAD_RESPONSE            (500, "Internal error."),
    INVALID_REQUEST         (500, "Invalid request."),
    SPONSOR_NOT_FOUND       (400, "Sponsor for sponsorCode not found"),
    APP_NOT_FOUND           (400, "Application for appCode not found"),
    EVENT_NOT_IN_SYSTEM     (400, "Proofing event not in system"),
    EVENT_NOT_FOUND         (400, "In Person Proofing event not found for record locator: %s");
    
	
    private int httpResponseCode;
    private String message;
    private Object[] messagePlaceholders;
     
    private ErrorMessage(int httpResponseCode, String message) {
        this.httpResponseCode = httpResponseCode;
        this.message = message;
    }

    public int getHttpResponseCode() {
        return httpResponseCode;
    }

    public String getMessage() {
        if (messagePlaceholders != null && messagePlaceholders.length > 0) {
             return String.format(message, messagePlaceholders);
        } else {
            return message;
        }
    }

    public Object[] getMessagePlaceholders() {
        return messagePlaceholders;
    }

    public void setMessagePlaceholders(Object[] messagePlaceholders) {
        this.messagePlaceholders = messagePlaceholders;
    }
    /**
     * Overloaded setter to take a single string argument
     * @param messagePlaceholder
     */
    public void setMessagePlaceholders(String messagePlaceholder) {
        this.messagePlaceholders = new Object[] {messagePlaceholder};
    }
         
    public String getFormattedErrorMessage(String arg1) {
    	String formattedErrorMessage = String.format(this.message, arg1);
    	return formattedErrorMessage;
    }
    
    public String getFormattedErrorMessage(String arg1, String arg2) {
    	String formattedErrorMessage = String.format(this.message, arg1, arg2);
    	return formattedErrorMessage;
    }
    
    public String getFormattedErrorMessage(String arg1, String arg2, String arg3) {
    	String formattedErrorMessage = String.format(this.message, arg1, arg2, arg3);
    	return formattedErrorMessage;
    }
}
