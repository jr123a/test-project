package com.ips.validation;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ips.common.common.Utils;
import com.ips.persistence.common.CountryCode;
import com.ips.request.RemoteRequest;
import com.ips.response.InputValidationError;
import com.ips.service.RemoteProofingServiceImpl;

public class RemoteProofingValidation implements Serializable {
    private final static long serialVersionUID = 1L;

    private final static Logger LOG = LogManager.getLogger(RemoteProofingValidation.class.getName()); 
    private final static String VALUE_COUNTRY_US = "US";
    private final static String VALUE_COUNTRY_GB = "GB";
    private final static String VALUE_COUNTRY_UK = "UK";
    private final static String PARAM_LONGER = "longer"; 
    private final static String PARAM_SHORTER = "shorter"; 
    public  final static String SPONSOR_APP_DISABLED_FMT = "Web service call for %s application of %s sponsor is disabled";
	private static final List<String> alpha2CodesList = Arrays.asList(CountryCode.getAlpha2Codes());
	private static final List<String> alpha3CodesList = Arrays.asList(CountryCode.getAlpha3Codes());

    public static HashMap<String, InputValidationError> validateRemoteProofingData(RemoteRequest remReq) {
        HashMap<String, InputValidationError> validationErrorMap = new HashMap<>();
		
    	String assessmentCall = remReq.getAssessmentCall();
 		boolean checkDevice = RemoteProofingServiceImpl.CHECK_DEVICE.equalsIgnoreCase(assessmentCall);
		boolean checkDevicePlus = RemoteProofingServiceImpl.CHECK_DEVICE_PLUS.equalsIgnoreCase(assessmentCall);
		boolean verifyBusiness = RemoteProofingServiceImpl.VERIFY_BUSINESS.equalsIgnoreCase(assessmentCall);
  		boolean verifyPhone = RemoteProofingServiceImpl.VERIFY_PHONE.equalsIgnoreCase(assessmentCall);
 		boolean confirmPasscode = RemoteProofingServiceImpl.CONFIRM_PASSCODE.equalsIgnoreCase(assessmentCall);
 		boolean requestPasscode = RemoteProofingServiceImpl.REQUEST_PASSCODE.equalsIgnoreCase(assessmentCall);
 		boolean validateLink = RemoteProofingServiceImpl.VALIDATE_LINK.equalsIgnoreCase(assessmentCall);
 		boolean resendLink = RemoteProofingServiceImpl.RESEND_LINK.equalsIgnoreCase(assessmentCall);
 		boolean hasPersonDataInput = checkDevicePlus || verifyBusiness || checkDevice || verifyPhone || requestPasscode
 				|| resendLink;
 		boolean domesticAddress = false;
 				
    	String fieldValue = null;
      	String notAllowedChars = "";
      	InputValidationError inputValidationError = null;
      	
      	if (hasPersonDataInput) {
	      	String countryFieldName = RemoteProofingValidatedField.FIELD_COUNTRY;
	  		fieldValue = remReq.getCountry();
	  		inputValidationError = getNullOrEmptyFieldErrorMsg(countryFieldName, fieldValue, true, validationErrorMap);
	
	        if (inputValidationError != null) {
	       		fieldValue = VALUE_COUNTRY_US;
	       		remReq.setCountry(VALUE_COUNTRY_US);
	       		domesticAddress = true;
	       		validationErrorMap.remove(countryFieldName);
	    	}
	       	else {
	       		RemoteProofingValidatedField fieldValidation = RemoteProofingValidatedField.lookupByFieldName(countryFieldName);
	       		inputValidationError = checkFormatValidationError(countryFieldName, fieldValue, null, fieldValidation.getRegex(), 2, 3, 
	        			false, validationErrorMap);
	          	
	       		if (inputValidationError == null) {  
	       			inputValidationError = getCountryAbbrValidationError(countryFieldName, fieldValue, validationErrorMap);
	       		}
	       		
	       		if (inputValidationError == null) {       		        		
	       			if(fieldValue.length() == 3) {
        				fieldValue = CountryCode.convertAlpha3ToAlpha2(fieldValue);
        			}

        			if (VALUE_COUNTRY_US.equalsIgnoreCase(fieldValue)) {
        				domesticAddress = true;
        			}
        			else if (VALUE_COUNTRY_GB.equalsIgnoreCase(fieldValue)) {
        				fieldValue = VALUE_COUNTRY_UK;
        			}
        			
        			remReq.setCountry(fieldValue);
	       		}
	    	}
      	}

        RemoteProofingValidatedField[] validatedFieldArray = null;
		try {
			validatedFieldArray = getRemoteProofingValidatedField(assessmentCall);
		} catch (Exception e) {
			LOG.error("Exception occurred while getting RemoteProofingValidatedField", e);
			return null;
		}
            	    
        for (RemoteProofingValidatedField fieldValidation : validatedFieldArray) {
           	try {
           		String fieldName = fieldValidation.getFieldName();

           		switch(fieldName) {
	           		case RemoteProofingValidatedField.FIELD_SPONSOR_CODE:
	           		case RemoteProofingValidatedField.FIELD_APP_CODE:

	           			if (RemoteProofingValidatedField.FIELD_SPONSOR_CODE.equalsIgnoreCase(fieldName)) {
	           				fieldValue = remReq.getSponsorCode();
                		}
                		else {
                			fieldValue = remReq.getAppCode();
                		}
	                	
	           			inputValidationError = checkFormatValidationError(fieldName, fieldValue, null, fieldValidation.getRegex(), 2, 3, 
	                			true, validationErrorMap);
	                	
	                	if (inputValidationError == null) {
	                		if (RemoteProofingValidatedField.FIELD_SPONSOR_CODE.equalsIgnoreCase(fieldName)) {
	                			remReq.setSponsorCode(fieldValue);
	                		}
	                		else {
	                			remReq.setAppCode(fieldValue);
	                		}
	                	}
	         			break;
 	           		case RemoteProofingValidatedField.FIELD_COMPANY_NAME:
	                	fieldValue = remReq.getCompanyName();
	                	
	         			notAllowedChars   = "!$%^*\"<>=[]\\;{}|:`~"; 
	   				    //All nonAlphaNum = "!$%^*\"<>=[]\\;{}|:`~@+?&()#/.,'-_"; 
	   			  	    //Allowed Chars   = "A1 @+?&()#/.,'-_";         			
	         			//Regex: ^[A-Za-z0-9\\-\\.'_,\"&()?#/+@\\s]*$ (from CustReg)
						
	         			inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 0, 
	                			true, validationErrorMap);
	         			
	         			if (inputValidationError == null) {
	                		remReq.setCompanyName(fieldValue);
	                	}
	                	break;
	             	case RemoteProofingValidatedField.FIELD_COMPANY_FEIN:
						fieldValue = remReq.getCompanyFEIN();
							
						//Regex: ^[0-9]{9}$
						
						inputValidationError = checkFormatValidationError(fieldName, fieldValue, null, fieldValidation.getRegex(), 0, 0, 
	                			fieldValidation.isRequired(), validationErrorMap);
						
						if (inputValidationError == null) {
	                		remReq.setCompanyFEIN(fieldValue);
	                	}
	           			break;
	           		case RemoteProofingValidatedField.FIELD_FIRST_NAME:
	                	fieldValue = remReq.getFirstName();
	                	
	         			notAllowedChars   = "!@$%^&*()+\"<>?=[]\\;{}|`~#/,:_";
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/,:_.'-";
	   			  	    //Allowed Chars   = "A .'-";
						//Regex: ^[\\sA-Za-z'\\.'\\-]*$ (FirstName)
	         			
	         			inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 255, 
	                			fieldValidation.isRequired(), validationErrorMap);
	         			
	         			if (inputValidationError == null) {
	         				remReq.setFirstName(fieldValue);
	                	}
	           			break; 
	           		case RemoteProofingValidatedField.FIELD_LAST_NAME:
	                	fieldValue = remReq.getLastName();
	                	
	         			notAllowedChars   = "!@$%^&*()+\"<>?=[]\\;{}|`~#/,:_";
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/,:_.'-";
	   			  	    //Allowed Chars   = "A .'-";
	         			//Regex: ^[\\sA-Za-z'\\-\\.]*$ (LastName)
	         			
	         			inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 255, 
	                			fieldValidation.isRequired(), validationErrorMap);
	         			
	         			if (inputValidationError == null) {
	         				remReq.setLastName(fieldValue);
	                	}
	           			break;                  
	           		case RemoteProofingValidatedField.FIELD_EMAIL_ADDRESS:
	                	fieldValue = remReq.getEmailAddress();
	                	
	         			notAllowedChars   = "!$%^&*()\"<>?=[]\\;{}|`~#/,:'";
	   				    //All nonAlphaNum = "!$%^&*()\"<>?=[]\\;{}|`~#/,:'+@.-_";
	   			  	    //Allowed Chars   = "A1_-.@+";
	         			//Regex:^([0-9a-zA-Z]([-.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$
		         			
	         			inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 255, 
	                			fieldValidation.isRequired(), validationErrorMap);
	         			
	         			if (inputValidationError == null) {
	                		remReq.setEmailAddress(fieldValue);
	                	}
	         			break;
	           		case RemoteProofingValidatedField.FIELD_STREET_ADDRESS_1:
	                	fieldValue = remReq.getStreetAddress1();
	                	
	         			notAllowedChars   = "!$%^*<>=[]\\;{}|`:~"; 
	   				    //All nonAlphaNum = "!$%^*<>=[]\\;{}|`:~&@()+?#/.,'-_\""; 
	   			  	    //Allowed Chars   = "A1 #/-.,'_?+&@()\"";
	         			//Regex: ^[0-9A-Za-z'\-\._",&()?#/+@\s]*$
	         			inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 255, 
	                			fieldValidation.isRequired(), validationErrorMap);
	         	
	         			if (inputValidationError == null) {
	                		remReq.setStreetAddress1(fieldValue);
	                	}
	                	break;
	           		case RemoteProofingValidatedField.FIELD_STREET_ADDRESS_2:
	                	fieldValue = remReq.getStreetAddress2();
	                	
	                	if (domesticAddress) {
	                		notAllowedChars   = "!$%^*<>=[]\\;{}|`:~"; 
		   				    //All nonAlphaNum = "!$%^*<>=[]\\;{}|`:~&@()+?#/.,'-_\""; 
		   			  	    //Allowed Chars   = "A1 #/-.,'_?+&@()\"";
		         			//Regex: ^[0-9A-Za-z'\-\._",&()?#/+@\s]*$
							
	                		inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 255, 
		                			fieldValidation.isRequired(), validationErrorMap);
	                	}
	                	else {
	 	                	remReq.setStreetAddress2(null);
	 	                	remReq.setStreetAddress3(null);
	 	                }
	                	
                		if (inputValidationError == null && fieldValidation.isRequired()) {
	                		remReq.setStreetAddress2(fieldValue);
	                	}
	                	break;
 	           		case RemoteProofingValidatedField.FIELD_CITY:
	         			fieldValue = remReq.getCity();
	         			
	         			notAllowedChars   = "!@$%^&*()+\"<>?=[]\\;{}|`~#/,:_"; 
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/,:_.'-"; 
	   			  	    //Allowed Chars   = "A -'.";
	         			//Regex: ^[A-Za-z'\-\.\s]*$
						
	         			inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 50, 
	                			fieldValidation.isRequired(), validationErrorMap);
	         		
	         			if (inputValidationError == null) {
	                		remReq.setCity(fieldValue);
	                	}
	                	break;
	           		case RemoteProofingValidatedField.FIELD_STATE:
	         			fieldValue = remReq.getState();
		    				    
	         			if (domesticAddress) {
	         				inputValidationError = checkFormatValidationError(fieldName, fieldValue, null, null, 2, 2, 
		                			fieldValidation.isRequired(), validationErrorMap);
	                      	
	         				if (inputValidationError == null) {
	         					inputValidationError = validateDomesticStates(fieldName, fieldValue, validationErrorMap);
	                		}
	         			}
	         			else {
	         				//Regex: ^[A-Za-z'\-\.\s]*$
	         			}
	         			
	         			if (inputValidationError == null) {
	                		remReq.setState(fieldValue);
	                	}
	         			break;
 	           		case RemoteProofingValidatedField.FIELD_ZIPCODE:
	         			fieldValue = remReq.getZipCode();
	         			
		         		notAllowedChars   = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'_";
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'_-";
	   			  	    //Allowed Chars   = "1-";
						
	         			String validationRegex = null;
	                	int minLength = 0;
	                	int maxLength = 20;
	                	
	                	if (domesticAddress) {
	                		minLength = 5;
	                    	maxLength = 10;
	                		validationRegex = fieldValidation.getRegex();
	                	}
	                	else {
	                		notAllowedChars   = "!$%^*<>=[]\\;{}|`~:";
		   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'-_";
		   			  	    //Allowed Chars   = "A1-";
		         			//Regex: ^[0-9\-\.'\sA-Za-z"_&( ),?#/+@]*$
	                	}
	                	
	                	inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, validationRegex, minLength, maxLength, 
	                			fieldValidation.isRequired(), validationErrorMap);
	                  	
	                	if (inputValidationError == null) {
	                		if (domesticAddress) {
	                			inputValidationError = getZipCodeValidationErrorMsg(fieldName, fieldValue, validationErrorMap);
	                		}
	                	}
	                	
	                	if (inputValidationError == null) {
	                		remReq.setZipCode(fieldValue);
	                	}
	                	break;
	           		case RemoteProofingValidatedField.FIELD_URBANIZATION_CODE:
						fieldValue = remReq.getUrbanizationCode();
						
						notAllowedChars   = "!$%^*<>=[]\\;{}|`:~"; 
	   				    //All nonAlphaNum = "!$%^*<>=[]\\;{}|`:~&@()+?#/.,'-_\""; 
	   			  	    //Allowed Chars   = "A1 #/-.,'_?+&@()\"";
	         			//Regex: ^[0-9A-Za-z'\-\._",&()?#/+@\s]*$
						
						inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 0, 
	                			fieldValidation.isRequired(), validationErrorMap);
	                	
						if (inputValidationError == null) {
	                		remReq.setUrbanizationCode(fieldValue);
	                	}
						break;
	           		case RemoteProofingValidatedField.FIELD_MOBILE_PHONE:
	                	fieldValue = remReq.getMobilePhone();
	                	
	                	notAllowedChars   = "!@$%^&*_\"<>?=[]\\;{}|`~#/.,:'";
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'-_"; 
	   			  	    //Allowed Chars   = "1+-()";  
	    				    
	                	validationRegex = null;
	                	minLength = 4;
	                	maxLength = 15;
	                	
	                	if (domesticAddress) {
	                		minLength = 10;
	                		validationRegex = fieldValidation.getRegex();

	                		if (fieldValue != null) {
	                			//Strip off spaces
		                		fieldValue = fieldValue.replaceAll("\\s+", "");
	                			
		                		//Strip off leading +1 chars
		                		if (fieldValue.startsWith("+1")) {
		               	        	fieldValue = fieldValue.substring(2, fieldValue.length());
		               	        }	
	                		}
	                	}
	                	
	                	fieldValue = Utils.removeNonNumericCharactersFromString(fieldValue);
	                	remReq.setMobilePhone(fieldValue);

	                	inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, validationRegex, minLength, maxLength, 
	                			fieldValidation.isRequired(), false, true, validationErrorMap);
	                	if (inputValidationError == null) {
	                		remReq.setMobilePhone(fieldValue);
	                	}
	                	break; 
	           		case RemoteProofingValidatedField.FIELD_CUSTOMER_UNIQUE_ID:
	                	fieldValue = remReq.getCustomerUniqueID();
	                	
	                	notAllowedChars   = "!@$%^&*()_+\"<>?=[]\\;{}|`~#/,.:'-";
	   				    //All AlphaNum    = "!@$%^&*()_+\"<>?=[]\\;{}|`~#/,.:'-A1";
	   			  	    //Allowed Chars   = "A1";
	    				    
	                	inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 18, 
	                			fieldValidation.isRequired(), validationErrorMap);
	                	
	                	if (inputValidationError == null) {
	                		remReq.setCustomerUniqueID(fieldValue);
	                	}
	                	break;
	           		case RemoteProofingValidatedField.FIELD_TRUE_IP_ADDRESS:
	                	fieldValue = remReq.getTrueIPAddress();
	                	
	                	notAllowedChars   = "!@$%^&*()_+\"<>?=[]\\;{}|`~#/,'-";
	   				    //All    AlphaNum = "!@$%^&*()_+\"<>?=[]\\;{}|`~#/,'-.:A1";
	   			  	    //Allowed Chars   = "A1:.";
	    				    
	                	inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 50, 
	                			fieldValidation.isRequired(), validationErrorMap);
	                	
	                	if (inputValidationError == null) {
	                		remReq.setTrueIPAddress(fieldValue);
	                	}
	                	break;
 	           		case RemoteProofingValidatedField.FIELD_PROFILING_SESSION_ID:
	           		case RemoteProofingValidatedField.FIELD_WEB_SESSION_ID:
   	                	fieldValue = RemoteProofingValidatedField.FIELD_PROFILING_SESSION_ID.equalsIgnoreCase(fieldName) ? remReq.getProfilingSessionID() : remReq.getWebSessionID();
 
                		notAllowedChars   = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'";
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'-_";
	   			  	    //Allowed Chars   = "A1 -_'";
	    				    
                		inputValidationError = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 60, 
	                			fieldValidation.isRequired(), validationErrorMap);
	                	
	                	if (inputValidationError == null) {
	                		if (RemoteProofingValidatedField.FIELD_PROFILING_SESSION_ID.equalsIgnoreCase(fieldName)) {
		                		remReq.setProfilingSessionID(fieldValue);
	                		}
	                		else {
	                    		remReq.setWebSessionID(fieldValue);
	                		}
	                	}
	                	break;
	                default:
           		}
            } catch (Exception e) {
                LOG.error("Exception occurred while validating remote data", e);
            }
         
    	}

        return validationErrorMap;
    }
    
    private static InputValidationError checkFormatValidationError(String fieldName, String fieldValue, String notAllowedChars, String validationRegex,
    		int minLength, int maxLength, boolean required, HashMap<String, InputValidationError> validationErrorMap) {
    	return checkFormatValidationError(fieldName, fieldValue, notAllowedChars, validationRegex, minLength, maxLength, required, false, false, validationErrorMap);
    }

    private static InputValidationError checkFormatValidationError(String fieldName, String fieldValue, String notAllowedChars, String validationRegex,
    		int minLength, int maxLength, boolean required, boolean removeNonNumeric, boolean checkSameDigit,
    		HashMap<String, InputValidationError> validationErrorMap) {
       	
      	if (fieldValue != null) {
      		fieldValue = fieldValue.trim();
      	}
      	
      	InputValidationError inputValidationError = getNullOrEmptyFieldErrorMsg(fieldName, fieldValue, required, validationErrorMap);
      	
       	if (inputValidationError == null) {
       		inputValidationError = maxLengthValidationErrorMsg(fieldName, fieldValue, maxLength, validationErrorMap);
   			
       		if (inputValidationError == null) {
       			inputValidationError = minLengthValidationErrorMsg(fieldName, fieldValue, minLength, validationErrorMap);
	    			
       			if (inputValidationError == null) {
       				inputValidationError = getContainsNotAllowedCharsErrorMessage(fieldName, fieldValue, notAllowedChars, validationErrorMap);
  
       				if (inputValidationError == null) {
	   					if (removeNonNumeric) {
	   						fieldValue = Utils.removeNonNumericCharactersFromString(fieldValue);
	   					}
	   					
	   					inputValidationError = getInvalidFormatMessage(fieldName, fieldValue, validationRegex, validationErrorMap);
		   				
		   				if (inputValidationError == null && checkSameDigit) {
		   					inputValidationError = getSameDigitErrorMessage(fieldName, fieldValue, validationErrorMap);
		   				}
	   				}
	   		     }       	
			}
       	}

       	return inputValidationError;
    }
    
    private static InputValidationError getNullOrEmptyFieldErrorMsg(String fieldName, String fieldValue, boolean requiredField,
    		HashMap<String, InputValidationError> validationErrorMap) {
    	InputValidationError inputValidationError = null;
    	ErrorMessage errorMessage = null;
      	
    	if (requiredField) {
		   	if (fieldValue == null) {
		   		errorMessage = ErrorMessage.MISSING_REQUIRED_FIELD;
		    }
		   	else {
		       	if (Utils.isEmptyString(fieldValue)) {
		       		errorMessage = ErrorMessage.EMPTY_REQUIRED_FIELD;
		        } 
		   	}
    	}
     	
    	if (errorMessage != null) {
	   		inputValidationError = getInputValidationError(fieldName, fieldValue, errorMessage.getFormattedErrorMessage(fieldName));   	
	    	validationErrorMap.put(fieldName, inputValidationError);
    	}

	   	return inputValidationError;
    }
    
    private static InputValidationError getInvalidFormatMessage(String fieldName, String fieldValue, String validationRegex,
    		HashMap<String, InputValidationError> validationErrorMap) {
    	InputValidationError inputValidationError = null;
    	ErrorMessage errorMessage = null;
    	
		if (!Utils.isEmptyString(fieldValue)) {
			try {
		    	if (!Utils.isEmptyString(validationRegex) && !Utils.matches(fieldValue, validationRegex)) {
		    		errorMessage = ErrorMessage.INVALID_FORMATTING;
		       		inputValidationError = getInputValidationError(fieldName, fieldValue, errorMessage.getFormattedErrorMessage(fieldName));   	
 	    	    	validationErrorMap.put(fieldName, inputValidationError);
				}
			} catch (Exception e) {
				String errorReason = "Exception occurred while getting InvalidFormatMessage.";
				LOG.error(errorReason, e);
				errorMessage = ErrorMessage.INVALID_INPUT_DATA;
	       		inputValidationError = getInputValidationError(fieldName, fieldValue, errorMessage.getFormattedErrorMessage(fieldName, errorReason));   	
 	  	    	validationErrorMap.put(fieldName, inputValidationError);
			}
		}
    	
    	return inputValidationError;
    }
    
    private static InputValidationError getSameDigitErrorMessage(String fieldName, String fieldValue, HashMap<String, InputValidationError> validationErrorMap) {
    	InputValidationError inputValidationError = null;
    	ErrorMessage errorMessage = null;
    	
    	if ( fieldValue != null ) {
	       	int valueLen = fieldValue.length();
	  		String regex = String.format("^(\\d)(?!\\1+$)\\d{%s}$", valueLen - 1);
	
	  		boolean hasSameDigit = !fieldValue.matches(regex);
	    	 
	  		if (hasSameDigit) {
	  			errorMessage = ErrorMessage.SAME_DIGITS;
	       		inputValidationError = getInputValidationError(fieldName, fieldValue, errorMessage.getFormattedErrorMessage(fieldName));   	   	    	
    	    	validationErrorMap.put(fieldName, inputValidationError); 		
	  		}
    	}

    	return inputValidationError;
    }
       	
    public static InputValidationError getValidationError(String fieldName, String fieldValue, String errorMessage) {   
		InputValidationError inputValidationError = new InputValidationError();
		inputValidationError.setFieldName(fieldName);
     	
		if (fieldValue != null) {
			inputValidationError.setFieldValue(fieldValue);
		}
		
		inputValidationError.setErrorMessage(errorMessage);
		
		return inputValidationError;
    }
	
	public static InputValidationError getInputValidationError(String fieldName, String fieldValue, String validationErrorMsg) {   
		InputValidationError inputValidationError = new InputValidationError();
		inputValidationError.setFieldName(fieldName);
		
		if (fieldValue != null) {
			inputValidationError.setFieldValue(fieldValue);
		}
		
		inputValidationError.setErrorMessage(validationErrorMsg);
		
		return inputValidationError;
    }
	
    private static InputValidationError getContainsNotAllowedCharsErrorMessage(String fieldName, String fieldValue, String notAllowedChars,
    		HashMap<String, InputValidationError> validationErrorMap) {
    	ErrorMessage errorMessage = null;
    	InputValidationError inputValidationError = null;
    	if (fieldValue != null) {
	    	if (!Utils.isEmptyString(notAllowedChars)) {
		    	for (int i = 0; i < fieldValue.length(); i++) {
		            char x = fieldValue.charAt(i);
		            if (notAllowedChars.contains(String.valueOf(x))) {
		            	errorMessage = ErrorMessage.INVALID_FORMATTING;
			       		inputValidationError = getInputValidationError(fieldName, fieldValue, errorMessage.getFormattedErrorMessage(fieldName));   	
		    	    	validationErrorMap.put(fieldName, inputValidationError);
		            }
		        }
	    	}
    	}

    	return inputValidationError;
    }
    
    /**
     * Validates 2 letter state code for domestic, military and US territories. Returns true if valid.
     * 
     * @param state
     *            - 2 letter state code
     * @return true if state code is valid
     */
    public static InputValidationError validateDomesticStates(String fieldName, String fieldValue, HashMap<String, InputValidationError> validationErrorMap) {
       	String allUSStates = "AL,AK,AS,AZ,AR,CA,CO,CT,DE,DC,FM,FL,GA,GU,HI,ID,IL,IN,IA,KS,KY,LA,"
    			+ "ME,MH,MD,MA,MI,MN,MS,MO,MT,NE,NV,NH,NJ,NM,NY,NC,ND,MP,OH,OK,OR,PW,PA,PR,RI,SC,"
    			+ "SD,TN,TX,UT,VT,VI,VA,WA,WV,WI,WY,AA,AE,AP";
       	
       	InputValidationError inputValidationError = null;
       	ErrorMessage errorMessage = null;
       	boolean isValidUSState = allUSStates.contains(fieldValue.toUpperCase());
       	
       	if (!isValidUSState) {
	       	errorMessage = ErrorMessage.INVALID_2_LETTER_CODE;
       		inputValidationError = getInputValidationError(fieldName, fieldValue, errorMessage.getFormattedErrorMessage(fieldName));   	
 	  		validationErrorMap.put(fieldName, inputValidationError);
       	}
       	
        return inputValidationError;
    }
    
    /**
     * Performs validation on zip code field to make sure it's a 5 digit zip code or 9 digit zip code (XXXXX-XXXX)
     */
    private static InputValidationError getZipCodeValidationErrorMsg(String fieldName, String fieldValue, HashMap<String, InputValidationError> validationErrorMap) {
    	InputValidationError inputValidationError = maxLengthValidationErrorMsg(fieldName, fieldValue, 10, validationErrorMap);
    	ErrorMessage errorMessage = null;
    	
        if (inputValidationError == null) {
        	inputValidationError = minLengthValidationErrorMsg(fieldName, fieldValue, 5, validationErrorMap);
           
           if (inputValidationError == null) {
        	   if (fieldValue.length() == 5 && !org.apache.commons.lang3.StringUtils.isNumeric(fieldValue)) {
        		   errorMessage = ErrorMessage.INVALID_FORMATTING;
             	   inputValidationError = getInputValidationError(fieldName, fieldValue, errorMessage.getFormattedErrorMessage(fieldName));   	
          	   }
        	   
        	   if (errorMessage == null) {
        		   if (fieldValue.length() >= 6) {
        			   if (fieldValue.indexOf('-') == -1) {
        				   errorMessage = ErrorMessage.INVALID_FORMATTING;
        		      		inputValidationError = getInputValidationError(fieldName, fieldValue, errorMessage.getFormattedErrorMessage(fieldName));   	
        	           } 
        			   
        			   if (errorMessage == null) {
        	                String[] zipComponents = fieldValue.split("-");
        	                String zip5 = zipComponents[0];
        	                String zip4 = "";
        	                
        	                if (zipComponents.length > 1) {
        	                	zip4 = zipComponents[1];
        	                 
        	                	boolean invalidZipCode = zip5.length() != 5 || zip4.length() != 4 || !org.apache.commons.lang3.StringUtils.isNumeric(zip5);
        	                	if (invalidZipCode) {
        	        				   errorMessage = ErrorMessage.INVALID_FORMATTING;
        	        		      	   inputValidationError = getInputValidationError(fieldName, fieldValue, errorMessage.getFormattedErrorMessage(fieldName));   	
        		                }
        	                }
        	            }
        		   }
        	   }
           }
        }
        	
        if (inputValidationError != null) {
       		validationErrorMap.put(fieldName, inputValidationError);
        }

        return inputValidationError;
    }

    /**
     * Performs value maximum length validation)
     */
    private static InputValidationError maxLengthValidationErrorMsg(String fieldName, String fieldValue, int maxLength,
    		HashMap<String, InputValidationError> validationErrorMap) {
    	InputValidationError inputValidationError = null;
    	
        if (!Utils.isEmptyString(fieldValue) && maxLength > 0 && fieldValue.length() > maxLength) {
        	ErrorMessage errorMessage = ErrorMessage.INVALID_FIELD_LENGTH;
      		inputValidationError = getInputValidationError(fieldName, fieldValue, errorMessage.getFormattedErrorMessage(fieldName, PARAM_LONGER, String.valueOf(maxLength)));   	
   	   	    validationErrorMap.put(fieldName, inputValidationError);
        }

        return inputValidationError;
    }
    
    /**
     * Performs value minimum length validation)
     */
    private static InputValidationError minLengthValidationErrorMsg(String fieldName, String fieldValue, int minLength,
    		HashMap<String, InputValidationError> validationErrorMap) {
    	InputValidationError inputValidationError= null;
        
    	if (!Utils.isEmptyString(fieldValue) && minLength > 0 && fieldValue.length() < minLength) {
        	ErrorMessage errorMessage = ErrorMessage.INVALID_FIELD_LENGTH;
	      	inputValidationError = getInputValidationError(fieldName, fieldValue, errorMessage.getFormattedErrorMessage(fieldName, PARAM_SHORTER, String.valueOf(minLength)));   	
       
   	   		validationErrorMap.put(fieldName, inputValidationError);
    	}
        
        return inputValidationError;
    }
    
    /**
     * Validates 2 letter abbreviation for international countries. Returns true if valid.
     * 
     * @param countryAbbr - 2 letter countryAbbr code
     * @return true if countryAbbr is valid
     */
    public static InputValidationError getCountryAbbrValidationError(String fieldName, String countryAbbr, HashMap<String, InputValidationError> validationErrorMap) {
    	InputValidationError inputValidationError = null;
    	ErrorMessage errorMessage = null;
    	countryAbbr = countryAbbr.toUpperCase();
   		
    	if (VALUE_COUNTRY_UK.equalsIgnoreCase(countryAbbr)) {
   			countryAbbr = VALUE_COUNTRY_GB;
		}

       	if (countryAbbr.length() == 2 && !alpha2CodesList.contains(countryAbbr)) {
       		errorMessage = ErrorMessage.INVALID_2_LETTER_CODE;
       		inputValidationError = getInputValidationError(fieldName, countryAbbr, errorMessage.getFormattedErrorMessage(fieldName));   	
 	  		validationErrorMap.put(fieldName, inputValidationError);
        } else if(countryAbbr.length() == 3 && !alpha3CodesList.contains(countryAbbr.toUpperCase())){
     		errorMessage = ErrorMessage.INVALID_3_LETTER_CODE;
       		inputValidationError = getInputValidationError(fieldName, countryAbbr, errorMessage.getFormattedErrorMessage(fieldName));   	
 	  		validationErrorMap.put(fieldName, inputValidationError);
		}

        return inputValidationError;
    }
    
    private static RemoteProofingValidatedField [] getRemoteProofingValidatedField(String assessmentCall) {
    	  RemoteProofingValidatedField [] validatedFieldArray = null;

    	  switch (assessmentCall) {
    	  	case RemoteProofingServiceImpl.CHECK_DEVICE_PLUS:
    		    validatedFieldArray = new RemoteProofingValidatedField [] {
    			RemoteProofingValidatedField.SPONSOR_CODE, 
				RemoteProofingValidatedField.APP_CODE,
  				RemoteProofingValidatedField.COMPANY_NAME,
  				RemoteProofingValidatedField.COMPANY_FEIN,
  				RemoteProofingValidatedField.FIRST_NAME,
  				RemoteProofingValidatedField.LAST_NAME,
  				RemoteProofingValidatedField.EMAIL_ADDRESS,
  				RemoteProofingValidatedField.STREET_ADDRESS_1,
  				RemoteProofingValidatedField.STREET_ADDRESS_2,
  				RemoteProofingValidatedField.URBANIZATION_CODE,
  				RemoteProofingValidatedField.CITY,
  				RemoteProofingValidatedField.STATE,
  				RemoteProofingValidatedField.ZIPCODE,
   				RemoteProofingValidatedField.MOBILE_PHONE,
  				RemoteProofingValidatedField.PROFILING_SESSION_ID,
  				RemoteProofingValidatedField.WEB_SESSION_ID,
  				RemoteProofingValidatedField.TRUE_IP_ADDRESS};
    		    break;
    	  	case RemoteProofingServiceImpl.VERIFY_BUSINESS:
      		    validatedFieldArray = new RemoteProofingValidatedField [] {
  				RemoteProofingValidatedField.SPONSOR_CODE, 
  				RemoteProofingValidatedField.APP_CODE,
				RemoteProofingValidatedField.COMPANY_NAME,
				RemoteProofingValidatedField.COMPANY_FEIN,
				RemoteProofingValidatedField.FIRST_NAME,
				RemoteProofingValidatedField.LAST_NAME,
 				RemoteProofingValidatedField.STREET_ADDRESS_1,
				RemoteProofingValidatedField.STREET_ADDRESS_2,
				RemoteProofingValidatedField.URBANIZATION_CODE,
				RemoteProofingValidatedField.CITY,
				RemoteProofingValidatedField.STATE,
				RemoteProofingValidatedField.ZIPCODE,
 				RemoteProofingValidatedField.MOBILE_PHONE};
      		  break;
    	  	case RemoteProofingServiceImpl.CHECK_DEVICE:
            	 //EmailAddress is not required yet by COA and OS applications 
    	  		validatedFieldArray = new RemoteProofingValidatedField [] {
				RemoteProofingValidatedField.SPONSOR_CODE, 
  				RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
    			RemoteProofingValidatedField.FIRST_NAME,
  				RemoteProofingValidatedField.LAST_NAME,
   				RemoteProofingValidatedField.STREET_ADDRESS_1,
  				RemoteProofingValidatedField.STREET_ADDRESS_2,
   				RemoteProofingValidatedField.CITY,
  				RemoteProofingValidatedField.STATE,
  				RemoteProofingValidatedField.ZIPCODE,
   				RemoteProofingValidatedField.MOBILE_PHONE,
  				RemoteProofingValidatedField.PROFILING_SESSION_ID,
  				RemoteProofingValidatedField.WEB_SESSION_ID,
  				RemoteProofingValidatedField.TRUE_IP_ADDRESS};
    	  		break;
     	  	case RemoteProofingServiceImpl.VERIFY_PHONE:
   	  		 	validatedFieldArray = new RemoteProofingValidatedField [] {
  				RemoteProofingValidatedField.SPONSOR_CODE, 
  				RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
  				RemoteProofingValidatedField.FIRST_NAME,
  				RemoteProofingValidatedField.LAST_NAME,
  				RemoteProofingValidatedField.MOBILE_PHONE,
  				RemoteProofingValidatedField.STREET_ADDRESS_1,
  				RemoteProofingValidatedField.STREET_ADDRESS_2,
   	  			RemoteProofingValidatedField.CITY,
  				RemoteProofingValidatedField.STATE,
  				RemoteProofingValidatedField.ZIPCODE};
    	  	    break;
     	  	case RemoteProofingServiceImpl.CONFIRM_PASSCODE: 
      	  		validatedFieldArray = new RemoteProofingValidatedField [] {
  	  			RemoteProofingValidatedField.SPONSOR_CODE, 
 				RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
 				RemoteProofingValidatedField.PASSCODE};
       	  		break;
     	  	case RemoteProofingServiceImpl.REQUEST_PASSCODE: 
     	  		validatedFieldArray = new RemoteProofingValidatedField [] {
 	  			RemoteProofingValidatedField.SPONSOR_CODE, 
 	  			RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
 	    		RemoteProofingValidatedField.FIRST_NAME,
 	  			RemoteProofingValidatedField.LAST_NAME,
 	   			RemoteProofingValidatedField.STREET_ADDRESS_1,
 	  			RemoteProofingValidatedField.STREET_ADDRESS_2,
 	   			RemoteProofingValidatedField.CITY,
 	  			RemoteProofingValidatedField.STATE,
 	  			RemoteProofingValidatedField.ZIPCODE};
      	  		break;	  
     	  	case RemoteProofingServiceImpl.VALIDATE_LINK:
    	  		validatedFieldArray = new RemoteProofingValidatedField [] {
	  			RemoteProofingValidatedField.SPONSOR_CODE, 
	  			RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
	  			RemoteProofingValidatedField.MOBILE_PHONE};
     	  		break;
     	  	case RemoteProofingServiceImpl.RESEND_LINK:
      	  		validatedFieldArray = new RemoteProofingValidatedField [] {
  	  			RemoteProofingValidatedField.SPONSOR_CODE, 
 				RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
 				RemoteProofingValidatedField.FIRST_NAME,
 				RemoteProofingValidatedField.LAST_NAME,
 				RemoteProofingValidatedField.MOBILE_PHONE,
  				RemoteProofingValidatedField.STREET_ADDRESS_1,
 				RemoteProofingValidatedField.STREET_ADDRESS_2,
  				RemoteProofingValidatedField.CITY,
 				RemoteProofingValidatedField.STATE,
 				RemoteProofingValidatedField.ZIPCODE};
       	  	   break;

    	  	default:    		  
    	  }
    	  return validatedFieldArray;
    }
}
