package com.ips.jaxrs;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.google.gson.Gson;
import com.ibm.json.java.JSONObject;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.SpringUtil;
import com.ips.request.RemoteRequest;
import com.ips.request.RemoteUtilityRequest;
import com.ips.service.RemoteProofingService;
import com.ips.service.RemoteUtilityService;

@Path("remote")
public class RemoteRestResource extends SpringBeanAutowiringSupport implements Serializable {
    private final static long serialVersionUID = 1L;

    @Autowired
    private RemoteProofingService remoteProofingService;
    @Autowired
    private RemoteUtilityService remoteUtilityService;
 
    public static final String REMOTE_PROOFING_SERVICE = "remoteProofingService";
    public static final String REMOTE_UTILITY_SERVICE = "remoteUtilityService";
    public final static String HEADER_ORIGIN = "Origin";
    
    public RemoteProofingService getRemoteProofingService(@Context HttpServletRequest hsr) {
    	if (remoteProofingService == null) {
			CustomLogger.info(this.getClass(), "IVSERROR RemoteRestResource getRemoteProofingService1 remoteProofingService is null");
    	   	remoteProofingService = (RemoteProofingService)SpringUtil.getInstance(hsr.getSession().getServletContext()).getBean(REMOTE_PROOFING_SERVICE);	
    	}
    	
    	return remoteProofingService;
    }
    
    public RemoteUtilityService getRemoteUtilityService(@Context HttpServletRequest hsr) {
    	if (remoteUtilityService == null) {
			CustomLogger.info(this.getClass(), "IVSERROR RemoteRestResource getRemoteProofingService1 remoteUtilityService is null");
    		remoteUtilityService = (RemoteUtilityService)SpringUtil.getInstance(hsr.getSession().getServletContext()).getBean(REMOTE_UTILITY_SERVICE);	
    	}
    	
    	return remoteUtilityService;
    }
    
    /**
     * Web Service used to check high risk address, device reputation and email risk. LexisNexis web service is called to retrieved the 
     * bundled (multi-product) assessment result using the unique session id passed in profiling tag as key.
     * Upon completion of device reputation/email risk check, an assessment status is returned with the response. 
     *
     * Consumer: BCG Thru CustReg
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("AssessDevicePlusEmailRisk")
    public Response assessDevicePlusEmailRisk(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteProofingService(hsr).assessDevicePlusEmailRisk(remoteReq, origin);
    }
    
    /**
     * Web Service used to check high risk address, LexisNexis device and email risk assessment (DERA), AMS address check 
     * and LexisNexis Business Instant Identification (BIID). LexisNexis DERA web service is called to retrieved the 
     * bundled (multi-product) assessment result using the unique session id passed in profiling tag as key.
     * Only BCG and COP type accounts are subjected to AMS and BIID step-up verification. Others are just verified through LN DERA. 
     * If BCG and COP type accounts passed AMS address check, LN BIID is bypassed and the AMS pass result is returned to CustReg. 
     *
     * Consumer: BCG Thru CustReg
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("VerifyBusiness")
    public Response verifyBusiness(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteProofingService(hsr).verifyBusiness(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("VerifyTestBusiness")
    public Response verifyTestBusiness(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteProofingService(hsr).verifyTestBusiness(remoteReq, origin);
    }
    
    /**
     * Web Service used to check high risk address and device reputation. LexisNexis web service is called to retrieved the 
     * device reputation assessment result using the unique session id passed in profiling tag as key.
     * Upon completion of device reputation check, an assessment status is returned with the response. 
     *
     * Consumer: Operation Santa / Change of Address
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CheckDevice")
    public Response checkDevice(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
       	return getRemoteProofingService(hsr).checkDevice(remoteReq, origin);
    }
    
    
    /**
     * Web Service used to verify a phone number. Upon successful verification, a
     * passcode is sent to the phone. If verification fails, an appropriate response
     * is returned stating what failed.
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     * @throws Throwable 
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("VerifyPhone")
    public Response verifyPhone(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) throws Throwable {
     	return getRemoteProofingService(hsr).verifyPhone(remoteReq, origin);
    }
 
    /**
     * Web Service used to confirm a passcode sent to a user. Indicates whether the
     * passcode entered was correct or not
     * 
     * @param passReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ConfirmPasscode")
    public Response confirmPasscode(RemoteRequest passReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteProofingService(hsr).confirmPasscode(passReq, origin);
    }

    /**
     * Web Service used to resend a passcode to a user if the user's phone has been
     * verified previously.
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     * @throws Throwable 
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RequestPasscode")
    public Response requestPasscode(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) throws Throwable {
     	return getRemoteProofingService(hsr).requestPasscode(remoteReq, origin);
     }

    /**
     * Web Service used to resend the SMFA link to the user's phone if it has been
     * verified previously by Equifax DIT.
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ResendLink")
    public Response resendLink(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteProofingService(hsr).resendLink(remoteReq, origin);
     }
    
    /**
     * Web Service used to validate the SMFA link sent to the user's phone.
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ValidateLink")
    public Response validateLink(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteProofingService(hsr).validateLink(remoteReq, origin);
     }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CreateRefSponsorConfigurationRecords")
    public Response createRefSponsorConfigurationForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteUtilityService(hsr).createRefSponsorConfigurationForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CreateRpOtpAttemptConfigRecords")
    public Response createRpOtpAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).createRpOtpAttemptConfigForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CreateRpInfPvAttemptConfigRecords")
    public Response createRpInfPvAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteUtilityService(hsr).createRpInfPvAttemptConfigForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CreateRpFeatureAttemptRecords")
    public Response createRpFeatureAttemptForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteUtilityService(hsr).createRpFeatureAttemptForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RemoveRefSponsorConfigurationRecords")
    public Response removeRefSponsorConfigurationForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteUtilityService(hsr).removeRefSponsorConfigurationForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RemoveRpFeatureAttemptRecords")
    public Response removeRpFeatureAttemptForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).removeRpFeatureAttemptForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RemoveRpOtpAttemptConfigRecords")
    public Response removeRpOtpAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).removeRpOtpAttemptConfigForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("GetModificationFingerprint")
    public Response getModificationFingerprint(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).getModificationFingerprint(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ConfigVerificationMethod")
    public Response configVerificationMethod(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteUtilityService(hsr).configVerificationMethod(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RetrieveSupplierConfig")
    public Response retrieveSupplierConfig(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).retrieveSupplierConfig(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ConfigPhoneVelocityWindow")
    public Response configPhoneVelocityWindow(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteUtilityService(hsr).configPhoneVelocityWindow(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("UpdatePersonProofingStatus")
    public Response updatePersonProofingStatus(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).updatePersonProofingStatus(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("SaveExperianAltApiInfo")
    public Response saveExperianAltApiInfo(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).saveRpSupplierToken(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RemoveExperianAltApiInfo")
    public Response removeExperianAltApiInfo(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteUtilityService(hsr).removeRpSupplierToken(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("SaveRefSponsorConfiguration")
    public Response saveRefSponsorConfiguration(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteUtilityService(hsr).saveRefSponsorConfiguration(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RetrieveRefSponsorConfiguration")
    public Response retrieveRefSponsorConfiguration(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).retrieveRefSponsorConfiguration(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RemoveRefSponsorConfiguration")
    public Response removeRefSponsorConfiguration(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteUtilityService(hsr).removeRefSponsorConfiguration(remoteReq, origin);
    }
      
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ObtainExperianWebToken")
    public Response obtainExperianWebToken(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteUtilityService(hsr).obtainExperianWebToken(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("GetHighRiskAddresses")
    public Response getHighRiskAddresses(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).getHighRiskAddresses(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("UpdateHighRiskAddress")
    public Response updateHighRiskAddress(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).updateHighRiskAddress(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CheckRegExForMatch")
    public Response checkRegExForMatch(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
     	return getRemoteUtilityService(hsr).checkRegExForMatch(remoteReq, origin);
    }
    

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ResetStatus")
    public Response resetPersonProofingStatus(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).resetPersonProofingStatus(remoteReq, origin);
    }
  
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RetrieveWorkflowApiTypes")
    public Response retrieveWorkflowApiTypes(JSONObject requestJson, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).retrieveWorkflowApiTypes(requestJson, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("UpdateWorkflowApiTypes")
    public Response updateWorkflowApiTypes(JSONObject requestJson, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).updateWorkflowApiTypes(requestJson, origin);
    }
    
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RetrieveRefApp")
    public Response retrieveRefApp(JSONObject requestJson, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).retrieveRefApp(requestJson, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CreateRefCustomerCategory")
    public Response createRefCustomerCategory(JSONObject requestJson, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).createRefCustomerCategory(requestJson, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("UpdateRefApp")
    public Response updateRefApp(JSONObject requestJson, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).updateRefApp(requestJson, origin);
    }
    
    /*
     * Endpoints:
     * https://mypc.usps.com:9443/RemoteRest/resources/remote/GetReportDataByEvent
     * https:https://ips-dev.usps.com/RemoteRest/resources/remote/GetReportDataByEvent
     * https:https://ips-sit.usps.com/RemoteRest/resources/remote/GetReportDataByEvent
     * https:https://ips-cat.usps.com/RemoteRest/resources/remote/GetReportDataByEvent
     * https:https://ips.usps.com/RemoteRest/resources/remote/GetReportDataByEvent
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("GetReportDataByEvent")
    public Response getReportDataByEvent(JSONObject requestJson, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).getReportDataByEvent(requestJson, origin);
    }
    
    /*
     * Endpoints:
     * https://mypc.usps.com:9443/RemoteRest/resources/remote/GetReportDataByPerson
     * https:https://ips-dev.usps.com/RemoteRest/resources/remote/GetReportDataByPerson
     * https:https://ips-sit.usps.com/RemoteRest/resources/remote/GetReportDataByPerson
     * https:https://ips-cat.usps.com/RemoteRest/resources/remote/GetReportDataByPerson
     * https:https://ips.usps.com/RemoteRest/resources/remote/GetReportDataByPerson
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("GetReportDataByPerson")
    public Response getReportDataByPerson(JSONObject requestJson, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
      	return getRemoteUtilityService(hsr).getReportDataByPerson(requestJson, origin);
    }  
 
    /*
     * Endpoints: (Only for lower environments)
     * https://mypc.usps.com:9443/RemoteRest/resources/remote/UpdateRpWorkflowApiDecision
     * https:https://ips-dev.usps.com/RemoteRest/resources/remote/UpdateRpWorkflowApiDecision
     * https:https://ips-sit.usps.com/RemoteRest/resources/remote/UpdateRpWorkflowApiDecision
     * https:https://ips-cat.usps.com/RemoteRest/resources/remote/UpdateRpWorkflowApiDecision
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("UpdateRpWorkflowApiDecision")
    public Response updateRpWorkflowApiDecision(JSONObject requestJson, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).updateRpWorkflowApiDecision(requestJson, origin);
    }
	
	@Path("CheckSponsorAppActivation")
    public Response checkSponsorAppActivation(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin, @Context HttpServletRequest hsr) {
    	return getRemoteUtilityService(hsr).checkSponsorAppActivation(remoteReq, origin);
    }
  }
