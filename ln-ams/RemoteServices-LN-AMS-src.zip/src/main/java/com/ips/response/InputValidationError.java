package com.ips.response;

import java.io.Serializable;

public class InputValidationError implements Serializable {
	private static final long serialVersionUID = 1L;
	private String FieldName;
	private String FieldValue;
	private String ErrorMessage;
	
	public String getFieldName() {
		return FieldName;
	}
	
	public void setFieldName(String fieldName) {
		FieldName = fieldName;
	}
	
	public String getFieldValue() {
		return FieldValue;
	}
	
	public void setFieldValue(String fieldValue) {
		FieldValue = fieldValue;
	}
	
	public String getErrorMessage() {
		return ErrorMessage;
	}
	
	public void setErrorMessage(String errorMessage) {
		ErrorMessage = errorMessage;
	}
		
}
