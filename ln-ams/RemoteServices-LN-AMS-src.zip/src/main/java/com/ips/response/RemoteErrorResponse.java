package com.ips.response;

import java.io.Serializable;

public class RemoteErrorResponse implements Serializable {
	private static final long serialVersionUID = 1L;
	private ErrorResponseStatus Status;
    
	public ErrorResponseStatus getStatus() {
		return Status;
	}
	
	public void setStatus(ErrorResponseStatus status) {
		Status = status;
	}

}
