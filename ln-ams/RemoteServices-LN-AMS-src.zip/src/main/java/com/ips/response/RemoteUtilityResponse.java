package com.ips.response;

import java.io.Serializable;
import java.util.List;

public class RemoteUtilityResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    private String sponsorCode;
    private Long phoneVelocityWindow;
	
    /* Supplier Allocation */
    private Long lexisNexisOTPAllocation;
    private Long equifaxSMFAAllocation;
    private Long equifaxIDFSAllocation;
    private Long experianCCAllocation;
    private String experianJwtToken;
    private String responseMessage;
    private String sponsorName;
    private String attemptTableToConfig;
    private String highRiskActivated;
    
    /* RefSponsorConfiguration */
    private String configName;
  	private String configValue;
   	private Long configCount;
    
    private String remoteServicesFingerprint;
    private String ivsPersistenceFingerprint;
    private List<String> highRiskAddresses;
    
    public String getSponsorCode() {
		return sponsorCode;
	}
    
	public void setSponsorCode(String sponsorCode) {
		this.sponsorCode = sponsorCode;
	}
	
	public Long getPhoneVelocityWindow() {
		return phoneVelocityWindow;
	}
	
	 public String getConfigValue() {
			return configValue;
	}
	 
	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}
	
	public void setPhoneVelocityWindow(Long phoneVelocityWindow) {
		this.phoneVelocityWindow = phoneVelocityWindow;
	}
	
	public Long getLexisNexisOTPAllocation() {
		return lexisNexisOTPAllocation;
	}
	
	public void setLexisNexisOTPAllocation(Long lexisNexisOTPAllocation) {
		this.lexisNexisOTPAllocation = lexisNexisOTPAllocation;
	}
	
	public Long getEquifaxSMFAAllocation() {
		return equifaxSMFAAllocation;
	}
	
	public void setEquifaxSMFAAllocation(Long equifaxSMFAAllocation) {
		this.equifaxSMFAAllocation = equifaxSMFAAllocation;
	}    
   
    public Long getExperianCCAllocation() {
		return experianCCAllocation;
	}
    
    public void setExperianCCAllocation(Long experianCCAllocation) {
		this.experianCCAllocation = experianCCAllocation;
	}
	
	public String getResponseMessage() {
        return responseMessage;
    }
	
    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }
    
	public String getSponsorName() {
		return sponsorName;
	}
	
	public void setSponsorName(String sponsorName) {
		this.sponsorName = sponsorName;
	}
	
	public String getRemoteServicesFingerprint() {
		return remoteServicesFingerprint;
	}
	
	public void setRemoteServicesFingerprint(String remoteServicesFingerprint) {
		this.remoteServicesFingerprint = remoteServicesFingerprint;
	}
	
	public String getIvsPersistenceFingerprint() {
		return ivsPersistenceFingerprint;
	}
	
	public void setIvsPersistenceFingerprint(String ivsPersistenceFingerprint) {
		this.ivsPersistenceFingerprint = ivsPersistenceFingerprint;
	}
	
	public Long getEquifaxIDFSAllocation() {
		return equifaxIDFSAllocation;
	}
	
	public String getExperianJwtToken() {
		return experianJwtToken;
	}
	
	public void setEquifaxIDFSAllocation(Long equifaxIDFSAllocation) {
		this.equifaxIDFSAllocation = equifaxIDFSAllocation;
	}
	
	public void setExperianJwtToken(String experianJwtToken) {
		this.experianJwtToken = experianJwtToken;
	}
	
	public Long getConfigCount() {
		return configCount;
	}
	
	public void setConfigCount(Long configCount) {
		this.configCount = configCount;
	}
	
	public String getConfigName() {
		return configName;
	}
	
	public void setConfigName(String configName) {
		this.configName = configName;
	}

	public String getAttemptTableToConfig() {
		return attemptTableToConfig;
	}

	public void setAttemptTableToConfig(String attemptTableToConfig) {
		this.attemptTableToConfig = attemptTableToConfig;
	}

	public List<String> getHighRiskAddresses() {
		return highRiskAddresses;
	}

	public void setHighRiskAddresses(List<String> highRiskAddresses) {
		this.highRiskAddresses = highRiskAddresses;
	}

	public String getHighRiskActivated() {
		return highRiskActivated;
	}

	public void setHighRiskActivated(String highRiskActivated) {
		this.highRiskActivated = highRiskActivated;
	}
}
