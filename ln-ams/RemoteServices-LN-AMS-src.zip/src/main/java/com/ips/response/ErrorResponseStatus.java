package com.ips.response;

import java.io.Serializable;
import java.util.List;

import com.lexisnexis.ns.identity_proofing._1.RdpReasonCodeModel;

public class ErrorResponseStatus implements Serializable {
	private static final long serialVersionUID = 1L;
	private String IvsReferenceId;
	private String TransactionStatus;
	private String Reference;
	private RdpReasonCodeModel TransactionReasonCode;
	private List<InputValidationError> InputValidationErrors;

	public String getIVSReferenceId() {
		return IvsReferenceId;
	}
	
	public void setIvsReferenceId(String ivsReferenceId) {
		IvsReferenceId = ivsReferenceId;
	}
	
	public String getTransactionStatus() {
		return TransactionStatus;
	}
	
	public void setTransactionStatus(String transactionStatus) {
		TransactionStatus = transactionStatus;
	}
	
	public String getReference() {
		return Reference;
	}
	
	public void setReference(String reference) {
		Reference = reference;
	}
	public RdpReasonCodeModel getTransactionReasonCode() {
		return TransactionReasonCode;
	}
	
	public void setTransactionReasonCode(RdpReasonCodeModel transactionReasonCode) {
		TransactionReasonCode = transactionReasonCode;
	}

	public List<InputValidationError> getInputValidationErrors() {
		return InputValidationErrors;
	}

	public void setInputValidationErrors(List<InputValidationError> inputValidationErrors) {
		InputValidationErrors = inputValidationErrors;
	}
	
}
