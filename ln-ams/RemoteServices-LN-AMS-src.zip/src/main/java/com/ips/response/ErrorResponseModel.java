package com.ips.response;

import java.io.Serializable;
import java.util.List;

public class ErrorResponseModel implements Serializable {
	private static final long serialVersionUID = 1L;
	private ResponseStatusModel Status;
	private List<InputValidationError> InputValidationErrors;
    
	public ResponseStatusModel getStatus() {
		return Status;
	}
	
	public List<InputValidationError> getInputValidationErrors() {
		return InputValidationErrors;
	}
	
	public void setStatus(ResponseStatusModel status) {
		Status = status;
	}
	
	public void setInputValidationErrors(List<InputValidationError> inputValidationErrors) {
		InputValidationErrors = inputValidationErrors;
	}
}
