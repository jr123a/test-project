package com.ips.service;

import java.io.Serializable;
import java.util.List;

import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.ibm.json.java.JSONObject;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefCustomerCategory;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefWorkflowApiType;
import com.ips.entity.RpEvent;
import com.ips.entity.RpPhoneVerification;
import com.ips.persistence.common.CommonAssessmentParamVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationResponse;
import com.ips.proofing.EquifaxService;
import com.ips.proofing.PhoneVerificationService;
import com.ips.proofing.ProofingService;
import com.ips.request.RemoteRequest;
import com.ips.response.RemoteResponse;

@Service("remoteProofingService")
@Transactional
public class RemoteProofingServiceImpl implements Serializable, RemoteProofingService {
 
	@Autowired
    private EquifaxService equifaxService;
    @Autowired
    private RemoteSupportService remoteSupportService;
    @Autowired
    private RemoteUtilityService remoteUtilityService;
    @Autowired
    private PersonDataService personDataService;
    @Autowired
    private PersonProofingStatusService personProofingStatusService;
    @Autowired
    private PhoneVerificationService phoneVerificationService;
    @Autowired
    private ProofingService proofingService;
    @Autowired
    private RefOtpSupplierDataService refOtpSupplierDataService;
    @Autowired
    private RefSponsorDataService refSponsorService;
    @Autowired
    private RpDeviceReputationResponseService rpDeviceReputationResponseService;
    @Autowired
    private RpEventDataService rpEventDataService;

    private final static long serialVersionUID = 1L;
    public final static String CHECK_DEVICE = "checkDevice";
    public final static String CHECK_DEVICE_PLUS = "checkDevicePlus";
    public final static String VERIFY_BUSINESS = "verifyBusiness";
    public final static String VERIFY_PHONE = "verifyPhone";
    public final static String CONFIRM_PASSCODE = "confirmPasscode";
    public final static String REQUEST_PASSCODE = "requestPasscode";
    public final static String VALIDATE_LINK = "validateLink";
    public final static String RESEND_LINK = "resendLink";

    @Override
    public Response checkDevice(RemoteRequest remoteReq, String origin) {
    	remoteReq.setAssessmentCall(RemoteProofingServiceImpl.CHECK_DEVICE);
    	PersonVo personVo = new PersonVo();
        Response response = remoteSupportService.buildRequestValidationResponse(remoteReq, personVo, origin);
           
        if (response != null) {
        	return response;
        }
          
        remoteSupportService.populatePersonVo(remoteReq, personVo);
        remoteSupportService.setSponsorAppData(remoteReq, personVo);
 
        try {
         	Person person = proofingService.updatePerson(personVo);
            proofingService.startProofingSession(person, personVo);

            CommonAssessmentParamVo assessmentVo = remoteSupportService.mergeParamObjects(remoteReq, personVo);
            response = remoteSupportService.checkDeviceReputation(origin, person, personVo, assessmentVo, remoteReq);
 
            return response;
        } catch (Exception e) {
        	response = remoteSupportService.exceptionErrorResponse(personVo, null, "assessing DevicePlusEmailRisk", origin, e);
          	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, response);
        }
        
		return response;
    }
    
    @Override
    public Response assessDevicePlusEmailRisk(RemoteRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
      	remoteReq.setAssessmentCall(RemoteProofingServiceImpl.CHECK_DEVICE_PLUS);

    	PersonVo personVo = new PersonVo();
        Response response = remoteSupportService.buildRequestValidationResponse(remoteReq, personVo, origin);
           
        if (response != null) {
        	return response;
        }
          
        remoteSupportService.populatePersonVo(remoteReq, personVo);
        remoteSupportService.setSponsorAppData(remoteReq, personVo);
 
        try {
         	// This call will create the person and person_proofing_status record if they do not exist.
        	if (personVo.getSponsorUserId() == null) {
        		String addressHash = remoteSupportService.calculateNameAddressHash(remoteReq);
            	personVo.setSponsorUserId(addressHash);
        	}

        	Person person = proofingService.updatePerson(personVo);
            proofingService.startProofingSession(person, personVo);

            CommonAssessmentParamVo assessmentVo = remoteSupportService.mergeParamObjects(remoteReq, personVo);
            response = remoteSupportService.assessDevicePlusEmailRisk(origin, remoteReq, person, personVo, assessmentVo);
             
            return response;
        } catch (Exception e) {
        	response = remoteSupportService.exceptionErrorResponse(personVo, null, "assessing DevicePlusEmailRisk", origin, e);
          	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, response);
        }
        
		return response;
    }
    
    @Override
    public Response verifyBusiness(RemoteRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
      	remoteReq.setAssessmentCall(RemoteProofingServiceImpl.VERIFY_BUSINESS);

    	PersonVo personVo = new PersonVo();
        Response response = remoteSupportService.buildRequestValidationResponse(remoteReq, personVo, origin);
           
        if (response != null) {
        	return response;
        }
          
        remoteSupportService.populatePersonVo(remoteReq, personVo);
        remoteSupportService.setSponsorAppData(remoteReq, personVo);
 
        try {
         	// This call will create the person and person_proofing_status record if they do not exist.
        	if (personVo.getSponsorUserId() == null) {
        		String addressHash = remoteSupportService.calculateNameAddressHash(remoteReq);
            	personVo.setSponsorUserId(addressHash);
        	}

        	Person person = proofingService.updatePerson(personVo);
            proofingService.startProofingSession(person, personVo);

            CommonAssessmentParamVo assessmentVo = remoteSupportService.mergeParamObjects(remoteReq, personVo);
            response = remoteSupportService.getVerifyBusinessResponse(origin, remoteReq, person, personVo, assessmentVo);
             
            return response;
        } catch (Exception e) {
        	response = remoteSupportService.exceptionErrorResponse(personVo, null, "assessing DevicePlusEmailRisk", origin, e);
          	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, response);
        }
        
		return response;
    }
     
    @Override
    public Response verifyTestBusiness(RemoteRequest remoteReq, String origin) {
    	remoteReq.setAssessmentCall(RemoteProofingServiceImpl.VERIFY_BUSINESS);
      	String propertyKey = remoteReq.getGenericParam1();
      	String workflow = remoteReq.getGenericParam2();
      	String directCall = remoteReq.getGenericParam3();
      	
      	String propertyValue = "";
       	
      	if (propertyKey != null) {
      		propertyValue = remoteUtilityService.getPropertyValue(propertyKey);
      	} else {
      		return remoteSupportService.buildErrorPVResponse(200, "propertyKey field is missing.", origin);
       	}
      	
      	if (workflow != null) {
      		if ("AMS-BIID".equalsIgnoreCase(workflow) && directCall != null) {
      			directCall = "false";
      		}
      	} else {
      		return remoteSupportService.buildErrorPVResponse(200, "workflow field is missing.", origin);
       	}
 
      	if ("DERA".equalsIgnoreCase(workflow)) {
      		remoteReq.setAssessmentCall(RemoteProofingServiceImpl.CHECK_DEVICE_PLUS);
      	} else {
      		remoteReq.setAssessmentCall(RemoteProofingServiceImpl.VERIFY_BUSINESS);
      	}
      	
     	String[] propertyValueArr = propertyValue.split(",");   	     	
       	
       	remoteReq.setSponsorCode(RefSponsor.SPONSOR_CODE_CR.toLowerCase());
       	remoteReq.setCountry("US");
       
       	if (remoteReq.getCompanyName() == null) {
       		remoteReq.setCompanyName(propertyValueArr[0]);
       	}
       	     	
      	if (remoteReq.getCompanyFEIN() == null) {
       		remoteReq.setCompanyFEIN(propertyValueArr[1]);
      	}     	
      	
      	if (remoteReq.getMobilePhone() == null) {
       		remoteReq.setMobilePhone(propertyValueArr[2]);
      	}
      	
      	if (remoteReq.getFirstName() == null) {
      		remoteReq.setFirstName(propertyValueArr[3]);
      	}
      	
      	if (remoteReq.getLastName() == null) {
      		remoteReq.setLastName(propertyValueArr[4]);
      	}
    	
    	if (remoteReq.getStreetAddress1	() == null) {
    		remoteReq.setStreetAddress1(propertyValueArr[5]);
    	}
       	
       	if (remoteReq.getCity() == null) {
       		remoteReq.setCity(propertyValueArr[6]);
       	}
       	
       	if (remoteReq.getState() == null) {
       		remoteReq.setState(propertyValueArr[7]);
       	}
       	
       	if (remoteReq.getZipCode() == null) {
       		remoteReq.setZipCode(propertyValueArr[8]);
       	}
       	
       	if ("DERA".equalsIgnoreCase(workflow)) {
       		if (remoteReq.getEmailAddress() == null) {
           		remoteReq.setEmailAddress(propertyValueArr[9]);
           	}
       		if (remoteReq.getProfilingSessionID() == null) {
           		remoteReq.setProfilingSessionID("8236EA586816-19c77d19-e778-442c");
           	}
       		if (remoteReq.getWebSessionID() == null) {
           		remoteReq.setWebSessionID("rDDJL5AUy2eTmXjm3L_sb-Z");
           	}
       		if (remoteReq.getTrueIPAddress() == null) {
           		remoteReq.setTrueIPAddress("127.0.0.1");
           	}
       	}

       	String remoteReqStr = new Gson().toJson(remoteReq);

    	PersonVo personVo = new PersonVo();
        Response response = remoteSupportService.buildRequestValidationResponse(remoteReq, personVo, origin);
           
        if (response != null) {
        	return response;
        }
          
        remoteSupportService.populatePersonVo(remoteReq, personVo);
        remoteSupportService.setSponsorAppData(remoteReq, personVo);
 
        try {
         	// This call will create the person and person_proofing_status record if they do not exist.
        	if (personVo.getSponsorUserId() == null) {
        		String addressHash = remoteSupportService.calculateNameAddressHash(remoteReq);
            	personVo.setSponsorUserId(addressHash);
        	}

        	Person person = proofingService.updatePerson(personVo);
            proofingService.startProofingSession(person, personVo);

            CommonAssessmentParamVo assessmentVo = remoteSupportService.mergeParamObjects(remoteReq, personVo);
            response = remoteSupportService.getVerifyTestBusinessResponse(origin, remoteReq, person, personVo, assessmentVo);
             
            return response;
        } catch (Exception e) {
        	response = remoteSupportService.exceptionErrorResponse(personVo, null, "assessing DevicePlusEmailRisk", origin, e);
          	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, response);
        }
        
		return response;
    }
   
    @Override
    public Response verifyPhone(RemoteRequest remoteReq, String origin) throws Throwable {
    	remoteReq.setAssessmentCall(RemoteProofingServiceImpl.VERIFY_PHONE);
    	PersonVo personVo = new PersonVo();
        // Validate the data that was passed in determining any missing or incorrect formatted values.
        Response response = remoteSupportService.buildRequestValidationResponse(remoteReq, personVo, origin);
           
        if (response != null) {
        	return response;
        }
          
        remoteSupportService.populatePersonVo(remoteReq, personVo);
        remoteSupportService.setSponsorAppData(remoteReq, personVo);
 
       	RefOtpSupplier phoneSupplier = null;
       	Person person = null;
        long sponsorId = personVo.getSponsorId();
        String requestId = getRequestId(personVo);
        
        try {
         	person = proofingService.updatePerson(personVo);
            proofingService.startProofingSession(person, personVo);

            boolean isIndividualNotFound = rpDeviceReputationResponseService.isIndividualNotFound(person.getPersonId());
            personVo.setLexisNexisIndividualNotFound(isIndividualNotFound);
            
         	phoneSupplier = remoteSupportService.determineVerificationMethod(personVo);

	        if (phoneSupplier == null) {
	         	String message = "";
	         	
	         	if (personVo.hasError()) {
	         		message = personVo.getErrorMessage();
	         	}
	         	else {
		         	String userId = personVo.getSponsorUserId();
		         	message = "while determining phone verification supplier: No PV supplier was selected";
		         	message = String.format("Error thrown for user: %s %s", userId, message);

	         	}
 	        	CustomLogger.error(this.getClass(), message);
	
 	            return remoteSupportService.buildErrorResponse(origin, sponsorId, requestId, personVo.getCallingMethod(), message);
	        } 
        } catch (Exception e) {
        	return remoteSupportService.exceptionErrorResponse(personVo, RemoteSupportServiceImpl.VERIFY_PHONE, "determining verification method", origin, e);
        }
       
        try {
            // Perform a phone velocity check; if check fails, return a fail response.
             boolean passPhoneVelocity = remoteSupportService.passPhoneVelocity(person, personVo, phoneSupplier, RemoteSupportServiceImpl.VERIFY_PHONE);
             
             if (!passPhoneVelocity) {
         	    //String userId = personVo.getSponsorUserId();
         	    //String message = "Phone velocity check failed for user:".concat(userId);
     	   	       
              	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, message);

              	JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, null, RemoteSupportServiceImpl.VERIFY_PHONE, IPSConstants.VELOCITY_TYPE_PHONE , RemoteSupportServiceImpl.REASON_FAILED_PHONE_VELOCITY);
                return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
            }
         } 
  		catch (Exception e) {
         	return remoteSupportService.exceptionErrorResponse(personVo, RemoteSupportServiceImpl.VERIFY_PHONE, "checking phone velocity", origin, e);
         }
         
            
        PhoneVerificationResponse pvResponse = null;
  
        // Set DeviceTypeMobile to false for Experian so it won't be directed to silent authentication process.
        //Silent authentication was only implemented in Informed Delivery/Hold Mail applications.
        if (phoneSupplier.isExperianPhone()) {
            personVo.setDeviceTypeMobile(false);
        }
        
         try {
            // Verify the phone number; return a response on a failed verification.
          	pvResponse = phoneVerificationService.verifyPhone(personVo, phoneSupplier);
         	
         	// pvResponse is null when all available suppliers web service failed.
         	if (pvResponse == null) {
         		JSONObject remResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, null, RemoteSupportServiceImpl.VERIFY_PHONE, IPSConstants.VELOCITY_TYPE_PHONE , RemoteSupportServiceImpl.REASON_FAILED_SUPPLIER_SELECTION);
  	   	        return remoteSupportService.buildPVResponse(null, remResponseJSON, origin);
         	}           	
         } catch (Exception e) {        	
         	return remoteSupportService.exceptionErrorResponse(personVo, null, "verifying phone", origin, e);
         }

     	String pvDecision = pvResponse.getPhoneVerificationDecision();
     	RpEvent rpEvent = null;
         try {
         	rpEvent = remoteSupportService.getLatestPV(person.getPersonId(), phoneSupplier.getOtpSupplierId());
             if (rpEvent != null && rpEvent.getRpPhoneVerification().getTransactionKey() != null) {
             	personVo.setTransactionId(rpEvent.getRpPhoneVerification().getTransactionKey());
             }
         } catch (Exception e) {
           	return remoteSupportService.latestEventErrorResponse(personVo, null, origin, e);
         }
         
     	if (RpPhoneVerification.DECISION_FAILED.equalsIgnoreCase(pvDecision) 
     			|| RpPhoneVerification.DECISION_DENIED.equalsIgnoreCase(pvDecision)) {
             String message = String.format(RemoteSupportServiceImpl.PV_FAILED_MSG_FMT, personVo.getSponsorUserId());
             CustomLogger.info(this.getClass(), message);
                 
             //message = String.format(RemoteSupportServiceImpl.PV_FAILED_MSG_FMT, personVo.getSponsorUserId());
             //remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, message);

             JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VERIFY_PHONE, IPSConstants.VELOCITY_TYPE_PHONE , RemoteSupportServiceImpl.REASON_FAILED_PHONE_VERIFICATION);
    	     return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
         }        	

         // If phone verification decision is "Approve", Equifax DIT (with all Trust is Y) 
     	 // or Experian (with successful Silent Authentication) was used as phone verification method.
         // The verification process stops here and the user has achieved the LOA 1.5. 
         if (RpPhoneVerification.DECISION_APPROVED.equalsIgnoreCase(pvDecision) || RpPhoneVerification.DECISION_PASSED.equalsIgnoreCase(pvDecision)) {
        	 JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VERIFY_PHONE, IPSConstants.VELOCITY_TYPE_PHONE , RemoteSupportServiceImpl.REASON_APPROVED_PHONE_VERIFICATION);
 	   	     return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
         } 
         
         // If phone verification decision is "Review", Experian (with OTPFlow) may be was used as phone verification method.
         // The verification process sends the OTP right after the phone was verified. 
         if (RpPhoneVerification.DECISION_FOR_REVIEW.equalsIgnoreCase(pvDecision) 
        		 && phoneSupplier.isExperianPhone()) {
             // Get the latest phone verification for the user in order to return the transaction id.
             RpEvent rp = remoteSupportService.getLatestPV(person.getPersonId(), phoneSupplier.getOtpSupplierId());
             if (rp != null && rp.getLatestOtpAttempt() != null) {
              	personVo.setTransactionId(rp.getLatestOtpAttempt().getTransactionKey());
             }
    
             JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VERIFY_PHONE, 
   	       			IPSConstants.VELOCITY_TYPE_PASSCODE , RemoteSupportServiceImpl.REASON_SUCCESSS_OTP_DELIVERY);
    	       	return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
         } 
        
         // If phone verification decision is "Pass" or "Review", the verification process continues.
      	String velocityType = phoneSupplier.isEquifaxDITPhone() ? IPSConstants.VELOCITY_TYPE_SMFA : IPSConstants.VELOCITY_TYPE_PASSCODE;
      	personVo.setAttemptType(RemoteSupportServiceImpl.ATTEMPT_TYPE_REQUEST);
         try {
             // Check if number of passcode or link attempts is exceeded; if exceeded, return a fail response.
        		boolean passOtpVelocity = remoteSupportService.passVelocityCheck(velocityType, person, personVo, phoneSupplier, rpEvent);
        		if (!passOtpVelocity) {
                	//String message = String.format("Customer %s exceeded %s attempts.", personVo.getSponsorUserId(), velocityType);
                	//sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId, RemoteSupportServiceImpl.VERIFY_PHONE,
                	//        Response.Status.BAD_REQUEST, message);

                 	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, message);

        			String reason =  phoneSupplier.isEquifaxDITPhone() ?  RemoteSupportServiceImpl.REASON_FAILED_SMFA_VELOCITY :  RemoteSupportServiceImpl.REASON_FAILED_OTP_VELOCITY;
        			JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VERIFY_PHONE, velocityType , reason);
 	   	       		return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
        		}
         } catch (Exception e) {
         	return remoteSupportService.exceptionErrorResponse(personVo, RemoteSupportServiceImpl.VERIFY_PHONE, "checkOTPLinkVelocity", origin, e);
         }
         
         try {
             if (phoneSupplier.isEquifaxDITPhone()) {
              	// isDesktop value is set to true as default. 
             	// For web service call, this flag is not evaluated as it is being done at the caller's side.
                	boolean isDesktop = true; 
              	int isLinkSuccessfullySent = phoneVerificationService.sendSmfaLink(personVo, phoneSupplier, isDesktop);

              	// values from sendSMFALink were changed from true/false (boolean) to:
              	// 0 success
              	// 200 unsuccessful and land line
              	// 422 unsuccessful and land line
              	// 500 error 'display unable to verify message'
              	// 401 error 'display unable to verify message'                
                 if (isLinkSuccessfullySent != 0) {
                     CustomLogger.info(this.getClass(), "SMFA Link failed to send for customer " + personVo.getSponsorUserId());

                     rpEvent = remoteSupportService.getLatestPV(personVo.getId(), phoneSupplier.getOtpSupplierId());
                     
                     if (rpEvent != null && rpEvent.getRpPhoneVerification() != null) {
                     	personVo.setTransactionId(rpEvent.getRpPhoneVerification().getTransactionKey());
                     }

                     JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VERIFY_PHONE, velocityType , RemoteSupportServiceImpl.REASON_FAILED_SMFA_DELIVERY);
     	   	       	 return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
                 }           
             }
             else {
             	 boolean sendPasscodeSuccessful = phoneVerificationService.sendPasscodeSuccessful(personVo, phoneSupplier);

                 // Get the most up to date person record so otp sent comparison can be accurate
                 person = personDataService.findByPK(personVo.getId());

                 // Get proofing status to determine if passcode was sent
                 int personId = (int) person.getPersonId();
                 PersonProofingStatus latestProofingStatus = personProofingStatusService.getByPersonId(personId);
                 boolean otpSent = latestProofingStatus != null && latestProofingStatus.getRefRpStatus().getStatusCode() == RefRpStatus.RpStatus.OTP_sent.getValue();

                 if (!otpSent) {
                     CustomLogger.info(this.getClass(), "Passcode failed to send for customer " + personVo.getSponsorUserId());

                     rpEvent = remoteSupportService.getLatestPV(person.getPersonId(), phoneSupplier.getOtpSupplierId());
                     if (rpEvent != null && rpEvent.getRpPhoneVerification() != null) {
 	                    String transactionKey = rpEvent.getRpPhoneVerification().getTransactionKey();
 	                    
 	                    if (transactionKey != null) {
 	                    	personVo.setTransactionId(transactionKey);
 	                    }
                     }

                     //String type = phoneSupplier.isEquifaxDITPhone() ? RemoteSupportServiceImpl.MFA_TYPE_SMFA_LINK : RemoteSupportServiceImpl.MFA_TYPE_PASSCODE;
                     //String message = String.format("%s was not sent to customer %s.", type, personVo.getSponsorUserId());
  
                     //remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, message);

                     JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VERIFY_PHONE, velocityType , RemoteSupportServiceImpl.REASON_FAILED_OTP_DELIVERY);
     	   	       	 return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
                  }
             }
         } catch (Exception e) {
          	if (personVo.isOtpSmsLandline()) {
          		JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, null, RemoteSupportServiceImpl.VERIFY_PHONE, IPSConstants.VELOCITY_TYPE_PHONE , RemoteSupportServiceImpl.REASON_FAILED_PHONE_VERIFICATION);
      	   	    return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
         	}
          	else {
          		return remoteSupportService.exceptionErrorResponse(personVo, RemoteSupportServiceImpl.VERIFY_PHONE, "checking Passcode or SMFA Link velocity", origin, e);
          	}
         }
         
         try {
             // Get the latest phone verification for the user in order to return the transaction id
             RpEvent rp = remoteSupportService.getLatestPV(person.getPersonId(), phoneSupplier.getOtpSupplierId());
             if (rp != null && rp.getLatestOtpAttempt() != null) {
              	personVo.setTransactionId(rp.getLatestOtpAttempt().getTransactionKey());
             }
             
             String reason = phoneSupplier.isEquifaxDITPhone() ? RemoteSupportServiceImpl.REASON_SUCCESSSFUL_SMFA_DELIVERY : RemoteSupportServiceImpl.REASON_SUCCESSS_OTP_DELIVERY;
             JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VERIFY_PHONE, velocityType , reason);
    	       	return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
          } catch (Exception e) {
         	return remoteSupportService.exceptionErrorResponse(personVo, RemoteSupportServiceImpl.VERIFY_PHONE, "sending passcode or SMFA Link to phone", origin, e);
         }

    }

    @Override
    public Response confirmPasscode(RemoteRequest remoteReq, String origin) {
     	CustomLogger.enter(this.getClass());
    	remoteReq.setAssessmentCall(RemoteProofingServiceImpl.CONFIRM_PASSCODE);
    	PersonVo personVo = new PersonVo();
    	
        // Validate the data that was passed in determining any missing or incorrect formatted values.
        Response response = remoteSupportService.buildRequestValidationResponse(remoteReq, personVo, origin);
           
        if (response != null) {
        	return response;
        }
          
        remoteSupportService.populatePersonVo(remoteReq, personVo);
        remoteSupportService.setSponsorAppData(remoteReq, personVo);

        RemoteResponse pvResponse = new RemoteResponse();
    	Person person =  null;
        long sponsorId = personVo.getSponsorId();
        String sponsorUserId = personVo.getSponsorUserId();
        String requestId = getRequestId(personVo);

         try {
             // Check if web service calls for sponsorID are disabled.
             RefSponsor sponsor = refSponsorService.findByPK(sponsorId);
             person = personDataService.findFirstBySponsor(sponsor, sponsorUserId);

             long personId = 0L;
             if (person != null) {
            	 personId = person.getPersonId();
             }
             else {
             	return remoteSupportService.personNotFoundResponse(sponsorId, sponsorUserId, requestId, 
             			RemoteSupportServiceImpl.CONFIRM_PASSCODE, origin);
             }

             RefOtpSupplier phoneSupplier = remoteSupportService.getLatestPhoneSupplier(personId);

             if (phoneSupplier == null) {
                 String message = String.format(RemoteSupportServiceImpl.SUPPLIER_NOT_FOUND_MSG_FMT, personId);
                 //String requestStr = new Gson().toJson(remoteReq);
                 //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, message, requestId);

                 return remoteSupportService.buildErrorPVResponse(400, message, origin);
             }
             
             if (phoneSupplier.isEquifaxDITPhone()) {
             	 String responseMessage = "Confirm Passcode is not implemented for Equifax DIT SMFA";
                 //String requestStr = new Gson().toJson(remoteReq);
                 //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, responseMessage, requestId);
 
                 return remoteSupportService.buildErrorPVResponse(400, responseMessage, origin);
             }
             else if (phoneSupplier.isExperianPhone()) {
            	 remoteSupportService.populatePersonVoFromPerson(person, personVo);
             }
             
             RpEvent rpEvent = null;
             try {
             	rpEvent = remoteSupportService.getLatestPV(person.getPersonId(), phoneSupplier.getOtpSupplierId());
             	
                 if (rpEvent == null) {
                 	return remoteSupportService.eventNotFoundResponse(sponsorId, phoneSupplier.getOtpSupplierId(), person.getSponsorUserId(), 
                 			requestId, RemoteSupportServiceImpl.CONFIRM_PASSCODE, origin);
                 }
             } catch (Exception e) {
             	return remoteSupportService.latestEventErrorResponse(personVo, RemoteSupportServiceImpl.CONFIRM_PASSCODE, origin, e);
             }

             // Get verified phone number on file.
             if (rpEvent.getRpPhoneVerification() != null) {
             	personVo.setMobileNumber(rpEvent.getRpPhoneVerification().getMobilePhoneNumber());
             }
             
             // If phone is not verified on file, return fail response.
             String reason = remoteSupportService.checkPhoneVerified(origin, person, personVo, rpEvent, phoneSupplier, RemoteSupportServiceImpl.CONFIRM_PASSCODE);
             
             if (reason != null) {    
            	 //String requestStr = new Gson().toJson(remoteReq);
            	 
	             if (RemoteSupportServiceImpl.REASON_FAILED_OTP_VELOCITY.equalsIgnoreCase(reason)) {
	                 //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);

	                 JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.CONFIRM_PASSCODE, IPSConstants.VELOCITY_TYPE_PASSCODE , reason);
	    	   	     return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
	             }
	             else if (RemoteSupportServiceImpl.REASON_FAILED_PHONE_VERIFICATION.equalsIgnoreCase(reason)) {
	                 //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);

	                 JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.CONFIRM_PASSCODE, IPSConstants.VELOCITY_TYPE_PASSCODE , reason);
	    	   	     return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
	             }
	             else if (RemoteSupportServiceImpl.REASON_APPROVED_PHONE_VERIFICATION.equalsIgnoreCase(reason)) {
	            	 JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.CONFIRM_PASSCODE, IPSConstants.VELOCITY_TYPE_PASSCODE , reason);
	 	   	       	 return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
	             }
	             else if (RemoteSupportServiceImpl.REASON_FAILED_RP_EVENT_RETRIEVAL.equalsIgnoreCase(reason)) {
	                //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);
		 	   	    
	                return remoteSupportService.latestEventErrorResponse(personVo, null, origin, null);
		         }	  
	         }

             pvResponse.setTransactionID(rpEvent.getLatestOtpAttempt().getTransactionKey());

             // Set the ID for PersonVo to Person ID.
             // Must do this so confirmPasscode call can find latest phone verification.
             personVo.setId(person.getPersonId());
             personVo.setSponsorId(person.getRefSponsor().getSponsorId());

             // Check if passcode sent by user matches with what was sent to the phone.
             // Return a fail response if passcode does not match.
             reason = remoteSupportService.passcodeConfirmation(origin, personVo, phoneSupplier);

             // PassVelocityCheck has already passed at this point. 
             // This is just to get the number of passcode attempts.
             personVo.setAttemptType(RemoteSupportServiceImpl.ATTEMPT_TYPE_CONFIRM);
             remoteSupportService.passVelocityCheck(IPSConstants.VELOCITY_TYPE_PASSCODE, person, personVo, phoneSupplier, rpEvent);

             if (reason != null) {
            	 if (RemoteSupportServiceImpl.REASON_FAILED_OTP_CONFIRMATION.equalsIgnoreCase(reason)) {
                     try {
                     	rpEvent = remoteSupportService.getLatestPV(person.getPersonId(), phoneSupplier.getOtpSupplierId());
                     } catch (Exception e) {
                    	//String requestStr = new Gson().toJson(remoteReq);
     	                //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);

                        return remoteSupportService.latestEventErrorResponse(personVo, RemoteSupportServiceImpl.CONFIRM_PASSCODE, origin, e);
                     }
                     
                     CustomLogger.info(this.getClass(), pvResponse.getResponseMessage());
  	                 //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);

  	                 JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.CONFIRM_PASSCODE, IPSConstants.VELOCITY_TYPE_PASSCODE , reason);
    	   	       	 return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
                }
            	else {
	                 //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);

                   	 return remoteSupportService.exceptionErrorResponse(personVo, RemoteSupportServiceImpl.CONFIRM_PASSCODE, reason, origin, null);
            	}
             }
              
             CustomLogger.info(this.getClass(), pvResponse.getResponseMessage());
             
             JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.CONFIRM_PASSCODE, IPSConstants.VELOCITY_TYPE_PASSCODE , RemoteSupportServiceImpl.REASON_PASSED_OTP_CONFIRMATION);
	   	     return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
          } catch (Exception e) {
         	 return remoteSupportService.exceptionErrorResponse(personVo, RemoteSupportServiceImpl.CONFIRM_PASSCODE, "confirming passcode", origin, e);
          }
    }
     
 	@SuppressWarnings("unused")
	@Override
    public Response requestPasscode(RemoteRequest remoteReq, String origin) throws Throwable {
    	CustomLogger.enter(this.getClass());
    	
    	remoteReq.setAssessmentCall(RemoteProofingServiceImpl.REQUEST_PASSCODE);
    	PersonVo personVo = new PersonVo();
		
		 // Validate the data that was passed in determining any missing or incorrect formatted values.
        Response response = remoteSupportService.buildRequestValidationResponse(remoteReq, personVo, origin);
           
        if (response != null) {
        	return response;
        }
          
        remoteSupportService.populatePersonVo(remoteReq, personVo);
        remoteSupportService.setSponsorAppData(remoteReq, personVo);
  
        JSONObject remoteResponseJSON = new JSONObject();
        long sponsorId = personVo.getSponsorId();
        String requestId = getRequestId(personVo);
    	String requestStr = new Gson().toJson(remoteReq);

        // Check if web service calls for sponsorID are disabled.
        RefSponsor sponsor = refSponsorService.findByPK(sponsorId);
 
        Person person = personDataService.findFirstBySponsor(sponsor, personVo.getSponsorUserId());
        if (person == null) {
            //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, "Person is null.", requestId);

        	return remoteSupportService.personNotFoundResponse(sponsorId, personVo.getSponsorUserId(), requestId, 
        			RemoteSupportServiceImpl.REQUEST_PASSCODE, origin);
        }
       
        personVo.setId(person.getPersonId());
        personVo.setSponsorId(person.getRefSponsor().getSponsorId());

        RefOtpSupplier phoneSupplier = remoteSupportService.getLatestPhoneSupplier(personVo.getId());

        if (phoneSupplier == null) {
            String message = String.format(RemoteSupportServiceImpl.SUPPLIER_NOT_FOUND_MSG_FMT, person.getPersonId());
            CustomLogger.info(this.getClass(), message);
            
            //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, message, requestId);

            return remoteSupportService.buildErrorPVResponse(400, message, origin);
        }

        if (phoneSupplier.isEquifaxDITPhone()) {
        	String responseMessage = "Request Passcode is not implemented for Equifax DIT SMFA";
          	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, responseMessage);

            return remoteSupportService.buildErrorPVResponse(400, responseMessage, origin);
        }
        else if (phoneSupplier.isLexisNexisPhone() || phoneSupplier.isExperianPhone()) {
            // Get proofing status to determine if passcode was already confirmed and user has achieved LOA level.
            List<PersonProofingStatus> proofingStatus = person.getProofingStatuses();
            boolean loaAchieved = !proofingStatus.isEmpty() && proofingStatus.get(0).getRefRpStatus()
                    .getStatusCode() == RefRpStatus.RpStatus.LOA_level_achieved.getValue();

            if (loaAchieved) {
           	 	String logMsg = "Previous passcode was confirmed and LOA level already achieved. New passcode could not be sent to customer " + personVo.getSponsorUserId();
                CustomLogger.info(this.getClass(), logMsg);

                remoteResponseJSON.put("responseMessage", logMsg);
            	return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
            }
        }
        
        RpEvent rpEvent = null;
        try {
            rpEvent = remoteSupportService.getLatestPV(person.getPersonId(), phoneSupplier.getOtpSupplierId());
            
            if (rpEvent == null) {
                //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, "RpEvent is null.", requestId);

            	return remoteSupportService.eventNotFoundResponse(sponsorId, phoneSupplier.getOtpSupplierId(), person.getSponsorUserId(), 
            			requestId, RemoteSupportServiceImpl.REQUEST_PASSCODE, origin);
            }
        } catch (Exception e) {
            //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, e.getMessage(), requestId);

           	return remoteSupportService.latestEventErrorResponse(personVo, RemoteSupportServiceImpl.REQUEST_PASSCODE, origin, e);
        }

        personVo.setPhoneVerificationSupplierName(phoneSupplier.getOtpSupplierName());
      
        // Get verified phone number on file.
        if (rpEvent != null && rpEvent.getRpPhoneVerification() != null) {
        	personVo.setMobileNumber(rpEvent.getRpPhoneVerification().getMobilePhoneNumber());
        }
        
        try {
        	person = personDataService.findByPK(personVo.getId());
        
        	// When phone is not verified on file, return fail response.
            String reason = remoteSupportService.checkPhoneVerified(origin, person, personVo, rpEvent, phoneSupplier, RemoteSupportServiceImpl.REQUEST_PASSCODE);

            if (reason != null) {
   	            if (RemoteSupportServiceImpl.REASON_FAILED_OTP_VELOCITY.equalsIgnoreCase(reason)) {
	                 //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);
	                 remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.CONFIRM_PASSCODE, IPSConstants.VELOCITY_TYPE_PASSCODE , reason);
   	    	   	     return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
   	             }
   	             else if (RemoteSupportServiceImpl.REASON_FAILED_PHONE_VERIFICATION.equalsIgnoreCase(reason)) {
 	                 //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);

 	                 remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.CONFIRM_PASSCODE, IPSConstants.VELOCITY_TYPE_PASSCODE , reason);
   	    	   	     return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
   	             }
   	             else if (RemoteSupportServiceImpl.REASON_APPROVED_PHONE_VERIFICATION.equalsIgnoreCase(reason)) {
 	                //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);

 	                remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.CONFIRM_PASSCODE, IPSConstants.VELOCITY_TYPE_PASSCODE , reason);
   	 	   	       	return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
   	             }
   	             else if (RemoteSupportServiceImpl.REASON_FAILED_RP_EVENT_RETRIEVAL.equalsIgnoreCase(reason)) {
	                //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);

		 	   	    return remoteSupportService.latestEventErrorResponse(personVo, null, origin, null);
   	             }
            }

           reason = remoteSupportService.sendPasscodeToPhone(personVo, phoneSupplier, rpEvent);
             
           if (reason != null) {
              	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, reason);

                if (RemoteSupportServiceImpl.REASON_FAILED_OTP_DELIVERY.equalsIgnoreCase(reason)) {
	                //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);

	                remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.REQUEST_PASSCODE, IPSConstants.VELOCITY_TYPE_PASSCODE , RemoteSupportServiceImpl.REASON_FAILED_OTP_DELIVERY);
    	   	       	return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
                }
                else {
	                //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);

                   	return remoteSupportService.exceptionErrorResponse(personVo, RemoteSupportServiceImpl.REQUEST_PASSCODE, reason, origin, null);
                }
            }
 
            //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, reason, requestId);

            remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.REQUEST_PASSCODE, IPSConstants.VELOCITY_TYPE_PASSCODE , RemoteSupportServiceImpl.REASON_SUCCESSS_OTP_DELIVERY);
  	       	return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);      	       	
        } catch (Exception e) {
            //remoteSupportService.saveDeviceReputationAssessmentResponse(person, requestStr, e.getMessage(), requestId);

          	return remoteSupportService.exceptionErrorResponse(personVo, RemoteSupportServiceImpl.REQUEST_PASSCODE, "requesting passcode", origin, e);
        }
    }
 	
 	 @Override
     public Response validateLink(RemoteRequest remoteReq, String origin) {
     	remoteReq.setAssessmentCall(RemoteProofingServiceImpl.VALIDATE_LINK);
     	PersonVo personVo = new PersonVo();
		
         // Validate the data that was passed in determining any missing or incorrect formatted values.
         Response response = remoteSupportService.buildRequestValidationResponse(remoteReq, personVo, origin);
            
         if (response != null) {
         	return response;
         }
           
         remoteSupportService.populatePersonVo(remoteReq, personVo);
         remoteSupportService.setSponsorAppData(remoteReq, personVo);
 
        RemoteResponse pvResponse = new RemoteResponse();
        long sponsorId = personVo.getSponsorId();
      	Person person =  null;
      	String requestId = getRequestId(personVo);

         try {
             // Check if web service calls for sponsorID are disabled.
             RefSponsor sponsor = refSponsorService.findByPK(sponsorId);
             
             person = personDataService.findFirstBySponsor(sponsor, personVo.getSponsorUserId());
             
             if (person == null) {
                	return remoteSupportService.personNotFoundResponse(sponsorId, personVo.getSponsorUserId(), requestId, 
                			RemoteSupportServiceImpl.VALIDATE_LINK, origin);
             }

             RefOtpSupplier phoneSupplier = remoteSupportService.getLatestPhoneSupplier(person.getPersonId());
             personVo.setId(person.getPersonId());
             personVo.setSponsorId(person.getRefSponsor().getSponsorId());

             if (phoneSupplier == null) {
                 String message = String.format(RemoteSupportServiceImpl.SUPPLIER_NOT_FOUND_MSG_FMT, person.getPersonId());
                 CustomLogger.info(this.getClass(), message);

                 //sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId,
                 //		 RemoteSupportServiceImpl.VALIDATE_LINK, Response.Status.BAD_REQUEST, message);

                 //remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, message);

                 return remoteSupportService.buildErrorPVResponse(400, message, origin);
             }
             
             if (phoneSupplier.isEquifaxIDFSPhone() || phoneSupplier.isLexisNexisPhone() || phoneSupplier.isExperianPhone()) {
             	String supplierName = phoneSupplier.isEquifaxIDFSPhone() ? RemoteSupportServiceImpl.SUPPLIER_EQUIFAX_IDFS : 
             		(phoneSupplier.isExperianPhone() ? RemoteSupportServiceImpl.SUPPLIER_EXPERIAN_CROSSCORE : RemoteSupportServiceImpl.SUPPLIER_LEXISNEXIS_RDP);
     	       	String responseMessage = "Validate SMFA Link is not implemented for ".concat(supplierName);
     	        //sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId,
     	        //		RemoteSupportServiceImpl.RESEND_LINK, Response.Status.BAD_REQUEST, responseMessage);
     	       	
               	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, responseMessage);

     	        return remoteSupportService.buildErrorPVResponse(400, responseMessage, origin);
             }  
             
             RpEvent rpEvent = null;
             try {
             	rpEvent = remoteSupportService.getLatestPV(person.getPersonId(), phoneSupplier.getOtpSupplierId());
             	
                 if (rpEvent == null) {
                    	return remoteSupportService.eventNotFoundResponse(sponsorId, phoneSupplier.getOtpSupplierId(), person.getSponsorUserId(), 
                 			requestId, RemoteSupportServiceImpl.VALIDATE_LINK, origin);
                 }
             } catch (Exception e) {
               	return remoteSupportService.latestEventErrorResponse(personVo, null, origin, e);
             }

             if(rpEvent.getLatestSmfaAttempt() != null) {
             	pvResponse.setSessionID(rpEvent.getLatestSmfaAttempt().getSessionId());
             }
             
             // Set the ID for PersonVo to Person ID.
             // Must do this so validateLink call can find latest phone verification.
             personVo.setId(person.getPersonId());
             personVo.setSponsorId(person.getRefSponsor().getSponsorId());

             // If phone is not verified on file, return fail response.
             String reason = remoteSupportService.checkPhoneVerified(origin, person, personVo, rpEvent, phoneSupplier, RemoteSupportServiceImpl.VALIDATE_LINK);
               
             if (reason != null) {
     	             if (RemoteSupportServiceImpl.REASON_FAILED_SMFA_VELOCITY.equalsIgnoreCase(reason)) {
    	             	//sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId,
    	             	//		RemoteSupportServiceImpl.VALIDATE_LINK, Response.Status.OK, reason);

     	               	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, reason);

     	                JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VALIDATE_LINK, IPSConstants.VELOCITY_TYPE_SMFA , reason);
    	    	   	    return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
    	             }
    	             else if (RemoteSupportServiceImpl.REASON_FAILED_PHONE_VERIFICATION.equalsIgnoreCase(reason)) {
    	             	//sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId,
    	             	//		RemoteSupportServiceImpl.VALIDATE_LINK, Response.Status.OK, reason);

    	                //remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, reason);

    	                JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VALIDATE_LINK, IPSConstants.VELOCITY_TYPE_SMFA , reason);
    	    	   	    return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
    	             }
    	             else if (RemoteSupportServiceImpl.REASON_APPROVED_PHONE_VERIFICATION.equalsIgnoreCase(reason)) {
    	            	JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VALIDATE_LINK, IPSConstants.VELOCITY_TYPE_SMFA , reason);
    	 	   	       	return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
    	             }
   	   	             else if (RemoteSupportServiceImpl.REASON_FAILED_RP_EVENT_RETRIEVAL.equalsIgnoreCase(reason)) {
   			 	   	    return remoteSupportService.latestEventErrorResponse(personVo, null, origin, null);
   	   	             }
             }
             
              try {
             	rpEvent = remoteSupportService.getLatestPV(person.getPersonId(), phoneSupplier.getOtpSupplierId());
             } catch (Exception e) {
              	return remoteSupportService.latestEventErrorResponse(personVo, null, origin, e);
             }

             // First check if the link attempt exceeded.
             boolean lastPasscodeAttemptExceededSubmit = rpEvent.lastPasscodeAttemptExceededSubmit();
             // Check if user tapped the link sent to the user's phone.
             // If so, check what color was returned from the Equifax SMFA validation.
             reason = remoteSupportService.checkSmfaLinkValidation(personVo);
             
             if (!lastPasscodeAttemptExceededSubmit && reason != null) {                 
                  if (RemoteSupportServiceImpl.REASON_FAILED_SMFA_VALIDATION.equalsIgnoreCase(reason)) {
                      //sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId,
                      //	  RemoteSupportServiceImpl.VALIDATE_LINK, Response.Status.OK, reason);

                      //remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, reason);

                      JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VALIDATE_LINK, IPSConstants.VELOCITY_TYPE_SMFA , reason);
    	 	   	      return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
                  }
                  else {
                	  //sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId,
                	  //		RemoteSupportServiceImpl.VALIDATE_LINK, Response.Status.OK, reason);
                     
                	  //remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, reason);

                	  return remoteSupportService.exceptionErrorResponse(personVo, null, reason, origin, null);
                  }
             }
                           
             CustomLogger.info(this.getClass(), pvResponse.getResponseMessage());

             JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.VALIDATE_LINK, IPSConstants.VELOCITY_TYPE_SMFA , RemoteSupportServiceImpl.REASON_PASSED_SMFA_VALIDATION);
 	   	     return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
         } catch (Exception e) {
          	return remoteSupportService.exceptionErrorResponse(personVo, null, "validating SMFA Link", origin, e);
         }
    }
 	
 	@SuppressWarnings("unused")
	@Override
    public Response resendLink(RemoteRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
    	
    	remoteReq.setAssessmentCall(RemoteProofingServiceImpl.RESEND_LINK);
    	PersonVo personVo = new PersonVo();
		
        // Validate the data that was passed in determining any missing or incorrect formatted values.
        Response response = remoteSupportService.buildRequestValidationResponse(remoteReq, personVo, origin);
           
        if (response != null) {
        	return response;
        }
          
        remoteSupportService.populatePersonVo(remoteReq, personVo);
        remoteSupportService.setSponsorAppData(remoteReq, personVo);
        
        JSONObject pvResponseJSON = new JSONObject();
        long sponsorId = personVo.getSponsorId();
        String requestId = getRequestId(personVo);  	        
         
        // Check if web service calls for sponsorID are disabled.
        RefSponsor sponsor = refSponsorService.findByPK(sponsorId);       
        Person person = personDataService.findFirstBySponsor(sponsor, personVo.getSponsorUserId());

        if (person == null) {
        	return remoteSupportService.personNotFoundResponse(sponsorId, personVo.getSponsorUserId(), requestId, 
        			RemoteSupportServiceImpl.RESEND_LINK, origin);
        }

        personVo.setId(person.getPersonId());
        personVo.setSponsorId(person.getRefSponsor().getSponsorId());

        RefOtpSupplier phoneSupplier = remoteSupportService.getLatestPhoneSupplier(personVo.getId());

        if (phoneSupplier == null) {
            String message = String.format(RemoteSupportServiceImpl.SUPPLIER_NOT_FOUND_MSG_FMT, person.getPersonId());
            CustomLogger.info(this.getClass(), message);
            
            //sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId,
            //		 RemoteSupportServiceImpl.RESEND_LINK, Response.Status.BAD_REQUEST, message);

           	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, message);

            return remoteSupportService.buildErrorPVResponse(400, message, origin);
        }
        
        if (phoneSupplier.isEquifaxIDFSPhone() || phoneSupplier.isLexisNexisPhone() || phoneSupplier.isExperianPhone()) {
        	String supplierName = phoneSupplier.isEquifaxIDFSPhone() ? RemoteSupportServiceImpl.SUPPLIER_EQUIFAX_IDFS : 
        		(phoneSupplier.isExperianPhone() ? RemoteSupportServiceImpl.SUPPLIER_EXPERIAN_CROSSCORE : RemoteSupportServiceImpl.SUPPLIER_LEXISNEXIS_RDP);
	       	String responseMessage = "Resend SMFA Link is not implemented for ".concat(supplierName);
	        //sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId,
	        //		RemoteSupportServiceImpl.RESEND_LINK, Response.Status.BAD_REQUEST, responseMessage);
	        
           	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, responseMessage);

	        return remoteSupportService.buildErrorPVResponse(400, responseMessage, origin);
        }  
        else if (phoneSupplier.isEquifaxDITPhone()) {
            // Get proofing status to determine if SMFA link was already validated successfully and user has achieved LOA level.
            List<PersonProofingStatus> proofingStatus = person.getProofingStatuses();
            boolean loaAchieved = !proofingStatus.isEmpty() && proofingStatus.get(0).getRefRpStatus()
                    .getStatusCode() == RefRpStatus.RpStatus.LOA_level_achieved.getValue();

            if (loaAchieved) {
           	 	String logMsg = "Previous authentication link was successfully validated and LOA level already achieved. New authentication link could not be sent to customer " + personVo.getSponsorUserId();
                CustomLogger.info(this.getClass(), logMsg);

                pvResponseJSON.put("responseMessage", logMsg);
            	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
            }
        }
        
        RpEvent rpEvent = null;
       
    	try {
            rpEvent = remoteSupportService.getLatestPV(person.getPersonId(), phoneSupplier.getOtpSupplierId());
            
            if (rpEvent == null) {
            	return remoteSupportService.eventNotFoundResponse(sponsorId, phoneSupplier.getOtpSupplierId(), person.getSponsorUserId(), 
            			requestId, RemoteSupportServiceImpl.RESEND_LINK, origin);
            }
        } catch (Exception e) {
           	return remoteSupportService.latestEventErrorResponse(personVo, RemoteSupportServiceImpl.RESEND_LINK, origin, e);
        }

        try {
            personVo.setPhoneVerificationSupplierName(phoneSupplier.getOtpSupplierName());
         
            // To obtain the phone velocity status.
            remoteSupportService.passVelocityCheck(IPSConstants.VELOCITY_TYPE_PHONE, person, personVo, phoneSupplier, null);

            // When phone is not verified on file, return fail response.
            String reason = remoteSupportService.checkPhoneVerified(origin, person, personVo, rpEvent, phoneSupplier, RemoteSupportServiceImpl.RESEND_LINK);
 
            if (reason != null) {                	
            	 if (RemoteSupportServiceImpl.REASON_APPROVED_PHONE_VERIFICATION.equalsIgnoreCase(reason)) {
            		JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.RESEND_LINK, IPSConstants.VELOCITY_TYPE_SMFA , reason);
   	 	   	       	return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
   	             }
            	 else if (RemoteSupportServiceImpl.REASON_FAILED_PHONE_VERIFICATION.equalsIgnoreCase(reason)) {
                    	//sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId,
                    	//		RemoteSupportServiceImpl.RESEND_LINK, Response.Status.OK, reason);

                    	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, reason);

                    	JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.RESEND_LINK, IPSConstants.VELOCITY_TYPE_SMFA , reason);
   	    	   	       	return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
   	             }
            	 else if (RemoteSupportServiceImpl.REASON_FAILED_SMFA_VELOCITY.equalsIgnoreCase(reason)) {
                    	//sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId,
                    	//		RemoteSupportServiceImpl.RESEND_LINK, Response.Status.OK, reason);

                    	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, reason);

                    	JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.RESEND_LINK, IPSConstants.VELOCITY_TYPE_SMFA , reason);
   	    	   	       	return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
   	             }
   	             else if (RemoteSupportServiceImpl.REASON_FAILED_RP_EVENT_RETRIEVAL.equalsIgnoreCase(reason)) {
		 	   	    return remoteSupportService.latestEventErrorResponse(personVo, null, origin, null);
   	             }
            }
           		
            // Get verified phone number on file.
            if (rpEvent != null && rpEvent.getRpPhoneVerification() != null) {
            	personVo.setMobileNumber(rpEvent.getRpPhoneVerification().getMobilePhoneNumber());
            }

         	// isDesktop value is set to true as default. 
        	// For web service call, this flag is not evaluated as it is being done at the caller's side.
           	boolean isDesktop = true; 
         	int isLinkSuccessfullySent = phoneVerificationService.sendSmfaLink(personVo, phoneSupplier, isDesktop);

         	// Values from sendSMFALink were changed from true/false (boolean) to:
         	// 0 success
         	// 200 unsuccessful and land line
         	// 422 unsuccessful and land line
         	// 500 error 'display unable to verify message'
         	// 401 error 'display unable to verify message'                
            if (isLinkSuccessfullySent != 0) {
            	String errorMsg = "SMFA Link failed to send for customer " + personVo.getSponsorUserId();
                CustomLogger.info(this.getClass(), errorMsg);
                //sponsorIncomingRequestsService.documentAgencyRequest(sponsorId, requestId,
                //		RemoteSupportServiceImpl.RESEND_LINK, Response.Status.OK, errorMsg);
                
               	//remoteSupportService.saveDeviceReputationAssessmentResponse(personVo, remoteReq, errorMsg);

                rpEvent = remoteSupportService.getLatestPV(personVo.getId(), phoneSupplier.getOtpSupplierId());
                if (rpEvent != null && rpEvent.getRpPhoneVerification() != null) {
                	personVo.setTransactionId(rpEvent.getRpPhoneVerification().getTransactionKey());
                }

                JSONObject remoteResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.RESEND_LINK, IPSConstants.VELOCITY_TYPE_SMFA , RemoteSupportServiceImpl.REASON_FAILED_SMFA_DELIVERY);
	   	       	return remoteSupportService.buildPVResponse(null, remoteResponseJSON, origin);
            }         
           
            pvResponseJSON = remoteSupportService.buildRemoteResponseJSON(personVo, phoneSupplier, rpEvent, RemoteSupportServiceImpl.RESEND_LINK, IPSConstants.VELOCITY_TYPE_SMFA, RemoteSupportServiceImpl.REASON_SUCCESSSFUL_SMFA_DELIVERY);
            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
        } catch (Exception e) {
          	return remoteSupportService.exceptionErrorResponse(personVo, RemoteSupportServiceImpl.RESEND_LINK, "resending SMFA Link", origin, e);
        }
    }

 	private String getRequestId(PersonVo personVo) {
        String requestId = personVo.getRequestId();
        
        if (requestId == null) {
        	String sponsorUserId = personVo.getSponsorUserId();
  
      		requestId = sponsorUserId != null? String.format("%s - %s", sponsorUserId, DateTimeUtil.getCurrentDateTime())
      			: String.format("DT%s",  DateTimeUtil.getCurrentDateTime());
         }
         
        personVo.setRequestId(requestId);
        return requestId;
	}
}
