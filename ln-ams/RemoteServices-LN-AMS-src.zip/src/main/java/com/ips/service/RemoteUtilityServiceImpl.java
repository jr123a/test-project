package com.ips.service;

import java.io.InputStream;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.Utils;
import com.ips.entity.HighRiskAddress;
import com.ips.entity.OtpLockoutInfo;
import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefApp;
import com.ips.entity.RefCustomerCategory;
import com.ips.entity.RefHighRiskAddressType;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RefWorkflowApiType;
import com.ips.entity.RpEvent;
import com.ips.entity.RpInfPvAttemptConfig;
import com.ips.entity.RpOtpAttemptConfig;
import com.ips.entity.RpSupplierToken;
import com.ips.entity.SponsorApplicationMap;
import com.ips.persistence.common.ExperianResultVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.NameValueVo;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.ReportIndividualDataVo;
import com.ips.persistence.common.WorkflowApiDecisionVo;
import com.ips.proofing.CommonRestService;
import com.ips.proofing.CommonRestServiceImpl;
import com.ips.proofing.ExperianServiceImpl;
import com.ips.request.RemoteRequest;
import com.ips.request.RemoteUtilityRequest;
import com.ips.response.InputValidationError;
import com.ips.validation.ErrorMessage;
import com.ips.validation.RemoteProofingValidatedField;

@Service("remoteUtilityService")
@Transactional
public class RemoteUtilityServiceImpl implements Serializable, RemoteUtilityService {
    private final static long serialVersionUID = 1L;

    @Autowired
    private CommonRestService commonRestService;
    @Autowired
    private HighRiskAddressService highRiskAddressService;
    @Autowired
    private OtpAttemptConfigService otpAttemptConfigService;
    @Autowired
    private OtpLockoutInfoService otpLockoutInfoService;
    @Autowired
    private PersonDataService personDataService;
    @Autowired
    private PersonProofingStatusService personProofingStatusService;
    @Autowired
    private RefAppService refAppService;
    @Autowired
    private RefCustomerCategoryService refCustomerCategoryService;
    @Autowired
    private RefLoaLevelService refLoaLevelService;
    @Autowired
    private RefRpStatusDataService refRpStatusDataService;
    @Autowired
    private RefSponsorConfigurationService refSponsorConfigService;
    @Autowired
    private RefSponsorDataService refSponsorDataService;
    @Autowired
    private RefWorkflowApiTypeService refWorkflowApiTypeService;
    @Autowired
    private RemoteSupportService remoteSupportService;
    @Autowired
    private RpEventDataService rpEventDataService;
    @Autowired
    private RpFeatureAttemptService rpFeatureAttemptService;
    @Autowired
    private RpInfPvAttemptConfigService rpInfPvAttemptConfigService;
    @Autowired
    private RpSupplierTokenService rpSupplierTokenService;
    @Autowired
    private RpWorkflowApiDecisionService rpWorkflowApiDecisionService;
    @Autowired
    private SponsorApplicationMapService sponsorApplicationMapService;
    @Autowired
    private ReportUtilityService reportUtilityService;
    
    private static final String DATA_RESOURCE_STREAM_PATH = "/data.properties";
    
    @Override
    public Response configVerificationMethod(RemoteUtilityRequest remoteReq, String origin) {
    	String sponsorCode = "";
      	if (remoteReq.getSponsorCode() != null) {
     		sponsorCode = remoteReq.getSponsorCode();
     	}
     	
     	int lexisNexisOTPAllocation = remoteReq.getLexisNexisOTPAllocation() != null ? remoteReq.getLexisNexisOTPAllocation() : 0;
       	int equifaxSMFAAllocation = remoteReq.getEquifaxSMFAAllocation() != null? remoteReq.getEquifaxSMFAAllocation() : 0;
       	int equifaxIDFSAllocation = remoteReq.getEquifaxIDFSAllocation() != null? remoteReq.getEquifaxIDFSAllocation() : 0;
       	int experianCCAllocation = remoteReq.getExperianCCAllocation() != null? remoteReq.getExperianCCAllocation() : 0;
  
       	long sponsorId = 0L;
       	JSONObject pvResponseJSON = new JSONObject();
       	
      	RefSponsor refSponsor = null; 

       	if (sponsorCode != null) {   
       		refSponsor = findRefSponsor(sponsorCode);
	        sponsorId = refSponsor.getSponsorId();
        }

       	if (refSponsor == null) {
       		pvResponseJSON.put("responseMessage", "Sponsor not found.");
            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       	}
       	
       	int totalAlloc = lexisNexisOTPAllocation + equifaxSMFAAllocation + equifaxIDFSAllocation + experianCCAllocation; 
       	if (totalAlloc != 100) {
       		pvResponseJSON.put("responseMessage", "Total percentage allocations must 100%.");
            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       	}
       	
        try {
    		String attemptTableType = "All";
      		if (remoteReq.getAttemptTableToConfig() != null) {
       			if ("rp_kba_attempts".equalsIgnoreCase(remoteReq.getAttemptTableToConfig())) {
     				attemptTableType = "Main";
    			}
    			else if ("rp_inf_pv_attempts".equalsIgnoreCase(remoteReq.getAttemptTableToConfig())) {
     				attemptTableType = "Inf";
    			}
    		}
    				
    		if ("All".equalsIgnoreCase(attemptTableType) || "Main".equalsIgnoreCase(attemptTableType)) {
         		// Main/Home Configuration
    			updateAllMainOtpAttemptConfig(sponsorId, equifaxIDFSAllocation, lexisNexisOTPAllocation, equifaxSMFAAllocation, experianCCAllocation);
        	}
            
       		if ("All".equalsIgnoreCase(attemptTableType) || "Inf".equalsIgnoreCase(attemptTableType)) {
                // Individual-Not-Found Configuration
       			updateAllInfOtpAttemptConfig(sponsorId, equifaxIDFSAllocation, lexisNexisOTPAllocation, equifaxSMFAAllocation, experianCCAllocation);
       		}
           
      		if ("All".equalsIgnoreCase(attemptTableType) || "Main".equalsIgnoreCase(attemptTableType)) {
	        	// Main/Home Configuration Response
                List<RpOtpAttemptConfig> updatedConfigList = otpAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
	            for (RpOtpAttemptConfig config : updatedConfigList) {
	            	if (config.getId().getOtpSupplierId() == 3) {
	            		pvResponseJSON.put("equifaxIDFSAllocation", Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getOtpSupplierId() == 4) {
	            		pvResponseJSON.put("lexisNexisOTPAllocation", Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getOtpSupplierId() == 5) {
	            		pvResponseJSON.put("equifaxSMFAAllocation", Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getOtpSupplierId() == 6) {
	            		pvResponseJSON.put("experianCCAllocation", Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            }
      		}
       		else if ("Inf".equalsIgnoreCase(attemptTableType)) {
	        	// Individual-Not-Found Configuration Response
                List<RpInfPvAttemptConfig> updatedConfigList = rpInfPvAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
	            for (RpInfPvAttemptConfig config : updatedConfigList) {
	            	if (config.getId().getSupplierId() == 3) {
	            		pvResponseJSON.put("equifaxIDFSAllocation", Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getSupplierId() == 4) {
	            		pvResponseJSON.put("lexisNexisOTPAllocation", Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getSupplierId() == 5) {
	            		pvResponseJSON.put("equifaxSMFAAllocation", Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getSupplierId() == 6) {
	            		pvResponseJSON.put("experianCCAllocation", Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            }
      		}
            
            pvResponseJSON.remove("phoneVelocityWindow");
                  	
            pvResponseJSON.put("responseMessage", "Verification Method configuration was successfully updated.");
            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);

        } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INTERNAL_ERROR.getHttpResponseCode(), ErrorMessage.INTERNAL_ERROR.getMessage(), origin);
        }
    }
    
    public void updateAllMainOtpAttemptConfig(long sponsorId, int equifaxIDFSAllocation, int lexisNexisOTPAllocation, int equifaxSMFAAllocation, int experianCCAllocation) {
        List<RpOtpAttemptConfig> configList = otpAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
        for (RpOtpAttemptConfig config : configList) {
        	if (config.getId().getOtpSupplierId() == 3) {
        		config.setTotalAttempts(equifaxIDFSAllocation);
        		config.setAttempts(0);
        	}
        	else if (config.getId().getOtpSupplierId() == 4) {
        		config.setTotalAttempts(lexisNexisOTPAllocation);
        		config.setAttempts(0);
        	}
        	else if (config.getId().getOtpSupplierId() == 5) {
        		config.setTotalAttempts(equifaxSMFAAllocation);
        		config.setAttempts(0);
        	}
        	else if (config.getId().getOtpSupplierId() == 6) {
        		config.setTotalAttempts(experianCCAllocation);
        		config.setAttempts(0);
        	}

        	config.setModifyConfigurationUserid(RemoteSupportServiceImpl.USERID_IPS_OWN);
        	config.setModifyConfigurationTime(new Timestamp(new Date().getTime()));
        	config.setUpdateDate(new Timestamp(new Date().getTime()));
        }

        otpAttemptConfigService.adminUpdate(configList);
    }
    
    public void updateAllInfOtpAttemptConfig(long sponsorId, int equifaxIDFSAllocation, int lexisNexisOTPAllocation, int equifaxSMFAAllocation, int experianCCAllocation) {
         List<RpInfPvAttemptConfig> infConfigList = rpInfPvAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
        
        for (RpInfPvAttemptConfig config : infConfigList) {
        	if (config.getId().getSupplierId() == 3) {
        		config.setTotalAttempts(equifaxIDFSAllocation);
        		config.setAttempts(0);
        	}
        	else if (config.getId().getSupplierId() == 4) {
        		config.setTotalAttempts(lexisNexisOTPAllocation);
        		config.setAttempts(0);
        	}
        	else if (config.getId().getSupplierId() == 5) {
        		config.setTotalAttempts(equifaxSMFAAllocation);
        		config.setAttempts(0);
        	}
        	else if (config.getId().getSupplierId() == 6) {
        		config.setTotalAttempts(experianCCAllocation);
        		config.setAttempts(0);
        	}

        	config.setModifyConfigurationUserid(RemoteSupportServiceImpl.USERID_IPS_OWN);
        	config.setModifyConfigurationTime(new Timestamp(new Date().getTime()));
        	config.setUpdateDate(new Timestamp(new Date().getTime()));
        }

        rpInfPvAttemptConfigService.adminUpdate(infConfigList);
    }   
     
    @Override
    public Response retrieveSupplierConfig(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
 
    	String sponsorCode = "";
      	if (remoteReq.getSponsorCode() != null) {
     		sponsorCode = remoteReq.getSponsorCode();
     	}
   
       	String sponsorName = null;
       	long sponsorId = 0L;
       	RefSponsor refSponsor = null;
       	JSONObject pvResponseJSON = new JSONObject();

       	if (sponsorCode != null) {
	        if (RefSponsor.SPONSOR_CODE_OS.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_OPERATION_SANTA;
	        }
	        else if (RefSponsor.SPONSOR_CODE_COA.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_CHANGE_ADDRESS;
	        }
	        else if (RefSponsor.SPONSOR_CODE_CR.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_CUSTREG;
	        }
	        
	        refSponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = refSponsor.getSponsorId();
        }
       	
       	if (refSponsor == null) {
            pvResponseJSON.put("responseMessage", "Sponsor not found.");
            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       	}

        try {
    		String attemptTableType = "Main";
      		if (remoteReq.getAttemptTableToConfig() != null) {
       			if ("rp_kba_attempts".equalsIgnoreCase(remoteReq.getAttemptTableToConfig())) {
     				attemptTableType = "Main";
    			}
    			else if ("rp_inf_pv_attempts".equalsIgnoreCase(remoteReq.getAttemptTableToConfig())) {
     				attemptTableType = "Inf";
    			}
    		}
    				
    		if ("Main".equalsIgnoreCase(attemptTableType)) {
         		// Main/Home Configuration
                List<RpOtpAttemptConfig> configList = otpAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
                for (RpOtpAttemptConfig config : configList) {
                	int supplierId = (int) config.getId().getOtpSupplierId();
                	
                	switch(supplierId) {
                		case 3:  
                			pvResponseJSON.put("equifaxIDFSAllocation", (long) config.getTotalAttempts());
                			break;
                		case 4:
                			pvResponseJSON.put("equifaxIDFSAllocation", (long) config.getTotalAttempts());
                			break;
                		case 5:
                			pvResponseJSON.put("equifaxSMFAAllocation", (long) config.getTotalAttempts());
                			break;
                		case 6:
                			pvResponseJSON.put("experianCCAllocation", (long) config.getTotalAttempts());
                			break;
                		default:
                	}
                	
                	pvResponseJSON.put("attemptTableToConfig", "rp_kba_attempts");
                }
    		}
    		else if ("Inf".equalsIgnoreCase(attemptTableType)) {
                // Individual-Not-Found Configuration
                List<RpInfPvAttemptConfig> infConfigList = rpInfPvAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
 
                for (RpInfPvAttemptConfig config : infConfigList) {
                	if (config.getId().getSupplierId() == 3) {
                		pvResponseJSON.put("equifaxIDFSAllocation", (long) config.getTotalAttempts());
                	}
                	else if (config.getId().getSupplierId() == 4) {
                		pvResponseJSON.put("equifaxIDFSAllocation", (long) config.getTotalAttempts());
                	}
                	else if (config.getId().getSupplierId() == 5) {
                		pvResponseJSON.put("equifaxSMFAAllocation", (long) config.getTotalAttempts());
                 	}
                	else if (config.getId().getSupplierId() == 6) {
                		pvResponseJSON.put("experianCCAllocation", (long) config.getTotalAttempts());
                	}
                	
                	pvResponseJSON.put("attemptTableToConfig", "rp_inf_pv_attempts");
                }
       		}
                    	
            pvResponseJSON.put("responseMessage", "Supplier Traffic Allocation Config was successfully retrieved.");
            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);

        } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INTERNAL_ERROR.getHttpResponseCode(), ErrorMessage.INTERNAL_ERROR.getMessage(), origin);
        }
    }
     
    @Override
    public Response configPhoneVelocityWindow(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
 
    	int phoneVelocityWindow = remoteReq.getPhoneVelocityWindow();
     	String sponsorCode = remoteReq.getSponsorCode();
    
       	String sponsorName = null;
       	RefSponsor refSponsor = null;
       	JSONObject pvResponseJSON = new JSONObject();

       	if (sponsorCode != null) {
	        if (RemoteSupportServiceImpl.SPONSOR_CODE_CR.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RemoteSupportServiceImpl.SPONSOR_NAME_OS;
	        }
	        else if (RemoteSupportServiceImpl.SPONSOR_CODE_OS.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RemoteSupportServiceImpl.SPONSOR_NAME_OS;
	        }
	        else if (RemoteSupportServiceImpl.SPONSOR_CODE_COA.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RemoteSupportServiceImpl.SPONSOR_NAME_COA;
	        }
	        
	        refSponsor = refSponsorDataService.findBySponsorName(sponsorName);
        }
       	
       	if (refSponsor == null) {
            pvResponseJSON.put("responseMessage", "Sponsor not found.");
            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       	}
       	
       	if (phoneVelocityWindow < 0 || phoneVelocityWindow > 60 ) {
            pvResponseJSON.put("responseMessage", "Phone Velocity Window value must be from 0 to 60 minutes.");
            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       	}
       	
        RefSponsorConfiguration sponsorConfig = null;
        try {
  			sponsorConfig = refSponsorConfigService.getConfigRecord(
					(int) refSponsor.getSponsorId(), "Device.Assessment.Velocity.Timer");
 			sponsorConfig.setValue(String.valueOf(phoneVelocityWindow));
  			
 			refSponsorConfigService.update(sponsorConfig);
  
        } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INTERNAL_ERROR.getHttpResponseCode(), ErrorMessage.INTERNAL_ERROR.getMessage(), origin);
        }
        
        String timeValueStr = "";
        try {
        	RefSponsorConfiguration sponsorConfigMod = refSponsorConfigService.getConfigRecord(
					(int) refSponsor.getSponsorId(), "Device.Assessment.Velocity.Timer");
 			timeValueStr = sponsorConfigMod.getValue();
  
        } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INTERNAL_ERROR.getHttpResponseCode(), ErrorMessage.INTERNAL_ERROR.getMessage(), origin);
        }
        
     	pvResponseJSON.put("phoneVelocityWindow", Long.parseLong(timeValueStr));
       	pvResponseJSON.put("lexisNexisOTPAllocation", null);
     	pvResponseJSON.put("equifaxSMFAAllocation", null);
  
     	pvResponseJSON.put("responseMessage", "Phone Velocity Window configuration was successfully updated.");
        return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response createRefSponsorConfigurationForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
 
     	String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	RefSponsor refSponsor = null;
       	JSONObject pvResponseJSON = new JSONObject();

       	if (sponsorName != null) {
	        refSponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = refSponsor.getSponsorId();
        }
       	
       	if (refSponsor == null) {
            pvResponseJSON.put("responseMessage", "Sponsor not found.");
            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       	}

        try {
 	        refSponsorConfigService.createRefSponsorConfigurationForRemoteClient(sponsorId);	
        } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RefSponsorConfiguration For RemoteClient", origin);
        }
        
  
    	pvResponseJSON.put("responseMessage", String.format("RefSponsorConfiguration records for remote client sponsor %s were successfully created.", sponsorName));
    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response createRpOtpAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

     	String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	RefSponsor sponsor = null;
       	JSONObject pvResponseJSON = new JSONObject();

       	if (sponsorName != null) {
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = sponsor.getSponsorId();
        }
       	
        try {
        	if (sponsorId > 0) {
        		otpAttemptConfigService.createRpOtpAttemptConfigForRemoteClient(sponsorId);
        	}
        	else {
        		List<RefSponsor> refSponsorList = refSponsorDataService.getAllRemoteProofingClients();
        		for(RefSponsor refSponsor : refSponsorList) {
            		otpAttemptConfigService.createRpOtpAttemptConfigForRemoteClient(refSponsor.getSponsorId());
        		}
        	}
         } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpOtpAttemptConfig For RemoteClient", origin);
        }
        
    	pvResponseJSON.put("responseMessage", String.format("RpOtpAttemptConfig records for remote client sponsor %s were successfully created.", sponsorName));
    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response createRpInfPvAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

     	String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	RefSponsor sponsor = null;
       	JSONObject pvResponseJSON = new JSONObject();

       	if (sponsorName != null) {
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = sponsor.getSponsorId();
        }

        try {
        	if (sponsorId > 0) {
        		rpInfPvAttemptConfigService.createRpInfPvAttemptConfigForRemoteClient(sponsorId);
        	}
        	else {
        		List<RefSponsor> refSponsorList = refSponsorDataService.getAllRemoteProofingClients();
        		for(RefSponsor refSponsor : refSponsorList) {
        			rpInfPvAttemptConfigService.createRpInfPvAttemptConfigForRemoteClient(refSponsor.getSponsorId());
        		}
        	}
         	
         } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpOtpAttemptConfig For RemoteClient", origin);
        }
        
    	pvResponseJSON.put("responseMessage", String.format("RpInfPvAttemptConfig records for remote client sponsor %s were successfully created.", sponsorName));
    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response createRpFeatureAttemptForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
 
		String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	long appId = 0L;
       	RefSponsor refSponsor = null;
       	JSONObject pvResponseJSON = new JSONObject();


       	if (sponsorName != null) {
	        refSponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        
	        if (refSponsor == null) {
	            pvResponseJSON.put("responseMessage", "Sponsor not found.");
	            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
	       	}
	        
	        sponsorId = refSponsor.getSponsorId();
        }
       	else {
       		sponsorId = remoteReq.getSponsorId();
       		appId = remoteReq.getAppId();
       	}
        
        RefApp refApp = refAppService.findByAppId(appId);
        
        try {
        	rpFeatureAttemptService.createRpFeatureAttemptForRemoteClient(refSponsor, refApp);
          } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpFeatureAttempt For RemoteClient", origin);
        }
        
    	pvResponseJSON.put("responseMessage", String.format("RpFeatureAttempt records for remote client sponsor %s were successfully created.", sponsorName));
        return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response removeRefSponsorConfigurationForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
     	
		String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	RefSponsor refSponsor = null;
       	JSONObject pvResponseJSON = new JSONObject();

       	if (sponsorName != null) {
	        refSponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = refSponsor.getSponsorId();
        }
       	
       	if (refSponsor == null) {
            pvResponseJSON.put("responseMessage", "Sponsor not found.");
            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       	}

        try {
 	        refSponsorConfigService.removeRefSponsorConfigurationForRemoteClient(sponsorId);	
        } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RefSponsorConfiguration For RemoteClient", origin);
        }
        
       	pvResponseJSON.put("responseMessage", String.format("RefSponsorConfiguration records for remote client sponsor %s were successfully removed.", sponsorName));
        return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response removeRpFeatureAttemptForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

     	String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	long appId = 0L;
       	RefSponsor refSponsor = null;
       	JSONObject pvResponseJSON = new JSONObject();

       	if (sponsorName != null) {
	        refSponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        
	        if (refSponsor == null) {
	            pvResponseJSON.put("responseMessage", "Sponsor not found.");
	            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
	       	}
	        
	        sponsorId = refSponsor.getSponsorId();
        }
       	else {
       		sponsorId = remoteReq.getSponsorId();
       		appId = remoteReq.getAppId();
       	}
        
        try {
        	rpFeatureAttemptService.removeRpFeatureAttemptForRemoteClient(sponsorId, appId);
        } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpFeatureAttempt For RemoteClient", origin);
        }
          
       	pvResponseJSON.put("responseMessage", String.format("RpFeatureAttempt records for remote client sponsor %s were successfully removed.", sponsorName));
        return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response removeRpOtpAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

     	String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	RefSponsor refSponsor = null;
       	JSONObject pvResponseJSON = new JSONObject();

       	if (sponsorName != null) {
	        refSponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = refSponsor.getSponsorId();
        }
       	
       	if (refSponsor == null) {
            pvResponseJSON.put("responseMessage", "Sponsor not found.");
            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       	}
        
        try {
        	otpAttemptConfigService.removeRpOtpAttemptConfigForRemoteClient(sponsorId);
         } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpOtpAttemptConfig For RemoteClient", origin);
        }

       	pvResponseJSON.put("responseMessage", String.format("RpOtpAttemptConfig records for remote client sponsor %s were successfully removed.", sponsorName));
        return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response getModificationFingerprint(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	String sponsorCode = remoteReq.getSponsorCode();
        String sponsorName = "";

        if (sponsorCode != null) {
	        if (RemoteSupportServiceImpl.SPONSOR_CODE_OS.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RemoteSupportServiceImpl.SPONSOR_NAME_OS;
	        }
	        else if (RemoteSupportServiceImpl.SPONSOR_CODE_COA.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RemoteSupportServiceImpl.SPONSOR_NAME_COA;
	        }
        }
       	
     	JSONObject pvResponseJSON = new JSONObject();
     	
     	pvResponseJSON.put("sponsorName", sponsorName);
     	pvResponseJSON.put("remoteServicesFingerprint", RemoteSupportServiceImpl.REMOTE_SERVICES_MOD_FP);
     	pvResponseJSON.put("ivsPersistenceFingerprint", IPSConstants.IVSPERSISTENCE_MOD_FP);

    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response updatePersonProofingStatus(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
 
    	PersonProofingStatus personProofingStatus = null;
    	int personId = remoteReq.getPersonId();
    	int newProofingStatus = remoteReq.getProofingStatus();
    	int oldProofingStatus = 0;
    	
        try {
         	personProofingStatus = personProofingStatusService.getByPersonId(personId); 
        	oldProofingStatus = (int) personProofingStatus.getRefRpStatus().getStatusCode();
  
        	if (personProofingStatus != null) {
         		RefRpStatus refRpStatus = refRpStatusDataService.findById(Long.valueOf(newProofingStatus));
         		personProofingStatus.setRefRpStatus(refRpStatus);
        		personProofingStatusService.update(personProofingStatus);
          	}
        } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INTERNAL_ERROR.getHttpResponseCode(), ErrorMessage.INTERNAL_ERROR.getMessage(), origin);
        }
               
        JSONObject pvResponseJSON = new JSONObject();
       	String respMsg = String.format("ProofingStatus was successfully updated from %s to %s for personId %s.",
     			oldProofingStatus, newProofingStatus, personId);
     	pvResponseJSON.put("responseMessage", respMsg);
      	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response saveRpSupplierToken(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	RpSupplierToken entity = null;
    	boolean createNewRecord = false;
    	
    	if (remoteReq.getExperianTokenType() != null) {
    		entity = rpSupplierTokenService.findByTokenType(remoteReq.getExperianTokenType());
    		
    		if (entity == null) {
    			createNewRecord = true;
    			entity = new RpSupplierToken();	
    			entity.setTokenType(remoteReq.getExperianTokenType());
    			entity.setCreateDate(new Timestamp(new Date().getTime()));
    		}
     	}
    	else {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpSupplierToken.  ExperianTokenCode is null", origin);
    	}
     	
    	if (remoteReq.getExperianTokenCode() != null) {
    		entity.setTokenCode(remoteReq.getExperianTokenCode());
    	}
    	
    	if (remoteReq.getExperianAccessToken() != null) {
    		entity.setAccessToken(remoteReq.getExperianAccessToken());
    	}
    	
    	entity.setUpdateDate(new Timestamp(new Date().getTime()));
    	
    	if (createNewRecord) {
    		rpSupplierTokenService.save(entity);
    	}
    	else {
    		rpSupplierTokenService.update(entity);
     	}
    	
    	JSONObject pvResponseJSON = new JSONObject();
       	String respMsg = "RpSupplierToken record was successfully created.";
      	pvResponseJSON.put("responseMessage", respMsg);
    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response removeRpSupplierToken(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	RpSupplierToken entity = null;
    	JSONObject pvResponseJSON = new JSONObject();
       	String respMsg = "RpSupplierToken record was successfully removed.";
       	
    	if (remoteReq.getExperianTokenType() != null) {
    		entity = rpSupplierTokenService.findByTokenType(remoteReq.getExperianTokenType());
    		
    		if (entity != null) {
    			rpSupplierTokenService.delete(entity);
    		}
     	}
    	else {
    		respMsg = "RpSupplierToken record with token type of " + remoteReq.getExperianTokenType() + " was not found.";
    	}
 
      	pvResponseJSON.put("responseMessage", respMsg);
    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response saveRefSponsorConfiguration(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	RefSponsorConfiguration entity = null;
    	boolean createNewRecord = false;
    	String configName = remoteReq.getSponsorConfigName();
       	RefSponsor refSponsor = findRefSponsor(remoteReq.getSponsorCode());

    	if (configName != null && refSponsor != null) {
    		entity = refSponsorConfigService.getConfigRecord((int) refSponsor.getSponsorId(), configName);
    		
    		if (entity == null) {
    			createNewRecord = true;
    			entity = new RefSponsorConfiguration();	
    			entity.setSponsorId(1);
    			entity.setName(configName);
    			entity.setValue(remoteReq.getSponsorConfigValue());
    			entity.setCreateDate(new Timestamp(new Date().getTime()));
    		}
     	}
    	else {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RefSponsorConfiguration. SponsorConfigName is null", origin);
    	}
     	
    	if (remoteReq.getSponsorConfigValue() != null) {
    		entity.setValue(remoteReq.getSponsorConfigValue());
    	}

    	entity.setUpdateDate(new Timestamp(new Date().getTime()));
    	
    	if (createNewRecord) {
    	   	entity.setConfigurationId(refSponsorConfigService.getMostRecentConfigId() + 1);
    		refSponsorConfigService.create(entity);
    	}
    	else {
    		refSponsorConfigService.update(entity);
     	}
    	
    	JSONObject pvResponseJSON = new JSONObject();
        	String respMsg = String.format("RefSponsorConfiguration record with name %s was successfully created.", configName);
      	pvResponseJSON.put("responseMessage", respMsg);
    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response retrieveRefSponsorConfiguration(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	RefSponsorConfiguration entity = null;
     	String configName = remoteReq.getSponsorConfigName();
    	JSONObject pvResponseJSON = new JSONObject();
    	RefSponsor refSponsor = findRefSponsor(remoteReq.getSponsorCode());
 
    	if (configName != null && refSponsor != null) {
    		entity = refSponsorConfigService.getConfigRecord((int) refSponsor.getSponsorId(), configName);
    		Long count = refSponsorConfigService.getConfigRecordCount((int) refSponsor.getSponsorId(), configName);
    		if (count == 0L) {
    			count = null;
    		}
    		
    		if (entity != null) {
    			pvResponseJSON.put("configName", configName);
    			pvResponseJSON.put("configValue", entity.getValue());
    			pvResponseJSON.put("configCount", count);
     		}
    		else {
                return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "RefSponsorConfiguration was not found.", origin);
    		}
     	}
    	else {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in retrieving RefSponsorConfiguration. SponsorConfigName is null", origin);
    	}
       	
       	String respMsg = String.format("RefSponsorConfiguration record with name %s was successfully retrieved.", configName);
      	pvResponseJSON.put("responseMessage", respMsg);
    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }

    @Override
    public Response removeRefSponsorConfiguration(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	RefSponsorConfiguration entity = null;
     	String configName = remoteReq.getSponsorConfigName();
       	RefSponsor refSponsor = findRefSponsor(remoteReq.getSponsorCode());

    	if (configName != null && refSponsor != null) {
    		entity = refSponsorConfigService.getConfigRecord((int) refSponsor.getSponsorId(), configName);
    		
    		if (entity != null) {
    			refSponsorConfigService.delete(entity);
     		}
     	}
    	else {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RefSponsorConfiguration. SponsorConfigName is null", origin);
    	}
       	
    	JSONObject pvResponseJSON = new JSONObject();
       	String respMsg = String.format("RefSponsorConfiguration record with name %s was successfully removed.", configName);
      	pvResponseJSON.put("responseMessage", respMsg);
    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response obtainExperianWebToken(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	String webServiceURL = commonRestService.getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_CC_JWT_ENDPT);
		List<NameValueVo> headerList = new ArrayList<>();
		headerList.add(new NameValueVo(ExperianServiceImpl.HEADER_USER_DOMAIN_NAME, ExperianServiceImpl.HEADER_USER_DOMAIN_VALUE));
		headerList.add(new NameValueVo(ExperianServiceImpl.HEADER_CORRELATION_ID_NAME, ExperianServiceImpl.HEADER_CORRELATION_ID_VALUE));
		
		ExperianResultVo resultVo = new ExperianResultVo();
		resultVo.setJwtUserName(remoteReq.getExperianJwtUserId());
		resultVo.setJwtUserKey(remoteReq.getExperianJwtPasscode());

		JSONObject tokenResponseJsonObj = commonRestService.getJsonWebTokenResponse(webServiceURL, headerList, resultVo);
		
		if (tokenResponseJsonObj != null) {
			String accessToken = (String) tokenResponseJsonObj.get("access_token");
			
			JSONObject pvResponseJSON = new JSONObject();
	       	
	       	if (accessToken != null) {
	       		String respMsg = "Experian JWT Access Token was successfully obtained.";
	       		pvResponseJSON.put("responseMessage", respMsg);
	       		pvResponseJSON.put("experianJwtToken", accessToken);
	       	}
	       	else {
	            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in obtaining Experian JWT Access Token.", origin);
	       	}

	    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
		}
		else {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in obtaining Experian JWT Access Token.", origin);
		}
    }
    
    @Override
    public Response getHighRiskAddresses(RemoteRequest remoteReq, String origin) {
    	JSONObject pvResponseJSON = new JSONObject();
    	String respMsg = "HighRiskAddress was successfully retrieved.";
    	
    	try {
    		
    		List<HighRiskAddress> addressList = highRiskAddressService.getAllPrimary();
    		JSONArray addressJSONArray = new JSONArray();
    		int ctr = 0;
     		
    		for (HighRiskAddress addr : addressList) {
    	     	PersonVo personVo = new PersonVo();
    	     	personVo.setAddressLine1(addr.getAddress());
    	     	personVo.setAddressLine2(addr.getAddressLine2());
    	     	personVo.setCity(addr.getCity());
    	     	personVo.setStateProvince(addr.getState());
    	     	personVo.setPostalCode(addr.getZip());
    	     	
    	     	boolean isHighRiskAddress = false;
    	    	int addressHash = highRiskAddressService.calculateAddressHash(personVo);
    	    	
    	    	if (addressHash == addr.getAddressHash()) {
    	    		isHighRiskAddress = true;
    	    	}

      	     	if (isHighRiskAddress) {
	    			String addrStr = String.format("Address1:%s, Address2:%s, City:%s, State:%s, ZipCode:%s", addr.getAddress(), addr.getAddressLine2(),
	    					addr.getCity(), addr.getState(), addr.getZip());
	    			JSONObject addressJSON = new JSONObject();
	    			addressJSON.put("address",  addrStr);
	    			addressJSONArray.add(addressJSON); 
	    			ctr++;
      	     	}
    			
    			if(ctr > 9) {
    				break;  				
    			}
    		}
    		
    		pvResponseJSON.put("highRiskAddresses", addressJSONArray);
	    	
    	    RefSponsorConfiguration sponsorConfigMod = refSponsorConfigService.getConfigRecord(1, RefSponsorConfiguration.HIGH_RISK_ACTIVATION);
    	    String highRiskActivated = "True".equalsIgnoreCase(sponsorConfigMod.getValue()) ? "true" : "false";
    	    pvResponseJSON.put("highRiskActivated", highRiskActivated);
    	     
	   		pvResponseJSON.put("responseMessage", respMsg);
   			return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    	}
    	catch (Exception e) {
    		respMsg = "HighRiskAddress retrieval has failed. " + e.getMessage();
    		pvResponseJSON.put("responseMessage", respMsg);

    		return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
        }
    }

    @Override
    public Response updateHighRiskAddress(RemoteRequest remoteReq, String origin) {
       	JSONObject pvResponseJSON = new JSONObject();
    	String respMsg = "HighRiskAddress was successfully updated.";
 
    	try {
    		
	    	HighRiskAddress entity = highRiskAddressService.findHighRiskAddressByAddress(remoteReq.getStreetAddress1(), remoteReq.getCity(),
	    			remoteReq.getState(), remoteReq.getZipCode());
	    	if (entity != null) {
	    		RefHighRiskAddressType hrAddressType = highRiskAddressService.findRefHighRiskAddressTypeByTypeId(1L);
   			  	entity.setRefHighRiskAddressType(hrAddressType);
		     	entity.setRemoved("N");
	
	     		int dbAddressHash = highRiskAddressService.calculateAddressHash(entity);
	    		entity.setAddressHash(dbAddressHash);
	    		
	    		highRiskAddressService.update(entity);
	       		String dbAddress2 = entity.getAddressLine2() != null? entity.getAddressLine2() : "";
            		
          		respMsg = respMsg + String.format(" Address1:%s, Address2:%s, City:%s, State:%s, ZipCode:%s,"
          				+ " highRiskAddressType:%s, Removed:%s, AddressHash:%s", entity.getAddress(), dbAddress2,
          				entity.getCity(), entity.getState(), entity.getZip(), entity.getRefHighRiskAddressType().getDescription(),
          				entity.getRemoved(), entity.getAddressHash());
	    	}
	    	else {
	    	 	respMsg = "HighRiskAddress not found.";
	    	}
	    	
	      	pvResponseJSON.put("responseMessage", respMsg);
	    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    	}
    	catch (Exception e) {
     		respMsg = "HighRiskAddress retrieval has failed. " + e.getMessage();
    		pvResponseJSON.put("responseMessage", respMsg);
    		return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
        }
    }
     
    @Override
    public Response checkRegExForMatch(RemoteUtilityRequest remoteReq, String origin) {
       	JSONObject pvResponseJSON = new JSONObject();
 
    	if (remoteReq.getFieldValue().matches(remoteReq.getRegEx())) {
    		pvResponseJSON.put("responseMessage", "FieldValue was successfully validated. FieldValue matches with Regex.");	
    	}
    	else {
    		pvResponseJSON.put("responseMessage", "FieldValue is invalid. It does not match with Regex.");	   		
    	}
    	
        return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
    
    @Override
    public Response resetPersonProofingStatus(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	Date updateDate = new Timestamp(new Date().getTime());
    	Timestamp updateTime = new Timestamp(new Date().getTime());
    	 
    	int personId = remoteReq.getPersonId();

    	PersonProofingStatus personProofingStatus = personProofingStatusService.getByPersonId(personId);
    	RefRpStatus refRpStatus = refRpStatusDataService.findById(11L);
    	personProofingStatus.setRefRpStatus(refRpStatus);
    	personProofingStatus.setUpdateDate(updateDate);
    	personProofingStatusService.update(personProofingStatus);

    	Person person = personDataService.findByPK((long)personId);
    	RefLoaLevel refLoaLevel = refLoaLevelService.findByCode(0);
    	person.setAchievedLoaLevel(refLoaLevel);
    	person.setUpdateDate(updateDate);
    	personDataService.update(person);
    	
    	List<OtpLockoutInfo> otpLockoutInfoList = otpLockoutInfoService.findByPersonID(person);

    	for(OtpLockoutInfo info : otpLockoutInfoList) {
    		info.setLockoutExpiresDatetime(null);
    		info.setLockoutFlag("N");
    		info.setUpdateDate(updateTime);
    	}
    	
    	List<RpEvent> rpEventList = rpEventDataService.findEventByPersonId(personId);

        int attemptWindow =  200;
        Timestamp current = new Timestamp(new Date().getTime());
        Timestamp window = new Timestamp(DateTimeUtil.getDateMinusHours(current, attemptWindow).getTime());

    	for(RpEvent event : rpEventList) {
    		event.setCreateDate(window);
    		event.setUpdateDate(updateTime);
    	}
    	
    	JSONObject pvResponseJSON = new JSONObject();
 
       	String respMsg = String.format("PersonProofingStatus for person Id %s was successfully reset.", personId);
      	pvResponseJSON.put("responseMessage", respMsg);
      	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
    }
   
    private Response buildErrorpvResponseJSON(Integer status, String message, String origin) {
    	CustomLogger.enter(this.getClass());

        JSONObject resp = new JSONObject();
        resp.put("responseMessage", message);
        return buildErrorpvResponseJSON(status, resp, origin);
    }
    
    private Response buildErrorpvResponseJSON(Integer status, JSONObject pvResponseJSON, String origin) {
    	CustomLogger.enter(this.getClass());

        Response resp = Response.status(status).entity(pvResponseJSON).type(MediaType.APPLICATION_JSON).build();
        ResponseBuilder rb = Response.fromResponse(resp);
        rb.header(RemoteSupportServiceImpl.ACCESS_CTL_ALLOW_ORIGIN, origin);
        rb.header(RemoteSupportServiceImpl.ACCESS_CTL_ALLOW_HEADERS, RemoteSupportServiceImpl.CONTENT_TYPE_HEADER_VALUE);
        resp = rb.build();
        return resp;
    }
    
    private RefSponsor findRefSponsor(String sponsorCode) {
        RefSponsor sponsor = null;
        String sponsorName = "";
 
        if (sponsorCode != null) {
	        if (RefSponsor.SPONSOR_CODE_OS.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_OPERATION_SANTA;
	        }
	        else if (RefSponsor.SPONSOR_CODE_COA.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_CHANGE_ADDRESS;
	        }
	        else if (RefSponsor.SPONSOR_CODE_CR.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_CUSTREG;
	        }
	        
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        return sponsor;
        }
        
        return null;
    }
    
	public Response checkSponsorAppActivation(RemoteUtilityRequest remoteReq, String origin) {
	    try {
			JSONObject pvResponseJSON = buildCheckSponsorAppActivationResponse(remoteReq, origin);
				 
			if (pvResponseJSON == null) {
				pvResponseJSON = new JSONObject();
		       	String respMsg = "Selected Sponsor and Application are activated.";
		      	pvResponseJSON.put("responseMessage", respMsg);
			}

	    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       } catch (Exception e) {
    	   	String respMsg = "Exception occurred in checking Sponsor and Application Activation. " +  e.getMessage();
    	   	JSONObject pvResponseJSON = new JSONObject();
   			pvResponseJSON.put("responseMessage", respMsg);
   			return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);       
   		}
	}
	
    public JSONObject buildCheckSponsorAppActivationResponse(RemoteUtilityRequest remoteReq, String origin) {
     	HashMap<String, InputValidationError> validationErrorMap = new HashMap<>();
		ErrorMessage errorMessage = null;
		InputValidationError inputValidationError = null;
 		String fieldName = RemoteProofingValidatedField.FIELD_SPONSOR_CODE;
 		String sponsorCode = remoteReq.getSponsorCode();
 		boolean hasSponsorAppInputError = false;
 		SponsorApplicationMap map = null;
 		
 		if (RefSponsor.SPONSOR_CODE_CR.equalsIgnoreCase(sponsorCode.toUpperCase())) {
 			remoteReq.setSponsorName(RefSponsor.SPONSOR_CUSTREG);
	    }
 		else {
 			hasSponsorAppInputError = true;
 		}
 		
 		if (hasSponsorAppInputError) {
			errorMessage = ErrorMessage.INVALID_CODE;
       		inputValidationError =  RemoteSupportServiceImpl.getInputValidationError(fieldName, sponsorCode, errorMessage.getFormattedErrorMessage("Sponsor", sponsorCode));   	
    	    validationErrorMap.put(fieldName, inputValidationError);
	    }

    	fieldName = RemoteProofingValidatedField.FIELD_APP_CODE;
    
 		Map<String, String> appCodeNameMap = remoteSupportService.getAppCodeNameMap();
		String appCode = remoteReq.getAppCode();
		String appName = appCodeNameMap.get(appCode.toUpperCase());
		
		if (appName != null) {
			remoteReq.setAppName(appName);
		}
		else {
			errorMessage = ErrorMessage.INVALID_CODE;
       		inputValidationError = RemoteSupportServiceImpl.getInputValidationError(fieldName, appCode, errorMessage.getFormattedErrorMessage("Application", appCode));   	
    	    validationErrorMap.put(fieldName, inputValidationError);
      		hasSponsorAppInputError = true;
		}

    	if (!hasSponsorAppInputError) {
    		String sponsorName =  remoteReq.getSponsorName();
    		appName = remoteReq.getAppName();
    		RefSponsor refSponsor = null;
    		
    		
    		try {
    			refSponsor = refSponsorDataService.findBySponsorName(sponsorName);
    		}
    		catch (Exception e) {
    	        //Set to default:
    			sponsorName = RefSponsor.SPONSOR_CUSTREG; 
    			CustomLogger.info(this.getClass(), "Error occurred in obtaining sponsor for sponsorName:" + sponsorName);
    	    }
    		
	        if (refSponsor != null) {
	     	   	boolean hasSponsorDisabled = sponsorApplicationMapService.hasSponsorDisabled(refSponsor.getSponsorId(), 0L);
	    	   	if (hasSponsorDisabled) {
	 				errorMessage = ErrorMessage.SPONSOR_APP_DISABLED;
		       		inputValidationError = RemoteSupportServiceImpl.getInputValidationError(fieldName, remoteReq.getSponsorCode(), errorMessage.getFormattedErrorMessage("Sponsor"));   	
		    	    validationErrorMap.put(fieldName, inputValidationError);
		    	    hasSponsorAppInputError = true;
	    	   	}
	    	   	else {
	    	        RefApp refApp = refAppService.findByAppName(appName);
	    	        
	    	        if (refApp != null) {
	    	        	map = sponsorApplicationMapService.getRelationBySponsorAndApplication(refSponsor.getSponsorId(), refApp.getAppId());

	    	        	 if (map != null) {
	    	               	if (!map.isActive()) {
		    	             	errorMessage = ErrorMessage.SPONSOR_APP_DISABLED;
					       		inputValidationError = RemoteSupportServiceImpl.getInputValidationError(fieldName, remoteReq.getSponsorCode(), errorMessage.getFormattedErrorMessage("Sponsor"));   	
					    	    validationErrorMap.put(fieldName, inputValidationError);
					    	    hasSponsorAppInputError = true;
		    	             }
	    	               	else {
					       		inputValidationError = RemoteSupportServiceImpl.getInputValidationError(fieldName, remoteReq.getSponsorCode(), "Sponsor and Application map is active.");   	
					    	    validationErrorMap.put(fieldName, inputValidationError);
					    	    hasSponsorAppInputError = false;

	    	               	}
	    	            }
	    	        }
	    	   	}
	        }
    	}
    	
        if (!validationErrorMap.isEmpty()) {
      		return buildCheckSponsorAppActivationErrorResponse(remoteReq, validationErrorMap, map, fieldName, origin, hasSponsorAppInputError);
        }
        
        return null;     
    }
	
	public JSONObject buildCheckSponsorAppActivationErrorResponse(RemoteUtilityRequest remoteReq, HashMap<String, InputValidationError> validationErrorMap, 
    		SponsorApplicationMap map, String fieldName, String origin, boolean hasSponsorAppInputError) {
		JSONArray validationErrorJSONArray = new JSONArray();
		JSONObject errorResponseJson = new JSONObject();
		String sponsorName = "";
		String applicationName = "";
		String activationDate = "";
		String deactivationDate = "";
		String updateDate = "";
		
		if (map != null) {
			sponsorName = map.getSponsor().getSponsorName();
			applicationName = map.getApp().getAppName();
			activationDate = map.getActivationDate().toString();
			deactivationDate = map.getDeactivationDate().toString();
			updateDate = map.getUpdateDate().toString();
		}
		
		if (hasSponsorAppInputError) {
	    	for (Map.Entry<String, InputValidationError> entry : validationErrorMap.entrySet()) {
	            InputValidationError validationError = entry.getValue();
	
	            JSONObject validationErrorJson = new JSONObject();
	            validationErrorJson.put("fieldName", validationError.getFieldName());
	            validationErrorJson.put("fieldValue", validationError.getFieldValue());
	            validationErrorJson.put("errorMessage", validationError.getErrorMessage());
	            validationErrorJSONArray.add(validationErrorJson);
	        }
	    	
	    	JSONObject statusJson = new JSONObject();
	    	statusJson.put("reference", "IVS_Transaction");
	    	statusJson.put("transactionStatus", "failed");
	    	
	    	JSONObject reasonCodeJSON = new JSONObject();
	    	reasonCodeJSON.put("description", "Input Validation Error");
	    	reasonCodeJSON.put("code", "input_validation_error");
	       
	    	statusJson.put("transactionReasonCode", reasonCodeJSON);
	    	statusJson.put("inputValidationErrors", validationErrorJSONArray);
	 
	    	errorResponseJson.put("sponsorName", sponsorName);
			errorResponseJson.put("applicationName", applicationName);
			errorResponseJson.put("activationDate", activationDate);
			errorResponseJson.put("deactivationDate", deactivationDate);
			errorResponseJson.put("updateDate", updateDate);
			
	    	errorResponseJson.put("status", statusJson);
		} else {
			errorResponseJson.put("sponsorName", sponsorName);
			errorResponseJson.put("applicationName", applicationName);
			errorResponseJson.put("activationDate", activationDate);
			errorResponseJson.put("deactivationDate", deactivationDate);
			errorResponseJson.put("updateDate", updateDate);
		}

      	return errorResponseJson;
    }
	
    public Response retrieveWorkflowApiTypes(JSONObject requestJson, String origin) {
	    try {
			JSONObject pvResponseJSON = new JSONObject(); 
			List<RefWorkflowApiType> refWorkflowApiTypeList =  (List<RefWorkflowApiType>) refWorkflowApiTypeService.getAll();
			JSONArray recordJSONArray = new JSONArray();
			
			for (RefWorkflowApiType type : refWorkflowApiTypeList) {
				JSONObject detailJSON = new JSONObject();
				detailJSON.put("apiTypeId", type.getApiTypeId());
				detailJSON.put("apiTypeCode", type.getApiTypeCode());
				detailJSON.put("apiTypeDescription", type.getApiTypeDescription());
				recordJSONArray.add(detailJSON);
			}
			
			pvResponseJSON.put("refWorkflowApiTypes", recordJSONArray);
		        
	    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       } catch (Exception e) {
    	   	String respMsg = "Exception occurred in retrieving WorkflowApiTypes table. " +  e.getMessage();
    	   	JSONObject pvResponseJSON = new JSONObject();
   			pvResponseJSON.put("responseMessage", respMsg);
   			return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);       
   		}
	}
    
    public Response updateWorkflowApiTypes(JSONObject requestJson, String origin) {
	    try {
			JSONObject pvResponseJSON = new JSONObject(); 		 
			JSONArray recordJSONArray = (JSONArray) requestJson.get("refWorkflowApiTypes");
				
			for (int i = 0; i < recordJSONArray.size(); i++) {
                 JSONObject recordDetail = (JSONObject) recordJSONArray.get(i);
                 long apiTypeId = (long) recordDetail.get("apiTypeId");
                 String apiTypeCode = (String) recordDetail.get("apiTypeCode");
                 String apiTypeDescription = (String) recordDetail.get("apiTypeDescription");
                 
                 RefWorkflowApiType refWorkflowApiType =  refWorkflowApiTypeService.findApiTypeId(apiTypeId);
                 if (refWorkflowApiType != null) {
                	 refWorkflowApiType.setApiTypeCode(apiTypeCode);
                	 refWorkflowApiType.setApiTypeDescription(apiTypeDescription);
                	 refWorkflowApiType.setUpdateDate(new Timestamp(new Date().getTime()));
                	 refWorkflowApiTypeService.update(refWorkflowApiType);
                 }
                 else {
                	 refWorkflowApiType = new RefWorkflowApiType();
                	 refWorkflowApiType.setApiTypeCode(apiTypeCode);
                	 refWorkflowApiType.setApiTypeDescription(apiTypeDescription);
                	 refWorkflowApiType.setCreateDate(new Timestamp(new Date().getTime()));
                	 refWorkflowApiTypeService.create(refWorkflowApiType);
                 }
			}

			pvResponseJSON.put("responseMessage", "Updating WorkflowApiTypes table was successful!. ");
		        
	    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       } catch (Exception e) {
    	   	String respMsg = "Exception occurred in updating WorkflowApiTypes table. " +  e.getMessage();
    	   	JSONObject pvResponseJSON = new JSONObject();
   			pvResponseJSON.put("responseMessage", respMsg);
   			return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);       
   		}
	}
    
    public Response retrieveRefApp(JSONObject requestJson, String origin) {
	    try {
			JSONObject pvResponseJSON = new JSONObject(); 
			List<RefApp> appList =  refAppService.list();
			JSONArray recordJSONArray = new JSONArray();
			
			for (RefApp app : appList) {
				JSONObject detailJSON = new JSONObject();
				detailJSON.put("appId", app.getAppId());
				detailJSON.put("appName", app.getAppName());
				detailJSON.put("customerCategoryId", app.getCustomerCategoryId());
				detailJSON.put("workflowApiCodes", app.getWorkflowApiCodes());
				
				recordJSONArray.add(detailJSON);
			}
			
			pvResponseJSON.put("refApp", recordJSONArray);
		        
	    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       } catch (Exception e) {
    	   	String respMsg = "Exception occurred in retrieving RefApp table. " +  e.getMessage();
    	   	JSONObject pvResponseJSON = new JSONObject();
   			pvResponseJSON.put("responseMessage", respMsg);
   			return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);       
   		}
	}
    
    public Response updateRefApp(JSONObject requestJson, String origin) {
	    try {
			JSONObject pvResponseJSON = new JSONObject(); 		 
			JSONArray recordJSONArray = (JSONArray) requestJson.get("refApp");

			for (int i = 0; i < recordJSONArray.size(); i++) {
                 JSONObject recordDetail = (JSONObject) recordJSONArray.get(i);
 
                 String appName = (String) recordDetail.get("appName");
                 long customerCategoryId = (long) recordDetail.get("customerCategoryId");
                 String workflowApiCodes = (String) recordDetail.get("workflowApiCodes");
                 
                  RefApp refApp =  refAppService.findByAppName(appName);
                  RefCustomerCategory refCustomerCategory = refCustomerCategoryService.findByCategoryId(customerCategoryId);
               
                 if (refApp != null) {
                 	 refApp.setRefCustomerCategory(refCustomerCategory);
                	 refApp.setWorkflowApiCodes(workflowApiCodes);
                	 refApp.setUpdateDate(new Timestamp(new Date().getTime()));
                	 refAppService.update(refApp);
                 }
			}
			pvResponseJSON.put("responseMessage", "Updating RefApp table with workflowApiCodes and customerCategoryId was successful!. ");

	    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       } catch (Exception e) {
    	   	String respMsg = "Exception occurred in updating RefApp table. " +  e.getMessage();
    	   	JSONObject pvResponseJSON = new JSONObject();
   			pvResponseJSON.put("responseMessage", respMsg);

   			return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);       
   		}
    }
    
    public Response createRefCustomerCategory(JSONObject requestJson, String origin) {
         try {
 			JSONObject pvResponseJSON = new JSONObject(); 		 
 			JSONArray recordJSONArray = (JSONArray) requestJson.get("refCustomerCategory");

 			for (int i = 0; i < recordJSONArray.size(); i++) {
                JSONObject recordDetail = (JSONObject) recordJSONArray.get(i);
                
	        	String categoryName = (String) recordDetail.get("categoryName"); 
	           	long categoryId =   (long) recordDetail.get("categoryId");
	           	
	           	RefCustomerCategory refCustomerCategory = refCustomerCategoryService.findByCategoryId(categoryId);
		
	           	if (refCustomerCategory == null) {
	           		refCustomerCategory = new RefCustomerCategory();
	           		refCustomerCategory.setCategoryName(categoryName);
	           		refCustomerCategory.setCustomerCategoryId(categoryId);
	           		refCustomerCategory.setUpdateDate(new Timestamp(new Date().getTime()));
	           		refCustomerCategoryService.create(refCustomerCategory);
	           		
	            }
 			}
 			
       	 	pvResponseJSON.put("responseMessage", "RefCustomerCategory records were successfully created.");

            return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);

        } catch (Exception e) {
            return buildErrorpvResponseJSON(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RefSponsorConfiguration For RemoteClient", origin);
        }
	}
    
    public Response getReportDataByEvent(JSONObject requestJson, String origin) {
    	requestJson.put("countType", "ByEvent");
    	return getReportData(requestJson, origin);	
	}
    
    public Response getReportDataByPerson(JSONObject requestJson, String origin) {
     	requestJson.put("countType", "ByPerson");
    	return getReportData(requestJson, origin);	
	}
	    
    private Response getReportData(JSONObject requestJson, String origin) {
	    try {
	    	String countType = (String) requestJson.get("countType");
	    	List<WorkflowApiDecisionVo> wkflowApiDecisionVoList = getWorkflowApiDecisionList(requestJson, origin);
			JSONObject remoteProofingJSON = new JSONObject();
			
			JSONObject individualJSON = getCustomerCategoryJSON(wkflowApiDecisionVoList, requestJson, RefCustomerCategory.CUSTOMER_CATEGORY_NAME_INDIVIDUAL, origin);
			remoteProofingJSON.put(RefCustomerCategory.CUSTOMER_CATEGORY_NAME_INDIVIDUAL, individualJSON);
			JSONObject businessJSON = getCustomerCategoryJSON(wkflowApiDecisionVoList, requestJson, RefCustomerCategory.CUSTOMER_CATEGORY_NAME_BUSINESS, origin);
			remoteProofingJSON.put(RefCustomerCategory.CUSTOMER_CATEGORY_NAME_BUSINESS, businessJSON);
			JSONObject pvResponseJSON = new JSONObject();
			pvResponseJSON.put("remoteProofing", remoteProofingJSON);
	    	
			return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       } catch (Exception e) {
     	   	String respMsg = "Exception occurred in updating RefApp table. " +  e.getMessage();
    	   	JSONObject pvResponseJSON = new JSONObject();
   			pvResponseJSON.put("responseMessage", respMsg);

   			return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);       
   	   }
    }
    
    public JSONObject getCustomerCategoryJSON(List<WorkflowApiDecisionVo> wkflowApiDecisionVoList, JSONObject requestJson, String categoryName, String origin) {
    	 try {
    	  	RefCustomerCategory customerCategory = refCustomerCategoryService.findByCategoryName(categoryName);
    		List<RefApp> appListByCustomerCategoryId = refAppService.getAppListByCustomerCategoryId(customerCategory.getCustomerCategoryId());
   	    	JSONObject customerCategoryJSON = new JSONObject();
			String countType = (String) requestJson.get("countType");

  	    	for (RefApp refApp : appListByCustomerCategoryId) {
       	    	if (requestJson.containsValue("appId")) {
       	    		requestJson.remove("appId");
       	    	}
       	    	
       	    	requestJson.put("appId", String.valueOf(refApp.getAppId()));
       	    	JSONObject customerCategoryDataJSON = null;

       	    	if (RefCustomerCategory.CUSTOMER_CATEGORY_NAME_INDIVIDUAL.equalsIgnoreCase(categoryName)) {
       	    		customerCategoryDataJSON = reportUtilityService.getIndividualAppReportJSON(wkflowApiDecisionVoList, requestJson, origin);
       	    	}
       	    	else if (RefCustomerCategory.CUSTOMER_CATEGORY_NAME_BUSINESS.equalsIgnoreCase(categoryName)) {
       	    		customerCategoryDataJSON = reportUtilityService.getBusinessAppReportJSON(wkflowApiDecisionVoList, requestJson, origin);
       	    	}

       	    	if (customerCategoryDataJSON != null) {
       	    		customerCategoryJSON.put(refApp.getAppName().replaceAll(" ",""), customerCategoryDataJSON);
       	    	}
       	    	else {
       	    		String respMsg = String.format("Exception occurred in getting JSON for %s transactions. CategoryName cannot be found.", categoryName);
       	     	   	JSONObject pvResponseJSON = new JSONObject();
       	    			pvResponseJSON.put("responseMessage", respMsg);

       	    		//return pvResponseJSON;    
       	    	}
    		}

 	    	return customerCategoryJSON;
        } catch (Exception e) {
     	   	String respMsg = String.format("Exception occurred in getting JSON for %s transactions. ", categoryName) +  e.getMessage();
     	   	JSONObject pvResponseJSON = new JSONObject();
    			pvResponseJSON.put("responseMessage", respMsg);

    		return pvResponseJSON;       
    	}
    }
    
    public List<WorkflowApiDecisionVo> getWorkflowApiDecisionList(JSONObject requestJson, String origin) {
    	List<WorkflowApiDecisionVo> voList = new ArrayList<>();

    	if (requestJson != null) {
       		String startDateTime = "";
      		String endDateTime = "";
       	
			if (requestJson.keySet() != null) {
	      		for (Object key : requestJson.keySet()) {
	      			if ("startDateTime".equalsIgnoreCase(key.toString())) {
	      				startDateTime = (String) requestJson.get(key);
	      				endDateTime = (String) requestJson.get(key);
	      			}
	      			else if ("endDateTime".equalsIgnoreCase(key.toString())) {
	      				endDateTime = (String) requestJson.get(key);
	      			}
	      		}
      		}
      		
			String countType = (String) requestJson.get("countType");
			  
      	   	voList = rpWorkflowApiDecisionService.getWorkflowApiDecisionList(startDateTime, endDateTime, countType);
     	}
   	   	
       	return voList;
    }
    
    public Response updateRpWorkflowApiDecision(JSONObject requestJson, String origin) {

	    try {
	    	
	        String env = Utils.getEnvironmentWithoutDot();
	        
    	   	JSONObject pvResponseJSON = new JSONObject();

	        if (!"PROD".equalsIgnoreCase(env)) {
	        	pvResponseJSON = reportUtilityService.updateRpWorkflowApiDecision(requestJson, origin);
	        } else {
	        	String respMsg = "This API must be only called in lower environments!";
	        	pvResponseJSON.put("responseMessage", respMsg);
	        }

	    	return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);
       } catch (Exception e) {
    	   	String respMsg = "Exception occurred in updating RpWorkflowApiDecision table. " +  e.getMessage();
    	   	JSONObject pvResponseJSON = new JSONObject();
   			pvResponseJSON.put("responseMessage", respMsg);

   			return remoteSupportService.buildPVResponse(null, pvResponseJSON, origin);       
   	   }
    }
    
    @Override
    public String getPropertyValue(String propertyName) {
        CustomLogger.enter(this.getClass());
        
        String propertyValue = null;
        try {
            Properties prop = getProperties();
            propertyValue = prop.getProperty(propertyName);
         } 
        catch (Exception ex) {        
            CustomLogger.error(this.getClass(), "Could not load data.properties",ex);        
        } 
        
        return propertyValue;
    }
    
    private Properties getProperties() {
        CustomLogger.enter(this.getClass());
        
        InputStream input = null;
        Properties prop = new Properties();

        try {
            input = CommonRestServiceImpl.class.getClassLoader().getResourceAsStream(DATA_RESOURCE_STREAM_PATH);
            // load a properties file
            prop.load(input); 
        } 
        catch (Exception ex) {    
            CustomLogger.error(this.getClass(), "Could not load ips.properties",ex);        
        } 
        
        return prop;
    }
     
}
