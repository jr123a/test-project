package com.ips.service;

import java.util.List;

import com.ibm.json.java.JSONObject;
import com.ips.persistence.common.WorkflowApiDecisionVo;


public interface ReportUtilityService {
    
	JSONObject getIndividualAppReportJSON(List<WorkflowApiDecisionVo> wkflowApiDecisionVoList, JSONObject requestJson, String origin);
	JSONObject getBusinessAppReportJSON(List<WorkflowApiDecisionVo> wkflowApiDecisionVoList, JSONObject requestJson, String origin);
	JSONObject updateRpWorkflowApiDecision(JSONObject requestJson, String origin);
}
