package com.ips.service;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ips.common.common.DateTimeUtil;
import com.ips.entity.RefApp;
import com.ips.entity.RpEvent;
import com.ips.entity.RpWorkflowApiDecision;
import com.ips.persistence.common.ReportBusinessDataVo;
import com.ips.persistence.common.ReportIndividualDataVo;
import com.ips.persistence.common.WorkflowApiDecisionVo;
import com.ips.proofing.CommonRestService;

@Service("reportUtilityService")
@Transactional
public class ReportUtilityServiceImpl implements Serializable, ReportUtilityService {
    private final static long serialVersionUID = 1L;
    
    @Autowired
    private RpWorkflowApiDecisionService rpWorkflowApiDecisionService;
    @Autowired
    private RpEventDataService rpEventDataService;
      
    public JSONObject getIndividualAppReportJSON(List<WorkflowApiDecisionVo> wkflowApiDecisionVoList, JSONObject requestJson, String origin) {
	    try {
	    	ReportIndividualDataVo reportDataVo = new ReportIndividualDataVo();
	    	reportDataVo.loadData(wkflowApiDecisionVoList);
	    	
	    	String appIdStr = (String) requestJson.get("appId"); 

	    	//highRiskAddr
	    	JSONObject highRiskAdddrReviewJSON = new JSONObject();
	    	highRiskAdddrReviewJSON.put("ApiResult", reportDataVo.getHighRiskAddrDataJSONObject("highRiskAddrReview", appIdStr));
	    	highRiskAdddrReviewJSON.put("Error", reportDataVo.getHighRiskAddrDataJSONObject("highRiskAddrError", appIdStr));
	    	highRiskAdddrReviewJSON.put("TotalReview", reportDataVo.getHighRiskAddrDataJSONObject("highRiskAddrTotalReview", appIdStr));
	    	JSONObject highRiskAddrFailJSON = new JSONObject();
	    	highRiskAddrFailJSON.put("Fail", reportDataVo.getHighRiskAddrDataJSONObject("highRiskAddrFail", appIdStr));
	    	JSONObject highRiskAddrJSON = new JSONObject();
	    	highRiskAddrJSON.put("Review", highRiskAdddrReviewJSON);
	    	highRiskAddrJSON.put("Fail", highRiskAddrFailJSON);
	    	highRiskAddrJSON.put("Total", reportDataVo.getHighRiskAddrDataJSONObject("highRiskAddrTotal", appIdStr));
	    	//tmxDevRep
	       	JSONObject tmxDevRepPassJSON = new JSONObject();
	       	tmxDevRepPassJSON.put("APIResult", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepInitPass", appIdStr));
	       	tmxDevRepPassJSON.put("PreviousResult", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepRepeatPass", appIdStr));
	       	tmxDevRepPassJSON.put("TotalPass", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepTotalPass", appIdStr));
	       	
	      	JSONObject tmxDevRepReviewJSON = new JSONObject();
	      	tmxDevRepReviewJSON.put("APIResult", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepInitReview", appIdStr));
	      	tmxDevRepReviewJSON.put("PreviousResult", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepRepeatReview", appIdStr));
	      	tmxDevRepReviewJSON.put("IndNotFound", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepIndNotFound", appIdStr));
	      	tmxDevRepReviewJSON.put("ProfilingDisabled", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepProfilingDisabled", appIdStr));
	      	tmxDevRepReviewJSON.put("Error", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepError", appIdStr));
	      	tmxDevRepReviewJSON.put("TotalReview", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepTotalReview", appIdStr));
	      	
	       	JSONObject tmxDevRepFailJSON = new JSONObject();
	       	tmxDevRepFailJSON.put("APIResult", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepInitFail", appIdStr));
	       	tmxDevRepFailJSON.put("PreviousResult", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepRepeatFail", appIdStr));
	       	tmxDevRepFailJSON.put("TotalFail", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepTotalFail", appIdStr));
	    	
	       	JSONObject tmxDevRepJSON = new JSONObject();
	    	tmxDevRepJSON.put("Pass", tmxDevRepPassJSON);
	    	tmxDevRepJSON.put("Review", tmxDevRepReviewJSON);
	    	tmxDevRepJSON.put("Fail", tmxDevRepFailJSON);
	    	tmxDevRepJSON.put("Total", reportDataVo.getTmxDevRepDataJSONObject("tmxDevRepTotal", appIdStr));

	    	//pvLexisNexis
	     	JSONObject pvLexisNexisReviewJSON = new JSONObject();
	     	pvLexisNexisReviewJSON.put("APIResult", reportDataVo.getPvLexisNexisDataJSONObject("pvLexisNexisInitReview", appIdStr));
	     	pvLexisNexisReviewJSON.put("PreviousResult", reportDataVo.getPvLexisNexisDataJSONObject("pvLexisNexisRepeatReview", appIdStr));
	     	pvLexisNexisReviewJSON.put("TotalReview", reportDataVo.getPvLexisNexisDataJSONObject("pvLexisNexisTotalReview", appIdStr));
	     	
	     	JSONObject pvLexisNexisFailJSON = new JSONObject();
	     	pvLexisNexisFailJSON.put("APIResult", reportDataVo.getPvLexisNexisDataJSONObject("pvLexisNexisInitFail", appIdStr));
	     	pvLexisNexisFailJSON.put("PreviousResult", reportDataVo.getPvLexisNexisDataJSONObject("pvLexisNexisRepeatFail", appIdStr));
	     	pvLexisNexisFailJSON.put("Abandoned", reportDataVo.getPvLexisNexisDataJSONObject("pvLexisNexisAbandoned", appIdStr));
	     	pvLexisNexisFailJSON.put("Error", reportDataVo.getPvLexisNexisDataJSONObject("pvLexisNexisError", appIdStr));
	     	pvLexisNexisFailJSON.put("TotalFail", reportDataVo.getPvLexisNexisDataJSONObject("pvLexisNexisTotalFail", appIdStr));
	     	
	    	JSONObject pvLexisNexisJSON = new JSONObject();
	    	pvLexisNexisJSON.put("Review", pvLexisNexisReviewJSON);
	    	pvLexisNexisJSON.put("Fail", pvLexisNexisFailJSON);
	    	pvLexisNexisJSON.put("Total", reportDataVo.getPvLexisNexisDataJSONObject("pvLexisNexisTotal", appIdStr));

	    	//pvExperian
	     	JSONObject pvExperianPassJSON = new JSONObject();
	     	pvExperianPassJSON.put("APIResult", reportDataVo.getPvExperianDataJSONObject("pvExperianInitPass", appIdStr));
	     	pvExperianPassJSON.put("PreviousResult", reportDataVo.getPvExperianDataJSONObject("pvExperianRepeatPass", appIdStr));
	     	pvExperianPassJSON.put("TotalPass", reportDataVo.getPvExperianDataJSONObject("pvExperianTotalPass", appIdStr));

	     	JSONObject pvExperianReviewJSON = new JSONObject();
	     	pvExperianReviewJSON.put("APIResult", reportDataVo.getPvExperianDataJSONObject("pvExperianInitReview", appIdStr));
	     	pvExperianReviewJSON.put("PreviousResult", reportDataVo.getPvExperianDataJSONObject("pvExperianRepeatReview", appIdStr));
	     	pvExperianReviewJSON.put("TotalReview", reportDataVo.getPvExperianDataJSONObject("pvExperianTotalReview", appIdStr));
	 
	     	JSONObject pvExperianFailJSON = new JSONObject();
	     	pvExperianFailJSON.put("APIResult", reportDataVo.getPvExperianDataJSONObject("pvExperianInitFail", appIdStr));
	     	pvExperianFailJSON.put("PreviousResult", reportDataVo.getPvExperianDataJSONObject("pvExperianRepeatFail", appIdStr));
	     	pvExperianFailJSON.put("Abandoned", reportDataVo.getPvExperianDataJSONObject("pvExperianAbandoned", appIdStr));
	     	pvExperianFailJSON.put("Error", reportDataVo.getPvExperianDataJSONObject("pvExperianError", appIdStr));
	     	pvExperianFailJSON.put("TotalFail", reportDataVo.getPvExperianDataJSONObject("pvExperianTotalFail", appIdStr));
	     	
	    	JSONObject pvExperianJSON = new JSONObject();
	    	pvExperianJSON.put("Pass", pvExperianPassJSON);
	    	pvExperianJSON.put("Review", pvExperianReviewJSON);
	    	pvExperianJSON.put("Fail", pvExperianFailJSON);
	    	pvExperianJSON.put("Total", reportDataVo.getPvExperianDataJSONObject("pvExperianTotal", appIdStr));

	    	//pvEquifaxDit
	     	JSONObject pvEquifaxDitPassJSON = new JSONObject();
	     	pvEquifaxDitPassJSON.put("APIResult", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitInitPass", appIdStr));
	     	pvEquifaxDitPassJSON.put("PreviousResult", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitRepeatPass", appIdStr));
	     	pvEquifaxDitPassJSON.put("TotalPass", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitTotalPass", appIdStr));
	     	
	     	JSONObject pvEquifaxDitReviewJSON = new JSONObject();
	     	pvEquifaxDitReviewJSON.put("APIResult", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitInitReview", appIdStr));
	     	pvEquifaxDitReviewJSON.put("PreviousResult", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitRepeatReview", appIdStr));
	     	pvEquifaxDitReviewJSON.put("TotalReview", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitTotalReview", appIdStr));
	     	
	     	JSONObject pvEquifaxDitFailJSON = new JSONObject();
	     	pvEquifaxDitFailJSON.put("APIResult", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitInitFail", appIdStr));
	     	pvEquifaxDitFailJSON.put("PreviousResult", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitRepeatFail", appIdStr));
	     	pvEquifaxDitFailJSON.put("Abandoned", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitAbandoned", appIdStr));
	     	pvEquifaxDitFailJSON.put("Error", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitError", appIdStr));
	     	pvEquifaxDitFailJSON.put("TotalFail", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitTotalFail", appIdStr));
	     	
	       	JSONObject pvEquifaxDitJSON = new JSONObject();
	    	pvEquifaxDitJSON.put("Pass", pvEquifaxDitPassJSON);
	    	pvEquifaxDitJSON.put("Review", pvEquifaxDitReviewJSON);
	    	pvEquifaxDitJSON.put("Fail", pvEquifaxDitFailJSON);
	    	pvEquifaxDitJSON.put("Total", reportDataVo.getPvEquifaxDitDataJSONObject("pvEquifaxDitTotal", appIdStr));

	    	//otpLexisNexis
	     	JSONObject otpLexisNexisPassJSON = new JSONObject();
	     	otpLexisNexisPassJSON.put("APIResult", reportDataVo.getOtpLexisNexisDataJSONObject("otpLexisNexisPass", appIdStr));
		   
	     	JSONObject otpLexisNexisFailJSON = new JSONObject();
	     	otpLexisNexisFailJSON.put("APIResult", reportDataVo.getOtpLexisNexisDataJSONObject("otpLexisNexisFail", appIdStr));
	     	otpLexisNexisFailJSON.put("Abandoned", reportDataVo.getOtpLexisNexisDataJSONObject("otpLexisNexisAbandoned", appIdStr));
	     	otpLexisNexisFailJSON.put("Error", reportDataVo.getOtpLexisNexisDataJSONObject("otpLexisNexisError", appIdStr));
	     	otpLexisNexisFailJSON.put("TotalFail", reportDataVo.getOtpLexisNexisDataJSONObject("otpLexisNexisTotalFail", appIdStr));

	    	JSONObject otpLexisNexisJSON = new JSONObject();
	    	otpLexisNexisJSON.put("Pass", otpLexisNexisPassJSON);
	    	otpLexisNexisJSON.put("Fail", otpLexisNexisFailJSON);
	    	otpLexisNexisJSON.put("Total", reportDataVo.getOtpLexisNexisDataJSONObject("otpLexisNexisTotal", appIdStr));

	    	//otpExperian
	     	JSONObject otpExperianPassJSON = new JSONObject();
	     	otpExperianPassJSON.put("APIResult", reportDataVo.getOtpExperianDataJSONObject("otpExperianPass", appIdStr));

	     	JSONObject otpExperianFailJSON = new JSONObject();
	     	otpExperianFailJSON.put("APIResult", reportDataVo.getOtpExperianDataJSONObject("otpExperianFail", appIdStr));
	     	otpExperianFailJSON.put("Abandoned", reportDataVo.getOtpExperianDataJSONObject("otpExperianAbandoned", appIdStr));
	     	otpExperianFailJSON.put("Error", reportDataVo.getOtpExperianDataJSONObject("otpExperianError", appIdStr));
	     	otpExperianFailJSON.put("TotalFail", reportDataVo.getOtpExperianDataJSONObject("otpExperianTotalFail", appIdStr));
	     
	    	JSONObject otpExperianJSON = new JSONObject();
	    	otpExperianJSON.put("Pass", otpExperianPassJSON);
	    	otpExperianJSON.put("Fail", otpExperianFailJSON);
	    	otpExperianJSON.put("Total", reportDataVo.getOtpExperianDataJSONObject("otpExperianTotal", appIdStr));

	    	//mfaEquifax
	     	JSONObject mfaEquifaxPassJSON = new JSONObject();
	     	mfaEquifaxPassJSON.put("APIResult", reportDataVo.getMfaEquifaxDataJSONObject("mfaEquifaxPass", appIdStr));

	    	JSONObject mfaEquifaxFailJSON = new JSONObject();
	    	mfaEquifaxFailJSON.put("APIResult", reportDataVo.getMfaEquifaxDataJSONObject("mfaEquifaxFail", appIdStr));
	    	mfaEquifaxFailJSON.put("Abandoned", reportDataVo.getMfaEquifaxDataJSONObject("mfaEquifaxAbandoned", appIdStr));
	    	mfaEquifaxFailJSON.put("Error", reportDataVo.getMfaEquifaxDataJSONObject("mfaEquifaxError", appIdStr));
	    	mfaEquifaxFailJSON.put("TotalFail", reportDataVo.getMfaEquifaxDataJSONObject("mfaEquifaxTotalFail", appIdStr));
		    		    	
	    	JSONObject mfaEquifaxJSON = new JSONObject();
	    	mfaEquifaxJSON.put("Pass", mfaEquifaxPassJSON);
	    	mfaEquifaxJSON.put("Fail", mfaEquifaxFailJSON);
	    	mfaEquifaxJSON.put("Total", reportDataVo.getMfaEquifaxDataJSONObject("mfaEquifaxTotal", appIdStr));

	    	JSONObject phoneVerificationJSON = new JSONObject();
	    	phoneVerificationJSON.put("LexisNexis", pvLexisNexisJSON);
	    	phoneVerificationJSON.put("Experian", pvExperianJSON);
	    	phoneVerificationJSON.put("EquifaxDIT", pvEquifaxDitJSON);
		    
	    	JSONObject otpMfaValidationJSON = new JSONObject();
	    	otpMfaValidationJSON.put("LexisNexis", otpLexisNexisJSON);
	    	otpMfaValidationJSON.put("Experian", otpExperianJSON);
	    	otpMfaValidationJSON.put("EquifaxSMFA", mfaEquifaxJSON);
	 
	    	JSONObject appJSON = new JSONObject();
	    	appJSON.put("HighRiskAddress", highRiskAddrJSON);
	    	appJSON.put("TmxDeviceReputation", tmxDevRepJSON);
	    	appJSON.put("PhoneVerification", phoneVerificationJSON);
	    	appJSON.put("OtpMfaValidation", otpMfaValidationJSON);
	    	
	    	return appJSON;
       } catch (Exception e) {
    	   	String respMsg = ". " +  e.getMessage();
    	   	JSONObject pvResponseJSON = new JSONObject();
   			pvResponseJSON.put("responseMessage", respMsg);
   			return null;       
   	   }
    }
    
    public JSONObject getBusinessAppReportJSON(List<WorkflowApiDecisionVo> wkflowApiDecisionVoList, JSONObject requestJson, String origin) {
	    try {
	    	ReportBusinessDataVo reportDataVo = new ReportBusinessDataVo();
	    	reportDataVo.loadData(wkflowApiDecisionVoList);
	    	
	    	//deviceEmailRisk
	    	JSONObject deviceEmailRiskJSON = new JSONObject();
	    	deviceEmailRiskJSON.put("Pass", reportDataVo.getDeviceEmailRiskDataJSONObject("deviceEmailRiskPass"));
	    	deviceEmailRiskJSON.put("Fail", reportDataVo.getDeviceEmailRiskDataJSONObject("deviceEmailRiskFail"));
	    	deviceEmailRiskJSON.put("Error", reportDataVo.getDeviceEmailRiskDataJSONObject("deviceEmailRiskError"));
	    	deviceEmailRiskJSON.put("Total", reportDataVo.getDeviceEmailRiskDataJSONObject("deviceEmailRiskTotal"));
	    	
	    	//amsAddressCheck
	    	JSONObject amsAddressCheckJSON = new JSONObject();
	    	amsAddressCheckJSON.put("Pass", reportDataVo.getAmsAddressCheckDataJSONObject("amsAddressCheckPass"));
	    	amsAddressCheckJSON.put("Fail", reportDataVo.getAmsAddressCheckDataJSONObject("amsAddressCheckFail"));
	    	amsAddressCheckJSON.put("Error", reportDataVo.getAmsAddressCheckDataJSONObject("amsAddressCheckError"));
	    	amsAddressCheckJSON.put("Total", reportDataVo.getAmsAddressCheckDataJSONObject("amsAddressCheckTotal"));

	    	//businessInstantId
	    	JSONObject businessInstantIdJSON = new JSONObject();
	    	businessInstantIdJSON.put("Pass", reportDataVo.getBusinessInstantIdDataJSONObject("businessInstantIdPass"));
	    	businessInstantIdJSON.put("Fail", reportDataVo.getBusinessInstantIdDataJSONObject("businessInstantIdFail"));
	    	businessInstantIdJSON.put("Error", reportDataVo.getBusinessInstantIdDataJSONObject("businessInstantIdError"));
	    	businessInstantIdJSON.put("Total", reportDataVo.getBusinessInstantIdDataJSONObject("businessInstantIdTotal"));
	    	
	    	JSONObject appJSON = new JSONObject();
	    	appJSON.put("DeviceEmailRisk", deviceEmailRiskJSON);
	    	appJSON.put("AmsAddressCheck", amsAddressCheckJSON);
	    	appJSON.put("BusinessInstantId", businessInstantIdJSON);
	    	
	     	return appJSON;
	    } catch (Exception e) {
    	   	String respMsg = ". " +  e.getMessage();
    	   	JSONObject pvResponseJSON = new JSONObject();
   			pvResponseJSON.put("responseMessage", respMsg);
   			return null;       
   	   }
    }

    public JSONObject updateRpWorkflowApiDecision(JSONObject requestJson, String origin) {
   	    try {
			JSONObject pvResponseJSON = new JSONObject(); 		 
			
			Date endDate = new Timestamp(new Date().getTime());
			Date startDate = DateTimeUtil.getDateMinusDays(endDate, 6);

			String result =  "was successful";
			String respMsg = String.format("RpWorkflowApiDecision record %s!", result);
   	   		pvResponseJSON.put("responseMessage", respMsg);
  	   		
			return pvResponseJSON; 
   	 } catch (Exception e) {
   	   		String respMsg = "Exception occurred in updating RpWorkflowApiDecision table. " +  e.getMessage();
  	   		JSONObject pvResponseJSON = new JSONObject();
  	   		pvResponseJSON.put("responseMessage", respMsg);
 			return pvResponseJSON;       
 		}
    }
    
    private boolean executeUpdateQuery(long apiDecisionId, long eventId, long workflowAPiTypeId, String decision, String decisionSource) {
    	//1, 14961, 2, 'REVIEW', 'Review', sysdate, sysdate)
    	String nativeQuery = String.format("INSERT INTO IPS_OWN.RP_WORKFLOW_API_DECISION (API_DECISION_ID, EVENT_ID, WORKFLOW_API_TYPE_ID, DECISION, DECISION_SOURCE, CREATE_DATE, UPDATE_DATE) " 
    			+ " VALUES (%s, %s, %s, '%s', '%s', sysdate, sysdate) ", apiDecisionId, eventId, workflowAPiTypeId, decision, decisionSource);
    	
     	boolean success= rpWorkflowApiDecisionService.executeCreateNativeQuery(nativeQuery);
 
    	return success;
    }
	
    public JSONObject updateRpWorkflowApiDecisionx(JSONObject requestJson, String origin) {
   	    try {
			JSONObject pvResponseJSON = new JSONObject(); 		 
			
			Date endDate = new Timestamp(new Date().getTime());
			Date startDate = DateTimeUtil.getDateMinusDays(endDate, 6);
			List<RpEvent> eventList = rpEventDataService.getEventsInWindow(startDate, endDate);
			List<Long> apiTypeIdList = new ArrayList<>();
			apiTypeIdList.add(2L);  //hraMap
			apiTypeIdList.add(3L);  //tmxDevRepMap
			apiTypeIdList.add(4L);  //pvLexisNexisMap, pvExperianMap, pvEquifaxDitMap
			apiTypeIdList.add(5L);  //otpMfaMap
			apiTypeIdList.add(6L);  //otpMfaMap
			
			Map<String, String> hraMap = new LinkedHashMap<>();
			hraMap.put("Pass", "LowRisk,Error");
			hraMap.put("Fail", "HighRisk");
			
			Map<String, String> tmxDevRepMap = new LinkedHashMap<>();
			tmxDevRepMap.put("Pass", "InitPass,RepeatPass");
			tmxDevRepMap.put("Review", "InitReview,RepeatReview,IndNotFound,ProfilingDisabled,LnError,IvsError");
			tmxDevRepMap.put("Fail", "InitReject,RepeatReject");
			
			Map<String, String> pvLexisNexisMap = new LinkedHashMap<>();
			pvLexisNexisMap.put("Pass", "InitPass,RepeatPass");
			pvLexisNexisMap.put("Fail", "InitFail,RepeatFail,Abandoned,Error");

			Map<String, String> pvExperianMap = new LinkedHashMap<>();
			pvExperianMap.put("Approve", "InitApprove,RepeatApprove");
			pvExperianMap.put("Pass", "InitPass,RepeatPass");
			pvExperianMap.put("Fail", "InitFail,RepeatFail,Abandoned,Error");
			
			Map<String, String> pvEquifaxDitMap = new LinkedHashMap<>();
			pvEquifaxDitMap.put("Approve", "InitApprove,RepeatApprove");
			pvEquifaxDitMap.put("Pass", "InitReview,RepeatReview");
			pvEquifaxDitMap.put("Fail", "InitDeny,RepeatDeny,Abandoned,Error");
			
			Map<String, String> otpMfaMap = new LinkedHashMap<>();//
			otpMfaMap.put("Pass", "InitPass,RepeatPass");
			otpMfaMap.put("Fail", "Fail,Abandoned,Error");

			int ctr = 0;
			for (RpEvent event : eventList) {
				for (Long apiId : apiTypeIdList) {
					Set<Entry<String, String>> mapSet = null;
					if (apiId == 2L) { //High-Risk Address
						mapSet = hraMap.entrySet();
					}
				
					if (mapSet != null) {
						for (Map.Entry<String, String> entry : mapSet) {
						    String decision = entry.getKey();
						    String value = entry.getValue();
							String[] sourceArr = value.split(",");
	
							for (String source : sourceArr) {
								RpWorkflowApiDecision apiDecision = new RpWorkflowApiDecision();
								
								apiDecision.setRpEvent(event);
								apiDecision.setWorkflowApiTypeId(apiId);
								apiDecision.setDecision(decision);
								apiDecision.setDecisionSource(source);
								apiDecision.setCreateDate(new Timestamp(new Date().getTime()));
								rpWorkflowApiDecisionService.create(apiDecision);
							}
						}
					}
				}
				ctr ++;
				if (ctr == 2) {
					break;
				}
			}
			
			pvResponseJSON.put("responseMessage", "Updating RpWorkflowApiDecision table was successful!. ");
	    	return pvResponseJSON;
       } catch (Exception e) {
    	   	String respMsg = "Exception occurred in updating RpWorkflowApiDecision table. " +  e.getMessage();
    	   	JSONObject pvResponseJSON = new JSONObject();
   			pvResponseJSON.put("responseMessage", respMsg);
   			return pvResponseJSON;       
   		}
    }

}
