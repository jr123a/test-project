package com.ips.bean;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.entity.RefIAL2ConfirmationNotification;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.exception.IPSException;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;
import com.ips.service.RefIAL2ConfirmationNotificationService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;

@ManagedBean(name = "ial2confirmconfigbean")
@ViewScoped
public class IAL2ConfirmationConfigurationBean extends IPSAdminController {
	private static final long serialVersionUID = 1L;
	private List<RefSponsor> sponsorList;
	private List<RefIAL2ConfirmationNotification> notificationList;
	private Long selectedSponsor;
	private Long selectedNotificationType;
	private boolean isInitialized = false;
	private Map<String, Boolean> booleanPropertyMapping;

	private static final String MAP_KEY_DATABASEERROR = "databaseError";
	private static final String MAP_KEY_EMAILERROR = "emailError";
	private static final String MAP_KEY_SUCCESS = "success";
	private static final String MAP_KEY_CONFIRMCHANGE = "confirmChange";

	public void init() {
		if (!isInitialized) {
			buildMap();
			buildSponsorList();
			buildNotifList();
			selectedSponsor = sponsorList.isEmpty() ? null : sponsorList.get(0).getSponsorId();
			resetFields();
			isInitialized = true;
		}
	}

	public void confirmChange() {
		setSuccess(false);
		if (isConfirmChange()) {
			resetFields();
		} else {
			setConfirmChange(!isConfirmChange());
		}
	}

	/**
	 * Sets the new selected sponsor when the dropdown is changed
	 */
	public void selectSponsor() {
		resetFields();
	}

	public String getSelectedSponsorName() {
		return sponsorList.stream().filter(sponsor -> sponsor.getSponsorId() == selectedSponsor).findFirst()
				.orElse(new RefSponsor()).getSponsorName();
	}

	public void saveValues() {
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			RefSponsorConfigurationService refSponsorConfigService = webAppContext
					.getBean(RefSponsorConfigurationService.class);

			clearBooleanProperties();

			try {
				RefSponsorConfiguration ial2ConfNotifConfig = refSponsorConfigService.getConfigRecord(
						selectedSponsor.intValue(), RefSponsorConfiguration.IAL2_CONFIRMATION_NOTIFICATION);
				if (ial2ConfNotifConfig == null) {
					ial2ConfNotifConfig = new RefSponsorConfiguration();
					ial2ConfNotifConfig.setCreateDate(new Date());
					ial2ConfNotifConfig.setName(RefSponsorConfiguration.IAL2_CONFIRMATION_NOTIFICATION);
					ial2ConfNotifConfig.setSponsorId(selectedSponsor.intValue());
					ial2ConfNotifConfig.setValue(selectedNotificationType.toString());
					ial2ConfNotifConfig.setConfigurationId(refSponsorConfigService.getMostRecentConfigId() + 1);
					refSponsorConfigService.create(ial2ConfNotifConfig);
				} else {
					ial2ConfNotifConfig.setValue(selectedNotificationType.toString());
					ial2ConfNotifConfig.setUpdateDate(new Date());
					refSponsorConfigService.update(ial2ConfNotifConfig);
				}
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred updating config in database", e);
				setDatabaseError(true);
				return;
			}

			setSuccess(true);

			if (isSuccess()) {
				if (webAppContext != null) {
					AdminService adminService = (AdminService) webAppContext.getBean("AdminService",
							AdminServiceImpl.class);
					HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance()
							.getExternalContext().getRequest();
					RefSponsor sponsor = sponsorList.stream().filter(sp -> sp.getSponsorId() == selectedSponsor)
							.findFirst().orElse(new RefSponsor());
					String notifType = notificationList.stream()
							.filter(notif -> notif.getId() == selectedNotificationType).findFirst()
							.orElse(new RefIAL2ConfirmationNotification()).getNotificationType();

					try {
						adminService.ial2ConfirmationNotificationChange(
								(String) request.getSession().getAttribute("IVSToken"),
								new Timestamp(new Date().getTime()), sponsor, notifType);
					} catch (IPSException e) {
						CustomLogger.error(this.getClass(),
								"Exception occurred when sending API configuration notification change", e);
						setEmailError(true);
					}
				}
			} else {
				CustomLogger.error(this.getClass(),
						"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
				goToPage(SYSTEM_ERROR_PAGE);
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve refSponsorConfigService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void resetFields() {
		clearBooleanProperties();

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			RefSponsorConfigurationService refSponsorConfigService = webAppContext
					.getBean(RefSponsorConfigurationService.class);

			try {
				RefSponsorConfiguration ial2ConfirmationNotificationConfig = refSponsorConfigService.getConfigRecord(
						selectedSponsor.intValue(), RefSponsorConfiguration.IAL2_CONFIRMATION_NOTIFICATION);
				selectedNotificationType = ial2ConfirmationNotificationConfig != null
						? Long.valueOf(ial2ConfirmationNotificationConfig.getValue())
						: 1L;
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred retrieving database values", e);
				setDatabaseError(true);
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve refSponsorConfigService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/**
	 * Builds list of external agency IPP sponsor clients for dropdown
	 * 
	 * @return
	 */
	private void buildSponsorList() {
		sponsorList = new ArrayList<>();

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			RefSponsorDataService refSponsorDataService = (RefSponsorDataService) webAppContext
					.getBean("RefSponsorDataService");

			try {
				sponsorList = refSponsorDataService.getIAL2Sponsors("IAL2.required");
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred when building RefSponsor list", e);
				setDatabaseError(true);
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void buildNotifList() {
		notificationList = new ArrayList<>();

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			RefIAL2ConfirmationNotificationService confirmationNotifService = (RefIAL2ConfirmationNotificationService) webAppContext
					.getBean("refIAL2ConfirmationNotificationService");

			try {
				notificationList = confirmationNotifService.findAll();
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred when building notification list", e);
				setDatabaseError(true);
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/**
	 * Builds the map of booleans for use on web page
	 * 
	 * @return
	 */
	private void buildMap() {
		booleanPropertyMapping = new HashMap<>();
		booleanPropertyMapping.put(MAP_KEY_DATABASEERROR, false);
		booleanPropertyMapping.put(MAP_KEY_EMAILERROR, false);
		booleanPropertyMapping.put(MAP_KEY_SUCCESS, false);
		booleanPropertyMapping.put(MAP_KEY_CONFIRMCHANGE, false);
	}

	/**
	 * Resets boolean properties
	 */
	private void clearBooleanProperties() {
		setDatabaseError(false);
		setEmailError(false);
		setSuccess(false);
		setConfirmChange(false);
	}

	public boolean isDatabaseError() {
		return booleanPropertyMapping.get(MAP_KEY_DATABASEERROR);
	}

	public void setDatabaseError(boolean databaseError) {
		booleanPropertyMapping.replace(MAP_KEY_DATABASEERROR, databaseError);
	}

	public boolean isEmailError() {
		return booleanPropertyMapping.get(MAP_KEY_EMAILERROR);
	}

	public void setEmailError(boolean emailError) {
		booleanPropertyMapping.replace(MAP_KEY_EMAILERROR, emailError);
	}

	public boolean isSuccess() {
		return booleanPropertyMapping.get(MAP_KEY_SUCCESS);
	}

	public void setSuccess(boolean success) {
		booleanPropertyMapping.replace(MAP_KEY_SUCCESS, success);
	}

	public boolean isConfirmChange() {
		return booleanPropertyMapping.get(MAP_KEY_CONFIRMCHANGE);
	}

	public void setConfirmChange(boolean confirmChange) {
		booleanPropertyMapping.replace(MAP_KEY_CONFIRMCHANGE, confirmChange);
	}

	public List<RefSponsor> getSponsorList() {
		return sponsorList;
	}

	public void setSponsorList(List<RefSponsor> sponsorList) {
		this.sponsorList = sponsorList;
	}

	public List<RefIAL2ConfirmationNotification> getNotificationList() {
		return notificationList;
	}

	public void setNotificationList(List<RefIAL2ConfirmationNotification> notificationList) {
		this.notificationList = notificationList;
	}

	public Long getSelectedSponsor() {
		return selectedSponsor;
	}

	public void setSelectedSponsor(Long selectedSponsor) {
		this.selectedSponsor = selectedSponsor;
	}

	public Long getSelectedNotificationType() {
		return selectedNotificationType;
	}

	public void setSelectedNotificationType(Long selectedNotificationType) {
		this.selectedNotificationType = selectedNotificationType;
	}
}
