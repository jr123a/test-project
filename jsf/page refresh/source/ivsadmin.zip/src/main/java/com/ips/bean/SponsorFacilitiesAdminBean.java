package com.ips.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.Paginator;
import com.ips.common.common.SpringUtil;
import com.ips.entity.RefFacFacility;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.SponsorFacilities;
import com.ips.entity.SponsorFacilitiesPK;
import com.ips.service.AdminService;
import com.ips.service.RefFacFacilityService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;
import com.ips.service.SponsorFacilitiesService;

@ManagedBean(name = "sponsorFacilitiesAdmin")
@ViewScoped
public class SponsorFacilitiesAdminBean extends IPSAdminController implements Serializable {
	private static final String ADMIN_SERVICE = "AdminService";
	private static final long serialVersionUID = 1L;
	private Paginator activeFacilitiesPaginator;
	private List<RefFacFacility> facilityResults;
	private List<RefFacFacility> activeFacilitiesForSponsor;
	private List<RefSponsor> sponsorList;
	private Long selectedSponsor;
	private Map<String, Boolean> booleanPropertyMapping;
	private String searchCriteria;
	private String searchValue;
	private boolean sublistFacility = false;
	private boolean isInitialized = false;
	private boolean retainPII = false;
	private RefSponsorConfigurationService refSponsorConfigService;
	private RefFacFacilityService refFacFacilityService;
	private SponsorFacilitiesService sponsorFacilitiesService;
	private AdminService adminService;
	private RefSponsorDataService refSponsorDataService;
	private Map<Long, RefSponsorConfiguration> piiConfig = new HashMap<>();

	private static final String MAP_KEY_DATABASEERROR = "databaseError";
	private static final String MAP_KEY_EMAILERROR = "emailError";
	private static final String MAP_KEY_REMOVALSUCCESS = "removalSuccess";
	private static final String MAP_KEY_ADDSUCCESSS = "addSuccess";
	private static final String MAP_KEY_SEARCHFACILITIESFOUND = "searchFacilitiesFound";
	private static final String MAP_KEY_ACTIVEFACILITIESFOUND = "activeFacilitiesFound";
	private static final String MAP_KEY_FACILITYFLAGS = "facilityFlags";
	private static final String MAP_KEY_ACTIVECONFIRMCHANGE = "activeConfirmChange";
	private static final String MAP_KEY_REMOVECONFIRMCHANGE = "removeConfirmChange";
	private static final String MAP_KEY_FLAGCONFIRMCHANGE = "flagConfirmChange";
	private static final String MAP_KEY_FACILITIESFILTERED = "facilitiesFiltered";
	private static final String ATTRIBUTE_IVSTOKEN = "IVSToken";
	private static final String BEAN_SPONSORFACILITIESSERVICE = "sponsorFacilitiesService";
	private static final String BEAN_REFFACFACILITYSERVICE = "refFacFacilityService";
	private static final String BEAN_REFSPONSORDATASERVICE = "RefSponsorDataService";
	private static final String BEAN_REFSPONSORCONFIGSERVICE = "refSponsorConfigurationService";

	public void init() {
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			if (!isInitialized) {
				refFacFacilityService = (RefFacFacilityService) webAppContext.getBean(BEAN_REFFACFACILITYSERVICE);
				sponsorFacilitiesService = (SponsorFacilitiesService) webAppContext
						.getBean(BEAN_SPONSORFACILITIESSERVICE);
				refSponsorConfigService = (RefSponsorConfigurationService) webAppContext
						.getBean(BEAN_REFSPONSORCONFIGSERVICE);
				adminService = (AdminService) webAppContext.getBean(ADMIN_SERVICE);
				refSponsorDataService = (RefSponsorDataService) webAppContext.getBean(BEAN_REFSPONSORDATASERVICE);
				booleanPropertyMapping = buildMap();
				activeFacilitiesPaginator = new Paginator(this);
				activeFacilitiesPaginator.initPaginatorProperties();
				sponsorList = buildSponsorList();
				selectedSponsor = sponsorList.isEmpty() ? null : sponsorList.get(0).getSponsorId();
				sublistFacility = !sponsorList.isEmpty() && sponsorList.get(0).isClientUsingFacilitySublist();
				activeFacilitiesForSponsor = buildActiveFacilities();
				facilityResults = new ArrayList<>();
				retrieveRetainPIIConfig();
				RefSponsorConfiguration refSpConfig = piiConfig.get(selectedSponsor);
				setRetainPII(refSpConfig != null && "TRUE".equalsIgnoreCase(refSpConfig.getValue()));
				isInitialized = true;
				
			}
		} else {
			CustomLogger.error(this.getClass(), "Error: WebApplicationContext is null.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void retrieveRetainPIIConfig() {
		for (int i = 0; i < sponsorList.size(); i++) {
			piiConfig.put(sponsorList.get(i).getSponsorId(), refSponsorConfigService
					.getConfigRecord((int) sponsorList.get(i).getSponsorId(), RefSponsorConfiguration.PERSIST_ADDRESS));
		}
	}

	public void selectSponsor() {
		clearBooleanProperties();


		try {
			RefSponsor sponsor = refSponsorDataService.findByPK(getSelectedSponsor());
			setSelectedSponsor(sponsor.getSponsorId());
			setSublistFacility(sponsor.isClientUsingFacilitySublist());
			RefSponsorConfiguration refSpConfig = piiConfig.get(selectedSponsor);
			setRetainPII(refSpConfig != null && "TRUE".equalsIgnoreCase(refSpConfig.getValue()));
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred when selecting new sponsor", e);
			setDatabaseError(true);
		}

		setActiveFacilitiesForSponsor(buildActiveFacilities());
		findFacilities();
	}

	/**
	 * Builds list of external agency IPP sponsor clients for dropdown
	 * 
	 * @return
	 */
	private List<RefSponsor> buildSponsorList() {
		sponsorList = new ArrayList<>();

		try {
			sponsorList = refSponsorDataService.getAllExternalIppClients();
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred when building RefSponsor list", e);
		}

		return sponsorList;
	}

	/**
	 * Builds the map of booleans for use on web page
	 * 
	 * @return
	 */
	private Map<String, Boolean> buildMap() {
		booleanPropertyMapping = new HashMap<>();
		booleanPropertyMapping.put(MAP_KEY_DATABASEERROR, false);
		booleanPropertyMapping.put(MAP_KEY_EMAILERROR, false);
		booleanPropertyMapping.put(MAP_KEY_REMOVALSUCCESS, false);
		booleanPropertyMapping.put(MAP_KEY_ADDSUCCESSS, false);
		booleanPropertyMapping.put(MAP_KEY_SEARCHFACILITIESFOUND, false);
		booleanPropertyMapping.put(MAP_KEY_ACTIVEFACILITIESFOUND, false);
		booleanPropertyMapping.put(MAP_KEY_FACILITYFLAGS, false);
		booleanPropertyMapping.put(MAP_KEY_ACTIVECONFIRMCHANGE, false);
		booleanPropertyMapping.put(MAP_KEY_REMOVECONFIRMCHANGE, false);
		booleanPropertyMapping.put(MAP_KEY_FLAGCONFIRMCHANGE, false);
		booleanPropertyMapping.put(MAP_KEY_FACILITIESFILTERED, false);
		return booleanPropertyMapping;
	}

	/**
	 * Builds the list of active facilities for the selected sponsor
	 * 
	 * @return
	 */
	private List<RefFacFacility> buildActiveFacilities() {
		activeFacilitiesForSponsor = activeFacilitiesForSponsor == null ? new ArrayList<>() : Collections.emptyList();


		try {
			if (activeFacilitiesPaginator.isResetTotalCount()) {
				activeFacilitiesPaginator.updateTotalCount(
						sponsorFacilitiesService.getActiveFacilitiesCountBySponsorId(getSelectedSponsor()));
			}
			activeFacilitiesForSponsor = refFacFacilityService
					.getFacilitiesByIds(sponsorFacilitiesService.getActiveFacilitiesIdsBySponsorId(getSelectedSponsor(),
							activeFacilitiesPaginator.getFirstResult(), activeFacilitiesPaginator.getMaxResults()));
			activeFacilitiesForSponsor.forEach(fac -> fac.setActivationDate(sponsorFacilitiesService
					.getFacilityBySponsorIdAndFacilityId(getSelectedSponsor(), fac.getRefFacilityId())
					.getActivationDate()));
			activeFacilitiesPaginator.updateRowRange();
			setNoActiveFacilitiesFound(activeFacilitiesForSponsor.isEmpty());
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred when building active facilities for sponsor", e);
			setDatabaseError(true);
		}

		return activeFacilitiesForSponsor;
	}

	/**
	 * Returns the name of the current selected sponsor - used on web page
	 * 
	 * @return
	 */
	public String getSelectedSponsorName() {
		return getSponsorList().stream().filter(sponsor -> sponsor.getSponsorId() == getSelectedSponsor().longValue())
				.findFirst().orElse(new RefSponsor()).getSponsorName();
	}

	/**
	 * Searches for facilities based on the selected criteria and search value
	 */
	public void findFacilities() {
		clearBooleanProperties();

		setFacilityResults(Collections.emptyList());


		if (StringUtils.isNotBlank(getSearchCriteria())) {
			try {
				switch (Integer.valueOf(getSearchCriteria())) {
				case 1:
					RefFacFacility fac = refFacFacilityService.findByFinanceNumber(getSearchValue());
					if (fac != null) {
						setFacilityResults(new ArrayList<>(Arrays.asList(fac)));
					}
					break;
				case 2:
					setFacilityResults(refFacFacilityService.findByFacilityId(Long.valueOf(getSearchValue())));
					break;
				case 3:
					setFacilityResults(refFacFacilityService.findByFacilityName(getSearchValue().trim().toUpperCase()));
					break;
				case 4:
					setSearchValue(getSearchValue().toUpperCase());
					String city = getSearchValue().split(",")[0].trim();
					String state = getSearchValue().split(",")[1].trim();
					setFacilityResults(refFacFacilityService.findByCityState(city, state));
					break;
				case 5:
					setFacilityResults(new ArrayList<>(refFacFacilityService.findByZipCode(getSearchValue())));
					break;
				default:
					break;
				}
				setNoFacilitiesFound(getFacilityResults().isEmpty());
				if (!isNoFacilitiesFound() && !isNoActiveFacilitiesFound() && getFacilityResults() != null
						&& getActiveFacilitiesForSponsor() != null) {
					// get refFacFacilityId of active facilities (activeFacilitiesIds)
					// get original size of search results (originalFacilityResultsSize)
					// if activeFacilitiesIds does not contain the refFacFacilityId of a searched
					// facility, then keep it, else discard it (filteredFacilities)
					// if filteredFacilities.size() != originalFacilityResultsSize, then that means
					// the list was filtered
					List<Long> activeFacilitiesIds = getActiveFacilitiesForSponsor().stream()
							.filter(facility -> facility.isActive()).map(RefFacFacility::getRefFacilityId)
							.collect(Collectors.toList());
					List<RefFacFacility> filteredFacilities = getFacilityResults().stream()
							.filter(facility -> !activeFacilitiesIds.contains(facility.getRefFacilityId()))
							.collect(Collectors.toList());
					setFacilitiesFiltered(getFacilityResults().size() != filteredFacilities.size());
					setFacilityResults(filteredFacilities);
				}
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred when executing search", e);
				setDatabaseError(true);
			}
		}
	}

	/**
	 * Converts a RefFacFacility object to a SponsorFacilities object
	 * 
	 * @param facility
	 * @param isRemoved - used to set activation date for the facility to be active
	 *                  or not
	 * @return
	 */
	private SponsorFacilities refFacFacilityToSponsorFacilities(RefFacFacility facility, boolean isRemoved) {
		SponsorFacilities spFacility = new SponsorFacilities();
		spFacility.setActivationDate(
				isRemoved ? Date.from(LocalDate.of(2099, 12, 31).atStartOfDay(ZoneId.systemDefault()).toInstant())
						: facility.getActivationDate());
		SponsorFacilitiesPK spFacilityPK = new SponsorFacilitiesPK();
		spFacilityPK.setRefFacilityId(facility.getRefFacilityId());
		spFacilityPK.setSponsorId(getSelectedSponsor());
		spFacility.setId(spFacilityPK);
		return spFacility;
	}

	public void paginatorLoadTables() {
		setActiveFacilitiesForSponsor(buildActiveFacilities());
	}

	public void saveSponsorFlags() {
		clearBooleanProperties();

		RefSponsor sponsor = null;
		try {
			sponsor = refSponsorDataService.findByPK(getSelectedSponsor());
			sponsor.setFacilitySublist(isSublistFacility() ? "Y" : "N");
			sponsor.setUpdateDate(new Timestamp(new Date().getTime()));
			refSponsorDataService.update(sponsor);
			setFacilitiesFlags(true);
			handlePIIConfig();
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred when updating flags for sponsor", e);
			setDatabaseError(true);
		}
		if (isFacilityFlagsUpdated()) {
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();

			try {
				adminService.externalAgencyFlagsAdminNotification(
						(String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN),
						new Timestamp(new Date().getTime()), refSponsorDataService.findByPK(getSelectedSponsor()));
			} catch (Exception e) {
				CustomLogger.error(this.getClass(),
						"Exception occurred when trying to send admin flags notification email", e);
				setEmailError(true);
			}
		}
	}

	private void handlePIIConfig() {
		RefSponsorConfiguration refSponsorConfig = piiConfig.get(selectedSponsor);

		if (refSponsorConfig == null) {
			return;
		}

		if (!(String.valueOf(retainPII).equalsIgnoreCase(refSponsorConfig.getValue()))) {
			String newValue = StringUtils.capitalize(String.valueOf(retainPII));
			refSponsorConfig.setValue(newValue);
			refSponsorConfig.setUpdateDate(new Date());
			refSponsorConfigService.update(refSponsorConfig);
			piiConfig.replace(selectedSponsor, refSponsorConfig);

			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();

			try {
				adminService.retainPIINotification((String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN),
						refSponsorDataService.findByPK(getSelectedSponsor()), newValue);
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred creating admin notification for retain PII", e);
				setEmailError(true);
			}
		}
	}

	/**
	 * Adds new or previously existing facilities to the active list for the
	 * selected sponsor
	 */
	public void addFacilitiesToActive() {
		clearBooleanProperties();

		if (getFacilityResults() == null || getFacilityResults().isEmpty()) {
			return;
		}


		// filter the list for facilities that are selected
		// for each selected facility, first check if facility is already added to
		// table, if yes then update; else create new record
		getFacilityResults().stream().filter(facility -> facility.isSelected()).forEach(facility -> {
			try {
				if (sponsorFacilitiesService.getFacilityBySponsorIdAndFacilityId(getSelectedSponsor(),
						facility.getRefFacilityId()) != null) {
					sponsorFacilitiesService.update(refFacFacilityToSponsorFacilities(facility, false));
				} else {
					sponsorFacilitiesService.save(refFacFacilityToSponsorFacilities(facility, false));
				}

				setAddSuccess(true);
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred when adding facility to active", e);
				setDatabaseError(true);
				setAddSuccess(false);
			}
		});

		if (isAddSuccess()) {
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();

			try {
				adminService.externalAgencyFacilityAdminNotification(
						getFacilityResults().stream().filter(fac -> fac.isSelected()).collect(Collectors.toList()),
						(String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN),
						new Timestamp(new Date().getTime()), true,
						refSponsorDataService.findByPK(getSelectedSponsor()));
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred when trying to send admin notification email",
						e);
				setEmailError(true);
			}
		}

		// build the new list
		setActiveFacilitiesForSponsor(buildActiveFacilities());
		findFacilities();
	}

	/**
	 * Removes active facilities from the list for the selected sponsor
	 */
	public void removeActiveFacilities() {
		clearBooleanProperties();

		if (getActiveFacilitiesForSponsor() == null || getActiveFacilitiesForSponsor().isEmpty()) {
			return;
		}


		// filter the list for facilities that are selected
		getActiveFacilitiesForSponsor().stream().filter(facility -> facility.isSelected()).forEach(facility -> {
			try {
				sponsorFacilitiesService.update(refFacFacilityToSponsorFacilities(facility, true));
				setRemovalSuccess(true);
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred when removing facility from active", e);
				setDatabaseError(true);
				setRemovalSuccess(false);
			}
		});

		if (isRemovalSuccess()) {
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();

			try {
				adminService.externalAgencyFacilityAdminNotification(
						getActiveFacilitiesForSponsor().stream().filter(fac -> fac.isSelected()).collect(
								Collectors.toList()),
						(String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN),
						new Timestamp(new Date().getTime()), false,
						refSponsorDataService.findByPK(getSelectedSponsor()));
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred when trying to send admin notification email",
						e);
				setEmailError(true);
			}
		}

		// build the new list
		setActiveFacilitiesForSponsor(buildActiveFacilities());
		findFacilities();
	}

	public void confirmFlagChange() {
		setRemovalSuccess(false);
		setAddSuccess(false);
		setFacilitiesFlags(false);

		if (isConfirmFlagChange()) {

			try {
				RefSponsor sponsor = refSponsorDataService.findByPK(getSelectedSponsor());
				setSublistFacility(sponsor.isClientUsingFacilitySublist());
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred when trying to change flags", e);
				setDatabaseError(true);
			}
		}

		setConfirmFlagChange(!isConfirmFlagChange());
	}

	public void confirmAddFacilityChange() {
		setRemovalSuccess(false);
		setAddSuccess(false);
		setFacilitiesFlags(false);
		setConfirmAddFacilityChange(!isConfirmAddFacilityChange());
	}

	public void confirmRemoveFacilityChange() {
		setRemovalSuccess(false);
		setAddSuccess(false);
		setFacilitiesFlags(false);
		setConfirmRemoveFacilityChange(!isConfirmRemoveFacilityChange());
	}

	private void clearBooleanProperties() {
		setAddSuccess(false);
		setDatabaseError(false);
		setRemovalSuccess(false);
		setEmailError(false);
		setNoActiveFacilitiesFound(getActiveFacilitiesForSponsor().isEmpty());
		setFacilitiesFlags(false);
		setConfirmAddFacilityChange(false);
		setConfirmFlagChange(false);
		setConfirmRemoveFacilityChange(false);
		setFacilitiesFiltered(false);
	}

	public boolean isFacilitiesFiltered() {
		return getBooleanPropertyMapping().get(MAP_KEY_FACILITIESFILTERED);
	}

	public void setFacilitiesFiltered(boolean facilitiesFiltered) {
		getBooleanPropertyMapping().replace(MAP_KEY_FACILITIESFILTERED, facilitiesFiltered);
	}

	public boolean isDatabaseError() {
		return getBooleanPropertyMapping().get(MAP_KEY_DATABASEERROR);
	}

	public void setDatabaseError(boolean databaseError) {
		getBooleanPropertyMapping().replace(MAP_KEY_DATABASEERROR, databaseError);
	}

	public boolean isRemovalSuccess() {
		return getBooleanPropertyMapping().get(MAP_KEY_REMOVALSUCCESS);
	}

	public void setRemovalSuccess(boolean isRemovalSuccess) {
		getBooleanPropertyMapping().replace(MAP_KEY_REMOVALSUCCESS, isRemovalSuccess);
	}

	public boolean isAddSuccess() {
		return getBooleanPropertyMapping().get(MAP_KEY_ADDSUCCESSS);
	}

	public void setAddSuccess(boolean isAddSuccess) {
		getBooleanPropertyMapping().replace(MAP_KEY_ADDSUCCESSS, isAddSuccess);
	}

	public boolean isEmailError() {
		return getBooleanPropertyMapping().get(MAP_KEY_EMAILERROR);
	}

	public void setEmailError(boolean isEmailError) {
		getBooleanPropertyMapping().replace(MAP_KEY_EMAILERROR, isEmailError);
	}

	public boolean isNoFacilitiesFound() {
		return getBooleanPropertyMapping().get(MAP_KEY_SEARCHFACILITIESFOUND);
	}

	public void setNoFacilitiesFound(boolean searchFacilitiesFound) {
		getBooleanPropertyMapping().replace(MAP_KEY_SEARCHFACILITIESFOUND, searchFacilitiesFound);
	}

	public boolean isNoActiveFacilitiesFound() {
		return getBooleanPropertyMapping().get(MAP_KEY_ACTIVEFACILITIESFOUND);
	}

	public void setNoActiveFacilitiesFound(boolean activeFacilitiesFound) {
		getBooleanPropertyMapping().replace(MAP_KEY_ACTIVEFACILITIESFOUND, activeFacilitiesFound);
	}

	public boolean isFacilityFlagsUpdated() {
		return getBooleanPropertyMapping().get(MAP_KEY_FACILITYFLAGS);
	}

	public void setFacilitiesFlags(boolean facilityFlags) {
		getBooleanPropertyMapping().replace(MAP_KEY_FACILITYFLAGS, facilityFlags);
	}

	public boolean isConfirmFlagChange() {
		return getBooleanPropertyMapping().get(MAP_KEY_FLAGCONFIRMCHANGE);
	}

	public void setConfirmFlagChange(boolean flagConfirmChange) {
		getBooleanPropertyMapping().replace(MAP_KEY_FLAGCONFIRMCHANGE, flagConfirmChange);
	}

	public boolean isConfirmAddFacilityChange() {
		return getBooleanPropertyMapping().get(MAP_KEY_ACTIVECONFIRMCHANGE);
	}

	public void setConfirmAddFacilityChange(boolean activeConfirmChange) {
		getBooleanPropertyMapping().replace(MAP_KEY_ACTIVECONFIRMCHANGE, activeConfirmChange);
	}

	public boolean isConfirmRemoveFacilityChange() {
		return getBooleanPropertyMapping().get(MAP_KEY_REMOVECONFIRMCHANGE);
	}

	public void setConfirmRemoveFacilityChange(boolean removeConfirmChange) {
		getBooleanPropertyMapping().replace(MAP_KEY_REMOVECONFIRMCHANGE, removeConfirmChange);
	}

	public Long getSelectedSponsor() {
		return selectedSponsor;
	}

	public void setSelectedSponsor(Long selectedSponsor) {
		this.selectedSponsor = selectedSponsor;
	}

	public List<RefSponsor> getSponsorList() {
		return sponsorList;
	}

	public void setSponsorList(List<RefSponsor> sponsorList) {
		this.sponsorList = sponsorList;
	}

	public List<RefFacFacility> getActiveFacilitiesForSponsor() {
		return activeFacilitiesForSponsor;
	}

	public void setActiveFacilitiesForSponsor(List<RefFacFacility> activeFacilitiesForSponsor) {
		this.activeFacilitiesForSponsor = activeFacilitiesForSponsor;
	}

	private Map<String, Boolean> getBooleanPropertyMapping() {
		return booleanPropertyMapping;
	}

	public String getSearchCriteria() {
		return searchCriteria;
	}

	public void setSearchCriteria(String searchCriteria) {
		this.searchCriteria = searchCriteria;
	}

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	public List<RefFacFacility> getFacilityResults() {
		return facilityResults;
	}

	public Paginator getActiveFacilitiesPaginator() {
		return activeFacilitiesPaginator;
	}

	public void setActiveFacilitiesPaginator(Paginator activeFacilitiesPaginator) {
		this.activeFacilitiesPaginator = activeFacilitiesPaginator;
	}

	public void setFacilityResults(List<RefFacFacility> facilityResults) {
		this.facilityResults = facilityResults;
	}

	public boolean isSublistFacility() {
		return sublistFacility;
	}

	public void setSublistFacility(boolean sublistFacility) {
		this.sublistFacility = sublistFacility;
	}

	public boolean isRetainPII() {
		return retainPII;
	}

	public void setRetainPII(boolean retainPII) {
		this.retainPII = retainPII;
	}
}
