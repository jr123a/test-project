package com.ips.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.apache.commons.lang.StringUtils;
import org.springframework.mail.MailSendException;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.HoldmailAdminVo;
import com.ips.common.common.CustomLogger;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;

@ManagedBean(name = "holdmailAdminBean")
@ViewScoped
public class HoldmailWorkFlowAdminBean extends IPSAdminController implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String ADMIN_SERVICE = "AdminService";
	private String errorMsg;
	private String warnMsg;
	private String infoMsg;
	private boolean showInfoMsg;
	private boolean showWarnMsg;
	private boolean showErrorMsg;
	private List<HoldmailAdminVo> holdmailWorkflowsList = new ArrayList<>();
	private boolean initialized;
	private long selectedWorkflowId;
	private boolean disable = false;
	private boolean confirmChange = false;
	private static final String ORIGINAL_FLOW = "Original Flow Only allows Pass to hold mail";
	private static final String SPECIAL_FLOW = "Special Flow Everything allowed to hold mail";

	@PostConstruct
	public void init() {
		CustomLogger.enter(this.getClass());
		if (!initialized) {
			setInitialized(true);
			setNoMsg();
			setWorkFlows();
		}
		getWorkflowStatus();
	}

	private void setNoMsg() {
		CustomLogger.enter(this.getClass());

		setErrorMsg(StringUtils.EMPTY);
		setWarnMsg(StringUtils.EMPTY);
		setInfoMsg(StringUtils.EMPTY);

		setShowErrorMsg(false);
		setShowWarnMsg(false);
		setShowInfoMsg(false);
	}

	private void setWorkFlows() {

		HoldmailAdminVo hlo1 = new HoldmailAdminVo();
		hlo1.setKey(1);
		hlo1.setValue(ORIGINAL_FLOW);
		holdmailWorkflowsList.add(hlo1);
		HoldmailAdminVo hlo2 = new HoldmailAdminVo();
		hlo2.setKey(2);
		hlo2.setValue(SPECIAL_FLOW);
		holdmailWorkflowsList.add(hlo2);
		RefSponsorConfiguration codes = getWorkflowStatus();
		if (codes != null) {
			CustomLogger.info(this.getClass(), "Workflow value is not null: " + codes.getValue());
			String value = codes.getValue() != null ? codes.getValue() : "";
			if (!value.isEmpty()) {
				if ("True".equalsIgnoreCase(value)) {
					setSelectedWorkflowId(1L);
				} else {
					setSelectedWorkflowId(2L);
				}
			} else {
				setSelectedWorkflowId(0L);
			}
		}

	}

	private RefSponsorConfiguration getWorkflowStatus() {
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);

			RefSponsorConfiguration workFlowValue = adminService.getWorkflowStatus();
			CustomLogger.info(this.getClass(), "Workflow value for holdmail trigger: " + workFlowValue);

			return workFlowValue;
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
			return null;
		}
		
	}

	public void saveRecord() {
		CustomLogger.enter(this.getClass());
		setNoMsg();

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);
			RefSponsorConfiguration lookupCodes = getWorkflowStatus();
			if (lookupCodes != null) {
				CustomLogger.info(this.getClass(), "Saving holdmail value: " + lookupCodes.getValue());
				if (getSelectedWorkflowId() == 1L) {
					lookupCodes.setValue("True");
				} else if (getSelectedWorkflowId() == 2L) {
					lookupCodes.setValue("False");
				} else {
					lookupCodes.setValue("False");
				}
			}
			try {
				String lookupcodeValue = lookupCodes != null ? lookupCodes.getValue()
						: "lookupcodes entity is null while saving";
				CustomLogger.info(this.getClass(), "Holdmail save process: " + lookupcodeValue);
				if (lookupCodes != null) {
					lookupCodes.setUpdateDate(new Timestamp(new Date().getTime()));
					adminService.saveHoldmailWorkflow(lookupCodes);
					setInfoMsg("Workflow saved successfully.");
					setShowInfoMsg(true);
				}

			} catch (MailSendException m) {
				CustomLogger.error(this.getClass(), "Exception occured while sending mail");
				setErrorMsg("Error sending e-mail.");
				setShowErrorMsg(true);
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occured while saving holdmail flow");
				setErrorMsg("Error saving workflow.");
				setShowErrorMsg(true);
			} finally {
				setDisable(false);
				setConfirmChange(false);
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void change() {
		setNoMsg();
		setDisable(true);
		setConfirmChange(true);
		setInfoMsg("You are about to change the Holdmail Workflow. If this is correct, select Confirm below.");
		setShowInfoMsg(true);
	}

	public void cancel() {
		setDisable(false);
		setConfirmChange(false);
		setWorkFlows();
		setNoMsg();
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getWarnMsg() {
		return warnMsg;
	}

	public void setWarnMsg(String warnMsg) {
		this.warnMsg = warnMsg;
	}

	public String getInfoMsg() {
		return infoMsg;
	}

	public void setInfoMsg(String infoMsg) {
		this.infoMsg = infoMsg;
	}

	public boolean isShowInfoMsg() {
		return showInfoMsg;
	}

	public void setShowInfoMsg(boolean showInfoMsg) {
		this.showInfoMsg = showInfoMsg;
	}

	public boolean isShowWarnMsg() {
		return showWarnMsg;
	}

	public void setShowWarnMsg(boolean showWarnMsg) {
		this.showWarnMsg = showWarnMsg;
	}

	public boolean isShowErrorMsg() {
		return showErrorMsg;
	}

	public void setShowErrorMsg(boolean showErrorMsg) {
		this.showErrorMsg = showErrorMsg;
	}

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public long getSelectedWorkflowId() {
		return selectedWorkflowId;
	}

	public void setSelectedWorkflowId(long selectedWorkflowId) {
		this.selectedWorkflowId = selectedWorkflowId;
	}

	public List<HoldmailAdminVo> getHoldmailWorkflowsList() {
		return holdmailWorkflowsList;
	}

	public void setHoldmailWorkflowsList(List<HoldmailAdminVo> holdmailWorkflowsList) {
		this.holdmailWorkflowsList = holdmailWorkflowsList;
	}

	public boolean isConfirmChange() {
		return confirmChange;
	}

	public void setConfirmChange(boolean confirmChange) {
		this.confirmChange = confirmChange;
	}

	public boolean isDisable() {
		return disable;
	}

	public void setDisable(boolean disable) {
		this.disable = disable;
	}
}
