package com.ips.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.Utils;
import com.ips.entity.RefAdminEvent;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;

@ManagedBean(name = "LookupCodeEnvConfig")
@ViewScoped
public class LookupCodeEnvConfigurationBean extends IPSAdminController implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<String> equifaxStagingList;
	private List<NameUrlPair> lookupCodeList;
	private String selectedStagingEnv;
	private boolean showWarnMsg;
	private boolean showInfoMsg;
	private boolean showErrorMsg;
	private boolean showChangeBtn;
	private boolean showConfirmBtn;
	private boolean initialized;
	private String errorMsg;
	private String warnMsg;
	private String infoMsg;
	private String userId;
	private static final String ADMIN_SERVICE = "AdminService";
	private static final String URL_QUALIFIER_SANDBOX = "sandbox";
	private static final String URL_QUALIFIER_UAT = "uat";
	private static final String ENV_LABEL_SANDBOX = "Sandbox";
	private static final String ENV_LABEL_UAT = "UAT";
	private static final String NAME_EFX_VERIFY_STATE_ID = "Equifax.VERIFY_STATE_ID_URL";
	private static final String NAME_EFX_STATE_OAUTH = "Equifax.STATE_OAUTH_URL";
	private static final String URL_EFX_VERIFY_STATE_ID = "https://api.sandbox.equifax.com/business/state-id-verification/v1/states/{state}/id-cards/verify";
	private static final String URL_EFX_STATE_OAUTH = "https://api.sandbox.equifax.com/v1/oauth/token";
	private static final String STATE_ID_VERIFY_TYPE = "SIV";
	private static final String NAME_URL_FMT = "%s: %s";

	@PostConstruct
	public void init() {
		CustomLogger.enter(this.getClass());

		if (!initialized) {
			setInitialized(true);
			loadLookupCodeList();
			initMessage();
			initialBtnMessage();

			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();
			setUserId((String) request.getSession().getAttribute("IVSToken"));
		}
	}

	/*************************** Initialization Methods ***************************/

	public void loadLookupCodeList() {
		CustomLogger.enter(this.getClass());

		equifaxStagingList = new ArrayList<>();
		equifaxStagingList.add(ENV_LABEL_SANDBOX);
		equifaxStagingList.add(ENV_LABEL_UAT);

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);

			String verifyStateIdUrlValue = adminService.getLookupValue(NAME_EFX_VERIFY_STATE_ID);
			setSelectedStagingEnv(
					verifyStateIdUrlValue.toLowerCase().contains(URL_QUALIFIER_SANDBOX) ? ENV_LABEL_SANDBOX
							: ENV_LABEL_UAT);

			lookupCodeList = new ArrayList<>();
			NameUrlPair verifyStateIdPair = new NameUrlPair();
			verifyStateIdPair.setName(NAME_EFX_VERIFY_STATE_ID);
			verifyStateIdPair.setUrl(verifyStateIdUrlValue);
			lookupCodeList.add(verifyStateIdPair);

			String stateOauthUrlValue = adminService.getLookupValue(NAME_EFX_STATE_OAUTH);
			NameUrlPair stateOautPair = new NameUrlPair();
			stateOautPair.setName(NAME_EFX_STATE_OAUTH);
			stateOautPair.setUrl(stateOauthUrlValue);
			lookupCodeList.add(stateOautPair);
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void change() {
		CustomLogger.enter(this.getClass());

		initMessage();

		String env = Utils.getEnvironmentWithoutDot();

		if ("PROD".equalsIgnoreCase(env)) {
			setWarnMsg("You cannot change the Equifax Verify State ID and Oauth Token url for production.");
			setShowWarnMsg(true);
			return;
		}

		setInfoMsg("You are changing the configuration value. If this is correct, select Confirm below.");
		setShowInfoMsg(true);

		setShowChangeBtn(false);
		setShowConfirmBtn(true);
	}

	public void confirm() {
		CustomLogger.enter(this.getClass());

		initMessage();

		String env = Utils.getEnvironmentWithoutDot();

		if ("PROD".equalsIgnoreCase(env)) {
			setWarnMsg("You cannot change the Equifax Verify State ID and Oauth Token url for production.");
			setShowWarnMsg(true);
			return;
		}

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);

			String efxStateOauthUrl = URL_EFX_STATE_OAUTH;
			String efxVerifyStateIdUrl = URL_EFX_VERIFY_STATE_ID;

			if (ENV_LABEL_UAT.equalsIgnoreCase(selectedStagingEnv)) {
				efxStateOauthUrl = efxStateOauthUrl.replace(URL_QUALIFIER_SANDBOX, URL_QUALIFIER_UAT);
				efxVerifyStateIdUrl = efxVerifyStateIdUrl.replace(URL_QUALIFIER_SANDBOX, URL_QUALIFIER_UAT);
			} else if (URL_QUALIFIER_SANDBOX.equalsIgnoreCase(selectedStagingEnv)) {
				efxStateOauthUrl = efxStateOauthUrl.replace(URL_QUALIFIER_UAT, URL_QUALIFIER_SANDBOX);
				efxVerifyStateIdUrl = efxVerifyStateIdUrl.replace(URL_QUALIFIER_UAT, URL_QUALIFIER_SANDBOX);
			} else {
				return;
			}

			boolean updateStateOauthUrlSuccess = adminService.updateEnvValueByEnvironment(
					Utils.getEnvironmentWithoutDot().toUpperCase(), NAME_EFX_STATE_OAUTH, efxStateOauthUrl, userId);

			if (!updateStateOauthUrlSuccess) {
				setErrorMsg("Equifax State Oauth Url value was not updated. Database error has occurred!");
				setShowErrorMsg(true);
				return;
			}

			boolean updateVerifyStateIdUrlSuccess = adminService.updateEnvValueByEnvironment(
					Utils.getEnvironmentWithoutDot().toUpperCase(), NAME_EFX_VERIFY_STATE_ID, efxVerifyStateIdUrl,
					userId);

			if (!updateVerifyStateIdUrlSuccess) {
				setErrorMsg("Equifax Verify State Id Url value was not updated. Database error has occurred!");
				setShowErrorMsg(true);
				return;
			}

			// Force the vendorToken to expire so it will not retrieve the previous one
			Date targetDate = DateTimeUtil.getCurrentDate();
			Date currDateMinusHour = DateTimeUtil.getDateMinusHours(targetDate, 1);
			Timestamp expirationTime = new Timestamp(currDateMinusHour.getTime());
			boolean updateVendorTokenSuccess = adminService.updateVendorTokenByType(STATE_ID_VERIFY_TYPE,
					expirationTime);

			if (!updateVendorTokenSuccess) {
				setErrorMsg("Error occurred in updating VendorToken expirationTime. Database error has occurred!");
				setShowErrorMsg(true);
				return;
			}

			setInfoMsg("Configurations were successfully updated!");
			setShowInfoMsg(true);
			setShowChangeBtn(true);
			setShowConfirmBtn(false);

			loadLookupCodeList();

			String adminEventDescription = RefAdminEvent.ADMIN_IAL2_VENDOR_CONFIGURATION_URL;
			List<String> newValueList = new ArrayList<>();
			newValueList.add(String.format(NAME_URL_FMT, NAME_EFX_VERIFY_STATE_ID, efxVerifyStateIdUrl));
			newValueList.add(String.format(NAME_URL_FMT, NAME_EFX_STATE_OAUTH, efxStateOauthUrl));

			adminService.sendTextEmailOnLookupCodeChange(newValueList, adminEventDescription, userId);
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void cancel() {
		CustomLogger.enter(this.getClass());

		loadLookupCodeList();
		initialBtnMessage();
	}

	private void initMessage() {
		CustomLogger.enter(this.getClass());

		setShowErrorMsg(false);
		setShowWarnMsg(false);
		setShowInfoMsg(false);
	}

	private void initialBtnMessage() {
		CustomLogger.enter(this.getClass());

		setInfoMsg("Select Equifax Verify State ID staging environment.");
		setShowInfoMsg(true);

		setShowChangeBtn(true);
		setShowConfirmBtn(false);
	}

	/*************************** Inner Classs ***************************/

	public class NameUrlPair {

		private String name;
		private String url;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getUrl() {
			return url;
		}

		public void setUrl(String url) {
			this.url = url;
		}
	}

	/*************************** Private Methods ***************************/

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public String getInfoMsg() {
		return infoMsg;
	}

	public void setInfoMsg(String infoMsg) {
		this.infoMsg = infoMsg;
	}

	public String getWarnMsg() {
		return warnMsg;
	}

	public void setWarnMsg(String warnMsg) {
		this.warnMsg = warnMsg;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public boolean isShowInfoMsg() {
		return showInfoMsg;
	}

	public void setShowInfoMsg(boolean showInfoMsg) {
		this.showInfoMsg = showInfoMsg;
	}

	public boolean isShowWarnMsg() {
		return showWarnMsg;
	}

	public void setShowWarnMsg(boolean showWarnMsg) {
		this.showWarnMsg = showWarnMsg;
	}

	public boolean isShowErrorMsg() {
		return showErrorMsg;
	}

	public void setShowErrorMsg(boolean showErrorMsg) {
		this.showErrorMsg = showErrorMsg;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSelectedStagingEnv() {
		return selectedStagingEnv;
	}

	public void setSelectedStagingEnv(String selectedStagingEnv) {
		this.selectedStagingEnv = selectedStagingEnv;
	}

	public List<String> getEquifaxStagingList() {
		return equifaxStagingList;
	}

	public void setEquifaxStagingList(List<String> equifaxStagingList) {
		this.equifaxStagingList = equifaxStagingList;
	}

	public boolean isShowChangeBtn() {
		return showChangeBtn;
	}

	public void setShowChangeBtn(boolean showChangeBtn) {
		this.showChangeBtn = showChangeBtn;
	}

	public boolean isShowConfirmBtn() {
		return showConfirmBtn;
	}

	public void setShowConfirmBtn(boolean showConfirmBtn) {
		this.showConfirmBtn = showConfirmBtn;
	}

	public List<NameUrlPair> getLookupCodeList() {
		return lookupCodeList;
	}

	public void setLookupCodeList(List<NameUrlPair> lookupCodeList) {
		this.lookupCodeList = lookupCodeList;
	}

}
