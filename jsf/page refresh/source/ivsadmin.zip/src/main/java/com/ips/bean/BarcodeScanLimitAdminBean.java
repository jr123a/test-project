package com.ips.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.mail.MailSendException;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;

@ManagedBean(name = "barcodeScan")
@ViewScoped
public class BarcodeScanLimitAdminBean extends IPSAdminController implements Serializable {
    private static final long serialVersionUID = 1L;
    private boolean initialized;
    private boolean showInfoMsg;
    private boolean showWarnMsg;
    private boolean showErrorMsg;
    private boolean showInitialBtn;
    private boolean showConfirmChangeBtn;
    private String userId;
    private String errorMsg;
    private String warnMsg;
    private String infoMsg;
    private String selectedLimitScanInd;
    private List<RefSponsor> sponsorList;
    private long selectedSponsorId = 0L;
    private String scanLimit;
    AdminService adminService;
    private boolean disableLimitScan = true;
    private boolean disableScanLimit = true;
    private static final String ADMIN_SERVICE = "AdminService";

    @PostConstruct
    public void init() {
        CustomLogger.enter(this.getClass());
        if (!initialized) {
            ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
            WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
            if (webAppContext != null) {
    		adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);
    		} else {
                CustomLogger.error(this.getClass(), "Error: WebApplicationContext is null. Unable to retrieve AdminService.");
                goToPage(SYSTEM_ERROR_PAGE);
            }
            setInitialized(true);
            

        }
        loadSponsorList();
        CustomLogger.debug(this.getClass(), "selectedLimitScanInd: " + selectedLimitScanInd);
        CustomLogger.debug(this.getClass(), "scanLimit: " + scanLimit);
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                .getRequest();
        setUserId((String) request.getSession().getAttribute("IVSToken"));

    }

    /*************************** Initialization Methods ***************************/

    private void loadSponsorList() {
        CustomLogger.enter(this.getClass());

        try {
            sponsorList = adminService.getSponsorList();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in loadSponsorList: ", e);
            goToPage(SYSTEM_ERROR_PAGE);
        }

        if (selectedSponsorId == 0) {
            manageFormPanelDisplay("InitLoad");
        }

    }

    public void sponsorControls() {
        CustomLogger.enter(this.getClass());
        CustomLogger.enter(this.getClass(), "selectedId: " + selectedSponsorId);
        setNoMsg();
        if (selectedSponsorId != 0) {
            setDisableLimitScan(false);
            int sponsorIdInt = Integer.parseInt(String.valueOf(selectedSponsorId));
            RefSponsorConfiguration limitScanIndicator = adminService.getRefSponsorConfiguration(sponsorIdInt,
                    RefSponsorConfiguration.LIMIT_IPP_SCANS);
            RefSponsorConfiguration scanLimitNum = adminService.getRefSponsorConfiguration(sponsorIdInt,
                    RefSponsorConfiguration.IPP_SCAN_LIMIT);
            CustomLogger.debug(this.getClass(),
                    limitScanIndicator != null ? limitScanIndicator.getValue() : "The limitScanIndicaotr is null");
            CustomLogger.debug(this.getClass(),
                    scanLimitNum != null ? scanLimitNum.getValue() : "The scanLimit is null");
            setSelectedLimitScanInd(limitScanIndicator != null ? limitScanIndicator.getValue() : "");
            setScanLimit(scanLimitNum != null ? scanLimitNum.getValue() : "");
            setDisableScanLimit(!"True".equalsIgnoreCase(getSelectedLimitScanInd()));
        } else {
            setSelectedLimitScanInd("");
            setScanLimit("");
            setDisableLimitScan(true);
            setDisableScanLimit(true);
        }

    }

    private void setNoMsg() {
        setShowErrorMsg(false);
        setShowWarnMsg(false);
        setShowInfoMsg(false);

        setErrorMsg("");
        setWarnMsg("");
        setInfoMsg("");

    }

    public void lmtScanControls() {
        CustomLogger.enter(this.getClass());
        if ("True".equalsIgnoreCase(selectedLimitScanInd)) {
            setDisableScanLimit(false);
        } else {
            setScanLimit("");
            setDisableScanLimit(true);
        }
    }

    public void change() {
        CustomLogger.enter(this.getClass());
        manageFormPanelDisplay("OnSelectChange");
    }

    public void save() {
        CustomLogger.enter(this.getClass());

        if (selectedSponsorId == 0) {
            manageFormPanelDisplay("SelectSponsor");
        } else if (selectedLimitScanInd.isEmpty()) {
            manageFormPanelDisplay("SelectLimitScan");
        } else {
            updateRefSponsorConfiguration();
            manageFormPanelDisplay("OnSavedSuccessfully");
        }

    }

    private void updateRefSponsorConfiguration() {
        CustomLogger.enter(this.getClass());
        try {
            int sponsorIdInt = Integer.parseInt(String.valueOf(selectedSponsorId));
            RefSponsorConfiguration limitScanInd = adminService.getRefSponsorConfiguration(sponsorIdInt,
                    RefSponsorConfiguration.LIMIT_IPP_SCANS);
            if (limitScanInd != null && !limitScanInd.getValue().equalsIgnoreCase(selectedLimitScanInd)) {
                limitScanInd.setValue(selectedLimitScanInd);

                CustomLogger.debug(this.getClass(), "limitScanInd: " + limitScanInd.getValue() + " userID: " + userId);
                adminService.updateRefSponsorConfiguration(limitScanInd);
                adminService.barcodeLimitScanIndAdminNotification(sponsorIdInt, userId);
            } else {
                manageFormPanelDisplay("OnSaveWithoutChange");
            }
            RefSponsorConfiguration scanLimitNum = adminService.getRefSponsorConfiguration(sponsorIdInt,
                    RefSponsorConfiguration.IPP_SCAN_LIMIT);

            if (scanLimitNum != null && !scanLimitNum.getValue().equalsIgnoreCase(scanLimit)) {
                if ("False".equalsIgnoreCase(selectedLimitScanInd)) {
                    scanLimitNum.setValue("0");
                } else {
                    scanLimitNum.setValue("".equalsIgnoreCase(scanLimit) ? "0" : scanLimit);
                }
                CustomLogger.debug(this.getClass(), "scanLimitNum: " + scanLimitNum.getValue() + " userID: " + userId);
                adminService.updateRefSponsorConfiguration(scanLimitNum);
                adminService.barcodeMaxScanLimitNotification(sponsorIdInt, userId);
            } else {
                manageFormPanelDisplay("OnSaveWithoutChange");
            }
        } catch (MailSendException e) {
            manageFormPanelDisplay("OnMailSendError");
        } catch (Exception e) {
            manageFormPanelDisplay("OnSaveError");
        }

    }

    public void cancel() {
        CustomLogger.enter(this.getClass());
        manageFormPanelDisplay("OnCancel");
    }

    private void manageFormPanelDisplay(String eventName) {
        CustomLogger.enter(this.getClass());

        initMessageAndButtonDisplay();

        switch (eventName) {
        case "InitLoad":
            setShowInitialBtn(true);
            selectedSponsorId = 0;
            setDisableScanLimit(true);
            break;
        case "SelectSponsor":
            setInfoMsg("Please select a sponsor.");
            setShowInfoMsg(true);
            break;
        case "SelectLimitScan":
            setInfoMsg("Please indicate whether to limit the number of barcode scans allowed.");
            setShowInfoMsg(true);
            break;
        case "OnCancel":
            setDisableLimitScan(false);
            setDisableScanLimit(false);
            setShowInitialBtn(true);
            break;
        case "OnSelectChange":
            setInfoMsg("You are changing the configuration value(s).  If this is correct, select Confirm below.");
            setShowInfoMsg(true);
            setShowConfirmChangeBtn(true);
            setDisableLimitScan(true);
            setDisableScanLimit(true);
            break;
        case "OnSavedSuccessfully":
            setInfoMsg("Configuration was successfully updated!");
            setShowInfoMsg(true);
            setShowInitialBtn(true);
            setDisableLimitScan(true);
            setDisableScanLimit(true);
            selectedSponsorId = 0;
            selectedLimitScanInd="";
            setScanLimit("");
            break;
        case "OnSaveWithoutChange":
            setInfoMsg("No configuration value changes were made.");
            setShowInfoMsg(true);
            setShowConfirmChangeBtn(false);
            break;
        case "OnSaveError":
            setInfoMsg("Error saving the configuration values.");
            selectedSponsorId = 0;
            setDisableScanLimit(true);
            setShowInfoMsg(true);
            setShowInitialBtn(true);
            setDisableLimitScan(false);
            setDisableScanLimit(false);
            loadSponsorList();
            break;
        case "OnMailSendError":
            setInfoMsg("Error sending the notification email.");
            selectedSponsorId = 0;
            setDisableScanLimit(true);
            setShowInfoMsg(true);
            setShowInitialBtn(true);
            setDisableLimitScan(false);
            setDisableScanLimit(false);
            loadSponsorList();
            break;

        default:
        }
    }

    private void initMessageAndButtonDisplay() {
        CustomLogger.enter(this.getClass());

        setShowInitialBtn(false);
        setShowConfirmChangeBtn(false);

        setNoMsg();

    }

    public boolean isInitialized() {
        return initialized;
    }

    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }

    public boolean isShowInfoMsg() {
        return showInfoMsg;
    }

    public void setShowInfoMsg(boolean showInfoMsg) {
        this.showInfoMsg = showInfoMsg;
    }

    public boolean isShowWarnMsg() {
        return showWarnMsg;
    }

    public void setShowWarnMsg(boolean showWarnMsg) {
        this.showWarnMsg = showWarnMsg;
    }

    public boolean isShowErrorMsg() {
        return showErrorMsg;
    }

    public void setShowErrorMsg(boolean showErrorMsg) {
        this.showErrorMsg = showErrorMsg;
    }

    public boolean isShowInitialBtn() {
        return showInitialBtn;
    }

    public void setShowInitialBtn(boolean showInitialBtn) {
        this.showInitialBtn = showInitialBtn;
    }

    public boolean isShowConfirmChangeBtn() {
        return showConfirmChangeBtn;
    }

    public void setShowConfirmChangeBtn(boolean showConfirmChangeBtn) {
        this.showConfirmChangeBtn = showConfirmChangeBtn;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getWarnMsg() {
        return warnMsg;
    }

    public void setWarnMsg(String warnMsg) {
        this.warnMsg = warnMsg;
    }

    public String getInfoMsg() {
        return infoMsg;
    }

    public void setInfoMsg(String infoMsg) {
        this.infoMsg = infoMsg;
    }

    public String getSelectedLimitScanInd() {
        return selectedLimitScanInd;
    }

    public void setSelectedLimitScanInd(String selectedLimitScanInd) {
        this.selectedLimitScanInd = selectedLimitScanInd;
    }

    public List<RefSponsor> getSponsorList() {
        return sponsorList;
    }

    public void setSponsorList(List<RefSponsor> sponsorList) {
        this.sponsorList = sponsorList;
    }

    public long getSelectedSponsorId() {
        return selectedSponsorId;
    }

    public void setSelectedSponsorId(long selectedSponsorId) {
        this.selectedSponsorId = selectedSponsorId;
    }

    public String getScanLimit() {
        return scanLimit;
    }

    public void setScanLimit(String scanLimit) {
        this.scanLimit = scanLimit;
    }

    public boolean isDisableLimitScan() {
        return disableLimitScan;
    }

    public void setDisableLimitScan(boolean disableLimitScan) {
        this.disableLimitScan = disableLimitScan;
    }

    public boolean isDisableScanLimit() {
        return disableScanLimit;
    }

    public void setDisableScanLimit(boolean disableScanLimit) {
        this.disableScanLimit = disableScanLimit;
    }

}
