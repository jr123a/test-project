package com.ips.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.exception.IPSException;
import com.ips.service.AdminService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;

@ManagedBean(name = "externalAgencyApi")
@ViewScoped
public class ExternalAgencyApiAdminBean extends IPSAdminController implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long selectedSponsor;
	private List<RefSponsor> sponsorList;
	private String retryAttempts;
	private String retryInterval;
	private String callAgencyService;
	private String serviceCallWaitTime;
	private boolean isInitialized = false;
	private Map<String, Boolean> booleanPropertyMapping;
	private static final String MAP_KEY_ISDATABASEERROR = "isDatabaseError";
	private static final String MAP_KEY_ISEMAILERROR = "isEmailError";
	private static final String MAP_KEY_ISSUCCESS = "isSuccess";
	private static final String MAP_KEY_ISCONFIRMCHANGE = "isConfirmChange";
	private static final String MAP_KEY_ISRETRYATTEMPTSEXISTS = "isRetryAttemptsExists";
	private static final String MAP_KEY_ISRETRYINTERVALEXISTS = "isRetryIntervalExists";
	private static final String MAP_KEY_ISSERVICECALLWAITTIMEEXISTS = "isServiceCallWaitTimeExists";

	public void init() {
		if (!isInitialized) {
			buildBooleanPropertyMapping();
			buildSponsorList();
			selectedSponsor = !sponsorList.isEmpty() && sponsorList.get(0) != null ? sponsorList.get(0).getSponsorId()
					: null;
			setValuesFromDatabase();
			isInitialized = true;
		}
	}

	public void confirmChange() {
		setSuccess(false);
		if (isConfirmChange()) {
			setValuesFromDatabase();
		}
		setConfirmChange(!isConfirmChange());
	}

	public void saveValues() {
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			RefSponsorConfigurationService refSponsorConfigService = webAppContext
					.getBean(RefSponsorConfigurationService.class);

			clearBooleanPropertyValues();

			String[] configurationNames = { RefSponsorConfiguration.IPP_CALL_AGENCY_SERVICE,
					RefSponsorConfiguration.AGENCY_SERVICE_ATTEMPTS, RefSponsorConfiguration.AGENCY_SERVICE_INTERVAL,
					RefSponsorConfiguration.AGENCY_SERVICE_CALL_WAIT };

			try {
				for (String configName : configurationNames) {
					RefSponsorConfiguration config = refSponsorConfigService.getConfigRecord(selectedSponsor.intValue(),
							configName);
					if (config == null) {
						config = new RefSponsorConfiguration();
						config.setConfigurationId(refSponsorConfigService.getMostRecentConfigId() + 1);
						config.setCreateDate(new Date());
						config.setName(configName);
						config.setSponsorId(selectedSponsor.intValue());
						if (RefSponsorConfiguration.IPP_CALL_AGENCY_SERVICE.equalsIgnoreCase(configName)) {
							config.setValue("1".equalsIgnoreCase(callAgencyService) ? "True" : "False");
						} else if (RefSponsorConfiguration.AGENCY_SERVICE_ATTEMPTS.equalsIgnoreCase(configName)) {
							config.setValue(retryAttempts);
						} else if (RefSponsorConfiguration.AGENCY_SERVICE_INTERVAL.equalsIgnoreCase(configName)) {
							config.setValue(retryInterval);
						} else if (RefSponsorConfiguration.AGENCY_SERVICE_CALL_WAIT.equalsIgnoreCase(configName)) {
							config.setValue(serviceCallWaitTime);
						} else {
							config.setValue("");
						}
						refSponsorConfigService.create(config);
					} else {
						if (RefSponsorConfiguration.IPP_CALL_AGENCY_SERVICE.equalsIgnoreCase(configName)) {
							config.setValue("1".equalsIgnoreCase(callAgencyService) ? "True" : "False");
						} else if (RefSponsorConfiguration.AGENCY_SERVICE_ATTEMPTS.equalsIgnoreCase(configName)) {
							config.setValue(retryAttempts);
						} else if (RefSponsorConfiguration.AGENCY_SERVICE_INTERVAL.equalsIgnoreCase(configName)) {
							config.setValue(retryInterval);
						} else if (RefSponsorConfiguration.AGENCY_SERVICE_CALL_WAIT.equalsIgnoreCase(configName)) {
							config.setValue(serviceCallWaitTime);
						} else {
							config.setValue("");
						}
						config.setUpdateDate(new Date());
						refSponsorConfigService.update(config);
					}
				}

				setSuccess(true);
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Error occurred when updating values", e);
				setDatabaseError(true);
				setValuesFromDatabase();
				return;
			}

			if (isSuccess()) {
				AdminService adminService = (AdminService) webAppContext.getBean("AdminService");
				RefSponsorDataService refSponsorDataService = (RefSponsorDataService) webAppContext
						.getBean("RefSponsorDataService");
				HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
						.getRequest();

				try {
					adminService.externalAgencyApiNotification((String) request.getSession().getAttribute("IVSToken"),
							new Timestamp(new Date().getTime()), refSponsorDataService.findByPK(getSelectedSponsor()),
							"1".equalsIgnoreCase(callAgencyService), retryAttempts, retryInterval, serviceCallWaitTime);
				} catch (IPSException e) {
					CustomLogger.error(this.getClass(),
							"Exception occurred when sending API configuration notification change", e);
					setEmailError(true);
				}
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve necessary services.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public String getSelectedSponsorName() {
		return sponsorList.stream().filter(sp -> sp.getSponsorId() == selectedSponsor).findFirst()
				.orElse(new RefSponsor()).getSponsorName();
	}

	public void selectSponsor() {
		try {
			setValuesFromDatabase();
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Error occurred when switching sponsors", e);
			setDatabaseError(true);
		}
	}

	private void setValuesFromDatabase() {
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			RefSponsorConfigurationService refSponsorConfigService = webAppContext
					.getBean(RefSponsorConfigurationService.class);
			RefSponsorConfiguration configCallAgencyService = null;
			RefSponsorConfiguration configRetryAttempts = null;
			RefSponsorConfiguration configRetryInterval = null;
			RefSponsorConfiguration configServiceCallWaitTime = null;

			clearBooleanPropertyValues();

			try {
				configCallAgencyService = refSponsorConfigService.getConfigRecord(selectedSponsor.intValue(),
						RefSponsorConfiguration.IPP_CALL_AGENCY_SERVICE);
				configRetryAttempts = refSponsorConfigService.getConfigRecord(selectedSponsor.intValue(),
						RefSponsorConfiguration.AGENCY_SERVICE_ATTEMPTS);
				configRetryInterval = refSponsorConfigService.getConfigRecord(selectedSponsor.intValue(),
						RefSponsorConfiguration.AGENCY_SERVICE_INTERVAL);
				configServiceCallWaitTime = refSponsorConfigService.getConfigRecord(selectedSponsor.intValue(),
						RefSponsorConfiguration.AGENCY_SERVICE_CALL_WAIT);
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred when retrieving configurations from database.",
						e);
				setDatabaseError(true);
			}

			this.callAgencyService = configCallAgencyService != null
					&& "true".equalsIgnoreCase(configCallAgencyService.getValue()) ? "1" : "0";
			this.retryAttempts = configRetryAttempts != null ? configRetryAttempts.getValue() : "";
			this.retryInterval = configRetryInterval != null ? configRetryInterval.getValue() : "";
			this.serviceCallWaitTime = configServiceCallWaitTime != null ? configServiceCallWaitTime.getValue() : "";

			setRetryAttemptsExists(StringUtils.isNotBlank(this.retryAttempts));
			setRetryIntervalExists(StringUtils.isNotBlank(this.retryInterval));
			setServiceCallWaitTimeExists(StringUtils.isNotBlank(this.serviceCallWaitTime));
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve refSponsorConfigService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void buildSponsorList() {
		sponsorList = new ArrayList<>();

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			RefSponsorDataService refSponsorDataService = (RefSponsorDataService) webAppContext
					.getBean("RefSponsorDataService");

			try {
				sponsorList.addAll(refSponsorDataService.getAllExternalIppClients());
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred when building RefSponsor list", e);
				setDatabaseError(true);
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void buildBooleanPropertyMapping() {
		booleanPropertyMapping = new HashMap<>();
		booleanPropertyMapping.put(MAP_KEY_ISDATABASEERROR, false);
		booleanPropertyMapping.put(MAP_KEY_ISEMAILERROR, false);
		booleanPropertyMapping.put(MAP_KEY_ISSUCCESS, false);
		booleanPropertyMapping.put(MAP_KEY_ISCONFIRMCHANGE, false);
		booleanPropertyMapping.put(MAP_KEY_ISRETRYATTEMPTSEXISTS, true);
		booleanPropertyMapping.put(MAP_KEY_ISRETRYINTERVALEXISTS, true);
		booleanPropertyMapping.put(MAP_KEY_ISSERVICECALLWAITTIMEEXISTS, true);
	}

	private void clearBooleanPropertyValues() {
		setDatabaseError(false);
		setEmailError(false);
		setSuccess(false);
		setConfirmChange(false);
		setRetryAttemptsExists(true);
		setRetryIntervalExists(true);
		setServiceCallWaitTimeExists(true);
	}

	public boolean isDatabaseError() {
		return booleanPropertyMapping.get(MAP_KEY_ISDATABASEERROR);
	}

	public void setDatabaseError(boolean isDatabaseError) {
		booleanPropertyMapping.replace(MAP_KEY_ISDATABASEERROR, isDatabaseError);
	}

	public boolean isRetryAttemptsExists() {
		return booleanPropertyMapping.get(MAP_KEY_ISRETRYATTEMPTSEXISTS);
	}

	public void setRetryAttemptsExists(boolean isRetryAttemptsExists) {
		booleanPropertyMapping.replace(MAP_KEY_ISRETRYATTEMPTSEXISTS, isRetryAttemptsExists);
	}

	public boolean isServiceCallWaitTimeExists() {
		return booleanPropertyMapping.get(MAP_KEY_ISSERVICECALLWAITTIMEEXISTS);
	}

	public void setServiceCallWaitTimeExists(boolean isServiceCallWaitTimeExists) {
		booleanPropertyMapping.replace(MAP_KEY_ISSERVICECALLWAITTIMEEXISTS, isServiceCallWaitTimeExists);
	}

	public boolean isRetryIntervalExists() {
		return booleanPropertyMapping.get(MAP_KEY_ISRETRYINTERVALEXISTS);
	}

	public void setRetryIntervalExists(boolean isRetryIntervalExists) {
		booleanPropertyMapping.replace(MAP_KEY_ISRETRYINTERVALEXISTS, isRetryIntervalExists);
	}

	public boolean isEmailError() {
		return booleanPropertyMapping.get(MAP_KEY_ISEMAILERROR);
	}

	public void setEmailError(boolean isEmailError) {
		booleanPropertyMapping.replace(MAP_KEY_ISEMAILERROR, isEmailError);
	}

	public boolean isSuccess() {
		return booleanPropertyMapping.get(MAP_KEY_ISSUCCESS);
	}

	public void setSuccess(boolean isSuccess) {
		booleanPropertyMapping.replace(MAP_KEY_ISSUCCESS, isSuccess);
	}

	public boolean isConfirmChange() {
		return booleanPropertyMapping.get(MAP_KEY_ISCONFIRMCHANGE);
	}

	public void setConfirmChange(boolean isConfirmChange) {
		booleanPropertyMapping.replace(MAP_KEY_ISCONFIRMCHANGE, isConfirmChange);
	}

	public String getRetryAttempts() {
		return retryAttempts;
	}

	public void setRetryAttempts(String retryAttempts) {
		this.retryAttempts = retryAttempts;
	}

	public String getCallAgencyService() {
		return callAgencyService;
	}

	public void setCallAgencyService(String callAgencyService) {
		this.callAgencyService = callAgencyService;
	}

	public String getRetryInterval() {
		return retryInterval;
	}

	public void setRetryInterval(String retryInterval) {
		this.retryInterval = retryInterval;
	}

	public Long getSelectedSponsor() {
		return selectedSponsor;
	}

	public void setSelectedSponsor(Long selectedSponsor) {
		this.selectedSponsor = selectedSponsor;
	}

	public List<RefSponsor> getSponsorList() {
		return sponsorList;
	}

	public String getServiceCallWaitTime() {
		return serviceCallWaitTime;
	}

	public void setServiceCallWaitTime(String serviceCallWaitTime) {
		this.serviceCallWaitTime = serviceCallWaitTime;
	}
}
