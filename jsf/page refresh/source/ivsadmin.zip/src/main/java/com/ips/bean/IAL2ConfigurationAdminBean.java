package com.ips.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.entity.RefIdValidationVendor;
import com.ips.entity.RefPrimaryIdType;
import com.ips.entity.RefSecondaryIdType;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.SponsorFairId;
import com.ips.entity.SponsorFairIdPK;
import com.ips.entity.SponsorStrongId;
import com.ips.entity.SponsorStrongIdPK;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;

@ManagedBean(name = "extAgencyIAL2Config")
@ViewScoped
public class IAL2ConfigurationAdminBean extends IPSAdminController implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<RefSponsor> sponsorList;
	private List<RefIdValidationVendor> vendorList;
	private List<RefPrimaryIdType> availableStrongIdTypeList;
	private List<RefPrimaryIdType> sponsorStrongIdTypeList;
	private List<SponsorStrongId> sponsorStrongIdList;
	private List<RefSecondaryIdType> availableFairIdTypeList;
	private List<RefSecondaryIdType> sponsorFairIdTypeList;
	private List<SponsorFairId> sponsorFairIdList;
	private List<RefPrimaryIdType> includedSelectedStrongIdList;
	private List<RefSecondaryIdType> includedSelectedFairIdList;
	private List<RefPrimaryIdType> removedSelectedStrongIdList;
	private List<RefSecondaryIdType> removedSelectedFairIdList;

	private long selectedSponsorId = 0L;
	private long selectedPrimaryVendorId = 0L;
	private long selectedBkupVendorId = 0L;
	private long currPrimaryVendorId;
	private long currBkupVendorId;

	private boolean initialized;
	private boolean showControlPnl;
	private boolean showInfoMsg;
	private boolean showWarnMsg;
	private boolean showErrorMsg;
	private boolean showInitialBtn;
	private boolean showConfirmChangeBtn;
	private boolean changedIAL2RequiredOption;
	private boolean changedIAL2Option1Enabled;
	private boolean changedIAL2IDValidationRetryAttempts;
	private boolean changedPrimaryVendorId;
	private boolean changedBkupVendorId;
	private boolean includedSelectedStrongIds;
	private boolean includedSelectedFairIds;
	private boolean removedSelectedStrongIds;
	private boolean removedSelectedFairIds;
	private boolean changeMadeInAnyControl;

	private String userId;
	private String selectedIAL2RequiredOption;
	private String selectedIAL2Option1Enabled;
	private String currValidationRetryAttempts;
	private String currIAL2RequiredOption;
	private String currIAL2Option1Enabled;
	private String errorMsg;
	private String warnMsg;
	private String infoMsg;
	private String externalAgencyName;
	private String ial2RequiredVal;
	private String ial2ValidationRetryAttemptsVal;
	private String ial2OptionVal;
	private String primaryIdVendorName;
	private String backupIdVendorName;
	private String includedStrongIdNames;
	private String includedFairIdNames;
	private String removedStrongIdNames;
	private String removedFairIdNames;

	public static final String CONFIG_REQUIRES_IAL2_TYPE = "1";
	public static final String CONFIG_OPTION1_ENABLED_TYPE = "2";
	public static final String CONFIG_PRIMARY_VENDOR_TYPE = "3";
	public static final String CONFIG_BACKUP_VENDOR_TYPE = "4";
	public static final String CONFIG_STRONG_ID_LIST_TYPE = "5";
	public static final String CONFIG_FAIR_ID_LIST_TYPE = "6";
	public static final String CONFIG_ID_VALIDATION_RETRY_ATTEMPTS = "8";

	private static final String ADMIN_SERVICE = "AdminService";
	private static final String IAL2_REQUIRED_CONFIG_NAME = "IAL2.required";
	private static final String IAL2_OPTION1_ENABLED_CONFIG_NAME = "IAL2.Option1.enabled";
	private static final String IAL2_PRIMARY_VENDOR_CONFIG_NAME = "Primary.id.validation.vendor";
	private static final String IAL2_BACKUP_VENDOR_CONFIG_NAME = "Backup.id.validation.vendor";
	private static final String IAL2_CONFIG_VALUE_TRUE = "True";
	private static final String IAL2_ID_VALIDATION_RETRY_ATTEMPTS = "ID.validation.retry.attempts";

	@PostConstruct
	public void init() {
		CustomLogger.enter(this.getClass());
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);

			if (!initialized) {
				setInitialized(true);

				HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
						.getRequest();
				setUserId((String) request.getSession().getAttribute("IVSToken"));

				loadSelectorsList(adminService);
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/*************************** Initialization Methods ***************************/

	public void loadSelectorsList(AdminService adminService) {
		CustomLogger.enter(this.getClass());

		try {
			sponsorList = adminService.getIAL2SponsorList(IAL2_REQUIRED_CONFIG_NAME);
			sponsorList = adminService.getAllExternalIppClients();
			vendorList = adminService.findValidationVendorList();
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in loadSelectorsList: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}

		if (selectedSponsorId == 0) {
			manageFormPanelDisplay("InitLoad");
		}

	}

	public void loadFormControls() {
		CustomLogger.enter(this.getClass());

		loadFormControls(selectedSponsorId);

		RefSponsor selectedSponsor = sponsorList.stream().filter(sponsor -> sponsor.getSponsorId() == selectedSponsorId)
				.findFirst().orElse(null);
		String sponsorName = selectedSponsor != null ? selectedSponsor.getSponsorName() : "";
		setExternalAgencyName(sponsorName);

		manageFormPanelDisplay("OnSponsorSelect");
	}

	/*************************** Public Event Methods ***************************/

	public void change() {
		CustomLogger.enter(this.getClass());

		manageFormPanelDisplay("OnSelectChange");
	}

	public void save() {
		CustomLogger.enter(this.getClass());

		if (selectedPrimaryVendorId == 0) {
			manageFormPanelDisplay("NoSelectedPrimaryVendor");
			return;
		}

		if (selectedBkupVendorId == 0) {
			manageFormPanelDisplay("NoSelectedBkupVendor");
			return;
		}

		if (selectedPrimaryVendorId == selectedBkupVendorId) {
			manageFormPanelDisplay("SameSelectedVendor");
			return;
		}

		if (!this.validateIsValidDigitInRange(ial2ValidationRetryAttemptsVal, 0, 5)) {
			manageFormPanelDisplay("InvalidRetryAttemptsVal");
			return;
		}

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);

			updateRefSponsorConfiguration(adminService);

			if (availableStrongIdTypeList != null) {
				includeSelectedStrongIds(adminService);
			}

			if (sponsorStrongIdTypeList != null) {
				removeSelectedStrongIds(adminService);
			}

			if (availableFairIdTypeList != null) {
				includeSelectedFairIds(adminService);
			}

			if (sponsorFairIdTypeList != null) {
				removeSelectedFairIds(adminService);
			}

			loadFormControls(selectedSponsorId);
			String lineBreak = "\t\n";

			if (includedSelectedStrongIds || removedSelectedStrongIds) {
				StringBuilder idNamesSb = new StringBuilder();
				for (RefPrimaryIdType type : sponsorStrongIdTypeList) {
					idNamesSb.append(lineBreak);
					idNamesSb.append(type.getIdTypeDescription());
				}

				idNamesSb.append(lineBreak);
				sendNotificationEmail(adminService, idNamesSb.toString(),
						IAL2ConfigurationAdminBean.CONFIG_STRONG_ID_LIST_TYPE);
			}

			if (includedSelectedFairIds || removedSelectedFairIds) {
				StringBuilder idNamesSb = new StringBuilder();
				for (RefSecondaryIdType type : sponsorFairIdTypeList) {
					idNamesSb.append(lineBreak);
					idNamesSb.append(type.getIdTypeDescription());
				}

				idNamesSb.append(lineBreak);
				sendNotificationEmail(adminService, idNamesSb.toString(),
						IAL2ConfigurationAdminBean.CONFIG_FAIR_ID_LIST_TYPE);
			}

			manageFormPanelDisplay("OnSavedSuccessfully");

			changeMadeInAnyControl = changedIAL2RequiredOption || changedIAL2Option1Enabled || changedPrimaryVendorId
					|| changedBkupVendorId || includedSelectedStrongIds || includedSelectedFairIds
					|| removedSelectedStrongIds || removedSelectedFairIds || changedIAL2IDValidationRetryAttempts;

			if (!changeMadeInAnyControl) {
				manageFormPanelDisplay("OnSaveWithoutChange");
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void cancel() {
		CustomLogger.enter(this.getClass());

		loadFormControls(selectedSponsorId);
		manageFormPanelDisplay("OnCancel");
	}

	/*************************** Private Methods ***************************/

	private void loadFormControls(long sponsorId) {
		CustomLogger.enter(this.getClass());

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);

			int sponsorIdInt = Integer.parseInt(String.valueOf(sponsorId));
			RefSponsorConfiguration ial2RequiredConfig = adminService.getRefSponsorConfiguration(sponsorIdInt,
					IAL2_REQUIRED_CONFIG_NAME);
			RefSponsorConfiguration ial2OptionEnabledConfig = adminService.getRefSponsorConfiguration(sponsorIdInt,
					IAL2_OPTION1_ENABLED_CONFIG_NAME);
			RefSponsorConfiguration ial2PrimaryVendorConfig = adminService.getRefSponsorConfiguration(sponsorIdInt,
					IAL2_PRIMARY_VENDOR_CONFIG_NAME);
			RefSponsorConfiguration ial2BackupVendorConfig = adminService.getRefSponsorConfiguration(sponsorIdInt,
					IAL2_BACKUP_VENDOR_CONFIG_NAME);

			RefSponsorConfiguration ial2ValidationRetryAttemptsConfig = adminService
					.getRefSponsorConfiguration(sponsorIdInt, IAL2_ID_VALIDATION_RETRY_ATTEMPTS);

			String ial2RequiredOption = ial2RequiredConfig != null ? ial2RequiredConfig.getValue() : "False";
			String ial2Option1Enabled = ial2OptionEnabledConfig != null ? ial2OptionEnabledConfig.getValue() : "False";
			long primaryVendorId = ial2PrimaryVendorConfig != null ? new Long(ial2PrimaryVendorConfig.getValue()) : 0;
			long bkupVendorId = ial2BackupVendorConfig != null ? new Long(ial2BackupVendorConfig.getValue()) : 0;

			String ial2ValidationRetryAttempts = ial2ValidationRetryAttemptsConfig != null
					? ial2ValidationRetryAttemptsConfig.getValue()
					: "";

			setSelectedIAL2RequiredOption(ial2RequiredOption);
			setSelectedIAL2Option1Enabled(ial2Option1Enabled);
			setSelectedPrimaryVendorId(primaryVendorId);
			setSelectedBkupVendorId(bkupVendorId);

			setIal2ValidationRetryAttemptsVal(ial2ValidationRetryAttempts);

			setCurrIAL2RequiredOption(ial2RequiredOption);
			setCurrIAL2Option1Enabled(ial2Option1Enabled);
			setCurrPrimaryVendorId(primaryVendorId);
			setCurrBkupVendorId(bkupVendorId);
			setCurrValidationRetryAttempts(ial2ValidationRetryAttempts);

			loadSponsorStrongIdList(adminService);
			loadSponsorFairIdList(adminService);
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void loadSponsorStrongIdList(AdminService adminService) {
		CustomLogger.enter(this.getClass());

		try {
			availableStrongIdTypeList = adminService.getAvailableStrongList(selectedSponsorId);
			sponsorStrongIdTypeList = adminService.getSponsorStrongList(selectedSponsorId);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in loadSponsorStrongIdList: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void loadSponsorFairIdList(AdminService adminService) {
		CustomLogger.enter(this.getClass());

		try {
			availableFairIdTypeList = adminService.getAvailableFairList(selectedSponsorId);
			sponsorFairIdTypeList = adminService.getSponsorFairList(selectedSponsorId);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in loadSponsorFairIdList: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void includeSelectedStrongIds(AdminService adminService) {
		CustomLogger.enter(this.getClass());

		RefPrimaryIdType idType = null;
		List<Long> selectedPrimaryIdList = new ArrayList<>();
		Iterator<RefPrimaryIdType> it = availableStrongIdTypeList.iterator();
		includedSelectedStrongIdList = new ArrayList<>();
		setIncludedSelectedStrongIds(false);

		while (it.hasNext()) {
			idType = it.next();

			if (idType.isSelected()) {
				selectedPrimaryIdList.add(idType.getIdType());
				includedSelectedStrongIdList.add(idType);
				setIncludedSelectedStrongIds(true);

			}
		}

		try {
			for (Long id : selectedPrimaryIdList) {
				SponsorStrongId entity = new SponsorStrongId();
				SponsorStrongIdPK pkId = new SponsorStrongIdPK();

				pkId.setSponsorId(selectedSponsorId);
				pkId.setIdType(id);
				entity.setId(pkId);
				entity.setCreateDate(getCurrentTime());
				adminService.createSponsorStrongId(entity);
			}
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in includeSelectedStrongIds: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void includeSelectedFairIds(AdminService adminService) {
		CustomLogger.enter(this.getClass());

		RefSecondaryIdType idType = null;
		List<Long> selectedSecondaryIdList = new ArrayList<>();
		Iterator<RefSecondaryIdType> it = availableFairIdTypeList.iterator();
		includedSelectedFairIdList = new ArrayList<>();
		setIncludedSelectedFairIds(false);

		while (it.hasNext()) {
			idType = it.next();

			if (idType.isSelected()) {
				selectedSecondaryIdList.add(idType.getIdType());
				includedSelectedFairIdList.add(idType);
				setIncludedSelectedFairIds(true);
			}
		}

		try {
			for (Long id : selectedSecondaryIdList) {
				SponsorFairId entity = new SponsorFairId();
				SponsorFairIdPK pkId = new SponsorFairIdPK();

				pkId.setSponsorId(selectedSponsorId);
				pkId.setIdType(id);
				entity.setId(pkId);
				entity.setCreateDate(getCurrentTime());
				adminService.createSponsorFairId(entity);
			}
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in includeSelectedFairIds: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void removeSelectedStrongIds(AdminService adminService) {
		CustomLogger.enter(this.getClass());

		RefPrimaryIdType idType = null;
		List<Long> selectedPrimaryIdList = new ArrayList<>();
		Iterator<RefPrimaryIdType> it = sponsorStrongIdTypeList.iterator();
		removedSelectedStrongIdList = new ArrayList<>();
		setRemovedSelectedStrongIds(false);

		while (it.hasNext()) {
			idType = it.next();

			if (idType.isSelected()) {
				selectedPrimaryIdList.add(idType.getIdType());
				removedSelectedStrongIdList.add(idType);
				setRemovedSelectedStrongIds(true);
			}
		}

		try {
			for (Long primaryIdType : selectedPrimaryIdList) {
				adminService.removeSponsorStrongId(selectedSponsorId, primaryIdType);
			}
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in removeSelectedStrongIds: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void removeSelectedFairIds(AdminService adminService) {
		CustomLogger.enter(this.getClass());

		RefSecondaryIdType idType = null;
		List<Long> selectedSecondaryIdList = new ArrayList<>();
		Iterator<RefSecondaryIdType> it = sponsorFairIdTypeList.iterator();
		removedSelectedFairIdList = new ArrayList<>();
		setRemovedSelectedFairIds(false);

		while (it.hasNext()) {
			idType = it.next();
			if (idType.isSelected()) {
				selectedSecondaryIdList.add(idType.getIdType());
				removedSelectedFairIdList.add(idType);
				setRemovedSelectedFairIds(true);
			}
		}

		try {
			for (Long secondaryIdType : selectedSecondaryIdList) {
				adminService.removeSponsorFairId(selectedSponsorId, secondaryIdType);
			}
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in removeSelectedFairIds: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void updateRefSponsorConfiguration(AdminService adminService) {
		CustomLogger.enter(this.getClass());

		int sponsorIdInt = Integer.parseInt(String.valueOf(selectedSponsorId));
		setChangedIAL2RequiredOption(false);
		setChangedIAL2Option1Enabled(false);
		setChangedPrimaryVendorId(false);
		setChangedBkupVendorId(false);
		setChangedIAL2IDValidationRetryAttempts(false);

		try {
			if (!currIAL2RequiredOption.equalsIgnoreCase(selectedIAL2RequiredOption)) {
				setChangedIAL2RequiredOption(true);
				updateCreateRefSponsorConfiguration(adminService, sponsorIdInt, selectedIAL2RequiredOption,
						IAL2_REQUIRED_CONFIG_NAME);

				setIal2RequiredVal(IAL2_CONFIG_VALUE_TRUE.equalsIgnoreCase(selectedIAL2RequiredOption) ? "Yes" : "No");

				sendNotificationEmail(adminService, ial2RequiredVal,
						IAL2ConfigurationAdminBean.CONFIG_REQUIRES_IAL2_TYPE);
			}

			if (!currIAL2Option1Enabled.equalsIgnoreCase(selectedIAL2Option1Enabled)) {
				setChangedIAL2Option1Enabled(true);
				updateCreateRefSponsorConfiguration(adminService, sponsorIdInt, selectedIAL2Option1Enabled,
						IAL2_OPTION1_ENABLED_CONFIG_NAME);

				setIal2OptionVal(IAL2_CONFIG_VALUE_TRUE.equalsIgnoreCase(selectedIAL2Option1Enabled) ? "Yes" : "No");

				sendNotificationEmail(adminService, ial2OptionVal,
						IAL2ConfigurationAdminBean.CONFIG_OPTION1_ENABLED_TYPE);
			}

			if (currPrimaryVendorId != selectedPrimaryVendorId) {
				setChangedPrimaryVendorId(true);
				updateCreateRefSponsorConfiguration(adminService, sponsorIdInt, String.valueOf(selectedPrimaryVendorId),
						IAL2_PRIMARY_VENDOR_CONFIG_NAME);

				RefIdValidationVendor validationVendor = vendorList.stream()
						.filter(vendor -> vendor.getVendorId() == selectedPrimaryVendorId).findFirst().orElse(null);
				setPrimaryIdVendorName(validationVendor != null ? validationVendor.getVendorName() : "");

				sendNotificationEmail(adminService, primaryIdVendorName,
						IAL2ConfigurationAdminBean.CONFIG_PRIMARY_VENDOR_TYPE);
			}

			if (currBkupVendorId != selectedBkupVendorId) {
				setChangedBkupVendorId(true);
				updateCreateRefSponsorConfiguration(adminService, sponsorIdInt, String.valueOf(selectedBkupVendorId),
						IAL2_BACKUP_VENDOR_CONFIG_NAME);

				RefIdValidationVendor validationVendor = vendorList.stream()
						.filter(vendor -> vendor.getVendorId() == selectedBkupVendorId).findFirst().orElse(null);
				setBackupIdVendorName(validationVendor != null ? validationVendor.getVendorName() : "");

				sendNotificationEmail(adminService, backupIdVendorName,
						IAL2ConfigurationAdminBean.CONFIG_BACKUP_VENDOR_TYPE);
			}

			if (currValidationRetryAttempts != ial2ValidationRetryAttemptsVal) {
				setChangedIAL2IDValidationRetryAttempts(true);
				updateCreateRefSponsorConfiguration(adminService, sponsorIdInt,
						String.valueOf(ial2ValidationRetryAttemptsVal), IAL2_ID_VALIDATION_RETRY_ATTEMPTS);

				sendNotificationEmail(adminService, ial2ValidationRetryAttemptsVal,
						IAL2ConfigurationAdminBean.CONFIG_ID_VALIDATION_RETRY_ATTEMPTS);
			}

		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in updateRefSponsorConfiguration: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void updateCreateRefSponsorConfiguration(AdminService adminService, int sponsorIdInt, String configValue,
			String configName) {
		RefSponsorConfiguration refSponsorConfig = adminService.getRefSponsorConfiguration(sponsorIdInt, configName);

		if (refSponsorConfig != null) {
			refSponsorConfig.setValue(String.valueOf(configValue));
			adminService.updateRefSponsorConfiguration(refSponsorConfig);
		} else {
			refSponsorConfig = new RefSponsorConfiguration();
			refSponsorConfig.setName(configName);
			refSponsorConfig.setSponsorId(sponsorIdInt);
			refSponsorConfig.setValue(configValue);
			adminService.createRefSponsorConfiguration(refSponsorConfig);
		}
	}

	private void sendNotificationEmail(AdminService adminService, String configValue, String configType) {
		CustomLogger.enter(this.getClass());

		try {
			Timestamp transactionTime = new Timestamp(new Date().getTime());
			adminService.sendIal2ConfigChangeConfirmNotification(selectedSponsorId, userId, externalAgencyName,
					transactionTime, configValue, configType);
		} catch (Exception e) {
			setErrorMsg("An error occurred while generating notification email for IAL-2 configuration value change.");
			setShowErrorMsg(true);
			CustomLogger.error(this.getClass(),
					"Error occurred while sending email notification to Sponsor Report automatic recipients upon Sponsor_Reports table update.",
					e);
		}
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userid) {
		this.userId = userid;
	}

	private Timestamp getCurrentTime() {
		Date date = new Date();
		return new Timestamp(date.getTime());
	}

	private void manageFormPanelDisplay(String eventName) {
		CustomLogger.enter(this.getClass());

		initMessageAndButtonDisplay();

		switch (eventName) {
		case "InitLoad":
			setInfoMsg("Select an external agency.");
			setShowInfoMsg(true);
			break;
		case "OnSponsorSelect":
		case "OnCancel":
			setShowControlPnl(true);
			setShowInitialBtn(true);
			break;
		case "OnSelectChange":
			setInfoMsg("You are changing the configuration value(s).  If this is correct, select Confirm below.");
			setShowInfoMsg(true);
			setShowControlPnl(true);
			setShowConfirmChangeBtn(true);
			break;
		case "OnSavedSuccessfully":
			setInfoMsg("Configuration was successfully updated!");
			setShowInfoMsg(true);
			setShowInitialBtn(true);
			setShowControlPnl(true);
			setIal2RequiredVal(null);
			setIal2OptionVal(null);
			setPrimaryIdVendorName(null);
			setBackupIdVendorName(null);
			break;
		case "OnSaveWithoutChange":
			setInfoMsg("No configuration value changes were made.");
			setShowInfoMsg(true);
			setShowControlPnl(true);
			setShowConfirmChangeBtn(true);
			break;
		case "NoSelectedPrimaryVendor":
			setInfoMsg("Primary vendor is required. Select a primary vendor.");
			setShowInfoMsg(true);
			setShowControlPnl(true);
			setShowConfirmChangeBtn(true);
			break;
		case "NoSelectedBkupVendor":
			setInfoMsg("Backup vendor is required. Select a backup vendor.");
			setShowInfoMsg(true);
			setShowControlPnl(true);
			setShowConfirmChangeBtn(true);
			break;
		case "SameSelectedVendor":
			setInfoMsg("Same primary and backup vendor were selected. Select a different primary or backup vendor.");
			setShowInfoMsg(true);
			setShowControlPnl(true);
			setShowConfirmChangeBtn(true);
			break;
		case "InvalidRetryAttemptsVal":
			setErrorMsg(
					"Invalid value for Maximum ID Validation Attempts. Value must be between a number between 0 and 5.");
			setShowErrorMsg(true);
			setShowControlPnl(true);
			setShowConfirmChangeBtn(true);
		default:
		}
	}

	private void initMessageAndButtonDisplay() {
		CustomLogger.enter(this.getClass());

		setShowControlPnl(false);
		setShowInitialBtn(false);
		setShowConfirmChangeBtn(false);

		setShowErrorMsg(false);
		setShowWarnMsg(false);
		setShowInfoMsg(false);

		setErrorMsg("");
		setWarnMsg("");
		setInfoMsg("");

	}

	/***************************
	 * Properties Getters/Setters
	 ***************************/

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public List<RefSponsor> getSponsorList() {
		return sponsorList;
	}

	public void setSponsorList(List<RefSponsor> sponsorList) {
		this.sponsorList = sponsorList;
	}

	public List<RefIdValidationVendor> getVendorList() {
		return vendorList;
	}

	public void setVendorList(List<RefIdValidationVendor> vendorList) {
		this.vendorList = vendorList;
	}

	public long getSelectedSponsorId() {
		return selectedSponsorId;
	}

	public void setSelectedSponsorId(long selectedSponsorId) {
		this.selectedSponsorId = selectedSponsorId;
	}

	public long getSelectedPrimaryVendorId() {
		return selectedPrimaryVendorId;
	}

	public void setSelectedPrimaryVendorId(long selectedPrimaryVendorId) {
		this.selectedPrimaryVendorId = selectedPrimaryVendorId;
	}

	public long getSelectedBkupVendorId() {
		return selectedBkupVendorId;
	}

	public void setSelectedBkupVendorId(long selectedBkupVendorId) {
		this.selectedBkupVendorId = selectedBkupVendorId;
	}

	public List<RefPrimaryIdType> getAvailableStrongIdTypeList() {
		return availableStrongIdTypeList;
	}

	public void setAvailableStrongIdTypeList(List<RefPrimaryIdType> availableStrongIdTypeList) {
		this.availableStrongIdTypeList = availableStrongIdTypeList;
	}

	public List<RefPrimaryIdType> getSponsorStrongIdTypeList() {
		return sponsorStrongIdTypeList;
	}

	public void setSponsorStrongIdTypeList(List<RefPrimaryIdType> sponsorStrongIdTypeList) {
		this.sponsorStrongIdTypeList = sponsorStrongIdTypeList;
	}

	public List<SponsorStrongId> getSponsorStrongIdList() {
		return sponsorStrongIdList;
	}

	public void setSponsorStrongIdList(List<SponsorStrongId> sponsorStrongIdList) {
		this.sponsorStrongIdList = sponsorStrongIdList;
	}

	public List<RefSecondaryIdType> getAvailableFairIdTypeList() {
		return availableFairIdTypeList;
	}

	public void setAvailableFairIdTypeList(List<RefSecondaryIdType> availableFairIdTypeList) {
		this.availableFairIdTypeList = availableFairIdTypeList;
	}

	public List<RefSecondaryIdType> getSponsorFairIdTypeList() {
		return sponsorFairIdTypeList;
	}

	public void setSponsorFairIdTypeList(List<RefSecondaryIdType> sponsorFairIdTypeList) {
		this.sponsorFairIdTypeList = sponsorFairIdTypeList;
	}

	public List<SponsorFairId> getSponsorFairIdList() {
		return sponsorFairIdList;
	}

	public void setSponsorFairIdList(List<SponsorFairId> sponsorFairIdList) {
		this.sponsorFairIdList = sponsorFairIdList;
	}

	public String getSelectedIAL2RequiredOption() {
		return selectedIAL2RequiredOption;
	}

	public void setSelectedIAL2RequiredOption(String selectedIAL2RequiredOption) {
		this.selectedIAL2RequiredOption = selectedIAL2RequiredOption;
	}

	public String getSelectedIAL2Option1Enabled() {
		return selectedIAL2Option1Enabled;
	}

	public void setSelectedIAL2Option1Enabled(String selectedIAL2Option1Enabled) {
		this.selectedIAL2Option1Enabled = selectedIAL2Option1Enabled;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getWarnMsg() {
		return warnMsg;
	}

	public void setWarnMsg(String warnMsg) {
		this.warnMsg = warnMsg;
	}

	public String getInfoMsg() {
		return infoMsg;
	}

	public void setInfoMsg(String infoMsg) {
		this.infoMsg = infoMsg;
	}

	public boolean isShowControlPnl() {
		return showControlPnl;
	}

	public void setShowControlPnl(boolean showControlPnl) {
		this.showControlPnl = showControlPnl;
	}

	public boolean isShowInfoMsg() {
		return showInfoMsg;
	}

	public void setShowInfoMsg(boolean showInfoMsg) {
		this.showInfoMsg = showInfoMsg;
	}

	public boolean isShowWarnMsg() {
		return showWarnMsg;
	}

	public void setShowWarnMsg(boolean showWarnMsg) {
		this.showWarnMsg = showWarnMsg;
	}

	public boolean isShowErrorMsg() {
		return showErrorMsg;
	}

	public void setShowErrorMsg(boolean showErrorMsg) {
		this.showErrorMsg = showErrorMsg;
	}

	public long getCurrPrimaryVendorId() {
		return currPrimaryVendorId;
	}

	public void setCurrPrimaryVendorId(long currPrimaryVendorId) {
		this.currPrimaryVendorId = currPrimaryVendorId;
	}

	public long getCurrBkupVendorId() {
		return currBkupVendorId;
	}

	public void setCurrBkupVendorId(long currBkupVendorId) {
		this.currBkupVendorId = currBkupVendorId;
	}

	public String getCurrIAL2RequiredOption() {
		return currIAL2RequiredOption;
	}

	public void setCurrIAL2RequiredOption(String currIAL2RequiredOption) {
		this.currIAL2RequiredOption = currIAL2RequiredOption;
	}

	public String getCurrIAL2Option1Enabled() {
		return currIAL2Option1Enabled;
	}

	public void setCurrIAL2Option1Enabled(String currIAL2Option1Enabled) {
		this.currIAL2Option1Enabled = currIAL2Option1Enabled;
	}

	public boolean isShowInitialBtn() {
		return showInitialBtn;
	}

	public void setShowInitialBtn(boolean showInitialBtn) {
		this.showInitialBtn = showInitialBtn;
	}

	public boolean isShowConfirmChangeBtn() {
		return showConfirmChangeBtn;
	}

	public void setShowConfirmChangeBtn(boolean showConfirmChangeBtn) {
		this.showConfirmChangeBtn = showConfirmChangeBtn;
	}

	public String getExternalAgencyName() {
		return externalAgencyName;
	}

	public void setExternalAgencyName(String externalAgencyName) {
		this.externalAgencyName = externalAgencyName;
	}

	public String getIal2RequiredVal() {
		return ial2RequiredVal;
	}

	public void setIal2RequiredVal(String ial2RequiredVal) {
		this.ial2RequiredVal = ial2RequiredVal;
	}

	public String getIal2OptionVal() {
		return ial2OptionVal;
	}

	public void setIal2OptionVal(String ial2OptionVal) {
		this.ial2OptionVal = ial2OptionVal;
	}

	public String getPrimaryIdVendorName() {
		return primaryIdVendorName;
	}

	public void setPrimaryIdVendorName(String primaryIdVendorName) {
		this.primaryIdVendorName = primaryIdVendorName;
	}

	public String getBackupIdVendorName() {
		return backupIdVendorName;
	}

	public void setBackupIdVendorName(String backupIdVendorName) {
		this.backupIdVendorName = backupIdVendorName;
	}

	public boolean isIncludedSelectedStrongIds() {
		return includedSelectedStrongIds;
	}

	public void setIncludedSelectedStrongIds(boolean includedSelectedStrongIds) {
		this.includedSelectedStrongIds = includedSelectedStrongIds;
	}

	public boolean isIncludedSelectedFairIds() {
		return includedSelectedFairIds;
	}

	public void setIncludedSelectedFairIds(boolean includedSelectedFairIds) {
		this.includedSelectedFairIds = includedSelectedFairIds;
	}

	public boolean isRemovedSelectedStrongIds() {
		return removedSelectedStrongIds;
	}

	public void setRemovedSelectedStrongIds(boolean removedSelectedStrongIds) {
		this.removedSelectedStrongIds = removedSelectedStrongIds;
	}

	public boolean isRemovedSelectedFairIds() {
		return removedSelectedFairIds;
	}

	public void setRemovedSelectedFairIds(boolean removedSelectedFairIds) {
		this.removedSelectedFairIds = removedSelectedFairIds;
	}

	public boolean isChangedIAL2RequiredOption() {
		return changedIAL2RequiredOption;
	}

	public void setChangedIAL2RequiredOption(boolean changedIAL2RequiredOption) {
		this.changedIAL2RequiredOption = changedIAL2RequiredOption;
	}

	public boolean isChangedIAL2Option1Enabled() {
		return changedIAL2Option1Enabled;
	}

	public void setChangedIAL2Option1Enabled(boolean changedIAL2Option1Enabled) {
		this.changedIAL2Option1Enabled = changedIAL2Option1Enabled;
	}

	public boolean isChangedPrimaryVendorId() {
		return changedPrimaryVendorId;
	}

	public void setChangedPrimaryVendorId(boolean changedPrimaryVendorId) {
		this.changedPrimaryVendorId = changedPrimaryVendorId;
	}

	public boolean isChangedBkupVendorId() {
		return changedBkupVendorId;
	}

	public void setChangedBkupVendorId(boolean changedBkupVendorId) {
		this.changedBkupVendorId = changedBkupVendorId;
	}

	public List<RefPrimaryIdType> getIncludedSelectedStrongIdList() {
		return includedSelectedStrongIdList;
	}

	public void setIncludedSelectedStrongIdList(List<RefPrimaryIdType> includedSelectedStrongIdList) {
		this.includedSelectedStrongIdList = includedSelectedStrongIdList;
	}

	public List<RefSecondaryIdType> getIncludedSelectedFairIdList() {
		return includedSelectedFairIdList;
	}

	public void setIncludedSelectedFairIdList(List<RefSecondaryIdType> includedSelectedFairIdList) {
		this.includedSelectedFairIdList = includedSelectedFairIdList;
	}

	public List<RefPrimaryIdType> getRemovedSelectedStrongIdList() {
		return removedSelectedStrongIdList;
	}

	public void setRemovedSelectedStrongIdList(List<RefPrimaryIdType> removedSelectedStrongIdList) {
		this.removedSelectedStrongIdList = removedSelectedStrongIdList;
	}

	public List<RefSecondaryIdType> getRemovedSelectedFairIdList() {
		return removedSelectedFairIdList;
	}

	public void setRemovedSelectedFairIdList(List<RefSecondaryIdType> removedSelectedFairIdList) {
		this.removedSelectedFairIdList = removedSelectedFairIdList;
	}

	public String getIncludedStrongIdNames() {
		return includedStrongIdNames;
	}

	public void setIncludedStrongIdNames(String includedStrongIdNames) {
		this.includedStrongIdNames = includedStrongIdNames;
	}

	public String getIncludedFairIdNames() {
		return includedFairIdNames;
	}

	public void setIncludedFairIdNames(String includedFairIdNames) {
		this.includedFairIdNames = includedFairIdNames;
	}

	public String getRemovedStrongIdNames() {
		return removedStrongIdNames;
	}

	public void setRemovedStrongIdNames(String removedStrongIdNames) {
		this.removedStrongIdNames = removedStrongIdNames;
	}

	public String getRemovedFairIdNames() {
		return removedFairIdNames;
	}

	public void setRemovedFairIdNames(String removedFairIdNames) {
		this.removedFairIdNames = removedFairIdNames;
	}

	public boolean isChangeMadeInAnyControl() {
		return changeMadeInAnyControl;
	}

	public void setChangeMadeInAnyControl(boolean changeMadeInAnyControl) {
		this.changeMadeInAnyControl = changeMadeInAnyControl;
	}

	public boolean isChangedIAL2IDValidationRetryAttempts() {
		return changedIAL2IDValidationRetryAttempts;
	}

	public void setChangedIAL2IDValidationRetryAttempts(boolean changedIAL2IDValidationRetryAttempts) {
		this.changedIAL2IDValidationRetryAttempts = changedIAL2IDValidationRetryAttempts;
	}

	public String getIal2ValidationRetryAttemptsVal() {
		return ial2ValidationRetryAttemptsVal;
	}

	public void setIal2ValidationRetryAttemptsVal(String ial2ValidationRetryAttemptsVal) {
		this.ial2ValidationRetryAttemptsVal = ial2ValidationRetryAttemptsVal;
	}

	public String getCurrValidationRetryAttempts() {
		return currValidationRetryAttempts;
	}

	public void setCurrValidationRetryAttempts(String currValidationRetryAttempts) {
		this.currValidationRetryAttempts = currValidationRetryAttempts;
	}

	private boolean validateIsValidDigitInRange(String stringVal, int startVal, int endVal) {

		int intValue;
		if (stringVal == null || "".equalsIgnoreCase(stringVal.trim())) {
			return false;
		}

		char[] stringCharArray = stringVal.toCharArray();
		if (stringCharArray.length != 1) {
			return false;
		}

		for (int charArrayIndex = 0; charArrayIndex < stringCharArray.length; charArrayIndex++) {
			char mychar = stringCharArray[charArrayIndex];
			if (Character.isDigit(mychar)) {
				continue;
			} else {
				return false;
			}
		}

		try {
			intValue = Integer.parseInt(stringVal);
		} catch (NumberFormatException nfe) {
			return false;
		}

		if (intValue >= startVal && intValue <= endVal) {
			return true;
		} else {
			return false;
		}

	}

}
