package com.ips.common;

import java.io.Serializable;


public class SponsorReportVo implements Serializable {

    private static final long serialVersionUID = 1L;
    private long reportEmailId;
    private long sponsorId;
    private long reportId;
    private String recipientEmailAddresses;
    private String sponsorName;
    private String reportName;
    private String createDate;
    private String updateDate;
    
    public long getReportEmailId() {
        return reportEmailId;
    }
    
    public void setReportEmailId(long reportEmailId) {
        this.reportEmailId = reportEmailId;
    }

    public long getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }

    public long getReportId() {
        return reportId;
    }

    public void setReportId(long reportId) {
        this.reportId = reportId;
    }

    public String getRecipientEmailAddresses() {
        return recipientEmailAddresses;
    }

    public void setRecipientEmailAddresses(String recipientEmailAddresses) {
        this.recipientEmailAddresses = recipientEmailAddresses;
    }

    public String getSponsorName() {
        return sponsorName;
    }

    public void setSponsorName(String sponsorName) {
        this.sponsorName = sponsorName;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }
    
}
