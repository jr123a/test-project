package com.ips.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.event.ValueChangeEvent;

import org.apache.commons.lang3.StringUtils;

import com.ips.bean.EventFacilityAdminBean;
import com.ips.bean.IPPFacilitiesAdminBean;
import com.ips.bean.SponsorFacilitiesAdminBean;

public class Paginator implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private EventFacilityAdminBean eventFacAdminBean;
    private IPPFacilitiesAdminBean ippFacAdminBean;
    private SponsorFacilitiesAdminBean sponsorFacAdminBean;
    
    private String callingBeanName = "";
    
    private long totalRowCount = 0;
    private int firstResult = 0;
    private int maxResults = 0;
    private int pageCount = 0;
    private int startRow = 0;
    private int endRow = 0;
    private int currentPageNum = 0;
    private static final int DEFAULT_MAX_RESULTS = 100;
    private static final int PAGE_SIZE_INTERVAL = 100;

    private boolean showPaginator = false;
    private boolean enableNextPage = false;
    private boolean enablePrevPage = false;
    private boolean enableFirstPage = false;
    private boolean enableLastPage = false;
    private boolean resetTotalCount = true;
    private boolean resetPagination = false;

    private List<Integer> pageNumList;
    private List<Integer> pageSizeList;
    
    public Paginator() {
        
    }
    
    public Paginator(EventFacilityAdminBean callingBean) {
        this();
        setEventFacAdminBean(callingBean);
        setCallingBeanName("eventFacilityAdmin");
    }
    
    public Paginator(IPPFacilitiesAdminBean callingBean) {
        this();
        setIppFacAdminBean(callingBean);
        setCallingBeanName("facAdmin");
    }
    
    public Paginator(SponsorFacilitiesAdminBean callingBean) {
        this();
        setSponsorFacAdminBean(callingBean);
        setCallingBeanName("sponsorFacAdmin");
    }
    
    public String getCallingBeanName() {
        return callingBeanName;
    }

    public void setCallingBeanName(String callingBeanName) {
        this.callingBeanName = callingBeanName;
    }
    
    public void updateRowRange() {
        updateStartRow();
        updateEndRow();    
    }
    
    public void initPaginatorProperties() {
        setResetTotalCount(true);
        setShowPaginator(false);
        setTotalRowCount(0);
        setPageCount(0);
        setCurrentPageNum(1);
        setPaginatorProperties() ;
    }
    
    public void resetPaginatorProperties() {
        setPageCount();
        setPageNumList();    
        setPageSizeList();
        setResetTotalCount(false);
        setShowPaginator(true);
        setResetPagination(true);
        setPaginatorProperties();
    }
    
    public void setPaginatorProperties() {
        if (maxResults == 0) {
            setMaxResults(DEFAULT_MAX_RESULTS);
        }
        
        setFirstResult(0);    
        setStartRow(0);
        setEndRow(0);
        setCurrentPageNum(1);

        setEnableNextPage(false);
        setEnablePrevPage(false);
        setEnableFirstPage(false);
        setEnableLastPage(false);
    }
    
    public void updateTotalCount(long totalCount) {
        setFirstResult(0);
        setTotalRowCount(totalCount);
        setPageCount();
        setPageNumList();    
        setPageSizeList();
    }
    
    public void navigatePage(String position){
        switch(position) {
            case "first": setCurrentPageNum(1);
                break;
            case "previous": setCurrentPageNum(currentPageNum - 1);
                break;
            case "next": setCurrentPageNum(currentPageNum + 1); 
                break;
            case "last": setCurrentPageNum(pageCount);            
                break;
            default:
        }
        
        setResetTotalCount(false);
        setResetPagination(false);
        setFirstResult((currentPageNum - 1) * maxResults);    
        loadDataTable();
    }

    public void gotoPage(ValueChangeEvent event){
        if (event.getNewValue() != null) {
            setCurrentPageNum((int) event.getNewValue());            
            setFirstResult((currentPageNum - 1) * maxResults);
            setResetTotalCount(false);
            setResetPagination(false);
            loadDataTable();
        }
    }
    
    public void reloadPage(ValueChangeEvent event){
        if (event.getNewValue() != null) {
            setMaxResults((int) event.getNewValue());
            resetPaginatorProperties();
            loadDataTable();
        }
    }
    
    public void loadDataTable() {
        if (!StringUtils.isEmpty(callingBeanName)) {
            switch(callingBeanName) {
                case "eventFacilityAdmin":
                    eventFacAdminBean.loadEventsForMonth(); 
                    break;
                case "facAdmin":
                    ippFacAdminBean.setLocsAdded(false);
                    ippFacAdminBean.setAllLocsAdded(false);
                    ippFacAdminBean.setLocsRemoved(false);
                    ippFacAdminBean.setAllLocsRemoved(false);
                    ippFacAdminBean.findFacilities(); 
                    break;
                case "sponsorFacAdmin":
                    sponsorFacAdminBean.paginatorLoadTables();
                    break;
                default:
            }    
        }
    }
    
    public void setPageCount() {
        Double dblPageCount = ((double) totalRowCount) / ((double) maxResults);    
        setPageCount((int) Math.ceil(dblPageCount));
    }
    
    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }
    
    public List<Integer> getPageNumList() {
        return this.pageNumList;
    }
    
    public void setPageNumList() {
        pageNumList = new ArrayList<>();
        for (int i = 1; i < pageCount + 1; i++) {
            pageNumList.add(i);
        }
    }
    
    public List<Integer> getPageSizeList() {
        return pageSizeList;
    }

    public void setPageSizeList() {
        pageSizeList = new ArrayList<>();
        int totalCount = (int) totalRowCount;
        int listCount = 5;
        int pageSize = DEFAULT_MAX_RESULTS;
    
        for (int i = 0; i < listCount; i++) {
            pageSizeList.add(pageSize);

            if (pageSize > totalCount) {
                break;
            }
            pageSize += PAGE_SIZE_INTERVAL; 
        }
    }
    
    public void updateStartRow() {
        setStartRow(firstResult + 1);        
    }
    
    public void setStartRow(int startRow) {
        this.startRow = startRow;        
    }

    public void updateEndRow() {
        setEndRow(firstResult + maxResults);
        if (endRow > totalRowCount) {
            setEndRow((int) totalRowCount);
        }
    }
    
    public void setEndRow(int endRow) {
        this.endRow = endRow;
    }
    
    public long getTotalRowCount() {
        return totalRowCount;
    }
    
    public void setTotalRowCount(long totalRowCount) {
        this.totalRowCount = totalRowCount;
    }
    
    public int getFirstResult() {
        return firstResult;
    }
    
    public void setFirstResult(int firstResult) {
        this.firstResult = firstResult;
    }
    
    public int getMaxResults() {
        if (maxResults == 0) {
            setMaxResults(DEFAULT_MAX_RESULTS);
        }
        return maxResults;
    }
    
    public void setMaxResults(int maxResults) {
        this.maxResults = maxResults;
    }
    
    public int getCurrentPageNum() {
        return this.currentPageNum;
    }
    
    public void setCurrentPageNum(int currentPageNum) {
        this.currentPageNum = currentPageNum;
    }
    
    public boolean isShowPaginator() {
        setShowPaginator(totalRowCount > 0);
        return showPaginator;
    }
    
    public void setShowPaginator(boolean showPaginator) {
        this.showPaginator = showPaginator;
    }
    
    public boolean isEnableNextPage() {
        setEnableNextPage(currentPageNum < pageCount);
        return enableNextPage;
    }
    
    public void setEnableNextPage(boolean enableNextPage) {
        this.enableNextPage = enableNextPage;
    }
    
    public boolean isEnablePrevPage() {
        setEnablePrevPage(currentPageNum > 1);
        if (this.isResetTotalCount()) {
            setEnableFirstPage(false);
        }
        return enablePrevPage;
    }
    
    public void setEnablePrevPage(boolean enablePrevPage) {
        this.enablePrevPage = enablePrevPage;
    }
    
    public boolean isEnableFirstPage() {
        setEnableFirstPage(currentPageNum > 1);
        
        if (this.isResetTotalCount()) {
            setEnableFirstPage(false);
            this.currentPageNum = 1;
        }
        
        if (this.isResetPagination()) {
            this.currentPageNum = 1;
        }
        return enableFirstPage;
    }
    
    public void setEnableFirstPage(boolean enableFirstPage) {
        this.enableFirstPage = enableFirstPage;
    }
    
    public boolean isEnableLastPage() {
        setEnableLastPage(currentPageNum <  pageCount);
        return enableLastPage;
    }
    
    public void setEnableLastPage(boolean enableLastPage) {
        this.enableLastPage = enableLastPage;
    }
    
    public boolean isResetTotalCount() {
        return resetTotalCount;
    }
    public void setResetTotalCount(boolean resetTotalCount) {
        this.resetTotalCount = resetTotalCount;
    }
    
    public int getPageCount() {
        return this.pageCount;
    }
    
    public int getStartRow() {
        return this.startRow;
    }
    
    public int getEndRow() {
        return this.endRow;
    }

    public boolean isResetPagination() {
        return resetPagination;
    }

    public void setResetPagination(boolean resetPagination) {
        this.resetPagination = resetPagination;
    }

    public EventFacilityAdminBean getEventFacAdminBean() {
        return eventFacAdminBean;
    }
    
    public void setEventFacAdminBean(EventFacilityAdminBean eventFacAdminBean) {
        this.eventFacAdminBean = eventFacAdminBean;
    }

    public IPPFacilitiesAdminBean getIppFacAdminBean() {
        return ippFacAdminBean;
    }

    public void setIppFacAdminBean(IPPFacilitiesAdminBean ippFacAdminBean) {
        this.ippFacAdminBean = ippFacAdminBean;
    }

    public SponsorFacilitiesAdminBean getSponsorFacAdminBean() {
        return sponsorFacAdminBean;
    }

    public void setSponsorFacAdminBean(SponsorFacilitiesAdminBean sponsorFacAdminBean) {
        this.sponsorFacAdminBean = sponsorFacAdminBean;
    }
}
