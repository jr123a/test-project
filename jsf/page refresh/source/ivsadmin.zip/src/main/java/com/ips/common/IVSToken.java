package com.ips.common;

import java.io.Serializable;

import org.apache.commons.codec.binary.Base64;

public class IVSToken implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private long expiration;
    private String username;
    
    public IVSToken(String username, long expiration){
        this.username = null;
        this.expiration = 0L;
        this.username = username;
        this.expiration = expiration;
    }
    
    public static IVSToken getInstance(String encryptedToken){
        IVSToken ivsToken = null;
        String token = new String(decodeFromBase64(encryptedToken));
        if(token.length() >= 30){
            String user = token.substring(0,15).trim();
            long exp = System.currentTimeMillis()+600000;
            ivsToken = new IVSToken(user, exp);
        }
        return ivsToken;
    }
    
    private static byte[] decodeFromBase64(String base64String) {
        return Base64.decodeBase64(base64String);
    }
     
    public boolean isExpired() {
        return  System.currentTimeMillis()>= expiration;
    }

    public long getExpiration() {
        return expiration;
    }

    public void setExpiration(long expiration) {
        this.expiration = expiration;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
