package com.ips.bean;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.Paginator;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.JSFUtils;
import com.ips.common.common.Utils;
import com.ips.persistence.common.IPSConstants;
import com.ips.polocator.common.LocationVo;
import com.ips.service.AdminServiceImpl;

@ManagedBean(name = "facAdmin")
@ViewScoped
public class IPPFacilitiesAdminBean extends IPSAdminController implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<LocationVo> facilities;
	private Paginator paginator;

	private String input;
	private String username;
	private String browserName;

	private boolean loadActiveFacilities = false;
	private boolean locsAdded = false;
	private boolean allLocsAdded = false;
	private boolean locsRemoved = false;
	private boolean allLocsRemoved = false;
	private boolean initialized = false;
	private long totalRowCount;

	private static final String CITY_STATE_INPUT_ERROR_MSG = "Please enter City and State (City, State Code), or ZIP code (5 digits).";
	private static final String ADMIN_SERVICE_BEAN = "AdminService";
	private static final String MPOS_FAC_COUNT_FMT = "mPOS PO Facilites Count = %s";
	private static final String FAC_RETRIEVE_ERROR_FMT = "%s Error occurred when retrieving the facilities: ";
	AdminServiceImpl adminService;

	@PostConstruct
	public void init() {
		CustomLogger.enter(this.getClass());
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);
			if (initialized) {
				return;
			}

			initialized = true;
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();
			HttpSession session = request.getSession();

			username = (String) request.getSession().getAttribute("IVSToken");

			if (session.getAttribute(LOCATIONS_ADDED) == null) {
				locsAdded = false;
			} else {
				locsAdded = (Boolean) session.getAttribute(LOCATIONS_ADDED);
			}

			if (session.getAttribute(ALL_LOCATIONS_ADDED) == null) {
				allLocsAdded = false;
			} else {
				allLocsAdded = (Boolean) session.getAttribute(ALL_LOCATIONS_ADDED);
			}
			paginator = new Paginator(this);
			browserName = Utils.getBrowserName(request);

			if (request.getRequestURI().contains(IPP_FACILITIES_ADMIN_PAGE)) {
				loadFacilities(true);
			} else if (request.getRequestURI().contains(IPP_ADD_USPS_LOCATION_PAGE)) {
				loadFacilities(false);
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void loadFacilities(boolean active) {
		CustomLogger.enter(this.getClass());
		setLoadActiveFacilities(active);
		paginator.initPaginatorProperties();
		findFacilities();
	}

	public void findFacilities() {
		CustomLogger.enter(this.getClass());

		locsAdded = false;
		allLocsAdded = false;
		locsRemoved = false;
		allLocsRemoved = false;

		try {
			if (paginator.isResetTotalCount()) {
				totalRowCount = adminService.findAllFacilitiesCountByActivationDate(isLoadActiveFacilities());
				paginator.updateTotalCount(totalRowCount);
			}

			facilities = adminService.findAllFacilitiesByActivationDate(isLoadActiveFacilities(),
					paginator.getFirstResult(), paginator.getMaxResults());
			paginator.updateRowRange();

			CustomLogger.debug(this.getClass(), String.format(MPOS_FAC_COUNT_FMT, totalRowCount));
		} catch (Exception e) {
			CustomLogger.error(this.getClass(),
					String.format(FAC_RETRIEVE_ERROR_FMT, IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE), e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void searchFacilities(boolean active) {
		CustomLogger.enter(this.getClass());

		try {
			if (!input.isEmpty()) {
				String trimmedInput = input.trim();
				if (Utils.isNumeric(trimmedInput)) {
					if (trimmedInput.length() < 5) {
						JSFUtils.addFacesErrorMessage(CITY_STATE_INPUT_ERROR_MSG);
					} else {
						facilities = adminService.findByZipAndActivationDate(trimmedInput, active);
						CustomLogger.debug(this.getClass(), String.format(MPOS_FAC_COUNT_FMT, facilities.size()));
					}
				} else {
					if (valid()) {
						String[] x = input.split(",");
						String city = x[0].trim().toUpperCase();
						String state = x[1].trim().toUpperCase();

						facilities = adminService.findByCityStateAndActivationDate(city, state, active);
						CustomLogger.debug(this.getClass(), String.format(MPOS_FAC_COUNT_FMT, facilities.size()));
					} else {
						input = null;
					}
				}
			} else {
				JSFUtils.addFacesErrorMessage(CITY_STATE_INPUT_ERROR_MSG);
			}
		} catch (Exception e) {
			CustomLogger.error(this.getClass(),
					String.format(FAC_RETRIEVE_ERROR_FMT, IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE), e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void toggleToNonActive() {
		CustomLogger.enter(this.getClass());
		locsAdded = false;
		allLocsAdded = false;
		allLocsRemoved = false;
		int updateCount = updateActivationDate(false);
		CustomLogger.debug(this.getClass(), "Facilities removed from the approved geographic area: " + updateCount);
		locsRemoved = locationsAdded(updateCount);
		loadFacilities(true);
	}

	public void toggleToActive() {
		CustomLogger.enter(this.getClass());
		int updateCount = updateActivationDate(true);
		CustomLogger.debug(this.getClass(), "Facilities added to the approved geographic area: " + updateCount);
		setSessionAllLocsAdded(false);
		setSessionLocsAdded(locationsAdded(updateCount));
		goToPage(IPP_FACILITIES_ADMIN_PAGE);
	}

	private boolean locationsAdded(int updateCount) {
		return updateCount != 0;
	}

	public void toggleAllToActive() {
		CustomLogger.enter(this.getClass());
		int updateCount = toggleAll(true);
		CustomLogger.debug(this.getClass(),
				"Added all facilities. Facilities added to the approved geographic area: " + updateCount);
		setSessionLocsAdded(false);
		setSessionAllLocsAdded(locationsAdded(updateCount));
		goToPage(IPP_FACILITIES_ADMIN_PAGE);
	}

	public void toggleAllToNonActive() {
		CustomLogger.enter(this.getClass());
		locsAdded = false;
		allLocsAdded = false;
		locsRemoved = false;
		int updateCount = toggleAll(false);
		CustomLogger.debug(this.getClass(),
				"Removed all facilities. Facilities removed from the approved geographic area: " + updateCount);
		allLocsRemoved = locationsAdded(updateCount);
		loadFacilities(true);
	}

	private int updateActivationDate(boolean activate) {
		CustomLogger.enter(this.getClass());

		List<String> refFacilityIdList = new ArrayList<>();
		List<Date> activationDateList = new ArrayList<>();
		LocationVo facDetail = null;
		int updateCount = 0;

		Date maxActivationDate = null;
		try {
			maxActivationDate = new SimpleDateFormat(IPSConstants.DDMMYYYY_FMT).parse(IPSConstants.MAX_VALID_DATE);
		} catch (ParseException e) {
			CustomLogger.error(this.getClass(), "Error occurred when parsing string date:", e);
		}

		if (facilities != null) {
			Iterator<LocationVo> it = facilities.iterator();
			while (it.hasNext()) {
				facDetail = it.next();
				if (facDetail.isSelected()) {
					// toggle the flag of the facilities
					refFacilityIdList.add(facDetail.getLocationID());
					activationDateList.add(activate ? facDetail.getActivationDate() : maxActivationDate);
				}
			}

			try {
				updateCount = adminService.updateActivationDate(activate, refFacilityIdList, activationDateList,
						username);
				CustomLogger.debug(this.getClass(), "Activate facilities count: " + updateCount);
			} catch (Exception e) {
				CustomLogger.error(this.getClass(),
						IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred when activating facility: ", e);
				goToPage(SYSTEM_ERROR_PAGE);
			}
		}
		return updateCount;
	}

	private int toggleAll(boolean activate) {
		CustomLogger.enter(this.getClass());
		Date activationDate = null;
		try {
			activationDate = activate ? new Date()
					: new SimpleDateFormat(IPSConstants.DDMMYYYY_FMT).parse(IPSConstants.MAX_VALID_DATE);
		} catch (ParseException e) {
			CustomLogger.error(this.getClass(), "Error occurred when parsing string date:", e);
		}

		int updateCount = 0;
		try {
			updateCount = adminService.toggleAll(activationDate, activate, username);
			CustomLogger.debug(this.getClass(), "Facilities updated activationDate: " + updateCount);
		} catch (Exception e) {	
			CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE
					+ "Error occurred when adding all of the facilities to the approved geographic area: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
		return updateCount;
	}

	public void addUspsLocations() {
		goToPage(IPP_ADD_USPS_LOCATION_PAGE);
	}

	private boolean valid() {
		if (input.length() < 6 || input.matches("^\\d{5}(-\\d{4})?$")) {
			JSFUtils.addFacesErrorMessage(CITY_STATE_INPUT_ERROR_MSG);
			return false;
		} else {
			if (!input.contains(",")) {
				JSFUtils.addFacesErrorMessage(CITY_STATE_INPUT_ERROR_MSG);
				return false;
			} else {
				return true;
			}
		}
	}

	public List<LocationVo> getFacilities() {
		return facilities;
	}

	public void setFacilities(List<LocationVo> facilities) {
		this.facilities = facilities;
	}

	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}

	public boolean isLocsAdded() {
		return locsAdded;
	}

	public void setLocsAdded(boolean locsAdded) {
		this.locsAdded = locsAdded;
	}

	public boolean isAllLocsAdded() {
		return allLocsAdded;
	}

	public void setAllLocsAdded(boolean allLocsAdded) {
		this.allLocsAdded = allLocsAdded;
	}

	public boolean isLocsRemoved() {
		return locsRemoved;
	}

	public void setLocsRemoved(boolean locsRemoved) {
		this.locsRemoved = locsRemoved;
	}

	public boolean isAllLocsRemoved() {
		return allLocsRemoved;
	}

	public void setAllLocsRemoved(boolean allLocsRemoved) {
		this.allLocsRemoved = allLocsRemoved;
	}

	public String getBrowserName() {
		return browserName;
	}

	public void setBrowserName(String browserName) {
		this.browserName = browserName;
	}

	public Paginator getPaginator() {
		return paginator;
	}

	public void setPaginator(Paginator paginator) {
		this.paginator = paginator;
	}

	public long getTotalRowCount() {
		return totalRowCount;
	}

	public void setTotalRowCount(long totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	public boolean isLoadActiveFacilities() {
		return loadActiveFacilities;
	}

	public void setLoadActiveFacilities(boolean loadActiveFacilities) {
		this.loadActiveFacilities = loadActiveFacilities;
	}
}
