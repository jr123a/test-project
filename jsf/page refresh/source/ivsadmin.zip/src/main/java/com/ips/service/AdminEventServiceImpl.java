package com.ips.service;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RefAdminEventDao;
import com.ips.dao.RpAdminDao;
import com.ips.entity.RefAdminEvent;
import com.ips.entity.RpAdmin;

@Service(value="adminEventService")
@Transactional
public class AdminEventServiceImpl implements AdminEventService, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Autowired
    private RpAdminDao adminDao;
    
    @Autowired
    private RefAdminEventDao eventDao;

    @Override
    public void logAdminEvent(String userId, String eventDescription) {
        logAdminEvent(userId, eventDescription, 1L);
    }

    @Override
    public void logAdminEvent(String userId, String eventDescription, Long sponsorId) {
    	logAdminEvent(userId, eventDescription, sponsorId, null);
    }
    
    @Override
    public void logAdminEvent(String userId, String eventDescription, Long sponsorId, Long appId) {
        RpAdmin admin = adminDao.getById(userId);
        Date date = new Date();
        
        try {
            if(admin != null){
        		CustomLogger.debug(this.getClass(), "logAdminEvent :: RpAdmin is not null.");
        		RefAdminEvent adminEvent = eventDao.getByDescription(eventDescription);
        		if (adminEvent != null) {
        			CustomLogger.debug(this.getClass(), "logAdminEvent :: RefAdminEvent is not null.");
        			adminEvent.addRpAdmin(admin);
	                admin.setRefAdminEvent(adminEvent);
	                admin.setSponsorId(sponsorId);
	                admin.setAppId(appId);
	                admin.setUpdateDate(new Timestamp(date.getTime()));
	                adminDao.update(admin);
        		}
        		else {
        			CustomLogger.error(this.getClass(), "logAdminEvent :: RefAdminEvent is null.");
        		}
            }else{
            	CustomLogger.debug(this.getClass(), "logAdminEvent :: RpAdmin is null. Creating one.");
                admin = new RpAdmin();
                admin.setUserId(userId);
                admin.setRefAdminEvent(eventDao.getByDescription(eventDescription));
                admin.setCreateDate(new Timestamp(date.getTime()));
                admin.setSponsorId(sponsorId);

                // Update date needs to be set so trigger will fire
                admin.setUpdateDate(new Timestamp(date.getTime()));
                adminDao.save(admin);
            }
        }
        catch(Exception e ) {     	
            CustomLogger.error(this.getClass(), "Error in invoking logAdminEvent for user " + userId, e);
        }
    } 
    
    @Override
    public String getAdminEventDescription(String userId) {
        return adminDao.getAuditEventDescription(userId);
    }
    
    @Override
    public List<RpAdmin> findRpAdminBySponsor(long sponsorId) {
        return adminDao.findRpAdminBySponsor(sponsorId);
    }
    
    @Override
    public void save(RpAdmin entity) {
    	adminDao.save(entity);
    }
    
    @Override
    public void update(RpAdmin entity) {
    	adminDao.update(entity);
    }
    
    @Override
    public void deleteRpAdmin(RpAdmin rpAdmin) {
        adminDao.delete(rpAdmin);
    }
    
}
