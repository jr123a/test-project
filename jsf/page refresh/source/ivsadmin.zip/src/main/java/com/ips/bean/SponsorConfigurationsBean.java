package com.ips.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;

@ManagedBean(name = "sponsorConfigBean")
@ViewScoped
public class SponsorConfigurationsBean extends IPSAdminController implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String IS_DATABASE_ERROR = "isDatabaseError";
	private static final String IS_SUCCESS = "isSuccess";
	private static final String IS_CONFIRM_CHANGE = "isConfirmChange";
	private static final String CONFIG_KEY_AGE_CHECK_REQD = "Age.check.required";
	private static final String CONFIG_KEY_MINIMUM_AGE = "Minimum.age";

	private RefSponsorConfigurationService refSponsorConfigService;
	private AdminService adminService;
	private boolean initialized = false;
	private Map<String, Boolean> booleanPropertyMapping;
	private List<RefSponsor> sponsorList;
	private Long selectedSponsorId = 1L;
	private String minAgeReq = "0";
	private String minAge;

	private static final String ADMIN_SERVICE = "AdminService";
	private static final String ATTRIBUTE_IVSTOKEN = "IVSToken";
	private static final String BEAN_REFSPONSORDATASERVICE = "RefSponsorDataService";

	@PostConstruct
	public void init() {
		if (!initialized) {
			ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
			WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
			if (webAppContext != null) {
				refSponsorConfigService = webAppContext.getBean(RefSponsorConfigurationService.class);
				adminService = webAppContext.getBean(ADMIN_SERVICE, AdminServiceImpl.class);
				loadSponsorList();
				buildBooleanPropertyMapping();
				setValuesFromDatabase();
				setInitialized(true);
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void loadSponsorList() {
		try {
			sponsorList = adminService.getSponsorList();
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in loadSponsorList: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void confirmChange() {
		setSuccess(false);
		if (isConfirmChange()) {
			setValuesFromDatabase();
		}
		setConfirmChange(!isConfirmChange());
	}

	private void setValuesFromDatabase() {
		RefSponsorConfiguration configMinAgeReq = null;
		RefSponsorConfiguration configMinAge = null;

		clearBooleanPropertyValues();

		try {
			configMinAgeReq = refSponsorConfigService.getConfigRecord(selectedSponsorId.intValue(),
					CONFIG_KEY_AGE_CHECK_REQD);
			configMinAge = refSponsorConfigService.getConfigRecord(selectedSponsorId.intValue(),
					CONFIG_KEY_MINIMUM_AGE);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred when retrieving configurations from database.", e);
			setDatabaseError(true);
		}

		this.setMinAgeReq(configMinAgeReq != null && "true".equalsIgnoreCase(configMinAgeReq.getValue()) ? "1" : "0");
		this.setMinAge(configMinAge != null ? configMinAge.getValue() : "");
	}

	public void saveValues() {
		clearBooleanPropertyValues();

		RefSponsorConfiguration newMinAgeReq = refSponsorConfigService.getConfigRecord(selectedSponsorId.intValue(),
				CONFIG_KEY_AGE_CHECK_REQD);
		RefSponsorConfiguration newMinAge = refSponsorConfigService.getConfigRecord(selectedSponsorId.intValue(),
				CONFIG_KEY_MINIMUM_AGE);
		Long seqNum = refSponsorConfigService.getMostRecentConfigId();

		if (newMinAgeReq != null) {
			newMinAgeReq.setValue("1".equals(this.minAgeReq) ? "True" : "False");
			newMinAgeReq.setUpdateDate(new Date());
			refSponsorConfigService.update(newMinAgeReq);
		} else {
			newMinAgeReq = new RefSponsorConfiguration();
			newMinAgeReq.setValue("1".equals(this.minAgeReq) ? "True" : "False");
			newMinAgeReq.setCreateDate(new Date());
			newMinAgeReq.setSponsorId(selectedSponsorId.intValue());
			newMinAgeReq.setName(CONFIG_KEY_AGE_CHECK_REQD);
			seqNum++;
			newMinAgeReq.setConfigurationId(seqNum);
			refSponsorConfigService.create(newMinAgeReq);
		}

		if (newMinAge != null) {
			newMinAge.setValue(this.minAge);
			newMinAge.setUpdateDate(new Date());
			refSponsorConfigService.update(newMinAge);
		} else {
			newMinAge = new RefSponsorConfiguration();
			newMinAge.setValue(this.minAge);
			newMinAge.setCreateDate(new Date());
			newMinAge.setSponsorId(selectedSponsorId.intValue());
			newMinAge.setName(CONFIG_KEY_MINIMUM_AGE);
			seqNum++;
			newMinAge.setConfigurationId(seqNum);
			refSponsorConfigService.create(newMinAge);
		}

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
				.getRequest();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			RefSponsorDataService refSponsorDataService = (RefSponsorDataService) webAppContext
					.getBean(BEAN_REFSPONSORDATASERVICE);

			try {
				adminService.minAgeChangeNotif((String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN),
						refSponsorDataService.findByPK(selectedSponsorId), minAgeReq, minAge);
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred creating Min Age notification", e);
			}

			setSuccess(true);
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public boolean isDatabaseError() {
		return booleanPropertyMapping.get(IS_DATABASE_ERROR);
	}

	public void setDatabaseError(boolean isDatabaseError) {
		booleanPropertyMapping.replace(IS_DATABASE_ERROR, isDatabaseError);
	}

	public boolean isSuccess() {
		return booleanPropertyMapping.get(IS_SUCCESS);
	}

	public void setSuccess(boolean isSuccess) {
		booleanPropertyMapping.replace(IS_SUCCESS, isSuccess);
	}

	public boolean isConfirmChange() {
		return booleanPropertyMapping.get(IS_CONFIRM_CHANGE);
	}

	public void setConfirmChange(boolean isConfirmChange) {
		booleanPropertyMapping.replace(IS_CONFIRM_CHANGE, isConfirmChange);
	}

	private void buildBooleanPropertyMapping() {
		booleanPropertyMapping = new HashMap<>();
		booleanPropertyMapping.put(IS_DATABASE_ERROR, false);
		booleanPropertyMapping.put(IS_SUCCESS, false);
		booleanPropertyMapping.put(IS_CONFIRM_CHANGE, false);
	}

	private void clearBooleanPropertyValues() {
		setDatabaseError(false);
		setSuccess(false);
		setConfirmChange(false);
	}

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public List<RefSponsor> getSponsorList() {
		return sponsorList;
	}

	public void setSponsorList(List<RefSponsor> sponsorList) {
		this.sponsorList = sponsorList;
	}

	public Long getSelectedSponsorId() {
		return selectedSponsorId;
	}

	public void setSelectedSponsorId(Long selectedSponsorId) {
		this.selectedSponsorId = selectedSponsorId;
	}

	public String getMinAgeReq() {
		return minAgeReq;
	}

	public void setMinAgeReq(String minAgeReq) {
		this.minAgeReq = minAgeReq;
	}

	public String getMinAge() {
		return minAge;
	}

	public void setMinAge(String minAge) {
		this.minAge = minAge;
	}

	public boolean isMinAgeRequired() {
		return "1".equals(minAgeReq);
	}

	public void refreshConfig() {
		setValuesFromDatabase();
	}

	public boolean isDisableAgeInput() {
		return "0".equals(minAgeReq);
	}
}
