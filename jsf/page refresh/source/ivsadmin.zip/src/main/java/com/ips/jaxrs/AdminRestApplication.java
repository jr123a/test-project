package com.ips.jaxrs;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import com.ibm.websphere.jaxrs.providers.json4j.JSON4JObjectProvider;
import com.ips.common.common.CustomLogger;

public class AdminRestApplication extends Application implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    
    
//    @Override
//    public Set<Object> getSingletons(){
//    	ServletContext servletContext = ServletContextHolder.getContext();
//    	if(servletContext ==null) {
//    		throw new IllegalStateException("ServletContext is not available");
//    	}
//    	
//    	ApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
//    	Set<Object> singleton = new HashSet<>();
//    	singleton.add(ctx.getBean(IPSRestResource.class));
//		return singleton;
//    }
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<>();
//        classes.add(JacksonJsonProvider.class);
        classes.add(IPSRestResource.class);
        classes.add(JSON4JObjectProvider.class);
        CustomLogger.debug(this.getClass(), "REST Classes:"+classes);
        return classes;
    }
    
}
