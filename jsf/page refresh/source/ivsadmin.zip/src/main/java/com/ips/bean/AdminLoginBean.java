package com.ips.bean;

import java.io.Serializable;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.JSFUtils;
import com.ips.persistence.common.IVSCookie;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;

@ManagedBean(name = "adminLogin")
@ViewScoped
public class AdminLoginBean extends IPSAdminController implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final int SALT_BYTE_SIZE = 8;
	public static final String HASH_ALGORITH = "PBKDF2WithHmacSHA256";
	public static final String ATTRIBUTE_IVSCOUNT = "IVSCount";
	public static final int DERIVED_KEY_LENGTH = 256;
	public static final int NUM_ITERATIONS = 20000;

	private String username;
	private transient String password;

	public void login() throws NoSuchAlgorithmException, InvalidKeySpecException {
		CustomLogger.enter(this.getClass());
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService service = webAppContext.getBean("AdminService", AdminServiceImpl.class);
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();

			HttpSession session = request.getSession(false);

			if (session != null) {
				Integer count = (Integer) session.getAttribute(ATTRIBUTE_IVSCOUNT);
				if (count == null) {
					session.setAttribute(ATTRIBUTE_IVSCOUNT, 0);
					count = 0;
				}

				if (count.intValue() < 5 && service.login(username, password)) {
					try {
						generateToken(session);
					} catch (NoSuchAlgorithmException nsae) {
						throw new NoSuchAlgorithmException(nsae);
					} catch (InvalidKeySpecException ikse) {
						throw new InvalidKeySpecException(ikse);
					}
					session.setAttribute("IVSToken", username);
					CustomLogger.debug(this.getClass(), "User " + username + " has logged in");
					goToPage(ADMIN_PAGE);
				} else {
					JSFUtils.addFacesErrorMessage("Invalid username/password combination");
					count = count.intValue() + 1;
					if (count.intValue() == 5) {
						service.userLockedOut(username);
					}
					session.setAttribute(ATTRIBUTE_IVSCOUNT, count);
					try {
						Thread.sleep((long) (2000 + count * 2000));
					} catch (InterruptedException e) {
						Thread.currentThread().interrupt();
					}
					CustomLogger.debug(this.getClass(), "User " + username + " has failed to login");
				}
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}

	}

	private static String generateSalt(int n) {
		byte[] bytes = null;
		SecureRandom random = new SecureRandom();
		bytes = new byte[n];
		random.nextBytes(bytes);
		return encodeToBase64(bytes);
	}

	private static String encodeToBase64(byte[] bytes) {
		Base64.Encoder encoder = Base64.getEncoder();
		return encoder.withoutPadding().encodeToString(bytes);
	}

	private static byte[] decodeFromBase64(String base64String) {
		Base64.Decoder decoder = Base64.getDecoder();
		return decoder.decode(base64String);
	}

	private static String hashAndEncodePassword(String password, String salt)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		CustomLogger.enter(AdminLoginBean.class.getClass());
		// Convert salt string to byte array
		byte[] saltBytes = decodeFromBase64(salt);
		// Convert password characters to a password-based encryption (PBE) key
		KeySpec spec = new PBEKeySpec(password.toCharArray(), saltBytes, NUM_ITERATIONS, DERIVED_KEY_LENGTH);
		SecretKeyFactory f = null;
		byte[] hashedPswd = null;
		// Create a secret key factory instatnce for PBKDF2WithHmacSHA256
		try {
			f = SecretKeyFactory.getInstance(HASH_ALGORITH);
		} catch (NoSuchAlgorithmException nsae) {
			throw new NoSuchAlgorithmException(nsae);
		}
		// Generate a secret key object from the key specification
		try {
			hashedPswd = f.generateSecret(spec).getEncoded();
		} catch (InvalidKeySpecException ikse) {
			throw new InvalidKeySpecException(ikse);
		}
		return encodeToBase64(hashedPswd);
	}

	protected void generateToken(HttpSession session) throws NoSuchAlgorithmException, InvalidKeySpecException {
		CustomLogger.enter(this.getClass());
		String encToken = null;
		try {
			encToken = hashAndEncodePassword(password, generateSalt(SALT_BYTE_SIZE));
		} catch (NoSuchAlgorithmException nsae) {
			throw new NoSuchAlgorithmException(nsae);
		} catch (InvalidKeySpecException ikse) {
			throw new InvalidKeySpecException(ikse);
		}
		IVSCookie ivsCookie = new IVSCookie(encToken);
		session.setAttribute("IVSID", ivsCookie.getCookieValue());
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
