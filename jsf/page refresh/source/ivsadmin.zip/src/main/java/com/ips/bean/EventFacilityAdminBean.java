package com.ips.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import com.ips.common.Paginator;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.JSFUtils;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.IppEvent;
import com.ips.entity.RefFacFacility;
import com.ips.persistence.common.IPSConstants;
import com.ips.service.IppEventService;
import com.ips.service.RefFacFacilityService;

@ManagedBean(name="eventFacilityAdmin")
@ViewScoped
public class EventFacilityAdminBean extends IPSAdminController implements Serializable {

    private static final long serialVersionUID = 1L;
    private List<IppEvent> ippEvents;
    private List<RefFacFacility> facilitiesInGrid;
    private boolean noFacilitiesFound = false;
    private boolean initialized = false;
    private List<String> monthList;
    private String selectedMonth;
    private String selectedSearch;
    private String searchNumber = null;
    private String browserName;
    private Paginator paginator;
    private IppEvent selectedEvent;
    private RefFacFacility selectedFacility;
    private static final String IPP_EVENT_SVC = "ippEventService";
    
    @PostConstruct
    public void init() {
        CustomLogger.enter(this.getClass());
        if (initialized) {
            return;
        }
        
        initialized = true;
        paginator = new Paginator(this);
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        browserName = Utils.getBrowserName(request);
    }

    public void loadMonthsForEventsWithoutFacilities() {
        CustomLogger.enter(this.getClass());
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        IppEventService service = (IppEventService)SpringUtil.getInstance(ctx).getBean(IPP_EVENT_SVC);
                
        try {
            monthList = service.findMonthsForEventsWithNoFacility();
        } 
        catch(Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred finding months for events with no facility: ",e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }

    public void resetSelections() {
        CustomLogger.enter(this.getClass());
        facilitiesInGrid = Collections.emptyList();
        selectedEvent = null;
        selectedFacility = null;
    }
    
    public void findFacilitiesInGrid() {
        CustomLogger.enter(this.getClass());
        facilitiesInGrid = Collections.emptyList();
    
        if (selectedEvent == null) {
            JSFUtils.addFacesErrorMessage("An event must be selected when searching for facilities in the grid.");
            return;
        }
        
        String proofingLocation = selectedEvent.getInPersonProofingLocation();
        if (proofingLocation != null && !proofingLocation.contains(",")) {            
            JSFUtils.addFacesErrorMessage("The proofing location for the event must contain coordinates when searching for facilities in the grid.");
            return;
        }
        
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        RefFacFacilityService service = (RefFacFacilityService)SpringUtil.getInstance(ctx).getBean("refFacFacilityService");
        
        try {
            facilitiesInGrid = service.findFacilitiesInGrid(proofingLocation);
        } 
        catch(Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred finding events with no facility: ",e);
            goToPage(SYSTEM_ERROR_PAGE);
        }

        setNoFacilitiesFound(facilitiesInGrid == null || facilitiesInGrid.isEmpty());
    }

    public void assignFacility() {
        CustomLogger.enter(this.getClass());
        if (ippEvents == null || selectedEvent == null) {
            JSFUtils.addFacesErrorMessage("An event must be selected when assigning a facility.");
            return;
        }
        else if (facilitiesInGrid == null || selectedFacility == null) {
            JSFUtils.addFacesErrorMessage("A facility must be selected to assign to the event.");
            return;
        }     

        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        IppEventService service = (IppEventService)SpringUtil.getInstance(ctx).getBean(IPP_EVENT_SVC);

        selectedEvent.setRefFacFacility(selectedFacility);
        selectedEvent.setUpdateDate(new Date());
        
        try {
               service.update(selectedEvent);
            loadEventsForMonth();
            facilitiesInGrid = Collections.emptyList();
        } 
        catch(Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred assigning facility to event: ", e);
            goToPage(SYSTEM_ERROR_PAGE);
        }

        setSearchNumber("");
    }
    
    public void markAsTestEvent() {
        CustomLogger.enter(this.getClass());
        if (facilitiesInGrid != null) {
            facilitiesInGrid = Collections.emptyList();
        }
    
        if (selectedEvent == null) {
            JSFUtils.addFacesErrorMessage("No events were selected to be marked as test events.");
            return;
        }
                 
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        IppEventService service = (IppEventService)SpringUtil.getInstance(ctx).getBean(IPP_EVENT_SVC);
        selectedEvent.setInPersonProofingType("T");
        selectedEvent.setUpdateDate(new Date());
    
        try {
            service.update(selectedEvent);
        } 
        catch(Exception e) {
                        CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred marking event as test: ",e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
        
        loadMonthsForEventsWithoutFacilities();
        loadEventsForMonth();
        setSearchNumber("");
    }

    public List<IppEvent> getIppEvents() {
        return ippEvents;
    }

    public void setIppEvents(List<IppEvent> ippEvents) {
        this.ippEvents = ippEvents;
    }

    public List<RefFacFacility> getFacilitiesInGrid() {
        return facilitiesInGrid;
    }

    public void setFacilitiesInGrid(List<RefFacFacility> facilitiesInGrid) {
        this.facilitiesInGrid = facilitiesInGrid;
    }

    public boolean isNoFacilitiesFound() {
        return noFacilitiesFound;
    }

    public void setNoFacilitiesFound(boolean noFacilitiesFound) {
        this.noFacilitiesFound = noFacilitiesFound;
    }
    
    public List<String> getMonthList() {
        return monthList;
    }

    public void setMonthList(List<String> monthList) {
        this.monthList = monthList;
    }

    public String getSelectedMonth() {
        return selectedMonth;
    }

    public void setSelectedMonth(String selectedMonth) {
        this.selectedMonth = selectedMonth;
    }
    
    /*
     * The selectMonth method is called by an event listener when the user
     * changes the month and year on the Correct Facility tab.
     */
    public void selectMonth(ValueChangeEvent vcEvent) {
        CustomLogger.enter(this.getClass());
         ippEvents = Collections.emptyList();
         facilitiesInGrid = Collections.emptyList();
         selectedMonth = (String)vcEvent.getNewValue();
         
         if (!StringUtils.isEmpty(selectedMonth)) {          
                paginator.initPaginatorProperties();
             loadEventsForMonth();
         }
    }
    
    public void loadEventsForMonth() {
        CustomLogger.enter(this.getClass());
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        IppEventService service = (IppEventService)SpringUtil.getInstance(ctx).getBean(IPP_EVENT_SVC);
            
        String firstDay = selectedMonth + "-01";
        CustomLogger.debug(this.getClass(), "First day is: " + firstDay);
        Date monthStart = DateTimeUtil.getDate(firstDay, "yyyy-MM-dd");
        // Add midnight
        Timestamp monthStartDateTime = new Timestamp(DateTimeUtil.getStartDate(monthStart).getTime());
        Timestamp monthEndDateTime = new Timestamp(DateTimeUtil.getDatePlusMonths(monthStart, 1).getTime());
        
        CustomLogger.debug(this.getClass(), "Start date for events is: " + monthStartDateTime + ", End date for events is: " + monthEndDateTime);
        
        try {
            if (paginator.isResetTotalCount()) {
                long totalRowCount = service.getEventsWithNoFacilityCountByMonth(monthStartDateTime, monthEndDateTime);    
                paginator.updateTotalCount(totalRowCount);
            }
            
            ippEvents = service.findEventsWithNoFacilityByMonth(monthStartDateTime, monthEndDateTime, paginator.getFirstResult(), paginator.getMaxResults());
            paginator.updateRowRange();
        } 
        catch(Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred finding events with no facility: ",e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }
    
    public String getSelectedSearch() {
        return selectedSearch;
    }

    public void setSelectedSearch(String selectedSearch) {
        this.selectedSearch = selectedSearch;
    }

    public String getSearchNumber() {
        return searchNumber;
    }

    public void setSearchNumber(String searchNumber) {
        this.searchNumber = searchNumber;
    }
    
    private boolean isValidSearch() {
        CustomLogger.enter(this.getClass());
        boolean valid = true;
        
        if (searchNumber == null) {
            JSFUtils.addFacesErrorMessage("A finance number or facility ID must be entered.");
            valid = false;
        }
        else {
            searchNumber = searchNumber.trim();
            
            if (StringUtils.isEmpty(searchNumber)) {
                JSFUtils.addFacesErrorMessage("A finance number or facility ID must be entered.");
                valid = false;
            }
            else {
                if (!Utils.isNumeric(searchNumber)) {
                    JSFUtils.addFacesErrorMessage("Search Data must be numeric.");
                    valid = false;
                }
            }
        }
        
        return valid;
    }
    
    public void findFacilities() {
        CustomLogger.enter(this.getClass());
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        RefFacFacilityService service = (RefFacFacilityService)SpringUtil.getInstance(ctx).getBean("refFacFacilityService");
            
        if (isValidSearch()) {
            try {
                if ("1".equals(selectedSearch)) {
                    RefFacFacility facility = service.findByFinanceNumber(searchNumber);
                    facilitiesInGrid = new ArrayList<>();
                    if (facility != null) {
                        facilitiesInGrid.add(facility);
                    }
                }
                else if ("2".equals(selectedSearch)) {
                    long facilityId = Long.parseLong(searchNumber);
                    facilitiesInGrid = service.findByFacilityId(facilityId);
                }
                        
                if (facilitiesInGrid == null) {
                    setNoFacilitiesFound(true);
                }
                else {
                    setNoFacilitiesFound(facilitiesInGrid.isEmpty());
                }
            }
            catch(Exception e) {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred finding events with no facility: ",e);
                goToPage(SYSTEM_ERROR_PAGE);
            }
        }
    }

    public void selectIppEvent(ValueChangeEvent event) {
        FacesContext context = FacesContext.getCurrentInstance();
        selectedEvent = context.getApplication().evaluateExpressionGet(context, "#{dataRow}", IppEvent.class);
    }
    
    public void selectRefFacFacility(ValueChangeEvent event) {
        FacesContext context = FacesContext.getCurrentInstance();
        selectedFacility = context.getApplication().evaluateExpressionGet(context, "#{dataRow}", RefFacFacility.class);
    }
    
    public Paginator getPaginator() {
        return paginator;
    }

    public void setPaginator(Paginator paginator) {
        this.paginator = paginator;
    }

    public String getBrowserName() {
        return browserName;
    }

    public void setBrowserName(String browserName) {
        this.browserName = browserName;
    }

    public IppEvent getSelectedEvent() {
        return selectedEvent;
    }

    public void setSelectedEvent(IppEvent selectedEvent) {
        this.selectedEvent = selectedEvent;
    }

    public RefFacFacility getSelectedFacility() {
        return selectedFacility;
    }

    public void setSelectedFacility(RefFacFacility selectedFacility) {
        this.selectedFacility = selectedFacility;
    }
}
