package com.ips.service;

import java.util.List;

import com.ips.entity.RpAdmin;

public interface AdminEventService {
    void logAdminEvent(String userId, String eventDescription);
    void logAdminEvent(String userId, String eventDescription, Long sponsorId);
    void logAdminEvent(String userId, String eventDescription, Long sponsorId, Long appId);
    String getAdminEventDescription(String userId);
    List<RpAdmin> findRpAdminBySponsor(long sponsorId);
    void save(RpAdmin entity);
    void update(RpAdmin entity);
    void deleteRpAdmin(RpAdmin entity);
}
