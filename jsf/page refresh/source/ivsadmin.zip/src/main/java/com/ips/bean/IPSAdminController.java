package com.ips.bean;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Properties;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.richfaces.event.ItemChangeEvent;

import com.ips.common.IVSAdminConstants;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.Utils;
import com.ips.polocator.common.AppointmentVo;

public class IPSAdminController implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    protected static final String SYSTEM_ERROR_PAGE = "systemError.xhtml";
    protected static final String VERIFICATION_ERROR_PAGE = "verification_error.xhtml";
    protected static final String ADMIN_PAGE = "home.xhtml";
    protected static final String ADMIN_LOGIN_PAGE = "login.xhtml";
    private static final String RETRY_LOGOUT = "com.usps.custreg.LOGOUT";
    protected static final String IPP_FACILITIES_ADMIN_PAGE = "ipp_facilities_admin.xhtml";
    protected static final String IPP_ADD_USPS_LOCATION_PAGE = "ipp_facilities_admin2.xhtml";
    protected static final String FACILITY_CORRECTION_PAGE = "correct_facility_admin.xhtml";
    protected static final String ANALYTICS_PAGE = "analytics_admin.xhtml";
    protected static final String DEVICE_REPUTATION = "device_reputation.xhtml";
    protected static final String SPONSOR_FACILITIES = "sponsor_facilities.xhtml";
    protected static final String SPONSOR_EMAILS = "sponsor_emails.xhtml";
    protected static final String SPONSOR_REPORTS = "sponsor_reports.xhtml";

    protected static final String LOCATIONS_ADDED = "locsAdded";
    protected static final String ALL_LOCATIONS_ADDED = "allLocsAdded";
    
    private static final String ALLOWED_DOMAIN = "com.ips.allowedDomains";
    private static final String IPS_PROPERTIES = "/ips.properties";
    private static String allowedDomain = null;
    
    
    static {
        Properties prop = new Properties();
        try {
            prop.load(IPSAdminController.class.getResourceAsStream(IPS_PROPERTIES));
            String env = Utils.getEnvironment();
            allowedDomain = prop.getProperty(env.concat(ALLOWED_DOMAIN));
        } catch (IOException e) {
            CustomLogger.error(IPSAdminController.class.getClass(), "Problem loading property file for Allowed Domain", e);
        }
    }
    
    public void logout() {
        HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
        Properties prop = new Properties();
        String env = Utils.getEnvironment();
        String retryLoginUrl = null;
        destroySession();
        try {
            prop.load(IPSAdminController.class.getResourceAsStream(IPS_PROPERTIES));
            retryLoginUrl = prop.getProperty(env.concat(RETRY_LOGOUT));
            response.sendRedirect(retryLoginUrl);
        }
        catch (IOException e) {
            CustomLogger.error(this.getClass(), IVSAdminConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "An error occurred redirecting to the logout page with URL: " + retryLoginUrl, e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }
    
    
    private void destroySession() {
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        
        session.invalidate();
        
    }


    public void goToPage(String nextPage)
    {
        String nextPageUrl = null;
        
        try {
            nextPageUrl = ((HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest()).getContextPath() + "/" + nextPage;
            CustomLogger.debug(this.getClass(), "goToPage() page=" + nextPageUrl);
            FacesContext.getCurrentInstance().getExternalContext().redirect(nextPageUrl);
        } 
        catch (Exception ex) {
            CustomLogger.error(this.getClass(), "Could not redirect to page: " + nextPageUrl, ex);
        }
    } 
    
    
    public AppointmentVo getSessionAppointment(){
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        return (AppointmentVo) session.getAttribute(IVSAdminConstants.APPOINTMENT_KEY);
    }
    
    public void setSessionLocsAdded(boolean locationsAdded){
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        session.setAttribute(LOCATIONS_ADDED, locationsAdded);
    }    
    
    public void setSessionAllLocsAdded(boolean allLocationsAdded){
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        session.setAttribute(ALL_LOCATIONS_ADDED, allLocationsAdded);
    }
    
    
    public void returnToCallingApp() {
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
        HttpSession session = request.getSession();
        
        String callingApp = null;
        String nextPage = null;
        
        try {
            if (session != null) {
                callingApp = (String) session.getAttribute(IVSAdminConstants.CALLING_APP_KEY);
                if (callingApp == null) {
                    goToPreferences();
                }
                else {
                    if (isCallingAppAllowed(callingApp)) {
                        response.sendRedirect(callingApp);
                    }
                    else {
                        CustomLogger.debug(this.getClass(), "Illegal appURL value: " + callingApp + " redirecting to allowed domain");
                        response.sendRedirect(allowedDomain);
                    }
                }
            }
        }
        catch (IOException e) {
            CustomLogger.error(this.getClass(), IVSAdminConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred redirecting to application URL: " + callingApp, e);
            nextPage = SYSTEM_ERROR_PAGE;
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), IVSAdminConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred redirecting to application URL: " + callingApp, e);
            nextPage = SYSTEM_ERROR_PAGE;
        }
        
        if (nextPage != null){
            goToPage(nextPage);
        }
    }
    
    public void goToPreferences() {
        Properties prop = new Properties();
        String nextPage = null;
        
        try {
            prop.load(IPSAdminController.class.getResourceAsStream(IPS_PROPERTIES));
            String environment = Utils.getEnvironment();
            String propName = environment.concat("com.usps.ips.CUSTREG_PREFERENCES_URL");
            String url = prop.getProperty(propName);
            HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
            CustomLogger.debug(this.getClass(), "IPSController.redirecting to url " + propName);
            response.sendRedirect(url);
        } catch (FileNotFoundException e) {
            CustomLogger.error(this.getClass(), IVSAdminConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Can not find properties file.",e);
            nextPage = SYSTEM_ERROR_PAGE;
        } catch (IOException e) {
            CustomLogger.error(this.getClass(), IVSAdminConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Something went wrong with the properties file",e);
            nextPage = SYSTEM_ERROR_PAGE;
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), IVSAdminConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred when routing to CustReg preferences page", e);
            nextPage = SYSTEM_ERROR_PAGE;
        }
        
        if (nextPage != null){
            goToPage(nextPage);
        }
    }
    
    public void goToProfile() {
        Properties prop = new Properties();
        String nextPage = null;
        
        try {
            prop.load(IPSAdminController.class.getResourceAsStream(IPS_PROPERTIES));
            String environment = Utils.getEnvironment();
            String propName = environment.concat("com.usps.ips.CUSTREG_PROFILE_URL");
            String url = prop.getProperty(propName);
            HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
            CustomLogger.debug(this.getClass(), "IPSController.redirecting to url " + propName);
            response.sendRedirect(url);
        } catch (FileNotFoundException e) {
            CustomLogger.error(this.getClass(), IVSAdminConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Can not find properties file.",e);
            nextPage = SYSTEM_ERROR_PAGE;
        } catch (IOException e) {
            CustomLogger.error(this.getClass(), IVSAdminConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Something went wrong with the properties file",e);
            nextPage = SYSTEM_ERROR_PAGE;
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), IVSAdminConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred when routing to CustReg profile page", e);
            nextPage = SYSTEM_ERROR_PAGE;
        }
        
        if (nextPage != null){
            goToPage(nextPage);
        }
    }
    
    protected String getClientIpAddress(HttpServletRequest request) {
        // Get IP from request header populated by CustReg
        String clientIP = request.getHeader(IVSAdminConstants.CLIENT_IP);
        CustomLogger.debug(this.getClass(), IVSAdminConstants.CLIENT_IP + " = " + clientIP);

        if (StringUtils.isBlank(clientIP)) {
            clientIP = request.getHeader(IVSAdminConstants.NS_CLIENT_IP);
            CustomLogger.debug(this.getClass(), IVSAdminConstants.NS_CLIENT_IP + " = " + clientIP);

            // If CustReg header not populated get IP directly from client or last server that sent request
            if (StringUtils.isBlank(clientIP)) {
                clientIP = request.getRemoteAddr();
                CustomLogger.debug(this.getClass(), "IP address of the client or last proxy that sent the request = "    + clientIP);
            }
        }
        
        if (Utils.isValidIpAddress(clientIP)) {
            return clientIP;
        }
        else {
            CustomLogger.warn(this.getClass(), "WARNING: Invalid IP address found: " + clientIP);
            return "";
        }
    }
    
    public String getAppointmentCanceledMessage() {
        AppointmentVo appt = getSessionAppointment();
        SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd");
        String scheduledDate = sdf.format(appt.getScheduledDate());
        return "Your appointment for " + scheduledDate + " at " + appt.getScheduledTime() + " has been canceled.";
    }
    
    public boolean isAppointmentCanceled() {
        AppointmentVo appt = getSessionAppointment();
        if(appt != null){
            return appt.isCanceled();
        }
        return false; 
    }
    
    protected boolean isCallingAppAllowed(String callingApp) {
        return callingApp.startsWith(allowedDomain);
    }
    
    public void onTabChange(ItemChangeEvent event) {
        CustomLogger.enter(this.getClass());
        String tabName = event.getNewItemName();

         switch(tabName) {
             case "supplierConfig": 
                 goToOtpConfigPage();
                 break;
             case "activeFacility": 
                 goToFacilitiesPage();
                 break;
             case "updateFacility": 
                 goToAddFacilitiesPage();
                 break;
             case "correctFacility": 
                 goToFacilityCorrectionPage();
                 break;
             case "analytics": 
                 goToAnalyticsPage();
                 break;
             case "deviceReputation": 
                 goToDeviceReputationPage();
                 break;
             case "sponsorFacilities":
                 goToSponsorFacilitiesPage();
                 break;
             case "sponsorEmails":
                 goToSponsorEmailsPage();
                 break;
             case "sponsorReports":
                 goToSponsorReportsPage();
                 break;
             default:
        }
   }
    public void goToOtpConfigPage(){
        goToPage(ADMIN_PAGE);
    }
    
    public void goToFacilitiesPage(){
        goToPage(IPP_FACILITIES_ADMIN_PAGE);
    }
    
    public void goToAddFacilitiesPage(){
        goToPage(IPP_ADD_USPS_LOCATION_PAGE);
    }
    
    public void goToFacilityCorrectionPage(){
        goToPage(FACILITY_CORRECTION_PAGE);
    }
    
    public void goToAnalyticsPage() {
        goToPage(ANALYTICS_PAGE);
    }
    
    public void goToDeviceReputationPage() {
        goToPage(DEVICE_REPUTATION);
    }
    
    public void goToSponsorFacilitiesPage() {
        goToPage(SPONSOR_FACILITIES);
    }
    
    public void goToSponsorEmailsPage() {
        goToPage(SPONSOR_EMAILS);
    }
    
    public void goToSponsorReportsPage() {
        goToPage(SPONSOR_REPORTS);
    }
}
