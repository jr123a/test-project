package com.ips.bean;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.equifax.common.AdditionalErrorDetailModel;
import com.equifax.common.ConsumerIdentifierModel;
import com.equifax.dit.request.DataModel;
import com.equifax.dit.request.EmailModel;
import com.equifax.dit.request.IdentityModel;
import com.equifax.dit.request.InitiateDITRequestModel;
import com.equifax.dit.request.NameModel;
import com.equifax.dit.request.PhoneModel;
import com.equifax.dit.response.DetailModel;
import com.equifax.dit.response.InitiateDITResponseModel;
import com.equifax.smfa.request.InitiateSMFARequestModel;
import com.equifax.smfa.request.StatusSMFARequestModel;
import com.equifax.smfa.response.InitiateSMFAResponseModel;
import com.equifax.smfa.response.OtpLifecycleModel;
import com.equifax.smfa.response.ResponseStatusModel;
import com.equifax.smfa.response.StatusSMFAResponseModel;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.ibm.json.java.JSONObject;
import com.ips.common.OtpConfigVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.OtpLockoutInfo;
import com.ips.entity.Person;
import com.ips.entity.PersonData;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefApp;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefOtpVelocity;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpDeviceReputation;
import com.ips.entity.RpDeviceReputationResponse;
import com.ips.entity.RpDitResponse;
import com.ips.entity.RpEvent;
import com.ips.entity.RpOtpAttempt;
import com.ips.entity.RpPhoneVerification;
import com.ips.entity.RpPhoneVerificationResult;
import com.ips.entity.RpSmfaAttempt;
import com.ips.entity.RpSmfaInitiateResponse;
import com.ips.entity.RpSmfaValidateResponse;
import com.ips.entity.RpSupplierToken;
import com.ips.entity.RpTruthDataSendResponse;
import com.ips.entity.SponsorApplicationMap;
import com.ips.persistence.common.AuditPersonVo;
import com.ips.persistence.common.ExperianResultVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.NameValueVo;
import com.ips.persistence.common.PersonVo;
import com.ips.proofing.CommonRestService;
import com.ips.proofing.CommonRestServiceImpl;
import com.ips.proofing.EquifaxService;
import com.ips.proofing.EquifaxServiceImpl;
import com.ips.proofing.ExperianService;
import com.ips.proofing.ExperianServiceImpl;
import com.ips.proofing.ManageEventService;
import com.ips.proofing.ProofingService;
import com.ips.proofing.ProofingServiceImpl;
import com.ips.proofing.VerificationProviderService;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;
import com.ips.service.DeviceReputationServiceImpl;
import com.ips.service.EquifaxDataService;
import com.ips.service.OtpAttemptConfigService;
import com.ips.service.OtpLockoutInfoService;
import com.ips.service.PersonDataService;
import com.ips.service.RefAppService;
import com.ips.service.RefLoaLevelService;
import com.ips.service.RefOtpSupplierDataService;
import com.ips.service.RefOtpVelocityDataService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;
import com.ips.service.RpDeviceReputationResponseService;
import com.ips.service.RpDeviceReputationService;
import com.ips.service.RpDitResponseService;
import com.ips.service.RpEventDataService;
import com.ips.service.RpInfPvAttemptConfigService;
import com.ips.service.RpOtpAttemptDataService;
import com.ips.service.RpSmfaAttemptDataService;
import com.ips.service.RpSmfaInitiateResponseService;
import com.ips.service.RpSmfaValidateResponseService;
import com.ips.service.RpSupplierTokenService;
import com.ips.service.RpTruthDataSendResponseService;
import com.ips.service.SponsorApplicationMapService;
import com.lexisnexis.ns.identity_proofing._1.RdpDeviceAssessmentResponseModel;
import com.lexisnexis.ns.identity_proofing._1.RdpPassThroughDataModel;
import com.lexisnexis.ns.identity_proofing._1.RdpPassThroughModel;
import com.lexisnexis.ns.identity_proofing._1.RdpPassThroughResponseModel;
import com.lexisnexis.ns.identity_proofing._1.RdpPassThroughResponseSummaryModel;
import com.lexisnexis.ns.identity_proofing._1.RdpProductModel;
import com.lexisnexis.ns.identity_proofing._1.RdpReasonCodeModel;
import com.lexisnexis.ns.identity_proofing._1.RdpStatusModel;
import com.lexisnexis.ns.identity_proofing._1.RdpTrustDefenderResponseExModel;

@ManagedBean(name="unitTestingPortalBean")
@ViewScoped
public class UnitTestingPortalAdminBean extends IPSAdminController implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private static final String DBL_ENTRY_VALUE_FMT = "%s %s";
    private static final String NEXT_AVAIL_SUPP_MSG_FMT = "Next available supplier is %s.";
    private static final String ALL_AVAIL_SUPP_FAILED_MSG_FMT = "All calls to available suppliers failed. Route User to In Person Proofing for sponsorUserId: %s.";
    public static final String CALL_TO_SUPP_FAILED_MSG_FMT = "Call to %s VerifyPhone failed. Determine next available supplier.";
    private static final String OTP_SWITCHING_ENABLED_MSG_FMT = "OTP Switching Is Not Enabled (100 Pct %s). Route User to In Person Proofing for sponsorUserId: %s.";
    private static final String TOKEN_PROMPT = "Token:";
    
    AdminService adminService;
    CommonRestService commonRestService;
    EquifaxDataService equifaxDataService;
    EquifaxService equifaxService;
    ExperianService experianService;
    ManageEventService manageEventService;
    OtpAttemptConfigService otpAttemptConfigService;
    OtpLockoutInfoService lockoutService;
    PersonVo personVo;
    ProofingService proofingService;
    PersonDataService personService;
    RefAppService refAppService;
    RefLoaLevelService refLoaLevelService;
    RefOtpSupplierDataService refOtpSupplierDataService;
    RefOtpVelocityDataService refOtpVelocityService;
    RefSponsorConfigurationService refSponsorConfigurationService;
    RefSponsorDataService sponsorDataService;
    RpDeviceReputationService rpDeviceReputationService;
    RpDeviceReputationResponseService rpDeviceReputationResponseService;
    RpDitResponseService rpDitResponseService;
    RpEventDataService rpEventDataService;
    RpInfPvAttemptConfigService rpInfPvAttemptConfigService;
    RpOtpAttemptDataService rpOtpAttemptDataService;
    RpSmfaAttemptDataService rpSmfaAttemptService;
    RpSmfaInitiateResponseService rpSmfaInitiateResponseService;
    RpSmfaValidateResponseService rpSmfaValidateResponseService;
    RpSupplierTokenService rpSupplierTokenService;
    RpTruthDataSendResponseService rpTruthDataSendResponseService;
    SponsorApplicationMapService sponsorApplicationMapService;
    VerificationProviderService verificationProviderService;

    ServletContext context; 
    
    /*******  Supplier Options / User Options / Environment Options / Predefined Experian Responses ************/
    
    List<ExperianResultVo> userOptionList;
    List<NameValueVo> altCredSettingList; 
    boolean useExpUatEnvironment;
    boolean useJwtAlternativeCredential;
    boolean useXcoreAlternativeCredential;
    boolean useJwtAlternativeEndpoint;
    boolean useXCoreAlternativeEndpoint;
    boolean enforceSupplierOption;
    boolean showAltCredSettingSuccessMsg;
    boolean showAltCredSettingErrorMsg;
    boolean showAltCredOptionSuccessMsg;
    boolean showAltCredOptionErrorMsg;
    boolean showSponsorConfigSetterSuccessMsg;
    boolean showSponsorConfigSetterErrorMsg;
    int supplierOptionSponsorId;
    int userOptionSponsorId;
    int altCredSponsorId;
    int environmentOptionSponsorId;
    int altCredEndptOptionSponsorId;
    int genericConfigSponsorId;
    String otpFlowUserIndex;
    String silentAuthFlowUserIndex;
    String bokuOtpFlowUserIndex;
    String predefinedUserIndex;
    String infAltSupplierId;
    String cnfAltSupplierId;
    String altCredSettingIndex;
    String altCredentialType;
    String altCredentialCode;
    String altCredentialValue;
    String sponsorConfigName;
    String sponsorConfigValue;
    String altCredSettingSuccessMsg;
    String altCredSettingErrorMsg;
    String altCredOptionSuccessMsg;
    String altCredOptionErrorMsg;
    String sponsorConfigSetterSuccessMsg;
    String sponsorConfigSetterErrorMsg;
    
    /*******  Experian Test User Orchestration Decisions / Test Passcodes ************/
    List<RefApp> appList;
    RefApp userApp;
    int userDecisionSponsorId;
    long userAppId;
	String expFirstName;
	String expLastName;
	String expEmailAddress;
	String exptreetAddress;
	String expCity;
	String expState;
	String expZip5;
	String expMobileNumber;
	String expSponsorUserId;

    String testUserIndex;
    String requestType;
    String ccRequestJson;
    String orchDecisionJson;
    String pidUsername;
    String pidPasscode;
    String jwtUsername;
    String jwtPasscode;
    String experianJwt; 
    
    /*******  Lockout Window Configuration************/
    
    List<RefOtpSupplier> refOtpSupplierList;
    int selectedOtpSupplierId;
    int phoneAttemptsWindow;
    int passcodeAttemptsWindow;
    int phoneAttemptsAllowed;
    int passcodeAttemptsAllowed;
    
    /*******  Equifax DIT Web Service ************/
   
    InitiateDITRequestModel ditInitiateRequest;
    InitiateDITResponseModel ditInitiateResponse;
    List<TestCaseVo> ditTestCaseList;
    List<TestCaseVo> ditSelectedTestCaseList;
    Map<String, Object> ditTestCaseMap;
    String efxDitFirstName;
    String efxDitMiddleName;
    String efxDitLastName;
    String efxDitStreetAddress;
    String efxDitCity;
    String efxDitState;
    String efxDitZip5;
    String efxDitEmail;
    String efxDitMobileNum;
    String efxDitJsonRequest;
    String efxDitJsonResponse;
    String ditInitiateRequestStr;
    String ditInitiateResponseStr;
    String ditSelectedTestCaseId;

    boolean isInitialized;
    boolean showEfxDitRequestJsonPanel;
    boolean showEfxDitResponseJsonPanel;
    boolean showEfxDitSubmitBtn;
    boolean showEfxDitGetDecisionBtn;
    boolean showEfxDitTrustDecisionPanel;
   
    /*******  Equifax SMFA Initiate Web Service ************/
    
    InitiateSMFARequestModel smfaInitiateRequest;
    InitiateSMFAResponseModel smfaInitiateResponse;
    String efxSmfaSponsorUserId;
    String efxSmfaInitMobileNum;
    String efxSmfaInitJsonRequest;
    String efxSmfaInitJsonResponse;
    String smfaInitiateRequestStr;
    String smfaInitiateResponseStr;
    String smfaInitiateResponseSessionId; 
    String smfaInitiateToken; 
    
    boolean showEfxSmfaInitRequestJsonPanel;
    boolean showEfxSmfaInitResponseJsonPanel;
    boolean showEfxSmfaInitSubmitBtn;
    
    /*******  Equifax SMFA Status Web Service ************/
    
    StatusSMFARequestModel smfaStatusRequest;
    StatusSMFAResponseModel smfaStatusResponse;
    String efxSmfaStatMobileNum;
    String efxSmfaStatJsonRequest;
    String efxSmfaStatJsonResponse;
    String smfaStatusRequestStr;
    String smfaStatusResponseStr;

    boolean showEfxSmfaStatRequestJsonPanel;
    boolean showEfxSmfaStatResponseJsonPanel;
    boolean showEfxSmfaStatSubmitBtn;
    
    /*******  Phone Verification Supplier Determination (Main) ************/

    private List<OtpConfigVo> otpSupplierList;
    private List<RefSponsor> rpSponsorList;
    String pvSupplierSelected;
    String supplierDetermineSuccessMsg;
    String supplierDetermineErrorMsg;
    long supplierDetSponsorId;
    boolean failedEquifaxOTP;
    boolean failedEquifaxDIT;
    boolean failedLexisNexisRDP;
    boolean failedExperianCC;
    boolean showSupplierDetermineSuccessMsg;
    boolean showSupplierDetermineErrorMsg;
    
    /*******  Phone Verification Supplier Determination (Inf) ************/

    private List<OtpConfigVo> otpSupplierList2;
    String pvSupplierSelected2;
    String supplierDetermine2SuccessMsg;
    String supplierDetermine2ErrorMsg;
    long supplierDetSponsorId2;
    boolean failedEquifaxOTP2;
    boolean failedEquifaxDIT2;
    boolean failedLexisNexisRDP2;
    boolean failedExperianCC2;
    boolean showSupplierDetermine2SuccessMsg;
    boolean showSupplierDetermine2ErrorMsg;
    
    /*******  Phone Remote Proofing Status Detail ************/

    private List<RefSponsor> rpAllRemoteProofingSponsorList;
    private List<RpEvent> rpEventList;
    List<RpSmfaAttempt> rpSmfaAttemptList;
    List<RpOtpAttempt> rpOtpAttemptList;
    private List<PhoneAttemptVo> rpPhoneAttemptList;
    private List<OtpLinkAttemptVo> rpOtpLinkAttemptList;
    private List<AuditPersonVo> rpAuditPersonList;
    private List<RpDeviceReputation> rpDeviceReputationList;
    private List<DeviceReputationResponseVo> rpDeviceReputationResponseList;
    private List<DitResponseVo> rpDitResponseList;
    private List<RpEvent> rpRemoteProofingEventList;
    private List<PhoneVerificationsVo> rpPhoneVerificationsList;
    private List<PhoneVerificationResultVo> rpPhoneVerificationResultList;
    private List<SmfaInitiateResponseVo> rpSmfaInitiateResponseList;
    private List<SmfaValidateResponseVo> rpSmfaValidateResponseList;
    private List<TruthDataSendResponseVo> rpTruthDataSendResponseList;
    private RefSponsor rpRefSponsor;
    private Person rpPerson;
    private RefOtpSupplier rpPhoneSupplier;
    private RefOtpVelocity rpVelocity;

	String rpPhoneSponsorUserId;
    Long rpSelectedRefSponsorId;
    Long rpPersonId;
    Long rpNumPhoneAttempts;
    int rpNumOtpLinkAttempts;
    int rpPhoneAttemptLimit;
    int rpOtpLinkAttemptLimit;
    int rpPhoneAttemptWindow;
    int rpOtpLinkAttemptWindow;
    String rpFirstLastName;
    String rpEmailAddress;
    String rpRemoteProofingStatus;
    String rpPhoneLockoutInEffect;
    String rpPhoneLockoutSupplier;
    String rpPhoneLockoutExpirationDateTime;
    String rpPhoneAttemptWindowDateTime;
    String rpRetrieveStatusInstMsg;
    String rpRetrieveStatusErrorMsg;
    String rpRetrieveStatusSuccessMsg;
    boolean showRetrieveStatusInstMsg;
    boolean showRetrieveStatusErrorMsg;
    boolean showRetrieveStatusSuccessMsg;

    @PostConstruct
    public void init(){   
       CustomLogger.enter(this.getClass()); 
       context = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
       WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(context);
       if (webAppContext != null) {
       if (isInitialized) {
            return;
       }
       setInitialized(true);
        
       
       adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);
       equifaxService = webAppContext.getBean("equifaxService", EquifaxServiceImpl.class);
       experianService = (ExperianService)SpringUtil.getInstance(context).getBean("experianService");
       manageEventService = (ManageEventService)SpringUtil.getInstance(context).getBean("manageEventService");
       commonRestService = webAppContext.getBean("commonRestService", CommonRestServiceImpl.class);
  	   equifaxDataService = (EquifaxDataService)SpringUtil.getInstance(context).getBean("equifaxDataService");
 	   proofingService = (ProofingService)webAppContext.getBean("ProofingService");
	   refLoaLevelService = (RefLoaLevelService)SpringUtil.getInstance(context).getBean("refLoaLevelService");
	   personService = (PersonDataService)SpringUtil.getInstance(context).getBean("personDataService");
	   refAppService = (RefAppService)SpringUtil.getInstance(context).getBean("RefAppService");
	   refSponsorConfigurationService = (RefSponsorConfigurationService)SpringUtil.getInstance(context).getBean("refSponsorConfigurationService");
	   sponsorDataService = (RefSponsorDataService)SpringUtil.getInstance(context).getBean("RefSponsorDataService");
	   rpEventDataService = (RpEventDataService)SpringUtil.getInstance(context).getBean("rpEventService");
	   otpAttemptConfigService = (OtpAttemptConfigService)SpringUtil.getInstance(context).getBean("otpAttemptConfigService");
	   refOtpSupplierDataService = (RefOtpSupplierDataService)SpringUtil.getInstance(context).getBean("refOtpSupplierDataService");
	   refOtpVelocityService = (RefOtpVelocityDataService)SpringUtil.getInstance(context).getBean("refOtpVelocityService");
	   lockoutService = (OtpLockoutInfoService)SpringUtil.getInstance(context).getBean("otpLockoutInfoService");
	   rpInfPvAttemptConfigService = (RpInfPvAttemptConfigService)SpringUtil.getInstance(context).getBean("rpInfPvAttemptConfigService");
	   rpSmfaAttemptService = (RpSmfaAttemptDataService)SpringUtil.getInstance(context).getBean("rpSmfaAttemptDataService");
	   rpOtpAttemptDataService = (RpOtpAttemptDataService)SpringUtil.getInstance(context).getBean("rpOtpAttemptDataService");
	   rpDeviceReputationService = (RpDeviceReputationService)SpringUtil.getInstance(context).getBean("rpDeviceReputationService");
	   rpDeviceReputationResponseService = (RpDeviceReputationResponseService)SpringUtil.getInstance(context).getBean("rpDeviceReputationResponseService");
	   rpDitResponseService = (RpDitResponseService)SpringUtil.getInstance(context).getBean("rpDitResponseService");
	   rpSmfaInitiateResponseService = (RpSmfaInitiateResponseService)SpringUtil.getInstance(context).getBean("rpSmfaInitiateResponseService");
	   rpSmfaValidateResponseService = (RpSmfaValidateResponseService)SpringUtil.getInstance(context).getBean("rpSmfaValidateResponseService");
	   rpSupplierTokenService = (RpSupplierTokenService)SpringUtil.getInstance(context).getBean("rpSupplierTokenService");
	   rpTruthDataSendResponseService = (RpTruthDataSendResponseService)SpringUtil.getInstance(context).getBean("rpTruthDataSendResponseService");
	   sponsorApplicationMapService = (SponsorApplicationMapService)SpringUtil.getInstance(context).getBean("sponsorApplicationMapService");
	   verificationProviderService = (VerificationProviderService)SpringUtil.getInstance(context).getBean("verificationProviderService");
       otpSupplierList = adminService.retrieveOtpAttemptConfigList(RefLoaLevel.LOA15_CODE, RefSponsor.SPONSOR_ID_CUSTREG); 
       otpSupplierList2 = adminService.retrieveInfPvAttemptConfigList(RefLoaLevel.LOA15_CODE, RefSponsor.SPONSOR_ID_CUSTREG); 
       rpSponsorList = adminService.retrieveSponsorList();
       rpAllRemoteProofingSponsorList = sponsorDataService.getAllRemoteProofingClients();
       refOtpSupplierList = refOtpSupplierDataService.getActiveSupplierList();
       appList = refAppService.list();
       
       enforceSupplierOption = currEnforceSupplierOption();
       
       refreshSupplierOptions();
       refreshUserOptions();
       refreshAltCredentialEndpointOptions();
       
       loadTestUserOptions();
       loadAltCredentialSettings();
       loadDitTestCases();
       prepopulateExperianAccessCredentials();
       
       pvSupplierSelected = "";
       pvSupplierSelected2 = "";
       supplierDetSponsorId = 1L;
       supplierDetSponsorId2 = 1L;

		} else {
			CustomLogger.error(this.getClass(), "Error: WebApplicationContext is null.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
    }
    

    /*========================================================================*/
	/*		                EXPERIAN SUPPLIER OPTIONS / RESPONSE OPTIONS      */
    /*========================================================================*/
    
    public void updateAltCredEndptOptions() {
    	CustomLogger.enter(this.getClass());
    	
    	if (altCredEndptOptionSponsorId < 1) {
    		setShowAltCredOptionSuccessMsg(false);
    		setShowAltCredOptionErrorMsg(true);
    		setAltCredOptionErrorMsg("Please select a sponsor.");
    		return;
    	}
    	
    	String useJwtAltCredConfigName = CommonRestServiceImpl.USE_EXP_JWT_ALT_CREDENTIAL;
    	String useXcoreAltCredConfigName = CommonRestServiceImpl.USE_EXP_XCORE_ALT_CREDENTIAL;
    	String useJwtAltEndptConfigName = CommonRestServiceImpl.USE_EXP_JWT_ALT_ENDPOINT;
    	String useXcoreEndptConfigName = CommonRestServiceImpl.USE_EXP_XCORE_ALT_ENDPOINT;
    	String envOptConfigName = CommonRestServiceImpl.USE_EXP_UAT_ENV;
 
       	String useJwtAltCredOption = this.useJwtAlternativeCredential? "Y" : "N";
       	String useXcoreAltCredOption = this.useXcoreAlternativeCredential? "Y" : "N";
       	String useJwtAltEndptOption = this.useJwtAlternativeEndpoint? "Y" : "N";
       	String useXcoreAltEndptOption = this.useXCoreAlternativeEndpoint? "Y" : "N";
       	String useExpUatEnvOption = this.useExpUatEnvironment? "Y" : "N";
 
      	RefSponsorConfiguration useJwtAltCredConfig = refSponsorConfigurationService.getConfigRecord(this.altCredEndptOptionSponsorId, useJwtAltCredConfigName);
      	RefSponsorConfiguration useXcoreAltCredConfig = refSponsorConfigurationService.getConfigRecord(this.altCredEndptOptionSponsorId, useXcoreAltCredConfigName);
      	RefSponsorConfiguration useJwtAltEndptConfig = refSponsorConfigurationService.getConfigRecord(this.altCredEndptOptionSponsorId, useJwtAltEndptConfigName);
      	RefSponsorConfiguration useXCoreAltEndptConfig = refSponsorConfigurationService.getConfigRecord(this.altCredEndptOptionSponsorId, useXcoreEndptConfigName);
      	RefSponsorConfiguration envOptConfig = refSponsorConfigurationService.getConfigRecord(this.altCredEndptOptionSponsorId, envOptConfigName);

     	if (useJwtAltCredConfig == null) {
     		useJwtAltCredConfig = new RefSponsorConfiguration();
     		useJwtAltCredConfig.setConfigurationId(refSponsorConfigurationService.getMostRecentConfigId() + 1);
     		useJwtAltCredConfig.setCreateDate(new Date());
     		useJwtAltCredConfig.setName(useJwtAltCredConfigName);
     		useJwtAltCredConfig.setValue(useJwtAltCredOption);
     		useJwtAltCredConfig.setSponsorId(altCredEndptOptionSponsorId);
			refSponsorConfigurationService.create(useJwtAltCredConfig);
		}
		else {
			useJwtAltCredConfig.setUpdateDate(new Date());
			useJwtAltCredConfig.setValue(useJwtAltCredOption);
			refSponsorConfigurationService.update(useJwtAltCredConfig);
		}
     	
     	if (useXcoreAltCredConfig == null) {
     		useXcoreAltCredConfig = new RefSponsorConfiguration();
     		useXcoreAltCredConfig.setConfigurationId(refSponsorConfigurationService.getMostRecentConfigId() + 1);
     		useXcoreAltCredConfig.setCreateDate(new Date());
     		useXcoreAltCredConfig.setName(useXcoreAltCredConfigName);
      		useXcoreAltCredConfig.setValue(useXcoreAltCredOption);
     		useXcoreAltCredConfig.setSponsorId(altCredEndptOptionSponsorId);
			refSponsorConfigurationService.create(useXcoreAltCredConfig);
		}
		else {
			useXcoreAltCredConfig.setUpdateDate(new Date());
			useXcoreAltCredConfig.setValue(useXcoreAltCredOption);
			refSponsorConfigurationService.update(useXcoreAltCredConfig);
		}
     	
     	if (useJwtAltEndptConfig == null) {
     		useJwtAltEndptConfig = new RefSponsorConfiguration();
     		useJwtAltEndptConfig.setConfigurationId(refSponsorConfigurationService.getMostRecentConfigId() + 1);
     		useJwtAltEndptConfig.setCreateDate(new Date());
     		useJwtAltEndptConfig.setName(useJwtAltEndptConfigName);
     		useJwtAltEndptConfig.setValue(useXcoreAltCredOption);
     		useJwtAltEndptConfig.setSponsorId(altCredEndptOptionSponsorId);
			refSponsorConfigurationService.create(useJwtAltEndptConfig);
		}
		else {
			useJwtAltEndptConfig.setUpdateDate(new Date());
			useJwtAltEndptConfig.setValue(useJwtAltEndptOption);
			refSponsorConfigurationService.update(useJwtAltEndptConfig);
		}
     	
     	if (useXCoreAltEndptConfig == null) {
     		useXCoreAltEndptConfig = new RefSponsorConfiguration();
     		useXCoreAltEndptConfig.setConfigurationId(refSponsorConfigurationService.getMostRecentConfigId() + 1);
     		useXCoreAltEndptConfig.setCreateDate(new Date());
     		useXCoreAltEndptConfig.setName(useXcoreEndptConfigName);
      		useXCoreAltEndptConfig.setValue(useXcoreAltEndptOption);
     		useXCoreAltEndptConfig.setSponsorId(altCredEndptOptionSponsorId);
			refSponsorConfigurationService.create(useXCoreAltEndptConfig);
		}
		else {
			useXCoreAltEndptConfig.setUpdateDate(new Date());
			useXCoreAltEndptConfig.setValue(useXcoreAltEndptOption);
			refSponsorConfigurationService.update(useXCoreAltEndptConfig);
		}
    		
     	if (envOptConfig == null) {
			envOptConfig = new RefSponsorConfiguration();
			envOptConfig.setConfigurationId(refSponsorConfigurationService.getMostRecentConfigId() + 1);
			envOptConfig.setCreateDate(new Date());
			envOptConfig.setName(envOptConfigName);
			envOptConfig.setValue(useExpUatEnvOption);
			envOptConfig.setSponsorId(altCredEndptOptionSponsorId);
			refSponsorConfigurationService.create(envOptConfig);
		}
		else {
			envOptConfig.setUpdateDate(new Date());
			envOptConfig.setValue(useExpUatEnvOption);
			refSponsorConfigurationService.update(envOptConfig);
		}
     	
     	setShowAltCredOptionErrorMsg(false);
     	setShowAltCredOptionSuccessMsg(true);
     	setAltCredOptionSuccessMsg("Alternative Credential, Endpoint Options were successfully updated!");
     }
    
    public void refreshAltCredentialEndpointOptions() {
    	CustomLogger.enter(this.getClass());

    	rpSponsorList = adminService.retrieveSponsorList();
    	
     	String useJwtAltCredConfigName = CommonRestServiceImpl.USE_EXP_JWT_ALT_CREDENTIAL;
    	String useXcoreAltCredConfigName = CommonRestServiceImpl.USE_EXP_XCORE_ALT_CREDENTIAL;
    	String useJwtAltEndptConfigName = CommonRestServiceImpl.USE_EXP_JWT_ALT_ENDPOINT;
    	String useXcoreEndptConfigName = CommonRestServiceImpl.USE_EXP_XCORE_ALT_ENDPOINT;
    	String envOptConfigName = CommonRestServiceImpl.USE_EXP_UAT_ENV;
        	
       	RefSponsorConfiguration useJwtAltCredConfig = refSponsorConfigurationService.getConfigRecord(this.altCredEndptOptionSponsorId, useJwtAltCredConfigName);
      	RefSponsorConfiguration useXcoreAltCredConfig = refSponsorConfigurationService.getConfigRecord(this.altCredEndptOptionSponsorId, useXcoreAltCredConfigName);
      	RefSponsorConfiguration useJwtAltEndptConfig = refSponsorConfigurationService.getConfigRecord(this.altCredEndptOptionSponsorId, useJwtAltEndptConfigName);
      	RefSponsorConfiguration useXCoreAltEndptConfig = refSponsorConfigurationService.getConfigRecord(this.altCredEndptOptionSponsorId, useXcoreEndptConfigName);
      	RefSponsorConfiguration envOptConfig = refSponsorConfigurationService.getConfigRecord(this.altCredEndptOptionSponsorId, envOptConfigName);

       	this.useJwtAlternativeCredential = false;
       	this.useXcoreAlternativeCredential = false;
       	this.useJwtAlternativeEndpoint = false;
       	this.useXCoreAlternativeEndpoint = false;
       	this.useExpUatEnvironment = false;

       	if (useJwtAltCredConfig != null) {
       		this.useJwtAlternativeCredential = "Y".equalsIgnoreCase(useJwtAltCredConfig.getValue());
       	}
       	if (useXcoreAltCredConfig != null) {
       		this.useXcoreAlternativeCredential  = "Y".equalsIgnoreCase(useXcoreAltCredConfig.getValue());
       	}
      	if (useJwtAltEndptConfig != null) {
      		this.useJwtAlternativeEndpoint  = "Y".equalsIgnoreCase(useJwtAltEndptConfig.getValue());
      	}
       	if (useXCoreAltEndptConfig != null) {
       		this.useXCoreAlternativeEndpoint  = "Y".equalsIgnoreCase(useXCoreAltEndptConfig.getValue());
       	}
       	if (envOptConfig != null) {
       		this.useExpUatEnvironment  = "Y".equalsIgnoreCase(envOptConfig.getValue());
       	}
    }
  
    public void refreshAltCredentialSettings() {
    	CustomLogger.enter(this.getClass());
 
    	int itemIndex = Integer.parseInt(altCredSettingIndex);

    	if (itemIndex > 0) {
 	    	NameValueVo selNvl = altCredSettingList.get(itemIndex - 1);
	    	String[] stringValueArr = selNvl.getStringValue().split(",");
	    	setAltCredentialType(stringValueArr[0]);
	    	setAltCredentialCode(stringValueArr[1]);
	    	setAltCredentialValue(stringValueArr[2]);
    	}
    	else {
    		setAltCredentialType("");
	    	setAltCredentialCode("");
	    	setAltCredentialValue("");
    	}
     }
    
    public void updateSupplierOptions() {
    	CustomLogger.enter(this.getClass());
    	
    	String supplierOptConfigName = "Test.Supplier.Options";
    	String supplierOption = enforceSupplierOption? "Y" : "N";
    	String value = String.format("%s,%s,%s", supplierOption, infAltSupplierId, cnfAltSupplierId);
    	RefSponsorConfiguration supplierOptConfig = refSponsorConfigurationService.getConfigRecord((int) supplierOptionSponsorId, supplierOptConfigName);
		if (supplierOptConfig == null) {
			supplierOptConfig = new RefSponsorConfiguration();
			supplierOptConfig.setConfigurationId(refSponsorConfigurationService.getMostRecentConfigId() + 1);
			supplierOptConfig.setCreateDate(new Date());
			supplierOptConfig.setName(supplierOptConfigName);
			supplierOptConfig.setSponsorId(supplierOptionSponsorId);
			supplierOptConfig.setValue(value);
			refSponsorConfigurationService.create(supplierOptConfig);
		}
		else {
			supplierOptConfig.setUpdateDate(new Date());
			supplierOptConfig.setValue(value);
			refSponsorConfigurationService.update(supplierOptConfig);
		}
    }
    
    public void refreshSupplierOptions() {
    	CustomLogger.enter(this.getClass());

    	rpSponsorList = adminService.retrieveSponsorList();
       	String supplierOptConfigName = "Test.Supplier.Options";

     	RefSponsorConfiguration supplierOptConfig = refSponsorConfigurationService.getConfigRecord(supplierOptionSponsorId, supplierOptConfigName);
		
     	enforceSupplierOption = false;
		infAltSupplierId = "0";
		cnfAltSupplierId = "0";
		
     	if (supplierOptConfig != null) {
			String[] supplierOptValueArr = supplierOptConfig.getValue().split(",");
			enforceSupplierOption = "Y".equalsIgnoreCase(supplierOptValueArr[0]);
			infAltSupplierId = supplierOptValueArr[1];
			cnfAltSupplierId = supplierOptValueArr[2];
		}
    }
    
    public void refreshUserOptions() {
    	CustomLogger.enter(this.getClass());

    	rpSponsorList = adminService.retrieveSponsorList();
       	String userOptConfigName = "Test.User.Options";
       	userOptionSponsorId = (int) RefSponsor.SPONSOR_ID_CUSTREG;
     	RefSponsorConfiguration userOptConfig = refSponsorConfigurationService.getConfigRecord(userOptionSponsorId, userOptConfigName);
		
     	enforceSupplierOption = false;
     	otpFlowUserIndex = "0";
     	silentAuthFlowUserIndex = "0";
     	bokuOtpFlowUserIndex = "0";
		
     	if (userOptConfig != null) {
			String[] userOptValueArr = userOptConfig.getValue().split(",");
			otpFlowUserIndex = userOptValueArr[0];
			silentAuthFlowUserIndex = userOptValueArr[1];
			bokuOtpFlowUserIndex = userOptValueArr[2];
		}
    }
    
    public void loadTestUserOptions() {
    	CustomLogger.enter(this.getClass());
    	userOptionList = new ArrayList<>();
    	
    	InputStream input = DeviceReputationServiceImpl.class.getClassLoader().getResourceAsStream("/ips.properties");
    	Properties prop = new Properties();
    	
    	String propertyValue = "";
    	String[] propertyValueArr = null;
    	try {
			prop.load(input);
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	if (prop != null) {
    		for(int i = 1; i < 17; i++) {
    			String propertyName = "Experian.TestUserData" + i;
				propertyValue = prop.getProperty(propertyName);
				
				if (propertyValue != null) {
					propertyValueArr = propertyValue.split(",");
					
					if (propertyValueArr != null ) {
						String firstName = propertyValueArr[0];
						String lastName = propertyValueArr[1];
						String streetAddress = propertyValueArr[2];
						String city = propertyValueArr[3];
						String state = propertyValueArr[4];
						String postalCode = propertyValueArr[5];
						String mobileNumber = propertyValueArr[6];
						
				    	ExperianResultVo resultVo = new ExperianResultVo();
				    	resultVo.setTestUserIndex(i);
				    	resultVo.setFirstName(firstName);
				    	resultVo.setLastName(lastName);
				    	resultVo.setAddressLine1(streetAddress);
				    	resultVo.setCity(city);
				    	resultVo.setStateProvince(state);
				    	resultVo.setPostalCode(postalCode);
				    	resultVo.setMobileNumber(mobileNumber);
				    	userOptionList.add(resultVo);
					}
				}
				
    		}
		}
    }
    
    public void loadAltCredentialSettings() {
    	CustomLogger.enter(this.getClass());
    	altCredSettingList = new ArrayList<>();
    	
    	InputStream input = DeviceReputationServiceImpl.class.getClassLoader().getResourceAsStream("/ips.properties");
    	Properties prop = new Properties();
    	
    	String propertyValue = "";
    	String[] propertyValueArr = null;
    	try {
			prop.load(input);
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	if (prop != null) {
    		for(int i = 1; i < 17; i++) {
    			String propertyName = "Alt.Credential" + i;
				propertyValue = prop.getProperty(propertyName);
				
				if (propertyValue != null) {
					propertyValueArr = propertyValue.split(",");
					
					if (propertyValueArr != null ) {
						String name = propertyValueArr[0];
						String type = propertyValueArr[1];
						String code = propertyValueArr[2];
						String value = propertyValueArr[3];
						
						NameValueVo nvl = new NameValueVo(i, String.format("%s - %s", name, code), String.format("%s,%s,%s", type, code, value));
				    	altCredSettingList.add(nvl);
					}
				}
    		}
		}
    }
    
    public void updateTestUserOptions() {
    	CustomLogger.enter(this.getClass());

    	String userOptConfigName = "Test.User.Options";
     	String value = String.format("%s,%s,%s,%s", otpFlowUserIndex, silentAuthFlowUserIndex, bokuOtpFlowUserIndex, predefinedUserIndex);
    	RefSponsorConfiguration userOptConfig = refSponsorConfigurationService.getConfigRecord(userOptionSponsorId, userOptConfigName);

		if (userOptConfig == null) {
			userOptConfig = new RefSponsorConfiguration();
			userOptConfig.setConfigurationId(refSponsorConfigurationService.getMostRecentConfigId() + 1);
			userOptConfig.setCreateDate(new Date());
			userOptConfig.setName(userOptConfigName);
			userOptConfig.setSponsorId(userOptionSponsorId);
			userOptConfig.setValue(value);
			refSponsorConfigurationService.create(userOptConfig);
		}
		else {
			userOptConfig.setUpdateDate(new Date());
			userOptConfig.setValue(value);
			refSponsorConfigurationService.update(userOptConfig);
		}
    }
    
    public void updateCredentialSetting() {
    	CustomLogger.enter(this.getClass());

    	if (Utils.isEmptyString(this.altCredentialType) || Utils.isEmptyString(this.altCredentialCode) 
    			|| Utils.isEmptyString(this.altCredentialValue)) {
       		setShowAltCredSettingSuccessMsg(false);
      		setShowAltCredSettingErrorMsg(true);
    		setAltCredSettingErrorMsg("Please select credential type, code and value.");
     		return;
    	}
    		
		RpSupplierToken supplierToken = rpSupplierTokenService.findByTokenType(this.altCredentialType);
         
		if (supplierToken != null) {
			supplierToken.setTokenCode(this.altCredentialCode);
			supplierToken.setAccessToken(this.altCredentialValue);
			supplierToken.setUpdateDate(new Timestamp(new Date().getTime()));
			rpSupplierTokenService.update(supplierToken);
			
			setAltCredSettingSuccessMsg(String.format("Credential type:%s with type code:%s and type value:%s was successfully updated!",
					this.altCredentialType, this.altCredentialCode, this.altCredentialValue));
		}
		else {
			supplierToken = new RpSupplierToken();
			supplierToken.setTokenType(this.altCredentialType);
			supplierToken.setTokenCode(this.altCredentialCode);
			supplierToken.setAccessToken(this.altCredentialValue);
			supplierToken.setCreateDate(new Timestamp(new Date().getTime()));
			rpSupplierTokenService.save(supplierToken);
			
			setAltCredSettingSuccessMsg(String.format("Credential type:%s with type code:%s and type value:%s was successfully added!",
					this.altCredentialType, this.altCredentialCode, this.altCredentialValue));

		}
    	
		setShowAltCredSettingErrorMsg(false);
		setShowAltCredSettingSuccessMsg(true);
    }
    
    public void createUpdateConfigGenericSetter() {
    	CustomLogger.enter(this.getClass());
    	
    	if (Utils.isEmptyString(sponsorConfigName) || Utils.isEmptyString(sponsorConfigValue) || genericConfigSponsorId == 0) {
      		setShowSponsorConfigSetterSuccessMsg(false);
      		setShowSponsorConfigSetterErrorMsg(true);
    		setSponsorConfigSetterErrorMsg("Please select sponsor and provide config name and config value.");
     		return;
    	}
    	
    	RefSponsorConfiguration genericConfig = refSponsorConfigurationService.getConfigRecord(genericConfigSponsorId, sponsorConfigName);
		if (genericConfig == null) {
			genericConfig = new RefSponsorConfiguration();
			genericConfig.setConfigurationId(refSponsorConfigurationService.getMostRecentConfigId() + 1);
			genericConfig.setCreateDate(new Date());
			genericConfig.setName(sponsorConfigName);
			genericConfig.setSponsorId(genericConfigSponsorId);
			genericConfig.setValue(sponsorConfigValue);
			refSponsorConfigurationService.create(genericConfig);
			
			setSponsorConfigSetterSuccessMsg(String.format("Config name:%s with config value:%s was successfully added!",
					sponsorConfigName, sponsorConfigValue));
		}
		else {
			genericConfig.setUpdateDate(new Date());
			genericConfig.setValue(sponsorConfigValue);
			refSponsorConfigurationService.update(genericConfig);
			
			setSponsorConfigSetterSuccessMsg(String.format("Config name:%s with config value:%s was successfully updated!",
					sponsorConfigName, sponsorConfigValue));
			}
		
 		setShowSponsorConfigSetterErrorMsg(false);
  		setShowSponsorConfigSetterSuccessMsg(true);

     }
    
    public void removeConfigGenericSetter() {
    	CustomLogger.enter(this.getClass());
    	
    	if (Utils.isEmptyString(sponsorConfigName) || Utils.isEmptyString(sponsorConfigValue) || genericConfigSponsorId > 1) {
      		setShowSponsorConfigSetterSuccessMsg(false);
      		setShowSponsorConfigSetterErrorMsg(true);
    		setSponsorConfigSetterErrorMsg("Please select sponsor and provide config name and config value to be removed.");
     		return;
    	}
    	
    	RefSponsorConfiguration genericConfig = refSponsorConfigurationService.getConfigRecord(genericConfigSponsorId, sponsorConfigName);
		if (genericConfig != null) {
			refSponsorConfigurationService.delete(genericConfig);
		}
		
		setSponsorConfigName("");
		setSponsorConfigValue("");
		setGenericConfigSponsorId(0);
		
		setSponsorConfigSetterSuccessMsg(String.format("Config name:%s with config value:%s was successfully removed!",
				sponsorConfigName, sponsorConfigValue));
			
		setShowSponsorConfigSetterErrorMsg(false);
		setShowSponsorConfigSetterSuccessMsg(true);
	}
    
    private boolean currEnforceSupplierOption() {
    	CustomLogger.enter(this.getClass());
    	boolean currEnforceSupplierOption = false;
    	
    	RefSponsorConfiguration supplierOptConfig = refSponsorConfigurationService.getConfigRecord(1, "Test.Supplier.Options");
   			
       	if (supplierOptConfig != null) {
       		String[] supplierOptValueArr = supplierOptConfig.getValue().split(",");
       		currEnforceSupplierOption = "Y".equalsIgnoreCase(supplierOptValueArr[0]);
       	}
		
		return currEnforceSupplierOption;
    }
    

    /*========================================================================*/
	/*		      EXPERIAN ORCHESTRATION DECISION   / TEST PASSCODES          */
    /*========================================================================*/
    
    public void getOrchestrationDecision() {
    	CustomLogger.enter(this.getClass());
    	
    	ExperianResultVo resultVo = new ExperianResultVo();
    	getCommonOrchestrationDecision(resultVo);
    }
    
    private void getCommonOrchestrationDecision(ExperianResultVo resultVo) {
    	CustomLogger.enter(this.getClass());
      	resultVo.setInitialRequest(true);
   		resultVo.setWorkflowRequestType(requestType);
    	resultVo.setTestUserIndex(Integer.parseInt(testUserIndex));
    	resultVo.setUseTargetTestUser(true);
  		
        SponsorApplicationMap sponsorApp = sponsorApplicationMapService.getRelationByApplication(userAppId);

     	personVo = createPersonVo();
     	personVo.setSponsor(sponsorApp.getSponsor().getSponsorName());
     	
		resultVo.setProofingAction("VerifyPhone");
     	experianService.initializeExperianResultVo(personVo, resultVo);

   		personVo.setDeviceTypeMobile(false);
 
   		if (ExperianResultVo.WORKFLOW_REQUEST_TYPE_SILENT_AUTH_FLOW.equalsIgnoreCase(requestType)) {
    		personVo.setDeviceTypeMobile(true);
    	}
    
		try {
 			proofingService.updatePerson(personVo);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred on updatePerson", e);
		}

		JSONObject ccResponseJsonObj = new JSONObject();
		RpEvent rpEvent = rpEventDataService.findLatestEventByPersonId(personVo.getId());
		
     	if (rpEvent == null) {
     		personVo.setHasPreviousPhoneVerificationDecision(false);
     		rpEvent = manageEventService.createEvent(personVo, null, 6L);
    	}
     	
     	setExperianAccessCredentials(resultVo);
     	
		try {
			ccResponseJsonObj = experianService.getCrossCoreResponse(personVo, null, resultVo, rpEvent);
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(), "Exception occurred during callCrossCoreWorkflow", ex);
		}

		if (ccResponseJsonObj != null) {
			experianService.extractResponseDecisionData(ccResponseJsonObj, resultVo);
		}
		
		setCcRequestJson(resultVo.getCrossCoreRequestJson());
		setOrchDecisionJson(resultVo.getOrchDecisionJson());
    }
    
	private void prepopulateExperianAccessCredentials() {
		//Setting JwtUserName and JwtUserKey
		String propUserName = commonRestService.getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_JWT_ACCT_NAME);
		String propUserKey = commonRestService.getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_JWT_ACCT_CODE);
	
		RefSponsorConfiguration sponsorConfig = refSponsorConfigurationService.getConfigRecord((int) RefSponsor.SPONSOR_ID_CUSTREG, CommonRestServiceImpl.USE_EXP_JWT_ALT_CREDENTIAL);
		if (sponsorConfig != null && IPSConstants.CONFIG_VALUE_Y.equalsIgnoreCase(sponsorConfig.getValue())) {
			RpSupplierToken altJwtCred = rpSupplierTokenService.findByTokenType(CommonRestServiceImpl.TOKEN_TYPE_EXP_JWT_ALT_CRED);
		   	CustomLogger.debug(this.getClass(), "Process check: CommonRest Service > RefSponsorConfiguration is found for Use.Exp.Jwt.Alt.Credential.");
	
			if (altJwtCred != null) {
				String altUserName = altJwtCred.getTokenCode();
				if (!Utils.isEmptyString(altUserName)) {
					if (altUserName.startsWith("crosscore.prod.non")) {
						propUserName = altUserName + "exp@usps.gov";
					}
					else {
						propUserName = altUserName + "@usps.gov";
					}
				}
						
				propUserKey = altJwtCred.getAccessToken();
			}
		}
		
		setJwtUsername(propUserName);
		setJwtPasscode(propUserKey);
				
		//Setting PidUserName and PidUserKey
		String pidUserName = commonRestService.getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_PID_ACCT_NAME);
		String pidUserPwd = commonRestService.getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_PID_ACCT_CODE);
		
		RefSponsorConfiguration altXcoreCredConfig = refSponsorConfigurationService.getConfigRecord((int) RefSponsor.SPONSOR_ID_CUSTREG, CommonRestServiceImpl.USE_EXP_XCORE_ALT_CREDENTIAL);
		if (altXcoreCredConfig != null && IPSConstants.CONFIG_VALUE_Y.equalsIgnoreCase(altXcoreCredConfig.getValue())) {
			RpSupplierToken altXcoreCred = rpSupplierTokenService.findByTokenType(CommonRestServiceImpl.TOKEN_TYPE_EXP_XCORE_ALT_CRED);
			
			if (altXcoreCred != null) {
				pidUserName =altXcoreCred.getTokenCode();
				pidUserPwd = altXcoreCred.getAccessToken();
			}
		}

		setPidUsername(pidUserName);
		setPidPasscode(pidUserPwd);
	}

    public void refreshExperianUserData() {
    	loadTestUserOptions();

    	if ("0".equalsIgnoreCase(testUserIndex)) {
	    	setExpFirstName("");
	    	setExpLastName("");
	    	setExpEmailAddress("");
	    	setExptreetAddress("");
	    	setExpCity("");
	    	setExpState("");
	    	setExpZip5("");
	    	setExpMobileNumber("");
    	}
    	else {
    		int index = Integer.parseInt(testUserIndex);
     		ExperianResultVo resultVo = userOptionList.get(index - 1);
      		
      		if (Utils.isEmptyString(resultVo.getEmailAddress())) {
      			resultVo.setEmailAddress("medium_confidence@usps.gov");
      		}
      		
	    	setExpFirstName(resultVo.getFirstName());
	    	setExpLastName(resultVo.getLastName());
	    	setExpEmailAddress(resultVo.getEmailAddress());
	    	setExptreetAddress(resultVo.getAddressLine1());
	    	setExpCity(resultVo.getCity());
	    	setExpState(resultVo.getStateProvince());
	    	setExpZip5(resultVo.getPostalCode());
	    	setExpMobileNumber(resultVo.getMobileNumber());
    	}
    }
    
    public void expGenerateCustomerId() {
    	int custIdHash = hashCode(expFirstName, expLastName, expEmailAddress, expMobileNumber);
    	String custIdHashStr = String.valueOf(custIdHash);
    	expSponsorUserId = custIdHashStr.replace("-", "");
    	expSponsorUserId = expSponsorUserId.replaceFirst("^0+(?!$)", "");
    }
    
    private int hashCode(String firstName, String lastName, String emailAddress, String cdMobileNumber) {
    	CustomLogger.enter(this.getClass());
    	
         int hash = 7;
         hash = 31 * hash + (firstName == null ? 0 : firstName.hashCode());
         hash = 31 * hash + (lastName == null ? 0 : lastName.hashCode());
         hash = 31 * hash + (emailAddress == null ? 0 : emailAddress.hashCode());
         hash = 31 * hash + (cdMobileNumber == null ? 0 : cdMobileNumber.hashCode());
         
         String hashStr = String.valueOf(hash);
         if (hashStr.length() > 10) {
        	 hashStr = hashStr.substring(0, 10);
        	 hash = Integer.valueOf(hashStr);
         }
         return hash;
    }
    
    public void getOrchUsingPasscode() {
    	CustomLogger.enter(this.getClass());
    	
    	ExperianResultVo resultVo = new ExperianResultVo();
    	resultVo.setPidUserName(pidUsername);
    	resultVo.setPidUserKey(pidPasscode);
 
    	getCommonOrchestrationDecision(resultVo);
    }
    
    public void getExperianJwtJson() {
    	CustomLogger.enter(this.getClass());
    	
    	String webServiceURL = commonRestService.getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_CC_JWT_ENDPT);
		List<NameValueVo> headerList = new ArrayList<>();
		headerList.add(new NameValueVo(ExperianServiceImpl.HEADER_USER_DOMAIN_NAME, ExperianServiceImpl.HEADER_USER_DOMAIN_VALUE));
		headerList.add(new NameValueVo(ExperianServiceImpl.HEADER_CORRELATION_ID_NAME, ExperianServiceImpl.HEADER_CORRELATION_ID_VALUE));
		
		ExperianResultVo resultVo = new ExperianResultVo();
		resultVo.setJwtUserName(jwtUsername);
		resultVo.setJwtUserKey(jwtPasscode);

		JSONObject tokenResponseJsonObj = commonRestService.getJsonWebTokenResponse(webServiceURL, headerList, resultVo);
		
		if (tokenResponseJsonObj != null) {
			Gson g = new Gson();
			experianJwt = getFormattedJson(g.toJson(tokenResponseJsonObj));
		}
    }
    
    public void setExperianAccessCredentials(ExperianResultVo resultVo) {
    	CustomLogger.enter(this.getClass());
    	
    	String webServiceURL = commonRestService.getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_CC_JWT_ENDPT);
		List<NameValueVo> headerList = new ArrayList<>();
		headerList.add(new NameValueVo(ExperianServiceImpl.HEADER_USER_DOMAIN_NAME, ExperianServiceImpl.HEADER_USER_DOMAIN_VALUE));
		headerList.add(new NameValueVo(ExperianServiceImpl.HEADER_CORRELATION_ID_NAME, ExperianServiceImpl.HEADER_CORRELATION_ID_VALUE));
		
		resultVo.setJwtUserName(jwtUsername);
		resultVo.setJwtUserKey(jwtPasscode);

    	resultVo.setPidUserName(pidUsername);
    	resultVo.setPidUserKey(pidPasscode);
    	
		JSONObject tokenResponseJsonObj = commonRestService.getJsonWebTokenResponse(webServiceURL, headerList, resultVo);
		String accessToken = "";
		
		if (tokenResponseJsonObj != null) {
			Gson g = new Gson();
			experianJwt = getFormattedJson(g.toJson(tokenResponseJsonObj));
			accessToken = (String) tokenResponseJsonObj.get("access_token");
			String bearerToken = String.format(CommonRestServiceImpl.BEARER_TOKEN_FMT, accessToken);
			resultVo.setBearerToken(bearerToken);
		}
    }
    
    public void getExperianJwtJsonAlt() {
    	CustomLogger.enter(this.getClass());
    	
    	String webServiceURL = commonRestService.getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_CC_JWT_ENDPT);
		List<NameValueVo> headerList = new ArrayList<>();
		headerList.add(new NameValueVo(ExperianServiceImpl.HEADER_USER_DOMAIN_NAME, ExperianServiceImpl.HEADER_USER_DOMAIN_VALUE));
		headerList.add(new NameValueVo(ExperianServiceImpl.HEADER_CORRELATION_ID_NAME, ExperianServiceImpl.HEADER_CORRELATION_ID_VALUE));
		
		ExperianResultVo resultVo = new ExperianResultVo();
		resultVo.setJwtUserName(jwtUsername);
		resultVo.setJwtUserKey(jwtPasscode);

		String tokenResponseJson = commonRestService.getJsonWebTokenHttpClientResponse(webServiceURL, headerList, resultVo);
		experianJwt = tokenResponseJson;
    }
    
    private PersonVo createPersonVo() {
        personVo = new PersonVo();
        personVo.setSponsorId(userDecisionSponsorId);
    	personVo.setSponsorUserId(expSponsorUserId);
        personVo.setFirstName(expFirstName);
        personVo.setLastName(expLastName);
        personVo.setAddressLine1(exptreetAddress);
        personVo.setCity(expCity);
        personVo.setStateProvince(expState);
        personVo.setPostalCode(expZip5);
        personVo.setEmailAddress(expEmailAddress);
        personVo.setMobileNumber(expMobileNumber);
        personVo.setProofingLevelSought("1.5");
         
        RefApp refApp = refAppService.findByAppId(userAppId);
        String sponsorName = "";

        if (refApp != null) {
	        personVo.setTransactionOriginAppName(refApp.getAppName());
	        personVo.setAppId(refApp.getAppId());
        
	        SponsorApplicationMap sponsorApp = sponsorApplicationMapService.getRelationByApplication(refApp.getAppId());
       		sponsorName = sponsorApp.getSponsor().getSponsorName();
        }

        personVo.setSponsor(sponsorName);

        return personVo;
    }
    
   
    /*========================================================================*/
  	/*		      LOCKOUT WINDOW CONFIGURATION                                */
    /*========================================================================*/
    
    public void refreshLockoutWindowConfig() {
    	CustomLogger.enter(this.getClass());
    	
    	RefOtpVelocity rpPhoneVelocity = refOtpVelocityService.findByIdAndVelocityType(selectedOtpSupplierId, "PHONE");
    	setPhoneAttemptsWindow(rpPhoneVelocity.getAttemptWindow());
    	setPhoneAttemptsAllowed(rpPhoneVelocity.getAttemptsAllowed());
    	
    	String velocityType = selectedOtpSupplierId == 5? "SMFA" : "PASSCODE";
      	RefOtpVelocity rpPasscodeVelocity = refOtpVelocityService.findByIdAndVelocityType(selectedOtpSupplierId, velocityType);
     	setPasscodeAttemptsWindow(rpPasscodeVelocity.getAttemptWindow());
    	setPasscodeAttemptsAllowed(rpPasscodeVelocity.getAttemptsAllowed());
    }
    
    public void updateLockoutWindow()  {
    	CustomLogger.enter(this.getClass());
    	
    	RefOtpVelocity rpPhoneVelocity = refOtpVelocityService.findByIdAndVelocityType(selectedOtpSupplierId, "PHONE");
    	rpPhoneVelocity.setAttemptWindow(phoneAttemptsWindow);
    	rpPhoneVelocity.setAttemptsAllowed(phoneAttemptsAllowed);
    	refOtpVelocityService.update(rpPhoneVelocity);
    	
      	String velocityType = selectedOtpSupplierId == 5? "SMFA" : "PASSCODE";
      	RefOtpVelocity rpPasscodeVelocity = refOtpVelocityService.findByIdAndVelocityType(selectedOtpSupplierId, velocityType);
      	rpPasscodeVelocity.setAttemptWindow(phoneAttemptsWindow);
      	rpPasscodeVelocity.setAttemptsAllowed(phoneAttemptsAllowed);
    	refOtpVelocityService.update(rpPasscodeVelocity);
    }
    
    public void setLockoutWindowDefault()  {
    	CustomLogger.enter(this.getClass());
    	
    	RefOtpVelocity rpPhoneVelocity = refOtpVelocityService.findByIdAndVelocityType(selectedOtpSupplierId, "PHONE");
    	rpPhoneVelocity.setAttemptWindow(72);
    	rpPhoneVelocity.setAttemptsAllowed(3);
    	refOtpVelocityService.update(rpPhoneVelocity);
    	
      	String velocityType = selectedOtpSupplierId == 5? "SMFA" : "PASSCODE";
      	RefOtpVelocity rpPasscodeVelocity = refOtpVelocityService.findByIdAndVelocityType(selectedOtpSupplierId, velocityType);
      	rpPasscodeVelocity.setAttemptWindow(180);
      	rpPasscodeVelocity.setAttemptsAllowed(8);
    	refOtpVelocityService.update(rpPasscodeVelocity);
    	
    	refreshLockoutWindowConfig();
    }
    
    
    /*========================================================================*/
	/*		                EQUIFAX DIT WEB SERVICE                           */
    /*========================================================================*/
    
    public void generateEfxDitRequest() {
    	CustomLogger.enter(this.getClass());
    	
 
    	personVo = new PersonVo();
    	personVo.setFirstName(efxDitFirstName);
    	personVo.setMiddleName(efxDitMiddleName);
    	personVo.setLastName(efxDitLastName);
    	personVo.setAddressLine1(efxDitStreetAddress);
    	personVo.setCity(efxDitCity);
    	personVo.setStateProvince(efxDitState);
    	personVo.setPostalCode(efxDitZip5);
    	personVo.setEmailAddress(efxDitEmail);
    	personVo.setMobileAreaCode("");
    	personVo.setMobileNumber(efxDitMobileNum);
    	
        String sponsorUserId = generateNumber(10);
        long eventId = Long.parseLong(generateNumber(4));
 
		try {
			ditInitiateRequest = equifaxService.prepareDitInitiateRequest(personVo, sponsorUserId, eventId);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in getting InitiateRequestModel request.", e);
		}
         
		String formattedJsonStr = "";
		if (ditInitiateRequest != null) {
			Gson g = new Gson();
			ditInitiateRequestStr = g.toJson(ditInitiateRequest);
            formattedJsonStr = getFormattedJson(ditInitiateRequestStr);
		}

		efxDitJsonRequest = formattedJsonStr;
		showEfxDitRequestJsonPanel = true;
		showEfxDitSubmitBtn = true;
    }
    
    public void submitEfxDitRequest() {
    	CustomLogger.enter(this.getClass());
    	
    	String bearerToken = "";
		try {
			bearerToken = equifaxService.generateEquifaxBearerToken(bearerToken, bearerToken, false);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in generating Equifax Bearer Token.", e);
		}
		
    	ditInitiateResponse = commonRestService.sendInitiateDITRequest(bearerToken, ditInitiateRequest);
    	
    	String formattedJsonStr = "";
    	if (ditInitiateResponse != null) {
	    	Gson g = new Gson();
	    	ditInitiateResponseStr = g.toJson(ditInitiateResponse);
	    	formattedJsonStr = getFormattedJson(ditInitiateResponseStr);
    	}
    	
    	String overallDecision = "";
    	if (ditInitiateResponse != null) {
    		equifaxService.evaluateDITOverallDecision(ditInitiateResponse);
    		overallDecision = ditInitiateResponse.getDecision();
    		
	    	ditSelectedTestCaseList = new ArrayList<>();
	    	TestCaseVo selectedCase = (TestCaseVo) ditTestCaseMap.get(ditSelectedTestCaseId);
	    	
	    	if (!"0".equals(ditSelectedTestCaseId)) {
		    	TestCaseVo expectedCase = new TestCaseVo();
		    	expectedCase.setTestCaseFirstName("Expected");
		    	expectedCase.setTestCaseOverallDecision("");
		    	expectedCase.setTestCaseIdentityTrust(selectedCase.getTestCaseIdentityTrust());
		    	expectedCase.setTestCaseAddressTrust(selectedCase.getTestCaseAddressTrust());
		    	expectedCase.setTestCasePhoneTrust(selectedCase.getTestCasePhoneTrust());
		    	ditSelectedTestCaseList.add(expectedCase);
	    	}
	    	
	    	TestCaseVo resultCase = new TestCaseVo();
	    	resultCase.setTestCaseFirstName("Actual");
	    	resultCase.setTestCaseOverallDecision(overallDecision);
	    	resultCase.setTestCaseIdentityTrust(ditInitiateResponse.getIdentityTrust());
	    	resultCase.setTestCaseAddressTrust(ditInitiateResponse.getAddressTrust());
	    	resultCase.setTestCasePhoneTrust(ditInitiateResponse.getPhoneTrust());
	    	ditSelectedTestCaseList.add(resultCase);
	    	
    	}
    	
    	setEfxSmfaInitMobileNum(efxDitMobileNum);    	
     	efxDitJsonResponse = formattedJsonStr;
       	setShowEfxDitResponseJsonPanel(true);
       	setShowEfxDitTrustDecisionPanel(true);
    }

    private String getFormattedJson(String rawJsonString) {
    	 CustomLogger.enter(this.getClass());
    	
    	 @SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
         Gson gson = new GsonBuilder().setPrettyPrinting().create();

         @SuppressWarnings("deprecation")
		JsonElement requestJsonEl = parser.parse(rawJsonString);
         return gson.toJson(requestJsonEl);
    }
    
    private String generateNumber(int numDigits) {
    	CustomLogger.enter(this.getClass());
    	
    	int intRandom = ThreadLocalRandom.current().nextInt();
    	String strRandom = String.valueOf(intRandom).replace("-", "");
    	
    	if (numDigits < strRandom.length()) {
    		strRandom = strRandom.substring(0, numDigits);
    	}
    	return strRandom;
    }
    
    private void loadDitTestCases() {
    	CustomLogger.enter(this.getClass());
    	
    	ditTestCaseList = new ArrayList<>();
     	ditTestCaseList.add(new TestCaseVo("1", "Quinn", "RosasUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("2", "Richard", "TestbestUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("3", "Zelda", "MccoolUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("4", "Lucie", "HoffmanUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("5", "Bob", "WolfUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("6", "Connie", "MccoolUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("7", "Eric", "MccoolUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("8", "Malcolm", "MccoolUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("9", "Lynn", "MccoolUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("10", "Larry", "MccoolUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("11", "Irwin", "MccoolUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("12", "Marvin", "MccoolUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("13", "Mary", "MccoolUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("14", "Jack", "MorrisUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("15", "Jacob", "MorrisUAT","N","N","Y"));
     	ditTestCaseList.add(new TestCaseVo("16", "Henry", "MccoolUAT","N","N","Y"));
     	ditTestCaseList.add(new TestCaseVo("17", "Test", "GrahmamUAT","N","N","Y"));
     	ditTestCaseList.add(new TestCaseVo("18", "Test", "NoChannelUAT","Y","Y","N"));
     	ditTestCaseList.add(new TestCaseVo("19", "Allow", "NoChannelUAT","Y","Y","Y"));
     	ditTestCaseList.add(new TestCaseVo("20", "Melane", "McolenUAT","Y","Y","Y"));
     	ditTestCaseList.add(new TestCaseVo("21", "Abby", "CaineenUAT","Y","Y","Y"));
     	ditTestCaseList.add(new TestCaseVo("22", "Nolan", "YoungUAT","Y","Y","Y"));
     }
   
    
    public void ditRefreshIdentityAddressInput() {
    	CustomLogger.enter(this.getClass());
    	
    	if (ditTestCaseMap == null)  {
    		loadDitTestCaseHashMap();
    	}

    	TestCaseVo testCaseVo = (TestCaseVo) ditTestCaseMap.get(ditSelectedTestCaseId);
       	setEfxDitFirstName(testCaseVo.getTestCaseFirstName());
       	setEfxDitLastName(testCaseVo.getTestCaseLastName());
       	setEfxDitMiddleName("");
       	setEfxDitStreetAddress("535 WILSON BRIDGE DR APT A1");
       	setEfxDitCity("OXON HILL");
       	setEfxDitState("MD");
       	setEfxDitZip5("20745");
       	
       	setShowEfxDitRequestJsonPanel(false);
       	setShowEfxDitResponseJsonPanel(false);
       	setShowEfxDitTrustDecisionPanel(false);
       	setShowEfxDitSubmitBtn(false);
       	setShowEfxDitTrustDecisionPanel(false);
    }
    
    private void loadDitTestCaseHashMap() {
    	CustomLogger.enter(this.getClass());
    	
    	ditTestCaseMap = new LinkedHashMap<>();
    	
    	for(TestCaseVo testCase : ditTestCaseList) {
    		ditTestCaseMap.put(testCase.getTestCaseId(), testCase);
     	}
    }
    
    public class TestCaseVo {
    	
    	String testCaseId;
    	String testCaseFirstName;
    	String testCaseLastName;
		String testCaseIdentityTrust;
    	String testCaseAddressTrust;
    	String testCasePhoneTrust;
    	String testCaseOverallDecision;
    	
    	public TestCaseVo() {

    	}
    	
		public TestCaseVo(String testCaseId, String testCaseFirstName, String testCaseLastName,
				String testCaseIdentityTrust, String testCaseAddressTrust, String testCasePhoneTrust) {
    		this.testCaseId = testCaseId;
    		this.testCaseLastName = testCaseLastName;
    		this.testCaseFirstName = testCaseFirstName;
    		this.testCaseIdentityTrust = testCaseIdentityTrust;
    		this.testCaseAddressTrust = testCaseAddressTrust;
    		this.testCasePhoneTrust = testCasePhoneTrust;
    	}

		public String getTestCaseId() {
			return testCaseId;
		}

		public void setTestCaseId(String testCaseId) {
			this.testCaseId = testCaseId;
		}

		public String getTestCaseFirstName() {
			return testCaseFirstName;
		}

		public void setTestCaseFirstName(String testCaseFirstName) {
			this.testCaseFirstName = testCaseFirstName;
		}

		public String getTestCaseLastName() {
			return testCaseLastName;
		}

		public void setTestCaseLastName(String testCaseLastName) {
			this.testCaseLastName = testCaseLastName;
		}

		public String getTestCaseIdentityTrust() {
			return testCaseIdentityTrust;
		}

		public void setTestCaseIdentityTrust(String testCaseIdentityTrust) {
			this.testCaseIdentityTrust = testCaseIdentityTrust;
		}

		public String getTestCaseAddressTrust() {
			return testCaseAddressTrust;
		}

		public void setTestCaseAddressTrust(String testCaseAddressTrust) {
			this.testCaseAddressTrust = testCaseAddressTrust;
		}

		public String getTestCasePhoneTrust() {
			return testCasePhoneTrust;
		}

		public void setTestCasePhoneTrust(String testCasePhoneTrust) {
			this.testCasePhoneTrust = testCasePhoneTrust;
		}

		public String getTestCaseOverallDecision() {
			return testCaseOverallDecision;
		}

		public void setTestCaseOverallDecision(String testCaseOverallDecision) {
			this.testCaseOverallDecision = testCaseOverallDecision;
		}
		
    	
    }

	public ServletContext getContext() {
		return context;
	}

	public void setContext(ServletContext context) {
		this.context = context;
	}

	public PersonVo getPersonVo() {
		return personVo;
	}

	public void setPersonVo(PersonVo personVo) {
		this.personVo = personVo;
	}

	public InitiateDITRequestModel getDitInitiateRequest() {
		return ditInitiateRequest;
	}

	public void setDitInitiateRequest(InitiateDITRequestModel ditInitiateRequest) {
		this.ditInitiateRequest = ditInitiateRequest;
	}

	public InitiateDITResponseModel getDitInitiateResponse() {
		return ditInitiateResponse;
	}

	public void setDitInitiateResponse(InitiateDITResponseModel ditInitiateResponse) {
		this.ditInitiateResponse = ditInitiateResponse;
	}

	public String getEfxDitFirstName() {
		return efxDitFirstName;
	}

	public void setEfxDitFirstName(String efxDitFirstName) {
		this.efxDitFirstName = efxDitFirstName;
	}

	public String getEfxDitMiddleName() {
		return efxDitMiddleName;
	}

	public void setEfxDitMiddleName(String efxDitMiddleName) {
		this.efxDitMiddleName = efxDitMiddleName;
	}

	public String getEfxDitLastName() {
		return efxDitLastName;
	}

	public void setEfxDitLastName(String efxDitLastName) {
		this.efxDitLastName = efxDitLastName;
	}

	public String getEfxDitStreetAddress() {
		return efxDitStreetAddress;
	}

	public void setEfxDitStreetAddress(String efxDitStreetAddress) {
		this.efxDitStreetAddress = efxDitStreetAddress;
	}

	public String getEfxDitCity() {
		return efxDitCity;
	}

	public void setEfxDitCity(String efxDitCity) {
		this.efxDitCity = efxDitCity;
	}

	public String getEfxDitState() {
		return efxDitState;
	}

	public void setEfxDitState(String efxDitState) {
		this.efxDitState = efxDitState;
	}

	public String getEfxDitZip5() {
		return efxDitZip5;
	}

	public void setEfxDitZip5(String efxDitZip5) {
		this.efxDitZip5 = efxDitZip5;
	}

	public String getEfxDitEmail() {
		return efxDitEmail;
	}

	public void setEfxDitEmail(String efxDitEmail) {
		this.efxDitEmail = efxDitEmail;
	}

	public String getEfxDitMobileNum() {
		return efxDitMobileNum;
	}

	public void setEfxDitMobileNum(String efxDitMobileNum) {
		this.efxDitMobileNum = efxDitMobileNum;
	}

	public String getEfxDitJsonRequest() {
		return efxDitJsonRequest;
	}

	public void setEfxDitJsonRequest(String efxDitJsonRequest) {
		this.efxDitJsonRequest = efxDitJsonRequest;
	}

	public String getEfxDitJsonResponse() {
		return efxDitJsonResponse;
	}

	public void setEfxDitJsonResponse(String efxDitJsonResponse) {
		this.efxDitJsonResponse = efxDitJsonResponse;
	}

	public boolean isInitialized() {
		return isInitialized;
	}

	public void setInitialized(boolean isInitialized) {
		this.isInitialized = isInitialized;
	}

	public boolean isShowEfxDitRequestJsonPanel() {
		return showEfxDitRequestJsonPanel;
	}

	public void setShowEfxDitRequestJsonPanel(boolean showEfxDitRequestJsonPanel) {
		this.showEfxDitRequestJsonPanel = showEfxDitRequestJsonPanel;
	}

	public boolean isShowEfxDitResponseJsonPanel() {
		return showEfxDitResponseJsonPanel;
	}

	public void setShowEfxDitResponseJsonPanel(boolean showEfxDitResponseJsonPanel) {
		this.showEfxDitResponseJsonPanel = showEfxDitResponseJsonPanel;
	}

	public boolean isShowEfxDitSubmitBtn() {
		return showEfxDitSubmitBtn;
	}

	public void setShowEfxDitSubmitBtn(boolean showEfxDitSubmitBtn) {
		this.showEfxDitSubmitBtn = showEfxDitSubmitBtn;
	}

	public boolean isShowEfxDitGetDecisionBtn() {
		return showEfxDitGetDecisionBtn;
	}

	public void setShowEfxDitGetDecisionBtn(boolean showEfxDitGetDecisionBtn) {
		this.showEfxDitGetDecisionBtn = showEfxDitGetDecisionBtn;
	}
	
	public String getDitInitiateRequestStr() {
		return ditInitiateRequestStr;
	}

	public void setInitiateRequestStr(String ditInitiateRequestStr) {
		this.ditInitiateRequestStr = ditInitiateRequestStr;
	}

	public String getDitInitiateResponseStr() {
		return ditInitiateResponseStr;
	}

	public void setDitInitiateResponseStr(String ditInitiateResponseStr) {
		this.ditInitiateResponseStr = ditInitiateResponseStr;
	}

	
    /*========================================================================*/
	/*		                EQUIFAX SMFA INITIATE WEB SERVICE                           */
    /*========================================================================*/
    
    public void generateEfxSmfaInitRequest() {
    	CustomLogger.enter(this.getClass());
    	
		try {
			String kbaUid = "";
			if (!(efxSmfaSponsorUserId == null || efxSmfaSponsorUserId.isEmpty())) {
		       	efxSmfaSponsorUserId = efxSmfaSponsorUserId.trim();
				RefSponsor refSponsor = sponsorDataService.findBySponsorName(RefSponsor.SPONSOR_CUSTREG);
			   	Person person = personService.findFirstBySponsor(refSponsor, efxSmfaSponsorUserId);
			   	kbaUid = person.getKbaUid();
			}
			
			personVo = new PersonVo();
			personVo.setMobileNumber(efxSmfaInitMobileNum);
			personVo.setWebServiceCall(false);
			
			smfaInitiateRequest = equifaxService.prepareSmfaInitiateRequest(personVo, kbaUid, true);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in getting InitiateRequestModel request.", e);
		}
         
		String formattedJsonStr = "";
		if (smfaInitiateRequest != null) {
			Gson g = new Gson();
			smfaInitiateRequestStr = g.toJson(smfaInitiateRequest);
            formattedJsonStr = getFormattedJson(smfaInitiateRequestStr);
		}

		efxSmfaInitJsonRequest = formattedJsonStr;
		showEfxSmfaInitRequestJsonPanel = true;
		showEfxSmfaInitSubmitBtn = true;
    }
    
    public void submitEfxSmfaInitRequest() {
    	CustomLogger.enter(this.getClass());
    	
		try {
			smfaInitiateToken = equifaxService.generateEquifaxBearerToken(CALL_TO_SUPP_FAILED_MSG_FMT, ALL_AVAIL_SUPP_FAILED_MSG_FMT, false);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in generating Equifax Bearer Token for SMFA Initiate.", e);
		}
		
     	try {
     	   	smfaInitiateResponse = commonRestService.sendInitiateSMFARequest(smfaInitiateToken, smfaInitiateRequest);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in getting StatusRequestModel request.", e);
			return;
		}
    	
    	smfaInitiateResponseSessionId = smfaInitiateResponse.getSessionId();
    	
    	String formattedJsonStr = "";
    	Gson g = new Gson();
    	smfaInitiateResponseStr = g.toJson(smfaInitiateResponse);
    	formattedJsonStr = getFormattedJson(smfaInitiateResponseStr);
   	
      	efxSmfaInitJsonResponse = formattedJsonStr;
    	showEfxSmfaInitResponseJsonPanel = true;
     }
    
    /*========================================================================*/
	/*		                EQUIFAX SMFA STATUS WEB SERVICE                           */
    /*========================================================================*/
    
    public void generateEfxSmfaStatRequest() {
    	CustomLogger.enter(this.getClass());
    	
		try {
			smfaStatusRequest = equifaxService.prepareSmfaStatusRequest(efxSmfaStatMobileNum);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in getting StatusRequestModel request.", e);
		}
         
		String formattedJsonStr = "";
		if (smfaStatusRequest != null) {
			Gson g = new Gson();
			smfaStatusRequestStr = g.toJson(smfaStatusRequest);
            formattedJsonStr = getFormattedJson(smfaStatusRequestStr);
		}

		efxSmfaStatJsonRequest = formattedJsonStr;
		showEfxSmfaStatRequestJsonPanel = true;
		showEfxSmfaStatSubmitBtn = true;
    }
    
    public void submitEfxSmfaStatRequest() throws IOException {
    	CustomLogger.enter(this.getClass());
    	
     	String smfaSessionId = smfaInitiateResponseSessionId;
		
    	try {
			smfaStatusResponse = commonRestService.sendStatusSMFARequest(smfaInitiateToken, smfaSessionId, smfaStatusRequest);
		} catch (IOException e) {
			CustomLogger.error(this.getClass(), "Error sending status SMFA request "+e);
		}
    	
    	String formattedJsonStr = "";
    	if (smfaStatusResponse != null) {
	    	Gson g = new Gson();
	    	smfaStatusResponseStr = g.toJson(smfaStatusResponse);
	    	formattedJsonStr = getFormattedJson(smfaStatusResponseStr);
    	}
    	
      	efxSmfaStatJsonResponse = formattedJsonStr;
    	showEfxSmfaStatResponseJsonPanel = true;
     }  
    
    /*========================================================================*/
	/*		       PHONE VERIFICATION SUPPLIER DETERMINATION (MAIN)                */
    /*========================================================================*/
    
	public void determinePhoneVerificationSupplier() {
		CustomLogger.enter(this.getClass());
		

		RefSponsor refSponsor = sponsorDataService.findByPK(supplierDetSponsorId);

		personVo = new PersonVo();
		personVo.setSponsor(refSponsor.getSponsorName());
		personVo.setProofingLevelSought(RefLoaLevel.LOA_15);
		personVo.setSponsorUserId("TEST100");
	        
		RefOtpSupplier otpSupplier = verificationProviderService.determineVerificationMethod(personVo);
		pvSupplierSelected = personVo.getPhoneVerificationSupplierName();
		CustomLogger.debug(this.getClass(), "RefOtpSupplier selected Supplier:" + otpSupplier.getOtpSupplierName());
		CustomLogger.debug(this.getClass(), "PersonVo selected Supplier:" + personVo.getPhoneVerificationSupplierName());
		try {
			verifyPhone(personVo, otpSupplier);
			setSupplierDetermineSuccessMsg("Phone verification supplier was successfully determined!");
			setSupplierDetermineErrorMsg("");
		    setShowSupplierDetermineSuccessMsg(true);
		    setShowSupplierDetermineErrorMsg(false);

		} catch (Exception e) {
			setSupplierDetermineSuccessMsg("");
			setSupplierDetermineErrorMsg("Exception occurred in determining phone verification supplier. " + e.getMessage());
		    setShowSupplierDetermineSuccessMsg(false);
		    setShowSupplierDetermineErrorMsg(true);
			CustomLogger.error(this.getClass(), "Exception occurred in determining phone verification supplier.", e);
		}
		
		otpSupplierList = adminService.retrieveOtpAttemptConfigList(RefLoaLevel.LOA15_CODE, supplierDetSponsorId);
		
	}
	
	public void refreshSuppliersAttempts() {
	    	CustomLogger.enter(this.getClass());
	    	otpSupplierList = adminService.retrieveOtpAttemptConfigList(RefLoaLevel.LOA15_CODE, supplierDetSponsorId);
	}
	 
	private void verifyPhone(PersonVo personVo, RefOtpSupplier otpSupplier) throws Exception {
	   CustomLogger.enter(this.getClass());
	   
	   refLoaLevelService = WebApplicationContextUtils.getWebApplicationContext(context).getBean("refLoaLevelService", RefLoaLevelService.class);
       RefLoaLevel level = refLoaLevelService.findByCode(RefLoaLevel.LOA15_CODE);
	   RefSponsorDataService refSponsorService = (RefSponsorDataService)SpringUtil.getInstance(context).getBean("RefSponsorDataService");

	   if (otpSupplier.isEquifaxIDFSPhone() && failedEquifaxOTP) {
            CustomLogger.info(this.getClass(), String.format(CALL_TO_SUPP_FAILED_MSG_FMT, RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_NAME));
            RefSponsor sponsor = refSponsorService.findBySponsorName(personVo.getSponsor());
          	RefOtpSupplier nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor);
          	
          	if (nextSupplier.isEquifaxIDFSPhone() && failedEquifaxOTP) {
          		otpAttemptConfigService.reset(RefLoaLevel.LOA15_CODE, RefSponsor.SPONSOR_ID_CUSTREG);
              	nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor, RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID);
          	}
          	
          	personVo.setPhoneVerificationSupplierName(nextSupplier.getOtpSupplierName());
          	pvSupplierSelected = pvSupplierSelected + ", " +  (pvSupplierSelected.contains(personVo.getPhoneVerificationSupplierName()) ? "None" : personVo.getPhoneVerificationSupplierName());
    		personVo.setFailedEquifaxIDFSCall(true);
    		
    		if (!nextSupplier.isEquifaxIDFSPhone()) {
    			if ((nextSupplier.isEquifaxDITPhone() && !personVo.isFailedEquifaxDITCall()) 
    				|| (nextSupplier.isLexisNexisPhone() && !personVo.isFailedLexisNexisRDPCall())
    				|| (nextSupplier.isExperianPhone() && !personVo.isFailedExperianCrossCoreCall())) {

    	            CustomLogger.debug(this.getClass(), String.format(NEXT_AVAIL_SUPP_MSG_FMT, nextSupplier.getOtpSupplierName()));
     	            verifyPhone(personVo, nextSupplier);
        		}
    			else {
                    // In this scenario the all calls to available suppliers failed so exception needs to be thrown to result in transfer to the confirm cancel page
                    CustomLogger.error(this.getClass(), String.format(ALL_AVAIL_SUPP_FAILED_MSG_FMT, personVo.getSponsorUserId()));
                    personVo.setPhoneVerificationSupplierName(null);
      			}
    		}
    		else {
                // In this scenario the Equifax IDFS is configured to 100% so exception needs to be thrown to result in transfer to the confirm cancel page
    	        CustomLogger.error(this.getClass(), String.format(OTP_SWITCHING_ENABLED_MSG_FMT, RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_NAME, personVo.getSponsorUserId()));
                personVo.setPhoneVerificationSupplierName(null);
       		}
        }
        else if (otpSupplier.isEquifaxDITPhone() && failedEquifaxDIT) {
            CustomLogger.info(this.getClass(), String.format(CALL_TO_SUPP_FAILED_MSG_FMT, RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME));
            RefSponsor sponsor = refSponsorService.findBySponsorName(personVo.getSponsor());
          	RefOtpSupplier nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor);
        	
          	if (nextSupplier.isEquifaxDITPhone() && failedEquifaxDIT) {
          		otpAttemptConfigService.reset(RefLoaLevel.LOA15_CODE, RefSponsor.SPONSOR_ID_CUSTREG);
              	nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor, RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID);
          	}
          	
          	personVo.setPhoneVerificationSupplierName(nextSupplier.getOtpSupplierName());
        	pvSupplierSelected = pvSupplierSelected + ", " + (pvSupplierSelected.contains(personVo.getPhoneVerificationSupplierName()) ? "None" : personVo.getPhoneVerificationSupplierName());
    		personVo.setFailedEquifaxDITCall(true);
    	
    		if (!nextSupplier.isEquifaxDITPhone()) {
    			if ((nextSupplier.isEquifaxIDFSPhone() && !personVo.isFailedEquifaxIDFSCall()) 
    				|| (nextSupplier.isLexisNexisPhone() && !personVo.isFailedLexisNexisRDPCall())
    				|| (nextSupplier.isExperianPhone() && !personVo.isFailedExperianCrossCoreCall())) {

       	            CustomLogger.debug(this.getClass(), String.format(NEXT_AVAIL_SUPP_MSG_FMT, nextSupplier.getOtpSupplierName()));
       	            verifyPhone(personVo, nextSupplier);
        		}
     			else {
                    // In this scenario the all calls to available suppliers failed so exception needs to be thrown to result in transfer to the confirm cancel page
                    CustomLogger.error(this.getClass(), String.format(ALL_AVAIL_SUPP_FAILED_MSG_FMT, personVo.getSponsorUserId()));
                    personVo.setPhoneVerificationSupplierName(null);
     			}
    		}
    		else {
                // In this scenario the Equifax DIT is configured to 100% so exception needs to be thrown to result in transfer to the confirm cancel page
                CustomLogger.error(this.getClass(), String.format(OTP_SWITCHING_ENABLED_MSG_FMT, RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME, personVo.getSponsorUserId()));
                personVo.setPhoneVerificationSupplierName(null);
    		}
         }
        else if (otpSupplier.isLexisNexisPhone() && failedLexisNexisRDP) {
            CustomLogger.info(this.getClass(), String.format(CALL_TO_SUPP_FAILED_MSG_FMT, RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_NAME));
            RefSponsor sponsor = refSponsorService.findBySponsorName(personVo.getSponsor());
          	RefOtpSupplier nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor);
        	
          	if (nextSupplier.isLexisNexisPhone() && failedLexisNexisRDP) {
          		otpAttemptConfigService.reset(RefLoaLevel.LOA15_CODE, RefSponsor.SPONSOR_ID_CUSTREG);
              	nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor, RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID);
          	}
          	
          	personVo.setPhoneVerificationSupplierName(nextSupplier.getOtpSupplierName());
        	pvSupplierSelected = pvSupplierSelected + ", " + (pvSupplierSelected.contains(personVo.getPhoneVerificationSupplierName()) ? "None" : personVo.getPhoneVerificationSupplierName());
    		personVo.setFailedLexisNexisRDPCall(true);

    		if (!nextSupplier.isLexisNexisPhone()) {
    			if ((nextSupplier.isEquifaxIDFSPhone() && !personVo.isFailedEquifaxIDFSCall()) 
    				|| (nextSupplier.isEquifaxDITPhone() && !personVo.isFailedEquifaxDITCall())) {
   
       	            CustomLogger.debug(this.getClass(), String.format(NEXT_AVAIL_SUPP_MSG_FMT, nextSupplier.getOtpSupplierName()));
       	            verifyPhone(personVo, nextSupplier);
        		}
    			else {
                    // In this scenario the all calls to available suppliers failed so exception needs to be thrown to result in transfer to the confirm cancel page
                    CustomLogger.error(this.getClass(), String.format(ALL_AVAIL_SUPP_FAILED_MSG_FMT, personVo.getSponsorUserId()));
                    personVo.setPhoneVerificationSupplierName(null);
         		}
    		}
    		else {
                // In this scenario the LexisNexis RDP is configured to 100% so exception needs to be thrown to result in transfer to the confirm cancel page
    			CustomLogger.error(this.getClass(), String.format(OTP_SWITCHING_ENABLED_MSG_FMT, RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_NAME, personVo.getSponsorUserId()));
    			personVo.setPhoneVerificationSupplierName(null);
     		}
    	}
        else if (otpSupplier.isExperianPhone() && failedExperianCC) {
            CustomLogger.info(this.getClass(), String.format(CALL_TO_SUPP_FAILED_MSG_FMT, RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_NAME));
            RefSponsor sponsor = refSponsorService.findBySponsorName(personVo.getSponsor());
          	RefOtpSupplier nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor);

          	if (nextSupplier.isExperianPhone() && failedExperianCC) {
          		otpAttemptConfigService.reset(RefLoaLevel.LOA15_CODE, RefSponsor.SPONSOR_ID_CUSTREG);
              	nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor, RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID);
          	}
          	
          	personVo.setPhoneVerificationSupplierName(nextSupplier.getOtpSupplierName());
        	pvSupplierSelected = pvSupplierSelected + ", " + (pvSupplierSelected.contains(personVo.getPhoneVerificationSupplierName()) ? "None" : personVo.getPhoneVerificationSupplierName());
    		personVo.setFailedExperianCrossCoreCall(true);
 
    		if (!nextSupplier.isExperianPhone()) {
    			if ((nextSupplier.isEquifaxIDFSPhone() && !personVo.isFailedEquifaxIDFSCall()) 
    				|| (nextSupplier.isEquifaxDITPhone() && !personVo.isFailedEquifaxDITCall())
    				|| (nextSupplier.isLexisNexisPhone() && !personVo.isFailedLexisNexisRDPCall())) {

  				    CustomLogger.debug(this.getClass(), String.format(NEXT_AVAIL_SUPP_MSG_FMT, nextSupplier.getOtpSupplierName()));
       	            
       	            verifyPhone(personVo, nextSupplier);
        		}
    			else {
                    // In this scenario the all calls to available suppliers failed so exception needs to be thrown to result in transfer to the confirm cancel page
                    CustomLogger.error(this.getClass(), String.format(ALL_AVAIL_SUPP_FAILED_MSG_FMT, personVo.getSponsorUserId()));
                    personVo.setPhoneVerificationSupplierName(null);
         		}
    		}
    		else {
                // In this scenario the LexisNexis RDP is configured to 100% so exception needs to be thrown to result in transfer to the confirm cancel page
    			CustomLogger.error(this.getClass(), String.format(OTP_SWITCHING_ENABLED_MSG_FMT, RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_NAME, personVo.getSponsorUserId()));
    			personVo.setPhoneVerificationSupplierName(null);
     		}
    	}
    }
 
    /*========================================================================*/
	/*		       PHONE VERIFICATION SUPPLIER DETERMINATION (INF)                 */
    /*========================================================================*/
    
	public void determinePhoneVerificationSupplier2() {
		CustomLogger.enter(this.getClass());
		

		RefSponsor refSponsor = sponsorDataService.findByPK(supplierDetSponsorId2);

		personVo = new PersonVo();
		personVo.setSponsor(refSponsor.getSponsorName());
		personVo.setProofingLevelSought(RefLoaLevel.LOA_15);
		personVo.setSponsorUserId("TEST100");
	       
        personVo.setLexisNexisIndividualNotFound(true);
		RefOtpSupplier otpSupplier = verificationProviderService.determineVerificationMethod(personVo);
		pvSupplierSelected2 = personVo.getPhoneVerificationSupplierName();
		CustomLogger.debug(this.getClass(), "RefOtpSupplier selected Supplier2:" + otpSupplier.getOtpSupplierName());
		CustomLogger.debug(this.getClass(), "PersonVo selected Supplier2:" + personVo.getPhoneVerificationSupplierName());
		try {
			verifyPhoneInf(personVo, otpSupplier);
			setSupplierDetermine2SuccessMsg("Phone verification supplier (for Indidividual-Not-Found was successfully determined!");
			setSupplierDetermine2ErrorMsg("");
		    setShowSupplierDetermine2SuccessMsg(true);
		    setShowSupplierDetermine2ErrorMsg(false);

		} catch (Exception e) {
			setSupplierDetermine2SuccessMsg("");
			setSupplierDetermine2ErrorMsg("Exception occurred in determining phone verification supplier (inf). " + e.getMessage());
		    setShowSupplierDetermine2SuccessMsg(false);
		    setShowSupplierDetermine2ErrorMsg(true);
			CustomLogger.error(this.getClass(), "Exception occurred in determining phone verification supplier (inf).", e);
		}
		
		otpSupplierList2 = adminService.retrieveInfPvAttemptConfigList(RefLoaLevel.LOA15_CODE, supplierDetSponsorId2);
		
	}
	
	public void refreshSuppliersAttempts2() {
	    	CustomLogger.enter(this.getClass());
	    	otpSupplierList2 = adminService.retrieveInfPvAttemptConfigList(RefLoaLevel.LOA15_CODE, supplierDetSponsorId2);
	}
	 
	public void verifyPhoneInf(PersonVo personVo, RefOtpSupplier otpSupplier) throws Exception {
	   CustomLogger.enter(this.getClass());
	   
	   refLoaLevelService = WebApplicationContextUtils.getWebApplicationContext(context).getBean("refLoaLevelService", RefLoaLevelService.class);
       RefLoaLevel level = refLoaLevelService.findByCode(RefLoaLevel.LOA15_CODE);
	   RefSponsorDataService refSponsorService = (RefSponsorDataService)SpringUtil.getInstance(context).getBean("RefSponsorDataService");

	   if (otpSupplier.isEquifaxIDFSPhone() && failedEquifaxOTP2) {
            CustomLogger.info(this.getClass(), String.format(CALL_TO_SUPP_FAILED_MSG_FMT, RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_NAME));
            RefSponsor sponsor = refSponsorService.findBySponsorName(personVo.getSponsor());
            personVo.setLexisNexisIndividualNotFound(true);
          	RefOtpSupplier nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor);
          	
          	if (nextSupplier.isEquifaxIDFSPhone() && failedEquifaxOTP2) {
          		rpInfPvAttemptConfigService.reset(RefLoaLevel.LOA15_CODE, RefSponsor.SPONSOR_ID_CUSTREG);
                personVo.setLexisNexisIndividualNotFound(true);
          		nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor, RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID);
          	}
          	
          	personVo.setPhoneVerificationSupplierName(nextSupplier.getOtpSupplierName());
          	pvSupplierSelected2 = pvSupplierSelected2 + ", " +  (pvSupplierSelected2.contains(personVo.getPhoneVerificationSupplierName()) ? "None" : personVo.getPhoneVerificationSupplierName());
    		personVo.setFailedEquifaxIDFSCall(true);
    		
    		if (!nextSupplier.isEquifaxIDFSPhone()) {
    			if ((nextSupplier.isEquifaxDITPhone() && !personVo.isFailedEquifaxDITCall()) 
    				|| (nextSupplier.isLexisNexisPhone() && !personVo.isFailedLexisNexisRDPCall())
    				|| (nextSupplier.isExperianPhone() && !personVo.isFailedExperianCrossCoreCall())) {

    	            CustomLogger.debug(this.getClass(), String.format(NEXT_AVAIL_SUPP_MSG_FMT, nextSupplier.getOtpSupplierName()));
    	            verifyPhoneInf(personVo, nextSupplier);
        		}
    			else {
                    // In this scenario the all calls to available suppliers failed so exception needs to be thrown to result in transfer to the confirm cancel page
                    CustomLogger.error(this.getClass(), String.format(ALL_AVAIL_SUPP_FAILED_MSG_FMT, personVo.getSponsorUserId()));
                    personVo.setPhoneVerificationSupplierName(null);
      			}
    		}
    		else {
                // In this scenario the Equifax IDFS is configured to 100% so exception needs to be thrown to result in transfer to the confirm cancel page
    	        CustomLogger.error(this.getClass(), String.format(OTP_SWITCHING_ENABLED_MSG_FMT, RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_NAME, personVo.getSponsorUserId()));
                personVo.setPhoneVerificationSupplierName(null);
       		}
        }
        else if (otpSupplier.isEquifaxDITPhone() && failedEquifaxDIT2) {
            CustomLogger.info(this.getClass(), String.format(CALL_TO_SUPP_FAILED_MSG_FMT, RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME));
            RefSponsor sponsor = refSponsorService.findBySponsorName(personVo.getSponsor());
            personVo.setLexisNexisIndividualNotFound(true);
          	RefOtpSupplier nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor);
        	
          	if (nextSupplier.isEquifaxDITPhone() && failedEquifaxDIT2) {
          		rpInfPvAttemptConfigService.reset(RefLoaLevel.LOA15_CODE, RefSponsor.SPONSOR_ID_CUSTREG);
                personVo.setLexisNexisIndividualNotFound(true);
          		nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor, RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID);
          	}
          	
          	personVo.setPhoneVerificationSupplierName(nextSupplier.getOtpSupplierName());
        	pvSupplierSelected2 = pvSupplierSelected2 + ", " + (pvSupplierSelected2.contains(personVo.getPhoneVerificationSupplierName()) ? "None" : personVo.getPhoneVerificationSupplierName());
    		personVo.setFailedEquifaxDITCall(true);
    	
    		if (!nextSupplier.isEquifaxDITPhone()) {
    			if ((nextSupplier.isEquifaxIDFSPhone() && !personVo.isFailedEquifaxIDFSCall()) 
    				|| (nextSupplier.isLexisNexisPhone() && !personVo.isFailedLexisNexisRDPCall())
    				|| (nextSupplier.isExperianPhone() && !personVo.isFailedExperianCrossCoreCall())) {

       	            CustomLogger.debug(this.getClass(), String.format(NEXT_AVAIL_SUPP_MSG_FMT, nextSupplier.getOtpSupplierName()));
       	            verifyPhoneInf(personVo, nextSupplier);
        		}
     			else {
                    // In this scenario the all calls to available suppliers failed so exception needs to be thrown to result in transfer to the confirm cancel page
                    CustomLogger.error(this.getClass(), String.format(ALL_AVAIL_SUPP_FAILED_MSG_FMT, personVo.getSponsorUserId()));
                    personVo.setPhoneVerificationSupplierName(null);
     			}
    		}
    		else {
                // In this scenario the Equifax DIT is configured to 100% so exception needs to be thrown to result in transfer to the confirm cancel page
                CustomLogger.error(this.getClass(), String.format(OTP_SWITCHING_ENABLED_MSG_FMT, RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME, personVo.getSponsorUserId()));
                personVo.setPhoneVerificationSupplierName(null);
    		}
         }
        else if (otpSupplier.isLexisNexisPhone() && failedLexisNexisRDP2) {
            CustomLogger.info(this.getClass(), String.format(CALL_TO_SUPP_FAILED_MSG_FMT, RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_NAME));
            RefSponsor sponsor = refSponsorService.findBySponsorName(personVo.getSponsor());
            personVo.setLexisNexisIndividualNotFound(true);
          	RefOtpSupplier nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor);
        	
          	if (nextSupplier.isLexisNexisPhone() && failedLexisNexisRDP2) {
          		rpInfPvAttemptConfigService.reset(RefLoaLevel.LOA15_CODE, RefSponsor.SPONSOR_ID_CUSTREG);
                personVo.setLexisNexisIndividualNotFound(true);
          		nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor, RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID);
          	}
          	
          	personVo.setPhoneVerificationSupplierName(nextSupplier.getOtpSupplierName());
        	pvSupplierSelected2 = pvSupplierSelected2 + ", " + (pvSupplierSelected2.contains(personVo.getPhoneVerificationSupplierName()) ? "None" : personVo.getPhoneVerificationSupplierName());
    		personVo.setFailedLexisNexisRDPCall(true);

    		if (!nextSupplier.isLexisNexisPhone()) {
    			if ((nextSupplier.isEquifaxIDFSPhone() && !personVo.isFailedEquifaxIDFSCall()) 
    				|| (nextSupplier.isEquifaxDITPhone() && !personVo.isFailedEquifaxDITCall())) {
   
       	            CustomLogger.debug(this.getClass(), String.format(NEXT_AVAIL_SUPP_MSG_FMT, nextSupplier.getOtpSupplierName()));
       	            verifyPhone(personVo, nextSupplier);
        		}
    			else {
                    // In this scenario the all calls to available suppliers failed so exception needs to be thrown to result in transfer to the confirm cancel page
                    CustomLogger.error(this.getClass(), String.format(ALL_AVAIL_SUPP_FAILED_MSG_FMT, personVo.getSponsorUserId()));
                    personVo.setPhoneVerificationSupplierName(null);
         		}
    		}
    		else {
                // In this scenario the LexisNexis RDP is configured to 100% so exception needs to be thrown to result in transfer to the confirm cancel page
    			CustomLogger.error(this.getClass(), String.format(OTP_SWITCHING_ENABLED_MSG_FMT, RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_NAME, personVo.getSponsorUserId()));
    			personVo.setPhoneVerificationSupplierName(null);
     		}
    	}
        else if (otpSupplier.isExperianPhone() && failedExperianCC2) {
            CustomLogger.info(this.getClass(), String.format(CALL_TO_SUPP_FAILED_MSG_FMT, RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_NAME));
            RefSponsor sponsor = refSponsorService.findBySponsorName(personVo.getSponsor());
            personVo.setLexisNexisIndividualNotFound(true);
          	RefOtpSupplier nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor);

          	if (nextSupplier.isExperianPhone() && failedExperianCC2) {
          		rpInfPvAttemptConfigService.reset(RefLoaLevel.LOA15_CODE, RefSponsor.SPONSOR_ID_CUSTREG);
                personVo.setLexisNexisIndividualNotFound(true);
          		nextSupplier = verificationProviderService.determineVerificationMethod(personVo, level, sponsor, RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID);
          	}
          	
          	personVo.setPhoneVerificationSupplierName(nextSupplier.getOtpSupplierName());
        	pvSupplierSelected2 = pvSupplierSelected2 + ", " + (pvSupplierSelected2.contains(personVo.getPhoneVerificationSupplierName()) ? "None" : personVo.getPhoneVerificationSupplierName());
    		personVo.setFailedExperianCrossCoreCall(true);
 
    		if (!nextSupplier.isExperianPhone()) {
    			if ((nextSupplier.isEquifaxIDFSPhone() && !personVo.isFailedEquifaxIDFSCall()) 
    				|| (nextSupplier.isEquifaxDITPhone() && !personVo.isFailedEquifaxDITCall())
    				|| (nextSupplier.isLexisNexisPhone() && !personVo.isFailedLexisNexisRDPCall())) {

  				    CustomLogger.debug(this.getClass(), String.format(NEXT_AVAIL_SUPP_MSG_FMT, nextSupplier.getOtpSupplierName()));
       	            
       	            verifyPhone(personVo, nextSupplier);
        		}
    			else {
                    // In this scenario the all calls to available suppliers failed so exception needs to be thrown to result in transfer to the confirm cancel page
                    CustomLogger.error(this.getClass(), String.format(ALL_AVAIL_SUPP_FAILED_MSG_FMT, personVo.getSponsorUserId()));
                    personVo.setPhoneVerificationSupplierName(null);
         		}
    		}
    		else {
                // In this scenario the LexisNexis RDP is configured to 100% so exception needs to be thrown to result in transfer to the confirm cancel page
    			CustomLogger.error(this.getClass(), String.format(OTP_SWITCHING_ENABLED_MSG_FMT, RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_NAME, personVo.getSponsorUserId()));
    			personVo.setPhoneVerificationSupplierName(null);
     		}
    	}
    }
	
   /*========================================================================*/
	/*		       PHONE REMOTE PROOFING STATUS DETAIL                       */
   /*========================================================================*/
    
   public void retrievePerson() {
	   retrievePerson(false);
   }
   
   public void retrievePerson(boolean refresh) {
	   setRpRetrieveStatusErrorMsg("");
	   setShowRetrieveStatusErrorMsg(false);
	   
	   if (rpPerson != null && !refresh) {
	    	return;
	   }
	   
	   if (rpRefSponsor == null) {
		   rpRefSponsor = sponsorDataService.findByPK(rpSelectedRefSponsorId);
	   }
       
	   rpPerson = personService.findFirstBySponsor(rpRefSponsor, rpPhoneSponsorUserId);

	   if (rpPerson == null) {
		   setRpRetrieveStatusErrorMsg("No person found on the selected sponsor and sponsor user id.");
		   setShowRetrieveStatusErrorMsg(true);
	   }
   }
   
   public void retrieveRpEventList() {

	   if ((rpEventList == null || rpEventList.isEmpty())) {
		   retrievePerson();
		   rpEventList = rpEventDataService.findEventByPersonId(rpPerson.getPersonId());
		   if ((rpEventList== null || rpEventList.isEmpty())) {
			   setRpRetrieveStatusErrorMsg("No RpEvent found for this person.");
			   setShowRetrieveStatusErrorMsg(true);
		   }
	   }
   }
   
   public void retrievePhoneSupplier() {
	   if (rpPhoneSupplier == null) {
		   if (rpEventList == null || rpEventList.isEmpty()) {
			   rpEventList = rpEventDataService.findEventByPersonId(rpPerson.getPersonId());
		   }
		   
		   if (!(rpEventList == null || rpEventList.isEmpty())) {
			   rpPhoneSupplier = rpEventList.get(0).getRefOtpSupplier();
		   }
		   else {
			   setRpRetrieveStatusErrorMsg("No RpEvent found for this person.");
			   setShowRetrieveStatusErrorMsg(true);
		   }
	   }
   }
   
   public void retrieveRefOtpVelocity() {
	   if (rpVelocity == null) {
		   if (rpPhoneSupplier == null) {
			   retrievePhoneSupplier();
		   }
		   
		   rpVelocity = refOtpVelocityService.findByVelocityType(rpPhoneSupplier, IPSConstants.VELOCITY_TYPE_PHONE);
		   if (rpVelocity == null) {
			    setRpRetrieveStatusErrorMsg("No RefOtpVelocity found for the selected supplier.");
			    setShowRetrieveStatusErrorMsg(true);
		   }
	   }
   }
   
   public void retrievePersonDataDetail() {
 	   try {
		    retrievePerson(true);
		    
		    PersonData personData = rpPerson.getPersonData();
		    PersonProofingStatus personProofingStatus = rpPerson.getStatusForLoaSought(RefLoaLevel.LOA_15);
	 
		    setRpPersonId(rpPerson.getPersonId());

		    if (personData != null) {
		        setRpFirstLastName(String.format(DBL_ENTRY_VALUE_FMT, personData.getFirstName(), personData.getLastName()));
 		        setRpEmailAddress(personData.getEmailAddress());
		    }
		   	setRpRemoteProofingStatus(personProofingStatus.getStatusDescription());
	   }
	   catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
	   }
   }
   
   public void retrieveAttemptsLockoutDataDetail() {
	   try {
		   	retrievePerson();
		   	retrievePhoneSupplier();
	    	retrieveRefOtpVelocity();
	        
	        int attemptsAllowed = rpVelocity.getAttemptsAllowed();
	        int attemptWindow =  rpVelocity.getAttemptWindow();
	        Timestamp current = DateTimeUtil.getCurrentTime();
	        Timestamp window = new Timestamp(DateTimeUtil.getDateMinusHours(current, attemptWindow).getTime());
	        
	        Long phoneEventCount = rpEventDataService.getPhoneCountInWindow(attemptWindow, attemptsAllowed, attemptWindow);
	        setRpNumPhoneAttempts(phoneEventCount);
	        setRpPhoneAttemptLimit(attemptsAllowed);
	        setRpPhoneAttemptWindow(attemptWindow);
	        
	        PersonVo rpPersonVo = new PersonVo();
	        rpPersonVo.setSponsorUserId(rpPhoneSponsorUserId);
	       	RefLoaLevel level = refLoaLevelService.findByCode(RefLoaLevel.LOA15_CODE);
	       	
        	String attemptWindowDate = DateTimeUtil.getDateString(window, DateTimeUtil.DATE_FORMAT);
        	String attemptWindowTime = DateTimeUtil.getDateString(window, DateTimeUtil.TIME_FORMAT);
	       	setRpPhoneAttemptWindowDateTime(String.format(DBL_ENTRY_VALUE_FMT, attemptWindowDate, attemptWindowTime));
	       	
	        OtpLockoutInfo lockout = lockoutService.findCurrentLockoutForSupplier(rpPerson.getPersonId(), rpPhoneSupplier, level);
	        if (lockout != null) {
	        	String formattedLockExpireDate = DateTimeUtil.getDateString(lockout.getLockoutExpiresDatetime(), DateTimeUtil.DATE_FORMAT);
	        	String formattedLockExpireTime = DateTimeUtil.getDateString(lockout.getLockoutExpiresDatetime(), DateTimeUtil.TIME_FORMAT);
	        	setRpPhoneLockoutExpirationDateTime(String.format(DBL_ENTRY_VALUE_FMT, formattedLockExpireDate, formattedLockExpireTime));
	        }
	        
	        boolean lockoutStillInEffect = proofingService.lockoutStillInEffect(rpPerson, rpPersonVo, rpPhoneSupplier, level);
	        
	        setRpPhoneLockoutInEffect(lockoutStillInEffect ? "Yes" : "No");
	    	setRpPhoneLockoutSupplier(rpPhoneSupplier.getOtpSupplierName());
	   }
	   catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
	   }
    }
    
    public void retrievePhoneAttemptsList() {
 	   try {
 		  retrieveRpEventList();
 		  rpPhoneAttemptList = new ArrayList<>();
            
 		  for(RpEvent event : rpEventList) {
 			  PhoneAttemptVo attempt = new PhoneAttemptVo();
           		attempt.setEventId(event.getEventId());
           		attempt.setSupplierId(event.getOtpSupplierId());
           		attempt.setTransactionId(event.getOtpTransactionId());
           		attempt.setPhoneDecision(event.getRpPhoneVerification().getPhoneVerificationDecision());
           		attempt.setOverallAssessment(event.getRpPhoneVerification().getOverallAssessment());
                String formattedSentDate = DateTimeUtil.getDateString(event.getRpPhoneVerification().getDecisionDateTime(), DateTimeUtil.DATE_FORMAT);
                String formattedSentTime = DateTimeUtil.getDateString(event.getRpPhoneVerification().getDecisionDateTime(), DateTimeUtil.TIME_FORMAT);
                attempt.setDecisionDatetime(String.format(DBL_ENTRY_VALUE_FMT, formattedSentDate, formattedSentTime));
           		rpPhoneAttemptList.add(attempt);
 		  }
 	   }
	   catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
	   }
    }
    
    public void retrieveOtpLinkVelocityDetail() {
  	   try {
	    	retrievePerson();
	    	retrievePhoneSupplier();
	       	retrieveRefOtpVelocity();
	       	Timestamp window = null;
	        Timestamp currentTime = DateTimeUtil.getCurrentTime(); 
	        
	        int attemptsAllowed = rpVelocity.getAttemptsAllowed();
	        int attemptWindow =  rpVelocity.getAttemptWindow();
	        window = new Timestamp(DateTimeUtil.getDateMinusHours(currentTime, attemptWindow).getTime());
	        setRpOtpLinkAttemptLimit(attemptsAllowed);
	        setRpOtpLinkAttemptWindow(attemptWindow);
	        
	        rpOtpLinkAttemptList = new ArrayList<>();
	        if (rpPhoneSupplier.isEquifaxDITPhone()) {
	        	if (rpSmfaAttemptList == null) {
	        		rpSmfaAttemptList = rpSmfaAttemptService.getSmfaAttemptsListInWindow(attemptWindow, window, currentTime, attemptsAllowed, attemptWindow);
        		
	        	}
	        	
	        	int numAttempts = rpSmfaAttemptList.size();
	        	setRpNumOtpLinkAttempts(numAttempts);
				
	            for(RpSmfaAttempt attempt : rpSmfaAttemptList) {
	            	OtpLinkAttemptVo vo = new OtpLinkAttemptVo();
	            	vo.setAttemptId(attempt.getMfaAttempId());
	            	vo.setSupplierId(RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID);
	            	vo.setOtpMfaDecision(attempt.getMfaDecision());
	                String formattedSentDate = DateTimeUtil.getDateString(attempt.getMfaSentDatetime(), DateTimeUtil.DATE_FORMAT);
	                String formattedSentTime = DateTimeUtil.getDateString(attempt.getMfaSentDatetime(), DateTimeUtil.TIME_FORMAT);
	                vo.setSentDatetime(String.format(DBL_ENTRY_VALUE_FMT, formattedSentDate, formattedSentTime));
	            	rpOtpLinkAttemptList.add(vo);
	            }
	        }
	        else {
	            List<String> attemptTypeList = new ArrayList<>();
	            attemptTypeList.add(IPSConstants.OTP_ATTEMPT_TYPE_INITIAL);
	            attemptTypeList.add(IPSConstants.OTP_ATTEMPT_TYPE_RENEW);
	
	            if (rpOtpAttemptList == null) {
	            	rpOtpAttemptList = rpOtpAttemptDataService.getOtpAttemptListInWindow(attemptWindow, attemptsAllowed, attemptWindow, attemptWindow);
	            }

	        	int numAttempts = rpOtpAttemptList.size();
	        	setRpNumOtpLinkAttempts(numAttempts);

	            for(RpOtpAttempt attempt : rpOtpAttemptList) {
	            	OtpLinkAttemptVo vo = new OtpLinkAttemptVo();
	            	vo.setAttemptId(attempt.getOtpAttemptId());
	            	vo.setSupplierId(rpPhoneSupplier.getOtpSupplierId());
	            	vo.setOtpMfaDecision(attempt.getOtpDecision());
	                String formattedSentDate = DateTimeUtil.getDateString(attempt.getOtpSentDateTime(), DateTimeUtil.DATE_FORMAT);
	                String formattedSentTime = DateTimeUtil.getDateString(attempt.getOtpSentDateTime(), DateTimeUtil.TIME_FORMAT);
	                vo.setSentDatetime(String.format(DBL_ENTRY_VALUE_FMT, formattedSentDate, formattedSentTime));

	            	rpOtpLinkAttemptList.add(vo);
	            }
	        }
 	   }
	   catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
	   }
    }
    
    public void retrieveOtpLinkAttemptList() {

   	   try {
 	    	retrievePerson();
	    	retrievePhoneSupplier();
	    	retrieveRefOtpVelocity();
	       	Timestamp window = null;
	        Timestamp currentTime = DateTimeUtil.getCurrentTime(); 
	        
            int attemptWindow =  rpVelocity.getAttemptWindow();
	        window = new Timestamp(DateTimeUtil.getDateMinusHours(currentTime, attemptWindow).getTime());

	        rpOtpLinkAttemptList = new ArrayList<>();
	        if (rpPhoneSupplier.isEquifaxDITPhone()) {
	        	if (rpSmfaAttemptList == null) {
	        		rpSmfaAttemptList = rpSmfaAttemptService.getSmfaAttemptsListInWindow(attemptWindow, attemptWindow, attemptWindow, attemptWindow);;
	           	}
	        	
	        	int numAttempts = rpSmfaAttemptList.size();
	        	setRpNumOtpLinkAttempts(numAttempts);
	             
	            for(RpSmfaAttempt attempt : rpSmfaAttemptList) {
	            	OtpLinkAttemptVo vo = new OtpLinkAttemptVo();
	            	vo.setAttemptId(attempt.getMfaAttempId());
	            	vo.setSupplierId(RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID);
	            	vo.setOtpMfaDecision(attempt.getMfaDecision());
	                String formattedSentDate = DateTimeUtil.getDateString(attempt.getMfaSentDatetime(), DateTimeUtil.DATE_FORMAT);
	                String formattedSentTime = DateTimeUtil.getDateString(attempt.getMfaSentDatetime(), DateTimeUtil.TIME_FORMAT);
	                vo.setSentDatetime(String.format(DBL_ENTRY_VALUE_FMT, formattedSentDate, formattedSentTime));
	            	rpOtpLinkAttemptList.add(vo);
	            }
	        }
	        else {
	            List<String> attemptTypeList = new ArrayList<>();
	            attemptTypeList.add(IPSConstants.OTP_ATTEMPT_TYPE_INITIAL);
	            attemptTypeList.add(IPSConstants.OTP_ATTEMPT_TYPE_RENEW);
	
	            if (rpOtpAttemptList == null) {
	            	rpOtpAttemptList = rpOtpAttemptDataService.getOtpAttemptListInWindow(attemptWindow, attemptWindow, attemptWindow, attemptWindow);
	            }
	            
	            for(RpOtpAttempt attempt : rpOtpAttemptList) {
	            	OtpLinkAttemptVo vo = new OtpLinkAttemptVo();
	            	vo.setAttemptId(attempt.getOtpAttemptId());
	            	vo.setSupplierId(rpPhoneSupplier.getOtpSupplierId());
	            	vo.setOtpMfaDecision(attempt.getOtpDecision());
	                String formattedSentDate = DateTimeUtil.getDateString(attempt.getOtpSentDateTime(), DateTimeUtil.DATE_FORMAT);
	                String formattedSentTime = DateTimeUtil.getDateString(attempt.getOtpSentDateTime(), DateTimeUtil.TIME_FORMAT);
	                vo.setSentDatetime(String.format(DBL_ENTRY_VALUE_FMT, formattedSentDate, formattedSentTime));
	            	rpOtpLinkAttemptList.add(vo);
	            }
	        }
 	   }
	   catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
	   }
    }
    
    public void retrieveAuditPersonList() {
   	   try {
   		   retrievePerson();
   		   setRpAuditPersonList(rpEventDataService.getAuditPersonList(rpRefSponsor.getSponsorId(), rpPhoneSponsorUserId));
 	   }
	   catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
	   }
   	}
    
    public void retrieveDeviceReputationList() {
   	   try {
   		   retrievePerson();
   		   setRpDeviceReputationList(rpDeviceReputationService.getListByPersonId(rpPerson.getPersonId()));
	   }
	   catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
	   }
    }
    
    public void retrieveDeviceReputationResponseList() {
   	   try {
	    	retrievePerson();
	    	List<RpDeviceReputationResponse> entityList = rpDeviceReputationResponseService.getListByPersonId(rpPerson.getPersonId()); 

	    	if (!(entityList== null || entityList.isEmpty())) {
	    		rpDeviceReputationResponseList = new ArrayList<>();
		    	Gson g = new Gson();
		    	for(RpDeviceReputationResponse entity : entityList) {
		    		DeviceReputationResponseVo vo = new DeviceReputationResponseVo();
	                String createDateFmtd = DateTimeUtil.getDateString(entity.getCreateDate(), DateTimeUtil.DATE_FORMAT);
	                String responseStr = entity.getResponse();
	                
	                RdpDeviceAssessmentResponseModel responseEntity = g.fromJson(responseStr, RdpDeviceAssessmentResponseModel.class);
	                if (responseEntity != null) {
	                	RdpStatusModel statusModel = responseEntity.getStatus();
	                	if (statusModel != null) {
	                		RdpReasonCodeModel trxCodeModel = statusModel.getTransactionReasonCode();
	                		vo.setLexID(statusModel.getLexID());
	                		vo.setTransactionStatus(statusModel.getTransactionStatus());
	                 		vo.setTransactionCode(trxCodeModel.getCode()); 
	                	}
	                	
	                	List<RdpProductModel> productList = responseEntity.getProducts();
	                	for(RdpProductModel prod : productList) {
	                		if("Discovery".equalsIgnoreCase(prod.getProductType())) {
	                			RdpReasonCodeModel prodCodeModel = prod.getProductReason();
	                			vo.setDiscoveryCode(prodCodeModel.getCode()); 
	                			vo.setDiscoveryStatus(prod.getProductStatus()); 
	                		}
	                		if("Velocity".equalsIgnoreCase(prod.getProductType())) {
	                			RdpReasonCodeModel prodCodeModel = prod.getProductReason();
	                			vo.setVelocityCode(prodCodeModel.getCode());
	                			vo.setVelocityStatus(prod.getProductStatus());
	                		}
	                		if("DeviceAssessment".equalsIgnoreCase(prod.getProductType())) {
	                			RdpReasonCodeModel prodCodeModel = prod.getProductReason();
	                			vo.setDeviceConfig(prod.getProductConfigurationName()); 
	                			vo.setDeviceCode(prodCodeModel.getCode()); 
	                			vo.setDeviceStatus(prod.getProductStatus()); 
	                			prod.getItems();
	                		}
	                	}
	                	
	                	List<RdpPassThroughModel> ptModeList = responseEntity.getPassThroughs();
	                	for(RdpPassThroughModel pt : ptModeList) {
	                		if ("device.assessment".equalsIgnoreCase(pt.getType())) {
	                			String ptDataStr = pt.getData();
	                		    RdpPassThroughDataModel ptData = g.fromJson(ptDataStr, RdpPassThroughDataModel.class);
	                		    RdpTrustDefenderResponseExModel trustDefResp = ptData.getTrustDefenderResponseEx();
	                		    
	                		    if (trustDefResp != null) {
	                		    	RdpPassThroughResponseModel ptResp = trustDefResp.getResponse();
	                		    	if (ptResp != null) {
	                		    		RdpPassThroughResponseSummaryModel ptSumm = ptResp.getSummary();
	                		    		if (ptSumm != null) {
	                		    			vo.setReviewStatus(ptSumm.getReviewStatus()); 
	                		    			vo.setRequestId(ptSumm.getRequestId()); 
	                		    			vo.setRequestResult(ptSumm.getRequestResult()); 
	                		    		}
	                		    	}
	                		    }
	                		}
	                	}
	                	ptModeList.get(0);
	                }
	                
	                vo.setAssessmentDate(createDateFmtd);
	                rpDeviceReputationResponseList.add(vo);
		    	}
		   	}
	   }
	   catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
	   }
    }
    
    public void retrieveDitResponseList() {
    	try {
	    	retrievePerson();
	    	List<RpDitResponse> entityList = rpDitResponseService.getListByPersonId(rpPerson.getPersonId());

	       	if (!(entityList== null || entityList.isEmpty())) {
	       		rpDitResponseList = new ArrayList<>();
		    	Gson g = new Gson();
	    	
		    	for(RpDitResponse entity : entityList) {
		    		DitResponseVo vo = new DitResponseVo();
		            String createDateFmtd = DateTimeUtil.getDateString(entity.getCreateDate(), DateTimeUtil.DATE_FORMAT);
		    		String requestStr = entity.getRequest();
		    		String responseStr = entity.getResponse();
		    		
		    		InitiateDITRequestModel requestEntity = g.fromJson(requestStr, InitiateDITRequestModel.class);
	                if (requestEntity != null) {
	                	DataModel data = requestEntity.getData();
	                	IdentityModel identity = data.getIdentity();
	                	NameModel name = identity.getName();
	                	List<PhoneModel> phoneList = identity.getPhone();
	                	List<EmailModel> emailList = identity.getEmail();
	                	
	                	vo.setFirstName(name.getFirstName());
	                	vo.setLastName(name.getLastName());
	                	vo.setPhoneNumber(!(phoneList == null || phoneList.isEmpty())? String.valueOf(phoneList.get(0).getNumber()) : "");
	                	vo.setEmail(!(emailList == null || emailList.isEmpty())? emailList.get(0).getEmail() : "");
	                	
	                }
	                
	                InitiateDITResponseModel responseEntity = g.fromJson(responseStr, InitiateDITResponseModel.class);
	                if (responseEntity != null) {
	                	vo.setDecision(responseEntity.getDecision());
	                	List<DetailModel> detailList = responseEntity.getDetails();
	                	
	                	for(DetailModel det : detailList) {
	                		if ("phoneTrust".equalsIgnoreCase(det.getKey())) {
	                			vo.setPhoneTrust(det.getValue());
	                 		}
	                		if ("identityTrust".equalsIgnoreCase(det.getKey())) {
	                			vo.setIdentityTrust(det.getValue());
	                 		}
	                		if ("addressTrust".equalsIgnoreCase(det.getKey())) {
	                			vo.setAddressTrust(det.getValue());
	                 		}
	                		if ("phoneVerification".equalsIgnoreCase(det.getKey())) {
	                			vo.setPhoneVerification(det.getValue());
	                 		}
	                		if ("phoneVerification".equalsIgnoreCase(det.getKey())) {
	                			vo.setPhoneVerification(det.getValue());
	                 		}
	                		if ("phoneVerificationReason".equalsIgnoreCase(det.getKey())) {
	                			vo.setPhoneVerificationReason(det.getValue());
	                 		}
	                	}
	                 	
	                	vo.setStatus(String.valueOf(responseEntity.getStatus()));
	                }
	                
	                vo.setResponseDate(createDateFmtd);
	                rpDitResponseList.add(vo);
		    	}
	       	}
    	}
    	catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
    	}
     }
    
    public void retrieveRemoteProofingEventList() {
       	try {
       		retrievePerson();
    		rpRemoteProofingEventList = rpEventDataService.findEventByPersonId(rpPerson.getPersonId());
    	}
    	catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
    	}
    }
    
    public void retrievePhoneVerificationsList() {
       	try {
	    	retrievePerson();
	    	retrieveRpEventList();
	    	
	     	rpPhoneVerificationsList = new ArrayList<>();
	    	for (RpEvent event : rpEventList) {
	    		PhoneVerificationsVo vo = new PhoneVerificationsVo();
	    		RpPhoneVerification entity = event.getRpPhoneVerification();
	    		
	    		if (entity != null) {
		    		vo.setEventId(event.getEventId());
		    		vo.setVerificationDecision(entity.getPhoneVerificationDecision());
		    		vo.setPhoneNumber(entity.getMobilePhoneNumber());
		    		vo.setSubmitAttempts(entity.getNumberOfSubmitAttempts());
		    		vo.setRenewAttempts(entity.getNumberOfRenewAttempts());
		    		vo.setEidDecision(entity.getEidDecision());
		    		vo.setOverallAssessment(entity.getOverallAssessment());
		    		vo.setVerificationDate(entity.getDecisionDateTime());
		    		rpPhoneVerificationsList.add(vo);
	    		}
	    	}
       	}
    	catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
    	}
    }
    
    public void retrievePhoneVerificationResultList() {
      	try {
	    	retrievePerson();
	    	retrieveRpEventList();
	    	
	    	rpPhoneVerificationResultList = new ArrayList<>();
	    	for (RpEvent event : rpEventList) {
	    		PhoneVerificationResultVo vo = new PhoneVerificationResultVo();
	    		RpPhoneVerificationResult entity = event.getRpPhoneVerificationResult();
	    		
	    		if (entity != null) {
		    		vo.setEventId(event.getEventId());
		    		vo.setValidNumber(entity.getValidNumber());
		    		vo.setMatchQuality(entity.getRefPhoneMatchQuality() != null ? entity.getRefPhoneMatchQuality().getMatchQuality() : "");
		    		vo.setMatchLevel(entity.getRefMatchLevel()!= null ? entity.getRefMatchLevel().getMatchLevel() : "");
		    		vo.setStatusCode(entity.getRefServiceStatusCode() != null ? entity.getRefServiceStatusCode().getServiceStatus() : "");
		    		vo.setProductStatus(entity.getRefProductStatusCode() != null ? entity.getRefProductStatusCode().getProductStatus() : "");
		    		vo.setVerificationDate(entity.getCreateDate());
		    		rpPhoneVerificationResultList.add(vo);
	    		}
	    		
	    	}
       	}
    	catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
    	}
    }
    
    public void retrieveSmfaInitiateResponseList() {
     	try {
	    	retrievePerson();
	    	List<RpSmfaInitiateResponse> entityList = rpSmfaInitiateResponseService.getListByPersonId(rpPerson.getPersonId());
	    	rpSmfaInitiateResponseList = new ArrayList<>();
	    	Gson g = new Gson();
	    	
	    	for(RpSmfaInitiateResponse entity : entityList) {
	    		SmfaInitiateResponseVo vo = new SmfaInitiateResponseVo();
	            String createDateFmtd = DateTimeUtil.getDateString(entity.getCreateDate(), DateTimeUtil.DATE_FORMAT);
	            String responseStr = entity.getResponse();
	            String allRequestStr = entity.getRequest();
	            int bodyStartIndex = 5;
	            int bodyEndIndex = allRequestStr.lastIndexOf(TOKEN_PROMPT) - 2;
	            int tokenStartIndex = allRequestStr.lastIndexOf(TOKEN_PROMPT) + 6;
	            String requestStr = allRequestStr.substring(bodyStartIndex, bodyEndIndex);
	            
	            if (tokenStartIndex > 5) {
	            	vo.setToken(allRequestStr.substring(tokenStartIndex, allRequestStr.length()));
	            }
	            
	            InitiateSMFARequestModel requestEntity = g.fromJson(requestStr, InitiateSMFARequestModel.class);
				if (requestEntity != null) {
					ConsumerIdentifierModel identifier = requestEntity.getConsumerIdentifier();
					if (identifier != null) {
						vo.setMobileNumber(identifier.getSubjectIdentifier());
					}
				}
	            
	            InitiateSMFAResponseModel responseEntity = g.fromJson(responseStr, InitiateSMFAResponseModel.class);
	            if (responseEntity != null) {
	            	OtpLifecycleModel cycle = responseEntity.getOtpLifecycle();
	            	if (cycle != null) {
	            		vo.setStatus(cycle.getStatus());
	            	}
	            	
	            	vo.setDescription(responseEntity.getDescription());
	            	vo.setEfxErrorCode(responseEntity.getEfxErrorCode());
	            	vo.setLinkSuccessfullySent(responseEntity.isLinkSuccessfullySent()? "true" : "false");
	            	
	            	AdditionalErrorDetailModel errDetail = responseEntity.getAdditionalErrorDetails();
	            	if (errDetail != null) {
	            		vo.setDeveloperMessage(errDetail.getDeveloperMessage());
	            		vo.setErrorCode(errDetail.getErrorCode());
		            	vo.setErrorType(errDetail.getErrorType());
	            	}
	            }
	            
	            vo.setCreateDate(createDateFmtd);
	            rpSmfaInitiateResponseList.add(vo);
	    	}
       	}
    	catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
    	}
    }
    
    public void retrieveSmfaValidateResponseList() {
     	try {
	    	retrievePerson();
	    	List<RpSmfaValidateResponse> entityList = rpSmfaValidateResponseService.getListByPersonId(rpPerson.getPersonId());
	    	rpSmfaValidateResponseList = new ArrayList<>();
	    	Gson g = new Gson();
	    	
	    	for(RpSmfaValidateResponse entity : entityList) {
	    		SmfaValidateResponseVo vo = new SmfaValidateResponseVo();
	            String createDateFmtd = DateTimeUtil.getDateString(entity.getCreateDate(), DateTimeUtil.DATE_FORMAT);
	            
	            String responseStr = entity.getResponse();
	            String allRequestStr = entity.getRequest();
	            int bodyStartIndex = 5;
	            int bodyEndIndex = allRequestStr.lastIndexOf(TOKEN_PROMPT) - 2;
	            int tokenStartIndex = allRequestStr.lastIndexOf(TOKEN_PROMPT) + 6;
	            String requestStr = allRequestStr.substring(bodyStartIndex, bodyEndIndex);
	            
	            if (tokenStartIndex > 5) {
	            	vo.setToken(allRequestStr.substring(tokenStartIndex, allRequestStr.length()));
	            }
		            
	            StatusSMFARequestModel requestEntity = g.fromJson(requestStr, StatusSMFARequestModel.class);
				if (requestEntity != null) {
					ConsumerIdentifierModel identifier = requestEntity.getConsumerIdentifier();
					if (identifier != null) {
						vo.setMobileNumber(identifier.getSubjectIdentifier());
					}
				}
	            
				StatusSMFAResponseModel responseEntity = g.fromJson(responseStr, StatusSMFAResponseModel.class);
	            if (responseEntity != null) {
	            	ResponseStatusModel response = responseEntity.getResponse();
	            	if (response != null) {
	            		vo.setPath(response.getPath());
	            	}
	            	
	            	vo.setDescription(responseEntity.getDescription());
	            	vo.setEfxErrorCode(responseEntity.getEfxErrorCode());
	            	
	            	AdditionalErrorDetailModel errDetail = responseEntity.getAdditionalErrorDetails();
	            	if (errDetail != null) {
	            		vo.setDeveloperMessage(errDetail.getDeveloperMessage());
	            		vo.setErrorCode(errDetail.getErrorCode());
		            	vo.setErrorType(errDetail.getErrorType());
	            	}
	            	
	            	vo.setDescription(responseEntity.getDescription());
	            }
	            
	            vo.setCreateDate(createDateFmtd);
	            rpSmfaValidateResponseList.add(vo);
	    	}
       	}
    	catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
    	}
    }
    
    public void retrieveTruthDataSendResponseList() {
     	try {
	    	retrievePerson();
	    	List<RpTruthDataSendResponse> entityList = rpTruthDataSendResponseService.getListByPersonId(rpPerson.getPersonId());
	    	rpTruthDataSendResponseList = new ArrayList<>();
	    	
	    	for(RpTruthDataSendResponse entity : entityList) {
	    		TruthDataSendResponseVo vo = new TruthDataSendResponseVo();
	            String createDateFmtd = DateTimeUtil.getDateString(entity.getCreateDate(), DateTimeUtil.DATE_FORMAT);

	            vo.setRequestId(entity.getRequestId());
	            vo.setEventType(entity.getRefTruthDataSendEvent().getEventType());
	    		
	            String responseStr = entity.getResponse();
	            
	            int startIndex = responseStr.lastIndexOf("\"notes\":");
	            int endIndex = 0;
	            if (startIndex > -1) {
	            	startIndex = startIndex + 7;
		            endIndex = startIndex + 30;
		            String notes = responseStr.substring(startIndex, endIndex);
		            startIndex = responseStr.lastIndexOf(',');
		            
		            if (startIndex > -1) {
			            endIndex = 0;
			            notes = notes.substring(startIndex, endIndex);
			            vo.setNotes(notes);
		            }
	            }
	            
	            startIndex = responseStr.lastIndexOf("\"event_tag\":");
	            if (startIndex > -1) {
	            	startIndex = startIndex + 11;
		            endIndex = startIndex + 30;
		            String eventTag = responseStr.substring(startIndex, endIndex);
		            startIndex = responseStr.lastIndexOf(',');
		            
		            if (startIndex > -1) {
			            endIndex = 0;
			            eventTag = eventTag.substring(startIndex, endIndex);
			            vo.setEventTag(eventTag);
		            }
	            }
	            
	            startIndex = responseStr.lastIndexOf("\"request_result\":");
	            if (startIndex > -1) {
	            	startIndex = startIndex + 17;
		            endIndex = startIndex + 30;
		            String requestResult = responseStr.substring(startIndex, endIndex);
		            startIndex = responseStr.lastIndexOf(',');
		            
		            if (startIndex > -1) {
			            endIndex = 0;
			            requestResult = requestResult.substring(startIndex, endIndex);
			            vo.setEventTag(requestResult);
		            }
	            }
	            	
	            vo.setCreateDate(createDateFmtd);
	    		rpTruthDataSendResponseList.add(vo);
	    	}
       	}
    	catch(Exception e) {
		    setRpRetrieveStatusErrorMsg(getRpRetrieveStatusErrorMsg() + e.getMessage());
		    setShowRetrieveStatusErrorMsg(true);
    	}
    }
    
    /***** UTLITIES ***********/
        
    /**** INNER CLASSES ************/
     
    public class DeviceReputationResponseVo {

        private String requestId;
        private String transactionStatus;
        private String transactionCode;
        private String lexID;
        private String reviewStatus;
        private String requestResult;
        private String discoveryCode;
        private String discoveryStatus;
        private String velocityCode;
        private String velocityStatus;
        private String deviceCode;
        private String deviceStatus;
        private String deviceConfig;
        private String assessmentDate;
        
 		public String getRequestId() {
			return requestId;
		}
		public void setRequestId(String requestId) {
			this.requestId = requestId;
		}
		public String getTransactionStatus() {
			return transactionStatus;
		}
		public void setTransactionStatus(String transactionStatus) {
			this.transactionStatus = transactionStatus;
		}
		public String getTransactionCode() {
			return transactionCode;
		}
		public void setTransactionCode(String transactionCode) {
			this.transactionCode = transactionCode;
		}
		public String getLexID() {
			return lexID;
		}
		public void setLexID(String lexID) {
			this.lexID = lexID;
		}
		public String getReviewStatus() {
			return reviewStatus;
		}
		public void setReviewStatus(String reviewStatus) {
			this.reviewStatus = reviewStatus;
		}
		public String getRequestResult() {
			return requestResult;
		}
		public void setRequestResult(String requestResult) {
			this.requestResult = requestResult;
		}
		public String getDiscoveryCode() {
			return discoveryCode;
		}
		public void setDiscoveryCode(String discoveryCode) {
			this.discoveryCode = discoveryCode;
		}
		public String getDiscoveryStatus() {
			return discoveryStatus;
		}
		public void setDiscoveryStatus(String discoveryStatus) {
			this.discoveryStatus = discoveryStatus;
		}
		public String getVelocityCode() {
			return velocityCode;
		}
		public void setVelocityCode(String velocityCode) {
			this.velocityCode = velocityCode;
		}
		public String getVelocityStatus() {
			return velocityStatus;
		}
		public void setVelocityStatus(String velocityStatus) {
			this.velocityStatus = velocityStatus;
		}
		public String getDeviceCode() {
			return deviceCode;
		}
		public void setDeviceCode(String deviceCode) {
			this.deviceCode = deviceCode;
		}
		public String getDeviceStatus() {
			return deviceStatus;
		}
		public void setDeviceStatus(String deviceStatus) {
			this.deviceStatus = deviceStatus;
		}
		public String getDeviceConfig() {
			return deviceConfig;
		}
		public void setDeviceConfig(String deviceConfig) {
			this.deviceConfig = deviceConfig;
		}
		public String getAssessmentDate() {
			return assessmentDate;
		}
		public void setAssessmentDate(String assessmentDate) {
			this.assessmentDate = assessmentDate;
		}
    }    
    
    public class DitResponseVo {

        private String firstName;
        private String lastName;
        private String phoneNumber;
        private String email;
        private String decision;
        private String status;
        private String phoneVerification;
        private String phoneVerificationReason;
        private String phoneTrust;
        private String addressTrust;
        private String identityTrust;
        private String responseDate;
        
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getDecision() {
			return decision;
		}
		public void setDecision(String decision) {
			this.decision = decision;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getPhoneVerification() {
			return phoneVerification;
		}
		public void setPhoneVerification(String phoneVerification) {
			this.phoneVerification = phoneVerification;
		}
		public String getPhoneVerificationReason() {
			return phoneVerificationReason;
		}
		public void setPhoneVerificationReason(String phoneVerificationReason) {
			this.phoneVerificationReason = phoneVerificationReason;
		}
		public String getPhoneTrust() {
			return phoneTrust;
		}
		public void setPhoneTrust(String phoneTrust) {
			this.phoneTrust = phoneTrust;
		}
		public String getAddressTrust() {
			return addressTrust;
		}
		public void setAddressTrust(String addressTrust) {
			this.addressTrust = addressTrust;
		}
		public String getIdentityTrust() {
			return identityTrust;
		}
		public void setIdentityTrust(String identityTrust) {
			this.identityTrust = identityTrust;
		}
		public String getResponseDate() {
			return responseDate;
		}
		public void setResponseDate(String responseDate) {
			this.responseDate = responseDate;
		}
    }
    
    public class PhoneVerificationsVo {

        private Long eventId;
        private String verificationDecision;
        private String phoneNumber;
        private int submitAttempts;
        private int renewAttempts;
        private String eidDecision;
        private String overallAssessment;
        private Timestamp verificationDate;
        
		public Long getEventId() {
			return eventId;
		}
		public void setEventId(Long eventId) {
			this.eventId = eventId;
		}
		public String getVerificationDecision() {
			return verificationDecision;
		}
		public void setVerificationDecision(String verificationDecision) {
			this.verificationDecision = verificationDecision;
		}
		public String getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		public int getSubmitAttempts() {
			return submitAttempts;
		}
		public void setSubmitAttempts(int submitAttempts) {
			this.submitAttempts = submitAttempts;
		}
		public int getRenewAttempts() {
			return renewAttempts;
		}
		public void setRenewAttempts(int renewAttempts) {
			this.renewAttempts = renewAttempts;
		}
		public String getEidDecision() {
			return eidDecision;
		}
		public void setEidDecision(String eidDecision) {
			this.eidDecision = eidDecision;
		}
		public String getOverallAssessment() {
			return overallAssessment;
		}
		public void setOverallAssessment(String overallAssessment) {
			this.overallAssessment = overallAssessment;
		}
		public Timestamp getVerificationDate() {
			return verificationDate;
		}
		public void setVerificationDate(Timestamp verificationDate) {
			this.verificationDate = verificationDate;
		}
    }
    
    public class PhoneVerificationResultVo {

        private Long eventId;
        private String validNumber;
        private String matchQuality;
        private String matchLevel;
        private String statusCode;
        private String productStatus;
        private Date verificationDate;
        
		public Long getEventId() {
			return eventId;
		}
		public void setEventId(Long eventId) {
			this.eventId = eventId;
		}
		public String getValidNumber() {
			return validNumber;
		}
		public void setValidNumber(String validNumber) {
			this.validNumber = validNumber;
		}
		public String getMatchQuality() {
			return matchQuality;
		}
		public void setMatchQuality(String matchQuality) {
			this.matchQuality = matchQuality;
		}
		public String getMatchLevel() {
			return matchLevel;
		}
		public void setMatchLevel(String matchLevel) {
			this.matchLevel = matchLevel;
		}
		public String getStatusCode() {
			return statusCode;
		}
		public void setStatusCode(String statusCode) {
			this.statusCode = statusCode;
		}
		public String getProductStatus() {
			return productStatus;
		}
		public void setProductStatus(String productStatus) {
			this.productStatus = productStatus;
		}
		public Date getVerificationDate() {
			return verificationDate;
		}
		public void setVerificationDate(Date verificationDate) {
			this.verificationDate = verificationDate;
		}
    }
    
    public class SmfaInitiateResponseVo {

        private String mobileNumber;
        private String token;
        private String linkSuccessfullySent;
        private String status;
        private String developerMessage;
        private String errorType;
        private String errorCode;
        private String efxErrorCode;
        private String description;
        private String createDate;
        
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public String getToken() {
			return token;
		}
		public void setToken(String token) {
			this.token = token;
		}
		public String getLinkSuccessfullySent() {
			return linkSuccessfullySent;
		}
		public void setLinkSuccessfullySent(String linkSuccessfullySent) {
			this.linkSuccessfullySent = linkSuccessfullySent;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getDeveloperMessage() {
			return developerMessage;
		}
		public void setDeveloperMessage(String developerMessage) {
			this.developerMessage = developerMessage;
		}
		public String getErrorType() {
			return errorType;
		}
		public void setErrorType(String errorType) {
			this.errorType = errorType;
		}
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getEfxErrorCode() {
			return efxErrorCode;
		}
		public void setEfxErrorCode(String efxErrorCode) {
			this.efxErrorCode = efxErrorCode;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getCreateDate() {
			return createDate;
		}
		public void setCreateDate(String createDate) {
			this.createDate = createDate;
		}
    }

    public class SmfaValidateResponseVo {

        private String mobileNumber;
        private String token;
        private String path;
        private String developerMessage;
        private String errorType;
        private String errorCode;
        private String efxErrorCode;
        private String description;
        private String createDate;
        
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public String getToken() {
			return token;
		}
		public void setToken(String token) {
			this.token = token;
		}
		public String getPath() {
			return path;
		}
		public void setPath(String path) {
			this.path = path;
		}
		public String getDeveloperMessage() {
			return developerMessage;
		}
		public void setDeveloperMessage(String developerMessage) {
			this.developerMessage = developerMessage;
		}
		public String getErrorType() {
			return errorType;
		}
		public void setErrorType(String errorType) {
			this.errorType = errorType;
		}
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getEfxErrorCode() {
			return efxErrorCode;
		}
		public void setEfxErrorCode(String efxErrorCode) {
			this.efxErrorCode = efxErrorCode;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getCreateDate() {
			return createDate;
		}
		public void setCreateDate(String createDate) {
			this.createDate = createDate;
		}
    }

    public class TruthDataSendResponseVo {

        private String requestId;
        private String eventType;
        private String notes;
        private String eventTag;
        private String requestResult;
        private String createDate;
        
		public String getRequestId() {
			return requestId;
		}
		public void setRequestId(String requestId) {
			this.requestId = requestId;
		}
		public String getEventType() {
			return eventType;
		}
		public void setEventType(String eventType) {
			this.eventType = eventType;
		}
		public String getNotes() {
			return notes;
		}
		public void setNotes(String notes) {
			this.notes = notes;
		}
		public String getEventTag() {
			return eventTag;
		}
		public void setEventTag(String eventTag) {
			this.eventTag = eventTag;
		}
		public String getRequestResult() {
			return requestResult;
		}
		public void setRequestResult(String requestResult) {
			this.requestResult = requestResult;
		}
		public String getCreateDate() {
			return createDate;
		}
		public void setCreateDate(String createDate) {
			this.createDate = createDate;
		}
  
    }

    public class LexisNexisResultVo {

        private Long eventId;
        private String responseCode;
        private String reasonCode;
        private String resultDate;
        
		public Long getEventId() {
			return eventId;
		}
		public void setEventId(Long eventId) {
			this.eventId = eventId;
		}
		public String getResponseCode() {
			return responseCode;
		}
		public void setResponseCode(String responseCode) {
			this.responseCode = responseCode;
		}
		public String getReasonCode() {
			return reasonCode;
		}
		public void setReasonCode(String reasonCode) {
			this.reasonCode = reasonCode;
		}
		public String getResultDate() {
			return resultDate;
		}
		public void setResultDate(String resultDate) {
			this.resultDate = resultDate;
		}
    }
    
    public class EquifaxIDSResultVo {

        private Long eventId;
        private String assessmentCode;
        private String overallScoreCode;
        private String reasonCode;
        private String resultDate;
        
		public Long getEventId() {
			return eventId;
		}
		public void setEventId(Long eventId) {
			this.eventId = eventId;
		}
		public String getAssessmentCode() {
			return assessmentCode;
		}
		public void setAssessmentCode(String assessmentCode) {
			this.assessmentCode = assessmentCode;
		}
		public String getOverallScoreCode() {
			return overallScoreCode;
		}
		public void setOverallScoreCode(String overallScoreCode) {
			this.overallScoreCode = overallScoreCode;
		}
		public String getReasonCode() {
			return reasonCode;
		}
		public void setReasonCode(String reasonCode) {
			this.reasonCode = reasonCode;
		}
		public String getResultDate() {
			return resultDate;
		}
		public void setResultDate(String resultDate) {
			this.resultDate = resultDate;
		}
    }
    
    public class PhoneAttemptVo {

        private long eventId;
        private long supplierId;
        private String transactionId;
        private String phoneDecision;
        private String overallAssessment;
        private String decisionDatetime;
        
		public long getEventId() {
			return eventId;
		}
		public void setEventId(long eventId) {
			this.eventId = eventId;
		}
		public long getSupplierId() {
			return supplierId;
		}
		public void setSupplierId(long supplierId) {
			this.supplierId = supplierId;
		}
		public String getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(String transactionId) {
			this.transactionId = transactionId;
		}
		public String getPhoneDecision() {
			return phoneDecision;
		}
		public void setPhoneDecision(String phoneDecision) {
			this.phoneDecision = phoneDecision;
		}
		public String getOverallAssessment() {
			return overallAssessment;
		}
		public void setOverallAssessment(String overallAssessment) {
			this.overallAssessment = overallAssessment;
		}

		public String getDecisionDatetime() {
			return decisionDatetime;
		}
		public void setDecisionDatetime(String decisionDatetime) {
			this.decisionDatetime = decisionDatetime;
		}
    }
    
    public class OtpLinkAttemptVo {

        private long attemptId;
        private long supplierId;
        private String otpMfaDecision;
        private String sentDatetime;
        
		public long getAttemptId() {
			return attemptId;
		}
		public void setAttemptId(long attemptId) {
			this.attemptId = attemptId;
		}
		public long getSupplierId() {
			return supplierId;
		}
		public void setSupplierId(long supplierId) {
			this.supplierId = supplierId;
		}
		public String getOtpMfaDecision() {
			return otpMfaDecision;
		}
		public void setOtpMfaDecision(String otpMfaDecision) {
			this.otpMfaDecision = otpMfaDecision;
		}
		public String getSentDatetime() {
			return sentDatetime;
		}
		public void setSentDatetime(String sentDatetime) {
			this.sentDatetime = sentDatetime;
		}
     }
    
	public String getPvSupplierSelected() {
		return pvSupplierSelected;
	}

	public void setPvSupplierSelected(String pvSupplierSelected) {
		this.pvSupplierSelected = pvSupplierSelected;
	}
	
	public String getPvSupplierSelected2() {
		return pvSupplierSelected2;
	}

	public void setPvSupplierSelected2(String pvSupplierSelected2) {
		this.pvSupplierSelected2 = pvSupplierSelected2;
	}
	
	public long getSupplierDetSponsorId() {
		return supplierDetSponsorId;
	}

	public void setSupplierDetSponsorId(long supplierDetSponsorId) {
		this.supplierDetSponsorId = supplierDetSponsorId;
	}
	
	public long getSupplierDetSponsorId2() {
		return supplierDetSponsorId2;
	}

	public void setSupplierDetSponsorId2(long supplierDetSponsorId2) {
		this.supplierDetSponsorId2 = supplierDetSponsorId2;
	}

	public boolean isFailedEquifaxOTP() {
		return failedEquifaxOTP;
	}

	public void setFailedEquifaxOTP(boolean failedEquifaxOTP) {
		this.failedEquifaxOTP = failedEquifaxOTP;
	}
	
	public boolean isFailedEquifaxOTP2() {
		return failedEquifaxOTP2;
	}

	public void setFailedEquifaxOTP2(boolean failedEquifaxOTP2) {
		this.failedEquifaxOTP2 = failedEquifaxOTP2;
	}

	public boolean isFailedEquifaxDIT() {
		return failedEquifaxDIT;
	}

	public void setFailedEquifaxDIT(boolean failedEquifaxDIT) {
		this.failedEquifaxDIT = failedEquifaxDIT;
	}
	
	public boolean isFailedEquifaxDIT2() {
		return failedEquifaxDIT2;
	}

	public void setFailedEquifaxDIT2(boolean failedEquifaxDIT2) {
		this.failedEquifaxDIT2 = failedEquifaxDIT2;
	}

	public boolean isFailedLexisNexisRDP() {
		return failedLexisNexisRDP;
	}

	public void setFailedLexisNexisRDP(boolean failedLexisNexisRDP) {
		this.failedLexisNexisRDP = failedLexisNexisRDP;
	}
	
	public boolean isFailedLexisNexisRDP2() {
		return failedLexisNexisRDP2;
	}

	public void setFailedLexisNexisRDP2(boolean failedLexisNexisRDP2) {
		this.failedLexisNexisRDP2 = failedLexisNexisRDP2;
	}

	public boolean isFailedExperianCC() {
		return failedExperianCC;
	}

	public void setFailedExperianCC(boolean failedExperianCC) {
		this.failedExperianCC = failedExperianCC;
	}
	
	public boolean isFailedExperianCC2() {
		return failedExperianCC2;
	}

	public void setFailedExperianCC2(boolean failedExperianCC2) {
		this.failedExperianCC2 = failedExperianCC2;
	}
	
	public List<RefSponsor> getRpSponsorList() {
		return rpSponsorList;
	}

	public void setRpSponsorList(List<RefSponsor> rpSponsorList) {
		this.rpSponsorList = rpSponsorList;
	}

	public List<OtpConfigVo> getOtpSupplierList() {
		return otpSupplierList;
	}

	public void setOtpSupplierList(List<OtpConfigVo> otpSupplierList) {
		this.otpSupplierList = otpSupplierList;
	}
	
	public List<OtpConfigVo> getOtpSupplierList2() {
		return otpSupplierList2;
	}

	public void setOtpSupplierList2(List<OtpConfigVo> otpSupplierList2) {
		this.otpSupplierList2 = otpSupplierList2;
	}

	public AdminService getAdminService() {
		return adminService;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	public EquifaxService getEquifaxService() {
		return equifaxService;
	}

	public void setEquifaxService(EquifaxService equifaxService) {
		this.equifaxService = equifaxService;
	}

	public CommonRestService getCommonRestService() {
		return commonRestService;
	}

	public void setCommonRestService(CommonRestService commonRestService) {
		this.commonRestService = commonRestService;
	}

	public EquifaxDataService getEquifaxDataService() {
		return equifaxDataService;
	}

	public void setEquifaxDataService(EquifaxDataService equifaxDataService) {
		this.equifaxDataService = equifaxDataService;
	}

	public String getEfxSmfaInitMobileNum() {
		return efxSmfaInitMobileNum;
	}

	public void setEfxSmfaInitMobileNum(String efxSmfaInitMobileNum) {
		this.efxSmfaInitMobileNum = efxSmfaInitMobileNum;
	}

	public String getEfxSmfaInitJsonRequest() {
		return efxSmfaInitJsonRequest;
	}

	public void setEfxSmfaInitJsonRequest(String efxSmfaInitJsonRequest) {
		this.efxSmfaInitJsonRequest = efxSmfaInitJsonRequest;
	}

	public String getEfxSmfaInitJsonResponse() {
		return efxSmfaInitJsonResponse;
	}

	public void setEfxSmfaInitJsonResponse(String efxSmfaInitJsonResponse) {
		this.efxSmfaInitJsonResponse = efxSmfaInitJsonResponse;
	}

	public boolean isShowEfxSmfaInitRequestJsonPanel() {
		return showEfxSmfaInitRequestJsonPanel;
	}

	public void setShowEfxSmfaInitRequestJsonPanel(boolean showEfxSmfaInitRequestJsonPanel) {
		this.showEfxSmfaInitRequestJsonPanel = showEfxSmfaInitRequestJsonPanel;
	}

	public boolean isShowEfxSmfaInitSubmitBtn() {
		return showEfxSmfaInitSubmitBtn;
	}

	public void setShowEfxSmfaInitSubmitBtn(boolean showEfxSmfaInitSubmitBtn) {
		this.showEfxSmfaInitSubmitBtn = showEfxSmfaInitSubmitBtn;
	}

	public InitiateSMFARequestModel getSmfaInitiateRequest() {
		return smfaInitiateRequest;
	}

	public void setSmfaInitiateRequest(InitiateSMFARequestModel smfaInitiateRequest) {
		this.smfaInitiateRequest = smfaInitiateRequest;
	}

	public InitiateSMFAResponseModel getSmfaInitiateResponse() {
		return smfaInitiateResponse;
	}

	public void setSmfaInitiateResponse(InitiateSMFAResponseModel smfaInitiateResponse) {
		this.smfaInitiateResponse = smfaInitiateResponse;
	}

	public String getSmfaInitiateRequestStr() {
		return smfaInitiateRequestStr;
	}

	public void setSmfaInitiateRequestStr(String smfaInitiateRequestStr) {
		this.smfaInitiateRequestStr = smfaInitiateRequestStr;
	}

	public String getSmfaInitiateResponseStr() {
		return smfaInitiateResponseStr;
	}

	public void setSmfaInitiateResponseStr(String smfaInitiateResponseStr) {
		this.smfaInitiateResponseStr = smfaInitiateResponseStr;
	}

	public boolean isShowEfxSmfaInitResponseJsonPanel() {
		return showEfxSmfaInitResponseJsonPanel;
	}

	public void setShowEfxSmfaInitResponseJsonPanel(boolean showEfxSmfaInitResponseJsonPanel) {
		this.showEfxSmfaInitResponseJsonPanel = showEfxSmfaInitResponseJsonPanel;
	}

	public String getDitSelectedTestCaseId() {
		return ditSelectedTestCaseId;
	}

	public void setDitSelectedTestCaseId(String ditSelectedTestCaseId) {
		this.ditSelectedTestCaseId = ditSelectedTestCaseId;
	}

	public List<TestCaseVo> getDitTestCaseList() {
		return ditTestCaseList;
	}

	public void setDitTestCaseList(List<TestCaseVo> ditTestCaseList) {
		this.ditTestCaseList = ditTestCaseList;
	}

	public Map<String, Object> getDitTestCaseMap() {
		return ditTestCaseMap;
	}

	public void setDitTestCaseMap(Map<String, Object> ditTestCaseMap) {
		this.ditTestCaseMap = ditTestCaseMap;
	}

	public List<TestCaseVo> getDitSelectedTestCaseList() {
		return ditSelectedTestCaseList;
	}

	public void setDitSelectedTestCaseList(List<TestCaseVo> ditSelectedTestCaseList) {
		this.ditSelectedTestCaseList = ditSelectedTestCaseList;
	}

	public boolean isShowEfxDitTrustDecisionPanel() {
		return showEfxDitTrustDecisionPanel;
	}

	public void setShowEfxDitTrustDecisionPanel(boolean showEfxDitTrustDecisionPanel) {
		this.showEfxDitTrustDecisionPanel = showEfxDitTrustDecisionPanel;
	}

	public String getEfxSmfaStatMobileNum() {
		return efxSmfaStatMobileNum;
	}

	public void setEfxSmfaStatMobileNum(String efxSmfaStatMobileNum) {
		this.efxSmfaStatMobileNum = efxSmfaStatMobileNum;
	}

	public StatusSMFARequestModel getSmfaStatusRequest() {
		return smfaStatusRequest;
	}

	public void setSmfaStatusRequest(StatusSMFARequestModel smfaStatusRequest) {
		this.smfaStatusRequest = smfaStatusRequest;
	}

	public StatusSMFAResponseModel getSmfaStatusResponse() {
		return smfaStatusResponse;
	}

	public void setSmfaStatusResponse(StatusSMFAResponseModel smfaStatusResponse) {
		this.smfaStatusResponse = smfaStatusResponse;
	}

	public String getEfxSmfaStatJsonRequest() {
		return efxSmfaStatJsonRequest;
	}

	public void setEfxSmfaStatJsonRequest(String efxSmfaStatJsonRequest) {
		this.efxSmfaStatJsonRequest = efxSmfaStatJsonRequest;
	}

	public String getEfxSmfaStatJsonResponse() {
		return efxSmfaStatJsonResponse;
	}

	public void setEfxSmfaStatJsonResponse(String efxSmfaStatJsonResponse) {
		this.efxSmfaStatJsonResponse = efxSmfaStatJsonResponse;
	}

	public String getSmfaStatusRequestStr() {
		return smfaStatusRequestStr;
	}

	public void setSmfaStatusRequestStr(String smfaStatusRequestStr) {
		this.smfaStatusRequestStr = smfaStatusRequestStr;
	}

	public String getSmfaStatusResponseStr() {
		return smfaStatusResponseStr;
	}

	public void setSmfaStatusResponseStr(String smfaStatusResponseStr) {
		this.smfaStatusResponseStr = smfaStatusResponseStr;
	}

	public boolean isShowEfxSmfaStatRequestJsonPanel() {
		return showEfxSmfaStatRequestJsonPanel;
	}

	public void setShowEfxSmfaStatRequestJsonPanel(boolean showEfxSmfaStatRequestJsonPanel) {
		this.showEfxSmfaStatRequestJsonPanel = showEfxSmfaStatRequestJsonPanel;
	}

	public boolean isShowEfxSmfaStatResponseJsonPanel() {
		return showEfxSmfaStatResponseJsonPanel;
	}

	public void setShowEfxSmfaStatResponseJsonPanel(boolean showEfxSmfaStatResponseJsonPanel) {
		this.showEfxSmfaStatResponseJsonPanel = showEfxSmfaStatResponseJsonPanel;
	}

	public boolean isShowEfxSmfaStatSubmitBtn() {
		return showEfxSmfaStatSubmitBtn;
	}

	public void setShowEfxSmfaStatSubmitBtn(boolean showEfxSmfaStatSubmitBtn) {
		this.showEfxSmfaStatSubmitBtn = showEfxSmfaStatSubmitBtn;
	}

	public String getSmfaInitiateResponseSessionId() {
		return smfaInitiateResponseSessionId;
	}

	public void setSmfaInitiateResponseSessionId(String smfaInitiateResponseSessionId) {
		this.smfaInitiateResponseSessionId = smfaInitiateResponseSessionId;
	}

	public String getSmfaInitiateToken() {
		return smfaInitiateToken;
	}

	public void setSmfaInitiateToken(String smfaInitiateToken) {
		this.smfaInitiateToken = smfaInitiateToken;
	}

	public String getRpPhoneSponsorUserId() {
		return rpPhoneSponsorUserId;
	}

	public void setRpPhoneSponsorUserId(String rpPhoneSponsorUserId) {
		this.rpPhoneSponsorUserId = rpPhoneSponsorUserId;
	}

	public Long getRpNumPhoneAttempts() {
		return rpNumPhoneAttempts;
	}

	public void setRpNumPhoneAttempts(Long rpNumPhoneAttempts) {
		this.rpNumPhoneAttempts = rpNumPhoneAttempts;
	}

	public int getRpNumOtpLinkAttempts() {
		return rpNumOtpLinkAttempts;
	}

	public void setRpNumOtpLinkAttempts(int rpNumOtpLinkAttempts) {
		this.rpNumOtpLinkAttempts = rpNumOtpLinkAttempts;
	}

	public List<PhoneAttemptVo> getRpPhoneAttemptList() {
		return rpPhoneAttemptList;
	}

	public void setRpPhoneAttemptList(List<PhoneAttemptVo> rpPhoneAttemptList) {
		this.rpPhoneAttemptList = rpPhoneAttemptList;
	}

	public List<OtpLinkAttemptVo> getRpOtpLinkAttemptList() {
		return rpOtpLinkAttemptList;
	}

	public void setRpOtpLinkAttemptList(List<OtpLinkAttemptVo> rpOtpLinkAttemptList) {
		this.rpOtpLinkAttemptList = rpOtpLinkAttemptList;
	}

	public ProofingService getProofingService() {
		return proofingService;
	}

	public void setProofingService(ProofingService proofingService) {
		this.proofingService = proofingService;
	}

	public String getRpRemoteProofingStatus() {
		return rpRemoteProofingStatus;
	}

	public void setRpRemoteProofingStatus(String rpRemoteProofingStatus) {
		this.rpRemoteProofingStatus = rpRemoteProofingStatus;
	}

	public Long getRpPersonId() {
		return rpPersonId;
	}

	public void setRpPersonId(Long rpPersonId) {
		this.rpPersonId = rpPersonId;
	}

	public String getRpFirstLastName() {
		return rpFirstLastName;
	}

	public void setRpFirstLastName(String rpFirstLastName) {
		this.rpFirstLastName = rpFirstLastName;
	}

	public String getRpPhoneLockoutSupplier() {
		return rpPhoneLockoutSupplier;
	}

	public void setRpPhoneLockoutSupplier(String rpPhoneLockoutSupplier) {
		this.rpPhoneLockoutSupplier = rpPhoneLockoutSupplier;
	}

	public String getRpPhoneLockoutInEffect() {
		return rpPhoneLockoutInEffect;
	}

	public void setRpPhoneLockoutInEffect(String rpPhoneLockoutInEffect) {
		this.rpPhoneLockoutInEffect = rpPhoneLockoutInEffect;
	}

	public int getRpPhoneAttemptLimit() {
		return rpPhoneAttemptLimit;
	}

	public void setRpPhoneAttemptLimit(int rpPhoneAttemptLimit) {
		this.rpPhoneAttemptLimit = rpPhoneAttemptLimit;
	}

	public String getRpPhoneLockoutExpirationDateTime() {
		return rpPhoneLockoutExpirationDateTime;
	}

	public void setRpPhoneLockoutExpirationDateTime(String rpPhoneLockoutExpirationDateTime) {
		this.rpPhoneLockoutExpirationDateTime = rpPhoneLockoutExpirationDateTime;
	}

	public String getRpPhoneAttemptWindowDateTime() {
		return rpPhoneAttemptWindowDateTime;
	}

	public void setRpPhoneAttemptWindowDateTime(String rpPhoneAttemptWindowDateTime) {
		this.rpPhoneAttemptWindowDateTime = rpPhoneAttemptWindowDateTime;
	}
	
	public int getRpOtpLinkAttemptLimit() {
		return rpOtpLinkAttemptLimit;
	}

	public void setRpOtpLinkAttemptLimit(int rpOtpLinkAttemptLimit) {
		this.rpOtpLinkAttemptLimit = rpOtpLinkAttemptLimit;
	}

	public String getEfxSmfaSponsorUserId() {
		return efxSmfaSponsorUserId;
	}

	public void setEfxSmfaSponsorUserId(String efxSmfaSponsorUserId) {
		this.efxSmfaSponsorUserId = efxSmfaSponsorUserId;
	}

	public int getRpPhoneAttemptWindow() {
		return rpPhoneAttemptWindow;
	}

	public void setRpPhoneAttemptWindow(int rpPhoneAttemptWindow) {
		this.rpPhoneAttemptWindow = rpPhoneAttemptWindow;
	}

	public int getRpOtpLinkAttemptWindow() {
		return rpOtpLinkAttemptWindow;
	}

	public void setRpOtpLinkAttemptWindow(int rpOtpLinkAttemptWindow) {
		this.rpOtpLinkAttemptWindow = rpOtpLinkAttemptWindow;
	}

	public List<AuditPersonVo> getRpAuditPersonList() {
		return rpAuditPersonList;
	}

	public void setRpAuditPersonList(List<AuditPersonVo> rpAuditPersonList) {
		this.rpAuditPersonList = rpAuditPersonList;
	}

	public String getRpRetrieveStatusInstMsg() {
		return rpRetrieveStatusInstMsg;
	}

	public void setRpRetrieveStatusInstMsg(String rpRetrieveStatusInstMsg) {
		this.rpRetrieveStatusInstMsg = rpRetrieveStatusInstMsg;
	}

	public String getRpRetrieveStatusErrorMsg() {
		return rpRetrieveStatusErrorMsg;
	}

	public void setRpRetrieveStatusErrorMsg(String rpRetrieveStatusErrorMsg) {
		this.rpRetrieveStatusErrorMsg = rpRetrieveStatusErrorMsg;
	}

	public String getRpRetrieveStatusSuccessMsg() {
		return rpRetrieveStatusSuccessMsg;
	}

	public void setRpRetrieveStatusSuccessMsg(String rpRetrieveStatusSuccessMsg) {
		this.rpRetrieveStatusSuccessMsg = rpRetrieveStatusSuccessMsg;
	}

	public boolean isShowRetrieveStatusInstMsg() {
		return showRetrieveStatusInstMsg;
	}

	public void setShowRetrieveStatusInstMsg(boolean showRetrieveStatusInstMsg) {
		this.showRetrieveStatusInstMsg = showRetrieveStatusInstMsg;
	}

	public boolean isShowRetrieveStatusErrorMsg() {
		return showRetrieveStatusErrorMsg;
	}

	public void setShowRetrieveStatusErrorMsg(boolean showRetrieveStatusErrorMsg) {
		this.showRetrieveStatusErrorMsg = showRetrieveStatusErrorMsg;
	}

	public boolean isShowRetrieveStatusSuccessMsg() {
		return showRetrieveStatusSuccessMsg;
	}

	public void setShowRetrieveStatusSuccessMsg(boolean showRetrieveStatusSuccessMsg) {
		this.showRetrieveStatusSuccessMsg = showRetrieveStatusSuccessMsg;
	}

	public List<RpDeviceReputation> getRpDeviceReputationList() {
		return rpDeviceReputationList;
	}

	public void setRpDeviceReputationList(List<RpDeviceReputation> rpDeviceReputationList) {
		this.rpDeviceReputationList = rpDeviceReputationList;
	}

	public List<DeviceReputationResponseVo> getRpDeviceReputationResponseList() {
		return rpDeviceReputationResponseList;
	}

	public void setRpDeviceReputationResponseList(List<DeviceReputationResponseVo> rpDeviceReputationResponseList) {
		this.rpDeviceReputationResponseList = rpDeviceReputationResponseList;
	}

	public List<DitResponseVo> getRpDitResponseList() {
		return rpDitResponseList;
	}

	public void setRpDitResponseList(List<DitResponseVo> rpDitResponseList) {
		this.rpDitResponseList = rpDitResponseList;
	}

	public List<RpEvent> getRpRemoteProofingEventList() {
		return rpRemoteProofingEventList;
	}

	public void setRpRemoteProofingEventList(List<RpEvent> rpRemoteProofingEventList) {
		this.rpRemoteProofingEventList = rpRemoteProofingEventList;
	}

	public List<PhoneVerificationsVo> getRpPhoneVerificationsList() {
		return rpPhoneVerificationsList;
	}

	public void setRpPhoneVerificationsList(List<PhoneVerificationsVo> rpPhoneVerificationsList) {
		this.rpPhoneVerificationsList = rpPhoneVerificationsList;
	}

	public List<PhoneVerificationResultVo> getRpPhoneVerificationResultList() {
		return rpPhoneVerificationResultList;
	}

	public void setRpPhoneVerificationResultList(List<PhoneVerificationResultVo> rpPhoneVerificationResultList) {
		this.rpPhoneVerificationResultList = rpPhoneVerificationResultList;
	}

	public List<SmfaInitiateResponseVo> getRpSmfaInitiateResponseList() {
		return rpSmfaInitiateResponseList;
	}

	public void setRpSmfaInitiateResponseList(List<SmfaInitiateResponseVo> rpSmfaInitiateResponseList) {
		this.rpSmfaInitiateResponseList = rpSmfaInitiateResponseList;
	}

	public List<SmfaValidateResponseVo> getRpSmfaValidateResponseList() {
		return rpSmfaValidateResponseList;
	}

	public void setRpSmfaValidateResponseList(List<SmfaValidateResponseVo> rpSmfaValidateResponseList) {
		this.rpSmfaValidateResponseList = rpSmfaValidateResponseList;
	}

	public List<TruthDataSendResponseVo> getRpTruthDataSendResponseList() {
		return rpTruthDataSendResponseList;
	}

	public void setRpTruthDataSendResponseList(List<TruthDataSendResponseVo> rpTruthDataSendResponseList) {
		this.rpTruthDataSendResponseList = rpTruthDataSendResponseList;
	}

	public List<RefSponsor> getRpAllRemoteProofingSponsorList() {
		return rpAllRemoteProofingSponsorList;
	}

	public void setRpAllRemoteProofingSponsorList(List<RefSponsor> rpAllRemoteProofingSponsorList) {
		this.rpAllRemoteProofingSponsorList = rpAllRemoteProofingSponsorList;
	}

	public Long getRpSelectedRefSponsorId() {
		return rpSelectedRefSponsorId;
	}

	public void setRpSelectedRefSponsorId(Long rpSelectedRefSponsorId) {
		this.rpSelectedRefSponsorId = rpSelectedRefSponsorId;
	}

	public RefSponsor getRpRefSponsor() {
		return rpRefSponsor;
	}

	public void setRpRefSponsor(RefSponsor rpRefSponsor) {
		this.rpRefSponsor = rpRefSponsor;
	}

    public Person getRpPerson() {
		return rpPerson;
	}

	public void setRpPerson(Person rpPerson) {
		this.rpPerson = rpPerson;
	}

	public String getRpEmailAddress() {
		return rpEmailAddress;
	}

	public void setRpEmailAddress(String rpEmailAddress) {
		this.rpEmailAddress = rpEmailAddress;
	}

	public List<RpEvent> getRpEventList() {
		return rpEventList;
	}

	public void setRpEventList(List<RpEvent> rpEventList) {
		this.rpEventList = rpEventList;
	}

	public RefOtpSupplier getRpPhoneSupplier() {
		return rpPhoneSupplier;
	}

	public void setRpPhoneSupplier(RefOtpSupplier rpPhoneSupplier) {
		this.rpPhoneSupplier = rpPhoneSupplier;
	}

	public RefOtpVelocity getRpVelocity() {
		return rpVelocity;
	}

	public void setRpVelocity(RefOtpVelocity rpVelocity) {
		this.rpVelocity = rpVelocity;
	}

	public List<RpSmfaAttempt> getRpSmfaAttemptList() {
		return rpSmfaAttemptList;
	}

	public void setRpSmfaAttemptList(List<RpSmfaAttempt> rpSmfaAttemptList) {
		this.rpSmfaAttemptList = rpSmfaAttemptList;
	}

	public List<RpOtpAttempt> getRpOtpAttemptList() {
		return rpOtpAttemptList;
	}

	public void setRpOtpAttemptList(List<RpOtpAttempt> rpOtpAttemptList) {
		this.rpOtpAttemptList = rpOtpAttemptList;
	}

	public boolean isUseExpUatEnvironment() {
		return useExpUatEnvironment;
	}

	public void setUseExpUatEnvironment(boolean useExpUatEnvironment) {
		this.useExpUatEnvironment = useExpUatEnvironment;
	}
	
	public boolean isEnforceSupplierOption() {
		return enforceSupplierOption;
	}

	public void setEnforceSupplierOption(boolean enforceSupplierOption) {
		this.enforceSupplierOption = enforceSupplierOption;
	}

	public String getInfAltSupplierId() {
		return infAltSupplierId;
	}

	public void setInfAltSupplierId(String infAltSupplierId) {
		this.infAltSupplierId = infAltSupplierId;
	}

	public String getCnfAltSupplierId() {
		return cnfAltSupplierId;
	}

	public void setCnfAltSupplierId(String cnfAltSupplierId) {
		this.cnfAltSupplierId = cnfAltSupplierId;
	}

	public int getSupplierOptionSponsorId() {
		return supplierOptionSponsorId;
	}

	public void setSupplierOptionSponsorId(int supplierOptionSponsorId) {
		this.supplierOptionSponsorId = supplierOptionSponsorId;
	}

	public int getUserOptionSponsorId() {
		return userOptionSponsorId;
	}

	public void setUserOptionSponsorId(int userOptionSponsorId) {
		this.userOptionSponsorId = userOptionSponsorId;
	}

	public int getEnvironmentOptionSponsorId() {
		return environmentOptionSponsorId;
	}

	public void setEnvironmentOptionSponsorId(int environmentOptionSponsorId) {
		this.environmentOptionSponsorId = environmentOptionSponsorId;
	}

	public String getOtpFlowUserIndex() {
		return otpFlowUserIndex;
	}

	public void setOtpFlowUserIndex(String otpFlowUserIndex) {
		this.otpFlowUserIndex = otpFlowUserIndex;
	}

	public String getSilentAuthFlowUserIndex() {
		return silentAuthFlowUserIndex;
	}

	public void setSilentAuthFlowUserIndex(String silentAuthFlowUserIndex) {
		this.silentAuthFlowUserIndex = silentAuthFlowUserIndex;
	}

	public String getBokuOtpFlowUserIndex() {
		return bokuOtpFlowUserIndex;
	}

	public void setBokuOtpFlowUserIndex(String bokuOtpFlowUserIndex) {
		this.bokuOtpFlowUserIndex = bokuOtpFlowUserIndex;
	}

	public List<ExperianResultVo> getUserOptionList() {
		return userOptionList;
	}

	public void setUserOptionList(List<ExperianResultVo> userOptionList) {
		this.userOptionList = userOptionList;
	}

	public int getUserDecisionSponsorId() {
		return userDecisionSponsorId;
	}

	public void setUserDecisionSponsorId(int userDecisionSponsorId) {
		this.userDecisionSponsorId = userDecisionSponsorId;
	}

	public String getTestUserIndex() {
		return testUserIndex;
	}

	public void setTestUserIndex(String testUserIndex) {
		this.testUserIndex = testUserIndex;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getOrchDecisionJson() {
		return orchDecisionJson;
	}

	public void setOrchDecisionJson(String orchDecisionJson) {
		this.orchDecisionJson = orchDecisionJson;
	}

	public String getCcRequestJson() {
		return ccRequestJson;
	}

	public void setCcRequestJson(String ccRequestJson) {
		this.ccRequestJson = ccRequestJson;
	}

	public String getPredefinedUserIndex() {
		return predefinedUserIndex;
	}

	public void setPredefinedUserIndex(String predefinedUserIndex) {
		this.predefinedUserIndex = predefinedUserIndex;
	}

	public String getPidUsername() {
		return pidUsername;
	}

	public void setPidUsername(String pidUsername) {
		this.pidUsername = pidUsername;
	}

	public String getPidPasscode() {
		return pidPasscode;
	}

	public void setPidPasscode(String pidPasscode) {
		this.pidPasscode = pidPasscode;
	}

	public String getJwtUsername() {
		return jwtUsername;
	}

	public void setJwtUsername(String jwtUsername) {
		this.jwtUsername = jwtUsername;
	}

	public String getJwtPasscode() {
		return jwtPasscode;
	}

	public void setJwtPasscode(String jwtPasscode) {
		this.jwtPasscode = jwtPasscode;
	}

	public String getExperianJwt() {
		return experianJwt;
	}

	public void setExperianJwt(String experianJwt) {
		this.experianJwt = experianJwt;
	}

	public List<RefOtpSupplier> getRefOtpSupplierList() {
		return refOtpSupplierList;
	}

	public void setRefOtpSupplierList(List<RefOtpSupplier> refOtpSupplierList) {
		this.refOtpSupplierList = refOtpSupplierList;
	}

	public int getPhoneAttemptsAllowed() {
		return phoneAttemptsAllowed;
	}

	public void setPhoneAttemptsAllowed(int phoneAttemptsAllowed) {
		this.phoneAttemptsAllowed = phoneAttemptsAllowed;
	}

	public int getPasscodeAttemptsAllowed() {
		return passcodeAttemptsAllowed;
	}

	public void setPasscodeAttemptsAllowed(int passcodeAttemptsAllowed) {
		this.passcodeAttemptsAllowed = passcodeAttemptsAllowed;
	}

	public int getSelectedOtpSupplierId() {
		return selectedOtpSupplierId;
	}

	public void setSelectedOtpSupplierId(int selectedOtpSupplierId) {
		this.selectedOtpSupplierId = selectedOtpSupplierId;
	}

	public int getPhoneAttemptsWindow() {
		return phoneAttemptsWindow;
	}

	public void setPhoneAttemptsWindow(int phoneAttemptsWindow) {
		this.phoneAttemptsWindow = phoneAttemptsWindow;
	}

	public int getPasscodeAttemptsWindow() {
		return passcodeAttemptsWindow;
	}

	public void setPasscodeAttemptsWindow(int passcodeAttemptsWindow) {
		this.passcodeAttemptsWindow = passcodeAttemptsWindow;
	}


	public String getSupplierDetermineSuccessMsg() {
		return supplierDetermineSuccessMsg;
	}

	public void setSupplierDetermineSuccessMsg(String supplierDetermineSuccessMsg) {
		this.supplierDetermineSuccessMsg = supplierDetermineSuccessMsg;
	}

	public String getSupplierDetermine2SuccessMsg() {
		return supplierDetermine2SuccessMsg;
	}

	public void setSupplierDetermine2SuccessMsg(String supplierDetermine2SuccessMsg) {
		this.supplierDetermine2SuccessMsg = supplierDetermine2SuccessMsg;
	}

	public String getSupplierDetermineErrorMsg() {
		return supplierDetermineErrorMsg;
	}

	public void setSupplierDetermineErrorMsg(String supplierDetermineErrorMsg) {
		this.supplierDetermineErrorMsg = supplierDetermineErrorMsg;
	}

	public String getSupplierDetermine2ErrorMsg() {
		return supplierDetermine2ErrorMsg;
	}

	public void setSupplierDetermine2ErrorMsg(String supplierDetermine2ErrorMsg) {
		this.supplierDetermine2ErrorMsg = supplierDetermine2ErrorMsg;
	}
	
	public boolean isShowSupplierDetermineSuccessMsg() {
		return showSupplierDetermineSuccessMsg;
	}

	public void setShowSupplierDetermineSuccessMsg(boolean showSupplierDetermineSuccessMsg) {
		this.showSupplierDetermineSuccessMsg = showSupplierDetermineSuccessMsg;
	}

	public boolean isShowSupplierDetermine2SuccessMsg() {
		return showSupplierDetermine2SuccessMsg;
	}

	public void setShowSupplierDetermine2SuccessMsg(boolean showSupplierDetermine2SuccessMsg) {
		this.showSupplierDetermine2SuccessMsg = showSupplierDetermine2SuccessMsg;
	}

	public boolean isShowSupplierDetermineErrorMsg() {
		return showSupplierDetermineErrorMsg;
	}

	public void setShowSupplierDetermineErrorMsg(boolean showSupplierDetermineErrorMsg) {
		this.showSupplierDetermineErrorMsg = showSupplierDetermineErrorMsg;
	}
	
	public boolean isShowSupplierDetermine2ErrorMsg() {
		return showSupplierDetermine2ErrorMsg;
	}

	public void setShowSupplierDetermine2ErrorMsg(boolean showSupplierDetermine2ErrorMsg) {
		this.showSupplierDetermine2ErrorMsg = showSupplierDetermine2ErrorMsg;
	}


	public String getExpFirstName() {
		return expFirstName;
	}


	public void setExpFirstName(String expFirstName) {
		this.expFirstName = expFirstName;
	}


	public String getExpLastName() {
		return expLastName;
	}


	public void setExpLastName(String expLastName) {
		this.expLastName = expLastName;
	}


	public String getExpEmailAddress() {
		return expEmailAddress;
	}


	public void setExpEmailAddress(String expEmailAddress) {
		this.expEmailAddress = expEmailAddress;
	}


	public String getExptreetAddress() {
		return exptreetAddress;
	}

	public void setExptreetAddress(String exptreetAddress) {
		this.exptreetAddress = exptreetAddress;
	}

	public String getExpCity() {
		return expCity;
	}

	public void setExpCity(String expCity) {
		this.expCity = expCity;
	}

	public String getExpState() {
		return expState;
	}

	public void setExpState(String expState) {
		this.expState = expState;
	}

	public String getExpZip5() {
		return expZip5;
	}

	public void setExpZip5(String expZip5) {
		this.expZip5 = expZip5;
	}

	public String getExpMobileNumber() {
		return expMobileNumber;
	}

	public void setExpMobileNumber(String expMobileNumber) {
		this.expMobileNumber = expMobileNumber;
	}

	public String getExpSponsorUserId() {
		return expSponsorUserId;
	}

	public void setExpSponsorUserId(String expSponsorUserId) {
		this.expSponsorUserId = expSponsorUserId;
	}

	public long getUserAppId() {
		return userAppId;
	}

	public void setUserAppId(long userAppId) {
		this.userAppId = userAppId;
	}

	public List<RefApp> getAppList() {
		return appList;
	}

	public void setAppList(List<RefApp> appList) {
		this.appList = appList;
	}

	public RefApp getUserApp() {
		return userApp;
	}

	public void setUserApp(RefApp userApp) {
		this.userApp = userApp;
	}


	public boolean isUseJwtAlternativeCredential() {
		return useJwtAlternativeCredential;
	}


	public void setUseJwtAlternativeCredential(boolean useJwtAlternativeCredential) {
		this.useJwtAlternativeCredential = useJwtAlternativeCredential;
	}


	public boolean isUseXcoreAlternativeCredential() {
		return useXcoreAlternativeCredential;
	}


	public void setUseXcoreAlternativeCredential(boolean useXcoreAlternativeCredential) {
		this.useXcoreAlternativeCredential = useXcoreAlternativeCredential;
	}


	public boolean isUseJwtAlternativeEndpoint() {
		return useJwtAlternativeEndpoint;
	}


	public void setUseJwtAlternativeEndpoint(boolean useJwtAlternativeEndpoint) {
		this.useJwtAlternativeEndpoint = useJwtAlternativeEndpoint;
	}


	public boolean isUseXCoreAlternativeEndpoint() {
		return useXCoreAlternativeEndpoint;
	}


	public void setUseXCoreAlternativeEndpoint(boolean useXCoreAlternativeEndpoint) {
		this.useXCoreAlternativeEndpoint = useXCoreAlternativeEndpoint;
	}


	public int getAltCredEndptOptionSponsorId() {
		return altCredEndptOptionSponsorId;
	}


	public void setAltCredEndptOptionSponsorId(int altCredEndptOptionSponsorId) {
		this.altCredEndptOptionSponsorId = altCredEndptOptionSponsorId;
	}


	public int getAltCredSponsorId() {
		return altCredSponsorId;
	}


	public void setAltCredSponsorId(int altCredSponsorId) {
		this.altCredSponsorId = altCredSponsorId;
	}


	public String getAltCredSettingIndex() {
		return altCredSettingIndex;
	}


	public void setAltCredSettingIndex(String altCredSettingIndex) {
		this.altCredSettingIndex = altCredSettingIndex;
	}


	public List<NameValueVo> getAltCredSettingList() {
		return altCredSettingList;
	}


	public void setAltCredSettingList(List<NameValueVo> altCredSettingList) {
		this.altCredSettingList = altCredSettingList;
	}


	public String getAltCredentialType() {
		return altCredentialType;
	}


	public void setAltCredentialType(String altCredentialType) {
		this.altCredentialType = altCredentialType;
	}


	public String getAltCredentialCode() {
		return altCredentialCode;
	}


	public void setAltCredentialCode(String altCredentialCode) {
		this.altCredentialCode = altCredentialCode;
	}


	public String getAltCredentialValue() {
		return altCredentialValue;
	}


	public void setAltCredentialValue(String altCredentialValue) {
		this.altCredentialValue = altCredentialValue;
	}


	public String getSponsorConfigValue() {
		return sponsorConfigValue;
	}


	public void setSponsorConfigValue(String sponsorConfigValue) {
		this.sponsorConfigValue = sponsorConfigValue;
	}


	public int getGenericConfigSponsorId() {
		return genericConfigSponsorId;
	}


	public void setGenericConfigSponsorId(int genericConfigSponsorId) {
		this.genericConfigSponsorId = genericConfigSponsorId;
	}


	public boolean isShowAltCredSettingSuccessMsg() {
		return showAltCredSettingSuccessMsg;
	}


	public void setShowAltCredSettingSuccessMsg(boolean showAltCredSettingSuccessMsg) {
		this.showAltCredSettingSuccessMsg = showAltCredSettingSuccessMsg;
	}


	public boolean isShowAltCredSettingErrorMsg() {
		return showAltCredSettingErrorMsg;
	}


	public void setShowAltCredSettingErrorMsg(boolean showAltCredSettingErrorMsg) {
		this.showAltCredSettingErrorMsg = showAltCredSettingErrorMsg;
	}


	public boolean isShowAltCredOptionSuccessMsg() {
		return showAltCredOptionSuccessMsg;
	}


	public void setShowAltCredOptionSuccessMsg(boolean showAltCredOptionSuccessMsg) {
		this.showAltCredOptionSuccessMsg = showAltCredOptionSuccessMsg;
	}


	public boolean isShowAltCredOptionErrorMsg() {
		return showAltCredOptionErrorMsg;
	}


	public void setShowAltCredOptionErrorMsg(boolean showAltCredOptionErrorMsg) {
		this.showAltCredOptionErrorMsg = showAltCredOptionErrorMsg;
	}


	public boolean isShowSponsorConfigSetterSuccessMsg() {
		return showSponsorConfigSetterSuccessMsg;
	}


	public void setShowSponsorConfigSetterSuccessMsg(boolean showSponsorConfigSetterSuccessMsg) {
		this.showSponsorConfigSetterSuccessMsg = showSponsorConfigSetterSuccessMsg;
	}


	public boolean isShowSponsorConfigSetterErrorMsg() {
		return showSponsorConfigSetterErrorMsg;
	}


	public void setShowSponsorConfigSetterErrorMsg(boolean showSponsorConfigSetterErrorMsg) {
		this.showSponsorConfigSetterErrorMsg = showSponsorConfigSetterErrorMsg;
	}


	public String getAltCredSettingSuccessMsg() {
		return altCredSettingSuccessMsg;
	}


	public void setAltCredSettingSuccessMsg(String altCredSettingSuccessMsg) {
		this.altCredSettingSuccessMsg = altCredSettingSuccessMsg;
	}


	public String getAltCredSettingErrorMsg() {
		return altCredSettingErrorMsg;
	}


	public void setAltCredSettingErrorMsg(String altCredSettingErrorMsg) {
		this.altCredSettingErrorMsg = altCredSettingErrorMsg;
	}


	public String getAltCredOptionSuccessMsg() {
		return altCredOptionSuccessMsg;
	}


	public void setAltCredOptionSuccessMsg(String altCredOptionSuccessMsg) {
		this.altCredOptionSuccessMsg = altCredOptionSuccessMsg;
	}


	public String getAltCredOptionErrorMsg() {
		return altCredOptionErrorMsg;
	}


	public void setAltCredOptionErrorMsg(String altCredOptionErrorMsg) {
		this.altCredOptionErrorMsg = altCredOptionErrorMsg;
	}


	public String getSponsorConfigSetterSuccessMsg() {
		return sponsorConfigSetterSuccessMsg;
	}


	public void setSponsorConfigSetterSuccessMsg(String sponsorConfigSetterSuccessMsg) {
		this.sponsorConfigSetterSuccessMsg = sponsorConfigSetterSuccessMsg;
	}


	public String getSponsorConfigSetterErrorMsg() {
		return sponsorConfigSetterErrorMsg;
	}

	public void setSponsorConfigSetterErrorMsg(String sponsorConfigSetterErrorMsg) {
		this.sponsorConfigSetterErrorMsg = sponsorConfigSetterErrorMsg;
	}

    public String getSponsorConfigName() {
		return sponsorConfigName;
	}


	public void setSponsorConfigName(String sponsorConfigName) {
		this.sponsorConfigName = sponsorConfigName;
	}

}

