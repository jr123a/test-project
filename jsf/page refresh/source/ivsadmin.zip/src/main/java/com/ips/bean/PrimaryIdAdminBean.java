package com.ips.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.entity.RefPrimaryIdType;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;

@ManagedBean(name = "primaryIdsAdminBean")
@ViewScoped
public class PrimaryIdAdminBean extends IPSAdminController implements Serializable {
    private static final long serialVersionUID = 1L;

    private static final String ADMIN_SERVICE = "AdminService";

    private String errorMsg;
    private String warnMsg;
    private String infoMsg;
    private boolean showInfoMsg;
    private boolean showWarnMsg;
    private boolean showErrorMsg;
    private String idDesc;
    private List<RefPrimaryIdType> primaryIdList;
    private boolean strongId;
    private boolean hasName;
    private boolean hasAddress;
    
    private boolean showSaveBtn;
    private boolean showUpdateBtn;
    private boolean showConfirmBtn;
    private boolean showCancelBtn;
    private RefPrimaryIdType refPrimaryIdType;
    private boolean initialized;
    private boolean disableDesc;
    private boolean disableCheck;
    private boolean disableNameCheck;
    private boolean disableAddressCheck;
    private boolean hasFirstLastPage;
    private boolean disableFirstLastPageCheck;
    private boolean hasStateId;
    private boolean disableHasStateId;
    private boolean captureBarcode;
    private boolean disableCaptureBarcode;
    private boolean idChanged;
    private AdminService adminService;

    @PostConstruct
    public void init() {
        CustomLogger.enter(this.getClass());
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
        if (webAppContext != null) {
		adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);
        if (!initialized) {
            setInitialized(true);
            initButtonDisplay();
            loadPrimaryIds();
        }
        } else {
			CustomLogger.error(this.getClass(), "Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
    }

    private void setNoMsg() {
        CustomLogger.enter(this.getClass());

        setErrorMsg(StringUtils.EMPTY);
        setWarnMsg(StringUtils.EMPTY);
        setInfoMsg(StringUtils.EMPTY);

        setShowErrorMsg(false);
        setShowWarnMsg(false);
        setShowInfoMsg(false);
    }

    private void initButtonDisplay() {
        CustomLogger.enter(this.getClass());
        setDisableDesc(false);
        setDisableCheck(false);
        setDisableNameCheck(false);
        setDisableAddressCheck(false);
        setDisableFirstLastPageCheck(false);
        setDisableHasStateId(false);
        setDisableCaptureBarcode(false);
        setIdDesc(StringUtils.EMPTY);
        setStrongId(false);
        setHasName(false);
        setHasAddress(false);
        setHasFirstLastPage(false);
        setCaptureBarcode(false);
        setHasStateId(false);
        setShowSaveBtn(true);
        setShowUpdateBtn(false);
        setShowConfirmBtn(false);
        setShowCancelBtn(false);
    }

    private void loadPrimaryIds() {

        primaryIdList = adminService.getPrimaryIdList();
    }

    public void addRecord() {
        setNoMsg();
        boolean alreadyOnList = false;
        primaryIdList = adminService.getPrimaryIdList();
        if (!idDesc.isEmpty()) {
            for (RefPrimaryIdType list : primaryIdList) {
                if (idDesc.equalsIgnoreCase(list.getIdTypeDescription())) {
                    setErrorMsg("Primary ID already on list.");
                    setShowErrorMsg(true);
                    alreadyOnList = true;
                    break;
                }
            }
            if (!alreadyOnList) {
                RefPrimaryIdType ids = new RefPrimaryIdType();
                ids.setIdTypeDescription(idDesc);
                ids.setStrongId(strongId ? "Y" : "N");
                ids.setHasName(hasName ? "Y" : "N");
                ids.setHasAddress(hasAddress ? "Y" : "N");
                ids.setHasFirstLastPage(hasFirstLastPage ? "Y" : "N");
                ids.setCaptureBarcode(captureBarcode ? "Y" : "N");
                ids.setIsStateid(hasStateId ? "Y" : "N");
                ids.setCreateDate(getCurrentTime());
                long newIdTypeId = primaryIdList.stream().max(Comparator.comparingLong(sp -> sp.getIdType())).get().getIdType() + 1;
                ids.setIdType(newIdTypeId);
                try {
                    adminService.addPrimaryId(ids);
                    setInfoMsg("Primary ID saved.");
                    setShowInfoMsg(true);
                } catch (Exception e) {
                    setErrorMsg("Error saving Primary ID.");
                    setShowErrorMsg(true);
                    CustomLogger.error(this.getClass(), "Exception occured while adding Primary id", e);
                }

            }

        } else {
            setErrorMsg("Id description cannot be empty.");
            setShowErrorMsg(true);
        }
        initButtonDisplay();
        loadPrimaryIds();

    }

    public void updateRecord() {
        boolean alreadyOnList = false;

        if (refPrimaryIdType != null && (!refPrimaryIdType.getIdTypeDescription().equalsIgnoreCase(idDesc))) {
            setIdChanged(true);
        }
        if (!idDesc.isEmpty()) {
            for (RefPrimaryIdType list : primaryIdList) {
                if (idDesc.equalsIgnoreCase(list.getIdTypeDescription()) && idChanged) {
                    setErrorMsg("Primary ID already on list.");
                    setShowErrorMsg(true);
                    alreadyOnList = true;
                    initButtonDisplay();
                    loadPrimaryIds();
                    setIdChanged(false);
                    break;
                }
            }
            if (!alreadyOnList && refPrimaryIdType != null) {
                refPrimaryIdType.setIdTypeDescription(idDesc);
                refPrimaryIdType.setStrongId(strongId ? "Y" : "N");
                refPrimaryIdType.setHasName(hasName ? "Y" : "N");
                refPrimaryIdType.setHasAddress(hasAddress ? "Y" : "N");
                refPrimaryIdType.setHasFirstLastPage(hasFirstLastPage ? "Y" : "N");
                refPrimaryIdType.setCaptureBarcode(captureBarcode ? "Y" : "N");
                refPrimaryIdType.setIsStateid(hasStateId ? "Y" : "N");
                refPrimaryIdType.setUpdateDate(getCurrentTime());
                try {
                    adminService.updatePrimaryId(refPrimaryIdType);
                    setNoMsg();
                    setInfoMsg("Primary ID updated.");
                    setShowInfoMsg(true);
                } catch (Exception e) {
                    setErrorMsg("Error updating Primary ID.");
                    setShowErrorMsg(true);
                    CustomLogger.error(this.getClass(), "Exception occured while updating Primary id", e);
                }

                initButtonDisplay();
                loadPrimaryIds();
            }
        }

    }

    public void editRecord(long idType) {
        setNoMsg();
        setIdDesc(StringUtils.EMPTY);
        setStrongId(false);
        long eventUse = adminService.getPrimaryIdUsedCountByIdType(idType);
        long sponsorUsed = adminService.getPrimaryIdCountForSponsor(idType);
        long idValidationUsed = adminService.getPrimaryIdUsedCountByIdValidation(idType);

        setDisableDesc(false);
        setDisableCheck(false);
        setDisableNameCheck(false);
        setDisableAddressCheck(false);
        setDisableFirstLastPageCheck(false);
        setDisableHasStateId(false);
        setDisableCaptureBarcode(false);
        if (eventUse > 0 || sponsorUsed > 0 || idValidationUsed > 0) {
            setWarnMsg("This Primary ID has been used for an IPP event. Only Strong ID can be modified.");
            setShowWarnMsg(true);
            refPrimaryIdType = adminService.getPrimaryIdType(idType);
            setIdDesc(refPrimaryIdType.getIdTypeDescription());
            strongId = refPrimaryIdType.getStrongId() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getStrongId());
            hasName = refPrimaryIdType.getHasName() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getHasName());
            hasAddress = refPrimaryIdType.getHasAddress() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getHasAddress());
            hasFirstLastPage= refPrimaryIdType.getHasFirstLastPage() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getHasFirstLastPage());
            hasStateId= refPrimaryIdType.getIsStateid() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getIsStateid());
            captureBarcode = refPrimaryIdType.getCaptureBarcode() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getCaptureBarcode());
            setDisableDesc(true);
            setShowSaveBtn(false);
            setShowUpdateBtn(true);
            setShowConfirmBtn(false);
            setShowCancelBtn(true);
        } else {
            refPrimaryIdType = adminService.getPrimaryIdType(idType);
            setIdDesc(refPrimaryIdType.getIdTypeDescription());
            strongId = refPrimaryIdType.getStrongId() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getStrongId());
            hasName = refPrimaryIdType.getHasName() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getHasName());
            hasAddress = refPrimaryIdType.getHasAddress() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getHasAddress());
            hasFirstLastPage= refPrimaryIdType.getHasFirstLastPage() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getHasFirstLastPage());
            hasStateId= refPrimaryIdType.getIsStateid() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getIsStateid());
            captureBarcode = refPrimaryIdType.getCaptureBarcode() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getCaptureBarcode());
            setDisableDesc(true);
            setShowSaveBtn(false);
            setShowUpdateBtn(true);
            setShowConfirmBtn(false);
            setShowCancelBtn(true);
        }

    }

    public void deleteRecord(long idType) {
        setNoMsg();
        setIdDesc(StringUtils.EMPTY);
        setStrongId(false);
        long eventUse = adminService.getPrimaryIdUsedCountByIdType(idType);
        long sponsorUsed = adminService.getPrimaryIdCountForSponsor(idType);
        long idValidationUsed = adminService.getPrimaryIdUsedCountByIdValidation(idType);
        setDisableDesc(false);
        setDisableCheck(false);
        setDisableNameCheck(false);
        setDisableAddressCheck(false);
        setDisableFirstLastPageCheck(false);
        setDisableHasStateId(false);
        setDisableCaptureBarcode(false);
        if (eventUse > 0 || sponsorUsed > 0 || idValidationUsed > 0) {
            setWarnMsg("This Primary ID has been used for an IPP event. It cannot be deleted.");
            setShowWarnMsg(true);
        } else {
            refPrimaryIdType = adminService.getPrimaryIdType(idType);
            setIdDesc(refPrimaryIdType.getIdTypeDescription());
            strongId = refPrimaryIdType.getStrongId() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getStrongId());
            hasName = refPrimaryIdType.getHasName() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getHasName());
            hasAddress = refPrimaryIdType.getHasAddress() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getHasAddress());
            hasFirstLastPage= refPrimaryIdType.getHasFirstLastPage() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getHasFirstLastPage());
            hasStateId= refPrimaryIdType.getIsStateid() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getIsStateid());
            captureBarcode = refPrimaryIdType.getCaptureBarcode() != null && "Y".equalsIgnoreCase(refPrimaryIdType.getCaptureBarcode());
            setDisableDesc(true);
            setDisableDesc(true);
            setDisableCheck(true);
            setDisableNameCheck(true);
            setDisableAddressCheck(true);
            setDisableFirstLastPageCheck(true);
            setDisableHasStateId(true);
            setDisableCaptureBarcode(true);
            setShowSaveBtn(false);
            setShowUpdateBtn(false);
            setShowConfirmBtn(true);
            setShowCancelBtn(true);
            setInfoMsg("Please confirm you want to delete this record.");
            setShowInfoMsg(true);
        }

    }

    public void confirmDelete() {
        setNoMsg();
        if (refPrimaryIdType != null) {

            try {
                adminService.deletePrimaryId(refPrimaryIdType);
                setInfoMsg("Primary ID deleted.");
                setShowInfoMsg(true);
            } catch (Exception e) {
                setErrorMsg("Error deleting Primary ID.");
                setShowErrorMsg(true);
                CustomLogger.error(this.getClass(), "Exception occured while deleting Primary id", e);
            }

            initButtonDisplay();
            loadPrimaryIds();
        }
    }

    public void cancel() {
        setNoMsg();
        refPrimaryIdType = new RefPrimaryIdType();
        initButtonDisplay();
        loadPrimaryIds();
    }

    private Timestamp getCurrentTime() {
        return new Timestamp(new Date().getTime());
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getWarnMsg() {
        return warnMsg;
    }

    public void setWarnMsg(String autoWarnMsg) {
        this.warnMsg = autoWarnMsg;
    }

    public String getInfoMsg() {
        return infoMsg;
    }

    public void setInfoMsg(String autoInfoMsg) {
        this.infoMsg = autoInfoMsg;
    }

    public boolean isShowInfoMsg() {
        return showInfoMsg;
    }

    public void setShowInfoMsg(boolean showAutoInfoMsg) {
        this.showInfoMsg = showAutoInfoMsg;
    }

    public boolean isShowWarnMsg() {
        return showWarnMsg;
    }

    public void setShowWarnMsg(boolean showAutoWarnMsg) {
        this.showWarnMsg = showAutoWarnMsg;
    }

    public boolean isShowErrorMsg() {
        return showErrorMsg;
    }

    public void setShowErrorMsg(boolean showAutoErrorMsg) {
        this.showErrorMsg = showAutoErrorMsg;
    }

    public String getIdDesc() {
        return idDesc;
    }

    public void setIdDesc(String idDesc) {
        this.idDesc = idDesc;
    }

    public List<RefPrimaryIdType> getPrimaryIdList() {
        return primaryIdList;
    }

    public void setPrimaryIdList(List<RefPrimaryIdType> primaryIdList) {
        this.primaryIdList = primaryIdList;
    }

    public boolean isStrongId() {
        return strongId;
    }

    public void setStrongId(boolean strongId) {
        this.strongId = strongId;
    }

    public boolean isShowSaveBtn() {
        return showSaveBtn;
    }

    public void setShowSaveBtn(boolean showSaveBtn) {
        this.showSaveBtn = showSaveBtn;
    }

    public boolean isShowUpdateBtn() {
        return showUpdateBtn;
    }

    public void setShowUpdateBtn(boolean showUpdateBtn) {
        this.showUpdateBtn = showUpdateBtn;
    }

    public boolean isShowConfirmBtn() {
        return showConfirmBtn;
    }

    public void setShowConfirmBtn(boolean showConfirmBtn) {
        this.showConfirmBtn = showConfirmBtn;
    }

    public boolean isShowCancelBtn() {
        return showCancelBtn;
    }

    public void setShowCancelBtn(boolean showCancelBtn) {
        this.showCancelBtn = showCancelBtn;
    }

    public boolean isInitialized() {
        return initialized;
    }

    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }

    public boolean isDisableDesc() {
        return disableDesc;
    }

    public void setDisableDesc(boolean disableDesc) {
        this.disableDesc = disableDesc;
    }

    public boolean isDisableCheck() {
        return disableCheck;
    }

    public void setDisableCheck(boolean disableCheck) {
        this.disableCheck = disableCheck;
    }
    
    public boolean isDisableNameCheck() {
        return disableNameCheck;
    }

    public void setDisableNameCheck(boolean disableNameCheck) {
        this.disableNameCheck = disableNameCheck;
    }
    public boolean isDisableAddressCheck() {
        return disableAddressCheck;
    }

    public void setDisableAddressCheck(boolean disableAddressCheck) {
        this.disableAddressCheck = disableAddressCheck;
    }
    
    public boolean ishasName() {
        return hasName;
    }

    public void setHasName(boolean hasName) {
        this.hasName = hasName;
    }
    public boolean ishasAddress() {
        return hasAddress;
    }

    public void setHasAddress(boolean hasAddress) {
        this.hasAddress = hasAddress;
    }
    
    public boolean isDisableFirstLastPageCheck() {
        return disableFirstLastPageCheck;
    }

    public void setDisableFirstLastPageCheck(boolean disableFirstLastPageCheck) {
        this.disableFirstLastPageCheck = disableFirstLastPageCheck;
    }
    
    public boolean ishasFirstLastPage() {
        return hasFirstLastPage;
    }

    public void setHasFirstLastPage(boolean hasFirstLastPage) {
        this.hasFirstLastPage = hasFirstLastPage;
    }


    public boolean isHasStateId() {
		return hasStateId;
	}

	public void setHasStateId(boolean hasStateId) {
		this.hasStateId = hasStateId;
	}

	public boolean isDisableHasStateId() {
		return disableHasStateId;
	}

	public void setDisableHasStateId(boolean disableHasStateId) {
		this.disableHasStateId = disableHasStateId;
	}

	public boolean isCaptureBarcode() {
		return captureBarcode;
	}

	public void setCaptureBarcode(boolean captureBarcode) {
		this.captureBarcode = captureBarcode;
	}

	public boolean isDisableCaptureBarcode() {
		return disableCaptureBarcode;
	}

	public void setDisableCaptureBarcode(boolean disableCaptureBarcode) {
		this.disableCaptureBarcode = disableCaptureBarcode;
	}

	public boolean isIdChanged() {
        return idChanged;
    }

    public void setIdChanged(boolean idChanged) {
        this.idChanged = idChanged;
    }

}
