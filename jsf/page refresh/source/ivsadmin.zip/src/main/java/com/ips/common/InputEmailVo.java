package com.ips.common;

import java.io.Serializable;

public class InputEmailVo implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private int index;
    private String emailAddress;
    private String message;
    private boolean renderDeleteImg;
    private boolean renderInvalidMsg;
    
    public int getIndex() {
        return index;
    }
    
    public void setIndex(int index) {
        this.index = index;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isRenderDeleteImg() {
        return renderDeleteImg;
    }

    public void setRenderDeleteImg(boolean renderDeleteImg) {
        this.renderDeleteImg = renderDeleteImg;
    }

    public boolean isRenderInvalidMsg() {
        return renderInvalidMsg;
    }

    public void setRenderInvalidMsg(boolean renderInvalidMsg) {
        this.renderInvalidMsg = renderInvalidMsg;
    }
}
