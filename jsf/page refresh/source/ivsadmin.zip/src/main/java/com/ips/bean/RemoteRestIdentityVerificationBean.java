package com.ips.bean;

import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.wink.client.ClientConfig;
import org.apache.wink.client.ClientRuntimeException;
import org.apache.wink.client.ClientWebException;
import org.apache.wink.client.Resource;
import org.apache.wink.client.RestClient;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.ibm.json.java.JSONObject;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.Utils;
import com.ips.request.RemoteRequest;
import com.ips.proofing.CommonRestService;
import com.ips.service.AdminService;
import com.ips.service.DeviceReputationService;
import com.ips.service.RemoteProofingService;

@ManagedBean(name = "remoteRestIdVerificationBean")
@ViewScoped
public class RemoteRestIdentityVerificationBean extends IPSAdminController implements Serializable {

	private static final long serialVersionUID = 1L;

	private DeviceReputationService deviceReputationService;
	private AdminService adminService;
	private CommonRestService commonRestService;

	private Map<String, Object> cdRequestHashMap;
	private Map<String, Object> vpRequestHashMap;
	private Map<String, Object> cpRequestHashMap;
	private Map<String, Object> rpRequestHashMap;
	private Map<String, Object> rlRequestHashMap;
	private Map<String, Object> vlRequestHashMap;
	private String cdProfilingOrgId;
	private String cdProfilingSessionId;
	private String cdCustomerIpAddress;
	private String cdWebSessionId;

	private String cdSponsorId;
	private String cdSponsorUserId;
	private String cdFirstName;
	private String cdLastName;
	private String cdEmailAddress;
	private String cdStreetAddress;
	private String cdCity;
	private String cdState;
	private String cdZip5;
	private String cdMobileNumber;
	private String cdJsonRequest;
	private String cdJsonResponse;

	private String vpSponsorId;
	private String vpSponsorUserId;
	private String vpFirstName;
	private String vpLastName;
	private String vpBirthDate;
	private String vpStreetAddress;
	private String vpCity;
	private String vpState;
	private String vpZip5;
	private String vpMobileNumber;
	private String vpJsonRequest;
	private String vpJsonResponse;

	private String cpSponsorId;
	private String cpSponsorUserId;
	private String cpPasscode;
	private String cpJsonRequest;
	private String cpJsonResponse;

	private String rpSponsorId;
	private String rpSponsorUserId;
	private String rpFirstName;
	private String rpLastName;
	private String rpBirthDate;
	private String rpStreetAddress;
	private String rpCity;
	private String rpState;
	private String rpZip5;
	private String rpJsonRequest;
	private String rpJsonResponse;

	private String rlSponsorId;
	private String rlSponsorUserId;
	private String rlFirstName;
	private String rlLastName;
	private String rlBirthDate;
	private String rlStreetAddress;
	private String rlCity;
	private String rlState;
	private String rlZip5;
	private String rlMobileNumber;
	private String rlJsonRequest;
	private String rlJsonResponse;

	private String vlSponsorId;
	private String vlSponsorUserId;
	private String vlMobileNumber;
	private String vlJsonRequest;
	private String vlJsonResponse;

	private String checkDeviceInstMsg;
	private String checkDeviceErrorMsg;
	private String checkDeviceSuccessMsg;

	private String verifyPhoneInstMsg;
	private String verifyPhoneErrorMsg;
	private String verifyPhoneSuccessMsg;

	private String confirmPasscodeInstMsg;
	private String confirmPasscodeErrorMsg;
	private String confirmPasscodeSuccessMsg;

	private String requestPasscodeInstMsg;
	private String requestPasscodeErrorMsg;
	private String requestPasscodeSuccessMsg;

	private String resendSmfaLinkInstMsg;
	private String resendSmfaLinkErrorMsg;
	private String resendSmfaLinkSuccessMsg;

	private String validateSmfaLinkInstMsg;
	private String validateSmfaLinkErrorMsg;
	private String validateSmfaLinkSuccessMsg;

	private boolean showCheckDeviceInstMsg;
	private boolean showCheckDeviceErrorMsg;
	private boolean showCheckDeviceSuccessMsg;
	private boolean showCheckDeviceRequestJsonPanel;
	private boolean showCheckDeviceResponseJsonPanel;
	private boolean showCheckDeviceSubmitBtn;

	private boolean showVerifyPhoneInstMsg;
	private boolean showVerifyPhoneErrorMsg;
	private boolean showVerifyPhoneSuccessMsg;
	private boolean showVerifyPhoneRequestJsonPanel;
	private boolean showVerifyPhoneResponseJsonPanel;
	private boolean showVerifyPhoneGenerateBtn;
	private boolean showVerifyPhoneSubmitBtn;

	private boolean showConfirmPasscodeInstMsg;
	private boolean showConfirmPasscodeErrorMsg;
	private boolean showConfirmPasscodeSuccessMsg;
	private boolean showConfirmPasscodeRequestJsonPanel;
	private boolean showConfirmPasscodeResponseJsonPanel;
	private boolean showConfirmPasscodeGenerateBtn;
	private boolean showConfirmPasscodeSubmitBtn;

	private boolean showRequestPasscodeInstMsg;
	private boolean showRequestPasscodeErrorMsg;
	private boolean showRequestPasscodeSuccessMsg;
	private boolean showRequestPasscodeRequestJsonPanel;
	private boolean showRequestPasscodeResponseJsonPanel;
	private boolean showRequestPasscodeGenerateBtn;
	private boolean showRequestPasscodeSubmitBtn;

	private boolean showResendSmfaLinkInstMsg;
	private boolean showResendSmfaLinkErrorMsg;
	private boolean showResendSmfaLinkSuccessMsg;
	private boolean showResendSmfaLinkRequestJsonPanel;
	private boolean showResendSmfaLinkResponseJsonPanel;
	private boolean showResendSmfaLinkGenerateBtn;
	private boolean showResendSmfaLinkSubmitBtn;

	private boolean showValidateSmfaLinkInstMsg;
	private boolean showValidateSmfaLinkErrorMsg;
	private boolean showValidateSmfaLinkSuccessMsg;
	private boolean showValidateSmfaLinkRequestJsonPanel;
	private boolean showValidateSmfaLinkResponseJsonPanel;
	private boolean showValidateSmfaLinkGenerateBtn;
	private boolean showValidateSmfaLinkSubmitBtn;
	private boolean initialized = false;

	private static String propHost;
	private static String propPort;
	private static String checkDeviceResourceUrl;
	private static String verifyPhoneResourceUrl;
	private static String confirmPasscodeResourceUrl;
	private static String requestPasscodeResourceUrl;
	private static String resendSmfaLinkResourceUrl;
	private static String validateSmfaLinkResourceUrl;
	private static final long SPONSOR_ID_OPERATION_SANTA = 2;
	private static final String RESOURCE_STREAM_PATH = "/ips.properties";
	private static final String PROXY_HOST_PROP_NAME = "com.ipsweb.proxyHost";
	private static final String PROXY_PORT_PROP_NAME = "com.ipsweb.proxyPort";
	private static final String URL_OP_SANTA_CHECK_DEVICE_WS = "com.ipsweb.OperationSantaCheckDeviceWs";
	private static final String URL_OP_SANTA_VERIFY_PHONE_WS = "com.ipsweb.OperationSantaVerifyPhoneWs";
	private static final String URL_OP_SANTA_CONFIRM_PASSCODE_WS = "com.ipsweb.OperationSantaConfirmPasscodeWs";
	private static final String URL_OP_SANTA_REQUEST_PASSCODE_WS = "com.ipsweb.OperationSantaRequestPasscodeWs";
	private static final String URL_OP_SANTA_RESEND_LINK_WS = "com.ipsweb.OperationSantaResendLinkWs";
	private static final String URL_OP_SANTA_VALIDATE_LINK_WS = "com.ipsweb.OperationSantaValidateLinkWs";
	private static final String ERROR_MSG_READING_PROP_FMT = "Error occured reading from properties file for %s.";
	private static final String WS_CHECK_DEVICE = "CheckDevice";
	private static final String WS_VERIFY_PHONE = "VerifyPhone";
	private static final String WS_CONFIRM_PASSCODE = "ConfirmPasscode";
	private static final String WS_REQUEST_PASSCODE = "RequestPasscode";
	private static final String WS_RESEND_LINK = "Resend SMFA Link";
	private static final String WS_VALIDATE_LINK = "Validate SMFA Link";
	private static final String MAP_KEY_SPONSOR_ID = "sponsorID";
	private static final String MAP_KEY_CUSTOMER_UNIQUE_ID = "customerUniqueID";
	private static final String MAP_KEY_FIRST_NAME = "firstName";
	private static final String MAP_KEY_LAST_NAME = "lastName";
	private static final String MAP_KEY_EMAIL_ADDRESS = "emailAddress";
	private static final String MAP_KEY_STREET_ADDRESS1 = "streetAddress1";
	private static final String MAP_KEY_CITY = "city";
	private static final String MAP_KEY_STATE = "state";
	private static final String MAP_KEY_ZIP_CODE = "zipCode";
	private static final String MAP_KEY_MOBILE_PHONE = "mobilePhone";
	private static final String MAP_KEY_BIRTH_DATE = "birthDate";
	private static final String MAP_KEY_PASSCODE = "passcode";
	private static final String MAP_KEY_PROFILING_SESSION_ID = "profilingSessionID";
	private static final String MAP_KEY_WEB_SESSION_ID = "webSessionID";
	private static final String MAP_KEY_TRUE_IP_ADDRESS = "trueIPAddress";
	private static final String MSG_SUCCESSFULLY_GENERATED_FMT = "%s web service request was successfully generated!";
	private static final String MSG_SUCCESSFULLY_SUBMITTED_FMT = "%s web service request was successfully submitted!";
	private static final String MSG_REQUEST_JSON_FMT = "%s requestJson: %s";
	private static final String MSG_RESPONSE_JSON_FMT = "%s responseJson: %s";

	/********** Initialization Methods **********/

	@PostConstruct
	public void init() {
		CustomLogger.enter(this.getClass());

		initDeviceReputationProfiler();
	}

	/**
	 * Determine if the device profiling is enabled and ip address is successfully
	 * for obtained for customer's device. If so, profilingSessionId and
	 * profilingOrgId are set.
	 * 
	 * @return
	 */
	public void initDeviceReputationProfiler() {
		CustomLogger.enter(this.getClass());

		if (isInitialized()) {
			return;
		}

		setInitialized(true);
		initServices();
		loadIpsProperties();

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
				.getRequest();
		boolean hasIpAddress = false;

		try {
			setCdCustomerIpAddress(this.getClientIpAddress(request));
			hasIpAddress = true;
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Error occurred in getting host address.", e);
		}

		if (hasIpAddress) {
			String sessionUserId = "OpSantaUser";
			String profilingSessionId = deviceReputationService.getProfilingSessionId(null);
			String orgId = deviceReputationService.retrieveOrgId(sessionUserId);
			setCdProfilingSessionId(profilingSessionId);
			setCdProfilingOrgId(orgId);
		}

		hideMessages();
	}

	/**
	 * Initialize the DeviceReputationService handler.
	 * 
	 * @param
	 * @return void
	 */
	public void initServices() {
		CustomLogger.enter(this.getClass());

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			setDeviceReputationService(webAppContext.getBean(DeviceReputationService.class));
			setAdminService(webAppContext.getBean(AdminService.class));
			setCommonRestService(webAppContext.getBean(CommonRestService.class));
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve necessary servies.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/********** Form Submission Methods **********/

	/**
	 * Generate CheckDevice request Json to be used as input in testing with Postman
	 * or SoapUI.
	 * 
	 * @param
	 * @return void
	 */
	public void generateCheckDeviceRequest() {
		CustomLogger.enter(this.getClass());

		HttpServletRequest httpRequest = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
				.getRequest();
		setCdCustomerIpAddress(getClientIpAddress(httpRequest));
		setCdWebSessionId(httpRequest.getSession().getId());

		cdRequestHashMap = new LinkedHashMap<>();

		cdRequestHashMap.put(MAP_KEY_SPONSOR_ID, SPONSOR_ID_OPERATION_SANTA);
		cdRequestHashMap.put(MAP_KEY_CUSTOMER_UNIQUE_ID, cdSponsorUserId);
		cdRequestHashMap.put(MAP_KEY_FIRST_NAME, cdFirstName);
		cdRequestHashMap.put(MAP_KEY_LAST_NAME, cdLastName);
		cdRequestHashMap.put(MAP_KEY_EMAIL_ADDRESS, cdEmailAddress);
		cdRequestHashMap.put(MAP_KEY_STREET_ADDRESS1, cdStreetAddress);
		cdRequestHashMap.put(MAP_KEY_CITY, cdCity);
		cdRequestHashMap.put(MAP_KEY_STATE, cdState);
		cdRequestHashMap.put(MAP_KEY_ZIP_CODE, cdZip5);
		cdRequestHashMap.put(MAP_KEY_MOBILE_PHONE, cdMobileNumber);
		cdRequestHashMap.put(MAP_KEY_PROFILING_SESSION_ID, cdProfilingSessionId);
		cdRequestHashMap.put(MAP_KEY_WEB_SESSION_ID, cdWebSessionId);
		cdRequestHashMap.put(MAP_KEY_TRUE_IP_ADDRESS, cdCustomerIpAddress);

		Gson g = new Gson();
		String rawJsonRequest = g.toJson(cdRequestHashMap);

		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();

		@SuppressWarnings("deprecation")
		JsonElement requestJsonEl = parser.parse(rawJsonRequest);
		String jsonRequestFmtd = gson.toJson(requestJsonEl);
		setCdJsonRequest(jsonRequestFmtd);

		populateOtherForms(WS_VERIFY_PHONE);

		hideMessages();
		setCheckDeviceSuccessMsg(String.format(MSG_SUCCESSFULLY_GENERATED_FMT, WS_CHECK_DEVICE));
		setShowCheckDeviceSuccessMsg(true);
		setShowCheckDeviceErrorMsg(false);
		setShowCheckDeviceRequestJsonPanel(true);
		setShowCheckDeviceSubmitBtn(true);
		setShowVerifyPhoneGenerateBtn(true);
		setShowCheckDeviceResponseJsonPanel(false);
	}

	/**
	 * Submit request to call CheckDevice remote proofing web service end-point.
	 * 
	 * @param
	 * @return void
	 */
	public void submitCheckDeviceRequest() {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		String requestJsonStr = g.toJson(cdRequestHashMap);

		CustomLogger.debug(this.getClass(), String.format(MSG_REQUEST_JSON_FMT, WS_CHECK_DEVICE, requestJsonStr));

		String responseJsonStr = "";

		if (adminService.isLocalServer()) {
			RemoteRequest remoteReq = g.fromJson(requestJsonStr, RemoteRequest.class);
			responseJsonStr = getLocalResponseJsonString(remoteReq, WS_CHECK_DEVICE);
		} else {
			Resource resource = getClientResource(checkDeviceResourceUrl);
			CustomLogger.debug(this.getClass(), "CheckDevice resourceUrl:" + checkDeviceResourceUrl);

			responseJsonStr = getResponseJsonString(resource, requestJsonStr, WS_CHECK_DEVICE);
		}

		CustomLogger.debug(this.getClass(), String.format(MSG_RESPONSE_JSON_FMT, WS_CHECK_DEVICE, responseJsonStr));

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		@SuppressWarnings("deprecation")
		JsonElement responseJsonEl = parser.parse(responseJsonStr);
		setCdJsonResponse(gson.toJson(responseJsonEl));

		populateOtherForms(WS_VERIFY_PHONE);

		hideMessages();
		setCheckDeviceSuccessMsg(String.format(MSG_SUCCESSFULLY_SUBMITTED_FMT, WS_CHECK_DEVICE));
		setShowCheckDeviceSuccessMsg(true);
		setShowCheckDeviceErrorMsg(false);
		setShowCheckDeviceResponseJsonPanel(true);
	}

	/**
	 * Generate VerifyPhone request Json to be used as input in testing with Postman
	 * or SoapUI.
	 * 
	 * @param
	 * @return void
	 */
	public void generateVerifyPhoneRequest() {
		CustomLogger.enter(this.getClass());

		vpRequestHashMap = new LinkedHashMap<>();

		vpRequestHashMap.put(MAP_KEY_SPONSOR_ID, SPONSOR_ID_OPERATION_SANTA);
		vpRequestHashMap.put(MAP_KEY_CUSTOMER_UNIQUE_ID, vpSponsorUserId);
		vpRequestHashMap.put(MAP_KEY_FIRST_NAME, vpFirstName);
		vpRequestHashMap.put(MAP_KEY_LAST_NAME, vpLastName);
		vpRequestHashMap.put(MAP_KEY_BIRTH_DATE, vpBirthDate);
		vpRequestHashMap.put(MAP_KEY_MOBILE_PHONE, vpMobileNumber);
		vpRequestHashMap.put(MAP_KEY_STREET_ADDRESS1, vpStreetAddress);
		vpRequestHashMap.put(MAP_KEY_CITY, vpCity);
		vpRequestHashMap.put(MAP_KEY_STATE, vpState);
		vpRequestHashMap.put(MAP_KEY_ZIP_CODE, vpZip5);

		Gson g = new Gson();
		String rawJsonRequest = g.toJson(vpRequestHashMap);

		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();

		@SuppressWarnings("deprecation")
		JsonElement requestJsonEl = parser.parse(rawJsonRequest);
		String jsonRequestFmtd = gson.toJson(requestJsonEl);
		setVpJsonRequest(jsonRequestFmtd);

		setRpBirthDate(vpBirthDate);

		populateOtherForms(WS_CONFIRM_PASSCODE);
		populateOtherForms(WS_REQUEST_PASSCODE);
		populateOtherForms(WS_RESEND_LINK);
		populateOtherForms(WS_VALIDATE_LINK);

		hideMessages();
		setVerifyPhoneSuccessMsg(String.format(MSG_SUCCESSFULLY_GENERATED_FMT, WS_VERIFY_PHONE));
		setShowVerifyPhoneSuccessMsg(true);
		setShowVerifyPhoneErrorMsg(false);
		setShowVerifyPhoneRequestJsonPanel(true);
		setShowVerifyPhoneSubmitBtn(true);
		setShowConfirmPasscodeGenerateBtn(true);
		setShowRequestPasscodeGenerateBtn(true);
		setShowResendSmfaLinkGenerateBtn(true);
		setShowValidateSmfaLinkGenerateBtn(true);
		setShowVerifyPhoneResponseJsonPanel(false);
	}

	/**
	 * Submit request to call VerifyPhone remote proofing web service end-point.
	 * 
	 * @param
	 * @return void
	 */
	public void submitVerifyPhoneRequest() {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		String requestJsonStr = g.toJson(vpRequestHashMap);

		CustomLogger.debug(this.getClass(), String.format(MSG_REQUEST_JSON_FMT, WS_VERIFY_PHONE, requestJsonStr));

		String responseJsonStr = "";

		if (adminService.isLocalServer()) {
			RemoteRequest remoteReq = g.fromJson(requestJsonStr, RemoteRequest.class);
			responseJsonStr = getLocalResponseJsonString(remoteReq, WS_VERIFY_PHONE);
		} else {
			Resource resource = getClientResource(verifyPhoneResourceUrl);
			CustomLogger.debug(this.getClass(), "VerifyPhone resourceUrl:" + verifyPhoneResourceUrl);

			responseJsonStr = getResponseJsonString(resource, requestJsonStr, WS_VERIFY_PHONE);
		}

		CustomLogger.debug(this.getClass(), String.format(MSG_RESPONSE_JSON_FMT, WS_VERIFY_PHONE, responseJsonStr));

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		@SuppressWarnings("deprecation")
		JsonElement responseJsonEl = parser.parse(responseJsonStr);
		setVpJsonResponse(gson.toJson(responseJsonEl));

		setRpBirthDate(vpBirthDate);

		populateOtherForms(WS_CONFIRM_PASSCODE);
		populateOtherForms(WS_REQUEST_PASSCODE);

		hideMessages();
		setVerifyPhoneSuccessMsg(String.format(MSG_SUCCESSFULLY_SUBMITTED_FMT, WS_VERIFY_PHONE));
		setShowVerifyPhoneSuccessMsg(true);
		setShowVerifyPhoneErrorMsg(false);
		setShowVerifyPhoneResponseJsonPanel(true);
	}

	/**
	 * Generate ConfirmPasscode request Json to be used as input in testing with
	 * Postman or SoapUI.
	 * 
	 * @param
	 * @return void
	 */
	public void generateConfirmPasscodeRequest() {
		CustomLogger.enter(this.getClass());

		cpRequestHashMap = new LinkedHashMap<>();

		cpRequestHashMap.put(MAP_KEY_SPONSOR_ID, SPONSOR_ID_OPERATION_SANTA);
		cpRequestHashMap.put(MAP_KEY_CUSTOMER_UNIQUE_ID, cpSponsorUserId);
		cpRequestHashMap.put(MAP_KEY_PASSCODE, cpPasscode);

		Gson g = new Gson();
		String rawJsonRequest = g.toJson(cpRequestHashMap);

		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();

		@SuppressWarnings("deprecation")
		JsonElement requestJsonEl = parser.parse(rawJsonRequest);
		String jsonRequestFmtd = gson.toJson(requestJsonEl);
		setCpJsonRequest(jsonRequestFmtd);

		populateOtherForms(WS_REQUEST_PASSCODE);

		hideMessages();
		setConfirmPasscodeSuccessMsg(String.format(MSG_SUCCESSFULLY_GENERATED_FMT, WS_CONFIRM_PASSCODE));
		setShowConfirmPasscodeSuccessMsg(true);
		setShowConfirmPasscodeErrorMsg(false);
		setShowConfirmPasscodeRequestJsonPanel(true);
		setShowConfirmPasscodeSubmitBtn(true);
		setShowConfirmPasscodeResponseJsonPanel(false);
	}

	/**
	 * Submit request to call ConfirmPasscode remote proofing web service end-point.
	 * 
	 * @param
	 * @return void
	 */
	public void submitConfirmPasscodeRequest() {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		String requestJsonStr = g.toJson(cpRequestHashMap);

		CustomLogger.debug(this.getClass(), String.format(MSG_REQUEST_JSON_FMT, WS_CONFIRM_PASSCODE, requestJsonStr));

		String responseJsonStr = "";

		if (adminService.isLocalServer()) {
			RemoteRequest remoteReq = g.fromJson(requestJsonStr, RemoteRequest.class);
			responseJsonStr = getLocalResponseJsonString(remoteReq, WS_CONFIRM_PASSCODE);
		} else {
			Resource resource = getClientResource(confirmPasscodeResourceUrl);
			CustomLogger.debug(this.getClass(), "ConfirmPasscode resourceUrl:" + confirmPasscodeResourceUrl);

			responseJsonStr = getResponseJsonString(resource, requestJsonStr, WS_CONFIRM_PASSCODE);
		}

		CustomLogger.debug(this.getClass(), String.format(MSG_RESPONSE_JSON_FMT, WS_CONFIRM_PASSCODE, responseJsonStr));

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		@SuppressWarnings("deprecation")
		JsonElement responseJsonEl = parser.parse(responseJsonStr);
		setCpJsonResponse(gson.toJson(responseJsonEl));

		populateOtherForms(WS_REQUEST_PASSCODE);

		hideMessages();
		setConfirmPasscodeSuccessMsg(String.format(MSG_SUCCESSFULLY_SUBMITTED_FMT, WS_CONFIRM_PASSCODE));
		setShowConfirmPasscodeSuccessMsg(true);
		setShowConfirmPasscodeErrorMsg(false);
		setShowConfirmPasscodeResponseJsonPanel(true);
	}

	/**
	 * Generate RequestPasscode request Json to be used as input in testing with
	 * Postman or SoapUI.
	 * 
	 * @param
	 * @return void
	 */
	public void generateRequestPasscodeRequest() {
		CustomLogger.enter(this.getClass());

		rpRequestHashMap = new LinkedHashMap<>();

		rpRequestHashMap.put(MAP_KEY_SPONSOR_ID, SPONSOR_ID_OPERATION_SANTA);
		rpRequestHashMap.put(MAP_KEY_CUSTOMER_UNIQUE_ID, rpSponsorUserId);
		rpRequestHashMap.put(MAP_KEY_FIRST_NAME, rpFirstName);
		rpRequestHashMap.put(MAP_KEY_LAST_NAME, rpLastName);
		rpRequestHashMap.put(MAP_KEY_BIRTH_DATE, rpBirthDate);
		rpRequestHashMap.put(MAP_KEY_STREET_ADDRESS1, rpStreetAddress);
		rpRequestHashMap.put(MAP_KEY_CITY, rpCity);
		rpRequestHashMap.put(MAP_KEY_STATE, rpState);
		rpRequestHashMap.put(MAP_KEY_ZIP_CODE, rpZip5);

		Gson g = new Gson();
		String rawJsonRequest = g.toJson(rpRequestHashMap);

		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();

		@SuppressWarnings("deprecation")
		JsonElement requestJsonEl = parser.parse(rawJsonRequest);
		String jsonRequestFmtd = gson.toJson(requestJsonEl);
		setRpJsonRequest(jsonRequestFmtd);

		hideMessages();
		setRequestPasscodeSuccessMsg(String.format(MSG_SUCCESSFULLY_GENERATED_FMT, WS_REQUEST_PASSCODE));
		setShowRequestPasscodeSuccessMsg(true);
		setShowRequestPasscodeErrorMsg(false);
		setShowRequestPasscodeRequestJsonPanel(true);
		setShowRequestPasscodeSubmitBtn(true);
		setShowRequestPasscodeResponseJsonPanel(false);
	}

	/**
	 * Submit request to call RequestPasscode remote proofing web service end-point.
	 * 
	 * @param
	 * @return void
	 */
	public void submitRequestPasscodeRequest() {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		String requestJsonStr = g.toJson(rpRequestHashMap);

		CustomLogger.debug(this.getClass(), String.format(MSG_REQUEST_JSON_FMT, WS_REQUEST_PASSCODE, requestJsonStr));

		String responseJsonStr = "";

		if (adminService.isLocalServer()) {
			RemoteRequest remoteReq = g.fromJson(requestJsonStr, RemoteRequest.class);
			responseJsonStr = getLocalResponseJsonString(remoteReq, WS_REQUEST_PASSCODE);
		} else {
			Resource resource = getClientResource(requestPasscodeResourceUrl);
			CustomLogger.debug(this.getClass(), "RequestPasscode resourceUrl:" + requestPasscodeResourceUrl);

			responseJsonStr = getResponseJsonString(resource, requestJsonStr, WS_REQUEST_PASSCODE);
		}

		CustomLogger.debug(this.getClass(), String.format(MSG_RESPONSE_JSON_FMT, WS_REQUEST_PASSCODE, responseJsonStr));

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		@SuppressWarnings("deprecation")
		JsonElement responseJsonEl = parser.parse(responseJsonStr);
		setRpJsonResponse(gson.toJson(responseJsonEl));

		hideMessages();
		setRequestPasscodeSuccessMsg(String.format(MSG_SUCCESSFULLY_SUBMITTED_FMT, WS_REQUEST_PASSCODE));
		setShowRequestPasscodeSuccessMsg(true);
		setShowRequestPasscodeErrorMsg(false);
		setShowRequestPasscodeResponseJsonPanel(true);
	}

	/**
	 * Generate ResendSmfaLink request Json to be used as input in testing with
	 * Postman or SoapUI.
	 * 
	 * @param
	 * @return void
	 */
	public void generateResendSmfaLinkRequest() {
		CustomLogger.enter(this.getClass());

		rlRequestHashMap = new LinkedHashMap<>();
		rlRequestHashMap.put(MAP_KEY_SPONSOR_ID, SPONSOR_ID_OPERATION_SANTA);
		rlRequestHashMap.put(MAP_KEY_CUSTOMER_UNIQUE_ID, rlSponsorUserId);
		rlRequestHashMap.put(MAP_KEY_FIRST_NAME, rlFirstName);
		rlRequestHashMap.put(MAP_KEY_LAST_NAME, rlLastName);
		rlRequestHashMap.put(MAP_KEY_BIRTH_DATE, rlBirthDate);
		rlRequestHashMap.put(MAP_KEY_MOBILE_PHONE, rlMobileNumber);
		rlRequestHashMap.put(MAP_KEY_STREET_ADDRESS1, rlStreetAddress);
		rlRequestHashMap.put(MAP_KEY_CITY, rlCity);
		rlRequestHashMap.put(MAP_KEY_STATE, rlState);
		rlRequestHashMap.put(MAP_KEY_ZIP_CODE, rlZip5);

		Gson g = new Gson();
		String rawJsonRequest = g.toJson(rlRequestHashMap);

		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();

		@SuppressWarnings("deprecation")
		JsonElement requestJsonEl = parser.parse(rawJsonRequest);
		String jsonRequestFmtd = gson.toJson(requestJsonEl);
		setRlJsonRequest(jsonRequestFmtd);

		hideMessages();
		setResendSmfaLinkSuccessMsg(String.format(MSG_SUCCESSFULLY_GENERATED_FMT, WS_RESEND_LINK));
		setShowResendSmfaLinkSuccessMsg(true);
		setShowResendSmfaLinkErrorMsg(false);
		setShowResendSmfaLinkRequestJsonPanel(true);
		setShowResendSmfaLinkSubmitBtn(true);
		setShowResendSmfaLinkResponseJsonPanel(false);
	}

	/**
	 * Submit request to call ResendSmfaLink remote proofing web service end-point.
	 * 
	 * @param
	 * @return void
	 */
	public void submitResendSmfaLinkRequest() {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		String requestJsonStr = g.toJson(rlRequestHashMap);

		CustomLogger.debug(this.getClass(), String.format(MSG_REQUEST_JSON_FMT, WS_RESEND_LINK, requestJsonStr));

		String responseJsonStr = "";

		if (adminService.isLocalServer()) {
			RemoteRequest remoteReq = g.fromJson(requestJsonStr, RemoteRequest.class);
			responseJsonStr = getLocalResponseJsonString(remoteReq, WS_RESEND_LINK);
		} else {
			Resource resource = getClientResource(resendSmfaLinkResourceUrl);
			CustomLogger.debug(this.getClass(), "ResendSmfaLink resourceUrl:" + resendSmfaLinkResourceUrl);

			responseJsonStr = getResponseJsonString(resource, requestJsonStr, WS_RESEND_LINK);
		}

		CustomLogger.debug(this.getClass(), String.format(MSG_RESPONSE_JSON_FMT, WS_RESEND_LINK, responseJsonStr));

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		@SuppressWarnings("deprecation")
		JsonElement responseJsonEl = parser.parse(responseJsonStr);
		setRlJsonResponse(gson.toJson(responseJsonEl));

		hideMessages();
		setResendSmfaLinkSuccessMsg(String.format(MSG_SUCCESSFULLY_SUBMITTED_FMT, WS_RESEND_LINK));
		setShowResendSmfaLinkSuccessMsg(true);
		setShowResendSmfaLinkErrorMsg(false);
		setShowResendSmfaLinkResponseJsonPanel(true);
	}

	/**
	 * Generate ValidateSmfaLink request Json to be used as input in testing with
	 * Postman or SoapUI.
	 * 
	 * @param
	 * @return void
	 */
	public void generateValidateSmfaLinkRequest() {
		CustomLogger.enter(this.getClass());

		vlRequestHashMap = new LinkedHashMap<>();
		vlRequestHashMap.put(MAP_KEY_SPONSOR_ID, SPONSOR_ID_OPERATION_SANTA);
		vlRequestHashMap.put(MAP_KEY_CUSTOMER_UNIQUE_ID, vlSponsorUserId);
		vlRequestHashMap.put(MAP_KEY_MOBILE_PHONE, vlMobileNumber);

		Gson g = new Gson();
		String rawJsonRequest = g.toJson(vlRequestHashMap);

		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();

		@SuppressWarnings("deprecation")
		JsonElement requestJsonEl = parser.parse(rawJsonRequest);
		String jsonRequestFmtd = gson.toJson(requestJsonEl);
		setVlJsonRequest(jsonRequestFmtd);

		hideMessages();
		setValidateSmfaLinkSuccessMsg(String.format(MSG_SUCCESSFULLY_GENERATED_FMT, WS_VALIDATE_LINK));
		setShowValidateSmfaLinkSuccessMsg(true);
		setShowValidateSmfaLinkErrorMsg(false);
		setShowValidateSmfaLinkRequestJsonPanel(true);
		setShowValidateSmfaLinkSubmitBtn(true);
		setShowValidateSmfaLinkResponseJsonPanel(false);
	}

	/**
	 * Submit request to call ValidateSmfaLink remote proofing web service
	 * end-point.
	 * 
	 * @param
	 * @return void
	 */
	public void submitValidateSmfaLinkRequest() {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		String requestJsonStr = g.toJson(vlRequestHashMap);

		CustomLogger.debug(this.getClass(), String.format(MSG_REQUEST_JSON_FMT, WS_VALIDATE_LINK, requestJsonStr));

		String responseJsonStr = "";

		if (adminService.isLocalServer()) {
			RemoteRequest remoteReq = g.fromJson(requestJsonStr, RemoteRequest.class);
			responseJsonStr = getLocalResponseJsonString(remoteReq, WS_VALIDATE_LINK);
		} else {
			Resource resource = getClientResource(validateSmfaLinkResourceUrl);
			CustomLogger.debug(this.getClass(), "ValidateSmfaLink resourceUrl:" + validateSmfaLinkResourceUrl);

			responseJsonStr = getResponseJsonString(resource, requestJsonStr, WS_VALIDATE_LINK);
		}

		CustomLogger.debug(this.getClass(), String.format(MSG_RESPONSE_JSON_FMT, WS_VALIDATE_LINK, responseJsonStr));

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		@SuppressWarnings("deprecation")
		JsonElement responseJsonEl = parser.parse(responseJsonStr);
		setVlJsonResponse(gson.toJson(responseJsonEl));

		hideMessages();
		setValidateSmfaLinkSuccessMsg(String.format(MSG_SUCCESSFULLY_SUBMITTED_FMT, WS_VALIDATE_LINK));
		setShowValidateSmfaLinkSuccessMsg(true);
		setShowValidateSmfaLinkErrorMsg(false);
		setShowValidateSmfaLinkResponseJsonPanel(true);
	}

	/**
	 * Generate Customer ID using hash code for FirstName, LastName, EmailAddress,
	 * MobileNumber and ProfilingSessionId. Remove leading zeroes and sign.
	 * 
	 * @param
	 * @return void
	 */
	public void generateCustomerId() {
		CustomLogger.enter(this.getClass());

		int custIdHash = hashCode(cdFirstName, cdLastName, cdEmailAddress, cdMobileNumber, cdProfilingSessionId);
		String custIdHashStr = String.valueOf(custIdHash);
		cdSponsorUserId = custIdHashStr.replace("-", "");
		cdSponsorUserId = cdSponsorUserId.replaceFirst("^0+(?!$)", "");
	}

	/********** Common Private Methods **********/

	/**
	 * Pre-populate other forms when CheckDevice form generates the request Json.
	 * 
	 * @param
	 * @return String
	 */
	private void populateOtherForms(String method) {
		CustomLogger.enter(this.getClass());

		switch (method) {
		case WS_VERIFY_PHONE:
			setVpSponsorUserId(cdSponsorUserId);
			setVpSponsorId(String.valueOf(SPONSOR_ID_OPERATION_SANTA));
			setVpFirstName(cdFirstName);
			setVpLastName(cdLastName);
			setVpMobileNumber(cdMobileNumber);
			setVpStreetAddress(cdStreetAddress);
			setVpCity(cdCity);
			setVpState(cdState);
			setVpZip5(cdZip5);
			break;
		case WS_CONFIRM_PASSCODE:
			setCpSponsorUserId(cdSponsorUserId);
			break;
		case WS_REQUEST_PASSCODE:
			setRpSponsorUserId(cdSponsorUserId);
			setRpFirstName(cdFirstName);
			setRpLastName(cdLastName);
			setRpStreetAddress(cdStreetAddress);
			setRpCity(cdCity);
			setRpState(cdState);
			setRpZip5(cdZip5);
			setRpSponsorUserId(cdSponsorUserId);
			break;
		case WS_VALIDATE_LINK:
			setVlSponsorUserId(cdSponsorUserId);
			setVlMobileNumber(cdMobileNumber);
			break;
		case WS_RESEND_LINK:
			setRlSponsorUserId(cdSponsorUserId);
			setRlMobileNumber(cdMobileNumber);
			setRlFirstName(cdFirstName);
			setRlLastName(cdLastName);
			setRlStreetAddress(cdStreetAddress);
			setRlCity(cdCity);
			setRlState(cdState);
			setRlZip5(cdZip5);
			break;
		default:
		}
	}

	/**
	 * Get the web service response string when endpoint is called.
	 * 
	 * @param
	 * @return String
	 */
	private String getResponseJsonString(Resource resource, String requestJsonStr, String webServiceName) {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		JSONObject responseJsonObj = new JSONObject();
		String responseJsonStr = "";
		String responseMessage = "";
		boolean hasResponse = false;

		try {
			responseJsonObj = resource.contentType(MediaType.APPLICATION_JSON).post(JSONObject.class, requestJsonStr);
			responseJsonStr = g.toJson(responseJsonObj);
			hasResponse = true;
		} catch (ClientWebException e) {
			Object entity = e.getResponse().getEntity(JSONObject.class);
			responseJsonStr = g.toJson(entity);
			hasResponse = true;
		} catch (ClientRuntimeException e) {
			CustomLogger.error(this.getClass(),
					"ClientRuntimeException occurs in getting Resource response from the web service:" + e.getMessage(),
					e);
			responseMessage = "ClientRuntimeException occurs in getting resource response for web service:"
					.concat(webServiceName);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(),
					"Exception occurs in getting Resource response from the web service:" + e.getMessage(), e);
			responseMessage = "Exception occurs in getting resource response for web service:".concat(webServiceName);
		}

		if (!hasResponse) {
			JSONObject defaultRespObj = new JSONObject();
			defaultRespObj.put("responseMessage", responseMessage);
			responseJsonStr = g.toJson(defaultRespObj);
			CustomLogger.debug(this.getClass(), "Default Response JSON::" + responseJsonStr);
		}

		return responseJsonStr;
	}

	/**
	 * Get the response string when the service is directly called for local
	 * environment instead of calling the endpoint.
	 * 
	 * @param
	 * @return String
	 */
	private String getLocalResponseJsonString(RemoteRequest remoteReq, String webServiceName) {
		CustomLogger.enter(this.getClass());

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
        if (webAppContext != null) {
		RemoteProofingService remoteProofingService = webAppContext
				.getBean(RemoteProofingService.class);
		Response response = null;
		String origin = "Operation Santa";

		switch (webServiceName) {
		case WS_CHECK_DEVICE:
			response = remoteProofingService.checkDevice(remoteReq, origin);
			break;
		case WS_VERIFY_PHONE:
			try {
			response = remoteProofingService.verifyPhone(remoteReq, origin);
			} catch (Throwable e) {
				CustomLogger.error(this.getClass(), "Error verifying phone "+e);
			}
			break;
		case WS_CONFIRM_PASSCODE:
			response = remoteProofingService.confirmPasscode(remoteReq, origin);
			break;
		case WS_REQUEST_PASSCODE:
			try {
			response = remoteProofingService.requestPasscode(remoteReq, origin);
			} catch (Throwable e) {
				CustomLogger.error(this.getClass(), "Error requesting passcode "+e);
			}
			break;
		case WS_RESEND_LINK:
			response = remoteProofingService.resendLink(remoteReq, origin);
			break;
		case WS_VALIDATE_LINK:
			response = remoteProofingService.validateLink(remoteReq, origin);
			break;
		default:
			response = remoteProofingService.validateLink(remoteReq, origin);
		}

		Gson g = new Gson();
	 	if(response!=null) {
		return g.toJson(response.getEntity());
	 	}
	 	
        }
        return null;
	}
    

	/**
	 * Evaluate the hash code for Customer ID generation.
	 * 
	 * @param
	 * @return String
	 */
	private int hashCode(String firstName, String lastName, String emailAddress, String cdMobileNumber,
			String cdProfilingSessionId) {
		CustomLogger.enter(this.getClass());

		int hash = 7;
		hash = 31 * hash + (firstName == null ? 0 : firstName.hashCode());
		hash = 31 * hash + (lastName == null ? 0 : lastName.hashCode());
		hash = 31 * hash + (emailAddress == null ? 0 : emailAddress.hashCode());
		hash = 31 * hash + (cdMobileNumber == null ? 0 : cdMobileNumber.hashCode());
		hash = 31 * hash + (cdProfilingSessionId == null ? 0 : cdProfilingSessionId.hashCode());

		String hashStr = String.valueOf(hash);
		if (hashStr.length() > 10) {
			hashStr = hashStr.substring(0, 10);
			hash = Integer.valueOf(hashStr);
		}
		return hash;
	}

	/**
	 * Obtain the client resource for the input uri.
	 * 
	 * @param
	 * @return String
	 */
	private Resource getClientResource(String inputUrl) {
		CustomLogger.enter(this.getClass());

		ClientConfig config = new ClientConfig();
		config.proxyHost(propHost);
		config.proxyPort(Integer.parseInt(propPort));

		RestClient client = new RestClient(config);

		return client.resource(inputUrl);
	}

	/**
	 * Load IPS Properties needed to retrieve Host, Port and Resource URL for a
	 * particular environment.
	 * 
	 * @param
	 * @return void
	 */
	private void loadIpsProperties() {
		CustomLogger.enter(this.getClass());

		try {
			Properties prop = getProperties();
			String environment = Utils.getEnvironment();

			List<String> propNames = new ArrayList<>();
			propNames.add(PROXY_HOST_PROP_NAME);
			propNames.add(PROXY_PORT_PROP_NAME);
			propNames.add(URL_OP_SANTA_CHECK_DEVICE_WS);
			propNames.add(URL_OP_SANTA_VERIFY_PHONE_WS);
			propNames.add(URL_OP_SANTA_CONFIRM_PASSCODE_WS);
			propNames.add(URL_OP_SANTA_REQUEST_PASSCODE_WS);
			propNames.add(URL_OP_SANTA_RESEND_LINK_WS);
			propNames.add(URL_OP_SANTA_VALIDATE_LINK_WS);

			List<String> propValues = new ArrayList<>();

			for (String item : propNames) {
				String propName = environment.concat(item);
				String propValue = prop.getProperty(propName);

				if (propValue == null) {
					CustomLogger.error(this.getClass(), String.format(ERROR_MSG_READING_PROP_FMT, propName));
				}

				propValues.add(propValue);
			}

			if (!propValues.isEmpty()) {
				propHost = propValues.get(0);
				propPort = propValues.get(1);
				checkDeviceResourceUrl = propValues.get(2);
				verifyPhoneResourceUrl = propValues.get(3);
				confirmPasscodeResourceUrl = propValues.get(4);
				requestPasscodeResourceUrl = propValues.get(5);
				resendSmfaLinkResourceUrl = propValues.get(6);
				validateSmfaLinkResourceUrl = propValues.get(7);
			}
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(), "Could not load ips.properties", ex);
		}
	}

	/**
	 * Return Properties after loading it with Host, Port and Resource URL Property
	 * data
	 * 
	 * @param
	 * @return Properties
	 */
	private Properties getProperties() {
		CustomLogger.enter(this.getClass());

		InputStream input = null;
		Properties prop = new Properties();

		try {
			input = RemoteRestIdentityVerificationBean.class.getClassLoader().getResourceAsStream(RESOURCE_STREAM_PATH);
			// load a properties file
			prop.load(input);
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(), "Could not load ips.properties", ex);
		}

		return prop;
	}

	/**
	 * Hide the messages for initialization.
	 * 
	 * @param
	 * @return String
	 */
	private void hideMessages() {
		CustomLogger.enter(this.getClass());

		setShowCheckDeviceInstMsg(false);
		setShowCheckDeviceErrorMsg(false);
		setShowCheckDeviceSuccessMsg(false);

		setShowVerifyPhoneInstMsg(false);
		setShowVerifyPhoneErrorMsg(false);
		setShowVerifyPhoneSuccessMsg(false);

		setShowConfirmPasscodeInstMsg(false);
		setShowConfirmPasscodeErrorMsg(false);
		setShowConfirmPasscodeSuccessMsg(false);

		setShowRequestPasscodeInstMsg(false);
		setShowRequestPasscodeErrorMsg(false);
		setShowRequestPasscodeSuccessMsg(false);
	}

	/**
	 * Obtain the client IP Address from HttpServletRequest header.
	 * 
	 * @param
	 * @return String
	 */
	@Override
	public String getClientIpAddress(HttpServletRequest request) {
		CustomLogger.enter(this.getClass());

		return commonRestService.getClientIpAddress(request);
	}

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public DeviceReputationService getDeviceReputationService() {
		return deviceReputationService;
	}

	public void setDeviceReputationService(DeviceReputationService deviceReputationService) {
		this.deviceReputationService = deviceReputationService;
	}

	public CommonRestService getCommonRestService() {
		return commonRestService;
	}

	public void setCommonRestService(CommonRestService commonRestService) {
		this.commonRestService = commonRestService;
	}

	public AdminService getAdminService() {
		return adminService;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	public String getCdProfilingOrgId() {
		return cdProfilingOrgId;
	}

	public void setCdProfilingOrgId(String cdProfilingOrgId) {
		this.cdProfilingOrgId = cdProfilingOrgId;
	}

	public String getCdProfilingSessionId() {
		return cdProfilingSessionId;
	}

	public void setCdProfilingSessionId(String cdProfilingSessionId) {
		this.cdProfilingSessionId = cdProfilingSessionId;
	}

	public String getCdCustomerIpAddress() {
		return cdCustomerIpAddress;
	}

	public void setCdCustomerIpAddress(String cdCustomerIpAddress) {
		this.cdCustomerIpAddress = cdCustomerIpAddress;
	}

	public String getCdWebSessionId() {
		return cdWebSessionId;
	}

	public void setCdWebSessionId(String cdWebSessionId) {
		this.cdWebSessionId = cdWebSessionId;
	}

	public String getCdSponsorId() {
		return cdSponsorId;
	}

	public void setCdSponsorId(String cdSponsorId) {
		this.cdSponsorId = cdSponsorId;
	}

	public String getCdSponsorUserId() {
		return cdSponsorUserId;
	}

	public void setCdSponsorUserId(String cdSponsorUserId) {
		this.cdSponsorUserId = cdSponsorUserId;
	}

	public String getCdFirstName() {
		return cdFirstName;
	}

	public void setCdFirstName(String cdFirstName) {
		this.cdFirstName = cdFirstName;
	}

	public String getCdLastName() {
		return cdLastName;
	}

	public void setCdLastName(String cdLastName) {
		this.cdLastName = cdLastName;
	}

	public String getCdEmailAddress() {
		return cdEmailAddress;
	}

	public void setCdEmailAddress(String cdEmailAddress) {
		this.cdEmailAddress = cdEmailAddress;
	}

	public String getCdStreetAddress() {
		return cdStreetAddress;
	}

	public void setCdStreetAddress(String cdStreetAddress) {
		this.cdStreetAddress = cdStreetAddress;
	}

	public String getCdCity() {
		return cdCity;
	}

	public void setCdCity(String cdCity) {
		this.cdCity = cdCity;
	}

	public String getCdState() {
		return cdState;
	}

	public void setCdState(String cdState) {
		this.cdState = cdState;
	}

	public String getCdZip5() {
		return cdZip5;
	}

	public void setCdZip5(String cdZip5) {
		this.cdZip5 = cdZip5;
	}

	public String getCdMobileNumber() {
		return cdMobileNumber;
	}

	public void setCdMobileNumber(String cdMobileNumber) {
		this.cdMobileNumber = cdMobileNumber;
	}

	public String getCdJsonRequest() {
		return cdJsonRequest;
	}

	public void setCdJsonRequest(String cdJsonRequest) {
		this.cdJsonRequest = cdJsonRequest;
	}

	public String getCdJsonResponse() {
		return cdJsonResponse;
	}

	public void setCdJsonResponse(String cdJsonResponse) {
		this.cdJsonResponse = cdJsonResponse;
	}

	public String getVpSponsorId() {
		return vpSponsorId;
	}

	public void setVpSponsorId(String vpSponsorId) {
		this.vpSponsorId = vpSponsorId;
	}

	public String getVpSponsorUserId() {
		return vpSponsorUserId;
	}

	public void setVpSponsorUserId(String vpSponsorUserId) {
		this.vpSponsorUserId = vpSponsorUserId;
	}

	public String getVpFirstName() {
		return vpFirstName;
	}

	public void setVpFirstName(String vpFirstName) {
		this.vpFirstName = vpFirstName;
	}

	public String getVpLastName() {
		return vpLastName;
	}

	public void setVpLastName(String vpLastName) {
		this.vpLastName = vpLastName;
	}

	public String getVpBirthDate() {
		return vpBirthDate;
	}

	public void setVpBirthDate(String vpBirthDate) {
		this.vpBirthDate = vpBirthDate;
	}

	public String getVpStreetAddress() {
		return vpStreetAddress;
	}

	public void setVpStreetAddress(String vpStreetAddress) {
		this.vpStreetAddress = vpStreetAddress;
	}

	public String getVpCity() {
		return vpCity;
	}

	public void setVpCity(String vpCity) {
		this.vpCity = vpCity;
	}

	public String getVpState() {
		return vpState;
	}

	public void setVpState(String vpState) {
		this.vpState = vpState;
	}

	public String getVpZip5() {
		return vpZip5;
	}

	public void setVpZip5(String vpZip5) {
		this.vpZip5 = vpZip5;
	}

	public String getVpMobileNumber() {
		return vpMobileNumber;
	}

	public void setVpMobileNumber(String vpMobileNumber) {
		this.vpMobileNumber = vpMobileNumber;
	}

	public String getVpJsonRequest() {
		return vpJsonRequest;
	}

	public void setVpJsonRequest(String vpJsonRequest) {
		this.vpJsonRequest = vpJsonRequest;
	}

	public String getVpJsonResponse() {
		return vpJsonResponse;
	}

	public void setVpJsonResponse(String vpJsonResponse) {
		this.vpJsonResponse = vpJsonResponse;
	}

	public String getCpSponsorId() {
		return cpSponsorId;
	}

	public void setCpSponsorId(String cpSponsorId) {
		this.cpSponsorId = cpSponsorId;
	}

	public String getCpSponsorUserId() {
		return cpSponsorUserId;
	}

	public void setCpSponsorUserId(String cpSponsorUserId) {
		this.cpSponsorUserId = cpSponsorUserId;
	}

	public String getCpPasscode() {
		return cpPasscode;
	}

	public void setCpPasscode(String cpPasscode) {
		this.cpPasscode = cpPasscode;
	}

	public String getCpJsonRequest() {
		return cpJsonRequest;
	}

	public void setCpJsonRequest(String cpJsonRequest) {
		this.cpJsonRequest = cpJsonRequest;
	}

	public String getCpJsonResponse() {
		return cpJsonResponse;
	}

	public void setCpJsonResponse(String cpJsonResponse) {
		this.cpJsonResponse = cpJsonResponse;
	}

	public String getRpSponsorId() {
		return rpSponsorId;
	}

	public void setRpSponsorId(String rpSponsorId) {
		this.rpSponsorId = rpSponsorId;
	}

	public String getRpSponsorUserId() {
		return rpSponsorUserId;
	}

	public void setRpSponsorUserId(String rpSponsorUserId) {
		this.rpSponsorUserId = rpSponsorUserId;
	}

	public String getRpFirstName() {
		return rpFirstName;
	}

	public void setRpFirstName(String rpFirstName) {
		this.rpFirstName = rpFirstName;
	}

	public String getRpLastName() {
		return rpLastName;
	}

	public void setRpLastName(String rpLastName) {
		this.rpLastName = rpLastName;
	}

	public String getRpBirthDate() {
		return rpBirthDate;
	}

	public void setRpBirthDate(String rpBirthDate) {
		this.rpBirthDate = rpBirthDate;
	}

	public String getRpStreetAddress() {
		return rpStreetAddress;
	}

	public void setRpStreetAddress(String rpStreetAddress) {
		this.rpStreetAddress = rpStreetAddress;
	}

	public String getRpCity() {
		return rpCity;
	}

	public void setRpCity(String rpCity) {
		this.rpCity = rpCity;
	}

	public String getRpState() {
		return rpState;
	}

	public void setRpState(String rpState) {
		this.rpState = rpState;
	}

	public String getRpZip5() {
		return rpZip5;
	}

	public void setRpZip5(String rpZip5) {
		this.rpZip5 = rpZip5;
	}

	public String getRpJsonRequest() {
		return rpJsonRequest;
	}

	public void setRpJsonRequest(String rpJsonRequest) {
		this.rpJsonRequest = rpJsonRequest;
	}

	public String getRpJsonResponse() {
		return rpJsonResponse;
	}

	public void setRpJsonResponse(String rpJsonResponse) {
		this.rpJsonResponse = rpJsonResponse;
	}

	public String getCheckDeviceInstMsg() {
		return checkDeviceInstMsg;
	}

	public void setCheckDeviceInstMsg(String checkDeviceInstMsg) {
		this.checkDeviceInstMsg = checkDeviceInstMsg;
	}

	public String getCheckDeviceErrorMsg() {
		return checkDeviceErrorMsg;
	}

	public void setCheckDeviceErrorMsg(String checkDeviceErrorMsg) {
		this.checkDeviceErrorMsg = checkDeviceErrorMsg;
	}

	public String getCheckDeviceSuccessMsg() {
		return checkDeviceSuccessMsg;
	}

	public void setCheckDeviceSuccessMsg(String checkDeviceSuccessMsg) {
		this.checkDeviceSuccessMsg = checkDeviceSuccessMsg;
	}

	public String getVerifyPhoneInstMsg() {
		return verifyPhoneInstMsg;
	}

	public void setVerifyPhoneInstMsg(String verifyPhoneInstMsg) {
		this.verifyPhoneInstMsg = verifyPhoneInstMsg;
	}

	public String getVerifyPhoneErrorMsg() {
		return verifyPhoneErrorMsg;
	}

	public void setVerifyPhoneErrorMsg(String verifyPhoneErrorMsg) {
		this.verifyPhoneErrorMsg = verifyPhoneErrorMsg;
	}

	public String getVerifyPhoneSuccessMsg() {
		return verifyPhoneSuccessMsg;
	}

	public void setVerifyPhoneSuccessMsg(String verifyPhoneSuccessMsg) {
		this.verifyPhoneSuccessMsg = verifyPhoneSuccessMsg;
	}

	public String getConfirmPasscodeInstMsg() {
		return confirmPasscodeInstMsg;
	}

	public void setConfirmPasscodeInstMsg(String confirmPasscodeInstMsg) {
		this.confirmPasscodeInstMsg = confirmPasscodeInstMsg;
	}

	public String getConfirmPasscodeErrorMsg() {
		return confirmPasscodeErrorMsg;
	}

	public void setConfirmPasscodeErrorMsg(String confirmPasscodeErrorMsg) {
		this.confirmPasscodeErrorMsg = confirmPasscodeErrorMsg;
	}

	public String getConfirmPasscodeSuccessMsg() {
		return confirmPasscodeSuccessMsg;
	}

	public void setConfirmPasscodeSuccessMsg(String confirmPasscodeSuccessMsg) {
		this.confirmPasscodeSuccessMsg = confirmPasscodeSuccessMsg;
	}

	public String getRequestPasscodeInstMsg() {
		return requestPasscodeInstMsg;
	}

	public void setRequestPasscodeInstMsg(String requestPasscodeInstMsg) {
		this.requestPasscodeInstMsg = requestPasscodeInstMsg;
	}

	public String getRequestPasscodeErrorMsg() {
		return requestPasscodeErrorMsg;
	}

	public void setRequestPasscodeErrorMsg(String requestPasscodeErrorMsg) {
		this.requestPasscodeErrorMsg = requestPasscodeErrorMsg;
	}

	public String getRequestPasscodeSuccessMsg() {
		return requestPasscodeSuccessMsg;
	}

	public void setRequestPasscodeSuccessMsg(String requestPasscodeSuccessMsg) {
		this.requestPasscodeSuccessMsg = requestPasscodeSuccessMsg;
	}

	public boolean isShowCheckDeviceInstMsg() {
		return showCheckDeviceInstMsg;
	}

	public void setShowCheckDeviceInstMsg(boolean showCheckDeviceInstMsg) {
		this.showCheckDeviceInstMsg = showCheckDeviceInstMsg;
	}

	public boolean isShowCheckDeviceErrorMsg() {
		return showCheckDeviceErrorMsg;
	}

	public void setShowCheckDeviceErrorMsg(boolean showCheckDeviceErrorMsg) {
		this.showCheckDeviceErrorMsg = showCheckDeviceErrorMsg;
	}

	public boolean isShowCheckDeviceSuccessMsg() {
		return showCheckDeviceSuccessMsg;
	}

	public void setShowCheckDeviceSuccessMsg(boolean showCheckDeviceSuccessMsg) {
		this.showCheckDeviceSuccessMsg = showCheckDeviceSuccessMsg;
	}

	public boolean isShowVerifyPhoneInstMsg() {
		return showVerifyPhoneInstMsg;
	}

	public void setShowVerifyPhoneInstMsg(boolean showVerifyPhoneInstMsg) {
		this.showVerifyPhoneInstMsg = showVerifyPhoneInstMsg;
	}

	public boolean isShowVerifyPhoneErrorMsg() {
		return showVerifyPhoneErrorMsg;
	}

	public void setShowVerifyPhoneErrorMsg(boolean showVerifyPhoneErrorMsg) {
		this.showVerifyPhoneErrorMsg = showVerifyPhoneErrorMsg;
	}

	public boolean isShowVerifyPhoneSuccessMsg() {
		return showVerifyPhoneSuccessMsg;
	}

	public void setShowVerifyPhoneSuccessMsg(boolean showVerifyPhoneSuccessMsg) {
		this.showVerifyPhoneSuccessMsg = showVerifyPhoneSuccessMsg;
	}

	public boolean isShowConfirmPasscodeInstMsg() {
		return showConfirmPasscodeInstMsg;
	}

	public void setShowConfirmPasscodeInstMsg(boolean showConfirmPasscodeInstMsg) {
		this.showConfirmPasscodeInstMsg = showConfirmPasscodeInstMsg;
	}

	public boolean isShowConfirmPasscodeErrorMsg() {
		return showConfirmPasscodeErrorMsg;
	}

	public void setShowConfirmPasscodeErrorMsg(boolean showConfirmPasscodeErrorMsg) {
		this.showConfirmPasscodeErrorMsg = showConfirmPasscodeErrorMsg;
	}

	public boolean isShowConfirmPasscodeSuccessMsg() {
		return showConfirmPasscodeSuccessMsg;
	}

	public void setShowConfirmPasscodeSuccessMsg(boolean showConfirmPasscodeSuccessMsg) {
		this.showConfirmPasscodeSuccessMsg = showConfirmPasscodeSuccessMsg;
	}

	public boolean isShowRequestPasscodeInstMsg() {
		return showRequestPasscodeInstMsg;
	}

	public void setShowRequestPasscodeInstMsg(boolean showRequestPasscodeInstMsg) {
		this.showRequestPasscodeInstMsg = showRequestPasscodeInstMsg;
	}

	public boolean isShowRequestPasscodeErrorMsg() {
		return showRequestPasscodeErrorMsg;
	}

	public void setShowRequestPasscodeErrorMsg(boolean showRequestPasscodeErrorMsg) {
		this.showRequestPasscodeErrorMsg = showRequestPasscodeErrorMsg;
	}

	public boolean isShowRequestPasscodeSuccessMsg() {
		return showRequestPasscodeSuccessMsg;
	}

	public void setShowRequestPasscodeSuccessMsg(boolean showRequestPasscodeSuccessMsg) {
		this.showRequestPasscodeSuccessMsg = showRequestPasscodeSuccessMsg;
	}

	public boolean isShowCheckDeviceRequestJsonPanel() {
		return showCheckDeviceRequestJsonPanel;
	}

	public void setShowCheckDeviceRequestJsonPanel(boolean showCheckDeviceRequestJsonPanel) {
		this.showCheckDeviceRequestJsonPanel = showCheckDeviceRequestJsonPanel;
	}

	public boolean isShowCheckDeviceResponseJsonPanel() {
		return showCheckDeviceResponseJsonPanel;
	}

	public void setShowCheckDeviceResponseJsonPanel(boolean showCheckDeviceResponseJsonPanel) {
		this.showCheckDeviceResponseJsonPanel = showCheckDeviceResponseJsonPanel;
	}

	public boolean isShowVerifyPhoneRequestJsonPanel() {
		return showVerifyPhoneRequestJsonPanel;
	}

	public void setShowVerifyPhoneRequestJsonPanel(boolean showVerifyPhoneRequestJsonPanel) {
		this.showVerifyPhoneRequestJsonPanel = showVerifyPhoneRequestJsonPanel;
	}

	public boolean isShowVerifyPhoneResponseJsonPanel() {
		return showVerifyPhoneResponseJsonPanel;
	}

	public void setShowVerifyPhoneResponseJsonPanel(boolean showVerifyPhoneResponseJsonPanel) {
		this.showVerifyPhoneResponseJsonPanel = showVerifyPhoneResponseJsonPanel;
	}

	public boolean isShowConfirmPasscodeRequestJsonPanel() {
		return showConfirmPasscodeRequestJsonPanel;
	}

	public void setShowConfirmPasscodeRequestJsonPanel(boolean showConfirmPasscodeRequestJsonPanel) {
		this.showConfirmPasscodeRequestJsonPanel = showConfirmPasscodeRequestJsonPanel;
	}

	public boolean isShowConfirmPasscodeResponseJsonPanel() {
		return showConfirmPasscodeResponseJsonPanel;
	}

	public void setShowConfirmPasscodeResponseJsonPanel(boolean showConfirmPasscodeResponseJsonPanel) {
		this.showConfirmPasscodeResponseJsonPanel = showConfirmPasscodeResponseJsonPanel;
	}

	public boolean isShowRequestPasscodeRequestJsonPanel() {
		return showRequestPasscodeRequestJsonPanel;
	}

	public void setShowRequestPasscodeRequestJsonPanel(boolean showRequestPasscodeRequestJsonPanel) {
		this.showRequestPasscodeRequestJsonPanel = showRequestPasscodeRequestJsonPanel;
	}

	public boolean isShowRequestPasscodeResponseJsonPanel() {
		return showRequestPasscodeResponseJsonPanel;
	}

	public void setShowRequestPasscodeResponseJsonPanel(boolean showRequestPasscodeResponseJsonPanel) {
		this.showRequestPasscodeResponseJsonPanel = showRequestPasscodeResponseJsonPanel;
	}

	public boolean isShowCheckDeviceSubmitBtn() {
		return showCheckDeviceSubmitBtn;
	}

	public void setShowCheckDeviceSubmitBtn(boolean showCheckDeviceSubmitBtn) {
		this.showCheckDeviceSubmitBtn = showCheckDeviceSubmitBtn;
	}

	public boolean isShowVerifyPhoneSubmitBtn() {
		return showVerifyPhoneSubmitBtn;
	}

	public boolean isShowVerifyPhoneGenerateBtn() {
		return showVerifyPhoneGenerateBtn;
	}

	public void setShowVerifyPhoneGenerateBtn(boolean showVerifyPhoneGenerateBtn) {
		this.showVerifyPhoneGenerateBtn = showVerifyPhoneGenerateBtn;
	}

	public void setShowVerifyPhoneSubmitBtn(boolean showVerifyPhoneSubmitBtn) {
		this.showVerifyPhoneSubmitBtn = showVerifyPhoneSubmitBtn;
	}

	public boolean isShowConfirmPasscodeGenerateBtn() {
		return showConfirmPasscodeGenerateBtn;
	}

	public void setShowConfirmPasscodeGenerateBtn(boolean showConfirmPasscodeGenerateBtn) {
		this.showConfirmPasscodeGenerateBtn = showConfirmPasscodeGenerateBtn;
	}

	public boolean isShowConfirmPasscodeSubmitBtn() {
		return showConfirmPasscodeSubmitBtn;
	}

	public void setShowConfirmPasscodeSubmitBtn(boolean showConfirmPasscodeSubmitBtn) {
		this.showConfirmPasscodeSubmitBtn = showConfirmPasscodeSubmitBtn;
	}

	public boolean isShowRequestPasscodeGenerateBtn() {
		return showRequestPasscodeGenerateBtn;
	}

	public void setShowRequestPasscodeGenerateBtn(boolean showRequestPasscodeGenerateBtn) {
		this.showRequestPasscodeGenerateBtn = showRequestPasscodeGenerateBtn;
	}

	public boolean isShowRequestPasscodeSubmitBtn() {
		return showRequestPasscodeSubmitBtn;
	}

	public void setShowRequestPasscodeSubmitBtn(boolean showRequestPasscodeSubmitBtn) {
		this.showRequestPasscodeSubmitBtn = showRequestPasscodeSubmitBtn;
	}

	public Map<String, Object> getCdRequestHashMap() {
		return cdRequestHashMap;
	}

	public void setCdRequestHashMap(Map<String, Object> cdRequestHashMap) {
		this.cdRequestHashMap = cdRequestHashMap;
	}

	public Map<String, Object> getVpRequestHashMap() {
		return vpRequestHashMap;
	}

	public void setVpRequestHashMap(Map<String, Object> vpRequestHashMap) {
		this.vpRequestHashMap = vpRequestHashMap;
	}

	public Map<String, Object> getCpRequestHashMap() {
		return cpRequestHashMap;
	}

	public void setCpRequestHashMap(Map<String, Object> cpRequestHashMap) {
		this.cpRequestHashMap = cpRequestHashMap;
	}

	public Map<String, Object> getRpRequestHashMap() {
		return rpRequestHashMap;
	}

	public void setRpRequestHashMap(Map<String, Object> rpRequestHashMap) {
		this.rpRequestHashMap = rpRequestHashMap;
	}

	public String getRlJsonRequest() {
		return rlJsonRequest;
	}

	public void setRlJsonRequest(String rlJsonRequest) {
		this.rlJsonRequest = rlJsonRequest;
	}

	public String getRlJsonResponse() {
		return rlJsonResponse;
	}

	public void setRlJsonResponse(String rlJsonResponse) {
		this.rlJsonResponse = rlJsonResponse;
	}

	public String getVlJsonRequest() {
		return vlJsonRequest;
	}

	public void setVlJsonRequest(String vlJsonRequest) {
		this.vlJsonRequest = vlJsonRequest;
	}

	public String getVlJsonResponse() {
		return vlJsonResponse;
	}

	public void setVlJsonResponse(String vlJsonResponse) {
		this.vlJsonResponse = vlJsonResponse;
	}

	public String getResendSmfaLinkInstMsg() {
		return resendSmfaLinkInstMsg;
	}

	public void setResendSmfaLinkInstMsg(String resendSmfaLinkInstMsg) {
		this.resendSmfaLinkInstMsg = resendSmfaLinkInstMsg;
	}

	public String getResendSmfaLinkErrorMsg() {
		return resendSmfaLinkErrorMsg;
	}

	public void setResendSmfaLinkErrorMsg(String resendSmfaLinkErrorMsg) {
		this.resendSmfaLinkErrorMsg = resendSmfaLinkErrorMsg;
	}

	public String getResendSmfaLinkSuccessMsg() {
		return resendSmfaLinkSuccessMsg;
	}

	public void setResendSmfaLinkSuccessMsg(String resendSmfaLinkSuccessMsg) {
		this.resendSmfaLinkSuccessMsg = resendSmfaLinkSuccessMsg;
	}

	public String getValidateSmfaLinkInstMsg() {
		return validateSmfaLinkInstMsg;
	}

	public void setValidateSmfaLinkInstMsg(String validateSmfaLinkInstMsg) {
		this.validateSmfaLinkInstMsg = validateSmfaLinkInstMsg;
	}

	public String getValidateSmfaLinkErrorMsg() {
		return validateSmfaLinkErrorMsg;
	}

	public void setValidateSmfaLinkErrorMsg(String validateSmfaLinkErrorMsg) {
		this.validateSmfaLinkErrorMsg = validateSmfaLinkErrorMsg;
	}

	public String getValidateSmfaLinkSuccessMsg() {
		return validateSmfaLinkSuccessMsg;
	}

	public void setValidateSmfaLinkSuccessMsg(String validateSmfaLinkSuccessMsg) {
		this.validateSmfaLinkSuccessMsg = validateSmfaLinkSuccessMsg;
	}

	public boolean isShowResendSmfaLinkInstMsg() {
		return showResendSmfaLinkInstMsg;
	}

	public void setShowResendSmfaLinkInstMsg(boolean showResendSmfaLinkInstMsg) {
		this.showResendSmfaLinkInstMsg = showResendSmfaLinkInstMsg;
	}

	public boolean isShowResendSmfaLinkErrorMsg() {
		return showResendSmfaLinkErrorMsg;
	}

	public void setShowResendSmfaLinkErrorMsg(boolean showResendSmfaLinkErrorMsg) {
		this.showResendSmfaLinkErrorMsg = showResendSmfaLinkErrorMsg;
	}

	public boolean isShowResendSmfaLinkSuccessMsg() {
		return showResendSmfaLinkSuccessMsg;
	}

	public void setShowResendSmfaLinkSuccessMsg(boolean showResendSmfaLinkSuccessMsg) {
		this.showResendSmfaLinkSuccessMsg = showResendSmfaLinkSuccessMsg;
	}

	public boolean isShowResendSmfaLinkRequestJsonPanel() {
		return showResendSmfaLinkRequestJsonPanel;
	}

	public void setShowResendSmfaLinkRequestJsonPanel(boolean showResendSmfaLinkRequestJsonPanel) {
		this.showResendSmfaLinkRequestJsonPanel = showResendSmfaLinkRequestJsonPanel;
	}

	public boolean isShowResendSmfaLinkResponseJsonPanel() {
		return showResendSmfaLinkResponseJsonPanel;
	}

	public void setShowResendSmfaLinkResponseJsonPanel(boolean showResendSmfaLinkResponseJsonPanel) {
		this.showResendSmfaLinkResponseJsonPanel = showResendSmfaLinkResponseJsonPanel;
	}

	public boolean isShowResendSmfaLinkGenerateBtn() {
		return showResendSmfaLinkGenerateBtn;
	}

	public void setShowResendSmfaLinkGenerateBtn(boolean showResendSmfaLinkGenerateBtn) {
		this.showResendSmfaLinkGenerateBtn = showResendSmfaLinkGenerateBtn;
	}

	public boolean isShowResendSmfaLinkSubmitBtn() {
		return showResendSmfaLinkSubmitBtn;
	}

	public void setShowResendSmfaLinkSubmitBtn(boolean showResendSmfaLinkSubmitBtn) {
		this.showResendSmfaLinkSubmitBtn = showResendSmfaLinkSubmitBtn;
	}

	public boolean isShowValidateSmfaLinkInstMsg() {
		return showValidateSmfaLinkInstMsg;
	}

	public void setShowValidateSmfaLinkInstMsg(boolean showValidateSmfaLinkInstMsg) {
		this.showValidateSmfaLinkInstMsg = showValidateSmfaLinkInstMsg;
	}

	public boolean isShowValidateSmfaLinkErrorMsg() {
		return showValidateSmfaLinkErrorMsg;
	}

	public void setShowValidateSmfaLinkErrorMsg(boolean showValidateSmfaLinkErrorMsg) {
		this.showValidateSmfaLinkErrorMsg = showValidateSmfaLinkErrorMsg;
	}

	public boolean isShowValidateSmfaLinkSuccessMsg() {
		return showValidateSmfaLinkSuccessMsg;
	}

	public void setShowValidateSmfaLinkSuccessMsg(boolean showValidateSmfaLinkSuccessMsg) {
		this.showValidateSmfaLinkSuccessMsg = showValidateSmfaLinkSuccessMsg;
	}

	public boolean isShowValidateSmfaLinkRequestJsonPanel() {
		return showValidateSmfaLinkRequestJsonPanel;
	}

	public void setShowValidateSmfaLinkRequestJsonPanel(boolean showValidateSmfaLinkRequestJsonPanel) {
		this.showValidateSmfaLinkRequestJsonPanel = showValidateSmfaLinkRequestJsonPanel;
	}

	public boolean isShowValidateSmfaLinkResponseJsonPanel() {
		return showValidateSmfaLinkResponseJsonPanel;
	}

	public void setShowValidateSmfaLinkResponseJsonPanel(boolean showValidateSmfaLinkResponseJsonPanel) {
		this.showValidateSmfaLinkResponseJsonPanel = showValidateSmfaLinkResponseJsonPanel;
	}

	public boolean isShowValidateSmfaLinkGenerateBtn() {
		return showValidateSmfaLinkGenerateBtn;
	}

	public void setShowValidateSmfaLinkGenerateBtn(boolean showValidateSmfaLinkGenerateBtn) {
		this.showValidateSmfaLinkGenerateBtn = showValidateSmfaLinkGenerateBtn;
	}

	public boolean isShowValidateSmfaLinkSubmitBtn() {
		return showValidateSmfaLinkSubmitBtn;
	}

	public void setShowValidateSmfaLinkSubmitBtn(boolean showValidateSmfaLinkSubmitBtn) {
		this.showValidateSmfaLinkSubmitBtn = showValidateSmfaLinkSubmitBtn;
	}

	public Map<String, Object> getRlRequestHashMap() {
		return rlRequestHashMap;
	}

	public void setRlRequestHashMap(Map<String, Object> rlRequestHashMap) {
		this.rlRequestHashMap = rlRequestHashMap;
	}

	public Map<String, Object> getVlRequestHashMap() {
		return vlRequestHashMap;
	}

	public void setVlRequestHashMap(Map<String, Object> vlRequestHashMap) {
		this.vlRequestHashMap = vlRequestHashMap;
	}

	public String getRlSponsorId() {
		return rlSponsorId;
	}

	public void setRlSponsorId(String rlSponsorId) {
		this.rlSponsorId = rlSponsorId;
	}

	public String getRlSponsorUserId() {
		return rlSponsorUserId;
	}

	public void setRlSponsorUserId(String rlSponsorUserId) {
		this.rlSponsorUserId = rlSponsorUserId;
	}

	public String getRlFirstName() {
		return rlFirstName;
	}

	public void setRlFirstName(String rlFirstName) {
		this.rlFirstName = rlFirstName;
	}

	public String getRlLastName() {
		return rlLastName;
	}

	public void setRlLastName(String rlLastName) {
		this.rlLastName = rlLastName;
	}

	public String getRlBirthDate() {
		return rlBirthDate;
	}

	public void setRlBirthDate(String rlBirthDate) {
		this.rlBirthDate = rlBirthDate;
	}

	public String getRlStreetAddress() {
		return rlStreetAddress;
	}

	public void setRlStreetAddress(String rlStreetAddress) {
		this.rlStreetAddress = rlStreetAddress;
	}

	public String getRlCity() {
		return rlCity;
	}

	public void setRlCity(String rlCity) {
		this.rlCity = rlCity;
	}

	public String getRlState() {
		return rlState;
	}

	public void setRlState(String rlState) {
		this.rlState = rlState;
	}

	public String getRlZip5() {
		return rlZip5;
	}

	public void setRlZip5(String rlZip5) {
		this.rlZip5 = rlZip5;
	}

	public String getRlMobileNumber() {
		return rlMobileNumber;
	}

	public void setRlMobileNumber(String rlMobileNumber) {
		this.rlMobileNumber = rlMobileNumber;
	}

	public String getVlSponsorId() {
		return vlSponsorId;
	}

	public void setVlSponsorId(String vlSponsorId) {
		this.vlSponsorId = vlSponsorId;
	}

	public String getVlSponsorUserId() {
		return vlSponsorUserId;
	}

	public void setVlSponsorUserId(String vlSponsorUserId) {
		this.vlSponsorUserId = vlSponsorUserId;
	}

	public String getVlMobileNumber() {
		return vlMobileNumber;
	}

	public void setVlMobileNumber(String vlMobileNumber) {
		this.vlMobileNumber = vlMobileNumber;
	}
}
