package com.ips.bean;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.richfaces.event.FileUploadEvent;
import org.richfaces.exception.FileUploadException;
import org.richfaces.model.UploadedFile;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.ibm.json.java.JSONObject;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.Utils;
import com.ips.entity.IppEvent;
import com.ips.entity.IvsAdminUser;
import com.ips.entity.RefPrimaryIdType;
import com.ips.jaxrs.CheckValidationResponse;
import com.ips.jaxrs.ErrorMessage;
import com.ips.jaxrs.InitiateValidationRequest;
import com.ips.jaxrs.ValidateIDRequest;
import com.ips.jaxrs.ValidationRequest;
import com.ips.rss.service.IDVerificationService;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;
import com.ips.service.IppEventService;
import com.ips.service.IvsAdminUserService;
import com.ips.service.RefIppWorkflowsService;
import com.ips.service.RefPrimaryIdTypeService;
import com.ips.service.SponsorApplicationMapService;

@ManagedBean(name = "ippIdValidationBean")
@ViewScoped
public class IPPIdValidationBean extends IPSAdminController implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String APPLICATION = "EBIS";
	private static final String REQUIRED_FIELDS_MSG = "Required fields not provided: ";
	private static final String CONTAINS_INVALID_CHARACTERS_MSG = " contains invalid characters";
	private static final String RECORD_LOCATOR = "recordLocator";
	private static final String WORKFLOW_OPTION = "workflowOption";
	private static final String PROOFING_LOCATION = "proofingLocation";
	private static final String SUSPECT_FRAUD = "suspectFraud";
	private static final String STRONG_ID_TYPE = "strongIdType";
	private static final String IVS_TOKEN = "IVSToken";

	private static final long VENDOR_ID_LEXISNEXIS = 3L;

	private RefPrimaryIdTypeService refPrimaryIdTypeService;
	private IppEventService ippEventService;
	private SponsorApplicationMapService sponsorAppMapService;
	private AdminService adminService;
	private IppEvent ippEvent;
	private IvsAdminUserService ivsAdminUserService;
	private RefIppWorkflowsService refIppWorkflowsService;
	private IDVerificationService idVerificationService;

	private boolean initialized = false;
	private List<RefPrimaryIdType> primaryIdTypeList;
	private byte[] storedFrontTempImage;
	private byte[] storedBackTempImage;
	private Long selectedPrimaryIdTypeId = 0L;
	private String selectedWorkflowId;
	private boolean suspectFraud;
	private String recordLocator;
	private String proofingLocation;
	private String webserviceResponse;
	private String frontImageExt;
	private String backImageExt;
	private String frontImageBase64String;
	private String backImageBase64String;
	private String frontImageName;
	private String backImageName;
	private String successMsg;
	private String errorMsg;
	private int frontImageLength;
	private int backImageLength;
	private int frontImageHeight;
	private int backImageHeight;
	private int frontImageWidth;
	private int backImageWidth;
	private long frontImageFileSize;
	private long backImageFileSize;
	private boolean renderFrontImage;
	private boolean renderBackImage;
	private boolean renderFrontImageUI;
	private boolean renderBackImageUI;
	private boolean renderResponse;
	private boolean validationErrorMsg;
	private boolean validationSuccessMsg;

	/*************************** Initialization Methods ***************************/

	@PostConstruct
	public void init() {
		CustomLogger.enter(this.getClass());

		if (!initialized) {
			setserviceHandlers();
			loadPrimaryIdList();
			setInitialized(true);

			setValidationErrorMsg(false);
			setValidationSuccessMsg(false);
			setRenderFrontImageUI(false);
			setRenderBackImageUI(false);
		}
	}

	private void setserviceHandlers() {
		CustomLogger.enter(this.getClass());

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			refPrimaryIdTypeService = webAppContext.getBean(RefPrimaryIdTypeService.class);
			adminService = webAppContext.getBean(AdminServiceImpl.class);
			ippEventService = webAppContext.getBean(IppEventService.class);
			sponsorAppMapService = webAppContext.getBean(SponsorApplicationMapService.class);
			ivsAdminUserService = webAppContext.getBean(IvsAdminUserService.class);
			refIppWorkflowsService = webAppContext.getBean(RefIppWorkflowsService.class);
			idVerificationService = webAppContext.getBean(IDVerificationService.class);
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve necessary services.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/*************************** Public Event Methods ***************************/

	/**
	 * Uploads the ID front image and stores the data in the view state. Invoked
	 * from the front-end.
	 * 
	 * @return
	 */
	public void storeUploadFrontImage(FileUploadEvent event) {
		CustomLogger.enter(this.getClass());

		byte[] imgFileData = null;
		UploadedFile imgFile = null;

		try {
			imgFile = event.getUploadedFile();
			imgFileData = imgFile.getData();
			setStoredFrontTempImage(imgFileData);
		} catch (FileUploadException e) {
			errorMsg = "Exception occurred when trying to upload Front ID image.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setValidationErrorMsg(true);
			setErrorMsg(errorMsg);
		}

		try {
			if (imgFileData != null) {
				setFrontImageFileSize(imgFile.getSize());

				byte[] base64String = encodeBytesToBase64(imgFileData);
				setFrontImageBase64String(new String(base64String));

				setFrontImageName(imgFile.getName());
				setFrontImageLength(imgFile.getData().length);
				setRenderFrontImage(true);
				int extNameIndex = frontImageName.lastIndexOf('.');
				String fileExtn = frontImageName.substring(extNameIndex + 1, frontImageName.length());
				setFrontImageExt(fileExtn);

				BufferedImage buffImg = ImageIO.read(new ByteArrayInputStream(imgFile.getData()));
				frontImageHeight = 100;
				frontImageWidth = frontImageHeight * buffImg.getWidth() / buffImg.getHeight();
			}

		} catch (FileUploadException e) {
			errorMsg = "FileUploadException occurred when encoding front image to base64.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setValidationErrorMsg(true);
			setErrorMsg(errorMsg);
		} catch (IOException e) {
			errorMsg = "IOException occurred when encoding front image to base64.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setValidationErrorMsg(true);
			setErrorMsg(errorMsg);
		}

	}

	/**
	 * Uploads the ID back image and stores the data in the view state. Invoked from
	 * the front-end.
	 * 
	 * @return
	 */
	public void storeUploadBackImage(FileUploadEvent event) {
		CustomLogger.enter(this.getClass());

		byte[] imgFileData = null;
		UploadedFile imgFile = null;

		try {
			imgFile = event.getUploadedFile();
			imgFileData = imgFile.getData();
			setStoredBackTempImage(imgFileData);

		} catch (FileUploadException e) {
			errorMsg = "Exception occurred when trying to upload Back ID image.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setValidationErrorMsg(true);
			setErrorMsg(errorMsg);
		}

		try {
			if (imgFileData != null) {
				setBackImageFileSize(imgFile.getSize());

				byte[] base64String = encodeBytesToBase64(imgFileData);
				setBackImageBase64String(new String(base64String));

				setBackImageName(imgFile.getName());
				setBackImageLength(imgFile.getData().length);
				setRenderBackImage(true);
				int extNameIndex = backImageName.lastIndexOf('.');
				String fileExtn = backImageName.substring(extNameIndex + 1, backImageName.length());
				setBackImageExt(fileExtn);

				BufferedImage buffImg = ImageIO.read(new ByteArrayInputStream(imgFile.getData()));
				backImageHeight = 100;
				backImageWidth = backImageHeight * buffImg.getWidth() / buffImg.getHeight();
			}
		} catch (FileUploadException e) {
			errorMsg = "FileUploadException occurred when encoding back image to base64.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setValidationErrorMsg(true);
			setErrorMsg(errorMsg);
		} catch (IOException e) {
			errorMsg = "IOException occurred when encoding back image to base64.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setValidationErrorMsg(true);
			setErrorMsg(errorMsg);
		}
	}

	/**
	 * Loads the primary and strong ID list.
	 * 
	 * @return
	 */
	public void loadPrimaryIdList() {
		CustomLogger.enter(this.getClass());

		try {
			primaryIdTypeList = refPrimaryIdTypeService.getAllStrongList();
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in loadSponsorList: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/**
	 * Submits the form to validate request data. Called from front-end.
	 * 
	 * @return
	 */
	public void validateIDData() {
		CustomLogger.enter(this.getClass());

		ValidateIDRequest idRequest = new ValidateIDRequest();
		String requestErrorMsg = validateIDInputData(idRequest);

		Gson g = new Gson();
		Response response = adminService.validateIDRequest(idRequest, requestErrorMsg);

		Object responseEntity = response.getEntity();
		JSONObject responseEntityJson = null;
		CheckValidationResponse checkValidationResponse = null;
		String vendor = "";

		if (responseEntity instanceof CheckValidationResponse) {
			checkValidationResponse = (CheckValidationResponse) response.getEntity();
			vendor = checkValidationResponse.getVendor();
		} else if (responseEntity instanceof JSONObject) {
			responseEntityJson = (JSONObject) response.getEntity();
			vendor = (String) responseEntityJson.get("vendor");
		}

		processValidationResult(response, requestErrorMsg, vendor);
	}

	/**
	 * Submits the form to verify the State ID request data. Called from front-end
	 * to State ID verification API only.
	 * 
	 * @return
	 */
	public void verifyStateId() {
		CustomLogger.enter(this.getClass());

		ValidateIDRequest idRequest = new ValidateIDRequest();
		String requestErrorMsg = validateIDInputData(idRequest);
		ValidationRequest verifyRequest = idRequest.getRequest();
		IppEvent event = ippEventService.findByRecordLocator(idRequest.getRecordLocator());

		Response response = adminService.verifyStateId(verifyRequest, event, requestErrorMsg);

		processValidationResult(response, requestErrorMsg, "Equifax");
	}

	/**
	 * Submits the form to verify the address request data using the USPS WebTools
	 * API. Called from front-end to USPS WebTools verification API only.
	 * 
	 * @return
	 */
	public void verifyAddress() {
		CustomLogger.enter(this.getClass());

		ValidateIDRequest idRequest = new ValidateIDRequest();
		String requestErrorMsg = validateIDInputData(idRequest);
		IppEvent event = ippEventService.findByRecordLocator(idRequest.getRecordLocator());

		Response response = adminService.verifyAddress(event, requestErrorMsg);

		processValidationResult(response, requestErrorMsg, null);
	}

	private String validateIDInputData(ValidateIDRequest idRequest) {
		CustomLogger.enter(this.getClass());

		setValidationSuccessMsg(false);

		idRequest.setFrontImage(frontImageBase64String);
		idRequest.setBackImage(backImageBase64String);

		ValidationRequest valRequest = idRequest.getRequest();
		valRequest.setWorkflowOption(selectedWorkflowId);
		valRequest.setSuspectFraud(suspectFraud ? "Y" : "N");
		valRequest.setProofingLocation(this.proofingLocation);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
				.getRequest();
		String username = (String) request.getSession().getAttribute(IVS_TOKEN);
		valRequest.setProoferAceId(username);

		IvsAdminUser adminUser = ivsAdminUserService.findByUserId(username);
		valRequest.setProoferFirstName(adminUser.getFirstName());
		valRequest.setProoferLastName(adminUser.getLastName());

		InitiateValidationRequest initValRequest = valRequest.getRequest();
		initValRequest.setApplication(APPLICATION);
		initValRequest.setRecordLocator(recordLocator);
		initValRequest.setStrongIdType(selectedPrimaryIdTypeId);

		String requestErrorMsg = "";

		if (frontImageFileSize > 2000000) {
			requestErrorMsg = "Front image file size exceeds 2000 kb limit.";
		}

		if (StringUtils.isEmpty(requestErrorMsg) && selectedPrimaryIdTypeId != 4L && backImageFileSize > 2000000) {
			requestErrorMsg = "Back image file size exceeds 2000 kb limit.";
		}

		if (StringUtils.isEmpty(requestErrorMsg)) {
			requestErrorMsg = validateIDRequest(idRequest);

			if (StringUtils.isEmpty(requestErrorMsg) && ippEvent != null) {
				long transactionEndDatetime = ippEvent.getTransactionEndDatetime() != null
						? ippEvent.getTransactionStartDatetime().getTime()
						: DateTimeUtil.getCurrentTime().getTime();
				valRequest.setTransactionStartDateTime(transactionEndDatetime);
			}
		}

		if (!StringUtils.isEmpty(requestErrorMsg)) {
			setErrorMsg(requestErrorMsg);
			setValidationErrorMsg(true);
			setRenderResponse(false);
		}

		return requestErrorMsg;
	}

	@SuppressWarnings("deprecation")
	public void processValidationResult(Response response, String requestErrorMsg, String vendor) {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		String rawJsonResponse = g.toJson(response.getEntity());

		JsonParser parser = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		JsonElement responseJsonEl = parser.parse(rawJsonResponse);
		setWebserviceResponse(gson.toJson(responseJsonEl));

		if (!StringUtils.isEmpty(webserviceResponse)) {
			if (StringUtils.isEmpty(requestErrorMsg)) {
				if (webserviceResponse.contains("ErrorCode")) {
					String errorMsg = vendor != null
							? String.format("Internal error occurred when validating ID by %s vendor.", vendor)
							: "Internal error occurred when verifying address.";

					setErrorMsg(errorMsg);
					setValidationSuccessMsg(false);
					setValidationErrorMsg(true);
				} else {
					String successMsg = vendor != null
							? String.format("ID image was successfully validated by %s vendor!", vendor)
							: "Address verification was successfully processed.";

					setValidationSuccessMsg(true);
					setValidationErrorMsg(false);
				}
			}

			setRenderResponse(true);
		} else {
			setErrorMsg(String.format("No validation response from %s vendor.", vendor));
			setValidationSuccessMsg(false);
			setValidationErrorMsg(true);
		}
	}

	/**
	 * Submits the form to validate request data. Called from front-end.
	 * 
	 * @return
	 */
	public void resetForm() {
		CustomLogger.enter(this.getClass());
		initialized = false;

		setValidationSuccessMsg(false);
		setValidationErrorMsg(false);
		setSelectedPrimaryIdTypeId(0L);
		setRecordLocator(null);
		setProofingLocation(null);
		setSelectedWorkflowId(null);
		setSuspectFraud(false);
		setFrontImageBase64String(null);
		setBackImageBase64String(null);
		setWebserviceResponse(null);

		setRenderFrontImageUI(false);
		setRenderFrontImage(false);
		setRenderBackImageUI(false);
		setRenderBackImage(false);
		setRenderResponse(false);
	}

	/**
	 * Shows or hides the the uploaded front and back images depending on the strong
	 * ID type selected.
	 * 
	 * @return
	 */
	public void showHideImageUploader(ValueChangeEvent event) {
		CustomLogger.enter(this.getClass());

		selectedPrimaryIdTypeId = (Long) event.getNewValue();

		setRenderFrontImageUI(true);
		setRenderFrontImage(true);
		setRenderBackImageUI(true);
		setRenderBackImage(true);
		setWebserviceResponse(null);

		if (selectedPrimaryIdTypeId == 0L) {
			setRenderFrontImageUI(false);
			setRenderFrontImage(false);
			setRenderBackImageUI(false);
			setRenderBackImage(false);
		} else if (selectedPrimaryIdTypeId == 4L) {
			setRenderBackImageUI(false);
			setRenderBackImage(false);
		}
	}

	/*************************** Private Methods ***************************/

	/**
	 * Checks if a strong type id was selected, if a record locator was provided,
	 * and if front image and back image (if id is not passport) were uploaded.
	 * 
	 * @return String
	 */
	private String validateIDRequest(ValidateIDRequest valIdRequest) {
		CustomLogger.enter(this.getClass());

		InitiateValidationRequest initValRequest = valIdRequest.getRequest().getRequest();
		StringBuilder missingFields = new StringBuilder();
		StringBuilder badFormattedFields = new StringBuilder();
		final String separator = ", ";

		if (StringUtils.isEmpty(initValRequest.getRecordLocator())) {
			missingFields.append(RECORD_LOCATOR + separator);
		} else {
			if (!Utils.isNumeric(initValRequest.getRecordLocator())) {
				badFormattedFields.append(RECORD_LOCATOR + separator);
			} else {
				ippEvent = ippEventService.findByRecordLocator(initValRequest.getRecordLocator());
				if (ippEvent == null) {
					return "In Person Proofing event was not found for record locator:"
							+ initValRequest.getRecordLocator();
				}
			}
		}

		if (StringUtils.isEmpty(valIdRequest.getWorkflowOption())) {
			missingFields.append(WORKFLOW_OPTION + separator);
		}

		if (initValRequest.getStrongIdType() == 0L) {
			missingFields.append(STRONG_ID_TYPE + separator);
		}

		if (StringUtils.isEmpty(valIdRequest.getProofingLocation())) {
			missingFields.append(PROOFING_LOCATION + separator);
		}

		// Web service calls for sponsorID are disabled
		if (ippEvent != null) {
			ErrorMessage errorMessage = sponsorAppMapService.sponsorDisabledCheck(ippEvent.getPerson().getRefSponsor(),
					ippEvent.getTransactionOriginId());
			if (errorMessage != null) {
				return errorMessage.getMessage();
			}

			if (ippEvent.getRefIppEventStatus().isIppPassed() || ippEvent.getRefIppEventStatus().isIppFailed()) {
				return "Proofing event already occurred";
			}
		}

		if (!StringUtils.isEmpty(missingFields.toString())) {
			return REQUIRED_FIELDS_MSG
					+ missingFields.toString().substring(0, missingFields.toString().length() - separator.length());
		}

		if (badFormattedFields.toString().length() > 0) {
			return badFormattedFields.toString().substring(0,
					badFormattedFields.toString().length() - separator.length()) + CONTAINS_INVALID_CHARACTERS_MSG;
		}

		if (StringUtils.isEmpty(valIdRequest.getFrontImage())) {
			missingFields.append("frontImage" + separator);
		} else if (!"JPG".equalsIgnoreCase(frontImageExt)) {
			return "ID front image is not a JPG format.";
		}

		if (selectedPrimaryIdTypeId != 4L) {
			if (StringUtils.isEmpty(valIdRequest.getBackImage())) {
				missingFields.append("backImage" + separator);
			} else if (!"JPG".equalsIgnoreCase(frontImageExt)) {
				return "ID back image is not a JPG format.";
			}
		}

		if (missingFields.toString().length() > 0) {
			return REQUIRED_FIELDS_MSG
					+ missingFields.toString().substring(0, missingFields.toString().length() - separator.length());
		}

		return null;
	}

	/**
	 * Encodes the image file data to base 64 format.
	 * 
	 * @return String
	 */
	private byte[] encodeBytesToBase64(byte[] imgFileData) {
		CustomLogger.enter(this.getClass());

		if (imgFileData == null || imgFileData.length == 0) {
			return new byte[0];
		}

		return Base64.encodeBase64(imgFileData);
	}

	/***************************
	 * Properties Getters/Setters
	 ***************************/

	public byte[] getStoredFrontTempImage() {
		return storedFrontTempImage;
	}

	public void setStoredFrontTempImage(byte[] storedFrontTempImage) {
		this.storedFrontTempImage = storedFrontTempImage;
	}

	public byte[] getStoredBackTempImage() {
		return storedBackTempImage;
	}

	public void setStoredBackTempImage(byte[] storedBackTempImage) {
		this.storedBackTempImage = storedBackTempImage;
	}

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public List<RefPrimaryIdType> getPrimaryIdTypeList() {
		return primaryIdTypeList;
	}

	public void setPrimaryIdTypeList(List<RefPrimaryIdType> primaryIdTypeList) {
		this.primaryIdTypeList = primaryIdTypeList;
	}

	public Long getSelectedPrimaryIdTypeId() {
		return selectedPrimaryIdTypeId;
	}

	public void setSelectedPrimaryIdTypeId(Long selectedPrimaryIdTypeId) {
		this.selectedPrimaryIdTypeId = selectedPrimaryIdTypeId;
	}

	public String getFrontImageExt() {
		return frontImageExt;
	}

	public void setFrontImageExt(String frontImageExt) {
		this.frontImageExt = frontImageExt;
	}

	public String getBackImageExt() {
		return backImageExt;
	}

	public void setBackImageExt(String backImageExt) {
		this.backImageExt = backImageExt;
	}

	public String getFrontImageBase64String() {
		return frontImageBase64String;
	}

	public void setFrontImageBase64String(String frontImageBase64String) {
		this.frontImageBase64String = frontImageBase64String;
	}

	public String getBackImageBase64String() {
		return backImageBase64String;
	}

	public void setBackImageBase64String(String backImageBase64String) {
		this.backImageBase64String = backImageBase64String;
	}

	public String getFrontImageName() {
		return frontImageName;
	}

	public void setFrontImageName(String frontImageName) {
		this.frontImageName = frontImageName;
	}

	public String getBackImageName() {
		return backImageName;
	}

	public void setBackImageName(String backImageName) {
		this.backImageName = backImageName;
	}

	public int getFrontImageLength() {
		return frontImageLength;
	}

	public void setFrontImageLength(int frontImageLength) {
		this.frontImageLength = frontImageLength;
	}

	public int getBackImageLength() {
		return backImageLength;
	}

	public void setBackImageLength(int backImageLength) {
		this.backImageLength = backImageLength;
	}

	public int getFrontImageHeight() {
		return frontImageHeight;
	}

	public void setFrontImageHeight(int frontImageHeight) {
		this.frontImageHeight = frontImageHeight;
	}

	public int getBackImageHeight() {
		return backImageHeight;
	}

	public void setBackImageHeight(int backImageHeight) {
		this.backImageHeight = backImageHeight;
	}

	public int getFrontImageWidth() {
		return frontImageWidth;
	}

	public void setFrontImageWidth(int frontImageWidth) {
		this.frontImageWidth = frontImageWidth;
	}

	public int getBackImageWidth() {
		return backImageWidth;
	}

	public void setBackImageWidth(int backImageWidth) {
		this.backImageWidth = backImageWidth;
	}

	public boolean isRenderFrontImage() {
		return renderFrontImage;
	}

	public void setRenderFrontImage(boolean renderFrontImage) {
		this.renderFrontImage = renderFrontImage;
	}

	public boolean isRenderBackImage() {
		return renderBackImage;
	}

	public void setRenderBackImage(boolean renderBackImage) {
		this.renderBackImage = renderBackImage;
	}

	public String getRecordLocator() {
		return recordLocator;
	}

	public void setRecordLocator(String recordLocator) {
		this.recordLocator = recordLocator;
	}

	public String getProofingLocation() {
		return proofingLocation;
	}

	public void setProofingLocation(String proofingLocation) {
		this.proofingLocation = proofingLocation;
	}

	public void setRefIppWorkflowsService(RefIppWorkflowsService refIppWorkflowsService) {
		this.refIppWorkflowsService = refIppWorkflowsService;
	}

	public String getWebserviceResponse() {
		return webserviceResponse;
	}

	public void setWebserviceResponse(String webserviceResponse) {
		this.webserviceResponse = webserviceResponse;
	}

	public boolean isValidationErrorMsg() {
		return validationErrorMsg;
	}

	public void setValidationErrorMsg(boolean validationErrorMsg) {
		this.validationErrorMsg = validationErrorMsg;
	}

	public boolean isValidationSuccessMsg() {
		return validationSuccessMsg;
	}

	public void setValidationSuccessMsg(boolean validationSuccessMsg) {
		this.validationSuccessMsg = validationSuccessMsg;
	}

	public String getSuccessMsg() {
		return successMsg;
	}

	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public boolean isRenderResponse() {
		return renderResponse;
	}

	public void setRenderResponse(boolean renderResponse) {
		this.renderResponse = renderResponse;
	}

	public IppEvent getIppEvent() {
		return ippEvent;
	}

	public void setIppEvent(IppEvent ippEvent) {
		this.ippEvent = ippEvent;
	}

	public long getFrontImageFileSize() {
		return frontImageFileSize;
	}

	public void setFrontImageFileSize(long frontImageFileSize) {
		this.frontImageFileSize = frontImageFileSize;
	}

	public long getBackImageFileSize() {
		return backImageFileSize;
	}

	public void setBackImageFileSize(long backImageFileSize) {
		this.backImageFileSize = backImageFileSize;
	}

	public boolean isRenderFrontImageUI() {
		return renderFrontImageUI;
	}

	public void setRenderFrontImageUI(boolean renderFrontImageUI) {
		this.renderFrontImageUI = renderFrontImageUI;
	}

	public boolean isRenderBackImageUI() {
		return renderBackImageUI;
	}

	public void setRenderBackImageUI(boolean renderBackImageUI) {
		this.renderBackImageUI = renderBackImageUI;
	}

	public RefPrimaryIdTypeService getRefPrimaryIdTypeService() {
		return refPrimaryIdTypeService;
	}

	public void setRefPrimaryIdTypeService(RefPrimaryIdTypeService refPrimaryIdTypeService) {
		this.refPrimaryIdTypeService = refPrimaryIdTypeService;
	}

	public IppEventService getIppEventService() {
		return ippEventService;
	}

	public void setIppEventService(IppEventService ippEventService) {
		this.ippEventService = ippEventService;
	}

	public SponsorApplicationMapService getSponsorAppMapService() {
		return sponsorAppMapService;
	}

	public void setSponsorAppMapService(SponsorApplicationMapService sponsorAppMapService) {
		this.sponsorAppMapService = sponsorAppMapService;
	}

	public AdminService getAdminService() {
		return adminService;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	public IvsAdminUserService getIvsAdminUserService() {
		return ivsAdminUserService;
	}

	public void setIvsAdminUserService(IvsAdminUserService ivsAdminUserService) {
		this.ivsAdminUserService = ivsAdminUserService;
	}

	public RefIppWorkflowsService getRefIppWorkflowsService() {
		return refIppWorkflowsService;
	}

	public String getSelectedWorkflowId() {
		return selectedWorkflowId;
	}

	public void setSelectedWorkflowId(String selectedWorkflowId) {
		this.selectedWorkflowId = selectedWorkflowId;
	}

	public boolean isSuspectFraud() {
		return suspectFraud;
	}

	public void setSuspectFraud(boolean suspectFraud) {
		this.suspectFraud = suspectFraud;
	}

	public IDVerificationService getIdVerificationService() {
		return idVerificationService;
	}

	public void setIdVerificationService(IDVerificationService idVerificationService) {
		this.idVerificationService = idVerificationService;
	}
}
