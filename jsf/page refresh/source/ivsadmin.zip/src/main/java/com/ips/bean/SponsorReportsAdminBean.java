package com.ips.bean;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.util.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.InputEmailVo;
import com.ips.common.SponsorReportVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.Utils;
import com.ips.entity.RefReports;
import com.ips.entity.RefSponsor;
import com.ips.entity.SponsorReports;
import com.ips.jaxrs.ReportRequest;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;
import com.ips.service.RefFacFacilityService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;
import com.ips.service.SponsorFacilitiesService;

@ManagedBean(name = "sponsorRptsAdmin")
@ViewScoped
public class SponsorReportsAdminBean extends IPSAdminController implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private List<RefSponsor> sponsorList;
    private List<RefReports> autoReportList;
    private List<RefReports> adhocReportList;
    private List<InputEmailVo> autoEmailList = new ArrayList<>();
    private List<InputEmailVo> adhocEmailList = new ArrayList<>();
    private List<SponsorReportVo> sponsorReportList;
    private SponsorReports selectedReport;
    
    private String selectedSponsorName;
    private String selectedReportName;
    private String autoErrorMsg;
    private String autoWarnMsg;
    private String autoInfoMsg;
    private String adhocErrorMsg;
    private String adhocWarnMsg;
    private String adhocInfoMsg;
    private long selectedAutoSponsorId = 0L;
    private long selectedAutoReportId = 0L;
    private long selectedAdhocSponsorId = 0L;
    private long selectedAdhocReportId = 0L;
    private int selectedAutoEmailIndex;
    private int selectedAdhocEmailIndex;    
    
    private Date startDate;
    private Date endDate;

    private boolean initialized;
    private boolean showAutoInfoMsg;
    private boolean showAutoWarnMsg;
    private boolean showAutoErrorMsg;
    private boolean showAdhocInfoMsg;
    private boolean showAdhocWarnMsg;
    private boolean showAdhocErrorMsg;
    private boolean showAutoEmailList;
    private boolean removeAutoEmailField;
    private boolean removeAdhocEmailField;
    private boolean addAutoEmailField;
    private boolean addAdhocEmailField;
    private boolean editSponsorReport;
    private boolean deleteSponsorReport;
    private boolean showEditBtn;
    private boolean showUpdateBtn;
    private boolean showConfirmBtn;
    private boolean showCancelBtn;
    private boolean showAutoResetBtn;
    private boolean showAdhocResetBtn;
    private boolean disableAutoSponsorSelect;
    private boolean disableAutoReportSelect;

    private static final String ADMIN_SERVICE = "AdminService";
    private static final String FORMAT_MMDDYYYY = "MM/dd/yyyy";
    private static final String EVENT_NAME_INITLOAD = "InitLoad";
    private static final String EVENT_NAME_EDITDELETELOAD = "EditDeleteLoad";
    private static final String EVENT_NAME_PRESAVEAUTOFORM = "PreSaveAutoForm";
    private static final String EVENT_NAME_POSTSAVEAUTOFORM = "PostSaveAutoForm";
    private static final String EVENT_NAME_PREUPDAREAUTOFORM = "PreUpdateAutoForm";
    private static final String EVENT_NAME_POSTUPDATEAUTOFORM = "PostUpdateAutoForm";
    private static final String EVENT_NAME_EDITAUTOFORM = "EditAutoForm";
    private static final String EVENT_NAME_CANCELEDITAUTOFORM = "CancelEditAutoForm";
    private static final String EVENT_NAME_REMOVEAUTOFORM = "RemoveAutoForm";
    private static final String EVENT_NAME_COMMITREMOVEAUTOFORM = "CommitRemoveAutoForm";    
    private static final String EVENT_NAME_CANCELREMOVEAUTOFORM = "CancelRemoveAutoForm";
    private static final String EVENT_NAME_RESETAUTOFORM = "ResetAutoForm";    
    private static final String EVENT_NAME_ADDAUTOEMAILFIELD = "AddAutoEmailField";
    private static final String EVENT_NAME_REMOVEAUTOEMAILFIELD = "RemoveAutoEmailField";
    private static final String EMAIL_ADDR_REQD_MSG = "At least one email address is required. Please enter an email address.";
    private static final String INVALID_EMAIL_ADDR_MSG_FMT = "An invalid email address is found:%s. Please enter valid email address.";
    private static final String SPONSOR_REQD_MSG = "Sponsor is required. Please select a sponsor.";
    private static final String REPORT_TYPE_REQD_MSG = "Report type is required. Please select a report.";
    private static final String CONST_VALUE_Y = "Y";
    
	private AdminService adminService;
	private RefSponsorDataService refSponsorDataService;
    
    @PostConstruct
    public void init(){        
        CustomLogger.enter(this.getClass());
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
        if (webAppContext != null) {
		adminService = webAppContext.getBean(ADMIN_SERVICE, AdminServiceImpl.class);
        if (!initialized) {
            setInitialized(true);
            loadFormControls();
        }
        } else {
			CustomLogger.error(this.getClass(), "Error: WebApplicationContext is null.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
    }
    
    /*************************** Initialization Methods ***************************/
    
    public void loadFormControls() {
        CustomLogger.enter(this.getClass());
        
        sponsorList = adminService.findSponsorReceivingReports();        
        
        loadInitAutoEmailControls();    
        loadSponsorReportTable(adminService);        
        loadInitAdhocEmailControls();
        
        manageAutoFormPanelDisplay(EVENT_NAME_INITLOAD);
    }
    
    public void loadInitAutoEmailControls() {
        InputEmailVo input = new InputEmailVo();
        int index = autoEmailList.size();
        input.setIndex(index);
        input.setRenderDeleteImg(true);
        setAddAutoEmailField(false);
        autoEmailList.add(input);
    }
    
    public void loadInitAdhocEmailControls() {
        InputEmailVo input = new InputEmailVo();
        int index = adhocEmailList.size();
        input.setIndex(index);
        input.setRenderDeleteImg(true);
        setAddAdhocEmailField(false);
        adhocEmailList.add(input);
        
        this.endDate =  DateTimeUtil.getCurrentDate();
        this.startDate = DateTimeUtil.getDatePlusDays(this.endDate, -31);
        setShowAdhocResetBtn(true);
    }
    
    public void loadSponsorReportTable(AdminService adminService) {
        CustomLogger.enter(this.getClass());
        
        List<SponsorReports> list = adminService.getSponsorReportList();
        sponsorReportList = new ArrayList<>();
        
        for(SponsorReports rpt : list) {
            SponsorReportVo vo = new SponsorReportVo();
            vo.setReportEmailId(rpt.getReportEmailId());
            vo.setSponsorName(rpt.getSponsor().getSponsorName());
            vo.setReportName(rpt.getReports().getName());
            
            String emailAddresses = "";
            if (rpt.getRecipientEmailAddresses() != null) {
                emailAddresses = rpt.getRecipientEmailAddresses().replace(";", "; ");                
            }
            
            vo.setRecipientEmailAddresses(emailAddresses);
            sponsorReportList.add(vo);
        }
    }
    
    /*************************** Public Event Methods - Auto Email Update Form ***************************/

    public void editRecord() {
        CustomLogger.enter(this.getClass());
            

        selectedReport = adminService.getBySponsorAndReportIds(selectedAutoSponsorId, selectedAutoReportId);
                
        if (selectedReport != null) {
            setShowAutoEmailList(true);
            loadEmailListForEdit();
        }
        else {
            if (selectedAutoSponsorId == 0L) {
                setAutoErrorMsg(SPONSOR_REQD_MSG); 
                setShowAutoErrorMsg(true);
            }
            else if (selectedAutoReportId == 0L) {
                setAutoErrorMsg(REPORT_TYPE_REQD_MSG); 
                setShowAutoErrorMsg(true);
            }
        }
    }
    
    public void updateRecord() {
        CustomLogger.enter(this.getClass());
        
        manageAutoFormPanelDisplay(EVENT_NAME_PREUPDAREAUTOFORM);
        
        if (!isAutoEmailValuesValid()) {
            setShowAutoErrorMsg(true);
            return;
        }
        
        StringBuilder emailSb = new StringBuilder();
        for(InputEmailVo vo : autoEmailList) {
            emailSb.append(emailSb.length() == 0? "" : ";");
            
            if (!emailSb.toString().contains(vo.getEmailAddress())) {
                emailSb.append(vo.getEmailAddress());
            }        
        }
                        

        selectedReport = adminService.getBySponsorAndReportIds(selectedAutoSponsorId, selectedAutoReportId);        
        String recipientEmailAddresses = emailSb.toString();

        if (selectedReport != null) {
            selectedReport.setRecipientEmailAddresses(recipientEmailAddresses);
            selectedReport.setUpdateDate(DateTimeUtil.getCurrentTime());
            adminService.updateSponsorReports(selectedReport);
            setAutoInfoMsg("Sponsor Report was successfully updated!");
            setShowAutoInfoMsg(true);
            
            notifyRecipientsEmailListChange(recipientEmailAddresses, adminService);            
        }
        
        loadSponsorReportTable(adminService);
        
        manageAutoFormPanelDisplay(EVENT_NAME_POSTUPDATEAUTOFORM);
    }
    
    public void showRecordForEdit(long reportEmailId) {
        CustomLogger.enter(this.getClass());
                

        selectedReport = adminService.getByPKId(reportEmailId);

        if (selectedReport != null) {
            selectedAutoSponsorId = selectedReport.getSponsor().getSponsorId();
            selectedAutoReportId = selectedReport.getReports().getReportId();

            autoReportList = adminService.findBySponsor(selectedAutoSponsorId);
            loadEmailListForEdit();
        }    
    }
    
    public void loadEmailListForEdit() {
        CustomLogger.enter(this.getClass());
            
        autoEmailList.clear();
        String recipientEmails = selectedReport.getRecipientEmailAddresses();
        
        if (recipientEmails != null) {
            String[] emailArray = recipientEmails.split(";");
            int index = 0;
            for(String email : emailArray) {
                InputEmailVo input = new InputEmailVo();
                email = email.replace(" ", "");
                
                if (!StringUtils.isEmpty(email)) {
                    input.setIndex(index);
                    input.setEmailAddress(email);
                    input.setRenderDeleteImg(true);
                    autoEmailList.add(input);
                    index++;
                }    
            }    
        }
        
        setEditSponsorReport(true);
        
        manageAutoFormPanelDisplay(EVENT_NAME_EDITAUTOFORM);
    }
    
    public void showRecordForEmailListRemove(long reportEmailId) {
        CustomLogger.enter(this.getClass());

        initAutoMessageDisplay();
        selectedReport = adminService.getByPKId(reportEmailId);
        setSelectedAutoSponsorId(selectedReport.getSponsor().getSponsorId());
        setSelectedAutoReportId(selectedReport.getReports().getReportId());
        
        setSelectedSponsorName(selectedReport.getSponsor().getSponsorName());
        setSelectedReportName(selectedReport.getReports().getName());
        autoReportList = adminService.findBySponsor(selectedAutoSponsorId);

        setAutoWarnMsg(String.format("Recipient email addresses of Sponsor report with sponsor:%s and report:%s will be emptied. Are you sure?", 
                selectedSponsorName, selectedReportName));
        
        manageAutoFormPanelDisplay(EVENT_NAME_REMOVEAUTOFORM);
    }
    
    public void commitRemoveEmailList() {
        CustomLogger.enter(this.getClass());
        selectedReport = adminService.getBySponsorAndReportIds(selectedAutoSponsorId, selectedAutoReportId);
        
        selectedReport.setRecipientEmailAddresses(null);
        selectedReport.setUpdateDate(DateTimeUtil.getCurrentTime());
        adminService.updateSponsorReports(selectedReport);
        setAutoInfoMsg("Sponsor Report recipient email addresses was successfully emptied!");
        setShowAutoInfoMsg(true);
        
        notifyRecipientsEmailListChange(null, adminService);            
        
        loadSponsorReportTable(adminService);
        
        setAutoInfoMsg(String.format("Sponsor report with sponsor:%s and report:%s was successfully deleted!", 
                selectedSponsorName, selectedReportName));    
        
        setSelectedAutoSponsorId(0L);
        setSelectedAutoReportId(0L);
        autoEmailList.clear();
        
        manageAutoFormPanelDisplay(EVENT_NAME_COMMITREMOVEAUTOFORM);
    }
    
    public void loadAutoReportList(ValueChangeEvent vcEvent) {
        CustomLogger.enter(this.getClass());
        
        long sponsorId = ((Long)vcEvent.getNewValue()).longValue();
        setSelectedAutoSponsorId(sponsorId);
        
     
        autoReportList = adminService.findBySponsor(sponsorId);

        autoEmailList.clear();
        setShowAutoEmailList(false);
        manageAutoFormPanelDisplay(EVENT_NAME_INITLOAD);
    }
    
    private void notifyRecipientsEmailListChange(String recipientEmailAddresses, AdminService adminService) {
        CustomLogger.enter(this.getClass());

        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        String username = (String) request.getSession().getAttribute("IVSToken");
        String reportName = selectedReport.getReports().getName();

        try{
            adminService.notifyRecipientsEmailListChange(selectedAutoSponsorId, username, reportName, recipientEmailAddresses);
        } catch(Exception e ){
            CustomLogger.error(this.getClass(),"Error occurred while sending email notification to Sponsor Report automatic recipients upon Sponsor_Reports table update.", e);
        }    
    }
    
    public void cancelEditRemoveEmailList() {
        CustomLogger.enter(this.getClass());
        
        manageAutoFormPanelDisplay(EVENT_NAME_CANCELEDITAUTOFORM);
    }
    
    public void resetAutoForm() {
        CustomLogger.enter(this.getClass());
    
        autoEmailList.clear();
        loadAutoEmailControls();
        
        setSelectedAutoSponsorId(0L);
        setSelectedAutoReportId(0L);            

        manageAutoFormPanelDisplay(EVENT_NAME_RESETAUTOFORM);
    }
    
    public void addAutoEmailField() {
        CustomLogger.enter(this.getClass());
        
        manageAutoFormPanelDisplay(EVENT_NAME_ADDAUTOEMAILFIELD);
        loadAutoEmailControls();
    }
    
    public void removeAutoEmailField(int index) {
        CustomLogger.enter(this.getClass());
        
        setSelectedAutoEmailIndex(index);
        manageAutoFormPanelDisplay(EVENT_NAME_REMOVEAUTOEMAILFIELD);
        loadAutoEmailControls();
    }
    
    /*************************** Private Methods - Auto Email Update Form ***************************/
    
    private void loadAutoEmailControls() {
        CustomLogger.enter(this.getClass());
        
        if (removeAutoEmailField) {
            List<InputEmailVo> newEmailList = new ArrayList<>();
            int selIndex = getSelectedAutoEmailIndex();
            
            for (InputEmailVo email : autoEmailList) {
                    if (email.getIndex() != selIndex) {
                    newEmailList.add(email);
                }
            }
            
            autoEmailList.clear();
            
            if (!newEmailList.isEmpty()) {
                autoEmailList.addAll(newEmailList);
            }
            else {
                InputEmailVo input = new InputEmailVo();
                int index = autoEmailList.size();
                input.setIndex(index);
                input.setRenderDeleteImg(true);
                autoEmailList.add(input);
            }
            
            setRemoveAutoEmailField(false);
        }
        else if (addAutoEmailField || autoEmailList.isEmpty()) {
            InputEmailVo input = new InputEmailVo();
            int index = autoEmailList.size();
            input.setIndex(index);
            input.setRenderDeleteImg(true);
            setAddAutoEmailField(false);
            autoEmailList.add(input);
        }
    }
    
    private boolean isAutoSponsorReportValuesValid() {
        CustomLogger.enter(this.getClass());
        if (selectedAutoSponsorId == 0L) {
            setAutoErrorMsg(SPONSOR_REQD_MSG); 
            return false;
        }
        else if (selectedAutoReportId == 0L) {
            setAutoErrorMsg(REPORT_TYPE_REQD_MSG); 
            return false;
        }
        else {
    
            selectedReport = adminService.getBySponsorAndReportIds(selectedAutoSponsorId, selectedAutoReportId);
    
            if (selectedReport != null) {    
                selectedSponsorName = selectedReport.getSponsor().getSponsorName();
                selectedReportName = selectedReport.getReports().getName();

                setAutoErrorMsg(String.format("A record with the Sponsor:%s and Report:%s is already exist. Please select another one.", 
                        selectedSponsorName, selectedReportName));
                
                return false;
            }
        }

        if (!autoEmailList.isEmpty()) {
            int emailCtr = 0;
            for(InputEmailVo input : autoEmailList) {
                String email = input.getEmailAddress();

                if (!StringUtils.isEmpty(email)) {
                    boolean isValidEmailAddress = Utils.isValidEmailAddress(email);
                    
                    if (!isValidEmailAddress) {
                        setAutoErrorMsg(String.format(INVALID_EMAIL_ADDR_MSG_FMT, email)); 
                        return false;
                    }
                
                    emailCtr++;
                }    
            }    

            if (emailCtr == 0) {
                setAutoErrorMsg(EMAIL_ADDR_REQD_MSG); 
                return false;
            }
        }
        else {
            setAutoErrorMsg(EMAIL_ADDR_REQD_MSG); 
            return false;
        }    

        return true;
    }
    
    private boolean isAutoEmailValuesValid() {
        CustomLogger.enter(this.getClass());
        
        setAutoErrorMsg("");

        if (!autoEmailList.isEmpty()) {
            int emailCtr = 0;
            for(InputEmailVo input : autoEmailList) {
                String email = input.getEmailAddress();

                if (!StringUtils.isEmpty(email)) {
                    boolean isValidEmailAddress = Utils.isValidEmailAddress(email);
                    
                    if (!isValidEmailAddress) {
                        setAutoErrorMsg(String.format(INVALID_EMAIL_ADDR_MSG_FMT, email)); 
                        return false;
                    }
                
                    emailCtr++;
                }    
            }    

            if (emailCtr == 0) {
                setAutoErrorMsg(EMAIL_ADDR_REQD_MSG); 
                return false;
            }
        }
        else {
            setAutoErrorMsg(EMAIL_ADDR_REQD_MSG); 
            return false;
        }    

        return true;
    }
    
    private void initAutoMessageDisplay() {
        CustomLogger.enter(this.getClass());
        
        setAutoErrorMsg("");
        setAutoWarnMsg("");
        setAutoInfoMsg("");
        
        setShowAutoErrorMsg(false);
        setShowAutoWarnMsg(false);
        setShowAutoInfoMsg(false);
    }
    
    private void initAutoButtonDisplay() {
        CustomLogger.enter(this.getClass());
        
        setShowEditBtn(true);
        setShowUpdateBtn(false);
        setShowConfirmBtn(false);
        setShowCancelBtn(false);
        setShowAutoResetBtn(true);
    }
    
    private void initAutoInputControl() {
        CustomLogger.enter(this.getClass());
        
        setSelectedAutoSponsorId(0L);
        setSelectedAutoReportId(0L);
        autoEmailList.clear();
        loadAutoEmailControls();
        
        setDisableAutoSponsorSelect(false);
        setDisableAutoReportSelect(false);
        
        setEditSponsorReport(false);
        setDeleteSponsorReport(false);
        
        setAddAutoEmailField(false);
        setAddAdhocEmailField(false);
    }
    
    private void manageAutoFormPanelDisplay(String eventName) {
        CustomLogger.enter(this.getClass());
                
        switch(eventName) {
            case EVENT_NAME_INITLOAD:
                initAutoButtonDisplay();
                break;
            case EVENT_NAME_EDITDELETELOAD:
                setShowAutoResetBtn(true);
                break;    
            case EVENT_NAME_PRESAVEAUTOFORM:
                initAutoButtonDisplay();
                initAutoMessageDisplay();
                setEditSponsorReport(false);
                break;
            case EVENT_NAME_POSTSAVEAUTOFORM:
                setShowAutoInfoMsg(true);
                initAutoButtonDisplay();    
                initAutoInputControl();
                setEditSponsorReport(false);
                setDeleteSponsorReport(false);    
                break;                
            case EVENT_NAME_PREUPDAREAUTOFORM:
                setEditSponsorReport(false);
                setShowCancelBtn(false);
                setShowAutoResetBtn(true);
                setShowUpdateBtn(true);
                setShowEditBtn(false);
                break;
            case EVENT_NAME_POSTUPDATEAUTOFORM:
                setShowAutoInfoMsg(true);
                initAutoButtonDisplay();    
                initAutoInputControl();
                setEditSponsorReport(false);
                setDeleteSponsorReport(false);    
                setShowAutoEmailList(false);
                break;
            case EVENT_NAME_EDITAUTOFORM:
                initAutoMessageDisplay();
                setShowUpdateBtn(true);
                setShowEditBtn(false);
                setShowCancelBtn(true);
                setShowAutoResetBtn(false);
                setShowAutoEmailList(true);
                setDisableAutoSponsorSelect(true);
                setDisableAutoReportSelect(true);                
                break;    
            case EVENT_NAME_CANCELEDITAUTOFORM:
                initAutoMessageDisplay();
                initAutoButtonDisplay();    
                initAutoInputControl();
                setEditSponsorReport(false);
                setDeleteSponsorReport(false);
                setShowAutoEmailList(false);
                break;    
            case EVENT_NAME_REMOVEAUTOFORM:
                setShowEditBtn(false);
                setShowUpdateBtn(false);
                setShowConfirmBtn(true);
                setShowCancelBtn(true);
                setShowAutoResetBtn(false);
                setShowAutoWarnMsg(true);
                setDisableAutoSponsorSelect(true);
                setDisableAutoReportSelect(true);
                setDeleteSponsorReport(true);
                setShowAutoEmailList(false);
                break;    
            case EVENT_NAME_COMMITREMOVEAUTOFORM:    
                initAutoButtonDisplay();
                setShowAutoWarnMsg(false);
                setShowAutoInfoMsg(true);
                setDisableAutoSponsorSelect(false);
                setDisableAutoReportSelect(false);
                setDeleteSponsorReport(false);
                initAutoInputControl();
                break;    
            case EVENT_NAME_CANCELREMOVEAUTOFORM:
                initAutoInputControl();
                setEditSponsorReport(false);
                setDeleteSponsorReport(false);    
                setShowConfirmBtn(false);
                setShowCancelBtn(false);
                break;        
            case EVENT_NAME_RESETAUTOFORM:    
                initAutoMessageDisplay();
                initAutoInputControl();            
                break;                        
            case EVENT_NAME_ADDAUTOEMAILFIELD:
                initAutoMessageDisplay();
                setAddAutoEmailField(true);
                setRemoveAutoEmailField(false);
                break;    
            case EVENT_NAME_REMOVEAUTOEMAILFIELD:
                initAutoMessageDisplay();
                setAddAutoEmailField(false);
                setRemoveAutoEmailField(true);
                break;
            default:
        }
    }
    
    /*************************** Public Event Methods - Adhoc Report Generation Form ***************************/
    
    public void generateReport() {
        CustomLogger.enter(this.getClass());
        
        manageAdhocFormPanelDisplay("PreGenerateReport");
            
        if (!isFormAdhocValuesValid()) {
            setShowAdhocErrorMsg(true);
            return;
        }
        
        String sponsorId = String.valueOf(selectedAdhocSponsorId);
        String reportId =  String.valueOf(selectedAdhocReportId); 
        
        String startDateStr = new SimpleDateFormat(FORMAT_MMDDYYYY).format(this.startDate); 
        String endDateStr = new SimpleDateFormat(FORMAT_MMDDYYYY).format(this.endDate); 
        
        StringBuilder emailSb = new StringBuilder();

        for(InputEmailVo vo : adhocEmailList) {
            emailSb.append(emailSb.length() == 0? "" : ";");
            
            if (!emailSb.toString().contains(vo.getEmailAddress())) {
                emailSb.append(vo.getEmailAddress());
            }    
        }
                
        String recipientEmailAddresses = emailSb.toString();
        String errorMessage = generateAgencyReport(sponsorId, reportId, startDateStr, endDateStr, recipientEmailAddresses);    
        
        if (!StringUtils.isEmpty(errorMessage)) {
            CustomLogger.error(this.getClass(), String.format("Failed report %s with sponsorId:%s and reportId:%s", errorMessage, sponsorId, reportId));
        }
        else {
            setAdhocInfoMsg("Sponsor Report was successfully generated and sent to the recipients."); 
            setShowAdhocInfoMsg(true);            
        }
        
        manageAdhocFormPanelDisplay("PostGenerateReport");
    }
    
    public void loadAdhocReportList(ValueChangeEvent vcEvent) {
        CustomLogger.enter(this.getClass());
        
        long sponsorId = ((Long)vcEvent.getNewValue()).longValue();
        setSelectedAutoSponsorId(sponsorId);
        
     
        RefSponsor sponsor = refSponsorDataService.findByPK(sponsorId);
			
        if ("Y".equalsIgnoreCase(sponsor.getIppClientActive())) {
        	adhocReportList = adminService.findReportsForIppClientActiveSponsor();
        }
        else {
        	adhocReportList = adminService.findBySponsor(sponsorId);
        }
    }
    
    public void addAdhocEmailField() {
        CustomLogger.enter(this.getClass());
        
        manageAdhocFormPanelDisplay("AddAdhocEmailField");
        loadAdhocEmailControls();
    }
    
    public void removeAdhocEmailField(int index) {
        CustomLogger.enter(this.getClass());
        
        setSelectedAdhocEmailIndex(index);
        manageAdhocFormPanelDisplay("RemoveAdhocEmailField");
        loadAdhocEmailControls();
    }
    
    public void resetAdhocForm() {
        CustomLogger.enter(this.getClass());
                
        manageAdhocFormPanelDisplay("resetAdhocForm");
    }
    
    
    /*************************** Private Methods - Adhoc Report Generation Form ***************************/

    private String generateAgencyReport(String sponsorId, String reportId, String startDate, String endDate, String recipientEmailAddresses) {
        CustomLogger.enter(this.getClass());
        
        if (!isFormAdhocValuesValid()) {
            setShowAdhocErrorMsg(true);
            return "";
        }
        

        ReportRequest reportRequest = new ReportRequest();
        reportRequest.setReportID(Integer.parseInt(reportId));
        reportRequest.setSponsorID(Integer.parseInt(sponsorId));
        reportRequest.setStartDate(startDate);
        reportRequest.setEndDate(endDate);
        reportRequest.setEmailAddress(recipientEmailAddresses);
        
        String response = "";
        try {
            response = adminService.generateAgencyReport(reportRequest);
        }
        catch (Exception e) {
            setAutoErrorMsg("Error occurred in generating and sending Sponsor Report."); 
            setShowAdhocErrorMsg(true);
        }
        
        SponsorReports sponsorReport = adminService.getBySponsorAndReportIds(Long.parseLong(sponsorId), Long.parseLong(reportId));
        if (sponsorReport == null) {
        	RefSponsor sponsor = refSponsorDataService.findByPK(Long.parseLong(sponsorId));
        	createSponsorReports(sponsor, Long.parseLong(reportId), recipientEmailAddresses); 
        }

        return response;
    }
    
    private boolean isFormAdhocValuesValid() {
        CustomLogger.enter(this.getClass());
        
        boolean isValuesValid = true;
        setAdhocErrorMsg("");
        
        SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_MMDDYYYY);            
        DateFormat dateFormat = new SimpleDateFormat(FORMAT_MMDDYYYY);             

        if (startDate == null) {
            setAdhocErrorMsg("Start Date is required. Please select a start date."); 
            isValuesValid = false;
        }
        else {
             try {
                String strDate = dateFormat.format(startDate); 
                sdf.parse(strDate);
            }
            catch (Exception e) {
                setAdhocErrorMsg("Start Date has invalid value. Please enter a valid start date."); 
                isValuesValid = false;
            }
        }
        
        if (isValuesValid) {
            if (endDate == null) {
                setAdhocErrorMsg("End Date is required. Please select a end date."); 
                isValuesValid = false;
            }
            else {
                try {
                    String strDate = dateFormat.format(endDate); 
                    sdf.parse(strDate);
                }
                catch (Exception e) {
                    setAdhocErrorMsg("End Date has invalid value. Please enter a valid End Date."); 
                    isValuesValid = false;
                }
            }    
        }

        if (isValuesValid) {
            //The date range that the report service will use is midnight on the start date through 11:59:59 pm on the end date.
             
            this.startDate = getModifiedDate(this.startDate, 0, 0, 0, 0);
            this.endDate = getModifiedDate(this.endDate, 23, 59, 59, 999);
            Date currentEndDate = getModifiedDate(DateTimeUtil.getCurrentDate(), 24, 0, 0, 0);
            Date minStartDate = getModifiedDate(DateTimeUtil.getDatePlusDays(this.endDate, -31), 0, 0, 0, 0);
            
            if (!minStartDate.equals(this.startDate) && this.startDate.before(minStartDate)) {
                setAdhocErrorMsg("Start Date must be within 31 days before End Date."); 
                isValuesValid = false;
            }
            else if (currentEndDate.before(this.startDate) || currentEndDate.before(this.endDate)) {
                setAdhocErrorMsg("Start Date and End Date must not be a future date."); 
                isValuesValid = false;
            }
            else if (this.endDate.before(this.startDate) || this.endDate.equals(this.startDate)) {
                setAdhocErrorMsg("Start Date must be before End Date."); 
                isValuesValid = false;
            }
        }

        if (isValuesValid) {
            if (selectedAdhocSponsorId == 0L) {
                setAdhocErrorMsg(SPONSOR_REQD_MSG); 
                isValuesValid = false;
            }
            else if (selectedAdhocReportId == 0L) {
                setAdhocErrorMsg(REPORT_TYPE_REQD_MSG); 
                isValuesValid = false;
            }
            else {
                if (!adhocEmailList.isEmpty()) {
                    int emailCtr = 0;
                    for(InputEmailVo input : adhocEmailList) {
                        String email = input.getEmailAddress();

                        if (!StringUtils.isEmpty(email)) {
                            boolean isValidEmailAddress = Utils.isValidEmailAddress(email);
                            
                            if (!isValidEmailAddress) {
                                setAdhocErrorMsg(String.format(INVALID_EMAIL_ADDR_MSG_FMT, email)); 
                                isValuesValid = false;
                            }
                        
                            emailCtr++;
                        }    
                    }    

                    if (emailCtr == 0) {
                        setAdhocErrorMsg(EMAIL_ADDR_REQD_MSG); 
                        isValuesValid = false;
                    }
                }
                else {
                    setAdhocErrorMsg(EMAIL_ADDR_REQD_MSG); 
                    isValuesValid = false;
                }    
            }
        }
        
        return isValuesValid;
    }
    
    private void loadAdhocEmailControls() {
        CustomLogger.enter(this.getClass());
        
        if (removeAdhocEmailField) {
            List<InputEmailVo> newEmailList = new ArrayList<>();
            int selIndex = getSelectedAdhocEmailIndex();
            
            for (InputEmailVo email : adhocEmailList) {
                    if (email.getIndex() != selIndex) {
                    newEmailList.add(email);
                }
            }
            
            adhocEmailList.clear();
            
            if (!newEmailList.isEmpty()) {
                adhocEmailList.addAll(newEmailList);
            }
            else {
                InputEmailVo input = new InputEmailVo();
                int index = adhocEmailList.size();
                input.setIndex(index);
                input.setRenderDeleteImg(true);
                adhocEmailList.add(input);
            }
            
            setRemoveAdhocEmailField(false);
        }
        else if (addAdhocEmailField || adhocEmailList.isEmpty()) {
            InputEmailVo input = new InputEmailVo();
            int index = adhocEmailList.size();
            input.setIndex(index);
            input.setRenderDeleteImg(true);
            setAddAdhocEmailField(false);
            adhocEmailList.add(input);
        }
    }
    
    private void initAdhocMessageDisplay() {
        CustomLogger.enter(this.getClass());
        
        setAdhocErrorMsg("");
        setAdhocInfoMsg("");
        
        setShowAdhocErrorMsg(false);
        setShowAdhocInfoMsg(false);
    }
    
    private void initAdhocInputControl() {
        CustomLogger.enter(this.getClass());
        
        this.endDate =  DateTimeUtil.getCurrentDate();
        this.startDate = DateTimeUtil.getDatePlusDays(this.endDate, -31);

        setSelectedAdhocSponsorId(0L);
        setSelectedAdhocReportId(0L);
        
        adhocEmailList.clear();
        loadAdhocEmailControls();
    }
    
    private void manageAdhocFormPanelDisplay(String eventName) {
        CustomLogger.enter(this.getClass());
        
        switch(eventName) {
            case "PreGenerateReport":
                initAdhocMessageDisplay();
                setShowAdhocErrorMsg(false);
                break;
            case "PostGenerateReport":
                setShowAdhocErrorMsg(false);
                initAdhocInputControl();
                break;
            case "AddAdhocEmailField":
                setAddAdhocEmailField(true);
                setRemoveAdhocEmailField(false);
                break;    
            case "RemoveAdhocEmailField":
                setRemoveAdhocEmailField(true);
                setAddAdhocEmailField(false);
                break;
            case "resetAdhocForm":
                initAdhocMessageDisplay();
                initAdhocInputControl();
                break;    
            default:
        }
    }
    
    private Date getModifiedDate(Date date, int hour, int minute, int second, int msecond) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, second);  
        cal.set(Calendar.MILLISECOND, msecond);          
        return cal.getTime();        
    }
    
    private void createSponsorReports(RefSponsor sponsor, long reportId, String recipientEmailAddresses) {
		if (CONST_VALUE_Y.equalsIgnoreCase(sponsor.getIppClientActive())) {
			try {

				RefReports report = adminService.getRefReportsById(reportId);
				SponsorReports sponsorReport = new SponsorReports();
				sponsorReport.setReports(report);
				sponsorReport.setSponsor(sponsor);
				sponsorReport.setRecipientEmailAddresses(recipientEmailAddresses);
				sponsorReport.setCreateDate(new Date());

				adminService.createSponsorReports(sponsorReport);
			} catch (Exception e) {
				String errMsg = "Exception occurred creating new sponsor reports";
				CustomLogger.error(this.getClass(), errMsg, e);
			}
		}
	}
    
    /*************************** Properties Getters/Setters ***************************/
    
    public List<RefSponsor> getSponsorList() {
        return sponsorList;
    }

    public void setSponsorList(List<RefSponsor> sponsorList) {
        this.sponsorList = sponsorList;
    }

    public long getSelectedAutoSponsorId() {
        return selectedAutoSponsorId;
    }

    public void setSelectedAutoSponsorId(long selectedAutoSponsorId) {
        this.selectedAutoSponsorId = selectedAutoSponsorId;
    }

    public long getSelectedAutoReportId() {
        return selectedAutoReportId;
    }

    public void setSelectedAutoReportId(long selectedAutoReportId) {
        this.selectedAutoReportId = selectedAutoReportId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public List<RefReports> getAutoReportList() {
        return autoReportList;
    }

    public void setAutoReportList(List<RefReports> autoReportList) {
        this.autoReportList = autoReportList;
    }
    
    public List<RefReports> getAdhocReportList() {
        return adhocReportList;
    }

    public void setAdhocReportList(List<RefReports> adhocReportList) {
        this.adhocReportList = adhocReportList;
    }

    public List<InputEmailVo> getAutoEmailList() {
        return autoEmailList;
    }

    public void setAutoEmailList(List<InputEmailVo> autoEmailList) {
        this.autoEmailList = autoEmailList;
    }

    public List<InputEmailVo> getAdhocEmailList() {
        return adhocEmailList;
    }

    public void setAdhocEmailList(List<InputEmailVo> adhocEmailList) {
        this.adhocEmailList = adhocEmailList;
    }

    public List<SponsorReportVo> getSponsorReportList() {
        return sponsorReportList;
    }

    public void setSponsorReportList(List<SponsorReportVo> sponsorReportList) {
        this.sponsorReportList = sponsorReportList;
    }

    public long getSelectedAdhocSponsorId() {
        return selectedAdhocSponsorId;
    }

    public void setSelectedAdhocSponsorId(long selectedAdhocSponsorId) {
        this.selectedAdhocSponsorId = selectedAdhocSponsorId;
    }

    public long getSelectedAdhocReportId() {
        return selectedAdhocReportId;
    }

    public void setSelectedAdhocReportId(long selectedAdhocReportId) {
        this.selectedAdhocReportId = selectedAdhocReportId;
    }

    public int getSelectedAutoEmailIndex() {
        return selectedAutoEmailIndex;
    }

    public void setSelectedAutoEmailIndex(int selectedAutoEmailIndex) {
        this.selectedAutoEmailIndex = selectedAutoEmailIndex;
    }

    public int getSelectedAdhocEmailIndex() {
        return selectedAdhocEmailIndex;
    }

    public void setSelectedAdhocEmailIndex(int selectedAdhocEmailIndex) {
        this.selectedAdhocEmailIndex = selectedAdhocEmailIndex;
    }

    public boolean isRemoveAutoEmailField() {
        return removeAutoEmailField;
    }

    public void setRemoveAutoEmailField(boolean removeAutoEmailField) {
        this.removeAutoEmailField = removeAutoEmailField;
    }

    public boolean isRemoveAdhocEmailField() {
        return removeAdhocEmailField;
    }

    public void setRemoveAdhocEmailField(boolean removeAdhocEmailField) {
        this.removeAdhocEmailField = removeAdhocEmailField;
    }

    public boolean isAddAutoEmailField() {
        return addAutoEmailField;
    }

    public void setAddAutoEmailField(boolean addAutoEmailField) {
        this.addAutoEmailField = addAutoEmailField;
    }

    public boolean isAddAdhocEmailField() {
        return addAdhocEmailField;
    }

    public void setAddAdhocEmailField(boolean addAdhocEmailField) {
        this.addAdhocEmailField = addAdhocEmailField;
    }

    public boolean isEditSponsorReport() {
        return editSponsorReport;
    }

    public void setEditSponsorReport(boolean editSponsorReport) {
        this.editSponsorReport = editSponsorReport;
    }

    public boolean isDeleteSponsorReport() {
        return deleteSponsorReport;
    }

    public void setDeleteSponsorReport(boolean deleteSponsorReport) {
        this.deleteSponsorReport = deleteSponsorReport;
    }

    public SponsorReports getSelectedReport() {
        return selectedReport;
    }

    public void setSelectedReport(SponsorReports selectedReport) {
        this.selectedReport = selectedReport;
    }

    public boolean isShowEditBtn() {
        return showEditBtn;
    }

    public void setShowEditBtn(boolean showEditBtn) {
        this.showEditBtn = showEditBtn;
    }

    public boolean isShowUpdateBtn() {
        return showUpdateBtn;
    }

    public void setShowUpdateBtn(boolean showUpdateBtn) {
        this.showUpdateBtn = showUpdateBtn;
    }

    public boolean isShowConfirmBtn() {
        return showConfirmBtn;
    }

    public void setShowConfirmBtn(boolean showConfirmBtn) {
        this.showConfirmBtn = showConfirmBtn;
    }

    public String getSelectedSponsorName() {
        return selectedSponsorName;
    }

    public void setSelectedSponsorName(String selectedSponsorName) {
        this.selectedSponsorName = selectedSponsorName;
    }

    public String getSelectedReportName() {
        return selectedReportName;
    }

    public void setSelectedReportName(String selectedReportName) {
        this.selectedReportName = selectedReportName;
    }

    public boolean isShowCancelBtn() {
        return showCancelBtn;
    }

    public void setShowCancelBtn(boolean showCancelBtn) {
        this.showCancelBtn = showCancelBtn;
    }
    
    public boolean isShowAutoEmailList() {
        return showAutoEmailList;
    }

    public void setShowAutoEmailList(boolean showAutoEmailList) {
        this.showAutoEmailList = showAutoEmailList;
    }

    public boolean isShowAutoResetBtn() {
        return showAutoResetBtn;
    }

    public void setShowAutoResetBtn(boolean showAutoResetBtn) {
        this.showAutoResetBtn = showAutoResetBtn;
    }

    public boolean isShowAdhocResetBtn() {
        return showAdhocResetBtn;
    }

    public void setShowAdhocResetBtn(boolean showAdhocResetBtn) {
        this.showAdhocResetBtn = showAdhocResetBtn;
    }

    public boolean isDisableAutoSponsorSelect() {
        return disableAutoSponsorSelect;
    }

    public void setDisableAutoSponsorSelect(boolean disableAutoSponsorSelect) {
        this.disableAutoSponsorSelect = disableAutoSponsorSelect;
    }

    public boolean isDisableAutoReportSelect() {
        return disableAutoReportSelect;
    }

    public void setDisableAutoReportSelect(boolean disableAutoReportSelect) {
        this.disableAutoReportSelect = disableAutoReportSelect;
    }

    public boolean isShowAutoInfoMsg() {
        return showAutoInfoMsg;
    }

    public void setShowAutoInfoMsg(boolean showAutoInfoMsg) {
        this.showAutoInfoMsg = showAutoInfoMsg;
    }

    public boolean isShowAutoWarnMsg() {
        return showAutoWarnMsg;
    }

    public void setShowAutoWarnMsg(boolean showAutoWarnMsg) {
        this.showAutoWarnMsg = showAutoWarnMsg;
    }

    public boolean isShowAutoErrorMsg() {
        return showAutoErrorMsg;
    }

    public void setShowAutoErrorMsg(boolean showAutoErrorMsg) {
        this.showAutoErrorMsg = showAutoErrorMsg;
    }

    public boolean isShowAdhocInfoMsg() {
        return showAdhocInfoMsg;
    }

    public void setShowAdhocInfoMsg(boolean showAdhocInfoMsg) {
        this.showAdhocInfoMsg = showAdhocInfoMsg;
    }

    public boolean isShowAdhocWarnMsg() {
        return showAdhocWarnMsg;
    }

    public void setShowAdhocWarnMsg(boolean showAdhocWarnMsg) {
        this.showAdhocWarnMsg = showAdhocWarnMsg;
    }

    public boolean isShowAdhocErrorMsg() {
        return showAdhocErrorMsg;
    }

    public void setShowAdhocErrorMsg(boolean showAdhocErrorMsg) {
        this.showAdhocErrorMsg = showAdhocErrorMsg;
    }

    public String getAutoErrorMsg() {
        return autoErrorMsg;
    }

    public void setAutoErrorMsg(String autoErrorMsg) {
        this.autoErrorMsg = autoErrorMsg;
    }

    public String getAutoWarnMsg() {
        return autoWarnMsg;
    }

    public void setAutoWarnMsg(String autoWarnMsg) {
        this.autoWarnMsg = autoWarnMsg;
    }

    public String getAutoInfoMsg() {
        return autoInfoMsg;
    }

    public void setAutoInfoMsg(String autoInfoMsg) {
        this.autoInfoMsg = autoInfoMsg;
    }

    public String getAdhocErrorMsg() {
        return adhocErrorMsg;
    }

    public void setAdhocErrorMsg(String adhocErrorMsg) {
        this.adhocErrorMsg = adhocErrorMsg;
    }

    public String getAdhocWarnMsg() {
        return adhocWarnMsg;
    }

    public void setAdhocWarnMsg(String adhocWarnMsg) {
        this.adhocWarnMsg = adhocWarnMsg;
    }

    public String getAdhocInfoMsg() {
        return adhocInfoMsg;
    }

    public void setAdhocInfoMsg(String adhocInfoMsg) {
        this.adhocInfoMsg = adhocInfoMsg;
    }

    public boolean isInitialized() {
        return initialized;
    }

    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }
}
