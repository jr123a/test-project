package com.ips.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.SpringUtil;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.exception.IPSException;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;
import com.ips.service.RefSponsorConfigurationService;

@ManagedBean(name = "analyticsAdmin")
@ViewScoped
public class AnalyticsAdminBean extends IPSAdminController implements Serializable {
	private static final long serialVersionUID = 1L;

	private Map<String, Boolean> booleanPropertyMapping;
	private List<TableObject> tableValues;
	private static final String DEFAULT_THRESHOLD_VALUE = "30";
	private static final String DEFAULT_RETENTION_VALUE = "180";
	private static final String THRESHOLD_ANALYTICS_NAME = "Adjustable Threshold for High Risk Address";
	private static final String RETENTION_PERIOD_ANALYTICS_NAME = "Adjustable Retention Period for High Risk Address";
	private RefSponsorConfiguration refSponsorConfig = new RefSponsorConfiguration();
	private boolean enter = true;
	private static final String THRESHOLD_CHANGE = "thresholdChange";
	private static final String THRESHOLD = "threshold";
	private static final String RETENTION_CHANGE = "retentionChange";
	private static final String RETENTION = "retention";
	private static final String SUCCESS = "success";
	private static final String ERROR = "error";
	private static final String EMAIL_ERROR = "emailError";
	private static final String DATABASE_ERROR = "databaseError";
	private static final String CURRENT_VALUE_UNIT = " Days";
	private static final String SPONSOR_CONFIG_DB_ERROR = "Error occurred while attempting to retrieve sponsor configurations from database.";
	private static final String NO_VALUE_IN_TABLE = "Unable to find High Risk Address Value in table.";
	private static final String UPDATE_HIGH_RISK = "Updating High Risk Address Threshold from ";
	private static final String UPDATE_HIGH_RISK_RETENTION = "Updating High Risk Address Retention Period from ";
	private static final String INVALID_USER = "Invalid username supplied, High Risk Address values not updated: ";
	private static final String EMAIL_GEN_ERROR = "Error occurred while generating notification email";
	private static final String DB_UPDATE_ERROR = "Error occurred trying to update an Analytics value";
	private static final String REF_SPONSOR_CONFIG_SERVICE_BEAN = "refSponsorConfigurationService";
	private static final String ADMIN_SERVICE_BEAN = "AdminService";

	private boolean activateHighRisk;
	private boolean activationChange = false;

	@PostConstruct
	public void init() {

		CustomLogger.enter(this.getClass());
		if (enter) {
			booleanPropertyMapping = buildMap();
			tableValues = buildTableValues();
			activateHighRisk = getHighRiskValue();
		}
		enter = false;
	}

	private boolean getHighRiskValue() {
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		RefSponsorConfigurationService refSponsorConfigService = (RefSponsorConfigurationService) SpringUtil
				.getInstance(ctx).getBean(REF_SPONSOR_CONFIG_SERVICE_BEAN);

		RefSponsorConfiguration spConfig = refSponsorConfigService.getConfigRecord(1,
				RefSponsorConfiguration.HIGH_RISK_ACTIVATION);
		return "True".equalsIgnoreCase(spConfig.getValue());
	}

	private Map<String, Boolean> buildMap() {
		CustomLogger.enter(this.getClass());
		booleanPropertyMapping = new HashMap<>();
		booleanPropertyMapping.put(THRESHOLD_CHANGE, false);
		booleanPropertyMapping.put(RETENTION_CHANGE, false);
		booleanPropertyMapping.put(SUCCESS, false);
		booleanPropertyMapping.put(ERROR, false);
		booleanPropertyMapping.put(EMAIL_ERROR, false);
		booleanPropertyMapping.put(DATABASE_ERROR, false);
		return booleanPropertyMapping;
	}

	private List<TableObject> buildTableValues() {
		tableValues = new ArrayList<>();
		List<RefSponsorConfiguration> configs = new ArrayList<>();

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		RefSponsorConfigurationService refSponsorConfigService = (RefSponsorConfigurationService) SpringUtil
				.getInstance(ctx).getBean(REF_SPONSOR_CONFIG_SERVICE_BEAN);

		try {
			configs.add(refSponsorConfigService.getConfigRecord(1, RefSponsorConfiguration.HIGH_RISK_THRESHOLD));
			configs.add(
					refSponsorConfigService.getConfigRecord(1, RefSponsorConfiguration.RISK_ADDRESS_RETENTION_PERIOD));
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), SPONSOR_CONFIG_DB_ERROR, e);
		}

		if (configs.isEmpty()) {
			setDatabaseError(true);
			Collections.emptyList();
		}

		configs.removeIf(config -> config == null);

		configs.forEach(config -> {
			TableObject obj = null;

			if (RefSponsorConfiguration.HIGH_RISK_THRESHOLD.equalsIgnoreCase(config.getName())) {
				obj = new TableObject();
				obj.setName(THRESHOLD_ANALYTICS_NAME);
			} else if (RefSponsorConfiguration.RISK_ADDRESS_RETENTION_PERIOD.equalsIgnoreCase(config.getName())) {
				obj = new TableObject();
				obj.setName(RETENTION_PERIOD_ANALYTICS_NAME);
			}

			if (obj != null) {
				obj.setSponsorId(config.getSponsorId());
				obj.setConfigurationId(config.getConfigurationId());
				obj.setCreateDate(config.getCreateDate());

				if (!StringUtils.isEmpty(config.getValue()) && StringUtils.isNumeric(config.getValue())) {
					CustomLogger.debug(this.getClass(),
							"Value retrieved from database: " + config.getValue() + " days");
					obj.setCurrentValue(config.getValue() + CURRENT_VALUE_UNIT);
				} else {
					if (RefSponsorConfiguration.RISK_ADDRESS_RETENTION_PERIOD.equalsIgnoreCase(config.getName())) {
						obj.setCurrentValue(DEFAULT_RETENTION_VALUE + CURRENT_VALUE_UNIT);
						obj.setNewValue(DEFAULT_RETENTION_VALUE);
					} else if (RefSponsorConfiguration.HIGH_RISK_THRESHOLD.equalsIgnoreCase(config.getName())) {
						obj.setCurrentValue(DEFAULT_THRESHOLD_VALUE + CURRENT_VALUE_UNIT);
						obj.setNewValue(DEFAULT_THRESHOLD_VALUE);
					}

					refSponsorConfig = updateConfiguration(obj);
				}

				obj.setNewValue(null);

				tableValues.add(obj);
			}
		});

		return tableValues;
	}

	public void change() {
		clear();

		if (isActivateHighRisk() != getHighRiskValue()) {
			setActivationChange(true);
		}

		getTableValues().forEach(value -> {
			if (value != null && !StringUtils.isEmpty(value.getNewValue())
					&& StringUtils.isNumeric(value.getNewValue())) {
				if (THRESHOLD_ANALYTICS_NAME.equalsIgnoreCase(value.getName())) {
					setThresholdChangeConfirm(true);
				} else if (RETENTION_PERIOD_ANALYTICS_NAME.equalsIgnoreCase(value.getName())) {
					setRetentionChangeConfirm(true);
				}
			}
		});
	}

	public void confirm() {
		try {
			HttpServletRequest hsr = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();
			String username = (String) hsr.getSession().getAttribute("IVSToken");

			if (!StringUtils.isAlphanumeric(username)) {
				CustomLogger.error(this.getClass(), INVALID_USER + username);
				setError(true);
				return;
			}

			if (isThresholdChangeConfirm()) {
				changeAnalyticsValue(THRESHOLD, username);
			}

			if (isRetentionChangeConfirm()) {
				changeAnalyticsValue(RETENTION, username);
			}

			if (isActivationChange()) {
				changeHighRiskActivation(username);
			}
		} catch (IPSException e) {
			CustomLogger.error(this.getClass(), EMAIL_GEN_ERROR, e);
			setEmailError(true);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), DB_UPDATE_ERROR, e);
			setError(true);
		}
	}

	private void changeHighRiskActivation(String username) throws IPSException {
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		RefSponsorConfigurationService refSponsorConfigService = (RefSponsorConfigurationService) SpringUtil
				.getInstance(ctx).getBean(REF_SPONSOR_CONFIG_SERVICE_BEAN);

		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService service = webAppContext.getBean("AdminService", AdminServiceImpl.class);
			RefSponsorConfiguration spConfig = refSponsorConfigService.getConfigRecord(1,
					RefSponsorConfiguration.HIGH_RISK_ACTIVATION);
			spConfig.setValue(activateHighRisk ? "True" : "False");
			spConfig.setUpdateDate(new Date());
			CustomLogger.debug(this.getClass(),
					"Changing activation from " + getHighRiskValue() + " to " + (activateHighRisk ? "True" : "False"));
			try {
				refSponsorConfigService.update(spConfig);
			} catch (Exception e) {
				setDatabaseError(true);
				CustomLogger.error(this.getClass(), DB_UPDATE_ERROR, e);
			}

			setSuccess(true);
			setActivationChange(false);

			service.notifyRiskAddresshActivationChange(spConfig, username);

		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void changeAnalyticsValue(String valueType, String username) throws IPSException {
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
        if (webAppContext != null) {
		AdminService service = webAppContext.getBean("AdminService", AdminServiceImpl.class);

		TableObject obj = null;

		if (THRESHOLD.equalsIgnoreCase(valueType)) {
			obj = getTableValues().stream().filter(value -> THRESHOLD_ANALYTICS_NAME.equalsIgnoreCase(value.getName()))
					.findFirst().orElse(null);
		} else if (RETENTION.equalsIgnoreCase(valueType)) {
			obj = getTableValues().stream()
					.filter(value -> RETENTION_PERIOD_ANALYTICS_NAME.equalsIgnoreCase(value.getName())).findFirst()
					.orElse(null);
		}

		if (obj == null) {
			CustomLogger.error(this.getClass(), NO_VALUE_IN_TABLE);
			setError(true);
			return;
		}

		if (THRESHOLD.equalsIgnoreCase(valueType)) {
			CustomLogger.debug(this.getClass(),
					UPDATE_HIGH_RISK + obj.getCurrentValue() + " to " + obj.getNewValue() + CURRENT_VALUE_UNIT);
		} else if (RETENTION.equalsIgnoreCase(valueType)) {
			CustomLogger.debug(this.getClass(), UPDATE_HIGH_RISK_RETENTION + obj.getCurrentValue() + " to "
					+ obj.getNewValue() + CURRENT_VALUE_UNIT);
		}
		try {
			refSponsorConfig = updateConfiguration(obj);
		} catch (Exception e) {
			setDatabaseError(true);
			CustomLogger.error(this.getClass(), DB_UPDATE_ERROR, e);
		}

		setSuccess(true);

		obj.setCurrentValue(obj.getNewValue() + CURRENT_VALUE_UNIT);
		obj.setNewValue(null);
		tableValues.set(tableValues.indexOf(obj), obj);

		if (THRESHOLD.equalsIgnoreCase(valueType)) {
			setThresholdChangeConfirm(false);
		} else if (RETENTION.equalsIgnoreCase(valueType)) {
			setRetentionChangeConfirm(false);
		}

		service.notifyAnalyticsChange(refSponsorConfig, username);
        } else {
            CustomLogger.error(this.getClass(), "Error: WebApplicationContext is null. Unable to retrieve AdminService.");
            goToPage(SYSTEM_ERROR_PAGE); 
        }
	}

	public void cancel() {
		clear();
		setActivateHighRisk(getHighRiskValue());
	}

	private void clear() {
		setThresholdChangeConfirm(false);
		setRetentionChangeConfirm(false);
		setError(false);
		setEmailError(false);
		setSuccess(false);
		setDatabaseError(false);
		setActivationChange(false);
	}

	private RefSponsorConfiguration updateConfiguration(TableObject obj) {
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		RefSponsorConfigurationService refSponsorConfigService = (RefSponsorConfigurationService) SpringUtil
				.getInstance(ctx).getBean(REF_SPONSOR_CONFIG_SERVICE_BEAN);

		if (THRESHOLD_ANALYTICS_NAME.equalsIgnoreCase(obj.getName())) {
			refSponsorConfig.setName(RefSponsorConfiguration.HIGH_RISK_THRESHOLD);
		} else if (RETENTION_PERIOD_ANALYTICS_NAME.equalsIgnoreCase(obj.getName())) {
			refSponsorConfig.setName(RefSponsorConfiguration.RISK_ADDRESS_RETENTION_PERIOD);
		}

		refSponsorConfig.setConfigurationId(obj.getConfigurationId());
		refSponsorConfig.setSponsorId(obj.getSponsorId());
		refSponsorConfig.setCreateDate(obj.getCreateDate());
		refSponsorConfig.setValue(obj.getNewValue());
		refSponsorConfig.setUpdateDate(new Date());
		refSponsorConfigService.update(refSponsorConfig);

		return refSponsorConfig;
	}

	public String getThresholdValue() {
		return getTableValues().stream().filter(value -> THRESHOLD_ANALYTICS_NAME.equalsIgnoreCase(value.getName()))
				.findFirst().orElse(new TableObject()).getNewValue();
	}

	public String getRetentionValue() {
		return getTableValues().stream()
				.filter(value -> RETENTION_PERIOD_ANALYTICS_NAME.equalsIgnoreCase(value.getName())).findFirst()
				.orElse(new TableObject()).getNewValue();
	}

	public boolean isThresholdChangeConfirm() {
		return getBooleanPropertyMapping().get(THRESHOLD_CHANGE);
	}

	public void setThresholdChangeConfirm(boolean thresholdChangeConfirm) {
		getBooleanPropertyMapping().replace(THRESHOLD_CHANGE, thresholdChangeConfirm);
	}

	public boolean isRetentionChangeConfirm() {
		return getBooleanPropertyMapping().get(RETENTION_CHANGE);
	}

	public void setRetentionChangeConfirm(boolean retentionChangeConfirm) {
		getBooleanPropertyMapping().replace(RETENTION_CHANGE, retentionChangeConfirm);
	}

	public boolean isSuccess() {
		return getBooleanPropertyMapping().get(SUCCESS);
	}

	public void setSuccess(boolean success) {
		getBooleanPropertyMapping().replace(SUCCESS, success);
	}

	public boolean isError() {
		return getBooleanPropertyMapping().get(ERROR);
	}

	public void setError(boolean error) {
		getBooleanPropertyMapping().replace(ERROR, error);
	}

	public boolean isEmailError() {
		return getBooleanPropertyMapping().get(EMAIL_ERROR);
	}

	public void setEmailError(boolean emailError) {
		getBooleanPropertyMapping().replace(EMAIL_ERROR, emailError);
	}

	public boolean isDatabaseError() {
		return getBooleanPropertyMapping().get(DATABASE_ERROR);
	}

	public void setDatabaseError(boolean databaseError) {
		getBooleanPropertyMapping().replace(DATABASE_ERROR, databaseError);
	}

	public List<TableObject> getTableValues() {
		return tableValues;
	}

	public void setTableValues(List<TableObject> tableValues) {
		this.tableValues = tableValues;
	}

	private Map<String, Boolean> getBooleanPropertyMapping() {
		return booleanPropertyMapping;
	}

	public class TableObject {
		private String name;
		private String currentValue;
		private String newValue;
		private Long configurationId;
		private Date createDate;
		private Integer sponsorId;

		private TableObject() {
			super();
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getCurrentValue() {
			return currentValue;
		}

		public void setCurrentValue(String currentValue) {
			this.currentValue = currentValue;
		}

		public String getNewValue() {
			return newValue;
		}

		public void setNewValue(String newValue) {
			this.newValue = newValue;
		}

		private Long getConfigurationId() {
			return configurationId;
		}

		private void setConfigurationId(Long configurationId) {
			this.configurationId = configurationId;
		}

		private Date getCreateDate() {
			return createDate;
		}

		private void setCreateDate(Date createDate) {
			this.createDate = createDate;
		}

		private Integer getSponsorId() {
			return sponsorId;
		}

		private void setSponsorId(Integer sponsorId) {
			this.sponsorId = sponsorId;
		}
	}

	public boolean isActivateHighRisk() {
		return activateHighRisk;
	}

	public void setActivateHighRisk(boolean activateHighRisk) {
		this.activateHighRisk = activateHighRisk;
	}

	public boolean isActivationChange() {
		return activationChange;
	}

	public void setActivationChange(boolean activationChange) {
		this.activationChange = activationChange;
	}
}
