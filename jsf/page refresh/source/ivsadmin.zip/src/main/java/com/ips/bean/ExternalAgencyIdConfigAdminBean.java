package com.ips.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.StringJoiner;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.entity.RefPrimaryIdType;
import com.ips.entity.RefSecondaryIdType;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.SponsorStrongId;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;

@ManagedBean(name = "extAgencyIdConfig")
@ViewScoped
public class ExternalAgencyIdConfigAdminBean extends IPSAdminController implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<RefSponsor> sponsorList;
	private long selectedSponsorId = 0L;
	private boolean showInfoMsg;
	private boolean showWarnMsg;
	private boolean showErrorMsg;
	private String errorMsg;
	private String warnMsg;
	private String infoMsg;
	private boolean initialized;
	private List<RefPrimaryIdType> availableIdTypeList;
	private List<RefPrimaryIdType> sponsorAcceptedIdTypeList;
	private List<RefSecondaryIdType> availableSecondaryIdTypeList;
	private List<RefSecondaryIdType> sponsorAcceptedSeconadryIdTypeList;
	private boolean showInitialBtn;
	private boolean showConfirmChangeBtn;
	private List<SponsorStrongId> sponsorStrongIdList;
	private List<RefPrimaryIdType> includedSelectedAvailableIdList;
	private List<RefSecondaryIdType> includedSelectedAvailableSecondaryIdList;
	private boolean includedSelectedStrongIds;
	private boolean removedSelectedStrongIds;
	private boolean includedSelectedFairIds;
	private boolean removedSelectedFairIds;
	private boolean changeMadeInAnyControl;
	private String userId;
	private String externalAgencyName;
	private String includedStrongIdNames;
	private String removedStrongIdNames;

	private boolean showControlPnl;

	private static final String ADMIN_SERVICE = "AdminService";

	public static final String CONFIG_ACCEPTED_ID_LIST_TYPE = "7";

	@PostConstruct
	public void init() {
		CustomLogger.enter(this.getClass());

		if (!initialized) {
			setInitialized(true);
		}

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
				.getRequest();
		setUserId((String) request.getSession().getAttribute("IVSToken"));

		loadSponsorList();
	}

	/*************************** Initialization Methods ***************************/

	public void loadSponsorList() {
		CustomLogger.enter(this.getClass());

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);

			try {
				sponsorList = adminService.getActiveExternalSponsorList();
			} catch (Exception e) {
				CustomLogger.error(this.getClass(), "Exception occurred in loadSponsorList: ", e);
				goToPage(SYSTEM_ERROR_PAGE);
			}

			if (selectedSponsorId == 0) {
				manageFormPanelDisplay("InitLoad");
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}

	}

	public void loadFormControls(ValueChangeEvent vcEvent) {
		CustomLogger.enter(this.getClass());

		selectedSponsorId = ((Long) vcEvent.getNewValue()).longValue();

		loadFormControls();

		RefSponsor selectedSponsor = sponsorList.stream().filter(sponsor -> sponsor.getSponsorId() == selectedSponsorId)
				.findFirst().orElse(null);
		setExternalAgencyName(selectedSponsor != null ? selectedSponsor.getSponsorName() : "");

		manageFormPanelDisplay("OnSponsorSelect");
	}

	/*************************** Public Event Methods ***************************/

	public void change() {
		CustomLogger.enter(this.getClass());

		manageFormPanelDisplay("OnSelectChange");
	}

	public void save() {
		CustomLogger.enter(this.getClass());

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);
			RefSponsorConfiguration primaryIdconfig = adminService.getRefSponsorConfiguration((int) selectedSponsorId,
					RefSponsorConfiguration.IPP_AGENCY_PRIMARY_IDS);
			RefSponsorConfiguration secondaryIdconfig = adminService.getRefSponsorConfiguration((int) selectedSponsorId,
					RefSponsorConfiguration.IPP_AGENCY_SECONDARY_IDS);
			if (availableIdTypeList != null) {
				primaryIdconfig = includeSelectedAvailableIds(primaryIdconfig);
			}

			if (sponsorAcceptedIdTypeList != null) {
				primaryIdconfig = removeSelectedAcceptedIds(primaryIdconfig);
			}

			if (availableSecondaryIdTypeList != null) {
				secondaryIdconfig = includeSelectedAvailableSeconadryIds(secondaryIdconfig);
			}

			if (sponsorAcceptedSeconadryIdTypeList != null) {
				secondaryIdconfig = removeSelectedAcceptedSecondaryIds(secondaryIdconfig);
			}

			adminService.updateRefSponsorConfiguration(primaryIdconfig);
			adminService.updateRefSponsorConfiguration(secondaryIdconfig);

			loadFormControls();
			String lineBreak = "\t\n";

			if (includedSelectedStrongIds || removedSelectedStrongIds) {
				StringBuilder idNamesSb = new StringBuilder();
				if (!sponsorAcceptedIdTypeList.isEmpty()) {
					for (RefPrimaryIdType type : sponsorAcceptedIdTypeList) {
						idNamesSb.append(lineBreak);
						idNamesSb.append(type.getIdTypeDescription());
					}

				} else {
					idNamesSb.append(lineBreak);
					idNamesSb.append("[NO IDS SELECTED]");
				}
				idNamesSb.append(lineBreak);
				sendNotificationEmail(adminService, idNamesSb.toString(), CONFIG_ACCEPTED_ID_LIST_TYPE);
			}

			if (includedSelectedFairIds || removedSelectedFairIds) {
				StringBuilder idNamesSb = new StringBuilder();
				if (!sponsorAcceptedSeconadryIdTypeList.isEmpty()) {
					for (RefSecondaryIdType type : sponsorAcceptedSeconadryIdTypeList) {
						idNamesSb.append(lineBreak);
						idNamesSb.append(type.getIdTypeDescription());
					}

				} else {
					idNamesSb.append(lineBreak);
					idNamesSb.append("[NO IDS SELECTED]");
				}
				idNamesSb.append(lineBreak);
				sendNotificationEmail(adminService, idNamesSb.toString(), CONFIG_ACCEPTED_ID_LIST_TYPE);
			}

			manageFormPanelDisplay("OnSavedSuccessfully");

			changeMadeInAnyControl = includedSelectedStrongIds || removedSelectedStrongIds || includedSelectedFairIds
					|| removedSelectedFairIds;

			if (!changeMadeInAnyControl) {
				manageFormPanelDisplay("OnSaveWithoutChange");
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void cancel() {
		CustomLogger.enter(this.getClass());

		loadFormControls();
		manageFormPanelDisplay("OnCancel");
	}

	/*************************** Private Methods ***************************/

	private void loadFormControls() {
		CustomLogger.enter(this.getClass());

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);
			sponsorList = adminService.getAllExternalIppClients();

			loadSponsorStrongIdList(adminService);
			loadSponsorFairIdList(adminService);
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void loadSponsorStrongIdList(AdminService adminService) {
		CustomLogger.enter(this.getClass());

		try {
			RefSponsorConfiguration primaryIdsconfig = adminService.getRefSponsorConfiguration((int) selectedSponsorId,
					RefSponsorConfiguration.IPP_AGENCY_PRIMARY_IDS);

			availableIdTypeList = adminService.getAvailableIdList(primaryIdsconfig.getValue());
			sponsorAcceptedIdTypeList = adminService.getSponsorAcceptedIdTypeList(primaryIdsconfig.getValue());
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in loadSponsorStrongIdList: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private void loadSponsorFairIdList(AdminService adminService) {
		CustomLogger.enter(this.getClass());

		try {
			RefSponsorConfiguration secondaryIdsconfig = adminService.getRefSponsorConfiguration(
					(int) selectedSponsorId, RefSponsorConfiguration.IPP_AGENCY_SECONDARY_IDS);

			availableSecondaryIdTypeList = adminService.getAvailableSecondaryIdList(secondaryIdsconfig.getValue());
			sponsorAcceptedSeconadryIdTypeList = adminService
					.getSponsorAcceptedSecondaryIdTypeList(secondaryIdsconfig.getValue());
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in loadSponsorFairIdList: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	private RefSponsorConfiguration includeSelectedAvailableIds(RefSponsorConfiguration config) {
		CustomLogger.enter(this.getClass());

		RefPrimaryIdType idType = null;
		List<Long> selectedPrimaryIdList = new ArrayList<>();
		Iterator<RefPrimaryIdType> it = availableIdTypeList.iterator();
		includedSelectedAvailableIdList = new ArrayList<>();
		setIncludedSelectedStrongIds(false);

		while (it.hasNext()) {
			idType = it.next();

			if (idType.isSelected()) {
				selectedPrimaryIdList.add(idType.getIdType());
				includedSelectedAvailableIdList.add(idType);
				setIncludedSelectedStrongIds(true);

			}
		}

		try {

			StringJoiner sj = new StringJoiner(",");
			for (RefPrimaryIdType acceptedIds : sponsorAcceptedIdTypeList) {
				sj.add(String.valueOf(acceptedIds.getIdType()));
			}
			for (int i = 0; i < selectedPrimaryIdList.size(); i++) {
				sj.add(selectedPrimaryIdList.get(i).toString());
			}
			String acceptedList = sj.toString();
			config.setValue(acceptedList);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in includeSelectedAvailableIds ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
		return config;
	}

	private RefSponsorConfiguration removeSelectedAcceptedIds(RefSponsorConfiguration config) {
		CustomLogger.enter(this.getClass());

		RefPrimaryIdType idType = null;
		Iterator<RefPrimaryIdType> it = sponsorAcceptedIdTypeList.iterator();
		setRemovedSelectedStrongIds(false);
		String acceptedSponsorIds = "";

		try {
			if (config != null) {
				acceptedSponsorIds = config.getValue();
				while (it.hasNext()) {
					idType = it.next();
					if (idType.isSelected()) {
						String idToRemove = String.valueOf(idType.getIdType());
						// Removing any double comma and/or ending comma
						acceptedSponsorIds = acceptedSponsorIds.replace(idToRemove, "").replace(",,", ",")
								.replaceAll(",$", "").replaceAll("^,", "");
						// Removing stating comma if present
						acceptedSponsorIds = acceptedSponsorIds.startsWith(",") ? acceptedSponsorIds.substring(1)
								: acceptedSponsorIds;
						setRemovedSelectedStrongIds(true);
					}
				}
				// The value field is not nullable so setting it as 0
				acceptedSponsorIds = acceptedSponsorIds.isEmpty() ? "0" : acceptedSponsorIds;
				config.setValue(acceptedSponsorIds);

			}
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in removeSelectedAcceptedIds: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
		return config;
	}

	private RefSponsorConfiguration includeSelectedAvailableSeconadryIds(RefSponsorConfiguration config) {
		CustomLogger.enter(this.getClass());

		RefSecondaryIdType idType = null;
		List<Long> selectedSecondaryIdList = new ArrayList<>();
		Iterator<RefSecondaryIdType> it = availableSecondaryIdTypeList.iterator();
		includedSelectedAvailableSecondaryIdList = new ArrayList<>();
		setIncludedSelectedFairIds(false);

		while (it.hasNext()) {
			idType = it.next();

			if (idType.isSelected()) {
				selectedSecondaryIdList.add(idType.getIdType());
				includedSelectedAvailableSecondaryIdList.add(idType);
				setIncludedSelectedFairIds(true);

			}
		}

		try {

			StringJoiner sj = new StringJoiner(",");
			for (RefSecondaryIdType acceptedIds : sponsorAcceptedSeconadryIdTypeList) {
				sj.add(String.valueOf(acceptedIds.getIdType()));
			}
			for (int i = 0; i < selectedSecondaryIdList.size(); i++) {
				sj.add(selectedSecondaryIdList.get(i).toString());
			}
			String acceptedList = sj.toString();
			config.setValue(acceptedList);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in includeSelectedAvailableIds ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
		return config;
	}

	private RefSponsorConfiguration removeSelectedAcceptedSecondaryIds(RefSponsorConfiguration config) {
		CustomLogger.enter(this.getClass());

		RefSecondaryIdType idType = null;
		Iterator<RefSecondaryIdType> it = sponsorAcceptedSeconadryIdTypeList.iterator();
		setRemovedSelectedFairIds(false);
		String acceptedSponsorIds = "";

		try {
			if (config != null) {
				acceptedSponsorIds = config.getValue();
				while (it.hasNext()) {
					idType = it.next();
					if (idType.isSelected()) {
						String idToRemove = String.valueOf(idType.getIdType());
						// Removing any double comma and/or ending comma
						acceptedSponsorIds = acceptedSponsorIds.replace(idToRemove, "").replace(",,", ",")
								.replaceAll(",$", "").replaceAll("^,", "");
						// Removing stating comma if present
						acceptedSponsorIds = acceptedSponsorIds.startsWith(",") ? acceptedSponsorIds.substring(1)
								: acceptedSponsorIds;
						setRemovedSelectedFairIds(true);
					}
				}
				// The value field is not nullable so setting it as 0
				acceptedSponsorIds = acceptedSponsorIds.isEmpty() ? "0" : acceptedSponsorIds;
				config.setValue(acceptedSponsorIds);

			}
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurred in removeSelectedAcceptedIds: ", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
		return config;
	}

	private void sendNotificationEmail(AdminService adminService, String configValue, String configType) {
		CustomLogger.enter(this.getClass());

		try {
			Timestamp transactionTime = new Timestamp(new Date().getTime());
			adminService.sendIal2ConfigChangeConfirmNotification(selectedSponsorId, userId, externalAgencyName,
					transactionTime, configValue, configType);
		} catch (Exception e) {
			setErrorMsg(
					"An error occurred while generating notification email for sponsor id configuration value change.");
			setShowErrorMsg(true);
			CustomLogger.error(this.getClass(), "Error occurred while sending email notification .", e);
		}
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userid) {
		this.userId = userid;
	}

	private void manageFormPanelDisplay(String eventName) {
		CustomLogger.enter(this.getClass());

		initMessageAndButtonDisplay();

		switch (eventName) {
		case "InitLoad":
			setInfoMsg("Select an external agency.");
			setShowInfoMsg(true);
			break;
		case "OnSponsorSelect":
		case "OnCancel":
			setShowControlPnl(true);
			setShowInitialBtn(true);
			break;
		case "OnSelectChange":
			setInfoMsg("You are changing the configuration value(s).  If this is correct, select Confirm below.");
			setShowInfoMsg(true);
			setShowControlPnl(true);
			setShowConfirmChangeBtn(true);
			break;
		case "OnSavedSuccessfully":
			setInfoMsg("Configuration was successfully updated!");
			setShowInfoMsg(true);
			setShowInitialBtn(true);
			setShowControlPnl(true);
			break;
		case "OnSaveWithoutChange":
			setInfoMsg("No configuration value changes were made.");
			setShowInfoMsg(true);
			setShowControlPnl(true);
			setShowConfirmChangeBtn(true);
			break;
		default:
		}
	}

	private void initMessageAndButtonDisplay() {
		CustomLogger.enter(this.getClass());

		setShowControlPnl(false);
		setShowInitialBtn(false);
		setShowConfirmChangeBtn(false);

		setShowErrorMsg(false);
		setShowWarnMsg(false);
		setShowInfoMsg(false);

		setErrorMsg("");
		setWarnMsg("");
		setInfoMsg("");

	}

	/***************************
	 * Properties Getters/Setters
	 ***************************/

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public List<RefSponsor> getSponsorList() {
		return sponsorList;
	}

	public void setSponsorList(List<RefSponsor> sponsorList) {
		this.sponsorList = sponsorList;
	}

	public long getSelectedSponsorId() {
		return selectedSponsorId;
	}

	public void setSelectedSponsorId(long selectedSponsorId) {
		this.selectedSponsorId = selectedSponsorId;
	}

	public List<RefPrimaryIdType> getAvailableStrongIdTypeList() {
		return availableIdTypeList;
	}

	public void setAvailableStrongIdTypeList(List<RefPrimaryIdType> availableStrongIdTypeList) {
		this.availableIdTypeList = availableStrongIdTypeList;
	}

	public List<RefPrimaryIdType> getSponsorStrongIdTypeList() {
		return sponsorAcceptedIdTypeList;
	}

	public void setSponsorStrongIdTypeList(List<RefPrimaryIdType> sponsorStrongIdTypeList) {
		this.sponsorAcceptedIdTypeList = sponsorStrongIdTypeList;
	}

	public List<RefSecondaryIdType> getAvailableFairIdTypeList() {
		return availableSecondaryIdTypeList;
	}

	public void setAvailableFairIdTypeList(List<RefSecondaryIdType> availableFairIdTypeList) {
		this.availableSecondaryIdTypeList = availableFairIdTypeList;
	}

	public List<RefSecondaryIdType> getSponsorFairIdTypeList() {
		return sponsorAcceptedSeconadryIdTypeList;
	}

	public void setSponsorFairIdTypeList(List<RefSecondaryIdType> sponsorFairIdTypeList) {
		this.sponsorAcceptedSeconadryIdTypeList = sponsorFairIdTypeList;
	}

	public List<SponsorStrongId> getSponsorStrongIdList() {
		return sponsorStrongIdList;
	}

	public void setSponsorStrongIdList(List<SponsorStrongId> sponsorStrongIdList) {
		this.sponsorStrongIdList = sponsorStrongIdList;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getWarnMsg() {
		return warnMsg;
	}

	public void setWarnMsg(String warnMsg) {
		this.warnMsg = warnMsg;
	}

	public String getInfoMsg() {
		return infoMsg;
	}

	public void setInfoMsg(String infoMsg) {
		this.infoMsg = infoMsg;
	}

	public boolean isShowControlPnl() {
		return showControlPnl;
	}

	public void setShowControlPnl(boolean showControlPnl) {
		this.showControlPnl = showControlPnl;
	}

	public boolean isShowInfoMsg() {
		return showInfoMsg;
	}

	public void setShowInfoMsg(boolean showInfoMsg) {
		this.showInfoMsg = showInfoMsg;
	}

	public boolean isShowWarnMsg() {
		return showWarnMsg;
	}

	public void setShowWarnMsg(boolean showWarnMsg) {
		this.showWarnMsg = showWarnMsg;
	}

	public boolean isShowErrorMsg() {
		return showErrorMsg;
	}

	public void setShowErrorMsg(boolean showErrorMsg) {
		this.showErrorMsg = showErrorMsg;
	}

	public boolean isShowInitialBtn() {
		return showInitialBtn;
	}

	public void setShowInitialBtn(boolean showInitialBtn) {
		this.showInitialBtn = showInitialBtn;
	}

	public boolean isShowConfirmChangeBtn() {
		return showConfirmChangeBtn;
	}

	public void setShowConfirmChangeBtn(boolean showConfirmChangeBtn) {
		this.showConfirmChangeBtn = showConfirmChangeBtn;
	}

	public String getExternalAgencyName() {
		return externalAgencyName;
	}

	public void setExternalAgencyName(String externalAgencyName) {
		this.externalAgencyName = externalAgencyName;
	}

	public boolean isIncludedSelectedStrongIds() {
		return includedSelectedStrongIds;
	}

	public void setIncludedSelectedStrongIds(boolean includedSelectedStrongIds) {
		this.includedSelectedStrongIds = includedSelectedStrongIds;
	}

	public boolean isRemovedSelectedStrongIds() {
		return removedSelectedStrongIds;
	}

	public void setRemovedSelectedStrongIds(boolean removedSelectedStrongIds) {
		this.removedSelectedStrongIds = removedSelectedStrongIds;
	}

	public boolean isIncludedSelectedFairIds() {
		return includedSelectedFairIds;
	}

	public void setIncludedSelectedFairIds(boolean includedSelectedFairIds) {
		this.includedSelectedFairIds = includedSelectedFairIds;
	}

	public boolean isRemovedSelectedFairIds() {
		return removedSelectedFairIds;
	}

	public void setRemovedSelectedFairIds(boolean removedSelectedFairIds) {
		this.removedSelectedFairIds = removedSelectedFairIds;
	}

	public List<RefPrimaryIdType> getIncludedSelectedStrongIdList() {
		return includedSelectedAvailableIdList;
	}

	public void setIncludedSelectedStrongIdList(List<RefPrimaryIdType> includedSelectedStrongIdList) {
		this.includedSelectedAvailableIdList = includedSelectedStrongIdList;
	}

	public List<RefSecondaryIdType> getIncludedSelectedFairIdList() {
		return includedSelectedAvailableSecondaryIdList;
	}

	public void setIncludedSelectedFairIdList(List<RefSecondaryIdType> includedSelectedFairIdList) {
		this.includedSelectedAvailableSecondaryIdList = includedSelectedFairIdList;
	}

	public String getIncludedStrongIdNames() {
		return includedStrongIdNames;
	}

	public void setIncludedStrongIdNames(String includedStrongIdNames) {
		this.includedStrongIdNames = includedStrongIdNames;
	}

	public String getRemovedStrongIdNames() {
		return removedStrongIdNames;
	}

	public void setRemovedStrongIdNames(String removedStrongIdNames) {
		this.removedStrongIdNames = removedStrongIdNames;
	}

	public boolean isChangeMadeInAnyControl() {
		return changeMadeInAnyControl;
	}

	public void setChangeMadeInAnyControl(boolean changeMadeInAnyControl) {
		this.changeMadeInAnyControl = changeMadeInAnyControl;
	}

}
