package com.ips.common;

import java.io.Serializable;

public class IVSAdminConstants implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    public static final String REDIRECT_TO_STATUS_ERROR_PAGE ="Redirecting to System Error Page: ";
    public static final String CLIENT_IP = "clientip";
    public static final String NS_CLIENT_IP = "NS-Client-IP";
    public static final String CALLING_APP_KEY = "CALLING_APP";
    public static final String APPOINTMENT_KEY = "APPOINTMENT";
    
    private IVSAdminConstants() {
        
    }
    
}
