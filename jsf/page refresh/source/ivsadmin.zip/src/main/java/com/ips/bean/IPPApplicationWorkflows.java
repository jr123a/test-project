package com.ips.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.entity.ApplicationWorkflows;
import com.ips.entity.RefDeviceTypes;
import com.ips.entity.RefIppApplications;
import com.ips.entity.RefIppWorkflows;
import com.ips.entity.RefSponsor;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;

@ManagedBean(name = "applicationWorkflow")
@ViewScoped
public class IPPApplicationWorkflows extends IPSAdminController implements Serializable {
	private static final long serialVersionUID = 1L;

	private String errorMsg;
	private String warnMsg;
	private String infoMsg;
	private boolean showInfoMsg;
	private boolean showWarnMsg;
	private boolean showErrorMsg;
	private boolean showSaveBtn = true;
	private boolean showUpdateBtn;
	private boolean showConfirmBtn;
	private boolean showCancelBtn;
	private static final String ADMIN_SERVICE = "AdminService";
	private List<RefIppApplications> applicationList;
	private List<RefDeviceTypes> deviceList;
	private List<RefSponsor> sponsorList;
	private List<RefIppWorkflows> workflowsList;
	private List<ApplicationWorkflows> applicationWorkflowsList;
	private long selectedApplicationId = 0L;
	private long selectedDeviceId = 0L;
	private long selectedSponsorId = 0L;
	private long selectedWorkflowId = 0L;
	private long workflowId = 0L;
	private boolean initialized;
	ApplicationWorkflows workflow;
	private boolean disable = false;
	AdminService adminService;

	@PostConstruct
	public void init() {
		CustomLogger.enter(this.getClass());
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);

			if (!initialized) {
				setInitialized(true);
				loadLists();
				initButtonDisplay();
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void setNoMsg() {
		CustomLogger.enter(this.getClass());

		setErrorMsg(StringUtils.EMPTY);
		setWarnMsg(StringUtils.EMPTY);
		setInfoMsg(StringUtils.EMPTY);

		setShowErrorMsg(false);
		setShowWarnMsg(false);
		setShowInfoMsg(false);
	}

	public void initButtonDisplay() {
		CustomLogger.enter(this.getClass());
		setSelectedApplicationId(0L);
		setSelectedDeviceId(0L);
		setSelectedSponsorId(0L);
		setSelectedWorkflowId(0L);
		setShowSaveBtn(true);
		setShowUpdateBtn(false);
		setShowConfirmBtn(false);
		setShowCancelBtn(false);
		disable = false;
	}

	public void loadLists() {

		try {
			applicationList = adminService.getApplicationList();
			deviceList = adminService.getDeviceList();
			sponsorList = adminService.getSponsorList();
			workflowsList = adminService.getWorkflowsList();
			loadWorkflowList();

		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Error getting list for workflows", e);
		}

	}

	public void loadWorkflowList() {
		applicationWorkflowsList = adminService.getAppWrkFlwList();
	}

	public void saveRecord() {
		setNoMsg();
		ApplicationWorkflows apps = null;


		if (selectedApplicationId == 0L) {
			setErrorMsg("Please select an application.");
			setShowErrorMsg(true);
		} else if (selectedDeviceId == 0L) {
			setErrorMsg("Please select a device.");
			setShowErrorMsg(true);
		} else if (selectedSponsorId == 0L) {
			setErrorMsg("Please select a sponsor.");
			setShowErrorMsg(true);
		} else if (selectedWorkflowId == 0L) {
			setErrorMsg("Please select a workflow.");
			setShowErrorMsg(true);
		} else {
			RefIppApplications selectedApp = getApp(selectedApplicationId);
			RefDeviceTypes selectedDevice = getDevice(selectedDeviceId);
			RefSponsor selectedSponsor = getSponsor(selectedSponsorId);
			RefIppWorkflows selectedWrkfl = getWorkflow(selectedWorkflowId);
			if (applicationWorkflowsList != null) { // check if workflow is already saved
				apps = adminService.getWorkflowCombo(selectedApplicationId, selectedDeviceId, selectedSponsorId,
						selectedWorkflowId);
			}
			if (apps == null) {
				apps = new ApplicationWorkflows();
				apps.setRefIppApplications(selectedApp);
				apps.setRefDeviceTypes(selectedDevice);
				apps.setRefSponsor(selectedSponsor);
				apps.setRefIppWorkflows(selectedWrkfl);
				apps.setCreateDate(getCurrentTime());
				adminService.saveApplicationWorkflow(apps);
				setInfoMsg("Workflow saved successfully.");
				setShowInfoMsg(true);
			} else {
				setErrorMsg("Workflow already on list.");
				setShowErrorMsg(true);
			}
		}
		initButtonDisplay();
		loadWorkflowList();
	}

	private RefIppWorkflows getWorkflow(long selectedWorkflowId) {
		RefIppWorkflows wrk = new RefIppWorkflows();
		for (RefIppWorkflows fl : workflowsList) {
			if (fl.getWorkflowId() == selectedWorkflowId) {
				wrk = fl;
			}
		}

		return wrk;
	}

	private RefSponsor getSponsor(long selectedSponsorId) {
		RefSponsor sponsor = new RefSponsor();
		for (RefSponsor sp : sponsorList) {
			if (sp.getSponsorId() == selectedSponsorId) {
				sponsor = sp;
			}
		}

		return sponsor;
	}

	private RefDeviceTypes getDevice(long selectedDeviceId) {
		RefDeviceTypes device = new RefDeviceTypes();
		for (RefDeviceTypes dvs : deviceList) {
			if (dvs.getDeviceTypeId() == selectedDeviceId) {
				device = dvs;
			}
		}

		return device;
	}

	private RefIppApplications getApp(long selectedApplicationId) {
		RefIppApplications app = new RefIppApplications();
		for (RefIppApplications apps : applicationList) {
			if (apps.getIppApplicationId() == selectedApplicationId) {
				app = apps;
			}
		}

		return app;
	}

	public void editRecord(long workflowId) {
		setNoMsg();

		workflow = adminService.getWorkflowFromId(workflowId);
		this.workflowId = workflowId;

		if (workflow != null) {
			setSelectedApplicationId(workflow.getRefIppApplications().getIppApplicationId());
			setSelectedDeviceId(workflow.getRefDeviceTypes().getDeviceTypeId());
			setSelectedSponsorId(workflow.getRefSponsor().getSponsorId());
			setSelectedWorkflowId(workflow.getRefIppWorkflows().getWorkflowId());

			setShowSaveBtn(false);
			setShowUpdateBtn(true);
			setShowConfirmBtn(false);
			setShowCancelBtn(true);
		}

	}

	public void updateRecord() {
		setNoMsg();


		if (selectedApplicationId == 0L) {
			setErrorMsg("Please select an application.");
			setShowErrorMsg(true);
		} else if (selectedDeviceId == 0L) {
			setErrorMsg("Please select a device.");
			setShowErrorMsg(true);
		} else if (selectedSponsorId == 0L) {
			setErrorMsg("Please select a sponsor.");
			setShowErrorMsg(true);
		} else if (selectedWorkflowId == 0L) {
			setErrorMsg("Please select a workflow.");
			setShowErrorMsg(true);
		} else {
			ApplicationWorkflows apps = null;
			if (applicationWorkflowsList != null) { // check if workflow is already saved
				apps = adminService.getWorkflowCombo(selectedApplicationId, selectedDeviceId, selectedSponsorId,
						selectedWorkflowId);
			}
			if (apps == null) {
				RefIppApplications selectedApp = getApp(selectedApplicationId);
				RefDeviceTypes selectedDevice = getDevice(selectedDeviceId);
				RefSponsor selectedSponsor = getSponsor(selectedSponsorId);
				RefIppWorkflows selectedWrkfl = getWorkflow(selectedWorkflowId);

				if (workflow != null) {
					workflow.setRefIppApplications(selectedApp);
					workflow.setRefDeviceTypes(selectedDevice);
					workflow.setRefSponsor(selectedSponsor);
					workflow.setRefIppWorkflows(selectedWrkfl);

					adminService.updateApplicationWorkflow(workflow);
					applicationWorkflowsList = adminService.getAppWrkFlwList();
					setInfoMsg("Workflow updated successfully.");
					setShowInfoMsg(true);
					initButtonDisplay();
				}
			} else {
				setErrorMsg("Workflow already on list.");
				setShowErrorMsg(true);
			}
		}
		initButtonDisplay();
		loadWorkflowList();
	}

	public void deleteRecord(long workflowId) {
		setNoMsg();
		disable = true;
		workflow = adminService.getWorkflowFromId(workflowId);
		this.workflowId = workflowId;
		if (workflow != null) {
			setSelectedApplicationId(workflow.getRefIppApplications().getIppApplicationId());
			setSelectedDeviceId(workflow.getRefDeviceTypes().getDeviceTypeId());
			setSelectedSponsorId(workflow.getRefSponsor().getSponsorId());
			setSelectedWorkflowId(workflow.getRefIppWorkflows().getWorkflowId());

			setShowSaveBtn(false);
			setShowUpdateBtn(false);
			setShowConfirmBtn(true);
			setShowCancelBtn(true);

			setInfoMsg("Please confirm you want to delete this record.");
			setShowInfoMsg(true);
		}
	}

	public void confirmDelete() {
		setNoMsg();


		if (workflow != null) {
			adminService.deleteApplicationWorkflow(workflow);
			applicationWorkflowsList = adminService.getAppWrkFlwList();
			setInfoMsg("Workflow deleted successfully.");
			setShowInfoMsg(true);
		}
		initButtonDisplay();
		loadWorkflowList();
	}

	public void cancel() {
		setNoMsg();
		setSelectedApplicationId(0L);
		setSelectedDeviceId(0L);
		setSelectedSponsorId(0L);
		setSelectedWorkflowId(0L);

		initButtonDisplay();
	}

	private Timestamp getCurrentTime() {
		return new Timestamp(new Date().getTime());
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getWarnMsg() {
		return warnMsg;
	}

	public void setWarnMsg(String warnMsg) {
		this.warnMsg = warnMsg;
	}

	public String getInfoMsg() {
		return infoMsg;
	}

	public void setInfoMsg(String infoMsg) {
		this.infoMsg = infoMsg;
	}

	public boolean isShowInfoMsg() {
		return showInfoMsg;
	}

	public void setShowInfoMsg(boolean showInfoMsg) {
		this.showInfoMsg = showInfoMsg;
	}

	public boolean isShowWarnMsg() {
		return showWarnMsg;
	}

	public void setShowWarnMsg(boolean showWarnMsg) {
		this.showWarnMsg = showWarnMsg;
	}

	public boolean isShowErrorMsg() {
		return showErrorMsg;
	}

	public void setShowErrorMsg(boolean showErrorMsg) {
		this.showErrorMsg = showErrorMsg;
	}

	public boolean isShowSaveBtn() {
		return showSaveBtn;
	}

	public void setShowSaveBtn(boolean showSaveBtn) {
		this.showSaveBtn = showSaveBtn;
	}

	public boolean isShowUpdateBtn() {
		return showUpdateBtn;
	}

	public void setShowUpdateBtn(boolean showUpdateBtn) {
		this.showUpdateBtn = showUpdateBtn;
	}

	public boolean isShowConfirmBtn() {
		return showConfirmBtn;
	}

	public void setShowConfirmBtn(boolean showConfirmBtn) {
		this.showConfirmBtn = showConfirmBtn;
	}

	public boolean isShowCancelBtn() {
		return showCancelBtn;
	}

	public void setShowCancelBtn(boolean showCancelBtn) {
		this.showCancelBtn = showCancelBtn;
	}

	public List<RefIppApplications> getApplicationList() {
		return applicationList;
	}

	public void setApplicationList(List<RefIppApplications> applicationList) {
		this.applicationList = applicationList;
	}

	public List<RefDeviceTypes> getDeviceList() {
		return deviceList;
	}

	public void setDeviceList(List<RefDeviceTypes> deviceList) {
		this.deviceList = deviceList;
	}

	public List<RefSponsor> getSponsorList() {
		return sponsorList;
	}

	public void setSponsorList(List<RefSponsor> sponsorList) {
		this.sponsorList = sponsorList;
	}

	public List<RefIppWorkflows> getWorkflowsList() {
		return workflowsList;
	}

	public void setWorkflowsList(List<RefIppWorkflows> workflowsList) {
		this.workflowsList = workflowsList;
	}

	public List<ApplicationWorkflows> getApplicationWorkflowsList() {
		return applicationWorkflowsList;
	}

	public void setApplicationWorkflowsList(List<ApplicationWorkflows> applicaitonWorkflowsList) {
		this.applicationWorkflowsList = applicaitonWorkflowsList;
	}

	public long getSelectedApplicationId() {
		return selectedApplicationId;
	}

	public void setSelectedApplicationId(long selectedApplicationId) {
		this.selectedApplicationId = selectedApplicationId;
	}

	public long getSelectedDeviceId() {
		return selectedDeviceId;
	}

	public void setSelectedDeviceId(long selectedDeviceId) {
		this.selectedDeviceId = selectedDeviceId;
	}

	public long getSelectedSponsorId() {
		return selectedSponsorId;
	}

	public void setSelectedSponsorId(long selectedSponsorId) {
		this.selectedSponsorId = selectedSponsorId;
	}

	public long getSelectedWorkflowId() {
		return selectedWorkflowId;
	}

	public void setSelectedWorkflowId(long selectedWorkflowId) {
		this.selectedWorkflowId = selectedWorkflowId;
	}

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public boolean isDisable() {
		return disable;
	}

	public void setDisable(boolean disable) {
		this.disable = disable;
	}

}
