package com.ips.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.entity.RefIdValidationVendor;
import com.ips.entity.RefIdValidationVendorConfiguration;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;

@ManagedBean(name = "IAL2VendorConfig")
@ViewScoped
public class IAL2VendorConfigurationBean extends IPSAdminController implements Serializable {
	private static final long serialVersionUID = 1L;

	private boolean initialized;
	private boolean showInfoMsg;
	private boolean showWarnMsg;
	private boolean showErrorMsg;
	private boolean showInitialBtn;
	private boolean showConfirmChangeBtn;
	private boolean showControlPnl;
	private static final String ADMIN_SERVICE = "AdminService";
	private List<RefIdValidationVendorConfiguration> vendorList;
	private String selectedVendorName;
	private String urlValue;
	private String errorMsg;
	private String warnMsg;
	private String infoMsg;
	private String userId;

	public String getSelectedVendorName() {
		return selectedVendorName;
	}

	public void setSelectedVendorName(String selectedVendorName) {
		this.selectedVendorName = selectedVendorName;
	}

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public String getInfoMsg() {
		return infoMsg;
	}

	public void setInfoMsg(String infoMsg) {
		this.infoMsg = infoMsg;
	}

	public String getWarnMsg() {
		return warnMsg;
	}

	public void setWarnMsg(String warnMsg) {
		this.warnMsg = warnMsg;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public boolean isShowInfoMsg() {
		return showInfoMsg;
	}

	public void setShowInfoMsg(boolean showInfoMsg) {
		this.showInfoMsg = showInfoMsg;
	}

	public boolean isShowWarnMsg() {
		return showWarnMsg;
	}

	public void setShowWarnMsg(boolean showWarnMsg) {
		this.showWarnMsg = showWarnMsg;
	}

	public boolean isShowErrorMsg() {
		return showErrorMsg;
	}

	public void setShowErrorMsg(boolean showErrorMsg) {
		this.showErrorMsg = showErrorMsg;
	}

	public String getUrlValue() {
		return urlValue;
	}

	public void setUrlValue(String urlValue) {
		this.urlValue = urlValue;
	}

	@PostConstruct
	public void init() {
		CustomLogger.enter(this.getClass());
		if (!initialized) {
			setInitialized(true);
			loadVendorList();
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();
			setUserId((String) request.getSession().getAttribute("IVSToken"));
		}
	}

	/*************************** Initialization Methods ***************************/

	public void loadVendorList() {
		CustomLogger.enter(this.getClass());
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);

			List<RefIdValidationVendor> validationVendorList = adminService.findValidationVendorList();
			List<RefIdValidationVendorConfiguration> configList = new ArrayList<>();
			for (RefIdValidationVendor v : validationVendorList) {
				RefIdValidationVendorConfiguration c = new RefIdValidationVendorConfiguration();
				c.setVendorId(v.getVendorId());
				c.setVendorName(v.getVendorName());
				c.setCreateDate(v.getCreateDate());
				c.setValue(adminService.getLookupValue(v.getVendorName().concat(".VENDORURL")));
				configList.add(c);

			}
			this.vendorList = configList;
			manageFormPanelDisplay("InitLoad");
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/*************************** Private Methods ***************************/

	private void manageFormPanelDisplay(String eventName) {
		CustomLogger.enter(this.getClass());

		initMessageAndButtonDisplay();

		switch (eventName) {
		case "InitLoad":
		case "OnCancel":
			setShowControlPnl(true);
			setShowInitialBtn(true);
			break;
		case "OnSelectChange":
			setInfoMsg("You are changing the configuration value.  If this is correct, select Confirm below.");
			setShowInfoMsg(true);
			setShowControlPnl(true);
			setShowConfirmChangeBtn(true);
			break;
		case "OnSavedSuccessfully":
			setInfoMsg("Configuration was successfully updated!");
			setShowInfoMsg(true);
			setShowInitialBtn(true);
			setShowControlPnl(true);
			break;
		default:
		}
	}

	public void change() {
		CustomLogger.enter(this.getClass());
		manageFormPanelDisplay("OnSelectChange");
	}

	public void save() {
		CustomLogger.enter(this.getClass());
		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			AdminService adminService = webAppContext.getBean("AdminService", AdminServiceImpl.class);
			updateVendorConfiguration(adminService);
			manageFormPanelDisplay("OnSavedSuccessfully");
			// sendNotificationEmail(adminService);
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}

	}

	public void cancel() {
		CustomLogger.enter(this.getClass());

		loadVendorList();
	}

	private void updateVendorConfiguration(AdminService adminService) {
		CustomLogger.enter(this.getClass());
		adminService.updateVendorConfiguration(vendorList, userId);
	}

	private void initMessageAndButtonDisplay() {
		CustomLogger.enter(this.getClass());
		setShowControlPnl(false);
		setShowInitialBtn(false);
		setShowConfirmChangeBtn(false);
		setShowErrorMsg(false);
		setShowWarnMsg(false);
		setShowInfoMsg(false);
		setErrorMsg("");
		setWarnMsg("");
		setInfoMsg("");

	}

	public boolean isShowInitialBtn() {
		return showInitialBtn;
	}

	public void setShowInitialBtn(boolean showInitialBtn) {
		this.showInitialBtn = showInitialBtn;
	}

	public boolean isShowConfirmChangeBtn() {
		return showConfirmChangeBtn;
	}

	public void setShowConfirmChangeBtn(boolean showConfirmChangeBtn) {
		this.showConfirmChangeBtn = showConfirmChangeBtn;
	}

	public boolean isShowControlPnl() {
		return showControlPnl;
	}

	public void setShowControlPnl(boolean showControlPnl) {
		this.showControlPnl = showControlPnl;
	}

	public List<RefIdValidationVendorConfiguration> getVendorList() {
		return vendorList;
	}

	public void setVendorList(List<RefIdValidationVendorConfiguration> vendorList) {
		this.vendorList = vendorList;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
