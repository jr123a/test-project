package com.ips.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.OtpConfigVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.Utils;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefSponsor;
import com.ips.exception.IPSException;
import com.ips.persistence.common.IPSConstants;
import com.ips.service.AdminService;
import com.ips.service.AdminServiceImpl;

@ManagedBean(name = "admin")
@ViewScoped
public class AdminBean extends IPSAdminController implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private boolean errorPercent = false;
    private boolean error = false;
    private boolean success = false;
    private List<OtpConfigVo> otpConfigList;
    private List<RefSponsor> sponsorList = new ArrayList<>();
    private List<RefLoaLevel> loaList = new ArrayList<>();
    private int[] percentages = {0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100};
    private long selectedSponsor = 1L;
    private long selectedLOA = RefLoaLevel.LOA15_CODE;
    private String selectedLOADesc;
    private String serverName;
    private boolean confirmChange = false;
    private boolean emailError = false;

    @PostConstruct
    public void init(){        
        CustomLogger.enter(this.getClass());
    }
    
    public void loadOtpConfigTable() {
        CustomLogger.enter(this.getClass());
         
        if (confirmChange) {
            return;
        }
        
        determineLOADescription();
        
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
        if (webAppContext != null) {
            AdminService service = webAppContext.getBean("AdminService", AdminServiceImpl.class);
            loadSelectorOptions(service);
           
            try {
                otpConfigList = service.retrieveOtpAttemptConfigList(selectedLOA, selectedSponsor);
                for (int i = 0; otpConfigList != null && i < otpConfigList.size(); i++) {
                    otpConfigList.get(i).setPercentage(String.valueOf(otpConfigList.get(i).getTotalAttempts()));
                }
            } catch (Exception e) {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error loading OTP Config Admin page", e);
                goToPage(SYSTEM_ERROR_PAGE);
            }
        } else {
            CustomLogger.error(this.getClass(), "Error: WebApplicationContext is null. Unable to retrieve AdminService.");
            goToPage(SYSTEM_ERROR_PAGE);  
        }
    }
    
    private void loadSelectorOptions(AdminService service) {
        CustomLogger.enter(this.getClass());
        sponsorList = service.retrieveSponsorList();
            
        loaList = new ArrayList<>();
        RefLoaLevel loa = new RefLoaLevel();
        loa.setLoaCode(1);
        loa.setLoaLevelDescription("LOA 1.5");
        loaList.add(loa);
        
        selectedLOA = RefLoaLevel.LOA15_CODE;
    }
    
    private void determineLOADescription() {
        CustomLogger.enter(this.getClass());
        if (selectedLOA == RefLoaLevel.LOA15_CODE) {
            setSelectedLOADesc(RefLoaLevel.LOA_15);
        }
    }

    public void change() {
        CustomLogger.enter(this.getClass());
        setSuccess(false);
        
        if (valid()) {
            setConfirmChange(true);
            errorPercent = false;
        } else {
            // set error
            errorPercent = true;
        }
    }
    
    public void save() {
        CustomLogger.enter(this.getClass());
        setSuccess(false);
        setConfirmChange(false);

        if (valid()) {
            errorPercent = false;
            ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
            
            WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
            if (webAppContext != null) {
    		AdminService service = webAppContext.getBean("AdminService", AdminServiceImpl.class);
    		

            for (int i = 0; i < otpConfigList.size(); i++) {
                otpConfigList.get(i).setTotalAttempts(otpConfigList.get(i).getNewPercentage());
            }
            
            try {
                HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
                String username = (String) request.getSession().getAttribute("IVSToken");
                
                if (Utils.isAlphanumeric(username)) {
                    service.changeOtpAttemptConfig(otpConfigList, username, selectedLOA, selectedSponsor, service.isLocalServer());
                    error = false;
                    setSuccess(true);
                    otpConfigList = service.retrieveOtpAttemptConfigList(selectedLOA, selectedSponsor);
                    
                    for (OtpConfigVo otpConfigVo : otpConfigList) {
                    	otpConfigVo.setPercentage(String.valueOf(otpConfigVo.getTotalAttempts()));
                    }
                } else {
                    CustomLogger.warn(this.getClass(), "WARNING: Invalid user name supplied, OTP configuration not updated: " + username);
                }
                setEmailError(false);
                setError(false);
            } catch (IPSException e) {
                setEmailError(true);
                CustomLogger.error(this.getClass(), "Error generating notification email for OTP configuration percentage change.",e);
                loadOtpConfigTable();
            } catch (Exception e) {
                setError(true);
                CustomLogger.error(this.getClass(), "Error trying to change OTP configuration percentages.",e);
            }
        } else {
             errorPercent = true;
        }
            } else {
            CustomLogger.error(this.getClass(), "Error: WebApplicationContext is null. Unable to retrieve AdminService.");
            goToPage(SYSTEM_ERROR_PAGE); 
        }
    }
    
    public void cancel() {
        clearErrors();
        loadOtpConfigTable();
    }
    
    private void clearErrors() {
        setSuccess(false);
        setError(false);
        setConfirmChange(false);
        setErrorPercent(false);
        setEmailError(false);
    }
    
    /*
     * The selectSponsor method is called by an event listener when the user
     * changes the Sponsor on the admin OTP Config percentage page.
     */
    public void selectSponsor(ValueChangeEvent vcEvent) {
         CustomLogger.enter(this.getClass());
         Long selectedSponsorLong = (Long)vcEvent.getNewValue();
        selectedSponsor = selectedSponsorLong.longValue();
        clearErrors();
        loadOtpConfigTable();
    }
    
    /*
     * The selectAssuranceLevel method is called by an event listener when the user
     * changes the Level of Assurance on the admin OTP Config percentage page.
     */
    public void selectAssuranceLevel(ValueChangeEvent vcEvent) {
        CustomLogger.enter(this.getClass());
        Long selectedLOALong = (Long)vcEvent.getNewValue();
        selectedLOA = selectedLOALong.longValue();
        clearErrors();
        loadOtpConfigTable();
    }

    private boolean valid() {
        CustomLogger.enter(this.getClass());
        int count = 0;
        for (int i = 0; i < otpConfigList.size(); i++) {
            count += otpConfigList.get(i).getNewPercentage();
        }
        
        return count == 100;
    }

    @Override
    public void logout(){
        CustomLogger.enter(this.getClass());
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        session.setAttribute("IVSID", null);
        session.invalidate();
        
        goToPage(ADMIN_LOGIN_PAGE);
    }
    
    public List<OtpConfigVo> getOtpConfigList() {
        return otpConfigList;
    }

    public void setOtpConfigList(List<OtpConfigVo> otpConfigList) {
        this.otpConfigList = otpConfigList;
    }

    public int[] getPercentages() {
        return percentages;
    }

    public void setPercentages(int[] percentages) {
        this.percentages = percentages;
    }

    public boolean isErrorPercent() {
        return errorPercent;
    }

    public void setErrorPercent(boolean errorPercent) {
        this.errorPercent = errorPercent;
    }

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public long getSelectedSponsor() {
        return selectedSponsor;
    }

    public void setSelectedSponsor(long selectedSponsor) {
        this.selectedSponsor = selectedSponsor;
    }

    public long getSelectedLOA() {
        return selectedLOA;
    }

    public void setSelectedLOA(long selectedLOA) {
        this.selectedLOA = selectedLOA;
    }

    public boolean isConfirmChange() {
        return confirmChange;
    }

    public void setConfirmChange(boolean confirmChange) {
        this.confirmChange = confirmChange;
    }
    
    public String getSelectedLOADesc() {
        return selectedLOADesc;
    }

    public void setSelectedLOADesc(String selectedLOADesc) {
        this.selectedLOADesc = selectedLOADesc;
    }

    public boolean isEmailError() {
        return emailError;
    }

    public void setEmailError(boolean emailError) {
        this.emailError = emailError;
    }

    public List<RefSponsor> getSponsorList() {
        return sponsorList;
    }

    public void setSponsorList(List<RefSponsor> sponsorList) {
        this.sponsorList = sponsorList;
    }
    
    public List<RefLoaLevel> getLoaList() {
        return loaList;
    }

    public void setLoaList(List<RefLoaLevel> loaList) {
        this.loaList = loaList;
    }

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
    
}
