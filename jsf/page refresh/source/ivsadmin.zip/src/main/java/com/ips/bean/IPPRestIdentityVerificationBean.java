package com.ips.bean;

import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.wink.client.ClientConfig;
import org.apache.wink.client.ClientRuntimeException;
import org.apache.wink.client.ClientWebException;
import org.apache.wink.client.Resource;
import org.apache.wink.client.RestClient;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.ibm.json.java.JSONObject;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.Utils;
import com.ips.entity.IppEvent;
import com.ips.entity.IvsAdminUser;
import com.ips.entity.Person;
import com.ips.entity.RefIppEventStatus;
import com.ips.entity.RefIppFailureReason;
import com.ips.entity.RefPrimaryIdType;
import com.ips.entity.RefSecondaryIdType;
import com.ips.entity.RefSponsor;
import com.ips.jaxrs.InPersonRequest;
import com.ips.rss.service.IPSRestResourceService;
import com.ips.service.AdminService;
import com.ips.service.IppEventService;
import com.ips.service.IvsAdminUserService;
import com.ips.service.PersonDataService;
import com.ips.service.RefIppEventStatusService;
import com.ips.service.RefIppFailureReasonService;
import com.ips.service.RefPrimaryIdTypeService;
import com.ips.service.RefSecondaryIdTypeService;
import com.ips.service.RefSponsorDataService;

@ManagedBean(name = "ippRestIdentityVerificationBean")
@ViewScoped
public class IPPRestIdentityVerificationBean extends IPSAdminController implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<RefSponsor> allSponsorList;
	private List<RefIppEventStatus> allIppEventStatusList;
	private List<RefPrimaryIdType> allPrimaryIdTypeList;
	private List<RefSecondaryIdType> allSecondaryIdTypeList;
	private List<RefIppFailureReason> allIppFailureReasonList;
	private Map<String, Object> gfRequestHashMap;
	private Map<String, Object> oiRequestHashMap;
	private Map<String, Object> srRequestHashMap;
	private Map<String, Object> reRequestHashMap;
	private Map<String, Object> grRequestHashMap;
	private RefSponsor selectedRefSponsor;
	private RefIppEventStatus selectedRefIppEventStatus;
	private RefPrimaryIdType selectedRefPrimaryIdType;
	private RefSecondaryIdType selectedRefSecondaryIdType;
	private RefIppFailureReason selectedRefIppFailureReason;
	private IppEvent selectedIppEvent;
	private Person selectedPerson;
	private AdminService adminService;

	private Long selectedRefSponsorId;
	private Long selectedRefIppEventStatusId;
	private Long selectedRefPrimaryIdTypeId;
	private Long selectedRefSecondaryIdTypeId;
	private long selectedRefIppFailureReasonId;
	private Long selectedIppEventId;
	private Long selectedPersonId;

	private HttpServletRequest httpServletRequest;
	private ServletContext servletContext;
	private WebApplicationContext webAppContext;
	private long oiSponsorId;
	private String oiSponsorUserId;
	private String oiFirstName;
	private String oiLastName;
	private String oiStreetAddress;
	private String oiCity;
	private String oiState;
	private String oiZip5;
	private String oiEmailAddress;
	private String oiAlternateEmail;
	private String oiPhoneNumber;
	private String oiIPPAssuranceLevel;
	private String oiOrigin;
	private String oiRequestId;
	private String oiJsonRequest;
	private String oiJsonRequestHold;
	private String oiJsonResponse;

	private long srStatus;
	private long srPrimaryIdType;
	private long srTransactionEndDateTime;
	private long srSecondaryIdType;
	private long srFailureReasonCode;
	private long srTransactionStartDateTime;
	private String srProoferFirstName;
	private String srProoferLastName;
	private String srProofingLocation;
	private String srRecordLocator;
	private String srProoferAceId;
	private String srConfirmationNumber;
	private String srSuspectFraud;
	private String srAuthorization;
	private String srApplication;
	private String srJsonRequest;
	private String srJsonRequestHold;
	private String srJsonResponse;
	private boolean suspectFraud;

	private long reSponsorId;
	private String reSponsorUserId;
	private String reOrigin;
	private String reRequestId;
	private String reJsonRequest;
	private String reJsonRequestHold;
	private String reJsonResponse;

	private long grSponsorId;
	private String grSponsorUserId;
	private String grEnrollmentCode;
	private String grOrigin;
	private String grRequestId;
	private String grJsonRequest;
	private String grJsonResponse;

	private String serverName;

	private String getIppFacilityListInstMsg;
	private String getIppFacilityListErrorMsg;
	private String getIppFacilityListSuccessMsg;

	private String optInIPPApplicantInstMsg;
	private String optInIPPApplicantErrorMsg;
	private String optInIPPApplicantSuccessMsg;

	private String sendProofingResultsInstMsg;
	private String sendProofingResultsErrorMsg;
	private String sendProofingResultsSuccessMsg;

	private String requestEnrollmentCodeInstMsg;
	private String requestEnrollmentCodeErrorMsg;
	private String requestEnrollmentCodeSuccessMsg;

	private String getProofingResultsInstMsg;
	private String getProofingResultsErrorMsg;
	private String getProofingResultsSuccessMsg;

	private boolean showGetIppFacilityListInstMsg;
	private boolean showGetIppFacilityListErrorMsg;
	private boolean showGetIppFacilityListSuccessMsg;

	private boolean showOptInIPPApplicantInstMsg;
	private boolean showOptInIPPApplicantErrorMsg;
	private boolean showOptInIPPApplicantSuccessMsg;

	private boolean showSendProofingResultsInstMsg;
	private boolean showSendProofingResultsErrorMsg;
	private boolean showSendProofingResultsSuccessMsg;

	private boolean showRequestEnrollmentCodeInstMsg;
	private boolean showRequestEnrollmentCodeErrorMsg;
	private boolean showRequestEnrollmentCodeSuccessMsg;

	private boolean showGetProofingResultsInstMsg;
	private boolean showGetProofingResultsErrorMsg;
	private boolean showGetProofingResultsSuccessMsg;

	private boolean showGetIppFacilityListRequestJsonPanel;
	private boolean showGetIppFacilityListResponseJsonPanel;
	private boolean showOptInIPPApplicantRequestJsonPanel;
	private boolean showOptInIPPApplicantResponseJsonPanel;
	private boolean showSendProofingResultsRequestJsonPanel;
	private boolean showSendProofingResultsResponseJsonPanel;
	private boolean showRequestEnrollmentCodeRequestJsonPanel;
	private boolean showRequestEnrollmentCodeResponseJsonPanel;
	private boolean showGetProofingResultsRequestJsonPanel;
	private boolean showGetProofingResultsResponseJsonPanel;

	private boolean showGetIppFacilityListSubmitBtn;
	private boolean showOptInIPPApplicantGenerateBtn;
	private boolean showOptInIPPApplicantSubmitBtn;
	private boolean showSendProofingResultsGenerateBtn;
	private boolean showSendProofingResultsSubmitBtn;
	private boolean showRequestEnrollmentCodeGenerateBtn;
	private boolean showRequestEnrollmentCodeSubmitBtn;
	private boolean showGetProofingResultsGenerateBtn;
	private boolean showGetProofingResultsSubmitBtn;
	private boolean initialized = false;

	private static String propHost;
	private static String propPort;
	private static String optInIPPApplicantResourceUrl;
	private static String sendProofingResultsResourceUrl;
	private static String requestEnrollmentCodeResourceUrl;
	private static String getProofingResultsResourceUrl;
	private static final String RESOURCE_STREAM_PATH = "/ips.properties";
	private static final String PROXY_HOST_PROP_NAME = "com.ipsweb.proxyHost";
	private static final String PROXY_PORT_PROP_NAME = "com.ipsweb.proxyPort";
	private static final String URL_OPT_IN_IPP_APPLICANT_WS = "com.ipsweb.OptInIPPApplicantWs";
	private static final String URL_SEND_PROOFING_RESULTS_WS = "com.ipsweb.SendProofingResultsWs";
	private static final String URL_REQUEST_ENROLLMENT_CODE_WS = "com.ipsweb.RequestEnrollmentCodeWs";
	private static final String URL_GET_PROOFING_RESULTS_WS = "com.ipsweb.GetProofingResultsWs";
	private static final String ERROR_MSG_READING_PROP_FMT = "Error occured reading from properties file for %s.";
	private static final String WS_OPT_IN_IPP_APPLICANT = "OptInIPPApplicant";
	private static final String WS_SEND_PROOFING_RESULTS = "SendProofingResults";
	private static final String WS_REQUEST_ENROLLMENT_CODE = "RequestEnrollmentCode";
	private static final String WS_GET_PROOFING_RESULTS = "GetProofingResults";

	private static final String FIELD_ORIGIN = "Origin";
	private static final String FIELD_REQUEST_ID = "RequestID";

	private static final String KEY_ALTERNATE_EMAIL = "alternateEmail";
	private static final String KEY_APPLICATION = "application";
	private static final String KEY_AUTHORIZATION = "authorization";
	private static final String KEY_CITY = "city";
	private static final String KEY_CONFIRMATION_NUMBER = "confirmationNumber";
	private static final String KEY_EMAIL_ADDRESS = "emailAddress";
	private static final String KEY_ENROLLMENT_CODE = "enrollmentCode";
	private static final String KEY_FAILURE_REASON_CODE = "failureReasonCode";
	private static final String KEY_FIRST_NAME = "firstName";
	private static final String KEY_IPP_ASSURANCE_LEVEL = "IPPAssuranceLevel";
	private static final String KEY_LAST_NAME = "lastName";
	private static final String KEY_PHONE_NUMBER = "phoneNumber";
	private static final String KEY_PRIMARY_ID_TYPE = "primaryIdType";
	private static final String KEY_PROOFER_ACE_ID = "prooferAceId";
	private static final String KEY_PROOFER_FIRST_NAME = "prooferFirstName";
	private static final String KEY_PROOFER_LAST_NAME = "prooferLastName";
	private static final String KEY_PROOFING_LOCATION = "proofingLocation";
	private static final String KEY_RECORD_LOCATOR = "recordLocator";
	private static final String KEY_RESPONSE_MESSAGE = "responseMessage";
	private static final String KEY_SECONDARY_ID_TYPE = "secondaryIdType";
	private static final String KEY_SPONSOR_ID = "sponsorID";
	private static final String KEY_STATE = "state";
	private static final String KEY_STATUS = "status";
	private static final String KEY_STREET_ADDRESS = "streetAddress";
	private static final String KEY_SUSPECT_FRAUD = "suspectFraud";
	private static final String KEY_TRANSACTION_END_DATE_TIME = "transactionEndDateTime";
	private static final String KEY_TRANSACTION_START_DATE_TIME = "transactionStartDateTime";
	private static final String KEY_UNIQUE_ID = "uniqueID";
	private static final String KEY_ZIP_CODE = "zipCode";

	private static final String MSG_SUCCESSFULLY_GENERATED_FMT = "%s web service request was successfully generated!";
	private static final String MSG_SUCCESSFULLY_SUBMITTED_FMT = "%s web service request was successfully submitted!";
	private static final String MSG_REQUEST_JSON_FMT = "%s requestJson: %s";
	private static final String MSG_RESPONSE_JSON_FMT = "%s responseJson: %s";
	private static final String METHOD_TYPE_SUBMIT = "Submit";
	private static final String METHOD_TYPE_GENERATE = "Generate";

	/********** Initialization Methods **********/

	@PostConstruct
	public void init() {
		CustomLogger.enter(this.getClass());

		if (isInitialized()) {
			return;
		}

		setInitialized(true);
		initListAndServices();
		loadIpsProperties();

		hideMessages();
	}

	/**
	 * Initialize query services and entity lists.
	 * 
	 * @param
	 * @return void
	 */
	private void initListAndServices() {
		CustomLogger.enter(this.getClass());

		servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		webAppContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
		httpServletRequest = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		setServerName(httpServletRequest.getServerName());
		if (webAppContext != null) {
			IvsAdminUserService ivsAdminUserService = webAppContext.getBean(IvsAdminUserService.class);
			adminService = webAppContext.getBean(AdminService.class);

			String username = (String) httpServletRequest.getSession().getAttribute("IVSToken");
			IvsAdminUser adminUser = ivsAdminUserService.findByUserId(username);

			setSrProoferAceId(username);
			setSrProoferFirstName(adminUser.getFirstName());
			setSrProoferLastName(adminUser.getLastName());

			long transactionEpochDate = System.currentTimeMillis() / 1000;
			setSrTransactionStartDateTime(transactionEpochDate);
			setSrTransactionEndDateTime(transactionEpochDate);
			setSrAuthorization("1PPf0rIVSIPPmP0$");
			setSrApplication("IVSIPP");

			try {
				allSponsorList = retrieveAllSponsorList();
				allIppEventStatusList = retrieveAllIppEventStatusList();
				allPrimaryIdTypeList = retrieveAllPrimaryIdTypeList();
				allSecondaryIdTypeList = retrieveAllSecondaryIdTypeList();
				allIppFailureReasonList = retrieveAllIppFailureReasonList();
			} catch (Exception ex) {
				CustomLogger.error(this.getClass(), "Error occurs in getting entity lists.", ex);
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/**
	 * Generate OptInIPPApplicant request Json to be used as input in testing with
	 * Postman or SoapUI.
	 * 
	 * @param
	 * @return void
	 */
	public void generateOptInIPPApplicantRequest() {
		CustomLogger.enter(this.getClass());
		if (webAppContext != null) {
			RefSponsorDataService refSponsorDataService = webAppContext.getBean(RefSponsorDataService.class);

			oiSponsorId = selectedRefSponsorId;
			selectedRefSponsor = refSponsorDataService.findByPK(oiSponsorId);

			oiRequestHashMap = new LinkedHashMap<>();

			oiRequestHashMap.put(KEY_SPONSOR_ID, oiSponsorId);
			oiRequestHashMap.put(KEY_UNIQUE_ID, oiSponsorUserId);
			oiRequestHashMap.put(KEY_FIRST_NAME, oiFirstName);
			oiRequestHashMap.put(KEY_LAST_NAME, oiLastName);
			oiRequestHashMap.put(KEY_STREET_ADDRESS, oiStreetAddress);
			oiRequestHashMap.put(KEY_CITY, oiCity);
			oiRequestHashMap.put(KEY_STATE, oiState);
			oiRequestHashMap.put(KEY_ZIP_CODE, oiZip5);
			oiRequestHashMap.put(KEY_EMAIL_ADDRESS, oiEmailAddress);
			oiRequestHashMap.put(KEY_ALTERNATE_EMAIL, oiAlternateEmail);
			oiRequestHashMap.put(KEY_PHONE_NUMBER, oiPhoneNumber);
			oiRequestHashMap.put(KEY_IPP_ASSURANCE_LEVEL, oiIPPAssuranceLevel);

			Gson g = new Gson();
			String rawJsonRequest = g.toJson(oiRequestHashMap);

			@SuppressWarnings("deprecation")
			JsonParser parser = new JsonParser();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();

			@SuppressWarnings("deprecation")
			JsonElement requestJsonEl = parser.parse(rawJsonRequest);
			String jsonRequestFmtd = gson.toJson(requestJsonEl);
			setOiJsonRequest(jsonRequestFmtd);
			setOiJsonRequestHold(jsonRequestFmtd);
			String methodType = METHOD_TYPE_GENERATE;

			populateOtherForms(WS_OPT_IN_IPP_APPLICANT, WS_SEND_PROOFING_RESULTS, methodType);
			populateOtherForms(WS_OPT_IN_IPP_APPLICANT, WS_REQUEST_ENROLLMENT_CODE, methodType);
			populateOtherForms(WS_OPT_IN_IPP_APPLICANT, WS_GET_PROOFING_RESULTS, methodType);

			hideMessages();
			setOptInIPPApplicantSuccessMsg(String.format(MSG_SUCCESSFULLY_GENERATED_FMT, WS_OPT_IN_IPP_APPLICANT));
			setShowOptInIPPApplicantSuccessMsg(true);
			setShowOptInIPPApplicantErrorMsg(false);
			setShowOptInIPPApplicantRequestJsonPanel(true);
			setShowOptInIPPApplicantSubmitBtn(true);
			setShowSendProofingResultsGenerateBtn(true);
			setShowRequestEnrollmentCodeGenerateBtn(true);
			setShowGetProofingResultsGenerateBtn(true);
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/**
	 * Submit request to call OptInIPPApplicant in-person proofing web service
	 * end-point.
	 * 
	 * @param
	 * @return void
	 */
	@SuppressWarnings("unchecked")
	public void submitOptInIPPApplicantRequest() {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		String requestJsonStr = g.toJson(oiRequestHashMap);
		CustomLogger.debug(this.getClass(),
				String.format(MSG_REQUEST_JSON_FMT, WS_OPT_IN_IPP_APPLICANT, requestJsonStr));

		String responseJsonStr = "";

		if (adminService.isLocalServer()) {
			JSONObject requestJsonObj = new JSONObject();
			requestJsonObj.putAll(oiRequestHashMap);
			responseJsonStr = getLocalResponseJsonString(requestJsonObj, null, WS_OPT_IN_IPP_APPLICANT);
		} else {
			Resource resource = getClientResource(optInIPPApplicantResourceUrl);
			CustomLogger.debug(this.getClass(), "OptInIPPApplicant resourceUrl:" + optInIPPApplicantResourceUrl);

			responseJsonStr = getResponseJsonString(resource, requestJsonStr, WS_OPT_IN_IPP_APPLICANT);
		}

		CustomLogger.debug(this.getClass(),
				String.format(MSG_RESPONSE_JSON_FMT, WS_OPT_IN_IPP_APPLICANT, responseJsonStr));

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		@SuppressWarnings("deprecation")
		JsonElement responseJsonEl = parser.parse(responseJsonStr);
		setOiJsonResponse(gson.toJson(responseJsonEl));
		String methodType = METHOD_TYPE_SUBMIT;

		JSONObject responseJsonObj = g.fromJson(responseJsonStr, JSONObject.class);
		String recordLocator = (String) responseJsonObj.get(KEY_ENROLLMENT_CODE);

		selectedIppEvent = findIppEventByRecordLocator(recordLocator);

		if (selectedIppEvent != null) {
			selectedPerson = selectedIppEvent.getPerson();
		}

		populateOtherForms(WS_OPT_IN_IPP_APPLICANT, WS_SEND_PROOFING_RESULTS, methodType);
		populateOtherForms(WS_OPT_IN_IPP_APPLICANT, WS_REQUEST_ENROLLMENT_CODE, methodType);
		populateOtherForms(WS_OPT_IN_IPP_APPLICANT, WS_GET_PROOFING_RESULTS, methodType);

		hideMessages();
		setOptInIPPApplicantSuccessMsg(String.format(MSG_SUCCESSFULLY_SUBMITTED_FMT, WS_OPT_IN_IPP_APPLICANT));
		setShowOptInIPPApplicantSuccessMsg(true);
		setShowOptInIPPApplicantErrorMsg(false);
		setShowOptInIPPApplicantResponseJsonPanel(true);
	}

	/**
	 * Generate SendProofingResults request Json to be used as input in testing with
	 * Postman or SoapUI.
	 * 
	 * @param
	 * @return void
	 */
	public void generateSendProofingResultsRequest() {
		CustomLogger.enter(this.getClass());

		srStatus = selectedRefIppEventStatusId;
		srPrimaryIdType = selectedRefPrimaryIdTypeId;
		srSecondaryIdType = selectedRefSecondaryIdTypeId;
		srFailureReasonCode = selectedRefIppFailureReasonId;
		srSuspectFraud = isSuspectFraud() ? "Y" : "N";
		srRequestHashMap = new LinkedHashMap<>();

		srRequestHashMap.put(KEY_STATUS, srStatus);
		srRequestHashMap.put(KEY_PROOFER_FIRST_NAME, srProoferFirstName);
		srRequestHashMap.put(KEY_PROOFER_LAST_NAME, srProoferLastName);
		srRequestHashMap.put(KEY_PROOFER_ACE_ID, srProoferAceId);
		srRequestHashMap.put(KEY_RECORD_LOCATOR, srRecordLocator);
		srRequestHashMap.put(KEY_PROOFING_LOCATION, srProofingLocation);
		srRequestHashMap.put(KEY_PRIMARY_ID_TYPE, srPrimaryIdType);
		srRequestHashMap.put(KEY_SECONDARY_ID_TYPE, srSecondaryIdType);
		srRequestHashMap.put(KEY_FAILURE_REASON_CODE, srFailureReasonCode);
		srRequestHashMap.put(KEY_CONFIRMATION_NUMBER, srConfirmationNumber);
		srRequestHashMap.put(KEY_SUSPECT_FRAUD, srSuspectFraud);
		srRequestHashMap.put(KEY_TRANSACTION_START_DATE_TIME, srTransactionStartDateTime);
		srRequestHashMap.put(KEY_TRANSACTION_END_DATE_TIME, srTransactionEndDateTime);
		srRequestHashMap.put(KEY_AUTHORIZATION, srAuthorization);
		srRequestHashMap.put(KEY_APPLICATION, srApplication);

		Gson g = new Gson();
		String rawJsonRequest = g.toJson(srRequestHashMap);

		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();

		@SuppressWarnings("deprecation")
		JsonElement requestJsonEl = parser.parse(rawJsonRequest);
		String jsonRequestFmtd = gson.toJson(requestJsonEl);
		setSrJsonRequest(jsonRequestFmtd);
		setSrJsonRequestHold(jsonRequestFmtd);
		String methodType = METHOD_TYPE_GENERATE;

		populateOtherForms(WS_SEND_PROOFING_RESULTS, WS_REQUEST_ENROLLMENT_CODE, methodType);
		populateOtherForms(WS_SEND_PROOFING_RESULTS, WS_GET_PROOFING_RESULTS, methodType);

		hideMessages();
		setSendProofingResultsSuccessMsg(String.format(MSG_SUCCESSFULLY_GENERATED_FMT, WS_SEND_PROOFING_RESULTS));
		setShowSendProofingResultsSuccessMsg(true);
		setShowSendProofingResultsErrorMsg(false);
		setShowSendProofingResultsRequestJsonPanel(true);
		setShowSendProofingResultsSubmitBtn(true);
	}

	/**
	 * Submit request to call SendProofingResults in-person proofing web service
	 * end-point.
	 * 
	 * @param
	 * @return void
	 */
	public void submitSendProofingResultsRequest() {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		String requestJsonStr = g.toJson(srRequestHashMap);

		CustomLogger.debug(this.getClass(),
				String.format(MSG_REQUEST_JSON_FMT, WS_SEND_PROOFING_RESULTS, requestJsonStr));

		String responseJsonStr = "";

		if (adminService.isLocalServer()) {
			InPersonRequest ipRequest = g.fromJson(requestJsonStr, InPersonRequest.class);
			responseJsonStr = getLocalResponseJsonString(null, ipRequest, WS_SEND_PROOFING_RESULTS);
		} else {
			Resource resource = getClientResource(sendProofingResultsResourceUrl);
			CustomLogger.debug(this.getClass(), "SendProofingResults resourceUrl:" + sendProofingResultsResourceUrl);

			responseJsonStr = getResponseJsonString(resource, requestJsonStr, WS_SEND_PROOFING_RESULTS);
		}

		CustomLogger.debug(this.getClass(),
				String.format(MSG_RESPONSE_JSON_FMT, WS_SEND_PROOFING_RESULTS, responseJsonStr));

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		@SuppressWarnings("deprecation")
		JsonElement responseJsonEl = parser.parse(responseJsonStr);
		setSrJsonResponse(gson.toJson(responseJsonEl));
		String methodType = METHOD_TYPE_SUBMIT;

		populateOtherForms(WS_SEND_PROOFING_RESULTS, WS_REQUEST_ENROLLMENT_CODE, methodType);
		populateOtherForms(WS_SEND_PROOFING_RESULTS, WS_GET_PROOFING_RESULTS, methodType);

		hideMessages();
		setSendProofingResultsSuccessMsg(String.format(MSG_SUCCESSFULLY_SUBMITTED_FMT, WS_SEND_PROOFING_RESULTS));
		setShowSendProofingResultsSuccessMsg(true);
		setShowSendProofingResultsErrorMsg(false);
		setShowSendProofingResultsResponseJsonPanel(true);
	}

	/**
	 * Generate RequestEnrollmentCode request Json to be used as input in testing
	 * with Postman or SoapUI.
	 * 
	 * @param
	 * @return void
	 */
	public void generateRequestEnrollmentCodeRequest() {
		CustomLogger.enter(this.getClass());

		reRequestHashMap = new LinkedHashMap<>();

		reRequestHashMap.put(KEY_SPONSOR_ID, reSponsorId);
		reRequestHashMap.put(KEY_UNIQUE_ID, reSponsorUserId);

		Gson g = new Gson();
		String rawJsonRequest = g.toJson(reRequestHashMap);

		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();

		@SuppressWarnings("deprecation")
		JsonElement requestJsonEl = parser.parse(rawJsonRequest);
		String jsonRequestFmtd = gson.toJson(requestJsonEl);
		setReJsonRequest(jsonRequestFmtd);
		setReJsonRequestHold(jsonRequestFmtd);

		hideMessages();
		setRequestEnrollmentCodeSuccessMsg(String.format(MSG_SUCCESSFULLY_GENERATED_FMT, WS_REQUEST_ENROLLMENT_CODE));
		setShowRequestEnrollmentCodeSuccessMsg(true);
		setShowRequestEnrollmentCodeErrorMsg(false);
		setShowRequestEnrollmentCodeRequestJsonPanel(true);
		setShowRequestEnrollmentCodeSubmitBtn(true);
	}

	/**
	 * Submit request to call RequestEnrollmentCode remote proofing web service
	 * end-point.
	 * 
	 * @param
	 * @return void
	 */
	@SuppressWarnings("unchecked")
	public void submitRequestEnrollmentCodeRequest() {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		String requestJsonStr = g.toJson(reRequestHashMap);

		CustomLogger.debug(this.getClass(),
				String.format(MSG_REQUEST_JSON_FMT, WS_REQUEST_ENROLLMENT_CODE, requestJsonStr));

		String responseJsonStr = "";

		if (adminService.isLocalServer()) {
			JSONObject requestJsonObj = new JSONObject();
			requestJsonObj.putAll(reRequestHashMap);
			responseJsonStr = getLocalResponseJsonString(requestJsonObj, null, WS_REQUEST_ENROLLMENT_CODE);
		} else {
			Resource resource = getClientResource(requestEnrollmentCodeResourceUrl);
			CustomLogger.debug(this.getClass(),
					"RequestEnrollmentCode resourceUrl:" + requestEnrollmentCodeResourceUrl);

			responseJsonStr = getResponseJsonString(resource, requestJsonStr, WS_REQUEST_ENROLLMENT_CODE);
		}

		CustomLogger.debug(this.getClass(),
				String.format(MSG_RESPONSE_JSON_FMT, WS_REQUEST_ENROLLMENT_CODE, responseJsonStr));

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		@SuppressWarnings("deprecation")
		JsonElement responseJsonEl = parser.parse(responseJsonStr);
		setReJsonResponse(gson.toJson(responseJsonEl));

		hideMessages();
		setRequestEnrollmentCodeSuccessMsg(String.format(MSG_SUCCESSFULLY_SUBMITTED_FMT, WS_REQUEST_ENROLLMENT_CODE));
		setShowRequestEnrollmentCodeSuccessMsg(true);
		setShowRequestEnrollmentCodeErrorMsg(false);
		setShowRequestEnrollmentCodeResponseJsonPanel(true);
	}

	/**
	 * Generate GetProofingResults request Json to be used as input in testing with
	 * Postman or SoapUI.
	 * 
	 * @param
	 * @return void
	 */
	public void generateGetProofingResultsRequest() {
		CustomLogger.enter(this.getClass());

		grRequestHashMap = new LinkedHashMap<>();

		grRequestHashMap.put(KEY_SPONSOR_ID, grSponsorId);
		grRequestHashMap.put(KEY_UNIQUE_ID, reSponsorUserId);
		grRequestHashMap.put(KEY_ENROLLMENT_CODE, grEnrollmentCode);

		Gson g = new Gson();
		String rawJsonRequest = g.toJson(grRequestHashMap);

		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();

		@SuppressWarnings("deprecation")
		JsonElement requestJsonEl = parser.parse(rawJsonRequest);
		String jsonRequestFmtd = gson.toJson(requestJsonEl);
		setGrJsonRequest(jsonRequestFmtd);

		hideMessages();
		setGetProofingResultsSuccessMsg(String.format(MSG_SUCCESSFULLY_GENERATED_FMT, WS_GET_PROOFING_RESULTS));
		setShowGetProofingResultsSuccessMsg(true);
		setShowGetProofingResultsErrorMsg(false);
		setShowGetProofingResultsRequestJsonPanel(true);
		setShowGetProofingResultsSubmitBtn(true);
	}

	/**
	 * Submit request to call GetProofingResults remote proofing web service
	 * end-point.
	 * 
	 * @param
	 * @return void
	 */
	@SuppressWarnings("unchecked")
	public void submitGetProofingResultsRequest() {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		@SuppressWarnings("deprecation")
		JsonParser parser = new JsonParser();
		String requestJsonStr = g.toJson(grRequestHashMap);

		CustomLogger.debug(this.getClass(),
				String.format(MSG_REQUEST_JSON_FMT, WS_GET_PROOFING_RESULTS, requestJsonStr));

		String responseJsonStr = "";

		if (adminService.isLocalServer()) {
			JSONObject requestJsonObj = new JSONObject();
			requestJsonObj.putAll(grRequestHashMap);
			responseJsonStr = getLocalResponseJsonString(requestJsonObj, null, WS_GET_PROOFING_RESULTS);
		} else {
			Resource resource = getClientResource(getProofingResultsResourceUrl);
			CustomLogger.debug(this.getClass(), "GetProofingResults resourceUrl:" + getProofingResultsResourceUrl);

			responseJsonStr = getResponseJsonString(resource, requestJsonStr, WS_GET_PROOFING_RESULTS);
		}

		CustomLogger.debug(this.getClass(),
				String.format(MSG_RESPONSE_JSON_FMT, WS_GET_PROOFING_RESULTS, responseJsonStr));

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		@SuppressWarnings("deprecation")
		JsonElement responseJsonEl = parser.parse(responseJsonStr);
		setGrJsonResponse(gson.toJson(responseJsonEl));

		hideMessages();
		setGetProofingResultsSuccessMsg(String.format(MSG_SUCCESSFULLY_SUBMITTED_FMT, WS_GET_PROOFING_RESULTS));
		setShowGetProofingResultsSuccessMsg(true);
		setShowGetProofingResultsErrorMsg(false);
		setShowGetProofingResultsResponseJsonPanel(true);
	}

	/**
	 * Generate Unique ID using hash code for FirstName, LastName, EmailAddress,
	 * MobileNumber and ProfilingSessionId. Remove leading zeroes and sign.
	 * 
	 * @param
	 * @return void
	 */
	public void generateRequestId(String webServiceName) {
		CustomLogger.enter(this.getClass());

		String randomId = UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
		String suffixStr = randomId.length() > 10 ? randomId.substring(0, 8) : randomId;
		String requestId = "OS-REQ".concat(suffixStr);

		if (WS_OPT_IN_IPP_APPLICANT.equalsIgnoreCase(webServiceName)) {
			oiRequestId = requestId;
		} else if (WS_REQUEST_ENROLLMENT_CODE.equalsIgnoreCase(webServiceName)) {
			reRequestId = requestId;
		} else if (WS_GET_PROOFING_RESULTS.equalsIgnoreCase(webServiceName)) {
			grRequestId = requestId;
		}

	}

	public void generateProofingLocation() {
		CustomLogger.enter(this.getClass());

		int intRandom = ThreadLocalRandom.current().nextInt();
		String strRandom = String.valueOf(intRandom).replace("-", "");
		srProofingLocation = strRandom;
	}

	public void generateConfirmationNumber() {
		CustomLogger.enter(this.getClass());

		int intRandom = ThreadLocalRandom.current().nextInt();
		String strRandom = String.valueOf(intRandom).replace("-", "");
		srConfirmationNumber = String.format("CN%s", strRandom);
	}

	public void retrieveRecordLocator(String webServiceName) {
		CustomLogger.enter(this.getClass());
		if (webAppContext != null) {
			String recordLocator = "";
			if (selectedIppEvent != null && selectedIppEvent.getRecordLocator() != null) {
				recordLocator = selectedIppEvent.getRecordLocator();
			} else {
				if (selectedRefSponsor == null) {
					RefSponsorDataService refSponsorDataService = webAppContext.getBean(RefSponsorDataService.class);
					selectedRefSponsor = refSponsorDataService.findByPK(oiSponsorId);

					if (selectedRefSponsor == null) {
						return;
					}
				}

				PersonDataService personService = webAppContext.getBean(PersonDataService.class);
				selectedPerson = personService.findFirstBySponsor(selectedRefSponsor, oiSponsorUserId);

				if (selectedPerson != null) {
					IPSRestResourceService ipsRestResourceService = webAppContext.getBean(IPSRestResourceService.class);
					IppEvent recentEvent = ipsRestResourceService.getMostRecentPersonIppEvent(selectedPerson);
					recordLocator = recentEvent.getRecordLocator();
				}
			}

			if (WS_SEND_PROOFING_RESULTS.equalsIgnoreCase(webServiceName)) {
				srRecordLocator = recordLocator;
			} else if (WS_GET_PROOFING_RESULTS.equalsIgnoreCase(webServiceName)) {
				grEnrollmentCode = recordLocator;
			}
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve AdminService.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/**
	 * Generate Unique ID using hash code for FirstName, LastName, EmailAddress,
	 * MobileNumber and ProfilingSessionId. Remove leading zeroes and sign.
	 * 
	 * @param
	 * @return void
	 */
	public void generateUniqueId() {
		CustomLogger.enter(this.getClass());

		int intRandom = ThreadLocalRandom.current().nextInt();
		String strRandom = String.valueOf(intRandom).replace("-", "");
		strRandom = strRandom.length() > 8 ? strRandom.substring(0, 8) : strRandom;
		oiSponsorUserId = String.format("OS-ID%s", strRandom);
	}

	/********** Common Private Methods **********/

	/**
	 * Pre-populate other forms when form generates the request Json.
	 * 
	 * @param
	 * @return String
	 */
	private void populateOtherForms(String sourceForm, String destForm, String method) {
		CustomLogger.enter(this.getClass());

		if (METHOD_TYPE_GENERATE.equalsIgnoreCase(method)) {
			switch (sourceForm) {
			case WS_OPT_IN_IPP_APPLICANT:
				switch (destForm) {
				case WS_OPT_IN_IPP_APPLICANT:
					break;
				case WS_SEND_PROOFING_RESULTS:
					break;
				case WS_REQUEST_ENROLLMENT_CODE:
					setReSponsorId(oiSponsorId);
					setReSponsorUserId(oiSponsorUserId);
					setReOrigin(oiOrigin);
					break;
				case WS_GET_PROOFING_RESULTS:
					setGrSponsorId(oiSponsorId);
					setGrSponsorUserId(oiSponsorUserId);
					setGrOrigin(oiOrigin);
					break;
				default:
				}
				break;
			case WS_SEND_PROOFING_RESULTS:
				break;
			case WS_REQUEST_ENROLLMENT_CODE:
				break;
			case WS_GET_PROOFING_RESULTS:

				break;
			default:
			}
		} else if (METHOD_TYPE_SUBMIT.equalsIgnoreCase(method)) {
			switch (sourceForm) {
			case WS_OPT_IN_IPP_APPLICANT:
				switch (destForm) {
				case WS_OPT_IN_IPP_APPLICANT:
					break;
				case WS_SEND_PROOFING_RESULTS:
					// private String srProofingLocation; load the location list
					break;
				case WS_REQUEST_ENROLLMENT_CODE:
					break;
				case WS_GET_PROOFING_RESULTS:
					break;
				default:
				}
				break;
			case WS_SEND_PROOFING_RESULTS:
				break;
			case WS_REQUEST_ENROLLMENT_CODE:
				break;
			case WS_GET_PROOFING_RESULTS:
				break;
			default:
			}
		}

	}

	/**
	 * Obtain the client resource for the input uri.
	 * 
	 * @param
	 * @return String
	 */
	private Resource getClientResource(String inputUrl) {
		CustomLogger.enter(this.getClass());

		ClientConfig config = new ClientConfig();
		config.proxyHost(propHost);
		config.proxyPort(Integer.parseInt(propPort));

		RestClient client = new RestClient(config);

		return client.resource(inputUrl);
	}

	/**
	 * Load IPS Properties needed to retrieve Host, Port and Resource URL for a
	 * particular environment.
	 * 
	 * @param
	 * @return void
	 */
	private void loadIpsProperties() {
		CustomLogger.enter(this.getClass());

		try {
			Properties prop = getProperties();
			String environment = Utils.getEnvironment();

			List<String> propNames = new ArrayList<>();
			propNames.add(PROXY_HOST_PROP_NAME);
			propNames.add(PROXY_PORT_PROP_NAME);
			propNames.add(URL_OPT_IN_IPP_APPLICANT_WS);
			propNames.add(URL_SEND_PROOFING_RESULTS_WS);
			propNames.add(URL_REQUEST_ENROLLMENT_CODE_WS);
			propNames.add(URL_GET_PROOFING_RESULTS_WS);

			List<String> propValues = new ArrayList<>();

			for (String item : propNames) {
				String propName = environment.concat(item);
				String propValue = prop.getProperty(propName);

				if (propValue == null) {
					CustomLogger.error(this.getClass(), String.format(ERROR_MSG_READING_PROP_FMT, propName));
				}

				propValues.add(propValue);
			}

			if (!propValues.isEmpty()) {
				propHost = propValues.get(0);
				propPort = propValues.get(1);
				optInIPPApplicantResourceUrl = propValues.get(2);
				sendProofingResultsResourceUrl = propValues.get(3);
				requestEnrollmentCodeResourceUrl = propValues.get(4);
				getProofingResultsResourceUrl = propValues.get(5);
			}
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(), "Could not load ips.properties", ex);
		}
	}

	/**
	 * Return Properties after loading it with Host, Port and Resource URL Property
	 * data
	 * 
	 * @param
	 * @return Properties
	 */
	private Properties getProperties() {
		CustomLogger.enter(this.getClass());

		InputStream input = null;
		Properties prop = new Properties();

		try {
			input = IPPRestIdentityVerificationBean.class.getClassLoader().getResourceAsStream(RESOURCE_STREAM_PATH);
			// load a properties file
			prop.load(input);
		} catch (Exception ex) {
			CustomLogger.error(this.getClass(), "Could not load ips.properties", ex);
		}

		return prop;
	}

	/**
	 * Hide the messages for initialization.
	 * 
	 * @param
	 * @return String
	 */
	private void hideMessages() {
		CustomLogger.enter(this.getClass());

		setShowGetIppFacilityListInstMsg(false);
		setShowGetIppFacilityListErrorMsg(false);
		setShowGetIppFacilityListSuccessMsg(false);

		setShowOptInIPPApplicantInstMsg(false);
		setShowOptInIPPApplicantErrorMsg(false);
		setShowOptInIPPApplicantSuccessMsg(false);

		setShowSendProofingResultsInstMsg(false);
		setShowSendProofingResultsErrorMsg(false);
		setShowSendProofingResultsSuccessMsg(false);

		setShowRequestEnrollmentCodeInstMsg(false);
		setShowRequestEnrollmentCodeErrorMsg(false);
		setShowRequestEnrollmentCodeSuccessMsg(false);

		setShowGetProofingResultsInstMsg(false);
		setShowGetProofingResultsErrorMsg(false);
		setShowGetProofingResultsSuccessMsg(false);
	}

	private String getResponseJsonString(Resource resource, String requestJsonStr, String webServiceName) {
		CustomLogger.enter(this.getClass());

		Gson g = new Gson();
		JSONObject responseJsonObj = new JSONObject();
		String responseJsonStr = "";
		String responseMessage = "";
		boolean hasResponse = false;

		try {
			switch (webServiceName) {
			case WS_OPT_IN_IPP_APPLICANT:
				responseJsonObj = resource.contentType(MediaType.APPLICATION_JSON).header(FIELD_ORIGIN, oiOrigin)
						.header(FIELD_REQUEST_ID, oiRequestId).post(JSONObject.class, requestJsonStr);
				break;
			case WS_SEND_PROOFING_RESULTS:
				responseJsonObj = resource.contentType(MediaType.APPLICATION_JSON).post(JSONObject.class,
						requestJsonStr);
				break;
			case WS_REQUEST_ENROLLMENT_CODE:
				responseJsonObj = resource.contentType(MediaType.APPLICATION_JSON).header(FIELD_ORIGIN, reOrigin)
						.header(FIELD_REQUEST_ID, reRequestId).post(JSONObject.class, requestJsonStr);
				break;
			case WS_GET_PROOFING_RESULTS:
				responseJsonObj = resource.contentType(MediaType.APPLICATION_JSON).header(FIELD_ORIGIN, grOrigin)
						.header(FIELD_REQUEST_ID, grRequestId).post(JSONObject.class, requestJsonStr);
				break;
			default:
			}

			responseJsonStr = g.toJson(responseJsonObj);
			hasResponse = true;
		} catch (ClientWebException e) {
			Object entity = e.getResponse().getEntity(JSONObject.class);
			responseJsonStr = g.toJson(entity);
			hasResponse = true;
		} catch (ClientRuntimeException e) {
			CustomLogger.error(this.getClass(), "ClientRuntimeException occurs in getting Resource response from "
					+ webServiceName + " web service:" + e.getMessage(), e);
			responseMessage = "ClientRuntimeException occurs in getting resource response";
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Exception occurs in getting Resource response from " + webServiceName
					+ " web service:" + e.getMessage(), e);
			responseMessage = "Exception occurs in getting resource response";
		}

		if (!hasResponse) {
			JSONObject defaultRespObj = new JSONObject();
			defaultRespObj.put(KEY_RESPONSE_MESSAGE, responseMessage);
			responseJsonStr = g.toJson(defaultRespObj);
			CustomLogger.debug(this.getClass(), "Default Response JSON::" + responseJsonStr);
		}

		return responseJsonStr;
	}

	private String getLocalResponseJsonString(JSONObject requestJsonObj, InPersonRequest ipRequest,
			String webServiceName) {
		CustomLogger.enter(this.getClass());
		if (webAppContext != null) {
			IPSRestResourceService ipsRestResourceService = webAppContext.getBean(IPSRestResourceService.class);
			Response response = null;

			switch (webServiceName) {
			case WS_OPT_IN_IPP_APPLICANT:
				response = ipsRestResourceService.optInIPPApplicant(requestJsonObj, oiOrigin, oiRequestId);
				break;
			case WS_SEND_PROOFING_RESULTS:
				response = ipsRestResourceService.sendProofingResults(ipRequest, httpServletRequest);
				break;
			case WS_REQUEST_ENROLLMENT_CODE:
				response = ipsRestResourceService.requestEnrollmentCode(requestJsonObj, reOrigin, reRequestId);
				break;
			case WS_GET_PROOFING_RESULTS:
				response = ipsRestResourceService.getProofingResults(requestJsonObj, grOrigin, grRequestId);
				break;
			default:
				response = ipsRestResourceService.getProofingResults(requestJsonObj, grOrigin, grRequestId);
			}

			Gson g = new Gson();

			return g.toJson(response.getEntity());
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve ipsRestResourceService.");
			goToPage(SYSTEM_ERROR_PAGE);
			return null;
		}
	}

	/** Service Queries **/

	public List<RefSponsor> retrieveAllSponsorList() {
		CustomLogger.enter(this.getClass());
		if (webAppContext != null) {
			RefSponsorDataService refSponsorDataService = webAppContext.getBean(RefSponsorDataService.class);
			return refSponsorDataService.list();
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve refSponsorDataService.");
			goToPage(SYSTEM_ERROR_PAGE);
			return null;
		}
	}

	public List<RefIppEventStatus> retrieveAllIppEventStatusList() {
		CustomLogger.enter(this.getClass());
		if (webAppContext != null) {
			RefIppEventStatusService refIppEventStatusService = webAppContext.getBean(RefIppEventStatusService.class);
			return refIppEventStatusService.list();
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve refIppEventStatusService.");
			goToPage(SYSTEM_ERROR_PAGE);
			return null;
		}
	}

	private IppEvent findIppEventByRecordLocator(String recordLocator) {
		CustomLogger.enter(this.getClass());
		if (webAppContext != null) {
			IppEventService ippEventService = webAppContext.getBean(IppEventService.class);
			return ippEventService.findByRecordLocator(recordLocator);
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve ippEventService.");
			goToPage(SYSTEM_ERROR_PAGE);
			return null;
		}
	}

	public List<RefPrimaryIdType> retrieveAllPrimaryIdTypeList() {
		CustomLogger.enter(this.getClass());
		if (webAppContext != null) {
			RefPrimaryIdTypeService refPrimaryIdTypeService = webAppContext.getBean(RefPrimaryIdTypeService.class);
			return refPrimaryIdTypeService.list();
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve refPrimaryIdTypeService.");
			goToPage(SYSTEM_ERROR_PAGE);
			return null;
		}
	}

	public List<RefSecondaryIdType> retrieveAllSecondaryIdTypeList() {
		CustomLogger.enter(this.getClass());
		if (webAppContext != null) {
			RefSecondaryIdTypeService refSecondaryIdTypeService = webAppContext
					.getBean(RefSecondaryIdTypeService.class);
			return refSecondaryIdTypeService.list();
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve refSecondaryIdTypeService.");
			goToPage(SYSTEM_ERROR_PAGE);
			return null;
		}
	}

	public List<RefIppFailureReason> retrieveAllIppFailureReasonList() {
		CustomLogger.enter(this.getClass());
		if (webAppContext != null) {
			RefIppFailureReasonService refIppFailureReasonService = webAppContext
					.getBean(RefIppFailureReasonService.class);
			return refIppFailureReasonService.list();
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve refIppFailureReasonService.");
			goToPage(SYSTEM_ERROR_PAGE);
			return null;
		}
	}

	public IppEvent getMostRecentIppEventByPerson(Person person) {
		CustomLogger.enter(this.getClass());

		List<IppEvent> ippEvents = person.getIppEvents();
		if (ippEvents != null && !ippEvents.isEmpty()) {
			ippEvents.sort((e1, e2) -> e2.getCreateDate().compareTo(e1.getCreateDate()));
			return ippEvents.get(0);
		}

		return null;
	}

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public long getOiSponsorId() {
		return oiSponsorId;
	}

	public void setOiSponsorId(long oiSponsorId) {
		this.oiSponsorId = oiSponsorId;
	}

	public String getOiSponsorUserId() {
		return oiSponsorUserId;
	}

	public void setOiSponsorUserId(String oiSponsorUserId) {
		this.oiSponsorUserId = oiSponsorUserId;
	}

	public String getOiFirstName() {
		return oiFirstName;
	}

	public void setOiFirstName(String oiFirstName) {
		this.oiFirstName = oiFirstName;
	}

	public String getOiLastName() {
		return oiLastName;
	}

	public void setOiLastName(String oiLastName) {
		this.oiLastName = oiLastName;
	}

	public String getOiStreetAddress() {
		return oiStreetAddress;
	}

	public void setOiStreetAddress(String oiStreetAddress) {
		this.oiStreetAddress = oiStreetAddress;
	}

	public String getOiCity() {
		return oiCity;
	}

	public void setOiCity(String oiCity) {
		this.oiCity = oiCity;
	}

	public String getOiState() {
		return oiState;
	}

	public void setOiState(String oiState) {
		this.oiState = oiState;
	}

	public String getOiZip5() {
		return oiZip5;
	}

	public void setOiZip5(String oiZip5) {
		this.oiZip5 = oiZip5;
	}

	public String getOiEmailAddress() {
		return oiEmailAddress;
	}

	public void setOiEmailAddress(String oiEmailAddress) {
		this.oiEmailAddress = oiEmailAddress;
	}

	public String getOiAlternateEmail() {
		return oiAlternateEmail;
	}

	public void setOiAlternateEmail(String oiAlternateEmail) {
		this.oiAlternateEmail = oiAlternateEmail;
	}

	public String getOiPhoneNumber() {
		return oiPhoneNumber;
	}

	public void setOiPhoneNumber(String oiPhoneNumber) {
		this.oiPhoneNumber = oiPhoneNumber;
	}

	public String getOiIPPAssuranceLevel() {
		return oiIPPAssuranceLevel;
	}

	public void setOiIPPAssuranceLevel(String oiIPPAssuranceLevel) {
		this.oiIPPAssuranceLevel = oiIPPAssuranceLevel;
	}

	public String getOiOrigin() {
		return oiOrigin;
	}

	public void setOiOrigin(String oiOrigin) {
		this.oiOrigin = oiOrigin;
	}

	public String getOiRequestId() {
		return oiRequestId;
	}

	public void setOiRequestId(String oiRequestId) {
		this.oiRequestId = oiRequestId;
	}

	public String getOiJsonRequest() {
		return oiJsonRequest;
	}

	public void setOiJsonRequest(String oiJsonRequest) {
		this.oiJsonRequest = oiJsonRequest;
	}

	public String getOiJsonRequestHold() {
		return oiJsonRequestHold;
	}

	public void setOiJsonRequestHold(String oiJsonRequestHold) {
		this.oiJsonRequestHold = oiJsonRequestHold;
	}

	public String getOiJsonResponse() {
		return oiJsonResponse;
	}

	public void setOiJsonResponse(String oiJsonResponse) {
		this.oiJsonResponse = oiJsonResponse;
	}

	public long getSrStatus() {
		return srStatus;
	}

	public void setSrStatus(long srStatus) {
		this.srStatus = srStatus;
	}

	public long getSrPrimaryIdType() {
		return srPrimaryIdType;
	}

	public void setSrPrimaryIdType(long srPrimaryIdType) {
		this.srPrimaryIdType = srPrimaryIdType;
	}

	public long getSrTransactionEndDateTime() {
		return srTransactionEndDateTime;
	}

	public void setSrTransactionEndDateTime(long srTransactionEndDateTime) {
		this.srTransactionEndDateTime = srTransactionEndDateTime;
	}

	public long getSrSecondaryIdType() {
		return srSecondaryIdType;
	}

	public void setSrSecondaryIdType(long srSecondaryIdType) {
		this.srSecondaryIdType = srSecondaryIdType;
	}

	public long getSrFailureReasonCode() {
		return srFailureReasonCode;
	}

	public void setSrFailureReasonCode(long srFailureReasonCode) {
		this.srFailureReasonCode = srFailureReasonCode;
	}

	public long getSrTransactionStartDateTime() {
		return srTransactionStartDateTime;
	}

	public void setSrTransactionStartDateTime(long srTransactionStartDateTime) {
		this.srTransactionStartDateTime = srTransactionStartDateTime;
	}

	public String getSrProoferFirstName() {
		return srProoferFirstName;
	}

	public void setSrProoferFirstName(String srProoferFirstName) {
		this.srProoferFirstName = srProoferFirstName;
	}

	public String getSrProoferLastName() {
		return srProoferLastName;
	}

	public void setSrProoferLastName(String srProoferLastName) {
		this.srProoferLastName = srProoferLastName;
	}

	public String getSrProofingLocation() {
		return srProofingLocation;
	}

	public void setSrProofingLocation(String srProofingLocation) {
		this.srProofingLocation = srProofingLocation;
	}

	public String getSrRecordLocator() {
		return srRecordLocator;
	}

	public void setSrRecordLocator(String srRecordLocator) {
		this.srRecordLocator = srRecordLocator;
	}

	public String getSrProoferAceId() {
		return srProoferAceId;
	}

	public void setSrProoferAceId(String srProoferAceId) {
		this.srProoferAceId = srProoferAceId;
	}

	public String getSrConfirmationNumber() {
		return srConfirmationNumber;
	}

	public void setSrConfirmationNumber(String srConfirmationNumber) {
		this.srConfirmationNumber = srConfirmationNumber;
	}

	public String getSrSuspectFraud() {
		return srSuspectFraud;
	}

	public void setSrSuspectFraud(String srSuspectFraud) {
		this.srSuspectFraud = srSuspectFraud;
	}

	public String getSrAuthorization() {
		return srAuthorization;
	}

	public void setSrAuthorization(String srAuthorization) {
		this.srAuthorization = srAuthorization;
	}

	public String getSrApplication() {
		return srApplication;
	}

	public void setSrApplication(String srApplication) {
		this.srApplication = srApplication;
	}

	public String getSrJsonRequest() {
		return srJsonRequest;
	}

	public void setSrJsonRequest(String srJsonRequest) {
		this.srJsonRequest = srJsonRequest;
	}

	public String getSrJsonRequestHold() {
		return srJsonRequestHold;
	}

	public void setSrJsonRequestHold(String srJsonRequestHold) {
		this.srJsonRequestHold = srJsonRequestHold;
	}

	public String getSrJsonResponse() {
		return srJsonResponse;
	}

	public void setSrJsonResponse(String srJsonResponse) {
		this.srJsonResponse = srJsonResponse;
	}

	public long getReSponsorId() {
		return reSponsorId;
	}

	public void setReSponsorId(long reSponsorId) {
		this.reSponsorId = reSponsorId;
	}

	public String getReSponsorUserId() {
		return reSponsorUserId;
	}

	public void setReSponsorUserId(String reSponsorUserId) {
		this.reSponsorUserId = reSponsorUserId;
	}

	public String getReJsonRequest() {
		return reJsonRequest;
	}

	public void setReJsonRequest(String reJsonRequest) {
		this.reJsonRequest = reJsonRequest;
	}

	public String getReJsonRequestHold() {
		return reJsonRequestHold;
	}

	public void setReJsonRequestHold(String reJsonRequestHold) {
		this.reJsonRequestHold = reJsonRequestHold;
	}

	public String getReJsonResponse() {
		return reJsonResponse;
	}

	public void setReJsonResponse(String reJsonResponse) {
		this.reJsonResponse = reJsonResponse;
	}

	public long getGrSponsorId() {
		return grSponsorId;
	}

	public void setGrSponsorId(long grSponsorId) {
		this.grSponsorId = grSponsorId;
	}

	public String getGrSponsorUserId() {
		return grSponsorUserId;
	}

	public void setGrSponsorUserId(String grSponsorUserId) {
		this.grSponsorUserId = grSponsorUserId;
	}

	public String getGrEnrollmentCode() {
		return grEnrollmentCode;
	}

	public void setGrEnrollmentCode(String grEnrollmentCode) {
		this.grEnrollmentCode = grEnrollmentCode;
	}

	public String getGrJsonRequest() {
		return grJsonRequest;
	}

	public void setGrJsonRequest(String grJsonRequest) {
		this.grJsonRequest = grJsonRequest;
	}

	public String getGrJsonResponse() {
		return grJsonResponse;
	}

	public void setGrJsonResponse(String grJsonResponse) {
		this.grJsonResponse = grJsonResponse;
	}

	public String getGetIppFacilityListInstMsg() {
		return getIppFacilityListInstMsg;
	}

	public void setGetIppFacilityListInstMsg(String getIppFacilityListInstMsg) {
		this.getIppFacilityListInstMsg = getIppFacilityListInstMsg;
	}

	public String getGetIppFacilityListErrorMsg() {
		return getIppFacilityListErrorMsg;
	}

	public void setGetIppFacilityListErrorMsg(String getIppFacilityListErrorMsg) {
		this.getIppFacilityListErrorMsg = getIppFacilityListErrorMsg;
	}

	public String getGetIppFacilityListSuccessMsg() {
		return getIppFacilityListSuccessMsg;
	}

	public void setGetIppFacilityListSuccessMsg(String getIppFacilityListSuccessMsg) {
		this.getIppFacilityListSuccessMsg = getIppFacilityListSuccessMsg;
	}

	public String getOptInIPPApplicantInstMsg() {
		return optInIPPApplicantInstMsg;
	}

	public void setOptInIPPApplicantInstMsg(String optInIPPApplicantInstMsg) {
		this.optInIPPApplicantInstMsg = optInIPPApplicantInstMsg;
	}

	public String getOptInIPPApplicantErrorMsg() {
		return optInIPPApplicantErrorMsg;
	}

	public void setOptInIPPApplicantErrorMsg(String optInIPPApplicantErrorMsg) {
		this.optInIPPApplicantErrorMsg = optInIPPApplicantErrorMsg;
	}

	public String getOptInIPPApplicantSuccessMsg() {
		return optInIPPApplicantSuccessMsg;
	}

	public void setOptInIPPApplicantSuccessMsg(String optInIPPApplicantSuccessMsg) {
		this.optInIPPApplicantSuccessMsg = optInIPPApplicantSuccessMsg;
	}

	public String getSendProofingResultsInstMsg() {
		return sendProofingResultsInstMsg;
	}

	public void setSendProofingResultsInstMsg(String sendProofingResultsInstMsg) {
		this.sendProofingResultsInstMsg = sendProofingResultsInstMsg;
	}

	public String getSendProofingResultsErrorMsg() {
		return sendProofingResultsErrorMsg;
	}

	public void setSendProofingResultsErrorMsg(String sendProofingResultsErrorMsg) {
		this.sendProofingResultsErrorMsg = sendProofingResultsErrorMsg;
	}

	public String getSendProofingResultsSuccessMsg() {
		return sendProofingResultsSuccessMsg;
	}

	public void setSendProofingResultsSuccessMsg(String sendProofingResultsSuccessMsg) {
		this.sendProofingResultsSuccessMsg = sendProofingResultsSuccessMsg;
	}

	public String getRequestEnrollmentCodeInstMsg() {
		return requestEnrollmentCodeInstMsg;
	}

	public void setRequestEnrollmentCodeInstMsg(String requestEnrollmentCodeInstMsg) {
		this.requestEnrollmentCodeInstMsg = requestEnrollmentCodeInstMsg;
	}

	public String getRequestEnrollmentCodeErrorMsg() {
		return requestEnrollmentCodeErrorMsg;
	}

	public void setRequestEnrollmentCodeErrorMsg(String requestEnrollmentCodeErrorMsg) {
		this.requestEnrollmentCodeErrorMsg = requestEnrollmentCodeErrorMsg;
	}

	public String getRequestEnrollmentCodeSuccessMsg() {
		return requestEnrollmentCodeSuccessMsg;
	}

	public void setRequestEnrollmentCodeSuccessMsg(String requestEnrollmentCodeSuccessMsg) {
		this.requestEnrollmentCodeSuccessMsg = requestEnrollmentCodeSuccessMsg;
	}

	public String getGetProofingResultsInstMsg() {
		return getProofingResultsInstMsg;
	}

	public void setGetProofingResultsInstMsg(String getProofingResultsInstMsg) {
		this.getProofingResultsInstMsg = getProofingResultsInstMsg;
	}

	public String getGetProofingResultsErrorMsg() {
		return getProofingResultsErrorMsg;
	}

	public void setGetProofingResultsErrorMsg(String getProofingResultsErrorMsg) {
		this.getProofingResultsErrorMsg = getProofingResultsErrorMsg;
	}

	public String getGetProofingResultsSuccessMsg() {
		return getProofingResultsSuccessMsg;
	}

	public void setGetProofingResultsSuccessMsg(String getProofingResultsSuccessMsg) {
		this.getProofingResultsSuccessMsg = getProofingResultsSuccessMsg;
	}

	public boolean isShowGetIppFacilityListInstMsg() {
		return showGetIppFacilityListInstMsg;
	}

	public void setShowGetIppFacilityListInstMsg(boolean showGetIppFacilityListInstMsg) {
		this.showGetIppFacilityListInstMsg = showGetIppFacilityListInstMsg;
	}

	public boolean isShowGetIppFacilityListErrorMsg() {
		return showGetIppFacilityListErrorMsg;
	}

	public void setShowGetIppFacilityListErrorMsg(boolean showGetIppFacilityListErrorMsg) {
		this.showGetIppFacilityListErrorMsg = showGetIppFacilityListErrorMsg;
	}

	public boolean isShowGetIppFacilityListSuccessMsg() {
		return showGetIppFacilityListSuccessMsg;
	}

	public void setShowGetIppFacilityListSuccessMsg(boolean showGetIppFacilityListSuccessMsg) {
		this.showGetIppFacilityListSuccessMsg = showGetIppFacilityListSuccessMsg;
	}

	public boolean isShowOptInIPPApplicantInstMsg() {
		return showOptInIPPApplicantInstMsg;
	}

	public void setShowOptInIPPApplicantInstMsg(boolean showOptInIPPApplicantInstMsg) {
		this.showOptInIPPApplicantInstMsg = showOptInIPPApplicantInstMsg;
	}

	public boolean isShowOptInIPPApplicantErrorMsg() {
		return showOptInIPPApplicantErrorMsg;
	}

	public void setShowOptInIPPApplicantErrorMsg(boolean showOptInIPPApplicantErrorMsg) {
		this.showOptInIPPApplicantErrorMsg = showOptInIPPApplicantErrorMsg;
	}

	public boolean isShowOptInIPPApplicantSuccessMsg() {
		return showOptInIPPApplicantSuccessMsg;
	}

	public void setShowOptInIPPApplicantSuccessMsg(boolean showOptInIPPApplicantSuccessMsg) {
		this.showOptInIPPApplicantSuccessMsg = showOptInIPPApplicantSuccessMsg;
	}

	public boolean isShowSendProofingResultsInstMsg() {
		return showSendProofingResultsInstMsg;
	}

	public void setShowSendProofingResultsInstMsg(boolean showSendProofingResultsInstMsg) {
		this.showSendProofingResultsInstMsg = showSendProofingResultsInstMsg;
	}

	public boolean isShowSendProofingResultsErrorMsg() {
		return showSendProofingResultsErrorMsg;
	}

	public void setShowSendProofingResultsErrorMsg(boolean showSendProofingResultsErrorMsg) {
		this.showSendProofingResultsErrorMsg = showSendProofingResultsErrorMsg;
	}

	public boolean isShowSendProofingResultsSuccessMsg() {
		return showSendProofingResultsSuccessMsg;
	}

	public void setShowSendProofingResultsSuccessMsg(boolean showSendProofingResultsSuccessMsg) {
		this.showSendProofingResultsSuccessMsg = showSendProofingResultsSuccessMsg;
	}

	public boolean isShowRequestEnrollmentCodeInstMsg() {
		return showRequestEnrollmentCodeInstMsg;
	}

	public void setShowRequestEnrollmentCodeInstMsg(boolean showRequestEnrollmentCodeInstMsg) {
		this.showRequestEnrollmentCodeInstMsg = showRequestEnrollmentCodeInstMsg;
	}

	public boolean isShowRequestEnrollmentCodeErrorMsg() {
		return showRequestEnrollmentCodeErrorMsg;
	}

	public void setShowRequestEnrollmentCodeErrorMsg(boolean showRequestEnrollmentCodeErrorMsg) {
		this.showRequestEnrollmentCodeErrorMsg = showRequestEnrollmentCodeErrorMsg;
	}

	public boolean isShowRequestEnrollmentCodeSuccessMsg() {
		return showRequestEnrollmentCodeSuccessMsg;
	}

	public void setShowRequestEnrollmentCodeSuccessMsg(boolean showRequestEnrollmentCodeSuccessMsg) {
		this.showRequestEnrollmentCodeSuccessMsg = showRequestEnrollmentCodeSuccessMsg;
	}

	public boolean isShowGetProofingResultsInstMsg() {
		return showGetProofingResultsInstMsg;
	}

	public void setShowGetProofingResultsInstMsg(boolean showGetProofingResultsInstMsg) {
		this.showGetProofingResultsInstMsg = showGetProofingResultsInstMsg;
	}

	public boolean isShowGetProofingResultsErrorMsg() {
		return showGetProofingResultsErrorMsg;
	}

	public void setShowGetProofingResultsErrorMsg(boolean showGetProofingResultsErrorMsg) {
		this.showGetProofingResultsErrorMsg = showGetProofingResultsErrorMsg;
	}

	public boolean isShowGetProofingResultsSuccessMsg() {
		return showGetProofingResultsSuccessMsg;
	}

	public void setShowGetProofingResultsSuccessMsg(boolean showGetProofingResultsSuccessMsg) {
		this.showGetProofingResultsSuccessMsg = showGetProofingResultsSuccessMsg;
	}

	public boolean isShowGetIppFacilityListRequestJsonPanel() {
		return showGetIppFacilityListRequestJsonPanel;
	}

	public void setShowGetIppFacilityListRequestJsonPanel(boolean showGetIppFacilityListRequestJsonPanel) {
		this.showGetIppFacilityListRequestJsonPanel = showGetIppFacilityListRequestJsonPanel;
	}

	public boolean isShowGetIppFacilityListResponseJsonPanel() {
		return showGetIppFacilityListResponseJsonPanel;
	}

	public void setShowGetIppFacilityListResponseJsonPanel(boolean showGetIppFacilityListResponseJsonPanel) {
		this.showGetIppFacilityListResponseJsonPanel = showGetIppFacilityListResponseJsonPanel;
	}

	public boolean isShowOptInIPPApplicantRequestJsonPanel() {
		return showOptInIPPApplicantRequestJsonPanel;
	}

	public void setShowOptInIPPApplicantRequestJsonPanel(boolean showOptInIPPApplicantRequestJsonPanel) {
		this.showOptInIPPApplicantRequestJsonPanel = showOptInIPPApplicantRequestJsonPanel;
	}

	public boolean isShowOptInIPPApplicantResponseJsonPanel() {
		return showOptInIPPApplicantResponseJsonPanel;
	}

	public void setShowOptInIPPApplicantResponseJsonPanel(boolean showOptInIPPApplicantResponseJsonPanel) {
		this.showOptInIPPApplicantResponseJsonPanel = showOptInIPPApplicantResponseJsonPanel;
	}

	public boolean isShowSendProofingResultsRequestJsonPanel() {
		return showSendProofingResultsRequestJsonPanel;
	}

	public void setShowSendProofingResultsRequestJsonPanel(boolean showSendProofingResultsRequestJsonPanel) {
		this.showSendProofingResultsRequestJsonPanel = showSendProofingResultsRequestJsonPanel;
	}

	public boolean isShowSendProofingResultsResponseJsonPanel() {
		return showSendProofingResultsResponseJsonPanel;
	}

	public void setShowSendProofingResultsResponseJsonPanel(boolean showSendProofingResultsResponseJsonPanel) {
		this.showSendProofingResultsResponseJsonPanel = showSendProofingResultsResponseJsonPanel;
	}

	public boolean isShowRequestEnrollmentCodeRequestJsonPanel() {
		return showRequestEnrollmentCodeRequestJsonPanel;
	}

	public void setShowRequestEnrollmentCodeRequestJsonPanel(boolean showRequestEnrollmentCodeRequestJsonPanel) {
		this.showRequestEnrollmentCodeRequestJsonPanel = showRequestEnrollmentCodeRequestJsonPanel;
	}

	public boolean isShowRequestEnrollmentCodeResponseJsonPanel() {
		return showRequestEnrollmentCodeResponseJsonPanel;
	}

	public void setShowRequestEnrollmentCodeResponseJsonPanel(boolean showRequestEnrollmentCodeResponseJsonPanel) {
		this.showRequestEnrollmentCodeResponseJsonPanel = showRequestEnrollmentCodeResponseJsonPanel;
	}

	public boolean isShowGetProofingResultsRequestJsonPanel() {
		return showGetProofingResultsRequestJsonPanel;
	}

	public void setShowGetProofingResultsRequestJsonPanel(boolean showGetProofingResultsRequestJsonPanel) {
		this.showGetProofingResultsRequestJsonPanel = showGetProofingResultsRequestJsonPanel;
	}

	public boolean isShowGetProofingResultsResponseJsonPanel() {
		return showGetProofingResultsResponseJsonPanel;
	}

	public boolean isShowGetIppFacilityListSubmitBtn() {
		return showGetIppFacilityListSubmitBtn;
	}

	public void setShowGetIppFacilityListSubmitBtn(boolean showGetIppFacilityListSubmitBtn) {
		this.showGetIppFacilityListSubmitBtn = showGetIppFacilityListSubmitBtn;
	}

	public void setShowGetProofingResultsResponseJsonPanel(boolean showGetProofingResultsResponseJsonPanel) {
		this.showGetProofingResultsResponseJsonPanel = showGetProofingResultsResponseJsonPanel;
	}

	public boolean isShowOptInIPPApplicantGenerateBtn() {
		return showOptInIPPApplicantGenerateBtn;
	}

	public void setShowOptInIPPApplicantGenerateBtn(boolean showOptInIPPApplicantGenerateBtn) {
		this.showOptInIPPApplicantGenerateBtn = showOptInIPPApplicantGenerateBtn;
	}

	public boolean isShowOptInIPPApplicantSubmitBtn() {
		return showOptInIPPApplicantSubmitBtn;
	}

	public void setShowOptInIPPApplicantSubmitBtn(boolean showOptInIPPApplicantSubmitBtn) {
		this.showOptInIPPApplicantSubmitBtn = showOptInIPPApplicantSubmitBtn;
	}

	public boolean isShowSendProofingResultsGenerateBtn() {
		return showSendProofingResultsGenerateBtn;
	}

	public void setShowSendProofingResultsGenerateBtn(boolean showSendProofingResultsGenerateBtn) {
		this.showSendProofingResultsGenerateBtn = showSendProofingResultsGenerateBtn;
	}

	public boolean isShowSendProofingResultsSubmitBtn() {
		return showSendProofingResultsSubmitBtn;
	}

	public void setShowSendProofingResultsSubmitBtn(boolean showSendProofingResultsSubmitBtn) {
		this.showSendProofingResultsSubmitBtn = showSendProofingResultsSubmitBtn;
	}

	public boolean isShowRequestEnrollmentCodeGenerateBtn() {
		return showRequestEnrollmentCodeGenerateBtn;
	}

	public void setShowRequestEnrollmentCodeGenerateBtn(boolean showRequestEnrollmentCodeGenerateBtn) {
		this.showRequestEnrollmentCodeGenerateBtn = showRequestEnrollmentCodeGenerateBtn;
	}

	public boolean isShowRequestEnrollmentCodeSubmitBtn() {
		return showRequestEnrollmentCodeSubmitBtn;
	}

	public void setShowRequestEnrollmentCodeSubmitBtn(boolean showRequestEnrollmentCodeSubmitBtn) {
		this.showRequestEnrollmentCodeSubmitBtn = showRequestEnrollmentCodeSubmitBtn;
	}

	public boolean isShowGetProofingResultsGenerateBtn() {
		return showGetProofingResultsGenerateBtn;
	}

	public void setShowGetProofingResultsGenerateBtn(boolean showGetProofingResultsGenerateBtn) {
		this.showGetProofingResultsGenerateBtn = showGetProofingResultsGenerateBtn;
	}

	public boolean isShowGetProofingResultsSubmitBtn() {
		return showGetProofingResultsSubmitBtn;
	}

	public void setShowGetProofingResultsSubmitBtn(boolean showGetProofingResultsSubmitBtn) {
		this.showGetProofingResultsSubmitBtn = showGetProofingResultsSubmitBtn;
	}

	public String getReOrigin() {
		return reOrigin;
	}

	public void setReOrigin(String reOrigin) {
		this.reOrigin = reOrigin;
	}

	public String getReRequestId() {
		return reRequestId;
	}

	public void setReRequestId(String reRequestId) {
		this.reRequestId = reRequestId;
	}

	public String getGrOrigin() {
		return grOrigin;
	}

	public void setGrOrigin(String grOrigin) {
		this.grOrigin = grOrigin;
	}

	public String getGrRequestId() {
		return grRequestId;
	}

	public void setGrRequestId(String grRequestId) {
		this.grRequestId = grRequestId;
	}

	public List<RefSponsor> getAllSponsorList() {
		return allSponsorList;
	}

	public void setAllSponsorList(List<RefSponsor> allSponsorList) {
		this.allSponsorList = allSponsorList;
	}

	public List<RefIppEventStatus> getAllIppEventStatusList() {
		return allIppEventStatusList;
	}

	public void setAllIppEventStatusList(List<RefIppEventStatus> allIppEventStatusList) {
		this.allIppEventStatusList = allIppEventStatusList;
	}

	public List<RefPrimaryIdType> getAllPrimaryIdTypeList() {
		return allPrimaryIdTypeList;
	}

	public void setAllPrimaryIdTypeList(List<RefPrimaryIdType> allPrimaryIdTypeList) {
		this.allPrimaryIdTypeList = allPrimaryIdTypeList;
	}

	public List<RefSecondaryIdType> getAllSecondaryIdTypeList() {
		return allSecondaryIdTypeList;
	}

	public void setAllSecondaryIdTypeList(List<RefSecondaryIdType> allSecondaryIdTypeList) {
		this.allSecondaryIdTypeList = allSecondaryIdTypeList;
	}

	public RefSponsor getSelectedRefSponsor() {
		return selectedRefSponsor;
	}

	public void setSelectedRefSponsor(RefSponsor selectedRefSponsor) {
		this.selectedRefSponsor = selectedRefSponsor;
	}

	public RefIppEventStatus getSelectedRefIppEventStatus() {
		return selectedRefIppEventStatus;
	}

	public void setSelectedRefIppEventStatus(RefIppEventStatus selectedRefIppEventStatus) {
		this.selectedRefIppEventStatus = selectedRefIppEventStatus;
	}

	public RefPrimaryIdType getSelectedRefPrimaryIdType() {
		return selectedRefPrimaryIdType;
	}

	public void setSelectedRefPrimaryIdType(RefPrimaryIdType selectedRefPrimaryIdType) {
		this.selectedRefPrimaryIdType = selectedRefPrimaryIdType;
	}

	public RefSecondaryIdType getSelectedRefSecondaryIdType() {
		return selectedRefSecondaryIdType;
	}

	public void setSelectedRefSecondaryIdType(RefSecondaryIdType selectedRefSecondaryIdType) {
		this.selectedRefSecondaryIdType = selectedRefSecondaryIdType;
	}

	public IppEvent getSelectedIppEvent() {
		return selectedIppEvent;
	}

	public void setSelectedIppEvent(IppEvent selectedIppEvent) {
		this.selectedIppEvent = selectedIppEvent;
	}

	public Person getSelectedPerson() {
		return selectedPerson;
	}

	public void setSelectedPerson(Person selectedPerson) {
		this.selectedPerson = selectedPerson;
	}

	public Long getSelectedRefSponsorId() {
		return selectedRefSponsorId;
	}

	public void setSelectedRefSponsorId(Long selectedRefSponsorId) {
		this.selectedRefSponsorId = selectedRefSponsorId;
	}

	public Long getSelectedRefIppEventStatusId() {
		return selectedRefIppEventStatusId;
	}

	public void setSelectedRefIppEventStatusId(Long selectedRefIppEventStatusId) {
		this.selectedRefIppEventStatusId = selectedRefIppEventStatusId;
	}

	public Long getSelectedRefPrimaryIdTypeId() {
		return selectedRefPrimaryIdTypeId;
	}

	public void setSelectedRefPrimaryIdTypeId(Long selectedRefPrimaryIdTypeId) {
		this.selectedRefPrimaryIdTypeId = selectedRefPrimaryIdTypeId;
	}

	public Long getSelectedRefSecondaryIdTypeId() {
		return selectedRefSecondaryIdTypeId;
	}

	public void setSelectedRefSecondaryIdTypeId(Long selectedRefSecondaryIdTypeId) {
		this.selectedRefSecondaryIdTypeId = selectedRefSecondaryIdTypeId;
	}

	public Long getSelectedIppEventId() {
		return selectedIppEventId;
	}

	public void setSelectedIppEventId(Long selectedIppEventId) {
		this.selectedIppEventId = selectedIppEventId;
	}

	public Long getSelectedPersonId() {
		return selectedPersonId;
	}

	public void setSelectedPersonId(Long selectedPersonId) {
		this.selectedPersonId = selectedPersonId;
	}

	public Map<String, Object> getGfRequestHashMap() {
		return gfRequestHashMap;
	}

	public void setGfRequestHashMap(Map<String, Object> gfRequestHashMap) {
		this.gfRequestHashMap = gfRequestHashMap;
	}

	public Map<String, Object> getOiRequestHashMap() {
		return oiRequestHashMap;
	}

	public void setOiRequestHashMap(Map<String, Object> oiRequestHashMap) {
		this.oiRequestHashMap = oiRequestHashMap;
	}

	public Map<String, Object> getSrRequestHashMap() {
		return srRequestHashMap;
	}

	public void setSrRequestHashMap(Map<String, Object> srRequestHashMap) {
		this.srRequestHashMap = srRequestHashMap;
	}

	public Map<String, Object> getReRequestHashMap() {
		return reRequestHashMap;
	}

	public void setReRequestHashMap(Map<String, Object> reRequestHashMap) {
		this.reRequestHashMap = reRequestHashMap;
	}

	public Map<String, Object> getGrRequestHashMap() {
		return grRequestHashMap;
	}

	public void setGrRequestHashMap(Map<String, Object> grRequestHashMap) {
		this.grRequestHashMap = grRequestHashMap;
	}

	public List<RefIppFailureReason> getAllIppFailureReasonList() {
		return allIppFailureReasonList;
	}

	public void setAllIppFailureReasonList(List<RefIppFailureReason> allIppFailureReasonList) {
		this.allIppFailureReasonList = allIppFailureReasonList;
	}

	public RefIppFailureReason getSelectedRefIppFailureReason() {
		return selectedRefIppFailureReason;
	}

	public void setSelectedRefIppFailureReason(RefIppFailureReason selectedRefIppFailureReason) {
		this.selectedRefIppFailureReason = selectedRefIppFailureReason;
	}

	public long getSelectedRefIppFailureReasonId() {
		return selectedRefIppFailureReasonId;
	}

	public void setSelectedRefIppFailureReasonId(long selectedRefIppFailureReasonId) {
		this.selectedRefIppFailureReasonId = selectedRefIppFailureReasonId;
	}

	public HttpServletRequest getHttpServletRequest() {
		return httpServletRequest;
	}

	public void setHttpServletRequest(HttpServletRequest httpServletRequest) {
		this.httpServletRequest = httpServletRequest;
	}

	public ServletContext getServletContext() {
		return servletContext;
	}

	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public boolean isSuspectFraud() {
		return suspectFraud;
	}

	public void setSuspectFraud(boolean suspectFraud) {
		this.suspectFraud = suspectFraud;
	}

	public AdminService getAdminService() {
		return adminService;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

}
