package com.ips.servlet.filter;

import java.io.IOException;
import java.io.Serializable;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ips.common.IVSToken;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.Utils;
import com.ips.persistence.common.IVSCookie;

public final class AdminSessionFilter implements Filter, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private static String loginPage;
    private static final String IVS_SESSION_ID = "IVSID";
    
    static{
        loginPage = Utils.getProperty("com.ipsweb.Admin");
    }
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        //TODO why is this empty
    }
    
    @Override
    public void destroy() {
        //TODO why is this empty
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse)response;
        
        HttpSession session = req.getSession(false);
        
        IVSToken ivsToken = null;
        IVSCookie ivsCookie = null;
        if(session != null){
            String sessionID = (String)session.getAttribute(IVS_SESSION_ID);
            if(sessionID != null){
                ivsCookie = new IVSCookie(sessionID);
                ivsToken = IVSToken.getInstance(ivsCookie.getSessionToken());
            }
        } 
        
        if(ivsToken != null && !ivsToken.isExpired()){
            writeCookies(session);
            chain.doFilter(request, response);
        } else{
            destroyCookies(session);
            req.getSession().invalidate();
            CustomLogger.debug(this.getClass(), "Redirecting to login page due to Session not being valid");
            resp.sendRedirect(loginPage);
        }

    }

    private void writeCookies(HttpSession session) {
        session.setAttribute(IVS_SESSION_ID, session.getAttribute(IVS_SESSION_ID));
    }

    private void destroyCookies(HttpSession session) {
        if(session != null){
            session.setAttribute(IVS_SESSION_ID, null);
            session.invalidate();
        }
    }

}
