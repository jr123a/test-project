package com.ips.common;

import java.io.File;
import java.io.FileWriter;
import java.io.Serializable;
import java.util.List;

import com.ips.common.common.CustomLogger;

public class FileUtil implements Serializable {

     /**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
     * This method is used to save a list of strings to a file separated by newlines.
     * @param pSrcFilePath
     * @param pInputStr
     * @throws Exception
     */
    public static void saveStringListToFile(String pSrcFilePath, List<String> stringList) throws Exception {
         File targetFile = new File(pSrcFilePath);
         FileWriter fw = new FileWriter(targetFile);

         try {
             for (String aString : stringList) {
                 fw.write(aString);
                 fw.write("\n");
             }
         } catch (Exception e) {        
             CustomLogger.error(FileUtil.class.getClass(),"Error occurred while saving String list to file.", e);
         } finally {
            fw.close();
         }
    }
}
