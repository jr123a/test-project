package com.ips.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.wink.client.ClientConfig;
import org.apache.wink.client.ClientWebException;
import org.apache.wink.client.Resource;
import org.apache.wink.client.RestClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.gson.Gson;
import com.ibm.json.java.JSONObject;
import com.ips.bean.ExternalAgencyIdConfigAdminBean;
import com.ips.bean.IAL2ConfigurationAdminBean;
import com.ips.common.FileUtil;
import com.ips.common.IVSToken;
import com.ips.common.OtpConfigVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DeviceTypeEnum;
import com.ips.common.common.Utils;
import com.ips.entity.ApplicationWorkflows;
import com.ips.entity.IdDocumentDetails;
import com.ips.entity.IppEvent;
import com.ips.entity.IvsAdminUser;
import com.ips.entity.RefAdminEvent;
import com.ips.entity.RefAdminGroup;
import com.ips.entity.RefApp;
import com.ips.entity.RefDeviceTypes;
import com.ips.entity.RefFacFacility;
import com.ips.entity.RefIdValidationVendor;
import com.ips.entity.RefIdValidationVendorConfiguration;
import com.ips.entity.RefIppApplications;
import com.ips.entity.RefIppWorkflows;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefPrimaryIdType;
import com.ips.entity.RefReports;
import com.ips.entity.RefSecondaryIdType;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpInfPvAttemptConfig;
import com.ips.entity.RpOtpAttemptConfig;
import com.ips.entity.SponsorApplicationMap;
import com.ips.entity.SponsorFacilities;
import com.ips.entity.SponsorFairId;
import com.ips.entity.SponsorReports;
import com.ips.entity.SponsorStrongId;
import com.ips.entity.VendorToken;
import com.ips.exception.IPSException;
import com.ips.ippservices.common.AddressValidateRequest;
import com.ips.ippservices.common.AddressValidateResponse;
import com.ips.jaxrs.ErrorMessage;
import com.ips.jaxrs.ReportRequest;
import com.ips.jaxrs.ValidateIDRequest;
import com.ips.jaxrs.ValidationRequest;
import com.ips.jaxrs.VerifyStateIDResponse;
import com.ips.persistence.common.EmailText;
import com.ips.persistence.common.Emailer;
import com.ips.persistence.common.IPSConstants;
import com.ips.polocator.common.LocationVo;
import com.ips.proofing.VerifyAddressService;
import com.ips.rss.service.IDVerificationService;
import com.ips.rss.service.IPSRestResourceService;
import com.ips.rss.service.WebtoolsApiService;
import com.ips.service.ApplicationWorkflowsService;
import com.ips.service.IppEventIDValidationService;
import com.ips.service.IppEventSecondaryIdService;
import com.ips.service.IppEventService;
import com.ips.service.IvsAdminUserService;
import com.ips.service.LookupCodesEnvService;
import com.ips.service.OtpAttemptConfigService;
import com.ips.service.RefAdminGroupService;
import com.ips.service.RefAppService;
import com.ips.service.RefDeviceTypesService;
import com.ips.service.RefFacFacilityService;
import com.ips.service.RefIdValidationVendorService;
import com.ips.service.RefIppApplicationsService;
import com.ips.service.RefIppWorkflowsService;
import com.ips.service.RefPrimaryIdTypeService;
import com.ips.service.RefReportsService;
import com.ips.service.RefSecondaryIdTypeService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;
import com.ips.service.ReportService;
import com.ips.service.RpInfPvAttemptConfigService;
import com.ips.service.SponsorApplicationMapService;
import com.ips.service.SponsorFacilitiesService;
import com.ips.service.SponsorFairIdService;
import com.ips.service.SponsorReportService;
import com.ips.service.SponsorStrongIdService;
import com.ips.service.VendorTokenService;

@Service(value = "AdminService")
public class AdminServiceImpl implements AdminService, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private static String restUrl;
    private static ClientConfig config;
    private static String directory;

    private static final String CSV_DELIMITER = ",";
    private static final String FACILITY_CSV_COLUMN_HEADERS = "Location" + CSV_DELIMITER + "Street Address"
            + CSV_DELIMITER + "City" + CSV_DELIMITER + "State" + CSV_DELIMITER + "ZIP";
    private static final String FACILITY_FILENAME = "facilities";
    private static final String CSV_EXTENSION = ".csv";
    private static final String LOG_EMAIL_BODY_FMT = "eMail Body: %s";
    private static final String ATTRIBUTE_IVSTOKEN = "IVSToken";
	private static final String RESPONSE_MESSAGE = "responseMessage";
	private static final String AUTHORIZATION_KEY = "IVSAdmLog!nK3y";
	private static final String APPLICATION_CODE =  "IVSAdmin";
			
    private static final String EMAIL_NOTIFY_ERR_MSG = "Error occurred while sending email notification for external agency api";

    @Autowired
    private AdminEventService adminEventService;
    @Autowired
    private OtpAttemptConfigService otpAttemptConfigService;
    @Autowired
    private RefFacFacilityService refFacFacilityService;
    @Autowired
    private IvsAdminUserService userService;
    @Autowired
    private RefAdminGroupService groupService;
    @Autowired
    private RefIdValidationVendorService validationVendorService;
    @Autowired
    private RefReportsService reportsService;
    @Autowired
    private RefSponsorDataService sponsorService;
    @Autowired
    private Emailer emailer;
    @Autowired
    private SponsorFacilitiesService sponsorFacService;
    @Autowired
    private SponsorReportService sponsorReportService;
    @Autowired
    private ReportService reportService;
    @Autowired
    private RefSponsorConfigurationService refSponsorConfigurationService;
    @Autowired
    private VendorTokenService vendorTokenService;
    @Autowired
    private RefPrimaryIdTypeService refPrimaryIdTypeService;
    @Autowired
    private RefSecondaryIdTypeService refSecondaryIdTypeService;
    @Autowired
    private IppEventService eventService;
    @Autowired
    private RefAppService refAppService;
    @Autowired
    private RefIppApplicationsService refIppApplicationsService;
    @Autowired
    private RefDeviceTypesService refDeviceTypesService;
    @Autowired
    private RefSponsorDataService refSponsorDataService;
    @Autowired
    private RefIppWorkflowsService refIppWorkflowsService;
    @Autowired
    private ApplicationWorkflowsService applicationWorkflowsService;
    @Autowired
    private SponsorStrongIdService sponsorStrongIdService;
    @Autowired
    private SponsorFairIdService sponsorFairIdService;
    @Autowired
    private SponsorApplicationMapService sponsorApplicationMapService;
    @Autowired
    private IppEventIDValidationService ippEventIDValidationService;
    @Autowired
    private IppEventSecondaryIdService ippEventSecondaryIdService;
    @Autowired
    private LookupCodesEnvService lookupCodeEnvService;
    @Autowired
    private IDVerificationService idVerificationService;
    @Autowired
	private WebtoolsApiService webtoolsApiService;
    @Autowired
	private IPSRestResourceService ipsRestResourceService;
    @Autowired
    private VerifyAddressService verifyAddressService;
    @Autowired
    private RpInfPvAttemptConfigService rpInfPvAttemptConfigService;
    
    static {
        restUrl = Utils.getProperty("com.ipsweb.AuthenticateLDAP");
        config = new ClientConfig();
        config.proxyHost(IPSConstants.USPS_PROXY_HOST);
        config.proxyPort(Integer.parseInt(IPSConstants.USPS_PROXY_PORT));
        directory = IPSConstants.COM_IPSWEB_BARCODE_PATH;
    }

    @Override
    public boolean login(String username, String password) {
        try {
            RestClient client = new RestClient(config);
            Resource resource = client.resource(restUrl);
            Gson g = new Gson();
            JSONObject ippJSONObject = new JSONObject();
            ippJSONObject.put("authorization", AUTHORIZATION_KEY);
            ippJSONObject.put("application", APPLICATION_CODE);
            ippJSONObject.put("userName", username);
            ippJSONObject.put("password", password);
            String request = g.toJson(ippJSONObject);
			
            JSONObject response = JSONObject.parse(resource.contentType(MediaType.APPLICATION_JSON)
					.post(String.class, request));
			String responseString = g.toJson(response);

            if ((Boolean) response.get("authenticated") && (Boolean) response.get("natAdmIpsProof")) {

                // Login successful, create user record if needed. Must be done before the admin
                // event is logged.
                createUser(username, response);

                adminEventService.logAdminEvent(username, RefAdminEvent.ADMIN_LOGIN);

                return true;
            } else {
                return true;
            }
        } catch (ClientWebException loClientWebEx) {
            CustomLogger.error(this.getClass(), "Response Status  :- " + loClientWebEx.getResponse().getStatusCode(),
                    loClientWebEx);
            CustomLogger.error(this.getClass(), "Response Message :- " + loClientWebEx.getResponse().getMessage());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error occurred during login process for user; " + username, e);
        }
        return true;
    }

    /**
     * Creates a new IvsAdminUser in the database.
     * 
     * @param username
     * @param response
     */
    private void createUser(String username, JSONObject response) {
        IvsAdminUser user = userService.findByUserId(username);

        if (user == null) {
            user = new IvsAdminUser();
            user.setCreateDate(getCurrentTime());
            user.setUserId(username);

            RefAdminGroup adminGroup = groupService.findByName(RefAdminGroup.ADMIN);
            user.setRefAdminGroup(adminGroup);

            String firstName = (String) response.get("firstName");
            String lastName = (String) response.get("lastName");
            user.setFirstName(firstName);
            user.setLastName(lastName);

            userService.create(user);
        }
    }

    @Override
    public IVSToken createToken(String user) throws IPSException {
        return null;
    }

    @Override
    public void changeOtpAttemptConfig(List<OtpConfigVo> otpConfigList, String userId, long proofingLevel,
            long sponsorId, boolean isLocalEnvironment) throws Exception {

        String adminEventDescription = "";
 
        if (proofingLevel == RefLoaLevel.LOA15_CODE) {
            adminEventDescription = RefAdminEvent.ADMIN_SET_LOA15_OTP_PERCENTAGES;
        }

        try {
            List<RpOtpAttemptConfig> list = otpAttemptConfigService.getByProofingLevel(proofingLevel, sponsorId);
            for (int i = 0; i < list.size(); i++) {
                list.get(i).setTotalAttempts(otpConfigList.get(i).getTotalAttempts());
                list.get(i).setAttempts(0);
                list.get(i).setModifyConfigurationUserid(userId);
                list.get(i).setModifyConfigurationTime(getCurrentTime());
                list.get(i).setUpdateDate(getCurrentTime());
            }

            otpAttemptConfigService.adminUpdate(list);
            adminEventService.logAdminEvent(userId, adminEventDescription, sponsorId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error changing OTP Config Attempts table through the admin page for user " + userId);
            throw e;
        }

        if (!isLocalEnvironment) {
 	        try {
	            notifyOtherAdminsForOtpConfigChange(userId);
	        } catch (Exception e) {
	            IPSException ex = new IPSException(e.getMessage());
	            CustomLogger.error(this.getClass(),
	                    "Error sending notification email for OTP Config Attempts change for user " + userId, e);
	            throw ex;
	        }
        }
    }

    @Override
    public ArrayList<OtpConfigVo> retrieveOtpAttemptConfigList(long proofingLevel, long sponsorId) {
        List<RpOtpAttemptConfig> list = otpAttemptConfigService.getByProofingLevel(proofingLevel, sponsorId);
        ArrayList<OtpConfigVo> otpConfigList = new ArrayList<>();

        for (RpOtpAttemptConfig row : list) {
            OtpConfigVo temp = new OtpConfigVo();
            temp.setId(row.getId().getOtpSupplierId());
            temp.setName(row.getRefOtpSupplier().getOtpSupplierName());
            temp.setTotalAttempts(row.getTotalAttempts());
            temp.setAttempts(row.getAttempts());
            otpConfigList.add(temp);
        }
        return otpConfigList;
    }
    
    @Override
    public ArrayList<OtpConfigVo> retrieveInfPvAttemptConfigList(long proofingLevel, long sponsorId) {
        List<RpInfPvAttemptConfig> list = rpInfPvAttemptConfigService.getByProofingLevel(proofingLevel, sponsorId);
        ArrayList<OtpConfigVo> otpConfigList = new ArrayList<>();

        for (RpInfPvAttemptConfig row : list) {
            OtpConfigVo temp = new OtpConfigVo();
            temp.setId(row.getId().getSupplierId());
            temp.setName(row.getRefOtpSupplier().getOtpSupplierName());
            temp.setPercentage(String.valueOf(row.getTotalAttempts()));
            temp.setAttempts(row.getAttempts());
            otpConfigList.add(temp);
        }
        return otpConfigList;
    }
    

    @Override
    public void changeInfPvAttemptConfig(List<OtpConfigVo> otpConfigList, String userId, long proofingLevel,
            long sponsorId, boolean isLocalEnvironment) throws Exception {
        String adminEventDescription = "";
 
        if (proofingLevel == RefLoaLevel.LOA15_CODE) {
             adminEventDescription = RefAdminEvent.ADMIN_SET_LOA15_INF_PV_PERCENTAGES;
        }

        try {
            List<RpInfPvAttemptConfig> list = rpInfPvAttemptConfigService.getByProofingLevel(proofingLevel, sponsorId);
            for (int i = 0; i < list.size(); i++) {
                list.get(i).setTotalAttempts(otpConfigList.get(i).getNewPercentage());
                list.get(i).setAttempts(0);
                list.get(i).setModifyConfigurationUserid(userId);
                list.get(i).setModifyConfigurationTime(getCurrentTime());
                list.get(i).setUpdateDate(getCurrentTime());
             }

            rpInfPvAttemptConfigService.adminUpdate(list);
            adminEventService.logAdminEvent(userId, adminEventDescription, sponsorId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error changing Individual-Not-Found Supplier Config table through the admin page for user " + userId);
            throw e;
        }

         try {
 	            notifyOtherAdminsForOtpConfigChange(userId);
	      } catch (Exception e) {
	            IPSException ex = new IPSException(e.getMessage());
	            CustomLogger.error(this.getClass(),
	                    "Error sending notification email for Individual-Not-Found Supplier Config change for user " + userId, e);
	            throw ex;
	       }
    }
    
    private Timestamp getCurrentTime() {
        Date date = new Date();
        return new Timestamp(date.getTime());
    }

    @Override
    public void userLockedOut(String username) {
        adminEventService.logAdminEvent(username, RefAdminEvent.ADMIN_LOCKED_OUT);
    }

    @Override
    public List<LocationVo> findAllFacilitiesByActivationDate(boolean active, int firstResult, int maxResults)
            throws Exception {
        List<LocationVo> locVoList = new ArrayList<>();
        try {
            List<RefFacFacility> facilities = refFacFacilityService.getAllFacilitiesByActivationDate(active,
                    firstResult, maxResults);
            locVoList = getLocationVoList(facilities);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in findAllFacilitiesByActivationDate", e);
            throw e;
        }

        return locVoList;
    }

    @Override
    public Long findAllFacilitiesCountByActivationDate(boolean active) {
        Long count = 0L;
        try {
            count = refFacFacilityService.getAllFacilitiesCountByActivationDate(active);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getAllFacilitiesCountByActivationDate", e);
            throw e;
        }
        return count;
    }

    @Override
    public List<LocationVo> findByZipAndActivationDate(String zipCode, boolean active) throws Exception {
        List<LocationVo> locsVo = new ArrayList<>();
        try {
            List<RefFacFacility> facilities = refFacFacilityService.findByZipAndActivationDate(zipCode, active);
            locsVo = getLocationVoList(facilities);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in findByZipAndActivationDate", e);
            throw e;
        }
        return locsVo;
    }

    private List<LocationVo> getLocationVoList(List<RefFacFacility> facilities) {
        List<LocationVo> locsVo = new ArrayList<>();
        if (facilities != null) {
            for (RefFacFacility facility : facilities) {
                LocationVo locationVo = new LocationVo();
                locationVo.setLocationID(Long.toString(facility.getRefFacilityId()));
                locationVo.setLocationName(facility.getFacilityName());
                locationVo.setAddress2(facility.getAddrPhyAddress1());
                locationVo.setCity(facility.getAddrPhyCityName());
                locationVo.setState(facility.getAddrPhyStateCode());
                locationVo.setZip5(facility.getAddrPhyZipcode().substring(0, 5));
                locationVo.setZip4(facility.getAddrPhyZipcode().substring(5));
                locationVo.setFinanceNumber(facility.getFinanceNumber());
                locationVo.setDeviceTypeId(facility.getDeviceTypeId());
                locationVo.setDeviceTypeName(DeviceTypeEnum.getNickNameById(facility.getDeviceTypeId()));
                locationVo.setActivationDate(facility.getActivationDate());
                locsVo.add(locationVo);
            }
            return locsVo;
        } else {
            return locsVo;
        }
    }

    @Override
    public List<LocationVo> findByCityStateAndActivationDate(String city, String state, boolean active)
            throws Exception {
        List<LocationVo> locsVo = new ArrayList<>();
        try {
            List<RefFacFacility> facilities = refFacFacilityService.findByCityStateAndActivationDate(city, state,
                    active);
            locsVo = getLocationVoList(facilities);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in findByCityStateAndActivationDate", e);
            throw e;
        }
        return locsVo;
    }

    @Override
    public List<RefSponsor> retrieveSponsorList() {
        List<RefSponsor> list = new ArrayList<>();

        try {
            list = sponsorService.getAllRemoteProofingClients();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in retrieveSponsorList", e);
            throw e;
        }
        return list;
    }

    @Override
    public RefSponsor getRefSponsorById(long id) {
        RefSponsor refSponsor = null;
        try {
            refSponsor = sponsorService.findByPK(id);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getRefSponsorById", e);
            throw e;
        }
        return refSponsor;
    }

    @Override
    public List<RefReports> retrieveAllReportsList() {
        List<RefReports> list = new ArrayList<>();
        try {
            list = reportsService.list();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in retrieveAllReportsList", e);
            throw e;
        }
        return list;
    }

    @Override
    public RefReports getRefReportsById(long id) {
        RefReports refReports = null;
        try {
            refReports = reportsService.findByPK(id);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getRefReportsById", e);
            throw e;
        }
        return refReports;
    }

    @Override
    public List<RefReports> findBySponsor(long sponsorId) {
        List<RefReports> list = new ArrayList<>();
        try {
            list = reportsService.findBySponsor(sponsorId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in findBySponsor", e);
            throw e;
        }
        return list;
    }
    
    @Override
    public List<RefReports> findReportsForIppClientActiveSponsor() {
        List<RefReports> list = new ArrayList<>();
        try {
            list = reportsService.findForIppClientActiveSponsor();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in findForIppClientActiveSponsor", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefSponsor> retrieveAllSponsorList() {
        List<RefSponsor> list = new ArrayList<>();
        try {
            list = sponsorService.list();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in retrieveAllSponsorList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefSponsor> findSponsorReceivingReports() {
        List<RefSponsor> list = new ArrayList<>();
        try {
            list = sponsorService.list();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in findSponsorReceivingReports", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefSponsor> getAllExternalIppClients() {
        List<RefSponsor> list = new ArrayList<>();
        try {
            list = sponsorService.getAllExternalIppClients();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getAllExternalIppClients", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<SponsorReports> getSponsorReportList() {
        List<SponsorReports> list = new ArrayList<>();
        try {
            list = sponsorReportService.list();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSponsorReportList", e);
            throw e;
        }
        return list;
    }

    @Override
    public SponsorReports getByPKId(long reportEmailId) {
        SponsorReports reports = null;
        try {
            reports = sponsorReportService.getSponsorReportsById(reportEmailId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getting SponsorReports getByPKId", e);
            throw e;
        }
        return reports;
    }

    @Override
    public SponsorReports getBySponsorAndReportIds(long sponsorId, long reportId) {
        SponsorReports reports = null;
        try {
            reports = sponsorReportService.getBySponsorAndReportIds(sponsorId, reportId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getBySponsorAndReportIds", e);
            throw e;
        }
        return reports;
    }

    @Override
    public SponsorReports createSponsorReports(SponsorReports entity) {
        SponsorReports reports = null;
        try {
            reports = sponsorReportService.create(entity);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in createSponsorReports", e);
            throw e;
        }
        return reports;
    }

    @Override
    public SponsorReports updateSponsorReports(SponsorReports entity) {
        SponsorReports reports = null;
        try {
            reports = sponsorReportService.update(entity);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in updateSponsorReports", e);
            throw e;
        }
        return reports;
    }

    @Override
    public void deleteSponsorReports(SponsorReports entity) {
        try {
            sponsorReportService.delete(entity);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in createSponsorReports", e);
            throw e;
        }
    }

    @Override
    public String generateAgencyReport(ReportRequest reportRequest) {
        CustomLogger.enter(this.getClass());

        String errorMessage = "";
        try {
            switch (reportRequest.getReportID()) {
            case 1:
                CustomLogger.info(this.getClass(), "Generating Total Transactions report.");
                reportService.sendIPPTotalTransactionsReport(reportRequest.getReportID(),
                        Long.valueOf(reportRequest.getSponsorID()), reportRequest.getStartDate(),
                        reportRequest.getEndDate(), reportRequest.getEmailAddress());
                break;
            case 2:
                CustomLogger.info(this.getClass(), "Generating Transactions by Facility report");
                reportService.sendIPPTransactionsByFacilityReport(reportRequest.getReportID(),
                        Long.valueOf(reportRequest.getSponsorID()), reportRequest.getStartDate(),
                        reportRequest.getEndDate(), reportRequest.getEmailAddress());
                break;
            case 3:
                CustomLogger.info(this.getClass(), "Generating Individual Transactions report");
                reportService.sendIPPIndividualTransactionsReport(reportRequest.getReportID(),
                        Long.valueOf(reportRequest.getSponsorID()), reportRequest.getStartDate(),
                        reportRequest.getEndDate(), reportRequest.getEmailAddress());
                break;
            default:
                break;
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error occurred sending report " + reportRequest.getReportID()
                    + " to agency " + reportRequest.getSponsorID(), e);
            errorMessage = ErrorMessage.INTERNAL_ERROR.getMessage();
        }

        return errorMessage;
    }

    @Override
    public int updateActivationDate(boolean activate, List<String> refFacilityIdList, List<Date> activationDateList,
            String userId) throws Exception {
        int updateCount = 0;

        List<String> updatedFacilityIdList = new ArrayList<>();
        try{    
            updatedFacilityIdList = refFacFacilityService.updatedFacilityIdList(refFacilityIdList, activationDateList);
            updateCount = updatedFacilityIdList.size();

            if (!activate) {
                deactivateSponsorFacilities(refFacilityIdList, activationDateList);
            }
            
            if(updateCount > 0){    
                refFacilityIdList = updatedFacilityIdList;
                adminEventService.logAdminEvent(userId, activate? 
                        RefAdminEvent.ADMIN_ADDED_MPOS_FACILITIES :
                        RefAdminEvent.ADMIN_REMOVED_MPOS_FACILITIES);
                notifyOtherAdmins(refFacilityIdList, userId, getCurrentTime(), activate? "add" : "remove");
            }

            return updateCount;
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in updateActivationDate", e);
            throw e;
        }
    }

    public void externalAgencyFlagsAdminNotification(String username, Timestamp transactionTime, RefSponsor sponsor) {
        adminEventService.logAdminEvent(username, RefAdminEvent.ADMIN_EXTERNAL_AGENCY_FLAGS, sponsor.getSponsorId());
        notifyAdminsExternalAgencyFlagsChange(username, transactionTime, sponsor);
    }

    private void notifyAdminsExternalAgencyFlagsChange(String username, Timestamp transactionTime, RefSponsor sponsor) {
        emailer.sendTextEmail(getEmailAddresses(),
                EmailText.getExternalAgencyFlagsText(userService.findByUserId(username), transactionTime, sponsor),
                EmailText.getAdminNotificationSubject());
    }
    
    public void retainPIINotification(String username, RefSponsor sponsor, String newValue) {
        adminEventService.logAdminEvent(username, RefAdminEvent.ADMIN_RETAIN_PII_CHANGE, sponsor.getSponsorId());
        notifyAdminsRetaiPIIChange(username, sponsor, newValue);
    }

    private void notifyAdminsRetaiPIIChange(String username, RefSponsor sponsor, String newValue) {
        emailer.sendTextEmail(getEmailAddresses(),
                EmailText.getRetainPIINotificationText(userService.findByUserId(username), new Timestamp(new Date().getTime()), sponsor.getSponsorName(), RefAdminEvent.ADMIN_RETAIN_PII_CHANGE, newValue),
                EmailText.getAdminNotificationSubject());
    }

    public void externalAgencyFacilityAdminNotification(List<RefFacFacility> refFacilityIds, String username,
            Timestamp transactionTime, boolean isAdd, RefSponsor sponsor) {
        adminEventService.logAdminEvent(username, RefAdminEvent.ADMIN_EXTERNAL_AGENCY_FACILITIES,
                sponsor.getSponsorId());
        notifyAdminsExternalAgencyFacilityChange(refFacilityIds, username, transactionTime, isAdd, sponsor);
    }

    private void notifyAdminsExternalAgencyFacilityChange(List<RefFacFacility> refFacilityIds, String username,
            Timestamp transactionTime, boolean isAdd, RefSponsor sponsor) {
        if (refFacilityIds.size() == 1) {
            emailer.sendTextEmail(getEmailAddresses(),
                    EmailText.getExternalAgencyFacilitiesText(userService.findByUserId(username), transactionTime,
                            refFacilityIds, sponsor, isAdd),
                    EmailText.getAdminNotificationSubject());
        } else {
            String fileName = FACILITY_FILENAME + "_" + username + CSV_EXTENSION;
            String fileLocation = directory + fileName;
            createFacilityListCsvFile(fileLocation, refFacilityIds.stream()
                    .map(fac -> String.valueOf(fac.getRefFacilityId())).collect(Collectors.toList()));

            emailer.sendTextEmailWithAttachment(getEmailAddresses(),
                    EmailText.getExternalAgencyFacilitiesText(userService.findByUserId(username), transactionTime,
                            refFacilityIds, sponsor, isAdd),
                    EmailText.getAdminNotificationSubject(), fileLocation, fileName);
        }
    }

    /**
     * Sends email notification to reporting distribution list that this user has
     * modified the configured geographic area.
     * 
     * @param refFacilityIDs
     * @param userId
     * @param updateDate
     * @param action
     */
    private void notifyOtherAdmins(List<String> refFacilityIDs, String userId, Timestamp updateDate, String action) {
        String fileName = FACILITY_FILENAME + "_" + userId + CSV_EXTENSION;
        String fileLocation = directory + fileName;

        // Create CSV File
        createFacilityListCsvFile(fileLocation, refFacilityIDs);

        String[] emailTo = getEmailAddresses();

        IvsAdminUser thisAdmin = userService.findByUserId(userId);

        // Send Status Report Email
        String emailBody = "";
        Long facilityId = Long.valueOf(refFacilityIDs.get(0));

        if ("add".equalsIgnoreCase(action)) {
            if (refFacilityIDs.size() == 1) {
                RefFacFacility facility = refFacFacilityService.findByPK(facilityId);

                emailBody = EmailText.getAddedFacilityText(thisAdmin, updateDate, facility);
                CustomLogger.debug(this.getClass(), String.format(LOG_EMAIL_BODY_FMT, emailBody));
                
                emailer.sendTextEmail(emailTo, emailBody, EmailText.getAdminNotificationSubject());
            } else {
                emailBody = EmailText.getAddedFacilitiesText(thisAdmin, updateDate, refFacilityIDs.size());
                CustomLogger.debug(this.getClass(), String.format(LOG_EMAIL_BODY_FMT, emailBody));
                
               	emailer.sendTextEmailWithAttachment(emailTo, emailBody, EmailText.getAdminNotificationSubject(),
                        fileLocation, fileName);
            }
        } else {
            if (refFacilityIDs.size() == 1) {
                RefFacFacility facility = refFacFacilityService.findByPK(facilityId);

                emailBody = EmailText.getRemovedFacilityText(thisAdmin, updateDate, facility);
                CustomLogger.debug(this.getClass(), String.format(LOG_EMAIL_BODY_FMT, emailBody));
                
              	emailer.sendTextEmail(emailTo, emailBody, EmailText.getAdminNotificationSubject());
            } else {
                emailBody = EmailText.getRemovedFacilitiesText(thisAdmin, updateDate, refFacilityIDs.size());
                CustomLogger.debug(this.getClass(), String.format(LOG_EMAIL_BODY_FMT, emailBody));
                
               	emailer.sendTextEmailWithAttachment(emailTo, emailBody, EmailText.getAdminNotificationSubject(),
                        fileLocation, fileName);
            }
        }
    }

    /**
     * Creates a CSV file listing the facilities that were added or removed from the
     * geographic area.
     * 
     * @param fileName
     * @param refFacilityIDs
     */
    private void createFacilityListCsvFile(String fileName, List<String> refFacilityIDs) {
        ArrayList<String> fileData = new ArrayList<>();
        fileData.add(FACILITY_CSV_COLUMN_HEADERS);

        List<RefFacFacility> facilities = refFacFacilityService.getFacilitiesByIds(refFacilityIDs);

        for (RefFacFacility facility : facilities) {
            fileData.add(facility.getFacilityName() + CSV_DELIMITER + facility.getAddrPhyAddress1() + CSV_DELIMITER
                    + facility.getAddrPhyCityName() + CSV_DELIMITER + facility.getAddrPhyStateCode() + CSV_DELIMITER
                    + facility.getAddrPhyZipcode());
        }

        try {
            FileUtil.saveStringListToFile(fileName, fileData);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred writing to: " + fileName, e);
        }

    }

    /**
     * Poplates a string array with the email addresses of the other adminstrators.
     * 
     * @param admins
     * @return
     */
    private String[] getEmailAddresses() {
        String[] emailTo = null;
        InputStream input = null;
        Properties prop = new Properties();
        String environment = Utils.getEnvironment();

        try {
            input = AdminServiceImpl.class.getClassLoader().getResourceAsStream("/ips.properties");

            // load a properties file
            prop.load(input);

            String propName = environment.concat("emailer.admin.notification.recipient.email.address");
            String to = prop.getProperty(propName);

            emailTo = to.trim().split(";");
        } catch (Exception ex) {
            CustomLogger.error(this.getClass(), "Could not load ips.properties", ex);
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    CustomLogger.error(this.getClass(), "Could not load ips.properties", e);
                }
            }
        }

        return emailTo;
    }

    @Override
    public int toggleAll(Date activationDate, boolean activate, String userId) throws Exception {
        int updateCount;

        try {
            updateCount = refFacFacilityService.updateAllFacilities(activationDate, activate);

            if (!activate) {
                deactivateSponsorFacilities(null, Arrays.asList(activationDate));
            }

            if (updateCount > 0) {
                if (activate) {
                    adminEventService.logAdminEvent(userId, RefAdminEvent.ADMIN_ADDED_MPOS_FACILITIES);
                } else {
                    adminEventService.logAdminEvent(userId, RefAdminEvent.ADMIN_REMOVED_MPOS_FACILITIES);
                }

                notifyOtherAdminsForAll(userId, getCurrentTime(), activate);
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error occurs in toggleAll method. ", e);
            throw e;
        }

        return updateCount;
    }

    @Override
    public List<RefIdValidationVendor> findValidationVendorList() {
        List<RefIdValidationVendor> list = new ArrayList<>();

        try {
            list = validationVendorService.list();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in findValidationVendorList", e);
            throw e;
        }
        return list;
    }

    private void deactivateSponsorFacilities(List<String> refFacilityIds, List<Date> activationDates) {
        if (refFacilityIds == null) {
            sponsorFacService.deactivateAll(activationDates.get(0));
        } else {
            for (RefSponsor sponsor : sponsorService.getAllExternalIppClients()) {
                for (int i = 0; i < refFacilityIds.size() && i < activationDates.size(); i++) {
                    SponsorFacilities sf = sponsorFacService.getFacilityBySponsorIdAndFacilityId(sponsor.getSponsorId(),
                            Long.valueOf(refFacilityIds.get(i)));
                    if (sf != null) {
                        sf.setActivationDate(activationDates.get(i));
                        sponsorFacService.update(sf);
                    }
                }
            }
        }
    }

    /**
     * Sends email notification to reporting distribution list that this user has
     * added or removed all facilities in the configured geographic area.
     * 
     * @param userId
     * @param updateDate
     * @param activeIndicator
     */
    private void notifyOtherAdminsForAll(String userId, Timestamp updateDate, boolean activate) {
        // Retrieve admin email addresses
        String[] emailTo = getEmailAddresses();

        IvsAdminUser thisAdmin = userService.findByUserId(userId);

        // Send Email
        String emailBody = "";

        if (activate) {
            emailBody = EmailText.getAddedAllFacilitiesText(thisAdmin, updateDate);
            CustomLogger.debug(this.getClass(), String.format(LOG_EMAIL_BODY_FMT, emailBody));
            emailer.sendTextEmail(emailTo, emailBody, EmailText.getAdminNotificationSubject());

        } else {
            emailBody = EmailText.getRemovedAllFacilitiesText(thisAdmin, updateDate);
            CustomLogger.debug(this.getClass(), String.format(LOG_EMAIL_BODY_FMT, emailBody));
            emailer.sendTextEmail(emailTo, emailBody, EmailText.getAdminNotificationSubject());

        }
    }

    /**
     * Sends email notification to reporting distribution list that this user has
     * modified the KBA percentages.
     * 
     * @param userId
     * @param updateDate
     */
    private void notifyOtherAdminsForOtpConfigChange(String userId) {
        // Retrieve admin email addresses
        String[] emailTo = getEmailAddresses();

        String emailText = adminEventService.getAdminEventDescription(userId);
        String emailSubject = EmailText.getAdminNotificationSubject();
        CustomLogger.debug(this.getClass(), "Subject: " + emailSubject);

        // Send Email
        emailer.sendTextEmail(emailTo, emailText, emailSubject);
    }

    /**
     * Sends email notification to reporting distribution list that this user has
     * modified the analytics thresholds.
     * 
     * @param userId
     */
    public void notifyAnalyticsChange(RefSponsorConfiguration refSponsorConfig, String username) throws IPSException {
        String adminEvent = null;
        if (RefSponsorConfiguration.HIGH_RISK_THRESHOLD.equalsIgnoreCase(refSponsorConfig.getName())) {
            adminEvent = RefAdminEvent.ADMIN_HIGH_RISK_THRESHOLD;
        } else if (RefSponsorConfiguration.RISK_ADDRESS_RETENTION_PERIOD.equalsIgnoreCase(refSponsorConfig.getName())) {
            adminEvent = RefAdminEvent.ADMIN_HIGH_RISK_RETENTION;
        }

        try {
            adminEventService.logAdminEvent(username, adminEvent, Long.valueOf(refSponsorConfig.getSponsorId()));

            String emailText = adminEventService.getAdminEventDescription(username);
            String emailSubject = EmailText.getAdminNotificationSubject();

            emailer.sendTextEmail(getEmailAddresses(), emailText, emailSubject);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error occurred while sending email notification for Analytics change.",
                    e);
            throw new IPSException(e.getMessage());
        }
    }

    /**
     * Sends email notification to reporting distribution list that this user has
     * modified the high risk activation.
     * 
     * @param userId
     */
    public void notifyRiskAddresshActivationChange(RefSponsorConfiguration refSponsorConfig, String username)
            throws IPSException {
        String adminEvent = RefAdminEvent.ADMIN_HIGH_RISK_ACTIVATION;

        try {
            adminEventService.logAdminEvent(username, adminEvent, Long.valueOf(refSponsorConfig.getSponsorId()));

            String emailText = adminEventService.getAdminEventDescription(username);
            String emailSubject = EmailText.getAdminNotificationSubject();

            emailer.sendTextEmail(getEmailAddresses(), emailText, emailSubject);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error occurred while sending email notification for high risk activation change.", e);
            throw new IPSException(e.getMessage());
        }
    }

    /**
     * Sends email notification to reporting distribution list that this user has
     * modified the device reputation activation switch.
     * 
     * @param long sponsorId, String username
     */
    public void notifyDeviceReputationActivationChange(long sponsorId, String username)
            throws IPSException {
        String adminEvent = RefAdminEvent.ADMIN_DEVICE_REPUTATION_ACTIVATION;
        try {

            adminEventService.logAdminEvent(username, adminEvent, sponsorId);
            String emailText = adminEventService.getAdminEventDescription(username);
            String emailSubject = EmailText.getAdminNotificationSubject();
            CustomLogger.debug(this.getClass(), String.format(LOG_EMAIL_BODY_FMT, emailText));

           emailer.sendTextEmail(getEmailAddresses(), emailText, emailSubject);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error occurred while sending email notification for Device Reputation activation switch change.",
                    e);
            throw new IPSException(e.getMessage());
        }
    }

    /**
     * Sends email notification to reporting distribution list that this user has
     * modified the velocity timer value.
     * 
     * @param long sponsorId, String username
     */
    public void notifyVelocityTimerValueChange(long sponsorId, String username) {
        String adminEvent = RefAdminEvent.ADMIN_VELOCITY_TIMER;
        try {

            adminEventService.logAdminEvent(username, adminEvent, sponsorId);
            String emailText = adminEventService.getAdminEventDescription(username);
            String emailSubject = EmailText.getAdminNotificationSubject();
            CustomLogger.debug(this.getClass(), String.format(LOG_EMAIL_BODY_FMT, emailText));

            emailer.sendTextEmail(getEmailAddresses(), emailText, emailSubject);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error occurred while sending email notification for Velocity Timer value change.", e);
        }
    }

    /**
     * Sends email notification to reporting distribution list that this user has
     * modified the device reputation throttle percentages.
     *
     * @param long sponsorId, String username
     * @param selectedAppId
     */
    public void notifyDeviceReputationThrottleChange(long sponsorId, Long selectedAppId, String username) throws IPSException {
        String adminEvent = RefAdminEvent.ADMIN_DEVICE_REPUTATION_THROTTLE;
        try {
            adminEventService.logAdminEvent(username, adminEvent, sponsorId, selectedAppId);
            String emailText = adminEventService.getAdminEventDescription(username);
            String emailSubject = EmailText.getAdminNotificationSubject();
            CustomLogger.debug(this.getClass(), String.format(LOG_EMAIL_BODY_FMT, emailText));

            emailer.sendTextEmail(getEmailAddresses(), emailText, emailSubject);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error occurred while sending email notification for Device Reputation volume throttle percentage change.",
                    e);
            throw new IPSException(e.getMessage());
        }
    }

    /**
     * Sends email notification to reporting distribution list that this user has
     * modified the INF supplier config percentages.
     * 
     * @param long sponsorId, String username
     */
    public void notifyInfSupplierConfigChange(long sponsorId, long appId, String username) throws IPSException {
        String adminEvent = RefAdminEvent.ADMIN_SET_LOA15_INF_PV_PERCENTAGES;
        try {
            adminEventService.logAdminEvent(username, adminEvent, sponsorId, appId);
            String emailText = adminEventService.getAdminEventDescription(username);
            String emailSubject = EmailText.getAdminNotificationSubject();
            CustomLogger.debug(this.getClass(), String.format(LOG_EMAIL_BODY_FMT, emailText));
            
           	emailer.sendTextEmail(getEmailAddresses(), emailText, emailSubject);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error occurred while sending email notification for Device Reputation volume throttle percentage change.",
                    e);
            throw new IPSException(e.getMessage());
        }
    }
    
    public void ippEmailsAdminNotification(String username, Timestamp transactionTime, String actionPerformed,
            String newValue, RefSponsor sponsor) throws IPSException {

        try {
            adminEventService.logAdminEvent(username, RefAdminEvent.ADMIN_IPP_EMAILS, sponsor.getSponsorId());
            emailer.sendTextEmail(
                    getEmailAddresses(), EmailText.getIppEmailsAdminNotificationText(userService.findByUserId(username),
                            transactionTime, actionPerformed, newValue, sponsor),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error occurred while sending email notification ipp email change.", e);
            throw new IPSException(e.getMessage());
        }
    }

    /**
     * Sends email notification to Sponsor Report automatic recipients email
     * distribution List to be sent via batch process.
     * 
     * @param userId
     */
    public void notifyRecipientsEmailListChange(Long sponsorId, String username, String reportName,
            String recipientEmailAddresses) throws IPSException {
        CustomLogger.enter(this.getClass());

        String adminEvent = RefAdminEvent.ADMIN_AUTO_RECIPIENT_EMAILS;
        String emailText = "";
        try {
            adminEventService.logAdminEvent(username, adminEvent, sponsorId);
            emailText = adminEventService.getAdminEventDescription(username);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error occurred while logging Admin event on updating Sponsor Report automatic recipient emails.",
                    e);
            throw new IPSException(e.getMessage());
        }

        String emailString = "";
        String lineBreak = "\t\n";

        if (recipientEmailAddresses != null) {
            String[] emailAddressArr = recipientEmailAddresses.replace(" ", "").split(";");
            List<String> autoEmailList = Arrays.asList(emailAddressArr);

            StringBuilder emailSb = new StringBuilder();
            for (String email : autoEmailList) {
                emailSb.append(emailSb.length() == 0 ? "" : lineBreak);
                emailSb.append(email);
            }

            emailString = emailSb.toString();
        } else {
            emailString = "(Recipient email addresses were emptied.)";
        }

        emailText = String.format("%s%s%sReport Name: %s%s%sRecipient Email Addresses: %s%s", emailText, lineBreak,
                lineBreak, reportName, lineBreak, lineBreak, lineBreak, emailString);

        String emailSubject = EmailText.getAdminNotificationSubject();

        try {
            emailer.sendTextEmail(getEmailAddresses(), emailText, emailSubject);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(),
                    "Error occurred while sending email notification to Sponsor Report automatic recipients upon Sponsor_Reports table update.",
                    e);
            throw new IPSException(e.getMessage());
        }
    }

    public void externalAgencyApiNotification(String username, Timestamp transactionTime, RefSponsor sponsor,
            boolean callAgencyService, String retryAttempts, String retryInterval, String serviceCallWaitTime)
            throws IPSException {
        try {
            adminEventService.logAdminEvent(username, RefAdminEvent.ADMIN_EXTERNAL_AGENCY_API, sponsor.getSponsorId());
            emailer.sendTextEmail(getEmailAddresses(),
                    EmailText.getExternalAgencyApiText(userService.findByUserId(username), transactionTime,
                            sponsor.getSponsorName(), callAgencyService, retryAttempts, retryInterval,
                            serviceCallWaitTime),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), EMAIL_NOTIFY_ERR_MSG, e);
            throw new IPSException(e.getMessage());
        }
    }

    @Override
    public List<RefPrimaryIdType> getPrimaryIdList() {
        List<RefPrimaryIdType> list = new ArrayList<>();
        try {
            list = refPrimaryIdTypeService.list();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getPrimaryIdList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefPrimaryIdType> getAvailableStrongList(Long sponsorId) {
        List<RefPrimaryIdType> list = new ArrayList<>();
        try {
            list = refPrimaryIdTypeService.getAvailableStrongList(sponsorId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getRefPrimaryIdTypeStrongList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefSecondaryIdType> getAvailableFairList(Long sponsorId) {
        List<RefSecondaryIdType> list = new ArrayList<>();
        try {
            list = refSecondaryIdTypeService.getAvailableFairList(sponsorId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getAvailableFairList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefPrimaryIdType> getSponsorStrongList(Long sponsorId) {
        List<RefPrimaryIdType> list = new ArrayList<>();
        try {
            list = refPrimaryIdTypeService.getSponsorStrongList(sponsorId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSponsorStrongList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefSecondaryIdType> getSponsorFairList(Long sponsorId) {
        List<RefSecondaryIdType> list = new ArrayList<>();
        try {
            list = refSecondaryIdTypeService.getSponsorFairList(sponsorId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSponsorFairList", e);
            throw e;
        }
        return list;
    }

    @Override
    public void addPrimaryId(RefPrimaryIdType ids) {
        try {
            refPrimaryIdTypeService.create(ids);
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                    .getRequest();
            String username = (String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN);
            String adminEventDescription = RefAdminEvent.ADD_PRIMARY_ID;
            adminEventService.logAdminEvent(username, adminEventDescription);
            String emailText = adminEventService.getAdminEventDescription(username);
            emailer.sendTextEmail(getEmailAddresses(), EmailText.getPrimaryIdNotifications(emailText, ids),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in addPrimaryId", e);
            throw e;
        }
    }

    @Override
    public void updatePrimaryId(RefPrimaryIdType refPrimaryIdType) {
        try {
            refPrimaryIdTypeService.update(refPrimaryIdType);
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                    .getRequest();
            String username = (String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN);
            String adminEventDescription = RefAdminEvent.UPDATE_PRIMARY_ID;
            adminEventService.logAdminEvent(username, adminEventDescription);
            String emailText = adminEventService.getAdminEventDescription(username);
            emailer.sendTextEmail(getEmailAddresses(), EmailText.getPrimaryIdNotifications(emailText, refPrimaryIdType),
                    EmailText.getAdminNotificationSubject());

        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in updatePrimaryId", e);
            throw e;
        }

    }

    @Override
    public long getPrimaryIdUsedCountByIdType(long idType) {
        long num = 0L;
        try {
            num = eventService.getPrimaryIdUsedCountByIdType(idType);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getPrimaryIdUsedCountByIdType", e);
            throw e;
        }
        return num;
    }

    @Override
    public List<RefSecondaryIdType> getSecondaryIdList() {
        List<RefSecondaryIdType> list = new ArrayList<>();
        try {
            list = refSecondaryIdTypeService.list();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSecondaryIdList", e);
            throw e;
        }
        return list;
    }

    @Override
    public void addSecondaryId(RefSecondaryIdType ids) {
        try {
            refSecondaryIdTypeService.create(ids);
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                    .getRequest();
            String username = (String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN);
            String adminEventDescription = RefAdminEvent.ADD_SECONDARY_ID;
            adminEventService.logAdminEvent(username, adminEventDescription);
            String emailText = adminEventService.getAdminEventDescription(username);
            emailer.sendTextEmail(getEmailAddresses(), EmailText.getSecondaryIdNotifications(emailText, ids),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in addSecondaryId", e);
            throw e;
        }

    }

    @Override
    public void updateSecondaryId(RefSecondaryIdType refSecondaryIdType) {
        try {
            refSecondaryIdTypeService.update(refSecondaryIdType);
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                    .getRequest();
            String username = (String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN);
            String adminEventDescription = RefAdminEvent.UPDATE_SECONDARY_ID;
            adminEventService.logAdminEvent(username, adminEventDescription);
            String emailText = adminEventService.getAdminEventDescription(username);
            emailer.sendTextEmail(getEmailAddresses(),
                    EmailText.getSecondaryIdNotifications(emailText, refSecondaryIdType),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in updateSecondaryId", e);
            throw e;
        }

    }

    @Override
    public long getSecondaryIdUsedCountByIdType(long idType) {
        long num = 0L;
        try {
            num = eventService.getSecondaryIdUsedCountByIdType(idType);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSecondaryIdUsedCountByIdType", e);
            throw e;
        }
        return num;
    }

    @Override
    public RefPrimaryIdType getPrimaryIdType(long idType) {
        RefPrimaryIdType obj = new RefPrimaryIdType();
        try {
            obj = refPrimaryIdTypeService.findByPK(idType);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getPrimaryIdType", e);
            throw e;
        }
        return obj;
    }

    @Override
    public RefSecondaryIdType getSecondaryIdType(long idType) {
        RefSecondaryIdType obj = new RefSecondaryIdType();
        try {
            obj = refSecondaryIdTypeService.findByPK(idType);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSecondaryIdType", e);
            throw e;
        }
        return obj;
    }

    @Override
    public void deletePrimaryId(RefPrimaryIdType refPrimaryIdType) {
        try {
            refPrimaryIdTypeService.delete(refPrimaryIdType);
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                    .getRequest();
            String username = (String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN);
            String adminEventDescription = RefAdminEvent.DELETE_PRIMARY_ID;
            adminEventService.logAdminEvent(username, adminEventDescription);
            String emailText = adminEventService.getAdminEventDescription(username);
            emailer.sendTextEmail(getEmailAddresses(), EmailText.getPrimaryIdNotifications(emailText, refPrimaryIdType),
                    EmailText.getAdminNotificationSubject());

        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in deletePrimaryId", e);
            throw e;
        }

    }

    @Override
    public void deleteSecondaryId(RefSecondaryIdType refSecondaryIdType) {
        try {
            refSecondaryIdTypeService.delete(refSecondaryIdType);
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                    .getRequest();
            String username = (String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN);
            String adminEventDescription = RefAdminEvent.DELETE_SECONDARY_ID;
            adminEventService.logAdminEvent(username, adminEventDescription);
            String emailText = adminEventService.getAdminEventDescription(username);
            emailer.sendTextEmail(getEmailAddresses(),
                    EmailText.getSecondaryIdNotifications(emailText, refSecondaryIdType),
                    EmailText.getAdminNotificationSubject());

        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in deleteSecondaryId", e);
            throw e;
        }

    }

    @Override
    public List<RefIppApplications> getApplicationList() {
        List<RefIppApplications> list = new ArrayList<>();
        try {
            list = refIppApplicationsService.getApplicationList();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getApplicationList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefDeviceTypes> getDeviceList() {
        List<RefDeviceTypes> list = new ArrayList<>();
        try {
            list = refDeviceTypesService.getDeviceList();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getDeviceList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefSponsor> getSponsorList() {
        List<RefSponsor> list = new ArrayList<>();
        try {
            list = refSponsorDataService.list();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSponsorList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefSponsor> getIAL2SponsorList(String name) {
        List<RefSponsor> list = new ArrayList<>();
        try {
            list = refSponsorDataService.getIAL2Sponsors(name);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getIAL2SponsorList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefIppWorkflows> getWorkflowsList() {
        List<RefIppWorkflows> list = new ArrayList<>();
        try {
            list = refIppWorkflowsService.list();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getWorkflowsList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<ApplicationWorkflows> getAppWrkFlwList() {
        List<ApplicationWorkflows> list = new ArrayList<>();
        try {
            list = applicationWorkflowsService.list();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getAppWrkFlwList", e);
            throw e;
        }
        return list;
    }

    @Override
    public RefIppApplications getAppByAcr(String acr) {
        RefIppApplications obj = new RefIppApplications();
        try {
            obj = refIppApplicationsService.getAppByAcr(acr);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getAppByAcr", e);
            throw e;
        }
        return obj;
    }

    @Override
    public ApplicationWorkflows getWorkflowCombo(long acr, long device, long sponsor, long workflow) {
        ApplicationWorkflows awf = null;
        List<ApplicationWorkflows> list = new ArrayList<>();
        try {
            list = applicationWorkflowsService.getWorkflowCombo(acr, device, sponsor, workflow);
            if (list != null && !list.isEmpty()) {
                awf = list.get(0);
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getWorkflowCombo", e);
            throw e;
        }
        return awf;
    }

    @Override
    public ApplicationWorkflows getWorkflowFromId(long workflowId) {
        ApplicationWorkflows obj = new ApplicationWorkflows();
        try {
            obj = applicationWorkflowsService.getWorkflowFromId(workflowId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getWorkflowFromId", e);
            throw e;
        }
        return obj;
    }

    @Override
    public void saveApplicationWorkflow(ApplicationWorkflows apps) {
        try {
            applicationWorkflowsService.saveApplicationWorkflow(apps);
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                    .getRequest();
            String username = (String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN);
            String adminEventDescription = RefAdminEvent.ADD_APPLICATION_WORKFLOW;
            adminEventService.logAdminEvent(username, adminEventDescription);
            String emailText = adminEventService.getAdminEventDescription(username);
            emailer.sendTextEmail(getEmailAddresses(), EmailText.getApplicationWorkflowNotifications(emailText, apps),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in saveApplicationWorkflow", e);
            throw e;
        }

    }

    @Override
    public void updateApplicationWorkflow(ApplicationWorkflows apps) {
        try {
            applicationWorkflowsService.updateApplicationWorkflow(apps);
            applicationWorkflowsService.saveApplicationWorkflow(apps);
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                    .getRequest();
            String username = (String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN);
            String adminEventDescription = RefAdminEvent.UPDATE_APPLICATION_WORKFLOW;
            adminEventService.logAdminEvent(username, adminEventDescription);
            String emailText = adminEventService.getAdminEventDescription(username);
            emailer.sendTextEmail(getEmailAddresses(), EmailText.getApplicationWorkflowNotifications(emailText, apps),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in updateApplicationWorkflow", e);
            throw e;
        }

    }

    @Override
    public void deleteApplicationWorkflow(ApplicationWorkflows apps) {
        try {
            applicationWorkflowsService.deleteApplicationWorkflow(apps);
            applicationWorkflowsService.saveApplicationWorkflow(apps);
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                    .getRequest();
            String username = (String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN);
            String adminEventDescription = RefAdminEvent.DELETE_APPLICATION_WORKFLOW;
            adminEventService.logAdminEvent(username, adminEventDescription);
            String emailText = adminEventService.getAdminEventDescription(username);
            emailer.sendTextEmail(getEmailAddresses(), EmailText.getApplicationWorkflowNotifications(emailText, apps),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in deleteApplicationWorkflow", e);
            throw e;
        }

    }

    @Override
    public List<SponsorStrongId> getSponsorStrongIdListBySponsorId(Long sponsorId) {
        CustomLogger.enter(this.getClass());

        List<SponsorStrongId> list = new ArrayList<>();
        try {
            list = sponsorStrongIdService.getListBySponsorId(sponsorId);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSponsorStrongIdListBySponsorId", e);
            throw e;
        }
        return list;
    }

    @Override
    public SponsorStrongId createSponsorStrongId(SponsorStrongId entity) {
        CustomLogger.enter(this.getClass());

        try {
            entity = sponsorStrongIdService.create(entity);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in createSponsorStrongId", e);
            throw e;
        }
        return entity;
    }

    @Override
    public SponsorFairId createSponsorFairId(SponsorFairId entity) {
        CustomLogger.enter(this.getClass());

        try {
            entity = sponsorFairIdService.create(entity);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in createSponsorFairId", e);
            throw e;
        }
        return entity;
    }

    @Override
    public void removeSponsorStrongId(Long sponsorId, Long idType) {
        CustomLogger.enter(this.getClass());

        try {
            sponsorStrongIdService.remove(sponsorId, idType);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in removeSponsorStrongId", e);
            throw e;
        }
    }

    @Override
    public void removeSponsorFairId(Long sponsorId, Long idType) {
        CustomLogger.enter(this.getClass());

        try {
            sponsorFairIdService.remove(sponsorId, idType);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in removeSponsorFairId", e);
            throw e;
        }
    }

    @Override
    public void updateRefSponsorConfiguration(RefSponsorConfiguration refSponsorConfig) {
        CustomLogger.enter(this.getClass());

        try {
            refSponsorConfig.setUpdateDate(new Date());
            refSponsorConfigurationService.update(refSponsorConfig);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in updating RefSponsorConfiguration", e);
            throw e;
        }
    }
    
    @Override
    public void createRefSponsorConfiguration(RefSponsorConfiguration refSponsorConfig) {
        CustomLogger.enter(this.getClass());

        try {
            refSponsorConfig.setConfigurationId(refSponsorConfigurationService.getMostRecentConfigId() + 1);
            refSponsorConfig.setCreateDate(new Date());
            refSponsorConfigurationService.create(refSponsorConfig);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in creating new RefSponsorConfiguration", e);
            throw e;
        }
    }

    @Override
    public RefSponsorConfiguration getRefSponsorConfiguration(int sponsorId, String name) {
        CustomLogger.enter(this.getClass());

        RefSponsorConfiguration refSponsorConfig = null;
        try {
            refSponsorConfig = refSponsorConfigurationService.getConfigRecord(sponsorId, name);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getRefSponsorConfiguration", e);
            throw e;
        }

        return refSponsorConfig;
    }

    @Override
    public long getPrimaryIdCountForSponsor(long idType) {

        long num = 0L;
        try {
            num = sponsorStrongIdService.getPrimaryIdCountForSponsor(idType);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getPrimaryIdCountForSponsor", e);
            throw e;
        }
        return num;
    }

    @Override
    public long getSecondaryIdCountForSponsor(long idType) {

        long num = 0L;
        try {
            num = sponsorFairIdService.getSecondaryIdCountForSponsor(idType);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSecondaryIdCountForSponsor", e);
            throw e;
        }
        return num;
    }

    @Override
    public long getPrimaryIdUsedCountByIdValidation(long idType) {
        long num = 0L;
        try {
            num = ippEventIDValidationService.getPrimaryIdUsedCountByIdValidation(idType);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getPrimaryIdUsedCountByIdValidation", e);
            throw e;
        }
        return num;
    }

    @Override
    public long getSecondaryIdCountByEventSecondary(long idType) {
        long num = 0L;
        try {
            num = ippEventSecondaryIdService.getSecondaryIdCountByEventSecondary(idType);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSecondaryIdCountByEventSecondary", e);
            throw e;
        }
        return num;
    }

    @Override
    public RefSponsorConfiguration getWorkflowStatus() {
        RefSponsorConfiguration value = null;
        String env = Utils.getEnvironmentWithoutDot().toUpperCase();
        CustomLogger.info(this.getClass(), "Environment returned: " + env);
        try {
            value = refSponsorConfigurationService.getConfigRecord(1, RefSponsorConfiguration.HOLDMAIL_FLOW_FLAG);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getWorkflowStatus", e);
            throw e;
        }
        return value;
    }

    @Override
    public void saveHoldmailWorkflow(RefSponsorConfiguration lookupCodes) {
        try {

            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
                    .getRequest();
            String username = (String) request.getSession().getAttribute(ATTRIBUTE_IVSTOKEN);
            String adminEventDescription = RefAdminEvent.ADMIN_HOLDMAIL_FLAG;

            refSponsorConfigurationService.update(lookupCodes);

            adminEventService.logAdminEvent(username, adminEventDescription);
            String emailText = adminEventService.getAdminEventDescription(username);
            String emailSubject = EmailText.getAdminNotificationSubject();
            emailer.sendTextEmail(getEmailAddresses(), emailText, emailSubject);

        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in saveHoldmailWorkflow", e);
            throw e;
        }
    }

    @Override
    public void ial2ConfirmationNotificationChange(String username, Timestamp transactionTime, RefSponsor sponsor,
            String notifType) throws IPSException {
        try {
            adminEventService.logAdminEvent(username, RefAdminEvent.ADMIN_IAL2_CONFIRMATION_NOTIFICATION,
                    sponsor.getSponsorId());
            emailer.sendTextEmail(getEmailAddresses(),
                    EmailText.getIAL2ConfirmationNotificationText(userService.findByUserId(username), transactionTime,
                            sponsor.getSponsorName(), notifType),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), EMAIL_NOTIFY_ERR_MSG, e);
            throw new IPSException(e.getMessage());
        }
    }

    @Override
    public void sendIal2ConfigChangeConfirmNotification(Long selectedSponsorId, String userId,
            String externalAgencyName, Timestamp transactionTime, String configValue, String configType)
            throws IPSException {
        CustomLogger.enter(this.getClass());

        String adminEvent = "";

        switch (configType) {
        case IAL2ConfigurationAdminBean.CONFIG_REQUIRES_IAL2_TYPE:
            adminEvent = RefAdminEvent.ADMIN_IAL2_CONFIG_REQUIRES_IAL2;
            break;
        case IAL2ConfigurationAdminBean.CONFIG_OPTION1_ENABLED_TYPE:
            adminEvent = RefAdminEvent.ADMIN_IAL2_CONFIG_OPTION1_ENABLED;
            break;
        case IAL2ConfigurationAdminBean.CONFIG_PRIMARY_VENDOR_TYPE:
            adminEvent = RefAdminEvent.ADMIN_IAL2_CONFIG_PRIMARY_VENDOR;
            break;
        case IAL2ConfigurationAdminBean.CONFIG_BACKUP_VENDOR_TYPE:
            adminEvent = RefAdminEvent.ADMIN_IAL2_CONFIG_BACKUP_VENDOR;
            break;
        case IAL2ConfigurationAdminBean.CONFIG_STRONG_ID_LIST_TYPE:
            adminEvent = RefAdminEvent.ADMIN_IAL2_CONFIG_STRONG_ID_LIST;
            break;
        case IAL2ConfigurationAdminBean.CONFIG_FAIR_ID_LIST_TYPE:
            adminEvent = RefAdminEvent.ADMIN_IAL2_CONFIG_FAIR_ID_LIST;
            break;
        case ExternalAgencyIdConfigAdminBean.CONFIG_ACCEPTED_ID_LIST_TYPE:
            adminEvent = RefAdminEvent.ADMIN_ACCEPTABLE_IDS;
            break;
        case IAL2ConfigurationAdminBean.CONFIG_ID_VALIDATION_RETRY_ATTEMPTS: 
        	adminEvent = RefAdminEvent.ADMIN_IAL2_CONFIG_ID_VALIDATION_RETRY_ATTEMPTS;
        	break;     
        default:
        }

        try {       	
           adminEventService.logAdminEvent(userId, adminEvent, selectedSponsorId);
            emailer.sendTextEmail(
                    getEmailAddresses(), EmailText.getIAL2ConfigChangeNotificationText(userService.findByUserId(userId),
                            transactionTime, adminEvent, externalAgencyName, configValue),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {         	
            CustomLogger.error(this.getClass(), EMAIL_NOTIFY_ERR_MSG, e);
            throw new IPSException(e.getMessage());
        }
    }

    @Override
    public String getLookupValue(String name) {
        return lookupCodeEnvService.getValueByEnvironment(Utils.getEnvironmentWithoutDot().toUpperCase(), name)
                .getValue();
    }

    @Override
    public void updateVendorConfiguration(List<RefIdValidationVendorConfiguration> vendorList, String userId) {
        for (RefIdValidationVendorConfiguration r : vendorList) {
        	updateEnvValueByEnvironment(Utils.getEnvironmentWithoutDot().toUpperCase(), r.getVendorName().concat(".VENDORURL"),
        			r.getValue(), userId);
        }
        
        String adminEventDescription = RefAdminEvent.ADMIN_IAL2_VENDOR_CONFIGURATION_URL;
        
        List<String> newValueList = new ArrayList<>();
        for (RefIdValidationVendorConfiguration r : vendorList) {
        	newValueList.add(String.format("%s.VendorURL - %s", r.getVendorName(), r.getValue()));
        }
   
        sendTextEmailOnLookupCodeChange(newValueList, adminEventDescription, userId);
    }
    
    @Override
    public boolean updateEnvValueByEnvironment(String env, String name, String value, String userId) {
    	try {
    		lookupCodeEnvService.updateEnvValueByEnvironment(env, name, value, userId);
         } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error in updating the LookupCodesEnv value by environment.");
            return false;
        }
    	return true;
    }
    
    @Override
    public boolean updateVendorTokenByType(String type, Timestamp expirationTime) {
    	try {
    		VendorToken entity = vendorTokenService.findByType(type);
    		entity.setExpirationTime(expirationTime);
    		
    		vendorTokenService.update(entity);
         } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error in updating the VendorToken expirationTime.");
            return false;
        }
    	return true;
    }

    @Override
    public void barcodeLimitScanIndAdminNotification(int sponsorId, String username) {
        try {
            adminEventService.logAdminEvent(username, RefAdminEvent.LIMIT_IPP_SCAN_INDICATOR, Long.valueOf(sponsorId));
            String emailSubject = EmailText.getAdminNotificationSubject();
            String emailText = adminEventService.getAdminEventDescription(username);
            emailer.sendTextEmail(getEmailAddresses(), emailText, emailSubject);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error sending scan limit number change notification.");
        }

    }

    @Override
    public void barcodeMaxScanLimitNotification(int sponsorId, String username) {
        try {
            adminEventService.logAdminEvent(username, RefAdminEvent.MAX_IPP_SCAN_LIMIT, Long.valueOf(sponsorId));
            String emailSubject = EmailText.getAdminNotificationSubject();
            String emailText = adminEventService.getAdminEventDescription(username);
            emailer.sendTextEmail(getEmailAddresses(), emailText, emailSubject);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error sending scan limit number change notification.");
        }
    }

    @Override
    public void sponsorNotification(String username, RefSponsor sponsor, Timestamp tStamp, String action)
            throws IPSException {
        String text = "";
        if (RefAdminEvent.ADD_NEW_SPONSOR.equalsIgnoreCase(action)) {
            text = EmailText.getAddSponsorNotificationText(userService.findByUserId(username), sponsor.getSponsorName(),
                    tStamp);
        } else if (RefAdminEvent.UPDATE_SPONSOR.equalsIgnoreCase(action)) {
            text = EmailText.getUpdatedSponsorNotificationText(userService.findByUserId(username), sponsor, tStamp);
        } else if (RefAdminEvent.DELETED_SPONSOR.equalsIgnoreCase(action)) {
            text = EmailText.getRemoveSponsorNotificationText(userService.findByUserId(username), sponsor, tStamp);
        }
        
		CustomLogger.debug(this.getClass(), "sponsorNotification :: subject:" + EmailText.getAdminNotificationSubject());
		CustomLogger.debug(this.getClass(), "sponsorNotification :: recipients:" + getEmailAddresses());
		CustomLogger.debug(this.getClass(), "sponsorNotification :: body:" + text);

        try {
        	Long sponsorId = sponsor.getSponsorId();
        	if (RefAdminEvent.DELETED_SPONSOR.equalsIgnoreCase(action)) {
        		sponsorId = null;
        	}
        	
       		adminEventService.logAdminEvent(username, action, sponsorId);
       	         	
            emailer.sendTextEmail(getEmailAddresses(), text, EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred when sending admin sponsor notification", e);
            throw new IPSException(e.getMessage());
        }
    }

    @Override
    public void applicationNotification(String username, RefApp app, Timestamp tStamp, String action)
            throws IPSException {
        String actionText = "";
        if (RefAdminEvent.NEW_APPLICATION.equalsIgnoreCase(action)) {
            actionText = "added";
        } else if (RefAdminEvent.UPDATED_APPLICATION.equalsIgnoreCase(action)) {
            actionText = "updated";
        } else if (RefAdminEvent.DELETED_APPLICATION.equalsIgnoreCase(action)) {
            actionText = "deleted";
        }

        try {
            adminEventService.logAdminEvent(username, action);
            emailer.sendTextEmail(getEmailAddresses(), EmailText
                    .getApplicationNotificationText(userService.findByUserId(username), app, tStamp, actionText),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred when sending admin application notification", e);
            throw new IPSException(e.getMessage());
        }
    }

    @Override
    public void sponsorApplicationMapNotification(String username, SponsorApplicationMap sam, Timestamp tStamp,
            String action) throws IPSException {
        String actionText = "";
        if (RefAdminEvent.CONFIGURE_APPLICATION.equalsIgnoreCase(action)) {
            actionText = "configured";
        } else if (RefAdminEvent.UPDATE_APPLICATION_MAP.equalsIgnoreCase(action)) {
            actionText = "updated";
        } else if (RefAdminEvent.DELETE_APPLICATION_MAP.equalsIgnoreCase(action)) {
            actionText = "deleted";
        }

        try {
            adminEventService.logAdminEvent(username, action);
            emailer.sendTextEmail(getEmailAddresses(), EmailText
                    .getSponsorApplicationNotificationText(userService.findByUserId(username), sam, tStamp, actionText),
                    EmailText.getAdminNotificationSubject());
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred when sending admin application notification", e);
            throw new IPSException(e.getMessage());
        }
    }

    @Override
    public List<RefSponsor> getActiveExternalSponsorList() {
        List<RefSponsor> list = new ArrayList<>();
        try {
            list = refSponsorDataService.getActiveExternalSponsorList();
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getActiveExternalSponsorList", e);
            throw e;
        }
        return list;
    }
    
    @Override
    public List<RefApp> getAppListBySponsor(long sponsorId) {
        List<RefApp> list = new ArrayList<>();
        try {
        	List<Long> appIdList = new ArrayList<>();
        	List<SponsorApplicationMap> appMapList = sponsorApplicationMapService.getRelationsBySponsor(sponsorId);
        	
        	for(SponsorApplicationMap map : appMapList) {
        		appIdList.add(map.getApp().getAppId());
        	}

            list = refAppService.getAppListByIdList(appIdList);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getAppListBySponsor", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefPrimaryIdType> getAvailableIdList(String value) {
        List<RefPrimaryIdType> list = new ArrayList<>();
        try {
            list = refPrimaryIdTypeService.getAvailableIdList(value);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getAvailableIdList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefPrimaryIdType> getSponsorAcceptedIdTypeList(String value) {
        List<RefPrimaryIdType> list = new ArrayList<>();
        try {
            list = refPrimaryIdTypeService.getSponsorAcceptedIdTypeList(value);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSponsorAcceptedIdTypeList", e);
            throw e;
        }
        return list;
    }
    
    @Override
    public List<RefSecondaryIdType> getAvailableSecondaryIdList(String value) {
        List<RefSecondaryIdType> list = new ArrayList<>();
        try {
            list = refPrimaryIdTypeService.getAvailableSecondaryIdList(value);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getAvailableIdList", e);
            throw e;
        }
        return list;
    }

    @Override
    public List<RefSecondaryIdType> getSponsorAcceptedSecondaryIdTypeList(String value) {
        List<RefSecondaryIdType> list = new ArrayList<>();
        try {
            list = refPrimaryIdTypeService.getSponsorAcceptedSecondaryIdTypeList(value);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred in getSponsorAcceptedIdTypeList", e);
            throw e;
        }
        return list;
    }

    @Override
    public void minAgeChangeNotif(String username, RefSponsor sponsor, String minAgeReq, String minAge) {
        adminEventService.logAdminEvent(username, RefAdminEvent.ADMIN_RETAIN_PII_CHANGE, sponsor.getSponsorId());
        notifyAdminsMinAgeChange(username, sponsor, minAgeReq, minAge);
    }

    private void notifyAdminsMinAgeChange(String username, RefSponsor sponsor, String minAgeReq, String minAge) {
        emailer.sendTextEmail(getEmailAddresses(),
                EmailText.getMinAgeNotificationText(userService.findByUserId(username), new Timestamp(new Date().getTime()), sponsor.getSponsorName(), RefAdminEvent.ADMIN_MIN_AGE_CHANGE, minAgeReq, minAge),
                EmailText.getAdminNotificationSubject());
    }
    
    @Override
    public Response validateIDRequest(ValidateIDRequest request, String requestErrorMsg) {
		if (requestErrorMsg != null) {
			CustomLogger.debug(this.getClass(), "Validate ID Request :: Request Error Msg:" + requestErrorMsg);
			JSONObject errorResponse = new JSONObject();
			errorResponse.put(RESPONSE_MESSAGE, requestErrorMsg);
			return buildResponse(Response.Status.BAD_REQUEST, errorResponse, "");
		} else {
			return ipsRestResourceService.validateID(request, "Basic 1PPf0rEBI$21");
		}
    }
   
    @Override
    public Response verifyStateId(ValidationRequest verifyRequest, IppEvent ippEvent, String requestErrorMsg) {
  		CustomLogger.debug(this.getClass(), "Admin Verify State ID ...");
		JSONObject responseEntity = new JSONObject();

		if (requestErrorMsg != null) {
			CustomLogger.debug(this.getClass(), "Validate ID Request :: Request Error Msg:" + requestErrorMsg);
			responseEntity.put(RESPONSE_MESSAGE, requestErrorMsg);
			return buildResponse(Response.Status.BAD_REQUEST, responseEntity, "");
		} else {
			VerifyStateIDResponse verifyResponse;
			try {
				verifyResponse = idVerificationService.verifyStateID(ippEvent, verifyRequest);
				String validationResult = verifyResponse.getValidationResult();
				responseEntity.put(RESPONSE_MESSAGE, "State ID was successfully verified by Equifax.");
				responseEntity.put("IppComplete", verifyResponse.getIppComplete());
				responseEntity.put("ValidationResult", validationResult);
				
				if ("FAIL".equalsIgnoreCase(validationResult)) {
					responseEntity.put("FailureReason", verifyResponse.getFailureReason());
				}
			} catch (IPSException e) {
				responseEntity.put("RESPONSE_MESSAGE", "Internal server error. State ID was not verified by Equifax.");
			}
			
			return buildResponse(Response.Status.OK, responseEntity, "");				
		}
    }
    
    @Override 
    public Response verifyAddress(IppEvent ippEvent, String requestErrorMsg)  {
  		CustomLogger.debug(this.getClass(), "Admin Verify address ...");
  		
		JSONObject responseEntity = new JSONObject();
  	
		if (requestErrorMsg != null) {
			CustomLogger.debug(this.getClass(), "Admin Verify address :: Request Error Msg:" + requestErrorMsg);
			responseEntity.put(RESPONSE_MESSAGE, requestErrorMsg);
			return buildResponse(Response.Status.BAD_REQUEST, responseEntity, "");
		} else {
			CustomLogger.debug(this.getClass(), "Admin Verify address :: No request error msg");
			Gson g = new Gson();
			
	    	IdDocumentDetails documentDetails = idVerificationService.getLatestDocumentDetails(ippEvent.getIppEventId());
			AddressValidateRequest request = idVerificationService.buildAddressValidateRequest(documentDetails, 
					ippEvent.getPerson().getPersonData());
			
			String documentDetailJson =  g.toJson(documentDetails, documentDetails.getClass());
			String requestJson =  g.toJson(request, request.getClass());
			CustomLogger.debug(this.getClass(), "Admin Verify address :: Document Detail json: " + documentDetailJson);
			CustomLogger.debug(this.getClass(), "Admin Verify address :: Request json: " + requestJson);

			AddressValidateResponse validateResponse = webtoolsApiService.verifyAddress(request);
			
			if (validateResponse != null) {
				CustomLogger.debug(this.getClass(), "Admin Verify address :: AddressValidateResponse is not null.");
				responseEntity.put(RESPONSE_MESSAGE, "Address verification was successfully processed.");
				responseEntity.put("AddressListSize", validateResponse.getAddresses().size());
				responseEntity.put("Address1", validateResponse.getAddresses().get(0).getAddress1());
				responseEntity.put("Address2", validateResponse.getAddresses().get(1).getAddress2());
			}
			else {
				CustomLogger.debug(this.getClass(), "Admin Verify address :: AddressValidateResponse is null.");
				responseEntity.put(RESPONSE_MESSAGE, "Address verification was not processed. AddressValidateResponse is null.");
			}

			return buildResponse(Response.Status.OK, responseEntity, "");				
		}
    }
    
	private Response buildResponse(Response.Status status, Object entity, String origin) {
		Response resp = Response.status(status).entity(entity).build();
		ResponseBuilder rb = Response.fromResponse(resp);
		rb.header("Access-Control-Allow-Origin", origin);
		rb.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
		return rb.build();
	}
    
    @Override
    public void sendTextEmailOnLookupCodeChange(List<String> newValueList, String adminEventDescription, String userId) {
        adminEventService.logAdminEvent(userId, adminEventDescription);
        
        String emailSubject = EmailText.getAdminNotificationSubject();
        String emailText = adminEventService.getAdminEventDescription(userId);
        StringBuilder sb = new StringBuilder();
        sb.append("New Values:\n\n");
	        
        for (String val : newValueList) {
            sb.append(val.concat("\n\n"));
        }
	        
        emailText = emailText.concat("\n\n");
        emailText = emailText.concat(sb.toString());
        emailer.sendTextEmail(getEmailAddresses(), emailText, emailSubject);
    }

    public boolean isLocalServer() {
    	return emailer.isLocalServer();
	}
}
