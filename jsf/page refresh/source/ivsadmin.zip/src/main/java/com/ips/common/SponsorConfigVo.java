package com.ips.common;

import java.io.Serializable;

public class SponsorConfigVo implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private int configId;
    private int sponsorId;
    private String configName;
    private String sponsorName;
    private String configValue;
    private boolean isValueTrue;
    
    public int getConfigId() {
        return configId;
    }
    
    public void setConfigId(int configId) {
        this.configId = configId;
    }

    public int getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(int sponsorId) {
        this.sponsorId = sponsorId;
    }

    public String getConfigName() {
        return configName;
    }

    public void setConfigName(String configName) {
        this.configName = configName;
    }

    public String getSponsorName() {
        return sponsorName;
    }

    public void setSponsorName(String sponsorName) {
        this.sponsorName = sponsorName;
    }

    public String getConfigValue() {
        return configValue;
    }

    public void setConfigValue(String configValue) {
        this.configValue = configValue;
    }

    public boolean isValueTrue() {
        return isValueTrue;
    }

    public void setIsValueTrue(boolean isValueTrue) {
        this.isValueTrue = isValueTrue;
    }
}
