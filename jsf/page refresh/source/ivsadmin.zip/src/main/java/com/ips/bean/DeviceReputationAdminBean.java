package com.ips.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.OtpConfigVo;
import com.ips.common.SponsorConfigVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.SponsorEnum;
import com.ips.common.common.Utils;
import com.ips.entity.RefApp;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpFeatureAttempt;
import com.ips.persistence.common.DeviceReputationVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.NameValueVo;
import com.ips.service.AdminService;
import com.ips.service.DeviceReputationService;
import com.ips.service.RefAppService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;
import com.ips.service.RpFeatureAttemptService;
import com.ips.service.SponsorApplicationMapService;
import com.ips.service.TruthDataReturnService;

@ManagedBean(name = "deviceReputationAdmin")
@ViewScoped
public class DeviceReputationAdminBean extends IPSAdminController implements Serializable {
	private static final long serialVersionUID = 1L;

	private RefSponsorConfigurationService refSponsorConfigService;
	private AdminService adminService;
	private RpFeatureAttemptService featureAttemptService;
	private RefSponsorConfiguration velocitySponsorConfig;
	private RefSponsorDataService refSponsorService;
	private RefAppService refAppService;
	private DeviceReputationService deviceReputationService;
	private TruthDataReturnService truthDataSendEmailService;
	private SponsorApplicationMapService sponsorApplicationMapService;

	private List<RefSponsorConfiguration> sponsorConfigList;
	private List<RefSponsor> sponsorList;
	private List<RefApp> appList;
	private List<NameValueVo> appNameValueList;
	private List<SponsorConfigVo> configVoList;
	private List<RpFeatureAttempt> featureNameList;
	private List<DeviceReputationVo> userAttemptList;
	private List<OtpConfigVo> infSupplierConfigList;

	private int[] percentages = { 0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100 };
	private Long selectedSponsorId = 0L;
	private Long selectedAppId = 1L;
	private Long selectedFeatSponsorId;
	private Long selectedFeatAppId;
	private Long selectedInfSponsorId = 1L;
	private Long selectedVelocityTimerSponsorId = 1L;
	private boolean initialized = false;
	private boolean confirmPercentageChange;
	private boolean confirmChangeBtn;
	private boolean initialActivationThrottleButton;
	private boolean activationChanged;
	private boolean percentageChanged;
	private boolean showActivationTable;
	private boolean showActivationThrottleInstMsg;
	private boolean showActivationThrottleErrorMsg;
	private boolean showActivationThrottleSuccessMsg;
	private boolean showAppSelector;
	private boolean showFeatAppSelector;
	private boolean showFeatConfigInstMsg;
	private boolean showFeatConfigErrorMsg;
	private boolean showFeatConfigSuccessMsg;
	private boolean showFeatConfigTable;
	private boolean showAddAttemptFeatBtn;
	private boolean showRemoveAttemptFeatBtn;
	private boolean showConfirmAttemptFeatBtn;
	private boolean showCancelAttemptFeatBtn;
	private boolean showInfSupplierConfigInstMsg;
	private boolean showInfSupplierConfigErrorMsg;
	private boolean showInfSupplierConfigSuccessMsg;
	private boolean infSupplierPercentageChanged;
	private boolean confirmInfSupplierPercentageChange;
	private boolean initialInfSupplierConfigButton;
	private boolean confirmInfSupplierConfigChangeBtn;
	private boolean showVelocityTimerInstMsg;
	private boolean showVelocityTimerErrorMsg;
	private boolean showVelocityTimerSuccessMsg;
	private boolean showVelocityTimerChangeBtn;
	private boolean showVelocityTimerConfirmBtn;
	private boolean showVelocityTimerCancelBtn;
	private boolean calendarSelectErrorMsg;
	private boolean renderReportSection;
	private String activationThrottleInstMsg;
	private String activationThrottleErrorMsg;
	private String activationThrottleSuccessMsg;
	private String featConfigInstMsg;
	private String featConfigErrorMsg;
	private String featConfigSuccessMsg;
	private String infSupplierConfigInstMsg;
	private String infSupplierConfigErrorMsg;
	private String infSupplierConfigSuccessMsg;
	private String velocityTimerInstMsg;
	private String velocityTimerErrorMsg;
	private String velocityTimerSuccessMsg;
	private String currVelocityTimerValue;
	private String velocityTimerValue;
	private String featureStatusMsg;
	private String truthDataSendEmailId;
	private String truthDataSendEmailAddress;
	private Date reportRunDate;
	private String serverName;

	protected static final String DEVICE_REPUTATION = "device_reputation.xhtml";
	private static final String CONFIG_VALUE_TRUE = "True";
	private static final String CONFIG_VALUE_FALSE = "False";
	private static final String THRESHOLD_CONFIG_PORTAL_URL = "https://portal.threatmetrix.us";
	private static final String MESSAGE_TYPE_INFO = "info";
	private static final String MESSAGE_TYPE_SUCCESS = "success";
	private static final String MESSAGE_TYPE_ERROR = "error";
	private static final String SUCCESS_MSG = "Successfully updated!";
	private static final String IVS_TOKEN = "IVSToken";
	private static final long CUST_REG_SPONSOR_ID = 1L;
	private static final long CUSTREG_DR_ENABLED_FEATURE_ID = 1L;
	private static final long OPSANTA_DR_ENABLED_FEATURE_ID = 3L;

	@PostConstruct
	public void init() {
		CustomLogger.enter(this.getClass());
		if (initialized) {
			return;
		}

		initialized = true;
		initServices();
		sponsorList = adminService.retrieveSponsorList();
		loadInfSupplierTable(RefSponsor.SPONSOR_ID_CUSTREG);
		resetButtons(true);
		clear();

		setActivationThrottleInstMsg("Select Sponsor of the Application to be configured.");
		setShowActivationThrottleInstMsg(true);
		setInitialActivationThrottleButton(false);

		setFeatConfigInstMsg("Select Sponsor of the Device Reputation Attempt Features.");
		setShowFeatConfigInstMsg(true);

		initVelocityTimerConfigControls();
	}

	/******* Common Methods *******/

	public void initServices() {
		CustomLogger.enter(this.getClass());

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(ctx);
		if (webAppContext != null) {
			adminService = webAppContext.getBean(AdminService.class);
			deviceReputationService = webAppContext
					.getBean(DeviceReputationService.class);
			refAppService = webAppContext.getBean(RefAppService.class);
			refSponsorConfigService = webAppContext
					.getBean(RefSponsorConfigurationService.class);
			refSponsorService = webAppContext
					.getBean(RefSponsorDataService.class);
			featureAttemptService = webAppContext
					.getBean(RpFeatureAttemptService.class);
			truthDataSendEmailService = webAppContext
					.getBean(TruthDataReturnService.class);
			sponsorApplicationMapService = webAppContext
					.getBean(SponsorApplicationMapService.class);
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();
			setServerName(request.getServerName());
		} else {
			CustomLogger.error(this.getClass(),
					"Error: WebApplicationContext is null. Unable to retrieve necessary services.");
			goToPage(SYSTEM_ERROR_PAGE);
		}
		
	}

	/**
	 * Checks if the activation switch and/or volume throttle percentage values are
	 * changed.
	 * 
	 * @return
	 */
	public void changeActivationThrottle() {
		CustomLogger.enter(this.getClass());

		percentageChanged = isPercentageChanged();
		boolean bothChanged = activationChanged && percentageChanged;
		boolean neitherChanged = !activationChanged && !percentageChanged;
		setShowActivationThrottleInstMsg(false);

		if (percentageChanged) {
			setInitialActivationThrottleButton(false);
			setConfirmChangeBtn(true);
			setConfirmPercentageChange(true);
			setActivationThrottleInstMsg(
					"You are changing the Device Reputation percentages.  If this is correct, select Confirm below.");
			setShowActivationThrottleInstMsg(true);
			setShowActivationThrottleSuccessMsg(false);
		} else {
			setShowActivationThrottleInstMsg(neitherChanged);
			setActivationThrottleInstMsg(neitherChanged ? "You have made no changes to save." : "");
		}

		initialized = true;
	}

	/**
	 * Updates activation switch and/or volume throttle percentage configuration.
	 * 
	 * @return
	 */
	public void saveActivationThrottle() {
		CustomLogger.enter(this.getClass());

		if (percentageChanged) {
			savePercentage();
		}
	}

	/**
	 * Reloads the checkbbox and feature attempts table, and resets buttons and
	 * messages.
	 * 
	 * @return
	 */
	public void cancelActivationThrottle() {
		CustomLogger.enter(this.getClass());

		initializedMessage();
		loadFeatureTable();
		resetListPercentages();
		resetButtons(true);
	}

	/**
	 * Resets buttons and messages.
	 * 
	 * @return
	 */
	private void resetButtons(boolean initial) {
		setInitialActivationThrottleButton(true);
		setConfirmChangeBtn(false);
		setConfirmPercentageChange(false);
		setShowActivationThrottleErrorMsg(false);
		setShowActivationThrottleInstMsg(initial);
		setShowActivationThrottleSuccessMsg(!initial);
		setInitialInfSupplierConfigButton(true);
	}

	/******* Activation Switch *******/

	public void refreshThrottleConfig() {
		CustomLogger.enter(this.getClass());

		if (selectedAppId == 0L) {
			return;
		}

		refreshThrottleConfigByApp(selectedAppId);
		setShowActivationThrottleInstMsg(false);
		setInitialActivationThrottleButton(true);
	}

	public void refreshThrottleConfigByApp(long appId) {
		CustomLogger.enter(this.getClass());

		if (appId == 0L) {
			return;
		}

		initializedMessage();
		loadFeatureTable();
		setActivationChanged(false);
		setPercentageChanged(false);
		setShowActivationTable(true);
		setInitialActivationThrottleButton(true);
	}

	public void loadAppSelector(ValueChangeEvent vcEvent) {
		CustomLogger.enter(this.getClass());

		selectedSponsorId = ((Long) vcEvent.getNewValue()).longValue();

		if (selectedSponsorId == 0L) {
			return;
		}
		appList = adminService.getAppListBySponsor(selectedSponsorId);

		if (appList == null || appList.isEmpty()) {
			return;
		}

		appNameValueList = new ArrayList<NameValueVo>();
		appNameValueList.add(new NameValueVo("Select an Application", 0L));

		for (RefApp app : appList) {
			appNameValueList.add(new NameValueVo(app.getAppName(), app.getAppId()));
		}

		setShowAppSelector(true);
		this.selectedAppId = 0L;

		setShowActivationTable(false);
		setActivationThrottleInstMsg("Select Application of the selected Sponsor.");
		setShowActivationThrottleInstMsg(true);
		setInitialActivationThrottleButton(false);

		featureStatusMsg = "";
	}

	/**
	 * Updates RefSponsorConfiguration for Device Reputation activation switch
	 * value.
	 * 
	 * @param refSponsorConfig
	 * @param username
	 * @return
	 */
	public void updateDeviceReputationActivation(RefSponsorConfiguration refSponsorConfig, String username) {
		CustomLogger.enter(this.getClass());

		try {
			refSponsorConfigService.update(refSponsorConfig);
			setShowActivationThrottleSuccessMsg(true);
			setActivationThrottleSuccessMsg(SUCCESS_MSG);
		} catch (Exception e) {
			String errorMsg = "Error occurred trying to update an Device Reputation value for user " + username;
			CustomLogger.error(this.getClass(), errorMsg, e);
			setShowActivationThrottleErrorMsg(true);
			setActivationThrottleErrorMsg(errorMsg);
			return;
		}

		notifyDeviceReputationActivationChange(username);
	}

	/**
	 * Set loadRefSponsorConfigList to find RefSponsorConfig list to be used
	 * globally inside the class.
	 * 
	 * @return
	 */
	public void loadRefSponsorConfigList() {
		CustomLogger.enter(this.getClass());

		try {
			sponsorConfigList = refSponsorConfigService
					.findConfigRecordByName(RefSponsorConfiguration.DEVICE_REPUTATION_ACTIVATION);
			configVoList = new ArrayList<>();

			for (RefSponsorConfiguration config : sponsorConfigList) {
				SponsorConfigVo vo = new SponsorConfigVo();

				String description = SponsorEnum.getDescriptionBySponsorId(config.getSponsorId());
				vo.setSponsorId(config.getSponsorId());
				vo.setSponsorName(description);
				vo.setIsValueTrue(CONFIG_VALUE_TRUE.equalsIgnoreCase(config.getValue()));
				configVoList.add(vo);
			}
		} catch (Exception e) {
			String errorMsg = "Error occurred trying to retrieve Sponsor Configuration for Device Reputation.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setShowActivationThrottleErrorMsg(true);
			setActivationThrottleErrorMsg(errorMsg);
		}
	}

	/**
	 * Initializes the activation switch checkbox value.
	 * 
	 * @return
	 */
	public void initializedMessage() {
		CustomLogger.enter(this.getClass());

		setShowActivationThrottleInstMsg(true);
		setActivationThrottleInstMsg(
				"Select or unselect the checkbox to activate or deactivate Device Reputation and/or "
						+ "change the dropdowm percentage values to a desired throttle volume.");
	}

	/**
	 * Sends email notifications to admin users when activation switch is changed.
	 * 
	 * @param refSponsorConfig
	 * @param username
	 * @return
	 */
	public void notifyDeviceReputationActivationChange(String username) {
		CustomLogger.enter(this.getClass());

		try {
			adminService.notifyDeviceReputationActivationChange(selectedSponsorId, username);
		} catch (Exception e) {
			String errorMsg = "An error occurred while generating notification email for Device Reputation activation switch change.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setShowActivationThrottleErrorMsg(true);
			setActivationThrottleErrorMsg(errorMsg);
		}
	}

	/******* RpFeaturesAttempts Config *******/

	public void loadFeatAppSelector(ValueChangeEvent vcEvent) {
		CustomLogger.enter(this.getClass());

		selectedFeatSponsorId = ((Long) vcEvent.getNewValue()).longValue();

		if (selectedFeatSponsorId == 0L) {
			return;
		}
		appList = adminService.getAppListBySponsor(selectedFeatSponsorId);

		if (appList == null || appList.isEmpty()) {
			return;
		}

		appNameValueList = new ArrayList<NameValueVo>();
		appNameValueList.add(new NameValueVo("Select an Application", 0L));

		for (RefApp app : appList) {
			appNameValueList.add(new NameValueVo(app.getAppName(), app.getAppId()));
		}

		setShowFeatAppSelector(true);
		this.selectedFeatAppId = 0L;

		setShowFeatConfigTable(false);
		setFeatConfigInstMsg("Select Application of the selected Sponsor.");
		setShowFeatConfigInstMsg(true);
	}

	public void refreshFeatConfig() {
		CustomLogger.enter(this.getClass());

		if (selectedFeatSponsorId == 0L) {
			return;
		}

		loadRpFeaturesAttemptsTable();
		setShowFeatConfigInstMsg(false);

		setShowAddAttemptFeatBtn(false);

		if (featureNameList == null || featureNameList.isEmpty()) {
			setShowAddAttemptFeatBtn(true);
		} else {
			setShowRemoveAttemptFeatBtn(true);
		}

		setShowFeatConfigTable(true);

	}

	public void loadRpFeaturesAttemptsTable() {
		CustomLogger.enter(this.getClass());

		try {
			featureNameList = featureAttemptService.getListByAppId(selectedFeatAppId);

			if (featureNameList == null || featureNameList.isEmpty()) {
				return;
			}
		} catch (Exception e) {
			CustomLogger.error(this.getClass(),
					IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error loading loadRpFeaturesAttempts Table", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	public void addAttemptFeature() {
		CustomLogger.enter(this.getClass());

		setFeatConfigInstMsg("Attempt features rows will be added for the selected application. Are you sure?");
		setShowFeatConfigInstMsg(true);
		setShowConfirmAttemptFeatBtn(true);
		setShowAddAttemptFeatBtn(false);
	}

	public void removeAttemptFeature() {
		CustomLogger.enter(this.getClass());

		setFeatConfigInstMsg("Attempt features rows of the selected application will be removed. Are you sure?");
		setShowFeatConfigInstMsg(true);
		setShowConfirmAttemptFeatBtn(true);
		setShowRemoveAttemptFeatBtn(false);
	}

	public void confirmAttemptFeature() {
		CustomLogger.enter(this.getClass());

		if (featureNameList == null || featureNameList.isEmpty()) {
			RefSponsor refSponsor = refSponsorService.findByPK(selectedFeatSponsorId);
			RefApp refApp = refAppService.findByAppId(selectedFeatAppId);

			featureAttemptService.createRpFeatureAttemptForRemoteClient(refSponsor, refApp);
			featureNameList = featureAttemptService.getListByAppId(selectedFeatAppId);
		} else {
			featureAttemptService.removeRpFeatureAttemptForRemoteClient(selectedFeatSponsorId, selectedFeatAppId);
		}

		loadRpFeaturesAttemptsTable();

		if (featureNameList == null || featureNameList.isEmpty()) {
			setShowAddAttemptFeatBtn(true);
		} else {
			setShowRemoveAttemptFeatBtn(true);
		}

		setShowConfirmAttemptFeatBtn(false);
		setFeatConfigInstMsg("");
		setShowFeatConfigInstMsg(false);

	}

	public void cancelAttemptFeature() {
		CustomLogger.enter(this.getClass());

	}

	/******* Individual-Not-Found Supplier Config *******/

	public void refreshInfSupplierConfig() {
		CustomLogger.enter(this.getClass());

		loadInfSupplierTable(selectedInfSponsorId);

		setInfSupplierPercentageChanged(false);
	}

	/**
	 * Loads and initializes the individual-not-found supplier list table.
	 * 
	 * @param initial boolean value
	 * @return
	 */
	public void loadInfSupplierTable(long selectedInfSponsorId) {
		if (confirmInfSupplierPercentageChange) {
			return;
		}
		try {
			infSupplierConfigList = adminService.retrieveInfPvAttemptConfigList(RefLoaLevel.LOA15_CODE,
					selectedInfSponsorId);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE
					+ "Error loading Supplier List for Individual-Not-Found Admin page", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/**
	 * Checks if the individual-not-found supplier config percentage values are
	 * changed.
	 * 
	 * @return
	 */
	public void changeInfSupplierConfig() {
		CustomLogger.enter(this.getClass());

		infSupplierPercentageChanged = isInfSupplierConfigPercentageChanged();
		setShowInfSupplierConfigInstMsg(true);

		// Remove success message
		setShowInfSupplierConfigSuccessMsg(false);
		setInfSupplierConfigSuccessMsg(null);

		if (infSupplierPercentageChanged) {
			if (checkIfValidInfTotalPercentage()) {
				setInitialInfSupplierConfigButton(false);
				setConfirmInfSupplierConfigChangeBtn(true);
				setConfirmInfSupplierPercentageChange(true);
				setInfSupplierConfigInstMsg(
						"You are changing the Individual-Not-Found Supplier Config percentages.  If this is correct, select Confirm below.");
			} else {
				setShowInfSupplierConfigInstMsg(false);
				setInfSupplierConfigInstMsg(null);
			}
		} else {
			setInfSupplierConfigInstMsg("You have made no changes to save.");

			setShowInfSupplierConfigErrorMsg(false);
			setInfSupplierConfigErrorMsg(null);
		}

		initialized = true;
	}

	/**
	 * Updates individual-not-found supplier config percentage configuration.
	 * 
	 * @return
	 */
	public void saveInfSupplierConfig() {
		if (infSupplierPercentageChanged && checkIfValidInfTotalPercentage()) {
			saveInfSupplierConfigPercentage();
		}
	}

	/**
	 * Reloads the inf supplier config list table, and resets buttons and messages.
	 * 
	 * @return
	 */
	public void cancelInfSupplierConfig() {
		CustomLogger.enter(this.getClass());

		loadInfSupplierTable(selectedInfSponsorId);
		resetInfSupplierConfigListPercentages();
		resetInfSupplierConfigButtons(true);
	}

	/**
	 * Checks if the inf supplier config percentage values were changed.
	 * 
	 * @return
	 */
	private boolean isInfSupplierConfigPercentageChanged() {
		CustomLogger.enter(this.getClass());

		StringBuilder oldValuesSb = new StringBuilder();
		StringBuilder newValuesSb = new StringBuilder();

		for (OtpConfigVo vo : infSupplierConfigList) {
			oldValuesSb.append(vo.getTotalAttempts());
			newValuesSb.append(vo.getNewPercentage());
		}

		if ("00".equals(newValuesSb.toString())) {
			return false;
		}

		return !oldValuesSb.toString().equalsIgnoreCase(newValuesSb.toString());
	}

	/**
	 * Implements the isValidInfTotalPercentage method then displays the error
	 * message if needed
	 * 
	 * @return
	 */
	private boolean checkIfValidInfTotalPercentage() {
		if (isValidInfTotalPercentage()) {
			setShowInfSupplierConfigErrorMsg(false);
			setInfSupplierConfigErrorMsg(null);

			return true;
		} else {
			setShowInfSupplierConfigErrorMsg(true);
			setInfSupplierConfigErrorMsg("Percentages must equal 100%!");

			return false;
		}
	}

	/**
	 * Checks if the total configuration percentage of the Supplier Traffic for
	 * Individual Not Found is equal to 100
	 * 
	 * @return
	 */
	private boolean isValidInfTotalPercentage() {
		CustomLogger.enter(this.getClass());
		int count = 0;
		for (OtpConfigVo infSupplierConfig : infSupplierConfigList) {
			count += infSupplierConfig.getNewPercentage();
		}

		return count == 100;
	}

	/**
	 * Updates inf supplier config values, RpAdmin for logging admin user events and
	 * sends email notifications to admin users.
	 * 
	 * @return
	 */
	public void saveInfSupplierConfigPercentage() {
		setShowInfSupplierConfigSuccessMsg(false);
		setConfirmInfSupplierPercentageChange(false);
		setShowInfSupplierConfigErrorMsg(false);

		try {
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();
			String username = (String) request.getSession().getAttribute(IVS_TOKEN);

			if (Utils.isAlphanumeric(username)) {
				adminService.changeInfPvAttemptConfig(infSupplierConfigList, username, RefLoaLevel.LOA15_CODE,
						selectedInfSponsorId, adminService.isLocalServer());
				infSupplierConfigList = adminService.retrieveInfPvAttemptConfigList(RefLoaLevel.LOA15_CODE,
						selectedInfSponsorId);

				for (OtpConfigVo otpConfigVo : infSupplierConfigList) {
					otpConfigVo.setPercentage(String.valueOf(otpConfigVo.getTotalAttempts()));
				}

				setShowInfSupplierConfigSuccessMsg(true);
				setInfSupplierConfigSuccessMsg(SUCCESS_MSG);
				setInitialInfSupplierConfigButton(true);
			} else {
				CustomLogger.warn(this.getClass(),
						"WARNING: Invalid user name supplied, INF supplier config not updated: " + username);
			}

			resetInfSupplierConfigListPercentages();

			loadInfSupplierTable(selectedInfSponsorId);
			resetInfSupplierConfigButtons(false);

			notifyInfSupplierConfigChange(selectedInfSponsorId, username);
		} catch (Exception e) {
			setShowInfSupplierConfigSuccessMsg(false);
			String errorMsg = "Error trying to change INF supplier config percentages.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setShowInfSupplierConfigErrorMsg(true);
			setInfSupplierConfigErrorMsg(errorMsg);
		}
	}

	/**
	 * Resets the inf supplier config percentage list values back to zeros.
	 * 
	 * @return
	 */
	private void resetInfSupplierConfigListPercentages() {
		CustomLogger.enter(this.getClass());

		for (OtpConfigVo otpConfigVo : infSupplierConfigList) {
			otpConfigVo.setNewPercentage(0);
		}
	}

	/**
	 * Resets buttons and messages for INF supplier config.
	 * 
	 * @return
	 */
	private void resetInfSupplierConfigButtons(boolean initial) {
		setInitialInfSupplierConfigButton(true);
		setConfirmInfSupplierConfigChangeBtn(false);
		setConfirmInfSupplierPercentageChange(false);
		setShowInfSupplierConfigErrorMsg(false);
		setShowInfSupplierConfigInstMsg(false);
		setInfSupplierConfigInstMsg(null);
		setShowInfSupplierConfigSuccessMsg(!initial);
	}

	/**
	 * Sends email notifications to admin users when INF supplier config percentage
	 * value is changed.
	 * 
	 * @param refSponsorConfig
	 * @param username
	 * @return
	 */
	public void notifyInfSupplierConfigChange(long sponsorId, String username) {
		CustomLogger.enter(this.getClass());

		try {
			RefSponsor refSponsor = refSponsorService.findByPK(sponsorId);
			if (refSponsor != null) {
				String sponsorName = refSponsor.getSponsorName();
				String appName = "Informed Delivery";
				
				if ("Change of Address".equalsIgnoreCase(sponsorName) || "Operation Santa".equalsIgnoreCase(sponsorName)) {
					appName = sponsorName;
					RefApp refApp = refAppService.findByAppName(appName);
					
					if (refApp != null) {
						long appId = refApp.getAppId();
						adminService.notifyInfSupplierConfigChange(sponsorId, appId, username);  
					}
				}
			}
			
		} catch (Exception e) {
			String errorMsg = "An error occurred while generating notification email for Individual-Not-Found supplier config change.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setShowInfSupplierConfigErrorMsg(true);
			setInfSupplierConfigErrorMsg(errorMsg);
			setShowInfSupplierConfigSuccessMsg(false);
		}
	}

	/**
	 * Sends email notifications to admin users when velocity timer value is
	 * changed.
	 * 
	 * @param refSponsorConfig
	 * @param username
	 * @return
	 */
	public void notifyVelocityTimerChange() {
		CustomLogger.enter(this.getClass());

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
				.getRequest();
		String username = (String) request.getSession().getAttribute(IVS_TOKEN);

		try {
			adminService.notifyVelocityTimerValueChange(CUST_REG_SPONSOR_ID, username);
		} catch (Exception e) {
			String errorMsg = "An error occurred while generating notification email for Velocity Timer value update.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setVelocityTimerErrorPanel(errorMsg);
		}
	}

	/******* Percentage Change *******/

	/**
	 * Loads and initializes the feature attempts table.
	 * 
	 * @param initial boolean value
	 * @return
	 */
	public void loadFeatureTable() {
		CustomLogger.enter(this.getClass());

		if (confirmPercentageChange) {
			return;
		}

		try {
			featureNameList = featureAttemptService.getListByAppId(selectedAppId);

			if (featureNameList == null || featureNameList.isEmpty()) {
				RefSponsor refSponsor = refSponsorService.findByPK(selectedSponsorId);
				RefApp refApp = refAppService.findByAppId(selectedAppId);

				featureAttemptService.createRpFeatureAttemptForRemoteClient(refSponsor, refApp);
				featureNameList = featureAttemptService.getListByAppId(selectedAppId);
			}

			detemineActiveStatus(featureNameList, selectedSponsorId);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE
					+ "Error loading Device Reputation Volume Throttle Admin page", e);
			goToPage(SYSTEM_ERROR_PAGE);
		}
	}

	/**
	 * Updates RpFeatureAttempt totalAttempts values, RpAdmin for logging admin user
	 * events and sends email notifications to admin users.
	 * 
	 * @return
	 */
	public void savePercentage() {
		CustomLogger.enter(this.getClass());

		setShowActivationThrottleSuccessMsg(false);
		setConfirmPercentageChange(false);
		setShowActivationThrottleErrorMsg(false);

		try {
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
					.getRequest();
			String username = (String) request.getSession().getAttribute(IVS_TOKEN);

			if (Utils.isAlphanumeric(username)) {
				featureAttemptService.updateTotalAttempts(featureNameList, username);
				setShowActivationThrottleSuccessMsg(true);
				setActivationThrottleSuccessMsg(SUCCESS_MSG);
				setInitialActivationThrottleButton(true);
			} else {
				CustomLogger.warn(this.getClass(),
						"WARNING: Invalid user name supplied, rp_features_attempts table not updated: " + username);
			}

			resetListPercentages();

			initializedMessage();
			loadFeatureTable();
			resetButtons(false);

			notifyDeviceReputationThrottleChange(this.selectedSponsorId, this.selectedAppId, username);
		} catch (Exception e) {
			setShowActivationThrottleSuccessMsg(false);
			String errorMsg = "Error trying to change Device Reputation volume throttle percentages.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setShowActivationThrottleErrorMsg(true);
			setActivationThrottleErrorMsg(errorMsg);
		}
	}

	/**
	 * Resets the volume throttle percentage values back to zeros.
	 * 
	 * @return
	 */
	public void cancelPercentageChange() {
		CustomLogger.enter(this.getClass());

		clearPercentageSaveError();
		initializedMessage();
		loadFeatureTable();
		resetButtons(true);
	}

	/**
	 * Resets the buttons and messages display.
	 * 
	 * @return
	 */
	public void resetButtonsMessages() {
		CustomLogger.enter(this.getClass());

		resetButtons(true);
	}

	/**
	 * Clears the message errors displayed when error occurred in saving total
	 * attempts.
	 * 
	 * @return
	 */
	private void clearPercentageSaveError() {
		setShowActivationThrottleSuccessMsg(false);
		setShowActivationThrottleErrorMsg(false);
		setConfirmPercentageChange(false);
	}

	/**
	 * Assigned dropdown list values to automatically set the total of 100%..
	 * 
	 * @param featureId
	 * @return
	 */
	public void onPercentageValueChange(long featureId) {
		CustomLogger.enter(this.getClass());

		RpFeatureAttempt featAttempt = featureNameList.stream().filter(attempt -> attempt.getFeatureId() == featureId)
				.findFirst().orElse(null);

		int thisNewTotalAttempts = 0;

		if (featAttempt != null) {
			thisNewTotalAttempts = featAttempt.getNewTotalAttempts();
		}

		int otherNewTotalAttempts = 100 - thisNewTotalAttempts;

		for (RpFeatureAttempt att : featureNameList) {
			if (att.getFeatureId() != featureId) {
				att.setNewTotalAttempts(otherNewTotalAttempts);
			}
		}
	}

	/**
	 * Resets the attempts percentage list values back to zeros.
	 * 
	 * @return
	 */
	private void resetListPercentages() {
		CustomLogger.enter(this.getClass());

		for (RpFeatureAttempt att : featureNameList) {
			att.setNewTotalAttempts(0);
		}
	}

	/**
	 * Sends email notifications to admin users when volume throttle percentage
	 * value is changed.
	 * 
	 * @param refSponsorConfig
	 * @param selectedAppId
	 * @param username
	 * @return
	 */
	public void notifyDeviceReputationThrottleChange(long sponsorId, Long selectedAppId, String username) {
		CustomLogger.enter(this.getClass());

		try {
			adminService.notifyDeviceReputationThrottleChange(sponsorId, selectedAppId, username);
		} catch (Exception e) {
			String errorMsg = "An error occurred while generating notification email for Device Reputation percentage change.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setShowActivationThrottleErrorMsg(true);
			setActivationThrottleErrorMsg(errorMsg);
			setShowActivationThrottleSuccessMsg(false);
		}
	}

	/**
	 * Checks if the volume throttle percentage values were changed.
	 * 
	 * @return
	 */
	private boolean isPercentageChanged() {
		CustomLogger.enter(this.getClass());

		StringBuilder oldValuesSb = new StringBuilder();
		StringBuilder newValuesSb = new StringBuilder();

		for (RpFeatureAttempt att : featureNameList) {
			oldValuesSb.append(att.getTotalAttempts());
			newValuesSb.append(att.getNewTotalAttempts());
		}

		if ("00".equals(newValuesSb.toString())) {
			return false;
		}

		return !oldValuesSb.toString().equalsIgnoreCase(newValuesSb.toString());
	}

	/******* Velocity Timer Methods *******/

	public void initVelocityTimerConfigControls() {
		CustomLogger.enter(this.getClass());

		int sponsorIdInt = Integer.parseInt(String.valueOf(CUST_REG_SPONSOR_ID));
		velocitySponsorConfig = adminService.getRefSponsorConfiguration(sponsorIdInt,
				RefSponsorConfiguration.DEVICE_VELOCITY_TIMER);
		setVelocityTimerValue(velocitySponsorConfig.getValue());

		setVelocityTimerInfoPanel("Change the value to a desired velocity timer in minutes.");

		setShowVelocityTimerChangeBtn(true);
		setShowVelocityTimerConfirmBtn(false);
		setShowVelocityTimerCancelBtn(false);
	}

	public void refreshVelocityTimer() {
		CustomLogger.enter(this.getClass());

		int sponsorIdInt = Integer.parseInt(String.valueOf(selectedVelocityTimerSponsorId));
		velocitySponsorConfig = adminService.getRefSponsorConfiguration(sponsorIdInt,
				RefSponsorConfiguration.DEVICE_VELOCITY_TIMER);
		setVelocityTimerValue(velocitySponsorConfig.getValue());
	}

	/**
	 * Prompts the confirmation message before the actual save.
	 * 
	 * @return
	 */
	public void changeVelocityTimer() {
		CustomLogger.enter(this.getClass());

		setVelocityTimerInfoPanel(
				"You are changing the velocity timer value.  If this is correct, select Confirm below.");

		setShowVelocityTimerChangeBtn(false);
		setShowVelocityTimerConfirmBtn(true);
		setShowVelocityTimerCancelBtn(false);
	}

	/**
	 * Confirms and saves the velocity timer value to the sponsor configuration
	 * table.
	 * 
	 * @return
	 */
	public void saveVelocityTimer() {
		CustomLogger.enter(this.getClass());

		boolean validTimerValue = false;

		if (StringUtils.isEmpty(velocityTimerValue)) {
			setVelocityTimerErrorPanel("Velocity timer value is empty.");
		} else if (!StringUtils.isNumeric(velocityTimerValue)) {
			setShowVelocityTimerErrorMsg(true);
			setVelocityTimerErrorPanel("Velocity timer value is not numeric.");
		} else {
			int intValue = Integer.parseInt(velocityTimerValue);
			if (intValue < 0 || intValue > 1440) {
				setVelocityTimerErrorPanel("Velocity timer has invalid value.");
			} else {
				validTimerValue = true;
			}
		}

		if (!validTimerValue) {
			return;
		}

		int sponsorIdInt = Integer.parseInt(String.valueOf(selectedVelocityTimerSponsorId));
		velocitySponsorConfig = adminService.getRefSponsorConfiguration(sponsorIdInt,
				RefSponsorConfiguration.DEVICE_VELOCITY_TIMER);

		try {
			velocitySponsorConfig.setValue(velocityTimerValue);
			adminService.updateRefSponsorConfiguration(velocitySponsorConfig);
		} catch (Exception e) {
			String errorMsg = "Exception occurred in saving velocity timer value.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setVelocityTimerErrorPanel(errorMsg);
			return;
		}

		notifyVelocityTimerChange();
		setVelocityTimerSuccessPanel("Saving velocity timer value successful.");

		setShowVelocityTimerChangeBtn(true);
		setShowVelocityTimerConfirmBtn(false);
		setShowVelocityTimerCancelBtn(true);
	}

	/**
	 * Cancels the confirmation.
	 * 
	 * @return
	 */
	public void cancelVelocityTimer() {
		CustomLogger.enter(this.getClass());

		setShowVelocityTimerChangeBtn(true);
		setShowVelocityTimerConfirmBtn(false);
		setShowVelocityTimerCancelBtn(false);
	}

	private void setShowVelocityTimerChangeMsg(String messageType) {
		CustomLogger.enter(this.getClass());

		boolean showInstMsg = false;
		boolean showErrorMsg = false;
		boolean showSuccessMsg = false;

		switch (messageType) {
		case MESSAGE_TYPE_SUCCESS:
			showSuccessMsg = true;
			break;
		case MESSAGE_TYPE_INFO:
			showInstMsg = true;
			break;
		case MESSAGE_TYPE_ERROR:
			showErrorMsg = true;
			break;
		default:
		}
		setShowVelocityTimerInstMsg(showInstMsg);
		setShowVelocityTimerErrorMsg(showErrorMsg);
		setShowVelocityTimerSuccessMsg(showSuccessMsg);
	}

	private void setVelocityTimerInfoPanel(String message) {
		CustomLogger.enter(this.getClass());

		setVelocityTimerErrorMsg(message);
		setShowVelocityTimerChangeMsg(MESSAGE_TYPE_INFO);
	}

	private void setVelocityTimerSuccessPanel(String message) {
		CustomLogger.enter(this.getClass());

		setVelocityTimerSuccessMsg(message);
		setShowVelocityTimerChangeMsg(MESSAGE_TYPE_SUCCESS);
	}

	private void setVelocityTimerErrorPanel(String message) {
		CustomLogger.enter(this.getClass());

		setVelocityTimerErrorMsg(message);
		setShowVelocityTimerChangeMsg(MESSAGE_TYPE_ERROR);
	}

	/******* Methods for Diagnostics/Testing Tool *******/

	private void detemineActiveStatus(List<RpFeatureAttempt> featureNameList, long selectedSponsorId) {
		CustomLogger.enter(this.getClass());

		boolean enabledAttemptsMaxed = false;
		boolean disabledAttemptsMaxed = false;
		boolean enabledDevRep = false;
		boolean enabledDevRepFixed = false;
		boolean disabledDevRepFixed = false;
		boolean enabledInitialized = false;
		boolean disabledInitialized = false;
		int moreAttempts = 0;
		String nextStatus = "";
		String enabledText = "enabled";
		String disabledText = "disabled/skipped";

		RpFeatureAttempt enabledFeature = null;
		RpFeatureAttempt disabledFeature = null;

		for (RpFeatureAttempt feature : featureNameList) {
			if ("Device Reputation".equalsIgnoreCase(feature.getFeatureName())) {
				enabledFeature = feature;
			} else {
				disabledFeature = feature;
			}
		}

		// Enabled Scenarios
		if (enabledFeature.getTotalAttempts() == 100) {
			// 100% Enabled
			enabledDevRepFixed = true;
			nextStatus = enabledText;
		} else if (enabledFeature.getAttempts() == 0 && disabledFeature != null && disabledFeature.getAttempts() == 0) {
			// Both Initialized. Enabled feature will be next.
			moreAttempts = enabledFeature.getTotalAttempts() + 1;
			nextStatus = disabledText;
		} else if ((enabledFeature.getTotalAttempts() == enabledFeature.getAttempts())
				&& (disabledFeature != null && (disabledFeature.getTotalAttempts() == disabledFeature.getAttempts()))) {
			// Both maxed out. Enabled feature will be next.
			moreAttempts = 1;
			nextStatus = enabledText;
		} else if (enabledFeature.getAttempts() > 0 && (disabledFeature != null && (disabledFeature.getAttempts() == 0
				|| (disabledFeature.getTotalAttempts() == disabledFeature.getAttempts())))) {
			// Enabled feature attempt is incrementing
			moreAttempts = (enabledFeature.getTotalAttempts() - enabledFeature.getAttempts()) + 1;
			nextStatus = disabledText;
		}
		// Disabled Scenarios
		else if (disabledFeature != null && disabledFeature.getTotalAttempts() == 100) {
			// 100% Disabled
			disabledDevRepFixed = true;
			nextStatus = disabledText;
		} else if (disabledFeature != null && disabledFeature.getAttempts() > 0 && (enabledFeature.getAttempts() == 0
				|| (enabledFeature.getTotalAttempts() == enabledFeature.getAttempts()))) {
			// Disabled feature attempt is incrementing
			moreAttempts = (disabledFeature.getTotalAttempts() - disabledFeature.getAttempts()) + 1;
			nextStatus = enabledText;
		}

		if (enabledDevRepFixed || disabledDevRepFixed) {
			featureStatusMsg = String.format("Device Reputation is always %s.", nextStatus);
		} else {
			featureStatusMsg = String.format("Device Reputation is %s after %s attempts.", nextStatus, moreAttempts);
		}

		String environment = Utils.getEnvironmentWithoutDot();
		setReportRunDate(new Date());
		setRenderReportSection(!"prod".equalsIgnoreCase(environment));
	}

	public void runReport() {
		CustomLogger.enter(this.getClass());

		boolean isReportRunDateNull = reportRunDate == null;
		setCalendarSelectErrorMsg(false);
		if (isReportRunDateNull) {
			setCalendarSelectErrorMsg(true);

			return;
		}

		try {
			userAttemptList = deviceReputationService.getDeviceReputationReport(reportRunDate);
		} catch (Exception e) {
			String errorMsg = "Error in getting  DeviceReputationReport item list.";
			CustomLogger.error(this.getClass(), errorMsg, e);
			setVelocityTimerErrorPanel(errorMsg);
		}
	}

	public void runAddToBlacklistJob() {
		CustomLogger.enter(this.getClass());

		try {
			truthDataSendEmailService.addFraudEmailToBlackList();
		} catch (Exception e) {
			String errorMsg = "Error in running AddToBlacklistJob.";
			CustomLogger.error(this.getClass(), errorMsg, e);
		}
	}

	public void resetTruthDataSendEmail() {
		CustomLogger.enter(this.getClass());

		try {
			if (!StringUtils.isEmpty(truthDataSendEmailId) && StringUtils.isNumeric(truthDataSendEmailId)) {
				long longValue = Long.parseLong(truthDataSendEmailId);
				if (longValue > 0L) {
					truthDataSendEmailService.resetTruthDataSendEmail(longValue);
				}
			}
		} catch (Exception e) {
			String errorMsg = "Error in resetting TruthDataSEndEmail.";
			CustomLogger.error(this.getClass(), errorMsg, e);
		}
	}

	public void addTruthDataSendEmail() {
		CustomLogger.enter(this.getClass());

		try {
			if (!StringUtils.isEmpty(truthDataSendEmailAddress)) {
				truthDataSendEmailService.addTruthDataSendEmail(truthDataSendEmailAddress);
			}
		} catch (Exception e) {
			String errorMsg = "Error in adding TruthDataSEndEmail record.";
			CustomLogger.error(this.getClass(), errorMsg, e);
		}
	}

	/******* ThreatMetrix Threshold Portal Link *******/

	public String getThresholdConfigPortalUrl() {
		return THRESHOLD_CONFIG_PORTAL_URL;
	}

	/**
	 * Clears the error messages.
	 * 
	 * @return
	 */
	private void clear() {
		CustomLogger.enter(this.getClass());
		setShowActivationThrottleErrorMsg(false);
		setShowActivationThrottleSuccessMsg(false);
		setShowActivationThrottleInstMsg(false);
		setConfirmPercentageChange(false);
	}

	public void setRefSponsorConfigService(RefSponsorConfigurationService refSponsorConfigService) {
		this.refSponsorConfigService = refSponsorConfigService;
	}

	public AdminService getAdminService() {
		return adminService;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	public RpFeatureAttemptService getFeatureAttemptService() {
		return featureAttemptService;
	}

	public void setFeatureAttemptService(RpFeatureAttemptService featureAttemptService) {
		this.featureAttemptService = featureAttemptService;
	}

	public RefSponsorDataService getRefSponsorService() {
		return refSponsorService;
	}

	public void setRefSponsorService(RefSponsorDataService refSponsorService) {
		this.refSponsorService = refSponsorService;
	}

	public List<SponsorConfigVo> getConfigVoList() {
		return configVoList;
	}

	public void setConfigVoList(List<SponsorConfigVo> configVoList) {
		this.configVoList = configVoList;
	}

	public List<RpFeatureAttempt> getFeatureNameList() {
		return featureNameList;
	}

	public void setFeatureNameList(List<RpFeatureAttempt> featureNameList) {
		this.featureNameList = featureNameList;
	}

	public List<RefSponsorConfiguration> getSponsorConfigList() {
		return sponsorConfigList;
	}

	public void setSponsorConfigList(List<RefSponsorConfiguration> sponsorConfigList) {
		this.sponsorConfigList = sponsorConfigList;
	}

	public RefSponsorConfiguration getVelocitySponsorConfig() {
		return velocitySponsorConfig;
	}

	public void setVelocitySponsorConfig(RefSponsorConfiguration velocitySponsorConfig) {
		this.velocitySponsorConfig = velocitySponsorConfig;
	}

	public int[] getPercentages() {
		return percentages;
	}

	public void setPercentages(int[] percentages) {
		this.percentages = percentages;
	}

	public boolean isConfirmChangeBtn() {
		return confirmChangeBtn;
	}

	public void setConfirmChangeBtn(boolean confirmChangeBtn) {
		this.confirmChangeBtn = confirmChangeBtn;
	}

	public boolean isConfirmPercentageChange() {
		return confirmPercentageChange;
	}

	public void setConfirmPercentageChange(boolean confirmPercentageChange) {
		this.confirmPercentageChange = confirmPercentageChange;
	}

	public boolean isInitialActivationThrottleButton() {
		return initialActivationThrottleButton;
	}

	public void setInitialActivationThrottleButton(boolean initialActivationThrottleButton) {
		this.initialActivationThrottleButton = initialActivationThrottleButton;
	}

	public String getActivationThrottleInstMsg() {
		return activationThrottleInstMsg;
	}

	public void setActivationThrottleInstMsg(String activationThrottleInstMsg) {
		this.activationThrottleInstMsg = activationThrottleInstMsg;
	}

	public void setActivationChanged(boolean activationChanged) {
		this.activationChanged = activationChanged;
	}

	public String getActivationThrottleErrorMsg() {
		return activationThrottleErrorMsg;
	}

	public void setActivationThrottleErrorMsg(String activationThrottleErrorMsg) {
		this.activationThrottleErrorMsg = activationThrottleErrorMsg;
	}

	public String getActivationThrottleSuccessMsg() {
		return activationThrottleSuccessMsg;
	}

	public void setActivationThrottleSuccessMsg(String activationThrottleSuccessMsg) {
		this.activationThrottleSuccessMsg = activationThrottleSuccessMsg;
	}

	public void setPercentageChanged(boolean percentageChanged) {
		this.percentageChanged = percentageChanged;
	}

	public String getFeatureStatusMsg() {
		return featureStatusMsg;
	}

	public void setFeatureStatusMsg(String featureStatusMsg) {
		this.featureStatusMsg = featureStatusMsg;
	}

	public Date getReportRunDate() {
		return reportRunDate;
	}

	public void setReportRunDate(Date reportRunDate) {
		this.reportRunDate = reportRunDate;
	}

	public List<DeviceReputationVo> getUserAttemptList() {
		return userAttemptList;
	}

	public void setUserAttemptList(List<DeviceReputationVo> userAttemptList) {
		this.userAttemptList = userAttemptList;
	}

	public boolean isCalendarSelectErrorMsg() {
		return calendarSelectErrorMsg;
	}

	public void setCalendarSelectErrorMsg(boolean calendarSelectErrorMsg) {
		this.calendarSelectErrorMsg = calendarSelectErrorMsg;
	}

	public boolean isRenderReportSection() {
		return renderReportSection;
	}

	public void setRenderReportSection(boolean renderReportSection) {
		this.renderReportSection = renderReportSection;
	}

	public boolean isShowActivationThrottleInstMsg() {
		return showActivationThrottleInstMsg;
	}

	public void setShowActivationThrottleInstMsg(boolean showActivationThrottleInstMsg) {
		this.showActivationThrottleInstMsg = showActivationThrottleInstMsg;
	}

	public boolean isShowActivationThrottleErrorMsg() {
		return showActivationThrottleErrorMsg;
	}

	public void setShowActivationThrottleErrorMsg(boolean showActivationThrottleErrorMsg) {
		this.showActivationThrottleErrorMsg = showActivationThrottleErrorMsg;
	}

	public boolean isShowActivationThrottleSuccessMsg() {
		return showActivationThrottleSuccessMsg;
	}

	public void setShowActivationThrottleSuccessMsg(boolean showActivationThrottleSuccessMsg) {
		this.showActivationThrottleSuccessMsg = showActivationThrottleSuccessMsg;
	}

	public boolean isShowVelocityTimerInstMsg() {
		return showVelocityTimerInstMsg;
	}

	public void setShowVelocityTimerInstMsg(boolean showVelocityTimerInstMsg) {
		this.showVelocityTimerInstMsg = showVelocityTimerInstMsg;
	}

	public boolean isShowVelocityTimerErrorMsg() {
		return showVelocityTimerErrorMsg;
	}

	public void setShowVelocityTimerErrorMsg(boolean showVelocityTimerErrorMsg) {
		this.showVelocityTimerErrorMsg = showVelocityTimerErrorMsg;
	}

	public boolean isShowVelocityTimerSuccessMsg() {
		return showVelocityTimerSuccessMsg;
	}

	public void setShowVelocityTimerSuccessMsg(boolean showVelocityTimerSuccessMsg) {
		this.showVelocityTimerSuccessMsg = showVelocityTimerSuccessMsg;
	}

	public boolean isShowVelocityTimerChangeBtn() {
		return showVelocityTimerChangeBtn;
	}

	public void setShowVelocityTimerChangeBtn(boolean showVelocityTimerChangeBtn) {
		this.showVelocityTimerChangeBtn = showVelocityTimerChangeBtn;
	}

	public boolean isShowVelocityTimerConfirmBtn() {
		return showVelocityTimerConfirmBtn;
	}

	public void setShowVelocityTimerConfirmBtn(boolean showVelocityTimerConfirmBtn) {
		this.showVelocityTimerConfirmBtn = showVelocityTimerConfirmBtn;
	}

	public boolean isShowVelocityTimerCancelBtn() {
		return showVelocityTimerCancelBtn;
	}

	public void setShowVelocityTimerCancelBtn(boolean showVelocityTimerCancelBtn) {
		this.showVelocityTimerCancelBtn = showVelocityTimerCancelBtn;
	}

	public String getVelocityTimerValue() {
		return velocityTimerValue;
	}

	public void setVelocityTimerValue(String velocityTimerValue) {
		this.velocityTimerValue = velocityTimerValue;
	}

	public String getVelocityTimerInstMsg() {
		return velocityTimerInstMsg;
	}

	public void setVelocityTimerInstMsg(String velocityTimerInstMsg) {
		this.velocityTimerInstMsg = velocityTimerInstMsg;
	}

	public String getVelocityTimerErrorMsg() {
		return velocityTimerErrorMsg;
	}

	public void setVelocityTimerErrorMsg(String velocityTimerErrorMsg) {
		this.velocityTimerErrorMsg = velocityTimerErrorMsg;
	}

	public String getVelocityTimerSuccessMsg() {
		return velocityTimerSuccessMsg;
	}

	public void setVelocityTimerSuccessMsg(String velocityTimerSuccessMsg) {
		this.velocityTimerSuccessMsg = velocityTimerSuccessMsg;
	}

	public String getTruthDataSendEmailId() {
		return truthDataSendEmailId;
	}

	public void setTruthDataSendEmailId(String truthDataSendEmailId) {
		this.truthDataSendEmailId = truthDataSendEmailId;
	}

	public String getTruthDataSendEmailAddress() {
		return truthDataSendEmailAddress;
	}

	public void setTruthDataSendEmailAddress(String truthDataSendEmailAddress) {
		this.truthDataSendEmailAddress = truthDataSendEmailAddress;
	}

	public Long getSelectedSponsorId() {
		return selectedSponsorId;
	}

	public void setSelectedSponsorId(Long selectedSponsorId) {
		this.selectedSponsorId = selectedSponsorId;
	}

	public Long getSelectedVelocityTimerSponsorId() {
		return selectedVelocityTimerSponsorId;
	}

	public void setSelectedVelocityTimerSponsorId(Long selectedVelocityTimerSponsorId) {
		this.selectedVelocityTimerSponsorId = selectedVelocityTimerSponsorId;
	}

	public List<RefSponsor> getSponsorList() {
		return sponsorList;
	}

	public void setSponsorList(List<RefSponsor> sponsorList) {
		this.sponsorList = sponsorList;
	}

	public RefAppService getRefAppService() {
		return refAppService;
	}

	public void setRefAppService(RefAppService refAppService) {
		this.refAppService = refAppService;
	}

	public DeviceReputationService getDeviceReputationService() {
		return deviceReputationService;
	}

	public void setDeviceReputationService(DeviceReputationService deviceReputationService) {
		this.deviceReputationService = deviceReputationService;
	}

	public TruthDataReturnService getTruthDataSendEmailService() {
		return truthDataSendEmailService;
	}

	public void setTruthDataSendEmailService(TruthDataReturnService truthDataSendEmailService) {
		this.truthDataSendEmailService = truthDataSendEmailService;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public boolean isShowInfSupplierConfigInstMsg() {
		return showInfSupplierConfigInstMsg;
	}

	public void setShowInfSupplierConfigInstMsg(boolean showInfSupplierConfigInstMsg) {
		this.showInfSupplierConfigInstMsg = showInfSupplierConfigInstMsg;
	}

	public boolean isShowInfSupplierConfigErrorMsg() {
		return showInfSupplierConfigErrorMsg;
	}

	public void setShowInfSupplierConfigErrorMsg(boolean showInfSupplierConfigErrorMsg) {
		this.showInfSupplierConfigErrorMsg = showInfSupplierConfigErrorMsg;
	}

	public boolean isShowInfSupplierConfigSuccessMsg() {
		return showInfSupplierConfigSuccessMsg;
	}

	public void setShowInfSupplierConfigSuccessMsg(boolean showInfSupplierConfigSuccessMsg) {
		this.showInfSupplierConfigSuccessMsg = showInfSupplierConfigSuccessMsg;
	}

	public String getInfSupplierConfigInstMsg() {
		return infSupplierConfigInstMsg;
	}

	public void setInfSupplierConfigInstMsg(String infSupplierConfigInstMsg) {
		this.infSupplierConfigInstMsg = infSupplierConfigInstMsg;
	}

	public String getInfSupplierConfigErrorMsg() {
		return infSupplierConfigErrorMsg;
	}

	public void setInfSupplierConfigErrorMsg(String infSupplierConfigErrorMsg) {
		this.infSupplierConfigErrorMsg = infSupplierConfigErrorMsg;
	}

	public String getInfSupplierConfigSuccessMsg() {
		return infSupplierConfigSuccessMsg;
	}

	public void setInfSupplierConfigSuccessMsg(String infSupplierConfigSuccessMsg) {
		this.infSupplierConfigSuccessMsg = infSupplierConfigSuccessMsg;
	}

	public Long getSelectedInfSponsorId() {
		return selectedInfSponsorId;
	}

	public void setSelectedInfSponsorId(Long selectedInfSponsorId) {
		this.selectedInfSponsorId = selectedInfSponsorId;
	}

	public boolean isInfSupplierPercentageChanged() {
		return infSupplierPercentageChanged;
	}

	public void setInfSupplierPercentageChanged(boolean infSupplierPercentageChanged) {
		this.infSupplierPercentageChanged = infSupplierPercentageChanged;
	}

	public boolean isConfirmInfSupplierPercentageChange() {
		return confirmInfSupplierPercentageChange;
	}

	public void setConfirmInfSupplierPercentageChange(boolean confirmInfSupplierPercentageChange) {
		this.confirmInfSupplierPercentageChange = confirmInfSupplierPercentageChange;
	}

	public List<OtpConfigVo> getInfSupplierConfigList() {
		return infSupplierConfigList;
	}

	public void setInfSupplierConfigList(List<OtpConfigVo> infSupplierConfigList) {
		this.infSupplierConfigList = infSupplierConfigList;
	}

	public boolean isInitialInfSupplierConfigButton() {
		return initialInfSupplierConfigButton;
	}

	public void setInitialInfSupplierConfigButton(boolean initialInfSupplierConfigButton) {
		this.initialInfSupplierConfigButton = initialInfSupplierConfigButton;
	}

	public boolean isConfirmInfSupplierConfigChangeBtn() {
		return confirmInfSupplierConfigChangeBtn;
	}

	public void setConfirmInfSupplierConfigChangeBtn(boolean confirmInfSupplierConfigChangeBtn) {
		this.confirmInfSupplierConfigChangeBtn = confirmInfSupplierConfigChangeBtn;
	}

	public List<RefApp> getAppList() {
		return appList;
	}

	public void setAppList(List<RefApp> appList) {
		this.appList = appList;
	}

	public Long getSelectedAppId() {
		return selectedAppId;
	}

	public void setSelectedAppId(Long selectedAppId) {
		this.selectedAppId = selectedAppId;
	}

	public boolean isShowActivationTable() {
		return showActivationTable;
	}

	public void setShowActivationTable(boolean showActivationTable) {
		this.showActivationTable = showActivationTable;
	}

	public SponsorApplicationMapService getSponsorApplicationMapService() {
		return sponsorApplicationMapService;
	}

	public void setSponsorApplicationMapService(SponsorApplicationMapService sponsorApplicationMapService) {
		this.sponsorApplicationMapService = sponsorApplicationMapService;
	}

	public List<NameValueVo> getAppNameValueList() {
		return appNameValueList;
	}

	public void setAppNameValueList(List<NameValueVo> appNameValueList) {
		this.appNameValueList = appNameValueList;
	}

	public boolean isShowAppSelector() {
		return showAppSelector;
	}

	public void setShowAppSelector(boolean showAppSelector) {
		this.showAppSelector = showAppSelector;
	}

	public boolean isShowFeatConfigInstMsg() {
		return showFeatConfigInstMsg;
	}

	public void setShowFeatConfigInstMsg(boolean showFeatConfigInstMsg) {
		this.showFeatConfigInstMsg = showFeatConfigInstMsg;
	}

	public boolean isShowFeatConfigErrorMsg() {
		return showFeatConfigErrorMsg;
	}

	public void setShowFeatConfigErrorMsg(boolean showFeatConfigErrorMsg) {
		this.showFeatConfigErrorMsg = showFeatConfigErrorMsg;
	}

	public boolean isShowFeatConfigSuccessMsg() {
		return showFeatConfigSuccessMsg;
	}

	public void setShowFeatConfigSuccessMsg(boolean showFeatConfigSuccessMsg) {
		this.showFeatConfigSuccessMsg = showFeatConfigSuccessMsg;
	}

	public boolean isShowFeatConfigTable() {
		return showFeatConfigTable;
	}

	public void setShowFeatConfigTable(boolean showFeatConfigTable) {
		this.showFeatConfigTable = showFeatConfigTable;
	}

	public String getFeatConfigInstMsg() {
		return featConfigInstMsg;
	}

	public void setFeatConfigInstMsg(String featConfigInstMsg) {
		this.featConfigInstMsg = featConfigInstMsg;
	}

	public String getFeatConfigErrorMsg() {
		return featConfigErrorMsg;
	}

	public void setFeatConfigErrorMsg(String featConfigErrorMsg) {
		this.featConfigErrorMsg = featConfigErrorMsg;
	}

	public String getFeatConfigSuccessMsg() {
		return featConfigSuccessMsg;
	}

	public void setFeatConfigSuccessMsg(String featConfigSuccessMsg) {
		this.featConfigSuccessMsg = featConfigSuccessMsg;
	}

	public boolean isShowAddAttemptFeatBtn() {
		return showAddAttemptFeatBtn;
	}

	public void setShowAddAttemptFeatBtn(boolean showAddAttemptFeatBtn) {
		this.showAddAttemptFeatBtn = showAddAttemptFeatBtn;
	}

	public boolean isShowRemoveAttemptFeatBtn() {
		return showRemoveAttemptFeatBtn;
	}

	public void setShowRemoveAttemptFeatBtn(boolean showRemoveAttemptFeatBtn) {
		this.showRemoveAttemptFeatBtn = showRemoveAttemptFeatBtn;
	}

	public boolean isShowConfirmAttemptFeatBtn() {
		return showConfirmAttemptFeatBtn;
	}

	public void setShowConfirmAttemptFeatBtn(boolean showConfirmAttemptFeatBtn) {
		this.showConfirmAttemptFeatBtn = showConfirmAttemptFeatBtn;
	}

	public boolean isShowCancelAttemptFeatBtn() {
		return showCancelAttemptFeatBtn;
	}

	public void setShowCancelAttemptFeatBtn(boolean showCancelAttemptFeatBtn) {
		this.showCancelAttemptFeatBtn = showCancelAttemptFeatBtn;
	}

	public Long getSelectedFeatSponsorId() {
		return selectedFeatSponsorId;
	}

	public void setSelectedFeatSponsorId(Long selectedFeatSponsorId) {
		this.selectedFeatSponsorId = selectedFeatSponsorId;
	}

	public Long getSelectedFeatAppId() {
		return selectedFeatAppId;
	}

	public void setSelectedFeatAppId(Long selectedFeatAppId) {
		this.selectedFeatAppId = selectedFeatAppId;
	}

	public boolean isShowFeatAppSelector() {
		return showFeatAppSelector;
	}

	public void setShowFeatAppSelector(boolean showFeatAppSelector) {
		this.showFeatAppSelector = showFeatAppSelector;
	}
}
