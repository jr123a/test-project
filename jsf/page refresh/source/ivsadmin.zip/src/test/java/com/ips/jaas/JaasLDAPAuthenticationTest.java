package com.ips.jaas;

import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import com.ips.common.common.CustomLogger;

/**
 *
 */
public class JaasLDAPAuthenticationTest {
    
    public static void main(String[] args) {
        String userName = System.getProperty("LDAPuser");
        String password = System.getProperty("LDAPpass");
        boolean loginStatus = true;
        CallbackHandler handler = new IPSCallbackHandler(userName,password);

        try {
            LoginContext loginContext = new LoginContext("IPSLDAPLogin" , handler);
            loginContext.login();
        } catch (LoginException e) {
            loginStatus = false;
            CustomLogger.error(JaasLDAPAuthenticationTest.class.getClass(), "Exception while testing JaasLDAPAuthentication with user "+userName,e);
        }

        if(loginStatus){
            CustomLogger.debug(JaasLDAPAuthenticationTest.class.getClass(), "LDAP Login Successful.");
        }else{
            CustomLogger.error(JaasLDAPAuthenticationTest.class.getClass(), "LDAP Login Failed.");
        }
    }

}
