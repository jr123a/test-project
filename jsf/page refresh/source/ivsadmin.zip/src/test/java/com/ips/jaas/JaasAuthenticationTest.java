package com.ips.jaas;

import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import com.ips.common.common.CustomLogger;

/**
 *
 */
public class JaasAuthenticationTest {
    
    public static void main(String[] args) {
        String userName = System.getProperty("user");
        String password = System.getProperty("pass");
        boolean loginStatus = true;
        CallbackHandler handler = new IPSCallbackHandler(userName,password);

        try {
            LoginContext loginContext = new LoginContext("IPSLogin" , handler);
            loginContext.login();
        } catch (LoginException e) {
            loginStatus = false;
        }

        if(loginStatus){
            CustomLogger.debug(JaasAuthenticationTest.class.getClass(), "Login Successful.");
        }else{
            CustomLogger.error(JaasAuthenticationTest.class.getClass(), "Login Failed.");
        }
    }

}
