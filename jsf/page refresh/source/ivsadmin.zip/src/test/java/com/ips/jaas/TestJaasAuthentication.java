package com.ips.jaas;

import static org.junit.jupiter.api.Assertions.*;

import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import com.ips.common.common.CustomLogger;
import org.junit.jupiter.api.Test;

class TestJaasAuthentication {

    @Test
    void testJaasAuthentication() {
        String userName = System.getProperty("user");
        String password = System.getProperty("pass");
        CustomLogger.debug(this.getClass(), "user property = "+userName + ", pass property = "+password);
        boolean loginStatus = true;
        CallbackHandler handler = new IPSCallbackHandler(userName,password);

        try {
            LoginContext loginContext = new LoginContext("IPSLogin" , handler);
            loginContext.login();
        } catch (LoginException e) {
            loginStatus = false;
        }

        if(loginStatus){
            CustomLogger.debug(this.getClass(), "Login Successful.");
            assertTrue(loginStatus, "Login Successful.");
        }else{
            CustomLogger.error(this.getClass(), "Login Failed.");
            assertFalse(loginStatus, "Login Failed.");
        }
    }

}
