package com.ips.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ips.dao.RefDeviceTypesDao;
import com.ips.entity.RefDeviceTypes;

@Service(value = "refDeviceTypesService")
public class RefDeviceTypesServiceImpl implements RefDeviceTypesService{

    @Autowired
    private RefDeviceTypesDao dao;
    @Override
    public List<RefDeviceTypes> getDeviceList() {
        return dao.getDeviceList();
    }
    @Override
    public RefDeviceTypes getDeviceTypeById(long deviceID) {
        return dao.getDeviceTypeById(deviceID);
    }

}
