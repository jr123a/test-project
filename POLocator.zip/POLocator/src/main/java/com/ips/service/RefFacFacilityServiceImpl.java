package com.ips.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ips.common.common.CustomLogger;
import com.ips.dao.RefFacFacilityDao;
import com.ips.entity.RefFacFacility;
import com.ips.exception.IPSException;
import com.ips.polocator.common.MainFacilityFinanceVo;

@Service("refFacFacilityService")
@Transactional
public class RefFacFacilityServiceImpl implements RefFacFacilityService, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private RefFacFacilityDao dao;
    
    @Override
    public RefFacFacility create(RefFacFacility entity) {
        dao.save(entity);
        return entity;
    }

    @Override
    public void delete(RefFacFacility entity) {
        dao.delete(entity);        
    }

    @Override
    public RefFacFacility update(RefFacFacility entity) {
        dao.update(entity);
        return dao.getById(entity.getFacilityId());
    }

    @Override
    public List<RefFacFacility> list() {
        return (List<RefFacFacility>) dao.getAll();
    }

    @Override
    public RefFacFacility findByPK(Object id) {
        return dao.getById((Long)id);
    }
    
    @Override
    public List<RefFacFacility> getAllFacilitiesByActivationDate(boolean active, int firstResult, int maxResults) {
        return dao.getAllFacilitiesByActivationDate(active, firstResult, maxResults);
    }
    
    @Override
    public Long getAllFacilitiesCountByActivationDate(boolean active) {
        return dao.getAllFacilitiesCountByActivationDate(active);
    }

    @Override
    public Collection<RefFacFacility> findByZipCode(String zipCode) {
        return dao.findByZipCode(zipCode);
    }

    @Override
    public List<RefFacFacility> findByZipAndActivationDate(String zipCode, boolean active) {
        return dao.findByZipAndActivationDate(zipCode, active);
    }
    
    @Override
    public List<RefFacFacility> findByCityStateAndActivationDate(String city, String state,  boolean active) {
        return dao.findByCityStateAndActivationDate(city, state, active);
    }
    
    @Override
    public List<RefFacFacility> findByCityState(String city, String state) {
        return dao.findByCityState(city, state);
    }

    @Override
    public int updateAllFacilities(Date activationDate, boolean activate) {
        return dao.updateAllFacilities(activationDate, activate);
    }

    @Override
    public int updateActivationDate(List<String> refFacilityIdList, List<Date> activationDateList) {
        return dao.updateActivationDate(refFacilityIdList, activationDateList);
    }
    
    @Override
    public List<String> updatedFacilityIdList(List<String> refFacilityIdList, List<Date> activationDateList) {
        return dao.updatedFacilityIdList(refFacilityIdList, activationDateList);
    }
    
    @Override
    public List<RefFacFacility> getFacilitiesByIds(List<String> refFacilityIDs) {
        return dao.getFacilitiesByIds(refFacilityIDs);
        
    }
    
    @Override
    public List<RefFacFacility> getFacilitiesNoCoord() {
        return dao.getFacilitiesNoCoord();
    }
    
    @Override
    public RefFacFacility findByFinanceNumber(String financeNumber) throws IPSException {
        return dao.findByFinanceNumber(financeNumber);
    }
    
    @Override
    public RefFacFacility findByCoordinates(double latitude, double longitude) throws IPSException {
        return dao.findByCoordinates(latitude, longitude);
    }
    
    public List<RefFacFacility> findByGridCoordinates(double lowLatitude, double highLatitude, double lowLongitude, double highLongitude) {
        return dao.findByGridCoordinates(lowLatitude, highLatitude, lowLongitude, highLongitude);
    }
    
    /**
     * This method is called from the Correct Facility tab of the admin page.
     */
    public List<RefFacFacility> findFacilitiesInGrid(String proofingLocation) {
        // Create Grid Boundaries
        BigDecimal[] gridBoundaries = determineGridBoundaries(proofingLocation);
        
        // Note that this is a grid around the proofing location, not around the facility
        BigDecimal locationLatLowBoundary = gridBoundaries[0];
        BigDecimal locationLatHighBoundary = gridBoundaries[1];
        BigDecimal locationLongLowBoundary = gridBoundaries[2];
        BigDecimal locationLongHighBoundary = gridBoundaries[3];
        
        CustomLogger.debug(this.getClass(), "Looking for facilities within this grid.  LatLow: " + locationLatLowBoundary + " LatHigh: " + locationLatHighBoundary);
        CustomLogger.debug(this.getClass(), "LongLow: " + locationLongLowBoundary + " LongHigh: " + locationLongHighBoundary);
        
        List<RefFacFacility> facilities = findByGridCoordinates(locationLatLowBoundary.doubleValue(), locationLatHighBoundary.doubleValue(), 
                locationLongLowBoundary.doubleValue(), locationLongHighBoundary.doubleValue());
        
        if (facilities == null) {
            CustomLogger.debug(this.getClass(), "0 facilities found");
        }
        else {
            CustomLogger.debug(this.getClass(), facilities.size() + " facilities found");
        }
        
        return facilities;
    }
    
    private BigDecimal truncateTo4DecimalPlaces(BigDecimal original) {
        DecimalFormat df = new DecimalFormat("##.####");
        df.setRoundingMode(RoundingMode.DOWN);
        
        String truncated = df.format(original);
        return new BigDecimal(truncated);
    }
    
    @Override
    public List<RefFacFacility> getActiveFacilitiesByIds(List<String> facIDs) {
        return dao.getActiveFacilitiesByIds(facIDs);
        
    }
    
    private BigDecimal[] determineGridBoundaries(String proofingLocation) {
        // Parse the coordinates from the proofingLocation
        String[]tokens = proofingLocation.split(",");
            
        String parsedLatitude = tokens[0].trim();
        String parsedLongitude = tokens[1].trim();
        
        BigDecimal latitude = new BigDecimal(parsedLatitude);
        BigDecimal longitude = new BigDecimal(parsedLongitude);
        
        // Truncate to 4 decimal places
        latitude = truncateTo4DecimalPlaces(latitude);
        longitude = truncateTo4DecimalPlaces(longitude);
        
        // Set Boundary Modifier.  Modify the thousandths place.
        BigDecimal boundaryModifier = new BigDecimal("0.004");

        // Create Grid Boundaries
        // Note that this is a grid around the proofing location, not around the facility
        BigDecimal locationLatLowBoundary = latitude.subtract(boundaryModifier);
        BigDecimal locationLatHighBoundary = latitude.add(boundaryModifier);
        BigDecimal locationLongLowBoundary = longitude.subtract(boundaryModifier);
        BigDecimal locationLongHighBoundary = longitude.add(boundaryModifier);
        BigDecimal[] boundaries = new BigDecimal[4];
        boundaries[0] = locationLatLowBoundary;
        boundaries[1] = locationLatHighBoundary;
        boundaries[2] = locationLongLowBoundary;
        boundaries[3] = locationLongHighBoundary;
        
        return boundaries;
    }
    
    /**
     * The IPP sendProofingResults web service uses this method to handle
     * duplicates (multiple facility rows with the same facility id and coordinates).
     */
    public List<BigDecimal> findUniqueFacilitiesInGrid(String proofingLocation) {
        BigDecimal[] gridBoundaries = determineGridBoundaries(proofingLocation);
        BigDecimal locationLatLowBoundary = gridBoundaries[0];
        BigDecimal locationLatHighBoundary = gridBoundaries[1];
        BigDecimal locationLongLowBoundary = gridBoundaries[2];
        BigDecimal locationLongHighBoundary = gridBoundaries[3];
        
        CustomLogger.debug(this.getClass(), "Looking for facilities within this grid.  LatLow: " + locationLatLowBoundary + " LatHigh: " + locationLatHighBoundary);
        CustomLogger.debug(this.getClass(), "LongLow: " + locationLongLowBoundary + " LongHigh: " + locationLongHighBoundary);
        
        return dao.findUniqueFacilityIdByGridCoordinates(locationLatLowBoundary.doubleValue(), locationLatHighBoundary.doubleValue(), 
                locationLongLowBoundary.doubleValue(), locationLongHighBoundary.doubleValue());
     }
    
    public RefFacFacility findByFacilityIdDeviceType(long facilityId, long deviceType) {
        return dao.findByFacilityIdDeviceType(facilityId, deviceType);
    }
    
    public List<RefFacFacility> findByFacilityId(long facilityId) {
        return dao.findByFacilityId(facilityId);
    }
    
    public List<RefFacFacility> findByFacilityName(String facilityName) {
        return dao.findByFacilityName(facilityName);
    }

    public RefFacFacilityDao getDao() {
        return dao;
    }

    public void setDao(RefFacFacilityDao dao) {
        this.dao = dao;
    }
    
    @Override
    public List<RefFacFacility> findActiveSponsorFacilitiesByIds(long sponsorId, List<String> facIDs) {
        List<String> refFacilityIds = dao.findActiveSponsorFacilityIds(sponsorId, facIDs);
        return getFacilitiesByIds(refFacilityIds);
    }

    @Override
    public List<RefFacFacility> getIAL2Facilities(List<String> facIDs, long sponsorId) {
        return dao.getIAL2Facilities(facIDs, sponsorId);
    }
    
    @Override
    public List<RefFacFacility> getIAL2FacilitiesSublist(List<String> facIDs, long sponsorId) {
        return dao.getIAL2FacilitiesSublist(facIDs, sponsorId);
    }

	@Override
	public RefFacFacility findByFacilityIdFinanceNumber(long facilityId, String financeNumber) {
		return dao.findByFacilityIdFinanceNumber(facilityId, financeNumber);
	}

	@Override
	public RefFacFacility findWithUpdatedFinanceNumber(long facilityId, long deviceTypeId) {
		return dao.findWithUpdatedFinanceNumber(facilityId, deviceTypeId);
	}

	@Override
	public List<RefFacFacility> getGen6Facilities(List<String> facIDs, long sponsorId) {
		return dao.getGen6Facilities(facIDs, sponsorId);
	}

	@Override
	public List<MainFacilityFinanceVo> getNewRecordsFromMainFacilities() {
		return dao.getNewRecordsFromMainFacilities();
	}


	@Override
	public List<RefFacFacility> getFinanceNumForUpdateFromStagingFacilities() {
		return dao.getFinanceNumForUpdateFromStagingFacilities();
	}

	@Override
	public List<RefFacFacility> getNodelessByFinanceNumFacilities() {
		return dao.getNodelessByFinanceNumFacilities();
	}

	@Override
	public List<RefFacFacility> getMultiNodeFacilities() {
		return dao.getMultiNodeFacilities();
	}

	@Override
	public List<RefFacFacility> getNodelessByMposDeviceFacilities() {
		return dao.getNodelessByMposDeviceFacilities();
	}

	@Override
	public List<RefFacFacility> getNodelessByPosDeviceFacilities() {
		return dao.getNodelessByPosDeviceFacilities();
	}

	@Override
	public List<RefFacFacility> getAdminOverriddenFacilities() {
		return dao.getAdminOverriddenFacilities();
	}

	@Override
	public List<RefFacFacility> getFacilityIdNotInStagingFacilities() {
		return dao.getFacilityIdNotInStagingFacilities();
	}

	@Override
	public List<RefFacFacility> getFinanceNumNotInStagingFacilities() {
		return dao.getFinanceNumNotInStagingFacilities();
	}

	@Override
	public List<RefFacFacility> getSinglePOSChannelFacilities() {
		return dao.getSinglePOSChannelFacilities();
	}

	@Override
	public List<RefFacFacility> getSingleMPOSChannelFacilities() {
		return dao.getSingleMPOSChannelFacilities();
	}
}
