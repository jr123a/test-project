package com.ips.service;

import java.util.List;

import com.ips.entity.RefMainFacility;

public interface RefMainFacilityService extends GenericService<RefMainFacility> {
	
	List<RefMainFacility> list();
	RefMainFacility findByFacilityId(long facilityId);
}
