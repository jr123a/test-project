package com.ips.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.RefDistrictDao;
import com.ips.entity.RefDistrict;

@Service("refDistrictService")
@Transactional
public class RefDistrictServiceImpl implements RefDistrictService, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private RefDistrictDao dao;
 
    @Override
    public List<RefDistrict> list() {
        return (List<RefDistrict>) dao.findAll();
    }
   
    @Override
    public RefDistrict findByDistrictId(long districtId) {
        return dao.findByDistrictId(districtId);
    }

	@Override
	public RefDistrict create(RefDistrict entity) {
		dao.save(entity);
        return entity;
	}

	@Override
	public void delete(RefDistrict entity) {
		dao.delete(entity); 
	}

	@Override
	public RefDistrict update(RefDistrict entity) {
		dao.update(entity);
	    return dao.getById(entity.getDistrictId());
 	}

	@Override
	public RefDistrict findByPK(Object id) {
		return dao.getById((Long)id);
	}

}
