package com.ips.service;

import java.util.List;

import com.ips.entity.RefDeviceTypes;

public interface RefDeviceTypesService {

    List<RefDeviceTypes> getDeviceList();

    RefDeviceTypes getDeviceTypeById(long deviceID);
}
