package com.ips.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.RefAreaDao;
import com.ips.entity.RefArea;

@Service("refAreaService")
@Transactional
public class RefAreaServiceImpl implements RefAreaService, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private RefAreaDao dao;
 
    @Override
    public List<RefArea> list() {
        return (List<RefArea>) dao.findAll();
    }
   
    @Override
    public RefArea findByAreaId(long areaId) {
        return dao.findByAreaId(areaId);
    }

	@Override
	public RefArea create(RefArea entity) {
		dao.save(entity);
        return entity;
	}

	@Override
	public void delete(RefArea entity) {
		dao.delete(entity); 
	}

	@Override
	public RefArea update(RefArea entity) {
		dao.update(entity);
	    return dao.getById(entity.getAreaId());
 	}

	@Override
	public RefArea findByPK(Object id) {
		return dao.getById((Long)id);
	}

}
