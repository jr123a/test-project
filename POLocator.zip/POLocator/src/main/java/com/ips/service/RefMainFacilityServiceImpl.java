package com.ips.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ips.dao.RefMainFacilityDao;
import com.ips.entity.RefMainFacility;

@Service("refMainFacilityService")
@Transactional
public class RefMainFacilityServiceImpl implements RefMainFacilityService, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private RefMainFacilityDao dao;
    
    @Override
    public List<RefMainFacility> list() {
        return (List<RefMainFacility>) dao.getAll();
    }
   
    @Override
    public RefMainFacility findByFacilityId(long facilityId) {
        return dao.findByFacilityId(facilityId);
    }

	@Override
	public RefMainFacility create(RefMainFacility entity) {
		dao.save(entity);
        return entity;
	}

	@Override
	public void delete(RefMainFacility entity) {
		dao.delete(entity); 
	}

	@Override
	public RefMainFacility update(RefMainFacility entity) {
        dao.update(entity);
        return dao.getById(entity.getFacilityId());
	}

	@Override
	public RefMainFacility findByPK(Object id) {
		return dao.getById((Long)id);
	}
}
