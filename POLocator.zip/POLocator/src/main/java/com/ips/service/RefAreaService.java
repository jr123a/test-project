package com.ips.service;

import java.util.List;

import com.ips.entity.RefArea;

public interface RefAreaService extends GenericService<RefArea> {
	
	List<RefArea> list();
	RefArea findByAreaId(long areaId);
}
