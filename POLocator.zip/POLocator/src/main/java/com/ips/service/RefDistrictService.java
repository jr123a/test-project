package com.ips.service;

import java.util.List;

import com.ips.entity.RefDistrict;

public interface RefDistrictService extends GenericService<RefDistrict> {
	
	List<RefDistrict> list();
	RefDistrict findByDistrictId(long districtId);
}
