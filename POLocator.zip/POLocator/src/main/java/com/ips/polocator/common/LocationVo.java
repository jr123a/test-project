package com.ips.polocator.common;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;

import com.ips.common.common.DateTimeUtil;
import com.ips.xml.generated.polocator.PhoneData;

public class LocationVo implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String locationType;
    private String locationID;
    private String locationName;
    private String address; 
    private String address2;
    private String city;
    private String state;
    private String zip5;
    private String zip4;
    private String fax;
    private String parking;
    private String weekdayHours;
    private String satHours;
    private String sunHours;
    private String distance;
    private String financeNumber;
    private String deviceTypeName;
    private Long deviceTypeId;
    private PhoneData phoneData;
    private boolean adminOverride;
    private boolean selected;
    private Date activationDate;
    private Locale locale = Locale.US;
    
    public String getLocationType() {
        return locationType;
    }
    public void setLocationType(String locationType) {
        this.locationType = locationType;
    }
    public String getLocationID() {
        return locationID;
    }
    public void setLocationID(String locationID) {
        this.locationID = locationID;
    }
    public String getLocationName() {
        return locationName;
    }
    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getAddress2() {
        return address2;
    }
    public void setAddress2(String address2) {
        this.address2 = address2;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getZip5() {
        return zip5;
    }
    public void setZip5(String zip5) {
        this.zip5 = zip5;
    }
    public String getZip4() {
        return zip4;
    }
    public void setZip4(String zip4) {
        this.zip4 = zip4;
    }
    public String getFax() {
        return fax;
    }
    public void setFax(String fax) {
        this.fax = fax;
    }
    public String getParking() {
        return parking;
    }
    public void setParking(String parking) {
        this.parking = parking;
    }
    public String getWeekdayHours() {
        return weekdayHours;
    }
    public void setWeekdayHours(String weekdayHours) {
        this.weekdayHours = weekdayHours;
    }
    public String getSatHours() {
        return satHours;
    }
    public void setSatHours(String satHours) {
        this.satHours = satHours;
    }
    public String getSunHours() {
        return sunHours;
    }
    public void setSunHours(String sunHours) {
        this.sunHours = sunHours;
    }
    public String getDistance() {
        return distance;
    }
    public void setDistance(String distance) {
        this.distance = distance;
    }
    public String getFinanceNumber() {
        return financeNumber;
    }
    public void setFinanceNumber(String financeNumber) {
        this.financeNumber = financeNumber;
    }
    public String getDeviceTypeName() {
        return deviceTypeName;
    }
    public void setDeviceTypeName(String deviceTypeName) {
        this.deviceTypeName = deviceTypeName;
    }
    public Long getDeviceTypeId() {
        return deviceTypeId;
    }
    public void setDeviceTypeId(Long deviceTypeId) {
        this.deviceTypeId = deviceTypeId;
    }
    public PhoneData getPhoneData() {
        return phoneData;
    }
    public void setPhoneData(PhoneData phoneData) {
        this.phoneData = phoneData;
    }
    public boolean isAdminOverride() {
		return adminOverride;
	}
	public void setAdminOverride(boolean adminOverride) {
		this.adminOverride = adminOverride;
	}
	public boolean isSelected() {
        return selected;
    }
    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    
    public Date getActivationDate() {
        return activationDate;
    }
    public void setActivationDate(Date activationDate) {
        this.activationDate = activationDate;
    }

    public String getActivationDateStr() {
        return DateTimeUtil.getDateString(this.activationDate, "MM/dd/yyyy");
    }

    public Locale getLocale() {
        return locale;
    }
 
    public void setLocale(Locale locale) {
        this.locale = locale;
    }
}
