package com.ips.polocator.common;

import java.io.Serializable;

public class MainFacilityFinanceVo implements Serializable {

    private static final long serialVersionUID = 1L;
    private long facilityId;
    private String financeNumber;
    private String facilityName;
    private String facilityAddress;
    private String facilityCity;
    private String facilityState;
    private String facilityZipCode;
 
	public long getFacilityId() {
		return facilityId;
	}
	
	public void setFacilityId(long facilityId) {
		this.facilityId = facilityId;
	}

	public String getFinanceNumber() {
		return financeNumber;
	}

	public void setFinanceNumber(String financeNumber) {
		this.financeNumber = financeNumber;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getFacilityAddress() {
		return facilityAddress;
	}

	public void setFacilityAddress(String facilityAddress) {
		this.facilityAddress = facilityAddress;
	}

	public String getFacilityCity() {
		return facilityCity;
	}

	public void setFacilityCity(String facilityCity) {
		this.facilityCity = facilityCity;
	}

	public String getFacilityState() {
		return facilityState;
	}

	public void setFacilityState(String facilityState) {
		this.facilityState = facilityState;
	}

	public String getFacilityZipCode() {
		return facilityZipCode;
	}

	public void setFacilityZipCode(String facilityZipCode) {
		this.facilityZipCode = facilityZipCode;
	}

}
