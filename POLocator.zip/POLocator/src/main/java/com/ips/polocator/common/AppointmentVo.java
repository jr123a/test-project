package com.ips.polocator.common;

import java.io.Serializable;
import java.util.Date;

public class AppointmentVo implements Serializable{
    private static final long serialVersionUID = 1L;

    private Date scheduledDate;
    private String scheduledTime;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String zip5;
    private String zip4;
    private boolean scheduled;
    private boolean canceled;
    private long eventId;
    private short deliveryPoint;
    private String carrierRoute;
    private double latitude;
    private double longitude;
    private String recordLocator;
    private String ippType;
    
    public String getRecordLocator(){
        return recordLocator;
    }
    
    public void setRecordLocator(String recordLocator){
        this.recordLocator = recordLocator;
    }
    
    public Date getScheduledDate() {
        return scheduledDate;
    }
    public void setScheduledDate(Date scheduledDate) {
        this.scheduledDate = scheduledDate;
    }
    public String getScheduledTime() {
        return scheduledTime;
    }
    public void setScheduledTime(String scheduledTime) {
        this.scheduledTime = scheduledTime;
    }
    public String getAddress1() {
        return address1;
    }
    public void setAddress1(String address1) {
        this.address1 = address1;
    }
    public String getAddress2() {
        return address2;
    }
    public void setAddress2(String address2) {
        this.address2 = address2;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getZip5() {
        return zip5;
    }
    public void setZip5(String zip5) {
        this.zip5 = zip5;
    }
    public String getZip4() {
        return zip4;
    }
    public void setZip4(String zip4) {
        this.zip4 = zip4;
    }
    public boolean isScheduled() {
        return scheduled;
    }
    public void setScheduled(boolean scheduled) {
        this.scheduled = scheduled;
    }

    public boolean isCanceled() {
        return canceled;
    }
    public void setCanceled(boolean canceled) {
        this.canceled = canceled;
    }
    public long getEventId() {
        return eventId;
    }
    public void setEventId(long eventId) {
        this.eventId = eventId;
    }
    public short getDeliveryPoint() {
        return deliveryPoint;
    }
    public void setDeliveryPoint(short deliveryPoint) {
        this.deliveryPoint = deliveryPoint;
    }
    public String getCarrierRoute() {
        return carrierRoute;
    }
    public void setCarrierRoute(String carrierRoute) {
        this.carrierRoute = carrierRoute;
    }
    public double getLatitude() {
        return latitude;
    }
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }
    public double getLongitude() {
        return longitude;
    }
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getIppType() {
        return ippType;
    }

    public void setIppType(String ippType) {
        this.ippType = ippType;
    }        
    
}
