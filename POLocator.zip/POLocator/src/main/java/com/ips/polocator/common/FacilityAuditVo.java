package com.ips.polocator.common;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

public class FacilityAuditVo implements Serializable {

    private static final long serialVersionUID = 1L;
    private long refFacilityId;
    private long facilityId;
    private String financeNumberBefore;
    private String financeNumberAfter;
    private String adminOverrideBefore;
    private String adminOverrideAfter;
	private Date activationDateBefore;
	private Date activationDateAfter;
	private Date automationUpdateDateBefore;
	private Date automationUpdateDateAfter;
	private Timestamp updateTimestampBefore;
	private Timestamp updateTimestampAfter;
	private Long activationTimeBefore;
	private Long automationUpdateTimeBefore;
	private Long updateTimeBefore;
    private String action;
    private String source;
    
	public long getRefFacilityId() {
		return refFacilityId;
	}

	public void setRefFacilityId(long refFacilityId) {
		this.refFacilityId = refFacilityId;
	}

	public long getFacilityId() {
		return facilityId;
	}
	
	public void setFacilityId(long facilityId) {
		this.facilityId = facilityId;
	}

	public String getFinanceNumberBefore() {
		return financeNumberBefore;
	}

	public void setFinanceNumberBefore(String financeNumberBefore) {
		this.financeNumberBefore = financeNumberBefore;
	}

	public String getFinanceNumberAfter() {
		return financeNumberAfter;
	}

	public void setFinanceNumberAfter(String financeNumberAfter) {
		this.financeNumberAfter = financeNumberAfter;
	}

	public String getAdminOverrideBefore() {
		return adminOverrideBefore;
	}

	public void setAdminOverrideBefore(String adminOverrideBefore) {
		this.adminOverrideBefore = adminOverrideBefore;
	}

	public String getAdminOverrideAfter() {
		return adminOverrideAfter;
	}

	public void setAdminOverrideAfter(String adminOverrideAfter) {
		this.adminOverrideAfter = adminOverrideAfter;
	}

	public Date getActivationDateBefore() {
		return activationDateBefore;
	}

	public void setActivationDateBefore(Date activationDateBefore) {
		this.activationDateBefore = activationDateBefore;
	}

	public Date getActivationDateAfter() {
		return activationDateAfter;
	}

	public void setActivationDateAfter(Date activationDateAfter) {
		this.activationDateAfter = activationDateAfter;
	}

	public Date getAutomationUpdateDateBefore() {
		return automationUpdateDateBefore;
	}

	public void setAutomationUpdateDateBefore(Date automationUpdateDateBefore) {
		this.automationUpdateDateBefore = automationUpdateDateBefore;
	}

	public Date getAutomationUpdateDateAfter() {
		return automationUpdateDateAfter;
	}

	public void setAutomationUpdateDateAfter(Date automationUpdateDateAfter) {
		this.automationUpdateDateAfter = automationUpdateDateAfter;
	}

	public Timestamp getUpdateTimestampBefore() {
		return updateTimestampBefore;
	}

	public void setUpdateTimestampBefore(Timestamp updateTimestampBefore) {
		this.updateTimestampBefore = updateTimestampBefore;
	}

	public Timestamp getUpdateTimestampAfter() {
		return updateTimestampAfter;
	}

	public void setUpdateTimestampAfter(Timestamp updateTimestampAfter) {
		this.updateTimestampAfter = updateTimestampAfter;
	}

	public Long getActivationTimeBefore() {
		return activationTimeBefore;
	}

	public void setActivationTimeBefore(Long activationTimeBefore) {
		this.activationTimeBefore = activationTimeBefore;
	}

	public Long getAutomationUpdateTimeBefore() {
		return automationUpdateTimeBefore;
	}

	public void setAutomationUpdateTimeBefore(Long automationUpdateTimeBefore) {
		this.automationUpdateTimeBefore = automationUpdateTimeBefore;
	}

	public Long getUpdateTimeBefore() {
		return updateTimeBefore;
	}

	public void setUpdateTimeBefore(Long updateTimeBefore) {
		this.updateTimeBefore = updateTimeBefore;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
 
}
