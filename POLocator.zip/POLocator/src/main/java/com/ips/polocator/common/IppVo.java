package com.ips.polocator.common;

import java.io.Serializable;

public class IppVo implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String email;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String stateProvince;
    private String postalCode;
    private String barcodeFileName;
    private String barcodeImagePath;
    private String recordLocator;
    private String status;
    private long sponsorId;
    private boolean sponsorCustReg;
    private boolean sponsorActiveIppClient;
    private boolean sponsorUsingFacilitySubList;
    private String expirationDays = "";
    private String ial2Transaction = "";
    private String radius = "50";
    private String zipCode;
    
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getAddressLine1() {
        return addressLine1;
    }
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }
    public String getAddressLine2() {
        return addressLine2;
    }
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getStateProvince() {
        return stateProvince;
    }
    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }
    public String getPostalCode() {
        return postalCode;
    }
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
    public String getBarcodeFileName() {
        return barcodeFileName;
    }
    public void setBarcodeFileName(String barcodeFileName) {
        this.barcodeFileName = barcodeFileName;
    }
    public String getBarcodeImagePath() {
        return barcodeImagePath;
    }
    public void setBarcodeImagePath(String barcodeImagePath) {
        this.barcodeImagePath = barcodeImagePath;
    }
    public String getRecordLocator() {
        return recordLocator;
    }
    public void setRecordLocator(String recordLocator) {
        this.recordLocator = recordLocator;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    
    public long getSponsorId() {
        return sponsorId;
    }
    
    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }
    
    public boolean isSponsorCustReg() {
        return sponsorCustReg;
    }
    
    public void setSponsorCustReg(boolean sponsorCustReg) {
        this.sponsorCustReg = sponsorCustReg;
    }
    
    public boolean isSponsorActiveIppClient() {
        return sponsorActiveIppClient;
    }
    
    public void setSponsorActiveIppClient(boolean sponsorActiveIppClient) {
        this.sponsorActiveIppClient = sponsorActiveIppClient;
    }
    
    public boolean isSponsorUsingFacilitySubList() {
        return sponsorUsingFacilitySubList;
    }
    
    public void setSponsorUsingFacilitySubList(boolean sponsorUsingFacilitySubList) {
        this.sponsorUsingFacilitySubList = sponsorUsingFacilitySubList;
    }
    
    public String getExpirationDays() {
        return expirationDays;
    }
    
    public void setExpirationDays(String expirationDays) {
        this.expirationDays = expirationDays;
    }
    
    public String getStreetAddressLines() {
        if (this.getAddressLine2() == null) {
            return this.getAddressLine1();
        }
        else {
            return this.getAddressLine1() + this.getAddressLine2();
        }
    }
    
    public String getCityStateLine() {
        return this.getCity() + ", " + this.getStateProvince() + " " + this.getPostalCode();
    }
    public String getIal2Transaction() {
        return ial2Transaction;
    }
    public void setIal2Transaction(String ial2Transaction) {
        this.ial2Transaction = ial2Transaction;
    }
	public String getRadius() {
		return radius;
	}
	public void setRadius(String radius) {
		this.radius = radius;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
}
