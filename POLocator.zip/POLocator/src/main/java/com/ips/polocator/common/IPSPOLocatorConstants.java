package com.ips.polocator.common;

public class IPSPOLocatorConstants {

    public static final String UNKNOWN = "Unknown";
    
    public static final String WEB_TOOLS_ALIAS = "AMS";

    public static final String USPS_PROXY_HOST = "proxy.usps.gov";
    public static final String USPS_PROXY_PORT = "8080";
    
    public static final String WEB_TOOLS_API_POLOCATOR_RADIUS = "50";
    public static final String WEB_TOOLS_API_POLOCATOR_MAXLOCATIONS = "100";
    public static final String WEB_TOOLS_API_POLOCATOR_FACILITYTYPE = "PO";
    public static final String WEB_TOOLS_API_POLOCATOR_SERVICE = "PICKUPHOLDMAIL";
    public static final String WEB_TOOLS_API_RSS_TERMINAL_SERVICE = "RTLMKTGTERMINALTYPERSS";
    public static final String WEB_TOOLS_API_BIOIPPA_SERVICE = "BIOIPPA";
    public static final String WEB_TOOLS_API_BIOIPPB_SERVICE = "BIOIPPB";
    public static final String WEB_TOOLS_API_GETADDRESS = "http://production.shippingapis.com/ShippingAPI.dll?API=GetAddress";
    public static final String WEB_TOOLS_API_POLOCATOR = "http://production.shippingapis.com/ShippingAPI.dll?API=POLocatorV2";

}
