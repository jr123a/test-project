package com.ips.proofing;

import java.text.ParseException;
import java.util.List;

import com.ips.exception.AMSException;
import com.ips.polocator.common.AppointmentVo;
import com.ips.polocator.common.IppVo;
import com.ips.polocator.common.LocationVo;
import com.ips.xml.generated.polocator.Location;

public interface VerifyAddressService {
    
    AppointmentVo verifyAddress(AppointmentVo appointment) throws AMSException;
    List<Object> getFilteredPOList(IppVo ippVo) throws AMSException;
    List<Object> getFilteredPOListByZipCode(IppVo ippVo, String zipCode) throws AMSException;
	List<Object> getFilteredPOListByZipCode(IppVo ippVo) throws AMSException;
    List<LocationVo> getLocationVo(List<Location> poLocations) throws ParseException;
    void populateGeocoordinates();
}
