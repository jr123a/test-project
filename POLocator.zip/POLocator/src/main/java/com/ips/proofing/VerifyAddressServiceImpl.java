package com.ips.proofing;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.math.RoundingMode;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.wink.client.ClientWebException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.ips.common.common.AliasVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.Utils;
import com.ips.entity.RefFacFacility;
import com.ips.exception.AMSException;
import com.ips.exception.IPSException;
import com.ips.polocator.common.AppointmentVo;
import com.ips.polocator.common.IPSPOLocatorConstants;
import com.ips.polocator.common.IppVo;
import com.ips.polocator.common.LocationVo;
import com.ips.service.RefFacFacilityService;
import com.ips.xml.generated.GetAddressRequestType;
import com.ips.xml.generated.GetAddressResponseType;
import com.ips.xml.generated.polocator.Error;
import com.ips.xml.generated.polocator.Filters;
import com.ips.xml.generated.polocator.Location;
import com.ips.xml.generated.polocator.POLocatorV2Request;
import com.ips.xml.generated.polocator.POLocatorV2Response;
import com.ips.xml.generated.polocator.Set;

@SuppressWarnings("deprecation")
@Service("VerifyAddressService")
public class VerifyAddressServiceImpl implements VerifyAddressService, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static URL URL;
	private static URL URLPOLocator;
	private static String username;
	private static String geocoderUrlGis = null;
	private static Proxy proxy;
	private static final String REVISION = "2";
	private static final String SUCCESS_MESSAGE = "EXACT MATCH";

	@Autowired
	private RefFacFacilityService refFacFacilityService;

	static {

		try {
			URL = new URL(IPSPOLocatorConstants.WEB_TOOLS_API_GETADDRESS);
			URLPOLocator = new URL(IPSPOLocatorConstants.WEB_TOOLS_API_POLOCATOR);
		} catch (MalformedURLException e) {
			CustomLogger.error(VerifyAddressServiceImpl.class.getClass(), "Error occured when converting String to Url",
					e);
		}

		AliasVo j2c = null;

		try {
			j2c = Utils.getAppCredentials(IPSPOLocatorConstants.WEB_TOOLS_ALIAS);
		} catch (IPSException e) {
			CustomLogger.error(VerifyAddressServiceImpl.class.getClass(), "Error adding SOAP Security Header", e);
		}
		username = j2c.getUserName();
		geocoderUrlGis = Utils.getProperty("com.ipsweb.GeocodeServer");
		proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(IPSPOLocatorConstants.USPS_PROXY_HOST,
				Integer.parseInt(IPSPOLocatorConstants.USPS_PROXY_PORT)));
	}

	@Override
	public AppointmentVo verifyAddress(AppointmentVo appointment) throws AMSException {

		GetAddressRequestType req = new GetAddressRequestType();
		req.setUSERID(username);
		req.setRevision(REVISION);
		req.setAddress1(appointment.getAddress1());
		if (appointment.getAddress2() == null) {
			req.setAddress2("");
		} else {
			req.setAddress2(appointment.getAddress2());
		}
		req.setCity(appointment.getCity());
		req.setState(appointment.getState());
		req.setZip5(appointment.getZip5());
		req.setZip4(appointment.getZip4());
		StringWriter s = new StringWriter();
		JAXBContext requestContext = null;
		JAXBContext responseContext = null;
		GetAddressResponseType rsp = null;

		try {
			requestContext = JAXBContext.newInstance(GetAddressRequestType.class);
			Marshaller m = requestContext.createMarshaller();
			m.setProperty(Marshaller.JAXB_FRAGMENT, true);
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
			m.marshal(req, s);
			String reqXML = s.toString();
			String message = "&XML=" + reqXML;
			CustomLogger.debug(this.getClass(), "AMS reqXML = " + message);
			StandardCharsets.UTF_8.encode(message);

			URLConnection conn = URL.openConnection(proxy);

			conn.setDoOutput(true);

			OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(message);
			out.close();

			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			InputSource xmlSource = new InputSource(in);

			DocumentBuilder db = Utils.getSecureDOMParser();
			Document document = db.parse(xmlSource);

			responseContext = JAXBContext.newInstance(GetAddressResponseType.class);
			Unmarshaller um = responseContext.createUnmarshaller();
			rsp = (GetAddressResponseType) um.unmarshal(document);

			in.close();

		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Something went wrong when calling AMS Web Service", e);
			throw new AMSException(e.getMessage());
		}

		if (SUCCESS_MESSAGE.equalsIgnoreCase(rsp.getAddressStatus())) {
			String ippType = appointment.getIppType(); // save this value since object is recreated
			appointment = new AppointmentVo();
			appointment.setIppType(ippType);
			if (StringUtils.isBlank(rsp.getDefaultAddress().getAddress1())) {
				appointment.setAddress1(rsp.getDefaultAddress().getAddress2());
			} else {
				appointment.setAddress1(
						rsp.getDefaultAddress().getAddress1() + " " + rsp.getDefaultAddress().getAddress2());
			}
			appointment.setCity(rsp.getDefaultAddress().getCity());
			appointment.setState(rsp.getDefaultAddress().getState());
			appointment.setZip5(rsp.getDefaultAddress().getZip5());
			appointment.setZip4(rsp.getDefaultAddress().getZip4());
			appointment.setCarrierRoute(rsp.getDefaultAddress().getCarrierRoute());
			try {
				if (rsp.getDefaultAddress() != null && !Utils.isEmptyString(rsp.getDefaultAddress().getDeliveryPoint())
						&& Utils.isNumeric(rsp.getDefaultAddress().getDeliveryPoint())) {
					appointment.setDeliveryPoint(Short.parseShort(rsp.getDefaultAddress().getDeliveryPoint()));
				}
			} catch (NumberFormatException e) {
				CustomLogger.error(this.getClass(), "AMS Web Service Delivery Point is invalid ", e);
				throw new AMSException(e.getMessage());
			}

			// Use verified address to call RESTful web service to get Latitude/Y and
			// Longitude/X coordinates
			if (!"F".equalsIgnoreCase(appointment.getIppType())) {
				getGisGeocoderCoordinates(appointment);
			}
			CustomLogger.debug(this.getClass(), "Appointment longitude x coord= " + appointment.getLongitude()
					+ ", appointment latitude y coord= " + appointment.getLatitude());

			return appointment;
		} else {
			throw new AMSException("Address Status is " + rsp.getAddressStatus());
		}
	}

	private List<Object> getPoLocationsByAddress(IppVo ippVo) throws AMSException {
		CustomLogger.info(this.getClass(), "Calling POlocator location service for sponsor::"+ ippVo.getSponsorId());
		POLocatorV2Request req = setCommonFields(ippVo);
		req.setAddress2(ippVo.getAddressLine1());
		req.setCity(ippVo.getCity());
		req.setState(ippVo.getStateProvince());
		CustomLogger.debug(this.getClass(), "calling POLocator from getPoLocationsByAddress...");
		return callPOLocator(req);
	}

	private List<Object> getPoLocationsByZipCode(IppVo ippVo, String zipCode) throws AMSException {
		POLocatorV2Request req = setCommonFields(ippVo);
		req.setZIP5(zipCode);
		CustomLogger.debug(this.getClass(), "calling POLocator from getPoLocationsByZipCode...");
		return callPOLocator(req);
	}

	private List<Object> getPoLocationsByZipCode(IppVo ippVo) throws AMSException {
		POLocatorV2Request req = setCommonFields(ippVo);
		req.setZIP5(ippVo.getZipCode());
		CustomLogger.debug(this.getClass(), "calling POLocator from getPoLocationsByZipCode...");
		return callPOLocator(req);
	}
	
	private POLocatorV2Request setCommonFields(IppVo ippVo) {
		POLocatorV2Request req = new POLocatorV2Request();
		Filters reqFilters = new Filters();

		req.setUSERID(username);
		req.setRevision("2");
		req.setResponseDetail("ALL");
		req.setRadius(ippVo.getRadius().isEmpty()?IPSPOLocatorConstants.WEB_TOOLS_API_POLOCATOR_RADIUS:ippVo.getRadius());
		req.setMaxLocations(IPSPOLocatorConstants.WEB_TOOLS_API_POLOCATOR_MAXLOCATIONS);
		reqFilters.setFacilityType(IPSPOLocatorConstants.WEB_TOOLS_API_POLOCATOR_FACILITYTYPE);
		
		//Setting both IAL2 and basic for Holdmail till we get the FDB flags set up properly
		if(!ippVo.getIal2Transaction().isEmpty() && "true".equalsIgnoreCase(ippVo.getIal2Transaction())) {
			//IAL2 option enabled for sponsor
			reqFilters.setService(IPSPOLocatorConstants.WEB_TOOLS_API_POLOCATOR_SERVICE);
		} else {
			//Basic sponsor
			reqFilters.setService(IPSPOLocatorConstants.WEB_TOOLS_API_POLOCATOR_SERVICE);
		}
		
		req.setFilters(reqFilters);
		return req;
	}

	private List<Object> callPOLocator(POLocatorV2Request req) throws AMSException {
		StringWriter s = new StringWriter();
		JAXBContext context = null;
		List<Object> resultList = new ArrayList<>();

		try {
			context = JAXBContext.newInstance(POLocatorV2Request.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FRAGMENT, true);
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
			m.marshal(req, s);

			String reqXML = s.toString();
			String message = "&XML=" + reqXML;
			CustomLogger.debug(this.getClass(), "POLocator reqXML = " + message);

			StandardCharsets.UTF_8.encode(message);

			URLConnection conn = URLPOLocator.openConnection(proxy);

			conn.setDoOutput(true);

			OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(message);
			out.close();

			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			InputSource xmlSource = new InputSource(in);

			DocumentBuilder db = Utils.getSecureDOMParser();
			Document document = db.parse(xmlSource);

			context = JAXBContext.newInstance(POLocatorV2Response.class, Error.class);
			Unmarshaller um = context.createUnmarshaller();
			Object responseObject = um.unmarshal(document);

			if (responseObject instanceof POLocatorV2Response) {
				POLocatorV2Response rsp = (POLocatorV2Response) responseObject;
				CustomLogger.debug(this.getClass(),
						"POLocator locations found = " + rsp.getLocations().getLocation().size());
				resultList.add(rsp);
			} else if (responseObject instanceof Error) {
				// If POLocator Error object returned, log error and display generic IVS error
				// message
				Error poLocatorError = (Error) responseObject;
				CustomLogger.error(this.getClass(),
						"Error response received from POLocator Web Service with description: "
								+ poLocatorError.getDescription() + " for the following input fields.  Address: "
								+ req.getAddress2() + " City: " + req.getCity() + " State: " + req.getState() + " Zip: "
								+ req.getZIP5());
				resultList.add(poLocatorError);
			} else {
				CustomLogger.error(this.getClass(), "Unexpected JAXBContext element " + responseObject);
				throw new AMSException("Unexpected JAXBContext element " + responseObject);
			}
			in.close();
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Something went wrong when calling POLocator Web Service", e);
			throw new AMSException(e.getMessage());
		}
		return resultList;
	}

	// Temporary USPS Internal GeocodeServer to get coordinates. Use until
	// replacement AMS service is available.
	private void getGisGeocoderCoordinates(AppointmentVo appointment) {

		try {
			RestTemplate restTemplate = new RestTemplate();
			SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
			factory.setProxy(proxy);
			restTemplate.setRequestFactory(factory);

			// If Address1 is empty, use alternate address stored in Address2
			String addressParam = appointment.getAddress1();

			if (StringUtils.isBlank(addressParam)) {
				addressParam = appointment.getAddress2();
			}

			String result = restTemplate.getForObject(geocoderUrlGis, String.class, addressParam, appointment.getCity(),
					appointment.getState(), appointment.getZip5());

			CustomLogger.debug(this.getClass(), "RestTemplate result = " + result);

			// "I want to iterate though the objects in the array..."
			org.json.JSONObject outerObject = new org.json.JSONObject(result);
			org.json.JSONArray innerArray = outerObject.getJSONArray("candidates");

			for (int i = 0, size = innerArray.length(); i < size; i++) {
				org.json.JSONObject objectInArray = innerArray.getJSONObject(i);

				// "...and get their component and their value."
				String[] elementNames = org.json.JSONObject.getNames(objectInArray);
				CustomLogger.debug(this.getClass(), elementNames.length + " ELEMENTS IN CURRENT OBJECT");

				for (String elementName : elementNames) {
					Object value = objectInArray.get(elementName);

					// set appointment coordinates from JSON object
					if ("location".equalsIgnoreCase(elementName) && value instanceof org.json.JSONObject) {
						setAppointmentCoordinates(appointment, elementName, value);
					} else {
						CustomLogger.debug(this.getClass(),
								"Name= " + elementName + ", Value= " + value.getClass().toString());
					}
				}
			}
		} catch (ClientWebException loClientWebEx) {
			CustomLogger.error(this.getClass(), "Response Status :- " + loClientWebEx.getResponse().getStatusCode()
					+ ", Response Message :- " + loClientWebEx.getResponse().getMessage(), loClientWebEx);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), "Error in getGeocoderCoordinates ... ", e);
		}
	}

	private void setAppointmentCoordinates(AppointmentVo appointment, String elementName, Object value) {
		CustomLogger.enter(this.getClass(), String.format("Name:%s, Value:%s", elementName, value.toString()));
		org.json.JSONObject resultJSON;
		resultJSON = (org.json.JSONObject) value;

		try {
			Double latitude = (Double) resultJSON.get("y");
			Double longitude = (Double) resultJSON.get("x");
			CustomLogger.debug(this.getClass(),
					"Latitude y coord= " + resultJSON.get("y") + ", Longitude x coord= " + resultJSON.get("x"));

			// Set coordinates from first result, which is the closest match
			appointment.setLatitude(latitude);
			appointment.setLongitude(longitude);

			CustomLogger.debug(this.getClass(), "returning... ");
		} catch (org.json.JSONException e) {
			CustomLogger.error(this.getClass(), "JSONObject[" + "x or y" + "] not found.", e);
		}
	}

	@Override
	public List<Object> getFilteredPOList(IppVo ippVo) throws AMSException {
		List<Object> poLocatortList = getPoLocationsByAddress(ippVo);
		return getPOLocatorResponse(ippVo, poLocatortList);
	}

	/**
	 * Gets list of PO Locations by ZIP Code within range where IVS Facilities List
	 * Geo Ind is Y
	 * 
	 * @param zipCode
	 *            - ZIP Code search criteria
	 * @return List<Object> - will contain POLocatorV2Response object or PO Locator
	 *         Error object
	 */
	@Override
	public List<Object> getFilteredPOListByZipCode(IppVo ippVo, String zipCode) throws AMSException {
		List<Object> poLocatortList = getPoLocationsByZipCode(ippVo,zipCode);
		return getPOLocatorResponse(ippVo, poLocatortList);
	}
	
	@Override
	public List<Object> getFilteredPOListByZipCode(IppVo ippVo) throws AMSException {
		List<Object> poLocatortList = getPoLocationsByZipCode(ippVo);
		return getPOLocatorResponse(ippVo, poLocatortList);
	}

	private List<Object> getPOLocatorResponse(IppVo ippVo, List<Object> poLocatorList) {
		List<Object> returnList = new ArrayList<>();

		List<String> facIDs = new ArrayList<>();

		for (Object obj : poLocatorList) {

			facIDs.clear();

			if (obj instanceof POLocatorV2Response) {
				POLocatorV2Response responseObj = (POLocatorV2Response) obj;
				List<Location> poLocations = responseObj.getLocations().getLocation();

				for (Location loc : poLocations) {
					facIDs.add(loc.getLocationID());
				}

				List<RefFacFacility> activeFacilitiesWithMatchingIDs = null;

				// Added to check if it is IAL2 transaction
				if (ippVo.getIal2Transaction() != null && "true".equalsIgnoreCase(ippVo.getIal2Transaction())) {
					if (ippVo.isSponsorUsingFacilitySubList()) {
						activeFacilitiesWithMatchingIDs = refFacFacilityService
								.getIAL2FacilitiesSublist(facIDs, ippVo.getSponsorId());
						CustomLogger.debug(this.getClass(), "PO Facilites sublist with IAL2 devices Count = "
								+ activeFacilitiesWithMatchingIDs.size());
					} else {
						activeFacilitiesWithMatchingIDs = refFacFacilityService.getIAL2Facilities(facIDs,
								ippVo.getSponsorId());
						CustomLogger.debug(this.getClass(), "PO Facilites main list with IAL2 devices Count = "
								+ activeFacilitiesWithMatchingIDs.size());
					}
					CustomLogger.debug(this.getClass(), "IVS Active mPOS PO Facilites with IAL2 devices Count = "
							+ activeFacilitiesWithMatchingIDs.size());
				} else if (ippVo.isSponsorCustReg() || !ippVo.isSponsorUsingFacilitySubList()) {
					// Only retrieve facilities that are in the PO locator list
					activeFacilitiesWithMatchingIDs = refFacFacilityService.getActiveFacilitiesByIds(facIDs);
					CustomLogger.debug(this.getClass(),
							"IVS Active mPOS PO Facilites Count = " + activeFacilitiesWithMatchingIDs.size());
				} else if (ippVo.isSponsorActiveIppClient() && ippVo.isSponsorUsingFacilitySubList()) {
					// Retrieve active facilities for the IPP sponsor
					activeFacilitiesWithMatchingIDs = refFacFacilityService
							.findActiveSponsorFacilitiesByIds(ippVo.getSponsorId(), facIDs);
					CustomLogger.debug(this.getClass(),
							"IVS Active Sites for Sponsor Count = " + activeFacilitiesWithMatchingIDs.size());
				}

				if (activeFacilitiesWithMatchingIDs != null) {
					returnList = matchFacilities(poLocations, activeFacilitiesWithMatchingIDs);
				}
			} else {
				returnList.add(obj);
			}
		}
		return returnList;
	}

	private List<Object> matchFacilities(List<Location> poLocations, List<RefFacFacility> facilities) {
		List<Object> filteredPOList = new ArrayList<>();

		// Locations needs to be the outer for because they are in order of closest to
		// farthest from address
		for (Location loc : poLocations) {
			for (RefFacFacility fac : facilities) {
				if (loc.getLocationID().equalsIgnoreCase(Long.toString(fac.getFacilityId()))) {
					filteredPOList.add(loc);

					// Limit Facilities displayed list to 10
					if (filteredPOList.size() == 10) {
						return filteredPOList;
					}
					break;
				}
			}
		}

		return filteredPOList;
	}

	@Override
	public List<LocationVo> getLocationVo(List<Location> poLocations) throws ParseException {
		List<LocationVo> locsVo = new ArrayList<>();
		DecimalFormat df = new DecimalFormat("###.##");

		for (Location location : poLocations) {
			LocationVo locationVo = new LocationVo();
			locationVo.setLocationType(location.getLocationType());
			locationVo.setLocationID(location.getLocationID());
			locationVo.setLocationName(location.getLocationName());
			locationVo.setAddress(String.format("%s, %s", location.getCity(), location.getState()));
			locationVo.setAddress2(location.getAddress2());
			locationVo.setCity(location.getCity());
			locationVo.setState(location.getState());
			locationVo.setZip5(location.getZIP5());
			locationVo.setZip4(location.getZIP4());
			locationVo.setFax(location.getPhoneData().getFax());
			locationVo.setParking(WordUtils.capitalizeFully(location.getParking()));
			locationVo.setDistance(df.format(Double.parseDouble(location.getGeoData().getDistance())));
			locationVo.setPhoneData(location.getPhoneData());

			// Format PO facility phone number as 999-999-9999
			String strPhone = location.getPhoneData().getPhone();
			locationVo.getPhoneData().setPhone(Utils.formatPhoneNumber(strPhone));

			List<Set> setList = location.getHours().getSet();
			String weekdayHours = "";
			for (int y = 0; y < setList.size(); y++) {
				Set set = setList.get(y);
				String name = set.getName();
				if ("BUSINESS".equalsIgnoreCase(name)) {
					// Get Weekday Hours
					if (set.getMO() != null && set.getMO().getOpen() != null && set.getMO().getClose() != null) {
						weekdayHours = DateTimeUtil.formatTime12Hr(set.getMO().getOpen().get(0)) + " - "
								+ DateTimeUtil.formatTime12Hr(set.getMO().getClose().get(0));
					}

					locationVo.setWeekdayHours(weekdayHours);

					// Get Weekend Hours
					// Hours for Saturday
					if (set.getSA().getOpen() == null) {
						locationVo.setSatHours("Closed");
					} else if (set.getSA().getOpen() != null) {
						locationVo.setSatHours(DateTimeUtil.formatTime12Hr(set.getSA().getOpen().get(0)) + " - "
								+ DateTimeUtil.formatTime12Hr(set.getSA().getClose().get(0)));
					}

					// Hours for Sunday
					if (set.getSU().getOpen() == null) {
						locationVo.setSunHours("Closed");
					} else if (set.getSU().getOpen() != null) {
						locationVo.setSunHours(DateTimeUtil.formatTime12Hr(set.getSU().getOpen().get(0)) + " - "
								+ DateTimeUtil.formatTime12Hr(set.getSU().getClose().get(0)));
					}

					break;
				}
			}

			locsVo.add(locationVo);
		}
		return locsVo;
	}

	/**
	 * Calls PO Locator for each facility in the REF_FAC_FACILITY table that is
	 * missing coordinates to retrieve the coordinates (latitude and longitude).
	 */
	public void populateGeocoordinates() {
		DecimalFormat df = new DecimalFormat("##.###");
		df.setRoundingMode(RoundingMode.DOWN);

		List<Object> poLocatorList = null;
		List<RefFacFacility> facilities = refFacFacilityService.getFacilitiesNoCoord();

		if (facilities != null) {
			CustomLogger.debug(this.getClass(), facilities.size() + " facilities were found with missing coordinates");

			for (RefFacFacility facility : facilities) {
				try {
					poLocatorList = getPoLocationByFacility(facility);
				} catch (AMSException e) {
					CustomLogger.error(this.getClass(), "Error occurred calling PO Locator for facility coordinates: ",
							e);
				}

				// Only expecting one facility
				if (poLocatorList.isEmpty()) {
					CustomLogger.error(this.getClass(),
							"No location returned for facility: " + facility.getFacilityId());
				} else if (poLocatorList.size() != 1) {
					CustomLogger.error(this.getClass(),
							"More than one location returned for facility: " + facility.getFacilityId());
				} else {

					String facilityId = Long.toString(facility.getFacilityId());

					for (Object obj : poLocatorList) {
						if (obj instanceof POLocatorV2Response) {
							POLocatorV2Response responseObj = (POLocatorV2Response) obj;
							List<Location> poLocations = responseObj.getLocations().getLocation();

							for (Location loc : poLocations) {

								CustomLogger.debug(this.getClass(), "Facility returned by PO Locator: "
										+ loc.getLocationID() + " " + loc.getLocationName());

								// Only update if the facility ids match
								if (loc.getLocationID().equals(facilityId)) {
									CustomLogger.debug(this.getClass(),
											"Geo Coordinates for Facility, Latitude: " + loc.getGeoData().getLatitude()
													+ " Longitude: " + loc.getGeoData().getLongitude());

									Double latitude = new Double(loc.getGeoData().getLatitude());
									String truncLat = df.format(latitude.doubleValue());
									Double truncLatitude = new Double(truncLat);
									facility.setLatitude(truncLatitude.doubleValue());
									CustomLogger.debug(this.getClass(),
											"Setting Latitude: " + truncLatitude.doubleValue());

									Double longitude = new Double(loc.getGeoData().getLongitude());
									String truncLong = df.format(longitude.doubleValue());
									Double truncLongitude = new Double(truncLong);
									facility.setLongitude(truncLongitude.doubleValue());
									CustomLogger.debug(this.getClass(),
											"Setting Longitude: " + truncLongitude.doubleValue());

									refFacFacilityService.update(facility);

									CustomLogger.debug(this.getClass(),
											"Coordinates successfully updated for facility: "
													+ facility.getFacilityId());
								}
							}
						}
					}
				}
			}
		}

		CustomLogger.debug(this.getClass(), "Processing of facility coordinates COMPLETE");
	}

	private List<Object> getPoLocationByFacility(RefFacFacility facility) throws AMSException {
		POLocatorV2Request req = new POLocatorV2Request();
		Filters reqFilters = new Filters();
		req.setRevision("1");
		req.setUSERID(username);
		req.setResponseDetail("ALL");
		req.setAddress2(facility.getAddrPhyAddress1());
		req.setCity(facility.getAddrPhyCityName());
		req.setState(facility.getAddrPhyStateCode());
		req.setRadius("10");
		req.setMaxLocations("5");
		reqFilters.setFacilityType(IPSPOLocatorConstants.WEB_TOOLS_API_POLOCATOR_FACILITYTYPE);
		req.setFilters(reqFilters);
		CustomLogger.debug(this.getClass(), "calling POLocator from getPoLocationByFacility...");
		return callPOLocator(req);
	}
}
