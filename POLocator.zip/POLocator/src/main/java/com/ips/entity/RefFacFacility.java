package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.DeviceTypeEnum;
import com.ips.polocator.common.IPSPOLocatorConstants;

import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the ref_fac_facility database table.
 * 
 */
@Entity
@Table(name="ref_fac_facility")
@NamedQueries({

    @NamedQuery(name="RefFacFacility.findAll", query="SELECT i FROM RefFacFacility i WHERE i.facilityId <> 0"),    
    @NamedQuery(name="RefFacFacility.findAllActiveByActivationDate", query="SELECT f FROM RefFacFacility f WHERE f.activationDate <= CURRENT_DATE AND f.facilityId <> 0 ORDER BY f.facilityId ASC"),
    @NamedQuery(name="RefFacFacility.findAllNonActiveByActivationDate", query="SELECT f FROM RefFacFacility f WHERE (f.activationDate > CURRENT_DATE OR f.activationDate IS NULL) AND f.facilityId <> 0 ORDER BY f.facilityId ASC"),    
    @NamedQuery(name="RefFacFacility.findAllActiveCountByActivationDate", query="SELECT COUNT(f) FROM RefFacFacility f WHERE f.activationDate <= CURRENT_DATE AND f.facilityId <> 0"),
    @NamedQuery(name="RefFacFacility.findAllNonActiveCountByActivationDate", query="SELECT COUNT(f) FROM RefFacFacility f WHERE (f.activationDate > CURRENT_DATE OR f.activationDate IS NULL) AND f.facilityId <> 0"),    
    @NamedQuery(name="RefFacFacility.findByZipCode", query="SELECT i FROM RefFacFacility i WHERE substring(i.addrPhyZipcode, 1, 5) = :zipCode"),
    @NamedQuery(name="RefFacFacility.findActiveByZipAndActivationDate", query="SELECT f FROM RefFacFacility f WHERE substring(f.addrPhyZipcode, 1, 5) = :zipCode AND f.activationDate <= CURRENT_DATE"),
    @NamedQuery(name="RefFacFacility.findNonActiveByZipAndActivationDate", query="SELECT f FROM RefFacFacility f WHERE substring(f.addrPhyZipcode, 1, 5) = :zipCode AND (f.activationDate > CURRENT_DATE OR f.activationDate IS NULL)"),
    @NamedQuery(name="RefFacFacility.findActiveByCityStateAndActivationDate", query="SELECT f FROM RefFacFacility f WHERE f.addrPhyCityName = :city AND f.addrPhyStateCode = :state AND f.activationDate <= CURRENT_DATE"),
    @NamedQuery(name="RefFacFacility.findNonActiveByCityStateAndActivationDate", query="SELECT f FROM RefFacFacility f WHERE f.addrPhyCityName = :city AND f.addrPhyStateCode = :state AND (f.activationDate > CURRENT_DATE OR f.activationDate IS NULL)"),      
    @NamedQuery(name="RefFacFacility.findByCityState", query="SELECT f FROM RefFacFacility f WHERE f.addrPhyCityName = :city AND f.addrPhyStateCode = :state"),
    @NamedQuery(name="RefFacFacility.findListByIds", query="SELECT i FROM RefFacFacility i WHERE i.refFacilityId IN :refFacilityIDs"),
    @NamedQuery(name="RefFacFacility.findAllNoCoord", query="SELECT i FROM RefFacFacility i WHERE i.latitude IS NULL"),
    @NamedQuery(name="RefFacFacility.findByFinanceNumber", query="SELECT i FROM RefFacFacility i WHERE i.financeNumber = :financeNumber "),
    @NamedQuery(name="RefFacFacility.findByCoordinates", query="SELECT i FROM RefFacFacility i WHERE i.latitude = :latitude AND i.longitude = :longitude"),
    // query used by the admin page to find the matching facilities using the coordinates
    @NamedQuery(name="RefFacFacility.findByGridCoordinates", 
        query="SELECT i FROM RefFacFacility i WHERE i.latitude >= :lowLatitude AND i.latitude <= :highLatitude " +
        "AND i.longitude >= :lowLongitude AND i.longitude <= :highLongitude"),
    @NamedQuery(name="RefFacFacility.findActiveFacilitiesByIds", query="SELECT f FROM RefFacFacility f WHERE f.activationDate <= CURRENT_DATE " +
            "AND f.facilityId <> 0 AND f.facilityId IN :facIDs ORDER BY f.facilityId ASC"),
    @NamedQuery(name="RefFacFacility.findByFacilityIdDeviceType", query="SELECT f FROM RefFacFacility f WHERE f.facilityId = :facilityId " +
            "AND f.deviceTypeId = :deviceType "),
    @NamedQuery(name="RefFacFacility.findByFacilityIdFinanceNumber", query="SELECT f FROM RefFacFacility f WHERE f.facilityId = :facilityId " +
            "AND f.financeNumber = :financeNumber "),
    @NamedQuery(name="RefFacFacility.findByFacilityId", query="SELECT i FROM RefFacFacility i WHERE i.facilityId = :facilityId "),
    @NamedQuery(name="RefFacFacility.findByFacilityName", query="SELECT f FROM RefFacFacility f WHERE f.facilityName LIKE :facilityName"),
    @NamedQuery(name="RefFacFacility.findGen6Facilities", query="SELECT f FROM RefFacFacility f WHERE f.deviceTypeId = :deviceTypes AND f.facilityId IN :facIDs")
 })

public class RefFacFacility implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String NOT_FOUND_FACILITY_NAME = "Facility not found";
    public static final int GEN6_DEVICE_TYPE_ID = 2;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RefFacilityIdSeq")
    @SequenceGenerator(name="RefFacilityIdSeq",sequenceName="REF_FACILITY_ID_SEQ", allocationSize=1)
    @Column(name="REF_FACILITY_ID")
    private long refFacilityId;
    
    @Column(name="FACILITY_ID")
    private long facilityId;

    @Column(name="ADDR_PHY_ADDRESS1")
    private String addrPhyAddress1;

    @Column(name="ADDR_PHY_CITY_NAME")
    private String addrPhyCityName;

    @Column(name="ADDR_PHY_STATE_CODE")
    private String addrPhyStateCode;

    @Column(name="ADDR_PHY_ZIPCODE")
    private String addrPhyZipcode;

    @Column(name="CREATE_DATE")
    private Timestamp createDate;

    @Column(name="FAC_MPOS_ENABLED")
    private String facMposEnabled;

    @Column(name="FACILITY_NAME")
    private String facilityName;

    @Column(name="UPDATE_DATE")
    private Timestamp updateDate;
    
    @Column(name="LATITUDE")
    private double latitude;
    
    @Column(name="LONGITUDE")
    private double longitude;
    
    @Column(name="INCLUDE_IN_DAILY_REPORT")
    private String includeInDailyReport;
    
    @Column(name="FINANCE_NUMBER")
    private String financeNumber;

    //@Column(name="ADMIN_OVERRIDE")
    //private String adminOverride;
    
   // @Column(name="AUTOMATION_UPDATE_DATE")
   // private Date automationUpdateDate;
    
    @Column(name="ACTIVATION_DATE")
    private Date activationDate;

    @Column(name="OLD_DISTRICT_ID")
    private long oldDistrictId;

    @Column(name="OLD_AREA_ID")
    private long oldAreaId;

    @Column(name="GEO_AREA_IND")
    private String geoAreaInd;

    //bi-directional many-to-one association to DEVICE_TYPE_ID
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="DEVICE_TYPE_ID"  , insertable = false, updatable = false )
    private RefDeviceTypes deviceType;
    
    @Column(name="DEVICE_TYPE_ID")
    private long deviceTypeId;
    
    
    //bi-directional many-to-one association to Area
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="AREA_ID")
    private RefArea area;
        
    //bi-directional many-to-one association to District
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="DISTRICT_ID")
    private RefDistrict district;

    @Transient
    private boolean selected;

    public long getRefFacilityId() {
        return refFacilityId;
    }

    public void setRefFacilityId(long refFacilityId) {
        this.refFacilityId = refFacilityId;
    }
    
    public long getFacilityId() {
        return this.facilityId;
    }

    public void setFacilityId(long facilityId) {
        this.facilityId = facilityId;
    }

    public String getAddrPhyAddress1() {
        return this.addrPhyAddress1;
    }

    public void setAddrPhyAddress1(String addrPhyAddress1) {
        this.addrPhyAddress1 = addrPhyAddress1;
    }

    public String getAddrPhyCityName() {
        return this.addrPhyCityName;
    }

    public void setAddrPhyCityName(String addrPhyCityName) {
        this.addrPhyCityName = addrPhyCityName;
    }

    public String getAddrPhyStateCode() {
        return this.addrPhyStateCode;
    }

    public void setAddrPhyStateCode(String addrPhyStateCode) {
        this.addrPhyStateCode = addrPhyStateCode;
    }

    public String getAddrPhyZipcode() {
        return this.addrPhyZipcode;
    }

    public void setAddrPhyZipcode(String addrPhyZipcode) {
        this.addrPhyZipcode = addrPhyZipcode;
    }

    public Timestamp getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public String getFacMposEnabled() {
        return this.facMposEnabled;
    }

    public void setFacMposEnabled(String facMposEnabled) {
        this.facMposEnabled = facMposEnabled;
    }

    public String getFacilityName() {
        return this.facilityName;
    }

    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName;
    }

    public Timestamp getUpdateDate() {
        return this.updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public boolean isNotFoundFacility() {
        return facilityId == 0L;
    }

    public RefArea getArea() {
        return area;
    }

    public void setArea(RefArea area) {
        this.area = area;
    }

    public RefDistrict getDistrict() {
        return district;
    }

    public void setDistrict(RefDistrict district) {
        this.district = district;
    }
    
    public String getAreaName() {
        return area == null ? IPSPOLocatorConstants.UNKNOWN : area.getAreaName();
    }
    
    public String getDistrictName() {
        return district == null ? IPSPOLocatorConstants.UNKNOWN : district.getDistrictName();
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    
    public String getZip5() {
        return getAddrPhyZipcode().substring(0, 5);
    }
    
    public String getZip4() {
        return getAddrPhyZipcode().substring(5);
    }

    public String getIncludeInDailyReport() {
        return includeInDailyReport;
    }

    public void setIncludeInDailyReport(String includeInDailyReport) {
        this.includeInDailyReport = includeInDailyReport;
    }

    public String getFinanceNumber() {
        return financeNumber;
    }

    public void setFinanceNumber(String financeNumber) {
        this.financeNumber = financeNumber;
    }

//    public String getAdminOverride() {
//		return adminOverride;
//	}
//
//	public void setAdminOverride(String adminOverride) {
//		this.adminOverride = adminOverride;
//	}

//	public Date getAutomationUpdateDate() {
//		return automationUpdateDate;
//	}
//
//	public void setAutomationUpdateDate(Date automationUpdateDate) {
//		this.automationUpdateDate = automationUpdateDate;
//	}

    public Date getActivationDate() {
        return activationDate;
    }

    public void setActivationDate(Date activationDate) {
        this.activationDate = activationDate;
    }

    public long getOldDistrictId() {
		return oldDistrictId;
	}

	public void setOldDistrictId(long oldDistrictId) {
		this.oldDistrictId = oldDistrictId;
	}

	public long getOldAreaId() {
		return oldAreaId;
	}

	public void setOldAreaId(long oldAreaId) {
		this.oldAreaId = oldAreaId;
	}

	public RefDeviceTypes getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(RefDeviceTypes deviceType) {
		this.deviceType = deviceType;
	}

	public String getGeoAreaInd() {
		return geoAreaInd;
    }

	public void setGeoAreaInd(String geoAreaInd) {
		this.geoAreaInd = geoAreaInd;
    }
    
    /**
     * facility is active if activation date is in the past
     * @return
     */
    public boolean isActive() {
        return this.getActivationDate() != null &&
                DateTimeUtil.getCurrentTime().after(this.getActivationDate());
    }
    
    public String getDeviceTypeName() {
        return getDeviceType() != null ? DeviceTypeEnum.getNickNameById(getDeviceType().getDeviceTypeId()) : null;
    }
    
    public Long getDeviceTypeId() {
         return getDeviceType() != null ? getDeviceType().getDeviceTypeId(): null;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((activationDate == null) ? 0 : activationDate.hashCode());
        result = prime * result + ((addrPhyAddress1 == null) ? 0 : addrPhyAddress1.hashCode());
        result = prime * result + ((addrPhyCityName == null) ? 0 : addrPhyCityName.hashCode());
        result = prime * result + ((addrPhyStateCode == null) ? 0 : addrPhyStateCode.hashCode());
        result = prime * result + ((addrPhyZipcode == null) ? 0 : addrPhyZipcode.hashCode());
        result = prime * result + ((area == null) ? 0 : area.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        //result = prime * result + (int) (getDeviceTypeId() ^ (getDeviceTypeId() >>> 32));
        result = prime * result + ((district == null) ? 0 : district.hashCode());
        result = prime * result + ((facMposEnabled == null) ? 0 : facMposEnabled.hashCode());
        result = prime * result + (int) (facilityId ^ (facilityId >>> 32));
        result = prime * result + ((facilityName == null) ? 0 : facilityName.hashCode());
        result = prime * result + ((financeNumber == null) ? 0 : financeNumber.hashCode());
        result = prime * result + ((includeInDailyReport == null) ? 0 : includeInDailyReport.hashCode());
        long temp;
        temp = Double.doubleToLongBits(latitude);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(longitude);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + (int) (refFacilityId ^ (refFacilityId >>> 32));
        result = prime * result + (selected ? 1231 : 1237);
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefFacFacility other = (RefFacFacility) obj;
        if (activationDate == null) {
            if (other.activationDate != null)
                return false;
        } else if (!activationDate.equals(other.activationDate))
            return false;
        if (addrPhyAddress1 == null) {
            if (other.addrPhyAddress1 != null)
                return false;
        } else if (!addrPhyAddress1.equals(other.addrPhyAddress1))
            return false;
        if (addrPhyCityName == null) {
            if (other.addrPhyCityName != null)
                return false;
        } else if (!addrPhyCityName.equals(other.addrPhyCityName))
            return false;
        if (addrPhyStateCode == null) {
            if (other.addrPhyStateCode != null)
                return false;
        } else if (!addrPhyStateCode.equals(other.addrPhyStateCode))
            return false;
        if (addrPhyZipcode == null) {
            if (other.addrPhyZipcode != null)
                return false;
        } else if (!addrPhyZipcode.equals(other.addrPhyZipcode))
            return false;
        if (area == null) {
            if (other.area != null)
                return false;
        } else if (!area.equals(other.area))
            return false;
        if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
        //if (getDeviceTypeId() != other.getDeviceTypeId())
        //    return false;
        if (district == null) {
            if (other.district != null)
                return false;
        } else if (!district.equals(other.district))
            return false;
        if (facMposEnabled == null) {
            if (other.facMposEnabled != null)
                return false;
        } else if (!facMposEnabled.equals(other.facMposEnabled))
            return false;
        if (facilityId != other.facilityId)
            return false;
        if (facilityName == null) {
            if (other.facilityName != null)
                return false;
        } else if (!facilityName.equals(other.facilityName))
            return false;
        if (financeNumber == null) {
            if (other.financeNumber != null)
                return false;
        } else if (!financeNumber.equals(other.financeNumber))
            return false;
        if (includeInDailyReport == null) {
            if (other.includeInDailyReport != null)
                return false;
        } else if (!includeInDailyReport.equals(other.includeInDailyReport))
            return false;
        if (Double.doubleToLongBits(latitude) != Double.doubleToLongBits(other.latitude))
            return false;
        if (Double.doubleToLongBits(longitude) != Double.doubleToLongBits(other.longitude))
            return false;
        if (refFacilityId != other.refFacilityId)
            return false;
        if (selected != other.selected)
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }
}