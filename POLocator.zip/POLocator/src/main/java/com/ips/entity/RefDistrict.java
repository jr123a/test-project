package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.ips.polocator.common.IPSPOLocatorConstants;


/**
 * The persistent class for the ref_district database table.
 * 
 */
@Entity
@Table(name="ref_district")
@NamedQueries({
    @NamedQuery(name="RefDistrict.findAll", query="SELECT d FROM RefDistrict d"),
    @NamedQuery(name="RefDistrict.findByDistrictId", query="SELECT d FROM RefDistrict d WHERE d.districtId = :districtId")
})
public class RefDistrict  implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DistrictSeq")
    @SequenceGenerator(name="DistrictSeq",sequenceName="SEQ_DISTRICT_ID", allocationSize=1)
    @Column(name="district_id")
    private long districtId;

    @Column(name="district_name")
    private String districtName;

    //bi-directional many-to-one association to Area
    @ManyToOne(cascade=CascadeType.REFRESH, fetch=FetchType.EAGER)
    @JoinColumn(name="area_id")
    private RefArea area;

    public long getDistrictId() {
        return districtId;
    }

    public void setDistrictId(long districtId) {
        this.districtId = districtId;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public RefArea getArea() {
        return area;
    }

    public void setArea(RefArea area) {
        this.area = area;
    }
    
    public String getAreaName() {
        return area == null ? IPSPOLocatorConstants.UNKNOWN : area.getAreaName();
    }
    
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        
        if (!(other instanceof RefDistrict)) {
            return false;
        }
        
        RefDistrict castOther = (RefDistrict)other;
        return this.districtId == castOther.districtId;
    }

    public int hashCode() {
        final int prime = 31;
        int hash = 17;
        hash = (int) (hash * prime + this.districtId);
        
        return hash;
    }
}