package com.ips.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ref_main_facility database table.
 * 
 */
@Entity
@Table(name="ref_main_facility")
@NamedQueries({
    @NamedQuery(name="RefMainFacility.findAll", query="SELECT f FROM RefMainFacility f WHERE f.facilityId <> 0"),
    @NamedQuery(name="RefMainFacility.findByFacilityId", query="SELECT f FROM RefMainFacility f WHERE f.facilityId = :facilityId ")
})

public class RefMainFacility implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String NOT_FOUND_FACILITY_NAME = "Facility not found";
    public static final int GEN6_DEVICE_TYPE_ID = 2;

    @Id
    @Column(name="REF_MAIN_FACILITY_ID")
    private long refMainFacilityId;
    
    @Column(name="FACILITY_ID")
    private long facilityId;

    @Column(name="AREA_ID")
    private long areaId;

    @Column(name="DISTRICT_ID")
    private long districtId;

    @Column(name="FACILITY_NAME")
    private String facilityName;

    @Column(name="FACILITY_ADDRESS1")
    private String facilityAddress1;

    @Column(name="FACILITY_CITY")
    private String facilityCity;

    @Column(name="FACILITY_STATE")
    private String facilityState;

    @Column(name="FACILITY_ZIP_CODE")
    private String facilityZipCode;

    @Column(name="FACILITY_STATUS")
    private String facilityStatus;

    @Column(name="FAC_TEMP_SUSP_IND")
    private String facTempSuspInd;

    @Column(name="BIORT")
    private String bioRt;

    @Column(name="BIOHR")
    private String bioHr;

    @Column(name="IPPBIOA")
    private String ippBioA;

    @Column(name="IPPBIOB")
    private String ippBioB;
       
    @Column(name="IPPA")
    private String ippA;

    @Column(name="IPPB")
    private String ippB;

    @Column(name="LATITUDE")
    private String latitude;

    @Column(name="LONGITUDE")
    private String longitude;

    @Column(name="UPDATE_DATE")
    private Date updateDate;

    @Column(name="CREATE_DATE")
    private Date createDate;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((facilityName == null) ? 0 : facilityName.hashCode());
        result = prime * result + ((facilityAddress1 == null) ? 0 : facilityAddress1.hashCode());
        result = prime * result + ((facilityCity == null) ? 0 : facilityCity.hashCode());
        result = prime * result + ((facilityState == null) ? 0 : facilityState.hashCode());
        result = prime * result + ((facilityZipCode == null) ? 0 : facilityZipCode.hashCode());
        result = prime * result + ((facilityStatus == null) ? 0 : facilityStatus.hashCode());
        result = prime * result + ((facTempSuspInd == null) ? 0 : facTempSuspInd.hashCode());
        result = prime * result + ((bioRt == null) ? 0 : bioRt.hashCode());
        result = prime * result + ((bioHr == null) ? 0 : bioHr.hashCode());
        result = prime * result + ((ippBioA == null) ? 0 : ippBioA.hashCode());
        result = prime * result + ((ippBioB == null) ? 0 : ippBioB.hashCode());
        result = prime * result + ((ippA == null) ? 0 : ippA.hashCode());
        result = prime * result + ((ippB == null) ? 0 : ippB.hashCode());
        result = prime * result + ((latitude == null) ? 0 : latitude.hashCode());
        result = prime * result + ((longitude == null) ? 0 : longitude.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        result = prime * result + ((createDate == null) ? 0 : createDate.hashCode());
        result = prime * result + (int) (refMainFacilityId ^ (refMainFacilityId >>> 32));
        result = prime * result + (int) (facilityId ^ (facilityId >>> 32));
        result = prime * result + (int) (areaId ^ (areaId >>> 32));
        result = prime * result + (int) (districtId ^ (districtId >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefMainFacility other = (RefMainFacility) obj;
        if (facilityName == null) {
            if (other.facilityName != null)
                return false;
        } else if (!facilityName.equals(other.facilityName))
            return false;
        if (facilityAddress1 == null) {
            if (other.facilityAddress1 != null)
                return false;
        } else if (!facilityAddress1.equals(other.facilityAddress1))
            return false;
        if (facilityCity == null) {
            if (other.facilityCity != null)
                return false;
        } else if (!facilityCity.equals(other.facilityCity))
            return false;
        if (facilityState == null) {
            if (other.facilityState != null)
                return false;
        } else if (!facilityState.equals(other.facilityState))
            return false;
        if (facilityZipCode == null) {
            if (other.facilityZipCode != null)
                return false;
        } else if (!facilityZipCode.equals(other.facilityZipCode))
            return false;
        if (facilityStatus == null) {
            if (other.facilityStatus != null)
                return false;
        } else if (!facilityStatus.equals(other.facilityStatus))
            return false;
        if (facTempSuspInd == null) {
            if (other.facTempSuspInd != null)
                return false;
        } else if (!facTempSuspInd.equals(other.facTempSuspInd))
            return false;
        if (bioRt == null) {
            if (other.bioRt != null)
                return false;
        } else if (!bioRt.equals(other.bioRt))
            return false;
        if (bioHr == null) {
            if (other.bioHr != null)
                return false;
        } else if (!bioHr.equals(other.bioHr))
            return false;
        if (ippBioA == null) {
            if (other.ippBioA != null)
                return false;
        } else if (!ippBioA.equals(other.ippBioA))
            return false; 
        if (ippBioB == null) {
            if (other.ippBioB != null)
                return false;
        } else if (!ippBioB.equals(other.ippBioB))
            return false;
        if (ippA == null) {
            if (other.ippA != null)
                return false;
        } else if (!ippA.equals(other.ippA))
            return false;
        if (ippB == null) {
            if (other.ippB != null)
                return false;
        } else if (!ippB.equals(other.ippB))
            return false;
        if (latitude == null) {
            if (other.latitude != null)
                return false;
        } else if (!latitude.equals(other.latitude))
            return false;
        if (longitude == null) {
            if (other.longitude != null)
                return false;
        } else if (!longitude.equals(other.longitude))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        } else if (!updateDate.equals(other.updateDate))
            return false;
       if (createDate == null) {
            if (other.createDate != null)
                return false;
        } else if (!createDate.equals(other.createDate))
            return false;
       if (refMainFacilityId != other.refMainFacilityId)
           return false;
       if (facilityId != other.facilityId)
           return false;
       if (areaId != other.areaId)
           return false;
       if (districtId != other.districtId)
           return false;
       
        return true;
    }

	public long getRefMainFacilityId() {
		return refMainFacilityId;
	}

	public void setRefMainFacilityId(long refMainFacilityId) {
		this.refMainFacilityId = refMainFacilityId;
	}

	public long getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(long facilityId) {
		this.facilityId = facilityId;
	}

	public long getAreaId() {
		return areaId;
	}

	public void setAreaId(long areaId) {
		this.areaId = areaId;
	}

	public long getDistrictId() {
		return districtId;
	}

	public void setDistrictId(long districtId) {
		this.districtId = districtId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getFacilityAddress1() {
		return facilityAddress1;
	}

	public void setFacilityAddress1(String facilityAddress1) {
		this.facilityAddress1 = facilityAddress1;
	}

	public String getFacilityCity() {
		return facilityCity;
	}

	public void setFacilityCity(String facilityCity) {
		this.facilityCity = facilityCity;
	}

	public String getFacilityState() {
		return facilityState;
	}

	public void setFacilityState(String facilityState) {
		this.facilityState = facilityState;
	}

	public String getFacilityZipCode() {
		return facilityZipCode;
	}

	public void setFacilityZipCode(String facilityZipCode) {
		this.facilityZipCode = facilityZipCode;
	}

	public String getFacilityStatus() {
		return facilityStatus;
	}

	public void setFacilityStatus(String facilityStatus) {
		this.facilityStatus = facilityStatus;
	}

	public String getFacTempSuspInd() {
		return facTempSuspInd;
	}

	public void setFacTempSuspInd(String facTempSuspInd) {
		this.facTempSuspInd = facTempSuspInd;
	}

	public String getBioRt() {
		return bioRt;
	}

	public void setBioRt(String bioRt) {
		this.bioRt = bioRt;
	}

	public String getBioHr() {
		return bioHr;
	}

	public void setBioHr(String bioHr) {
		this.bioHr = bioHr;
	}

	public String getIppBioB() {
		return ippBioB;
	}

	public void setIppBioB(String ippBioB) {
		this.ippBioB = ippBioB;
	}

	public String getIppBioA() {
		return ippBioA;
	}

	public void setIppBioA(String ippBioA) {
		this.ippBioA = ippBioA;
	}

	public String getIppA() {
		return ippA;
	}

	public void setIppA(String ippA) {
		this.ippA = ippA;
	}

	public String getIppB() {
		return ippB;
	}

	public void setIppB(String ippB) {
		this.ippB = ippB;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

}