package com.ips.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the ref_area database table.
 * 
 */
@Entity
@Table(name="ref_area")
@NamedQueries({
    @NamedQuery(name="RefArea.findAll", query="SELECT a FROM RefArea a"),
    @NamedQuery(name="RefArea.findByAreaId", query="SELECT a FROM RefArea a WHERE a.areaId = :areaId")
})
public class RefArea  implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AreaSeq")
    @SequenceGenerator(name="AreaSeq",sequenceName="SEQ_AREA_ID", allocationSize=1)
    @Column(name="area_id")
    private long areaId;

    @Column(name="area_name")
    private String areaName;

    public long getAreaId() {
        return areaId;
    }

    public void setAreaId(long areaId) {
        this.areaId = areaId;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }
    
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        
        if (!(other instanceof RefArea)) {
            return false;
        }
        
        RefArea castOther = (RefArea)other;
        return this.areaId == castOther.areaId;
    }

    public int hashCode() {
        final int prime = 31;
        int hash = 17;
        hash = (int) (hash * prime + this.areaId);
        
        return hash;
    }
}