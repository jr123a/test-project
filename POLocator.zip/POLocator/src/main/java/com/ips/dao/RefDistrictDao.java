package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefDistrict;

public interface RefDistrictDao {

	Collection<RefDistrict> findAll();
	RefDistrict getById(Long id);
	RefDistrict findByDistrictId(long areaId);
	void save(RefDistrict entity);
	void delete(RefDistrict entity);
	void update(RefDistrict entity);
}
