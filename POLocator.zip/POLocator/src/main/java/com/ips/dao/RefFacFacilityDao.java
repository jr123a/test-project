package com.ips.dao;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.ips.entity.RefFacFacility;
import com.ips.exception.IPSException;
import com.ips.polocator.common.MainFacilityFinanceVo;

public interface RefFacFacilityDao {

    RefFacFacility getById(Long id);
    List<RefFacFacility> getAllFacilitiesByActivationDate(boolean active, int firstResult, int maxResults);
    Long getAllFacilitiesCountByActivationDate(boolean active);
    List<RefFacFacility> findByZipAndActivationDate(String zipCode, boolean active);
    List<RefFacFacility> findByCityStateAndActivationDate(String city, String state, boolean active);
    List<RefFacFacility> findByCityState(String city, String state);
    int updateAllFacilities(Date activationDate, boolean activate);
    void save(RefFacFacility entity);
    void delete(RefFacFacility entity);
    void update(RefFacFacility entity);
    Collection<RefFacFacility> getAll();
    Collection<RefFacFacility> findByZipCode(String zipCode);
    int updateActivationDate(List<String> refFacilityIdList, List<Date> activationDateList);
    List<String> updatedFacilityIdList(List<String> refFacilityIdList, List<Date> activationDateList);
    List<RefFacFacility> getFacilitiesByIds(List<String> refFacilityIDs);
    List<RefFacFacility> getFacilitiesNoCoord();
    RefFacFacility findByFinanceNumber(String financeNumber) throws IPSException;
    RefFacFacility findByCoordinates(double latitude, double longitude) throws IPSException;
    List<RefFacFacility> findByGridCoordinates(double lowLatitude, double highLatitude, double lowLongitude, double highLongitude);
    List<RefFacFacility> getActiveFacilitiesByIds(List<String> facIDs);
    List<BigDecimal> findUniqueFacilityIdByGridCoordinates(double lowLatitude, double highLatitude, double lowLongitude, double highLongitude);
    RefFacFacility findByFacilityIdDeviceType(long facilityId, long deviceType);
    RefFacFacility findByFacilityIdFinanceNumber(long facilityId, String financeNumber);
    RefFacFacility findWithUpdatedFinanceNumber(long facilityId, long deviceTypeId);
    List<RefFacFacility> findByFacilityId(long facilityId);
    List<RefFacFacility> findByFacilityName(String facilityName);
    List<String> findActiveSponsorFacilityIds(long sponsorId, List<String> facIDs);
    List<RefFacFacility> getGen6Facilities(List<String> facIDs, long sponsorId);
    List<MainFacilityFinanceVo> getNewRecordsFromMainFacilities();
    List<RefFacFacility> getFinanceNumForUpdateFromStagingFacilities();
    List<RefFacFacility> getNodelessByFinanceNumFacilities();
    List<RefFacFacility> getMultiNodeFacilities();
    List<RefFacFacility> getNodelessByMposDeviceFacilities();
    List<RefFacFacility> getNodelessByPosDeviceFacilities();
    List<RefFacFacility> getAdminOverriddenFacilities();
    List<RefFacFacility> getFacilityIdNotInStagingFacilities();
    List<RefFacFacility> getFinanceNumNotInStagingFacilities();
    List<RefFacFacility> getSinglePOSChannelFacilities();
    List<RefFacFacility> getSingleMPOSChannelFacilities();
	List<RefFacFacility> getIAL2Facilities(List<String> facIDs, long sponsorId);
	List<RefFacFacility> getIAL2FacilitiesSublist(List<String> facIDs, long sponsorId);
 }
