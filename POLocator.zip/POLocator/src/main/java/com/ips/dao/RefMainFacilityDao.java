package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefMainFacility;

public interface RefMainFacilityDao {

	Collection<RefMainFacility> getAll();
	RefMainFacility getById(Long id);
	RefMainFacility findByFacilityId(long facilityId);
	void save(RefMainFacility entity);
	void delete(RefMainFacility entity);
	void update(RefMainFacility entity);
}
