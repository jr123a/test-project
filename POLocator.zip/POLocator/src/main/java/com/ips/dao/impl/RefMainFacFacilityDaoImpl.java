package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefMainFacilityDao;
import com.ips.entity.RefMainFacility;

@Repository
public class RefMainFacFacilityDaoImpl extends GenericJPADAO<RefMainFacility, String> implements RefMainFacilityDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefMainFacility> getAll() {
        Query query = em.createNamedQuery("RefFacFacility.findAll");
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public RefMainFacility findByFacilityId(long facilityId) {
    	RefMainFacility entity = null;

        Query query = em.createNamedQuery("RefMainFacility.findByFacilityId");
        query.setParameter("facilityId", facilityId);

        List<RefMainFacility> list = query.getResultList();
        Optional<RefMainFacility> result = list.stream().findFirst();

        if (result.isPresent()) {
        	entity = result.get();
        }

        return entity;
    }

	@Override
	public void update(RefMainFacility entity) {
		super.merge(entity);	
	}

	@Override
	public RefMainFacility getById(Long id) {
		return super.getById(id);
	} 
}
