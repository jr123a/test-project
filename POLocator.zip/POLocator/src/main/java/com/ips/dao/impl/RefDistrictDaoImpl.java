package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefDistrictDao;
import com.ips.entity.RefDistrict;

@Repository
public class RefDistrictDaoImpl extends GenericJPADAO<RefDistrict, String> implements RefDistrictDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefDistrict> findAll() {
        Query query = em.createNamedQuery("RefDistrict.findAll");
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public RefDistrict findByDistrictId(long districtId) {
    	RefDistrict entity = null;

        Query query = em.createNamedQuery("RefDistrict.findByDistrictId");
        query.setParameter("districtId", districtId);

        List<RefDistrict> list = query.getResultList();
        Optional<RefDistrict> result = list.stream().findFirst();

        if (result.isPresent()) {
        	entity = result.get();
        }

        return entity;
    }

    @Override
    public void update(RefDistrict entity) {
        super.merge(entity);
    }

	@Override
	public RefDistrict getById(Long id) {
		return super.getById(id);
	}

}
