
package com.ips.dao;

import java.util.List;

import com.ips.entity.RefDeviceTypes;

public interface RefDeviceTypesDao {

    List<RefDeviceTypes> getDeviceList();
    
    RefDeviceTypes getDeviceTypeById(long deviceID);

}
