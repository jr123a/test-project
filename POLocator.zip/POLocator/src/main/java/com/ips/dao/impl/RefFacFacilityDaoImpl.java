package com.ips.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.common.common.DateTimeUtil;
import com.ips.dao.RefFacFacilityDao;
import com.ips.entity.RefFacFacility;
import com.ips.exception.IPSException;
import com.ips.polocator.common.MainFacilityFinanceVo;

@Repository
public class RefFacFacilityDaoImpl extends GenericJPADAO<RefFacFacility, String> implements RefFacFacilityDao {

	private static final String NEW_RECORDS_FROM_MAIN_FACILITIES = "NewRecordsFromMainFacilities";
	private static final String NEW_RECORDS_FROM_STAGING_FACILITIES = "NewRecordsFromStagingFacilities";
	private static final String FINANCE_NUM_FOR_UPDATE_FROM_STAGING = "FinanceNumForUpdateFrom_Staging";
	private static final String NODELESS_BY_FINNUM_FACILITIES = "NodelessByFinNumFacilities";
	private static final String MULTI_NODE_FACILITIES = "MultiNodeFacilities";
	private static final String NODELESS_BY_MPOS_DEVICE_FACILITIES = "NodelessByMposDeviceFacilities";
	private static final String NODELESS_BY_POS_DEVICE_FACILITIES = "NodelessByPosDeviceFacilities";
	private static final String MANUAL_FACILITIES = "ManualFacilities";
	private static final String ADMIN_OVERRIDDEN_FACILITIES = "AdminOverriddenFacilities";
	private static final String FACILITY_ID_NOT_IN_STAGING_FACILITIES = "FacilityIdNotInStagingFacilities";
	private static final String FINANCE_NUM_NOT_IN_STAGING_FACILITIES = "FinanceNumNotInStagingFacilities";
	private static final String SINGLE_CHANNEL_FACILITIES = "SingleChannelFacilities";
		
    @Override
    public RefFacFacility getById(Long id) {
        return super.getById(id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> getAllFacilitiesByActivationDate(boolean active, int firstResult, int maxResults) {
        String namedQuery = active ? "RefFacFacility.findAllActiveByActivationDate"
                : "RefFacFacility.findAllNonActiveByActivationDate";
        Query query = em.createNamedQuery(namedQuery);
        query.setFirstResult(firstResult);
        query.setMaxResults(maxResults);
        return query.getResultList();
    }

    @Override
    public Long getAllFacilitiesCountByActivationDate(boolean active) {
        String namedQuery = active ? "RefFacFacility.findAllActiveCountByActivationDate"
                : "RefFacFacility.findAllNonActiveCountByActivationDate";
        Query query = em.createNamedQuery(namedQuery);
        return (Long) query.getSingleResult();
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefFacFacility> getAll() {
        Query query = em.createNamedQuery("RefFacFacility.findAll");
        return query.getResultList();
    }

    @Override
    public void update(RefFacFacility refFacFacility) {
        super.merge(refFacFacility);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefFacFacility> findByZipCode(String zipCode) {
        Query query = em.createNamedQuery("RefFacFacility.findByZipCode").setParameter("zipCode", zipCode);
        List<RefFacFacility> results = query.getResultList();
        if (results.isEmpty()) {
            return Collections.emptyList();          
        } 
        else {
            return results;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> findByZipAndActivationDate(String zipCode, boolean active) {
        String namedQuery = active ? "RefFacFacility.findActiveByZipAndActivationDate"
                : "RefFacFacility.findNonActiveByZipAndActivationDate";
        Query query = em.createNamedQuery(namedQuery)
                .setParameter("zipCode", zipCode);        
        List<RefFacFacility> results = query.getResultList();
        if (results.isEmpty()) {
            return Collections.emptyList(); 
        } 
        else {
            return results;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> findByCityStateAndActivationDate(String city, String state, boolean active) {
        String namedQuery = active ? "RefFacFacility.findActiveByCityStateAndActivationDate" : "RefFacFacility.findNonActiveByCityStateAndActivationDate";
        Query query = em.createNamedQuery(namedQuery)
                .setParameter("city", city)
                .setParameter("state", state);
        List<RefFacFacility> results = query.getResultList();
        if (results.isEmpty()) {
            return Collections.emptyList(); 
        } 
        else {
            return results;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> findByCityState(String city, String state) {
        Query query = em.createNamedQuery("RefFacFacility.findByCityState").setParameter("city", city)
                .setParameter("state", state);
        List<RefFacFacility> results = query.getResultList();
        
        if (results.isEmpty()) {
            return Collections.emptyList(); 
        } 
        else {
            return results;
        }
    }

    @Override
    public int updateAllFacilities(Date activationDate, boolean activate) {
    	String whereClause = activate ? 
    			"WHERE (i.activationDate > CURRENT_DATE OR i.activationDate IS NULL) AND i.facilityId <> 0" :
                "WHERE i.activationDate <= CURRENT_DATE AND i.facilityId <> 0";
                    
    	String jpqlString  = "UPDATE RefFacFacility i " +
                "SET i.activationDate = :activationDate, "
                //+ "i.automationUpdateDate = :automationUpdateDate, "
        		+ "i.adminOverride = :adminOverride, i.updateDate = :updateDate " 
                + whereClause; 
                        
        Object currentDatetime = new Timestamp(new Date().getTime());
        Query query = em.createQuery(jpqlString)
        .setParameter("activationDate", activationDate)
        //.setParameter("automationUpdateDate", currentDatetime)
        .setParameter("adminOverride", activate? "N" : "Y")
        .setParameter("updateDate", currentDatetime);

        return query.executeUpdate();
    }

    @Override
    public int updateActivationDate(List<String> refFacilityIdList, List<Date> activationDateList) {
        int index = 0;
        for (String id : refFacilityIdList) {
            Long facilityId = Long.valueOf(id);
            RefFacFacility entity = getById(facilityId);
            java.sql.Date sActivateDate = new java.sql.Date(activationDateList.get(index).getTime());
            entity.setActivationDate(sActivateDate);
            entity.setUpdateDate(DateTimeUtil.getCurrentTime());
            super.save(entity);
            index++;
        }
        return index;
    }
    
    @Override
    public List<String> updatedFacilityIdList(List<String> refFacilityIdList, List<Date> activationDateList) {
        int index = 0;
        List<String> updatedFacilityIdList = new ArrayList<>();
        
        for(String id : refFacilityIdList) {
            Long facilityId = Long.valueOf(id);
            RefFacFacility entity = getById(facilityId);
            Date inputActivateDate = activationDateList.get(index);
            Date currActivateDate = entity.getActivationDate();
            java.sql.Date activateDate = new java.sql.Date(inputActivateDate.getTime());
            index++;
            
            if (!inputActivateDate.toString().equals(currActivateDate.toString())) {
                entity.setActivationDate(activateDate);
                //entity.setAutomationUpdateDate(DateTimeUtil.getCurrentDate());
                //entity.setAdminOverride("Y");
                entity.setUpdateDate(DateTimeUtil.getCurrentTime());
                super.save(entity);  

                updatedFacilityIdList.add(id);
            }
        }
        return updatedFacilityIdList;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> getFacilitiesByIds(List<String> refFacilityIDs) {
        Query query = em.createNamedQuery("RefFacFacility.findListByIds").setParameter("refFacilityIDs",
                refFacilityIDs);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> getFacilitiesNoCoord() {
        Query query = em.createNamedQuery("RefFacFacility.findAllNoCoord");
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public RefFacFacility findByFinanceNumber(String financeNumber) throws IPSException {
        RefFacFacility facility = null;

        Query query = em.createNamedQuery("RefFacFacility.findByFinanceNumber");
        query.setParameter("financeNumber", financeNumber);

        List<RefFacFacility> list = query.getResultList();
        Optional<RefFacFacility> result = list.stream().findFirst();

        if (result.isPresent()) {
            facility = result.get();
        }

        return facility;
    }

    @SuppressWarnings("unchecked")
    @Override
    public RefFacFacility findByCoordinates(double latitude, double longitude) throws IPSException {
        RefFacFacility facility = null;

        Query query = em.createNamedQuery("RefFacFacility.findByCoordinates");
        query.setParameter("latitude", latitude);
        query.setParameter("longitude", longitude);

        List<RefFacFacility> results = query.getResultList();

        if (!results.isEmpty()) {
            if (results.size() > 1) {
                throw new IPSException("More than one facility found for coordinates");
            } else {
                facility = results.get(0);
            }
        }

        return facility;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> findByGridCoordinates(double lowLatitude, double highLatitude, double lowLongitude,
            double highLongitude) {
        Query query = em.createNamedQuery("RefFacFacility.findByGridCoordinates");
        query.setParameter("lowLatitude", lowLatitude);
        query.setParameter("highLatitude", highLatitude);
        query.setParameter("lowLongitude", lowLongitude);
        query.setParameter("highLongitude", highLongitude);

        List<RefFacFacility> results = query.getResultList();
        if (results.isEmpty()) {
            return Collections.emptyList();
        } else {
            return results;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> getActiveFacilitiesByIds(List<String> facIDs) {
        Query query = em.createNamedQuery("RefFacFacility.findActiveFacilitiesByIds").setParameter("facIDs", facIDs);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<BigDecimal> findUniqueFacilityIdByGridCoordinates(double lowLatitude, double highLatitude,
            double lowLongitude, double highLongitude) {

        Query query = em.createNativeQuery("SELECT DISTINCT f.facility_id " +
                "FROM ref_fac_facility f " +
                "WHERE latitude >= ? AND latitude <= ? " +
                "AND longitude >= ? AND longitude <= ? " +
                "AND device_type_id in (1,2) ");
        
        query.setParameter(1, lowLatitude);
        query.setParameter(2, highLatitude);
        query.setParameter(3, lowLongitude);
        query.setParameter(4, highLongitude);

        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public RefFacFacility findByFacilityIdDeviceType(long facilityId, long deviceType) {
        Query query = em.createNamedQuery("RefFacFacility.findByFacilityIdDeviceType");
        query.setParameter("facilityId", facilityId);
        query.setParameter("deviceType", deviceType);

        List<RefFacFacility> list = query.getResultList();
        Optional<RefFacFacility> result = list.stream().findFirst();
        RefFacFacility entity = null;
        
        if (result.isPresent()) {
        	entity = result.get();
        }

        return entity;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public RefFacFacility findByFacilityIdFinanceNumber(long facilityId, String financeNumber) {
        Query query = em.createNamedQuery("RefFacFacility.findByFacilityIdFinanceNumber");
        query.setParameter("facilityId", facilityId);
        query.setParameter("financeNumber", financeNumber);

        List<RefFacFacility> list = query.getResultList();
        Optional<RefFacFacility> result = list.stream().findFirst();
        RefFacFacility entity = null;
        
        if (result.isPresent()) {
        	entity = result.get();
        }

        return entity;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> findByFacilityId(long facilityId) {
        Query query = em.createNamedQuery("RefFacFacility.findByFacilityId");
        query.setParameter("facilityId", facilityId);

        List<RefFacFacility> results = query.getResultList();
        if (results.isEmpty()) {
            return Collections.emptyList();
        } else {
            return results;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> findByFacilityName(String facilityName) {
        Query query = em.createNamedQuery("RefFacFacility.findByFacilityName").setParameter("facilityName",
                "%" + facilityName + "%");
        List<RefFacFacility> results = query.getResultList();
        
        if (results.isEmpty()) {
            return Collections.emptyList(); 
        } 
        else {
            return results;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<String> findActiveSponsorFacilityIds(long sponsorId, List<String> facIDs) {

        Query query = em.createNativeQuery("SELECT f.ref_facility_id " +
                "FROM sponsor_facilities s, ref_fac_facility f " +
                "WHERE s.ref_facility_id = f.ref_facility_id " +
                "AND s.activation_date <= CURRENT_DATE " + 
                "AND facility_id IN (" + createCommaSeparatedList(facIDs) + ") " +
                "AND sponsor_id = ? ");
         
        query.setParameter(1, sponsorId);

        return query.getResultList();
    }

    private String createCommaSeparatedList(List<String> facIDs) {
        StringBuilder sb = new StringBuilder();

        for (String facilityId : facIDs) {
            sb.append(facilityId + ",");
        }

        return sb.substring(0, sb.length() - 1);
    }
    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> getGen6Facilities(List<String> facIDs, long sponsorId) {
        String sqlString = "select f.FACILITY_ID,f.FACILITY_NAME,f.ADDR_PHY_ADDRESS1,f.ADDR_PHY_CITY_NAME,f.ADDR_PHY_STATE_CODE,f.ADDR_PHY_ZIPCODE,f.FAC_MPOS_ENABLED,f.CREATE_DATE,f.UPDATE_DATE,f.LATITUDE,f.LONGITUDE,f.AREA_ID,"
                + " f.DISTRICT_ID,f.INCLUDE_IN_DAILY_REPORT,f.FINANCE_NUMBER,f.ACTIVATION_DATE,f.REF_FACILITY_ID,f.DEVICE_TYPE_ID,f.GEO_AREA_IND\r\n"
                + " from IPS_OWN.REF_FAC_FACILITY f"
                + " inner join sponsor_facilities s on s.REF_FACILITY_ID = f.REF_FACILITY_ID "
                + " where DEVICE_TYPE_ID = ?" + " AND f.FACILITY_ID IN (" + createCommaSeparatedList(facIDs) + " ) AND s.SPONSOR_ID=? and s.ACTIVATION_DATE <= sysdate ";
        Query q = em.createNativeQuery(sqlString, RefFacFacility.class);
        q.setParameter(1, RefFacFacility.GEN6_DEVICE_TYPE_ID);
        q.setParameter(2, sponsorId);
        return q.getResultList();
    }    
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> getIAL2Facilities(List<String> facIDs, long sponsorId) {
        String sqlString = "select f.FACILITY_ID,f.FACILITY_NAME,f.ADDR_PHY_ADDRESS1,f.ADDR_PHY_CITY_NAME,f.ADDR_PHY_STATE_CODE,f.ADDR_PHY_ZIPCODE,f.FAC_MPOS_ENABLED,f.CREATE_DATE,f.UPDATE_DATE,f.LATITUDE,f.LONGITUDE,f.AREA_ID,"
                + " f.DISTRICT_ID,f.INCLUDE_IN_DAILY_REPORT,f.FINANCE_NUMBER,f.ACTIVATION_DATE,f.REF_FACILITY_ID,f.DEVICE_TYPE_ID,f.GEO_AREA_IND"
                + " from IPS_OWN.REF_FAC_FACILITY f"
                + " where DEVICE_TYPE_ID IN (select DEVICE_TYPE_ID from APPLICATION_WORKFLOWS where WORKFLOW_ID in ( select WORKFLOW_ID from REF_IPP_WORKFLOWS where ASSURANCE_LEVEL = 2))" 
                + " AND f.FACILITY_ID IN (" + createCommaSeparatedList(facIDs) + " ) and f.ACTIVATION_DATE <= sysdate";
        Query q = em.createNativeQuery(sqlString, RefFacFacility.class);
        q.setParameter(1, sponsorId);
        return q.getResultList();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<RefFacFacility> getIAL2FacilitiesSublist(List<String> facIDs, long sponsorId) {
        String sqlString = "select f.FACILITY_ID,f.FACILITY_NAME,f.ADDR_PHY_ADDRESS1,f.ADDR_PHY_CITY_NAME,f.ADDR_PHY_STATE_CODE,f.ADDR_PHY_ZIPCODE,f.FAC_MPOS_ENABLED,f.CREATE_DATE,f.UPDATE_DATE,f.LATITUDE,f.LONGITUDE,f.AREA_ID,"
                + " f.DISTRICT_ID,f.INCLUDE_IN_DAILY_REPORT,f.FINANCE_NUMBER,f.ACTIVATION_DATE,f.REF_FACILITY_ID,f.DEVICE_TYPE_ID,f.GEO_AREA_IND"
                + " from IPS_OWN.REF_FAC_FACILITY f"
                + " inner join sponsor_facilities s on s.REF_FACILITY_ID = f.REF_FACILITY_ID "
                + " where DEVICE_TYPE_ID IN (select DEVICE_TYPE_ID from APPLICATION_WORKFLOWS where WORKFLOW_ID in ( select WORKFLOW_ID from REF_IPP_WORKFLOWS where ASSURANCE_LEVEL = 2))" 
                + " AND f.FACILITY_ID IN (" + createCommaSeparatedList(facIDs) + " ) AND s.SPONSOR_ID=? and s.ACTIVATION_DATE <= sysdate ";
        Query q = em.createNativeQuery(sqlString, RefFacFacility.class);
        q.setParameter(1, sponsorId);
        return q.getResultList();
    }
    @SuppressWarnings("unchecked")
    @Override
    public RefFacFacility findWithUpdatedFinanceNumber(long facilityId, long deviceTypeId) {
    	StringBuilder sqlSb = new StringBuilder();
    	sqlSb.append("SELECT * FROM ips_own.ref_fac_facility rf ");
    	sqlSb.append("LEFT JOIN  ips_own.ipp_facility_staging  fs ");
    	sqlSb.append("ON rf.finance_number = fs.ufn  ");
    	sqlSb.append("WHERE fs.ufn IS NULL AND rf.finance_number IS NOT NULL ");
    	sqlSb.append("AND rf.facility_id = ? AND rf.device_type_id = ?");
       
        Query query = em.createNativeQuery(sqlSb.toString(), RefFacFacility.class);
        query.setParameter(1, facilityId);
        query.setParameter(2, deviceTypeId);

        List<RefFacFacility> list = query.getResultList();
        Optional<RefFacFacility> result = list.stream().findFirst();
        RefFacFacility entity = null;
        
        if (result.isPresent()) {
        	entity = result.get();
        }

        return entity;
    }
   
    @Override
    public List<RefFacFacility> getNodelessByFinanceNumFacilities() {  
    	String sql = getSql(NODELESS_BY_FINNUM_FACILITIES); 
        return getRefFacFacilityList(sql);
    }
    
    @Override
    public List<RefFacFacility> getNodelessByMposDeviceFacilities() {  
    	String sql = getSql(NODELESS_BY_MPOS_DEVICE_FACILITIES); 
        return getRefFacFacilityList(sql);
    }
    
    @Override
    public List<RefFacFacility> getNodelessByPosDeviceFacilities() {  
    	String sql = getSql(NODELESS_BY_POS_DEVICE_FACILITIES); 
        return getRefFacFacilityList(sql);
    }
     
    @Override
    public List<RefFacFacility> getMultiNodeFacilities() {      
    	String sql = getSql(MULTI_NODE_FACILITIES);
        return getRefFacFacilityList(sql);
    }
    
    @Override
    public List<RefFacFacility> getAdminOverriddenFacilities() {      
    	String sql = getSql(ADMIN_OVERRIDDEN_FACILITIES);
        return getRefFacFacilityList(sql);
    }
    
	@Override
    public List<RefFacFacility> getFinanceNumForUpdateFromStagingFacilities() { 
    	String sql = "SELECT rfo.* FROM (";
    	sql += getSql(FINANCE_NUM_FOR_UPDATE_FROM_STAGING);
        return getRefFacFacilityList(sql);
    }

    
    @SuppressWarnings("unchecked")
	@Override
    public List<MainFacilityFinanceVo> getNewRecordsFromMainFacilities() {      
     	String sql = getSql(NEW_RECORDS_FROM_MAIN_FACILITIES);
        Query query = em.createNativeQuery(sql, MainFacilityFinanceVo.class);
 
        return query.getResultList();
    }
 
    @Override
    public List<RefFacFacility> getFacilityIdNotInStagingFacilities() {      
    	String sql = getSql(FACILITY_ID_NOT_IN_STAGING_FACILITIES);
        return getRefFacFacilityList(sql);
    }
    
    @Override
    public List<RefFacFacility> getFinanceNumNotInStagingFacilities() {      
    	String sql = getSql(FINANCE_NUM_NOT_IN_STAGING_FACILITIES);
        return getRefFacFacilityList(sql);
    }
    
    @Override
    public List<RefFacFacility> getSinglePOSChannelFacilities() {
      	StringBuilder sqlSb = new StringBuilder();
	    sqlSb.append("AND fso.channel = 'POS' AND rf.device_type_id IN (1, 2) ");
	
	    String sql = getSql(SINGLE_CHANNEL_FACILITIES) + sqlSb.toString();
        return getRefFacFacilityList(sql);
   }
    
    @Override
    public List<RefFacFacility> getSingleMPOSChannelFacilities() {      
     	StringBuilder sqlSb = new StringBuilder();
	    sqlSb.append("AND fso.channel = 'MPOS' AND rf.device_type_id = 3 ");

    	String sql = getSql(SINGLE_CHANNEL_FACILITIES) + sqlSb.toString();
        return getRefFacFacilityList(sql);
    }
     
	@SuppressWarnings("unchecked")
	private List<RefFacFacility> getRefFacFacilityList(String sql) {    
         Query query = em.createNativeQuery(sql, RefFacFacility.class);
   
        return query.getResultList();
    }
    
    private String getSql(String sqlName) {      
    	StringBuilder sqlSb = new StringBuilder();
    	
    	switch (sqlName) {
  		case NEW_RECORDS_FROM_MAIN_FACILITIES:   //Scenario #1
  			sqlSb.append("SELECT mf.facility_id as facilityId, fsoo.ufn as financeNumber, ");
  			sqlSb.append("mf.facility_name as facilityName, mf.facility_address1 as facilityAddress, ");
  			sqlSb.append("mf. facility_city as facilityCity, mf.facility_state as facilityState, ");
  			sqlSb.append("mf.facility_zip_code as facilityZipCode ");
  			sqlSb.append("FROM ips_own.ref_main_facility mf ");
  			sqlSb.append("INNER JOIN ");
  			
			//B. Select records from ipp_facility_staging where facility_id and channel (device type)
  			//are not in ref_fac_facility table
   			sqlSb.append("(SELECT fso.* FROM ( ");
  			
  			//C. Select records from ipp_facility_staging where facility_id and ufn (finance_number)
  			//   are not in ref_fac_facility table
  			sqlSb.append("SELECT fs.* FROM ips_own.ipp_facility_staging fs ");
  			sqlSb.append("LEFT JOIN ips_own.ref_fac_facility rf ");
  			sqlSb.append("ON fs.facility_id = rf.facility_id AND fs.ufn = rf.finance_number ");
  			sqlSb.append("WHERE rf.facility_id IS NULL AND rf.finance_number IS NULL ");
  			//C. ends
  			
  			sqlSb.append(") fso ");
  			sqlSb.append("LEFT JOIN (SELECT rf.*, CASE WHEN rf.device_type_id = 3 THEN 'POS' ELSE 'MPOS' END channel ");
  			sqlSb.append("FROM ips_own.ref_fac_facility rf) rfo ");
  			sqlSb.append("ON fso.facility_id = rfo.facility_id AND fso.channel = rfo.channel ");
  			sqlSb.append("WHERE rfo.facility_id IS NULL AND rfo.channel IS NULL) fsoo ");
  		    //B. ends
  			
  			sqlSb.append("ON mf.facility_id = fsoo.facility_id ");
  			//A. ends
  			break;
    	case NEW_RECORDS_FROM_STAGING_FACILITIES:   //Scenario #2  
			//A. Select records from ipp_facility_staging where facility_id is not in ref_main_facility table
     		sqlSb.append("SELECT fsoo.* FROM (SELECT fso.* FROM (");
     		
 			//B. Select records from ipp_facility_staging where facility_id and ufn (finance_number)
  			//   are not in ref_fac_facility table
     		sqlSb.append("SELECT fs.* FROM ips_own.ipp_facility_staging fs ");
     		sqlSb.append("LEFT JOIN ips_own.ref_fac_facility rf  ");
    		sqlSb.append("ON fs.facility_id = rf.facility_id AND fs.ufn = rf.finance_number ");
    		sqlSb.append("WHERE rf.facility_id IS NULL AND rf.finance_number IS NULL ");
    		//B. ends
    		
    		sqlSb.append(") fso ");
			//C. Left Join with records from ref_fac_facility where facility_id and channel (device type)
  			//are not in ipp_facility_staging table
    		sqlSb.append("LEFT JOIN (SELECT rf.*, CASE WHEN rf.device_type_id = 3 THEN 'POS' ELSE 'MPOS' END channel ");
    		sqlSb.append("FROM ips_own.ref_fac_facility rf) rfo  ");
    		sqlSb.append("ON fso.facility_id = rfo.facility_id AND fso.channel = rfo.channel ");
    		sqlSb.append("WHERE rfo.facility_id IS NULL AND rfo.channel IS NULL) fsoo ");
    		//C. ends
    		
    		sqlSb.append("LEFT JOIN ips_own.ref_main_facility mf ");
    		sqlSb.append("ON fsoo.facility_id = mf.facility_id ");
    		sqlSb.append("WHERE mf.facility_id IS NULL ");
    		//A. ends
    		break;
    	case FINANCE_NUM_FOR_UPDATE_FROM_STAGING:  //Scenario #3 
     		sqlSb.append("SELECT rf.*, CASE WHEN rf.device_type_id = 3 THEN 'POS' ELSE 'MPOS' END channel ");
    		sqlSb.append("FROM ips_own.ref_fac_facility rf) rfo ");
    		sqlSb.append("INNER JOIN ");
    		sqlSb.append("(SELECT fs.* FROM ips_own.ipp_facility_staging fs ");
    		sqlSb.append("LEFT JOIN ips_own.ref_fac_facility rf  ");
    		sqlSb.append("ON fs.facility_id = rf.facility_id AND fs.ufn = rf.finance_number  ");
    		sqlSb.append("WHERE rf.facility_id IS NULL AND rf.finance_number IS NULL) fso ");
    		sqlSb.append("ON rfo.facility_id = fso.facility_id AND rfo.channel = fso.channel ");
    		sqlSb.append("WHERE rfo.finance_number IS NOT NULL ");
     		sqlSb.append("AND (rfo.admin_override IS NULL OR rfo.admin_override = 'N') ");
    		break;
   		case NODELESS_BY_FINNUM_FACILITIES:  //Scenario #4 
     	    sqlSb.append("SELECT rf.* FROM ips_own.ref_fac_facility rf  ");
    	    sqlSb.append("INNER JOIN (SELECT fs.*  from ips_own.ipp_facility_staging fs "); 
    	    sqlSb.append("INNER JOIN ips_own.ref_fac_facility rf ");
    	    sqlSb.append("ON fs.facility_id = rf.facility_id and fs.ufn = rf.finance_number  ");
    	    sqlSb.append("WHERE fs.node_count = 0) fso ");
    	    sqlSb.append("ON rf.facility_id = fso.facility_id ");
    	    sqlSb.append("WHERE rf.finance_number IS NOT NULL ");
    		sqlSb.append("AND (rf.admin_override IS NULL OR rf.admin_override = 'N') ");
    	    break;
   		case MULTI_NODE_FACILITIES:  //Scenario #5 
   			sqlSb.append("SELECT rfo.* FROM (SELECT rf.* FROM ips_own.ref_fac_facility rf ");
   			sqlSb.append("INNER JOIN (SELECT fs.* from ips_own.ipp_facility_staging fs ");
   			sqlSb.append("INNER JOIN ips_own.ref_fac_facility rf ");
   			sqlSb.append("ON fs.facility_id = rf.facility_id and fs.ufn = rf.finance_number ");
   			sqlSb.append("WHERE fs.node_count > 0 AND (rf.admin_override = 'N' OR rf.admin_override IS NULL)) fso ");
   			sqlSb.append("ON rf.facility_id = fso.facility_id ");
   			sqlSb.append("WHERE rf.finance_number IS NOT NULL) rfo ");
   			sqlSb.append("INNER JOIN ips_own.ref_main_facility mf ");
   			sqlSb.append("ON rfo.facility_id = mf.facility_id ");
   			sqlSb.append("WHERE mf.facility_status NOT IN ('C','D','S','E') ");
    		sqlSb.append("AND (rfo.admin_override IS NULL OR rfo.admin_override = 'N') ");
   			break;
   		case NODELESS_BY_MPOS_DEVICE_FACILITIES:   //Scenario #6 
   			sqlSb.append("SELECT  rf.* FROM ips_own.ref_fac_facility rf  ");
   			sqlSb.append("INNER JOIN (SELECT fs.* from ips_own.ipp_facility_staging fs  ");
   			sqlSb.append("WHERE fs.channel = 'MPOS' and fs.node_count = 0) fso ");
   			sqlSb.append("ON rf.facility_id = fso.facility_id  ");
   			sqlSb.append("WHERE (rf.device_type_id = 1 OR rf.device_type_id = 2) ");
   			sqlSb.append("AND rf.finance_number IS NOT NULL  ");
    		sqlSb.append("AND (rf.admin_override IS NULL OR rf.admin_override = 'N') ");
   			break;
  		case NODELESS_BY_POS_DEVICE_FACILITIES:  //Scenario #7 
  			sqlSb.append("SELECT rf.*  FROM ips_own.ref_fac_facility rf  ");
  			sqlSb.append("INNER JOIN (SELECT fs.* from ips_own.ipp_facility_staging fs  ");
  			sqlSb.append("WHERE fs.channel = 'POS' and fs.node_count = 0) fso ");
  			sqlSb.append("ON rf.facility_id = fso.facility_id  ");
  			sqlSb.append("WHERE rf.device_type_id = 3 ");
  	   		sqlSb.append("AND (rf.admin_override IS NULL OR rf.admin_override = 'N')  ");
  			break;
		case FACILITY_ID_NOT_IN_STAGING_FACILITIES: //Scenario #8 
  			sqlSb.append("SELECT  rf.*  FROM ips_own.ref_fac_facility rf  ");
  			sqlSb.append("LEFT JOIN ips_own.ipp_facility_staging  fs "); 
  			sqlSb.append("ON rf.facility_id = fs.facility_id ");
  			sqlSb.append("WHERE fs.facility_id IS NULL ");
  			sqlSb.append("AND (rf.admin_override = 'N' OR rf.admin_override IS NULL) ");
  			sqlSb.append("AND rf.finance_number  IS NOT NULL ");
  	   		sqlSb.append("AND (rf.admin_override IS NULL OR rf.admin_override = 'N')  ");
   			break;
		case SINGLE_CHANNEL_FACILITIES:  //Scenario #9 , #10
  			sqlSb.append("SELECT rf.*  from ips_own.ref_fac_facility rf ");
  			sqlSb.append("INNER JOIN (WITH fac_id_list AS ");
  			sqlSb.append("(SELECT facility_id FROM ips_own.ipp_facility_staging ");
  			sqlSb.append("GROUP BY facility_id HAVING COUNT(facility_id) = 1) ");
  			sqlSb.append("SELECT fs.facility_id, fs.ufn, fs.channel ");
  			sqlSb.append("FROM ips_own.ipp_facility_staging fs, fac_id_list fi ");
  			sqlSb.append("WHERE fs.facility_id = fi.facility_id) fso ");
  			sqlSb.append("ON rf.facility_id =  fso.facility_id ");
  			sqlSb.append("WHERE rf.finance_number IS NOT NULL ");
 	   		sqlSb.append("AND  (rf.admin_override IS NULL OR rf.admin_override = 'N') ");
  			break;
     	case ADMIN_OVERRIDDEN_FACILITIES:  //Scenario #11 
    	    sqlSb.append("SELECT rf.*  FROM ips_own.ref_fac_facility rf ");
    	    sqlSb.append("INNER JOIN (SELECT fs.*  from ips_own.ipp_facility_staging fs ");
    	    sqlSb.append("INNER JOIN ips_own.ref_fac_facility rf  ");
    	    sqlSb.append("ON fs.facility_id = rf.facility_id and fs.ufn = rf.finance_number  ");
    	    sqlSb.append("WHERE fs.node_count > 0 AND rf.admin_override = 'Y') fso ");
    	    sqlSb.append("ON rf.facility_id =  fso.facility_id ");
    	    sqlSb.append("WHERE rf.finance_number IS NOT NULL  ");
    	    break;
		case FINANCE_NUM_NOT_IN_STAGING_FACILITIES:  //Scenario #12 
  			sqlSb.append("SELECT rf.* FROM ips_own.ref_fac_facility rf  ");
  			sqlSb.append("LEFT JOIN ips_own.ipp_facility_staging  fs "); 
  			sqlSb.append("ON rf.finance_number = fs.ufn ");
  			sqlSb.append("WHERE fs.ufn IS NULL ");
  			sqlSb.append("AND (rf.admin_override = 'N' OR rf.admin_override IS NULL) ");
  			sqlSb.append("AND rf.finance_number IS NOT NULL  ");
 	   		sqlSb.append("AND  (rf.admin_override IS NULL OR rf.admin_override = 'N') ");
   			break;
  		case MANUAL_FACILITIES:  //Scenario #13 
     	    sqlSb.append("SELECT fso.* FROM (SELECT fs.* FROM ips_own.ipp_facility_staging fs ");
    	    sqlSb.append("INNER JOIN ips_own.ref_fac_facility rf  ");
    	    sqlSb.append("ON fs.facility_id = rf.facility_id AND fs.ufn = rf.finance_number  ");
    	    sqlSb.append("WHERE fs.node_count > 0 AND fs.channel = 'POS') fso ");
    	    sqlSb.append("LEFT JOIN ips_own.ref_main_facility mf ");
    	    sqlSb.append("ON fso.facility_id = mf.facility_id  ");
    	    sqlSb.append("WHERE mf.facility_id IS NULL ");
     	    break;
     	  default:
    	}
        return sqlSb.toString();
    }
}
