package com.ips.dao.impl;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ips.dao.RefAreaDao;
import com.ips.entity.RefArea;

@Repository
public class RefAreaDaoImpl extends GenericJPADAO<RefArea, String> implements RefAreaDao {

    @SuppressWarnings("unchecked")
    @Override
    public Collection<RefArea> findAll() {
        Query query = em.createNamedQuery("RefArea.findAll");
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public RefArea findByAreaId(long areaId) {
    	RefArea entity = null;

        Query query = em.createNamedQuery("RefArea.findByAreaId");
        query.setParameter("areaId", areaId);

        List<RefArea> list = query.getResultList();
        Optional<RefArea> result = list.stream().findFirst();

        if (result.isPresent()) {
        	entity = result.get();
        }

        return entity;
    }

    @Override
    public void update(RefArea entity) {
        super.merge(entity);
    }

	@Override
	public RefArea getById(Long id) {
		return super.getById(id);
	}

}
