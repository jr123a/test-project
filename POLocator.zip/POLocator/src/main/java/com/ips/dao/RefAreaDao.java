package com.ips.dao;

import java.util.Collection;

import com.ips.entity.RefArea;

public interface RefAreaDao {

	Collection<RefArea> findAll();
	RefArea getById(Long id);
	RefArea findByAreaId(long areaId);
	void save(RefArea entity);
	void delete(RefArea entity);
	void update(RefArea entity);
}
