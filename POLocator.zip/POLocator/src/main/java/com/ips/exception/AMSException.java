package com.ips.exception;

public class AMSException extends Exception {

    private static final long serialVersionUID = 1L;
    private final String message;
    
    public AMSException(String message){
        this.message = message;
    }

    @Override
    public String getMessage() {        
        return message;
    }
}
