package com.ips.proofing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.ips.polocator.common.AppointmentVo;
import com.ips.common.common.DateTimeUtil;
import com.ips.polocator.common.IppVo;
import com.ips.polocator.common.LocationVo;
import com.ips.dao.RefFacFacilityDao;
import com.ips.entity.RefFacFacility;
import com.ips.exception.AMSException;
import com.ips.exception.IPSException;
import com.ips.service.RefFacFacilityServiceImpl;
import com.ips.xml.generated.polocator.Location;
import com.ips.xml.generated.polocator.PhoneData;

class TestVerifyAddressService {
    
    private static VerifyAddressService verifyAddressService;
    private static RefFacFacilityServiceImpl refFacFacilityService;
    private static RefFacFacilityDao refFacFacilityDao;
    private static AppointmentVo appointmentVo;
    private static IppVo ippVo;

    @BeforeAll
    public static void setup() throws IPSException, AMSException, ParseException {
        verifyAddressService = Mockito.mock(VerifyAddressService.class);
        refFacFacilityDao = Mockito.mock(RefFacFacilityDao.class);
        refFacFacilityService = new RefFacFacilityServiceImpl();
        refFacFacilityService.setDao(refFacFacilityDao);
            
        appointmentVo = createAppointmentVo();
        ippVo = createIppVo("22124");
        
        
        Mockito.when(verifyAddressService.verifyAddress(appointmentVo)).thenReturn(verifyAddress(appointmentVo));
        Mockito.when(verifyAddressService.getFilteredPOList(ippVo)).thenReturn(getFilteredPOList(ippVo));
//        Mockito.when(verifyAddressService.getFilteredPOListByZipCode(ippVo)).thenReturn(getFilteredPOListByZipCode("22124"));
        Mockito.when(verifyAddressService.getLocationVo(new ArrayList<Location>())).thenReturn(getLocationVo(new ArrayList<Location>()));    
        Mockito.when(refFacFacilityDao.getFacilitiesNoCoord()).thenReturn(getFacilitiesNoCoord());
    }    

    @Test
    public void testVerifyAddress() throws AMSException  {
        AppointmentVo appointment1 = new AppointmentVo();
        appointment1.setAddress1("13600 EDS DRIVE");
        appointment1.setCity("HERNDON");
        appointment1.setState("VA");
        appointment1.setZip5("20171");
        
        AppointmentVo appointment2 = appointment1;        
        AppointmentVo appointment3 = verifyAddressService.verifyAddress(appointment1);
        
        assertEquals(appointment1, appointment2);
        assertNotEquals(appointment1, appointment3);
        assertEquals("13600 EDS DRIVE", appointment1.getAddress1());
        assertNotEquals("13601 EDS DRIVE", appointment1.getAddress1());
    }
        
    @Test
    public void testGetFilteredPOList() {
        List<Object> poLocatortList = new ArrayList<>();
        
        IppVo ippVo1 = createIppVo("22124");
        IppVo ippVo2 = createIppVo("22125");
        IppVo ippVo3 = ippVo1;
        poLocatortList.add(ippVo1);
        poLocatortList.add(ippVo2);
        
        assertNotEquals(ippVo1, ippVo2);
        assertEquals(ippVo1, ippVo3);
        assertEquals(2, poLocatortList.size());
        assertNotEquals(3, poLocatortList.size());
    }
    
    private static AppointmentVo verifyAddress(AppointmentVo appointment) {
        return appointment;
    }
    
    private static List<Object> getFilteredPOList(IppVo ippVo) {
        List<Object> list = new ArrayList<>();
        list.add(ippVo);
        return list;
    }
    
    private static List<Object> getFilteredPOListByZipCode(String zipCode) {
        List<Object> list = new ArrayList<>();
        IppVo ippVo1 = createIppVo(zipCode);
        list.add(ippVo1);
        return list;
    }
    
    private static List<LocationVo> getLocationVo(List<Location> poLocations) {
        List<LocationVo> list = new ArrayList<>();
        LocationVo locationVo1 = createLocationVo();
        list.add(locationVo1);
        return list;
    }
    
    private static List<RefFacFacility> getFacilitiesNoCoord() {
        List<RefFacFacility> list = new ArrayList<>();
        RefFacFacility facility = new RefFacFacility();
        list.add(facility);
        return list;
    }
    
    private static AppointmentVo createAppointmentVo() {
        AppointmentVo apptVo = new AppointmentVo();
        apptVo.setRecordLocator("1500000039401295");
        apptVo.setScheduledDate(DateTimeUtil.getCurrentDate());
        apptVo.setScheduledTime("23-OCT-15 07.18.30.000000000");
        apptVo.setAddress1("25629 UNION TPKE");
        apptVo.setAddress2("UNIT 2");
        apptVo.setCity("GLEN OAKS");
        apptVo.setState("NY");
        apptVo.setZip5("11004");
        apptVo.setZip4("9997");
        apptVo.setScheduled(true);
        apptVo.setCanceled(false);
        apptVo.setEventId(394L);
        apptVo.setDeliveryPoint((short) 10);
        apptVo.setCarrierRoute("ROUTE 66");
        apptVo.setLatitude((double) 38.921662);
        apptVo.setLongitude((double) -77.429936);
        
        return apptVo;
    }
    
    private static IppVo createIppVo(String zipCode) {
        IppVo ippVo = new IppVo();
        ippVo.setEmail("testEmail@email.com");
        ippVo.setAddressLine1("2952 CHAIN BRIDGE RD");
        ippVo.setAddressLine2("STE K");
        ippVo.setCity("VIENNA");
        ippVo.setStateProvince("VA");
        ippVo.setPostalCode(zipCode);
        ippVo.setBarcodeFileName("1500000039401295.JPG");
        ippVo.setBarcodeImagePath("/opt/WebSphere/ipsimages/");
        ippVo.setRecordLocator("1500000039401295");
        ippVo.setStatus("In-person passed");
            
        return ippVo;
    }
    
    private static LocationVo createLocationVo() {
        LocationVo locationVo = new LocationVo();
        PhoneData phoneData = new PhoneData();
        locationVo.setLocationType("POST OFFICE");
        locationVo.setLocationID("323");
        locationVo.setLocationName("ASHBURN - Post Office");
        locationVo.setAddress("44715 PRENTICE DR");
        locationVo.setAddress2("UNIT 1");
        locationVo.setCity("DULLES");
        locationVo.setState("VA");
        locationVo.setZip5("20101");
        locationVo.setZip4("9996");
        locationVo.setFax("7034066499");
        locationVo.setParking("Lot Parking Available");
        locationVo.setWeekdayHours("9:00 am - 6:00 pm");
        locationVo.setSatHours("9:00 am - 1:00 pm");
        locationVo.setSunHours("Closed");
        locationVo.setDistance("5 miles");
        locationVo.setFinanceNumber("4833817500");
        locationVo.setDeviceTypeName("Generation 6");
        locationVo.setDeviceTypeId(2L);
        locationVo.setPhoneData(phoneData);
        locationVo.setSelected(true);
        locationVo.setActivationDate(DateTimeUtil.getCurrentDate());
        locationVo.setLocale(new Locale(""));
            
        return locationVo;
    }
}