package com.ips.service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.ips.common.common.DateTimeUtil;
import com.ips.dao.RefFacFacilityDao;
import com.ips.entity.RefArea;
import com.ips.entity.RefDistrict;
import com.ips.entity.RefFacFacility;
import com.ips.exception.IPSException;

class TestRefFacFacilityService {
    
    private static RefFacFacilityDao dao;
    private static RefFacFacilityServiceImpl service;
    
    @BeforeAll
    public static void setup() throws IPSException {
        dao = Mockito.mock(RefFacFacilityDao.class);
        service = new RefFacFacilityServiceImpl(); 
        
        service.setDao(dao);
        
        Mockito.when(dao.getById(1L)).thenReturn(getById());
        Mockito.when(dao.getAllFacilitiesByActivationDate(true, 0, 25)).thenReturn(getAllFacilitiesByActivationDate(true, 0, 25));
        Mockito.when(dao.findByZipAndActivationDate("20170", true)).thenReturn(findByZipAndActivationDate("20170", true));
        Mockito.when(dao.findByCityStateAndActivationDate("HERNDON", "VA", true)).thenReturn(findByCityStateAndActivationDate("HERNDON", "VA", true));
        //Mockito.when(dao.updateAllFacilities(testActivationDate1, true)).thenReturn(updateAllFacilities(testActivationDate2, true));
        Mockito.when(dao.getAll()).thenReturn(getAll());
        Mockito.when(dao.findByZipCode("20170")).thenReturn(findByZipCode("20170"));
        
        Mockito.when(dao.updateActivationDate(new ArrayList<String>(), new ArrayList<Date>())).thenReturn(updateActivationDate(new ArrayList<String>(), new ArrayList<Date>()));
        Mockito.when(dao.getFacilitiesByIds(new ArrayList<String>())).thenReturn(getFacilitiesByIds(new ArrayList<String>()));
        
        Mockito.when(dao.getFacilitiesNoCoord()).thenReturn(getFacilitiesNoCoord());        
        Mockito.when(dao.findByFinanceNumber("3528807501")).thenReturn(findByFinanceNumber("3528807501"));        
        Mockito.when(dao.findByCoordinates((double) 40.746, (double) -73.715)).thenReturn(findByCoordinates((double) 40.746, (double) -73.715));
        Mockito.when(dao.findByGridCoordinates((double) 29.289, (double) 40.746, (double) -94.832, (double) -73.715)).thenReturn(findByGridCoordinates((double) 29.289, (double) 40.746, (double) -94.832, (double) -73.715));
        Mockito.when(dao.getActiveFacilitiesByIds(new ArrayList<String>())).thenReturn(getActiveFacilitiesByIds(new ArrayList<String>()));        
        Mockito.when(dao.findUniqueFacilityIdByGridCoordinates((double) 29.289, (double) 40.746, (double) -94.832, (double) -73.715)).thenReturn(findUniqueFacilityIdByGridCoordinates((double) 29.289, (double) 40.746, (double) -94.832, (double) -73.715));        
        Mockito.when(dao.findByFacilityIdDeviceType(1433762L, 2L)).thenReturn(findByFacilityIdDeviceType(1433762L, 2L));        
    }
    
    private static RefFacFacility getById() {
        RefFacFacility facility = createFacility();
        return facility;
    }
    
    private static List<RefFacFacility> getAllFacilitiesByActivationDate(boolean active, int firstResult, int maxResults) {
        List<RefFacFacility> list = new ArrayList<>();
        RefFacFacility facility1 = createFacility();
        list.add(facility1);
        return list;
    }
    
    private static List<RefFacFacility> findByZipAndActivationDate(String zipCode, boolean active) {
        List<RefFacFacility>  list = new  ArrayList<>();
        RefFacFacility facility = createFacility();
        list.add(facility);
        return list;
    }
    
    private static List<RefFacFacility> findByCityStateAndActivationDate(String city, String state, boolean active) {
        List<RefFacFacility>  list = new  ArrayList<>();
        RefFacFacility facility = createFacility();
        list.add(facility);
        return list;    
    }
    
    private static Collection<RefFacFacility> getAll() {
        List<RefFacFacility>  list = new  ArrayList<>();
        RefFacFacility facility = createFacility();
        list.add(facility);
        return list;
    }
    
    private static Collection<RefFacFacility> findByZipCode(String zipCode) {
        List<RefFacFacility>  list = new  ArrayList<>();
        RefFacFacility facility = createFacility();
        list.add(facility);
        return list;
    }
    
    private static int updateActivationDate(List<String> refFacilityIdList, List<Date> activationDateList) {
        return 1;
    }
    
    private static List<RefFacFacility> getFacilitiesByIds(List<String> refFacilityIDs) {
        List<RefFacFacility>  list = new  ArrayList<>();
        RefFacFacility facility = createFacility();
        list.add(facility);
        return list;
    }
    
    private static List<RefFacFacility> getFacilitiesNoCoord() {
        List<RefFacFacility>  list = new  ArrayList<>();
        RefFacFacility facility = createFacility();
        list.add(facility);
        return list;
    }
    
    private static RefFacFacility findByFinanceNumber(String financeNumber) throws IPSException {
        return new RefFacFacility();
    }
    
    private static RefFacFacility findByCoordinates(double latitude, double longitude) throws IPSException {
        return new RefFacFacility();
    }
    
    private static List<RefFacFacility> findByGridCoordinates(double lowLatitude, double highLatitude, double lowLongitude, double highLongitude) {
        List<RefFacFacility>  list = new  ArrayList<>();
        RefFacFacility facility = createFacility();
        list.add(facility);
        return list;
    }
    
    private static List<RefFacFacility> getActiveFacilitiesByIds(List<String> facIDs) {
        List<RefFacFacility>  list = new  ArrayList<>();
        RefFacFacility facility = createFacility();
        list.add(facility);
        return list;
    }
    
    private static List<BigDecimal> findUniqueFacilityIdByGridCoordinates(double lowLatitude, double highLatitude, double lowLongitude, double highLongitude) {
        List<BigDecimal>  list = new  ArrayList<>();
        BigDecimal decimal = new BigDecimal(1);
        list.add(decimal);
        return list;
    }
    
    private static RefFacFacility findByFacilityIdDeviceType(long facilityId, long deviceType) {
        RefFacFacility facility = createFacility();
        return facility;
    }

    @Test
    public void save() {
        RefFacFacility entity = createFacility();        
        service.create(entity);
    }
    
    @Test
    public void delete() {
        RefFacFacility entity = createFacility();
        service.delete(entity);
    }
    
    @Test
    public void update() {
        RefFacFacility entity = createFacility();
        service.update(entity);
        return;
    }
    
    private static RefFacFacility createFacility() {
        RefFacFacility entity = new RefFacFacility();
        
        RefArea area = new RefArea();
        area.setAreaId(6);
        area.setAreaName("Eastern");
        
        RefDistrict district = new RefDistrict();
        district.setArea(area);
        district.setDistrictId(13L);
        district.setDistrictName("Richmond");
        
        entity.setActivationDate(new java.sql.Date(DateTimeUtil.getCurrentDate().getTime()));
        entity.setAddrPhyAddress1("123 MAIN ST");
        entity.setAddrPhyCityName("HERNDON");
        entity.setAddrPhyStateCode("VA");
        entity.setAddrPhyZipcode("20170");    
        entity.setArea(area);
        entity.setCreateDate(new Timestamp(new Date().getTime()));
        entity.setDistrict(district);
        entity.setFacilityId(0L);
        entity.setFacilityName("TEST FACILITY");
        entity.setFacMposEnabled("Y");
        entity.setFinanceNumber("3528807501");
        entity.setIncludeInDailyReport(null);
        entity.setLatitude(40.746);
        entity.setLongitude(-73.715);
        entity.setUpdateDate(new Timestamp(new Date().getTime()));
            
        return entity;
    }
    
}