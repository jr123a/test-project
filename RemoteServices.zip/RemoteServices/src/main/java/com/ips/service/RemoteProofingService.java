package com.ips.service;

import javax.ws.rs.core.Response;

import com.ips.request.RemoteRequest;

public interface RemoteProofingService {
	Response checkDevice(RemoteRequest remoteReq, String origin);
	Response assessDevicePlusEmailRisk(RemoteRequest remoteReq, String origin);
	Response verifyPhone(RemoteRequest remoteReq, String origin) throws Throwable;
	Response confirmPasscode(RemoteRequest passReq, String origin);
	Response requestPasscode(RemoteRequest remoteReq, String origin) throws Throwable;
    Response resendLink(RemoteRequest remoteReq, String origin);
    Response validateLink(RemoteRequest remoteReq, String origin);
 }
