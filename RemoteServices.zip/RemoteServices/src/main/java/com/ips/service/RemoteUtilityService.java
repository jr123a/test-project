package com.ips.service;

import javax.ws.rs.core.Response;

import com.ips.request.RemoteRequest;
import com.ips.request.RemoteUtilityRequest;


public interface RemoteUtilityService {

    Response createRefSponsorConfigurationForRemoteClient(RemoteUtilityRequest remoteReq, String origin);
    Response createRpOtpAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, String origin);
    Response createRpInfPvAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, String origin);
    Response createRpFeatureAttemptForRemoteClient(RemoteUtilityRequest remoteReq, String origin);
    Response removeRefSponsorConfigurationForRemoteClient(RemoteUtilityRequest remoteReq, String origin);
    Response removeRpFeatureAttemptForRemoteClient(RemoteUtilityRequest remoteReq, String origin);
    Response removeRpOtpAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, String origin);
    Response getModificationFingerprint(RemoteUtilityRequest remoteReq, String origin);
    Response configVerificationMethod(RemoteUtilityRequest remoteReq, String origin);
    Response retrieveSupplierConfig(RemoteUtilityRequest remoteReq, String origin);
    Response configPhoneVelocityWindow(RemoteUtilityRequest remoteReq, String origin);   
    Response updatePersonProofingStatus(RemoteUtilityRequest remoteReq, String origin);
    Response saveRpSupplierToken(RemoteUtilityRequest remoteReq, String origin);
    Response removeRpSupplierToken(RemoteUtilityRequest remoteReq, String origin);
    Response saveRefSponsorConfiguration(RemoteUtilityRequest remoteReq, String origin);
    Response retrieveRefSponsorConfiguration(RemoteUtilityRequest remoteReq, String origin);
    Response removeRefSponsorConfiguration(RemoteUtilityRequest remoteReq, String origin);
    Response obtainExperianWebToken(RemoteUtilityRequest remoteReq, String origin);
    Response getHighRiskAddresses(RemoteRequest remoteReq, String origin);
    Response updateHighRiskAddress(RemoteRequest remoteReq, String origin);
    Response checkRegExForMatch(RemoteUtilityRequest remoteReq, String origin);

 }
