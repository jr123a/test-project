package com.ips.service;

import javax.ws.rs.core.Response;

import com.ibm.json.java.JSONObject;
import com.ips.entity.Person;
import com.ips.entity.RefApp;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefSponsor;
import com.ips.entity.RpEvent;
import com.ips.persistence.common.DeviceAssessmentParamVo;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.RemoteResponse;
import com.ips.persistence.common.SponsorConfigurationResponse;
import com.ips.request.RemoteRequest;
import com.ips.response.RemoteUtilityResponse;

public interface RemoteSupportService {
    
    Response buildRequestValidationResponse(RemoteRequest remoteReq, PersonVo personVo, String origin);
    Response checkDeviceReputation(String origin, Person person, PersonVo personVo, DeviceAssessmentParamVo assessmentVo, RemoteRequest remoteReq);
    Response assessDevicePlusEmailRisk(String origin, RemoteRequest remoteReq, Person person, PersonVo personVo, DeviceAssessmentParamVo assessmentVo);
    RefOtpSupplier determineVerificationMethod(PersonVo personVo);
    boolean passPhoneVelocity(Person person, PersonVo personVo, RefOtpSupplier phoneSupplier, String serviceName);
    String sendPasscodeToPhone(PersonVo personVo, RefOtpSupplier phoneSupplier, RpEvent rpEvent) throws Throwable;
    RemoteResponse buildRemoteResponse(PersonVo personVo, RefOtpSupplier phoneSupplier, RpEvent rpEvent, String serviceName, String velocityType, String reason);
    boolean passVelocityCheck(String velocityType, Person person, PersonVo personVo, RefOtpSupplier phoneSupplier, RpEvent rpEvent);
    String passcodeConfirmation(String origin, PersonVo personVo, RefOtpSupplier phoneSupplier);
    String checkPhoneVerified(String origin, Person person, PersonVo personVo, RpEvent rp, RefOtpSupplier phoneSupplier, String serviceName);
    String checkOTPSent(PersonVo personVo, RpEvent rp);
    RpEvent getLatestPV(long personId, long supplierId);
    Response buildPVResponse(Integer status, RemoteResponse pvResponse, String origin);
    Response buildPVResponse(Integer status, RemoteUtilityResponse pvResponse, String origin);
    Response buildErrorPVResponse(Integer status, String message, String origin);
    Response buildErrorPVResponse(Integer status, JSONObject pvResponse, String origin);
    Response buildErrorResponse(String origin, long sponsorId, String requestId, String serviceName, String message);
    PersonVo mergeObjects(RemoteRequest remReq, String serviceName); 
    DeviceAssessmentParamVo mergeParamObjects(RemoteRequest remReq, PersonVo personVo);
    RefApp determineTransactionOriginApp(RefSponsor sponsor, String appCode);
    RefOtpSupplier getLatestPhoneSupplier(long personId);
    String checkSmfaLinkValidation(PersonVo personVo);
    String calculateNameAddressHash(PersonVo personVo);
    String calculateNameAddressHash(RemoteRequest remReq);
    Response sponsorConfiguration(String origin);
    SponsorConfigurationResponse retrieveSponsorConfiguration();
    Response buildSCResponse(Integer status, SponsorConfigurationResponse scResponse, String origin);
    Response eventNotFoundResponse(long sponsorID, long otpSupplierId, String sponsorUserId, String requestId, String serviceName, String origin);
    Response personNotFoundResponse(long sponsorID, String sponsorUserId, String requestId, String serviceName, String origin);
    Response latestEventErrorResponse(PersonVo personVo, String serviceName, String origin, Exception e);
    Response exceptionErrorResponse(PersonVo personVo, String serviceName, String message, String origin, Exception e);
    void populatePersonVo(RemoteRequest remReq, PersonVo personVo);
    void setSponsorAppData(RemoteRequest remReq, PersonVo personVo);
	void saveDeviceReputationAssessmentResponse(PersonVo personVo, RemoteRequest remoteReq, Response errorResponse);
	void populatePersonVoFromPerson(Person person, PersonVo personVo);
 }
