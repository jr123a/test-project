package com.ips.service;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.json.java.JSONObject;
import com.ips.common.common.CustomLogger;
import com.ips.entity.HighRiskAddress;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefApp;
import com.ips.entity.RefHighRiskAddressType;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpInfPvAttemptConfig;
import com.ips.entity.RpOtpAttemptConfig;
import com.ips.entity.RpSupplierToken;
import com.ips.jaxrs.ErrorMessage;
import com.ips.persistence.common.ExperianResultVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.NameValueVo;
import com.ips.persistence.common.PersonVo;
import com.ips.proofing.CommonRestService;
import com.ips.proofing.ExperianServiceImpl;
import com.ips.request.RemoteRequest;
import com.ips.request.RemoteUtilityRequest;
import com.ips.response.RemoteUtilityResponse;

@Service("remoteUtilityService")
public class RemoteUtilityServiceImpl implements Serializable, RemoteUtilityService {
    private static final long serialVersionUID = 1L;

    @Autowired
    private CommonRestService commonRestService;
    @Autowired
    private HighRiskAddressService highRiskAddressService;
    @Autowired
    private OtpAttemptConfigService otpAttemptConfigService;
    @Autowired
    private PersonProofingStatusService personProofingStatusService;
    @Autowired
    private RefAppService refAppService;
    @Autowired
    private RefRpStatusDataService refRpStatusDataService;
    @Autowired
    private RefSponsorConfigurationService refSponsorConfigService;
    @Autowired
    private RefSponsorDataService refSponsorDataService;
    @Autowired
    private RpFeatureAttemptService rpFeatureAttemptService;
    @Autowired
    private RpInfPvAttemptConfigService rpInfPvAttemptConfigService;
    @Autowired
    private RpSupplierTokenService rpSupplierTokenService;
  
    @Override
    public Response configVerificationMethod(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
 
    	String sponsorCode = "";
      	if (remoteReq.getSponsorCode() != null) {
     		sponsorCode = remoteReq.getSponsorCode();
     	}
     	
     	int lexisNexisOTPAllocation = remoteReq.getLexisNexisOTPAllocation() != null ? remoteReq.getLexisNexisOTPAllocation() : 0;
       	int equifaxSMFAAllocation = remoteReq.getEquifaxSMFAAllocation() != null? remoteReq.getEquifaxSMFAAllocation() : 0;
       	int equifaxIDFSAllocation = remoteReq.getEquifaxIDFSAllocation() != null? remoteReq.getEquifaxIDFSAllocation() : 0;
       	int experianCCAllocation = remoteReq.getExperianCCAllocation() != null? remoteReq.getExperianCCAllocation() : 0;
  
       	String sponsorName = null;
       	long sponsorId = 0L;
       	RefSponsor sponsor = null;
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
      	RefSponsor refSponsor = findRefSponsor(sponsorCode);

       	if (sponsorCode != null) {        
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = refSponsor.getSponsorId();
        }
       	
       	if (sponsor == null) {
            pvResponse.setResponseMessage("Sponsor not found.");
            return buildPVResponse(null, pvResponse, origin);
       	}
       	
       	int totalAlloc = lexisNexisOTPAllocation + equifaxSMFAAllocation + equifaxIDFSAllocation + experianCCAllocation; 
       	if (totalAlloc != 100) {
            pvResponse.setResponseMessage("Total percentage allocations must 100%.");
            return buildPVResponse(null, pvResponse, origin);
       	}
       	
        try {
    		String attemptTableType = "All";
      		if (remoteReq.getAttemptTableToConfig() != null) {
       			if ("rp_kba_attempts".equalsIgnoreCase(remoteReq.getAttemptTableToConfig())) {
     				attemptTableType = "Main";
    			}
    			else if ("rp_inf_pv_attempts".equalsIgnoreCase(remoteReq.getAttemptTableToConfig())) {
     				attemptTableType = "Inf";
    			}
    		}
    				
    		if ("All".equalsIgnoreCase(attemptTableType) || "Main".equalsIgnoreCase(attemptTableType)) {
         		// Main/Home Configuration
                List<RpOtpAttemptConfig> configList = otpAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
                for (RpOtpAttemptConfig config : configList) {
                	if (config.getId().getOtpSupplierId() == 3) {
                		config.setTotalAttempts(equifaxIDFSAllocation);
                		config.setAttempts(0);
                	}
                	else if (config.getId().getOtpSupplierId() == 4) {
                		config.setTotalAttempts(lexisNexisOTPAllocation);
                		config.setAttempts(0);
                	}
                	else if (config.getId().getOtpSupplierId() == 5) {
                		config.setTotalAttempts(equifaxSMFAAllocation);
                		config.setAttempts(0);
                	}
                	else if (config.getId().getOtpSupplierId() == 6) {
                		config.setTotalAttempts(experianCCAllocation);
                		config.setAttempts(0);
                	}

                	config.setModifyConfigurationUserid(RemoteSupportServiceImpl.USERID_IPS_OWN);
                	config.setModifyConfigurationTime(new Timestamp(new Date().getTime()));
                	config.setUpdateDate(new Timestamp(new Date().getTime()));
                }

                otpAttemptConfigService.adminUpdate(configList);
    		}
            
       		if ("All".equalsIgnoreCase(attemptTableType) || "Inf".equalsIgnoreCase(attemptTableType)) {
                // Individual-Not-Found Configuration
                List<RpInfPvAttemptConfig> infConfigList = rpInfPvAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
 
                for (RpInfPvAttemptConfig config : infConfigList) {
                	if (config.getId().getSupplierId() == 3) {
                		config.setTotalAttempts(equifaxIDFSAllocation);
                		config.setAttempts(0);
                	}
                	else if (config.getId().getSupplierId() == 4) {
                		config.setTotalAttempts(lexisNexisOTPAllocation);
                		config.setAttempts(0);
                	}
                	else if (config.getId().getSupplierId() == 5) {
                		config.setTotalAttempts(equifaxSMFAAllocation);
                		config.setAttempts(0);
                	}
                	else if (config.getId().getSupplierId() == 6) {
                		config.setTotalAttempts(experianCCAllocation);
                		config.setAttempts(0);
                	}

                	config.setModifyConfigurationUserid(RemoteSupportServiceImpl.USERID_IPS_OWN);
                	config.setModifyConfigurationTime(new Timestamp(new Date().getTime()));
                	config.setUpdateDate(new Timestamp(new Date().getTime()));
                }

                rpInfPvAttemptConfigService.adminUpdate(infConfigList);
       		}
           
      		if ("All".equalsIgnoreCase(attemptTableType) || "Main".equalsIgnoreCase(attemptTableType)) {
	        	// Main/Home Configuration Response
                List<RpOtpAttemptConfig> updatedConfigList = otpAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
	            for (RpOtpAttemptConfig config : updatedConfigList) {
	            	if (config.getId().getOtpSupplierId() == 3) {
	            		pvResponse.setEquifaxIDFSAllocation(Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getOtpSupplierId() == 4) {
	            		pvResponse.setLexisNexisOTPAllocation(Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getOtpSupplierId() == 5) {
	            		pvResponse.setEquifaxSMFAAllocation(Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getOtpSupplierId() == 6) {
	            		pvResponse.setExperianCCAllocation(Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            }
      		}
       		else if ("Inf".equalsIgnoreCase(attemptTableType)) {
	        	// Individual-Not-Found Configuration Response
                List<RpInfPvAttemptConfig> updatedConfigList = rpInfPvAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
	            for (RpInfPvAttemptConfig config : updatedConfigList) {
	            	if (config.getId().getSupplierId() == 3) {
	            		pvResponse.setEquifaxIDFSAllocation(Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getSupplierId() == 4) {
	            		pvResponse.setLexisNexisOTPAllocation(Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getSupplierId() == 5) {
	            		pvResponse.setEquifaxSMFAAllocation(Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            	else if (config.getId().getSupplierId() == 6) {
	            		pvResponse.setExperianCCAllocation(Long.parseLong(String.valueOf(config.getTotalAttempts())));
	            	}
	            }
      		}
            
            pvResponse.setPhoneVelocityWindow(null);
                  	
            pvResponse.setResponseMessage("Verification Method configuration was successfully updated.");
            return buildPVResponse(null, pvResponse, origin);

        } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INTERNAL_ERROR.getHttpResponseCode(), ErrorMessage.INTERNAL_ERROR.getMessage(), origin);
        }
    }
     
    @Override
    public Response retrieveSupplierConfig(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
 
    	String sponsorCode = "";
      	if (remoteReq.getSponsorCode() != null) {
     		sponsorCode = remoteReq.getSponsorCode();
     	}
   
       	String sponsorName = null;
       	long sponsorId = 0L;
       	RefSponsor sponsor = null;
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();

       	if (sponsorCode != null) {
	        if (RefSponsor.SPONSOR_CODE_OS.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_OPERATION_SANTA;
	        }
	        else if (RefSponsor.SPONSOR_CODE_COA.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_CHANGE_ADDRESS;
	        }
	        else if (RefSponsor.SPONSOR_CODE_CR.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_CUSTREG;
	        }
	        
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = sponsor.getSponsorId();
        }
       	
       	if (sponsor == null) {
            pvResponse.setResponseMessage("Sponsor not found.");
            return buildPVResponse(null, pvResponse, origin);
       	}

        try {
    		String attemptTableType = "Main";
      		if (remoteReq.getAttemptTableToConfig() != null) {
       			if ("rp_kba_attempts".equalsIgnoreCase(remoteReq.getAttemptTableToConfig())) {
     				attemptTableType = "Main";
    			}
    			else if ("rp_inf_pv_attempts".equalsIgnoreCase(remoteReq.getAttemptTableToConfig())) {
     				attemptTableType = "Inf";
    			}
    		}
    				
    		if ("Main".equalsIgnoreCase(attemptTableType)) {
         		// Main/Home Configuration
                List<RpOtpAttemptConfig> configList = otpAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
                for (RpOtpAttemptConfig config : configList) {
                	int supplierId = (int) config.getId().getOtpSupplierId();
                	
                	switch(supplierId) {
                		case 3:  
                			pvResponse.setEquifaxIDFSAllocation((long) config.getTotalAttempts());
                			break;
                		case 4:
                			pvResponse.setEquifaxIDFSAllocation((long) config.getTotalAttempts());
                			break;
                		case 5:
                			pvResponse.setEquifaxSMFAAllocation((long) config.getTotalAttempts());
                			break;
                		case 6:
                			pvResponse.setExperianCCAllocation((long) config.getTotalAttempts());
                			break;
                		default:
                	}
                	
                	pvResponse.setAttemptTableToConfig("rp_kba_attempts");
                }
    		}
    		else if ("Inf".equalsIgnoreCase(attemptTableType)) {
                // Individual-Not-Found Configuration
                List<RpInfPvAttemptConfig> infConfigList = rpInfPvAttemptConfigService.getByProofingLevel(RefLoaLevel.LOA15_CODE, sponsorId);
 
                for (RpInfPvAttemptConfig config : infConfigList) {
                	if (config.getId().getSupplierId() == 3) {
                		pvResponse.setEquifaxIDFSAllocation((long) config.getTotalAttempts());
                	}
                	else if (config.getId().getSupplierId() == 4) {
                		pvResponse.setEquifaxIDFSAllocation((long) config.getTotalAttempts());
                	}
                	else if (config.getId().getSupplierId() == 5) {
                		pvResponse.setEquifaxSMFAAllocation((long) config.getTotalAttempts());
                 	}
                	else if (config.getId().getSupplierId() == 6) {
                		pvResponse.setExperianCCAllocation((long) config.getTotalAttempts());
                	}
                	
                	pvResponse.setAttemptTableToConfig("rp_inf_pv_attempts");
                }
       		}
                    	
            pvResponse.setResponseMessage("Supplier Traffic Allocation Config was successfully retrieved.");
            return buildPVResponse(null, pvResponse, origin);

        } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INTERNAL_ERROR.getHttpResponseCode(), ErrorMessage.INTERNAL_ERROR.getMessage(), origin);
        }
    }
     
    @Override
    public Response configPhoneVelocityWindow(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
 
    	int phoneVelocityWindow = remoteReq.getPhoneVelocityWindow();
     	String sponsorCode = remoteReq.getSponsorCode();
    
       	String sponsorName = null;
       	RefSponsor sponsor = null;
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();

       	if (sponsorCode != null) {
	        if (RemoteSupportServiceImpl.SPONSOR_CODE_CR.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RemoteSupportServiceImpl.SPONSOR_NAME_OS;
	        }
	        else if (RemoteSupportServiceImpl.SPONSOR_CODE_OS.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RemoteSupportServiceImpl.SPONSOR_NAME_OS;
	        }
	        else if (RemoteSupportServiceImpl.SPONSOR_CODE_COA.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RemoteSupportServiceImpl.SPONSOR_NAME_COA;
	        }
	        
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
        }
       	
       	if (sponsor == null) {
            pvResponse.setResponseMessage("Sponsor not found.");
            return buildPVResponse(null, pvResponse, origin);
       	}
       	
       	if (phoneVelocityWindow < 0 || phoneVelocityWindow > 60 ) {
            pvResponse.setResponseMessage("Phone Velocity Window value must be from 0 to 60 minutes.");
            return buildPVResponse(null, pvResponse, origin);
       	}
       	
        RefSponsorConfiguration sponsorConfig = null;
        try {
  			sponsorConfig = refSponsorConfigService.getConfigRecord(
					(int) sponsor.getSponsorId(), "Device.Assessment.Velocity.Timer");
 			sponsorConfig.setValue(String.valueOf(phoneVelocityWindow));
  			
 			refSponsorConfigService.update(sponsorConfig);
  
        } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INTERNAL_ERROR.getHttpResponseCode(), ErrorMessage.INTERNAL_ERROR.getMessage(), origin);
        }
        
        String timeValueStr = "";
        try {
        	RefSponsorConfiguration sponsorConfigMod = refSponsorConfigService.getConfigRecord(
					(int) sponsor.getSponsorId(), "Device.Assessment.Velocity.Timer");
 			timeValueStr = sponsorConfigMod.getValue();
  
        } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INTERNAL_ERROR.getHttpResponseCode(), ErrorMessage.INTERNAL_ERROR.getMessage(), origin);
        }
        
     	pvResponse.setPhoneVelocityWindow(Long.parseLong(timeValueStr));
       	pvResponse.setLexisNexisOTPAllocation(null);
     	pvResponse.setEquifaxSMFAAllocation(null);
  
     	pvResponse.setResponseMessage("Phone Velocity Window configuration was successfully updated.");

        return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response createRefSponsorConfigurationForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
 
     	String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	RefSponsor sponsor = null;
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();

       	if (sponsorName != null) {
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = sponsor.getSponsorId();
        }
       	
       	if (sponsor == null) {
            pvResponse.setResponseMessage("Sponsor not found.");
            return buildPVResponse(null, pvResponse, origin);
       	}

        try {
 	        refSponsorConfigService.createRefSponsorConfigurationForRemoteClient(sponsorId);	
        } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RefSponsorConfiguration For RemoteClient", origin);
        }
        
  
    	pvResponse.setResponseMessage(String.format("RefSponsorConfiguration records for remote client sponsor %s were successfully created.", sponsorName));
        return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response createRpOtpAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

     	String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	RefSponsor sponsor = null;
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();

       	if (sponsorName != null) {
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = sponsor.getSponsorId();
        }
       	
        try {
        	if (sponsorId > 0) {
        		otpAttemptConfigService.createRpOtpAttemptConfigForRemoteClient(sponsorId);
        	}
        	else {
        		List<RefSponsor> refSponsorList = refSponsorDataService.getAllRemoteProofingClients();
        		for(RefSponsor refSponsor : refSponsorList) {
            		otpAttemptConfigService.createRpOtpAttemptConfigForRemoteClient(refSponsor.getSponsorId());
        		}
        	}
         } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpOtpAttemptConfig For RemoteClient", origin);
        }
        
    	pvResponse.setResponseMessage(String.format("RpOtpAttemptConfig records for remote client sponsor %s were successfully created.", sponsorName));
        return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response createRpInfPvAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

     	String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	RefSponsor sponsor = null;
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();

       	if (sponsorName != null) {
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = sponsor.getSponsorId();
        }

        try {
        	if (sponsorId > 0) {
        		rpInfPvAttemptConfigService.createRpInfPvAttemptConfigForRemoteClient(sponsorId);
        	}
        	else {
        		List<RefSponsor> refSponsorList = refSponsorDataService.getAllRemoteProofingClients();
        		for(RefSponsor refSponsor : refSponsorList) {
        			rpInfPvAttemptConfigService.createRpInfPvAttemptConfigForRemoteClient(refSponsor.getSponsorId());
        		}
        	}
         	
         } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpOtpAttemptConfig For RemoteClient", origin);
        }
        
    	pvResponse.setResponseMessage(String.format("RpInfPvAttemptConfig records for remote client sponsor %s were successfully created.", sponsorName));
        return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response createRpFeatureAttemptForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
 
		String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	long appId = 0L;
       	RefSponsor refSponsor = null;
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();


       	if (sponsorName != null) {
	        refSponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        
	        if (refSponsor == null) {
	            pvResponse.setResponseMessage("Sponsor not found.");
	            return buildPVResponse(null, pvResponse, origin);
	       	}
	        
	        sponsorId = refSponsor.getSponsorId();
        }
       	else {
       		sponsorId = remoteReq.getSponsorId();
       		appId = remoteReq.getAppId();
       	}
        
        RefApp refApp = refAppService.findByAppId(appId);
        
        try {
        	rpFeatureAttemptService.createRpFeatureAttemptForRemoteClient(refSponsor, refApp);
          } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpFeatureAttempt For RemoteClient", origin);
        }
        
    	pvResponse.setResponseMessage(String.format("RpFeatureAttempt records for remote client sponsor %s were successfully created.", sponsorName));
        return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response removeRefSponsorConfigurationForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
     	
		String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	RefSponsor sponsor = null;
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();

       	if (sponsorName != null) {
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = sponsor.getSponsorId();
        }
       	
       	if (sponsor == null) {
            pvResponse.setResponseMessage("Sponsor not found.");
            return buildPVResponse(null, pvResponse, origin);
       	}

        try {
 	        refSponsorConfigService.removeRefSponsorConfigurationForRemoteClient(sponsorId);	
        } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RefSponsorConfiguration For RemoteClient", origin);
        }
        
       	pvResponse.setResponseMessage(String.format("RefSponsorConfiguration records for remote client sponsor %s were successfully removed.", sponsorName));
        return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response removeRpFeatureAttemptForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

     	String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	long appId = 0L;
       	RefSponsor sponsor = null;
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();

       	if (sponsorName != null) {
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        
	        if (sponsor == null) {
	            pvResponse.setResponseMessage("Sponsor not found.");
	            return buildPVResponse(null, pvResponse, origin);
	       	}
	        
	        sponsorId = sponsor.getSponsorId();
        }
       	else {
       		sponsorId = remoteReq.getSponsorId();
       		appId = remoteReq.getAppId();
       	}
        
        try {
        	rpFeatureAttemptService.removeRpFeatureAttemptForRemoteClient(sponsorId, appId);
        } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpFeatureAttempt For RemoteClient", origin);
        }
          
       	pvResponse.setResponseMessage(String.format("RpFeatureAttempt records for remote client sponsor %s were successfully removed.", sponsorName));
        return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response removeRpOtpAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

     	String sponsorName = remoteReq.getSponsorName();
       	long sponsorId = 0L;
       	RefSponsor sponsor = null;
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();

       	if (sponsorName != null) {
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        sponsorId = sponsor.getSponsorId();
        }
       	
       	if (sponsor == null) {
            pvResponse.setResponseMessage("Sponsor not found.");
            return buildPVResponse(null, pvResponse, origin);
       	}
        
        try {
        	otpAttemptConfigService.removeRpOtpAttemptConfigForRemoteClient(sponsorId);
         } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpOtpAttemptConfig For RemoteClient", origin);
        }

       	pvResponse.setResponseMessage(String.format("RpOtpAttemptConfig records for remote client sponsor %s were successfully removed.", sponsorName));
        return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response getModificationFingerprint(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	String sponsorCode = remoteReq.getSponsorCode();
        String sponsorName = "";

        if (sponsorCode != null) {
	        if (RemoteSupportServiceImpl.SPONSOR_CODE_OS.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RemoteSupportServiceImpl.SPONSOR_NAME_OS;
	        }
	        else if (RemoteSupportServiceImpl.SPONSOR_CODE_COA.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RemoteSupportServiceImpl.SPONSOR_NAME_COA;
	        }
        }
       	
     	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
     	
     	pvResponse.setSponsorName(sponsorName);
     	pvResponse.setRemoteServicesFingerprint(RemoteSupportServiceImpl.REMOTE_SERVICES_MOD_FP);
     	pvResponse.setIvsPersistenceFingerprint(IPSConstants.IVSPERSISTENCE_MOD_FP);

    	return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response updatePersonProofingStatus(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());
 
    	PersonProofingStatus personProofingStatus = null;
    	int personId = remoteReq.getPersonId();
    	int newProofingStatus = remoteReq.getProofingStatus();
    	int oldProofingStatus = 0;
    	
        try {
         	personProofingStatus = personProofingStatusService.getByPersonId(personId); 
        	oldProofingStatus = (int) personProofingStatus.getRefRpStatus().getStatusCode();
  
        	if (personProofingStatus != null) {
         		RefRpStatus refRpStatus = refRpStatusDataService.findById(Long.valueOf(newProofingStatus));
         		personProofingStatus.setRefRpStatus(refRpStatus);
        		personProofingStatusService.update(personProofingStatus);
          	}
        } catch (Exception e) {
            return buildErrorPVResponse(ErrorMessage.INTERNAL_ERROR.getHttpResponseCode(), ErrorMessage.INTERNAL_ERROR.getMessage(), origin);
        }
               
        RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
       	String respMsg = String.format("ProofingStatus was successfully updated from %s to %s for personId %s.",
     			oldProofingStatus, newProofingStatus, personId);
     	pvResponse.setResponseMessage(respMsg);
      	return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response saveRpSupplierToken(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	RpSupplierToken entity = null;
    	boolean createNewRecord = false;
    	
    	if (remoteReq.getExperianTokenType() != null) {
    		entity = rpSupplierTokenService.findByTokenType(remoteReq.getExperianTokenType());
    		
    		if (entity == null) {
    			createNewRecord = true;
    			entity = new RpSupplierToken();	
    			entity.setTokenType(remoteReq.getExperianTokenType());
    			entity.setCreateDate(new Timestamp(new Date().getTime()));
    		}
     	}
    	else {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RpSupplierToken.  ExperianTokenCode is null", origin);
    	}
     	
    	if (remoteReq.getExperianTokenCode() != null) {
    		entity.setTokenCode(remoteReq.getExperianTokenCode());
    	}
    	
    	if (remoteReq.getExperianAccessToken() != null) {
    		entity.setAccessToken(remoteReq.getExperianAccessToken());
    	}
    	
    	entity.setUpdateDate(new Timestamp(new Date().getTime()));
    	
    	if (createNewRecord) {
    		rpSupplierTokenService.save(entity);
    	}
    	else {
    		rpSupplierTokenService.update(entity);
     	}
    	
    	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
       	String respMsg = "RpSupplierToken record was successfully created.";
      	pvResponse.setResponseMessage(respMsg);
    	return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response removeRpSupplierToken(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	RpSupplierToken entity = null;
    	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
       	String respMsg = "RpSupplierToken record was successfully removed.";
       	
    	if (remoteReq.getExperianTokenType() != null) {
    		entity = rpSupplierTokenService.findByTokenType(remoteReq.getExperianTokenType());
    		
    		if (entity != null) {
    			rpSupplierTokenService.delete(entity);
    		}
     	}
    	else {
    		respMsg = "RpSupplierToken record with token type of " + remoteReq.getExperianTokenType() + " was not found.";
    	}
 
      	pvResponse.setResponseMessage(respMsg);
    	return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response saveRefSponsorConfiguration(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	RefSponsorConfiguration entity = null;
    	boolean createNewRecord = false;
    	String configName = remoteReq.getSponsorConfigName();
       	RefSponsor refSponsor = findRefSponsor(remoteReq.getSponsorCode());

    	if (configName != null && refSponsor != null) {
    		entity = refSponsorConfigService.getConfigRecord((int) refSponsor.getSponsorId(), configName);
    		
    		if (entity == null) {
    			createNewRecord = true;
    			entity = new RefSponsorConfiguration();	
    			entity.setSponsorId(1);
    			entity.setName(configName);
    			entity.setValue(remoteReq.getSponsorConfigValue());
    			entity.setCreateDate(new Timestamp(new Date().getTime()));
    		}
     	}
    	else {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RefSponsorConfiguration. SponsorConfigName is null", origin);
    	}
     	
    	if (remoteReq.getSponsorConfigValue() != null) {
    		entity.setValue(remoteReq.getSponsorConfigValue());
    	}

    	entity.setUpdateDate(new Timestamp(new Date().getTime()));
    	
    	if (createNewRecord) {
    	   	entity.setConfigurationId(refSponsorConfigService.getMostRecentConfigId() + 1);
    		refSponsorConfigService.create(entity);
    	}
    	else {
    		refSponsorConfigService.update(entity);
     	}
    	
    	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
        	String respMsg = String.format("RefSponsorConfiguration record with name %s was successfully created.", configName);
      	pvResponse.setResponseMessage(respMsg);
    	return buildPVResponse(null, pvResponse, origin);
    }
    
    @Override
    public Response retrieveRefSponsorConfiguration(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	RefSponsorConfiguration entity = null;
     	String configName = remoteReq.getSponsorConfigName();
    	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
    	RefSponsor refSponsor = findRefSponsor(remoteReq.getSponsorCode());
 
    	if (configName != null && refSponsor != null) {
    		entity = refSponsorConfigService.getConfigRecord((int) refSponsor.getSponsorId(), configName);
    		Long count = refSponsorConfigService.getConfigRecordCount((int) refSponsor.getSponsorId(), configName);
    		if (count == 0L) {
    			count = null;
    		}
    		
    		if (entity != null) {
    			pvResponse.setConfigName(configName);
    			pvResponse.setConfigValue(entity.getValue());
    			pvResponse.setConfigCount(count);
     		}
    		else {
                return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "RefSponsorConfiguration was not found.", origin);
    		}
     	}
    	else {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in retrieving RefSponsorConfiguration. SponsorConfigName is null", origin);
    	}
       	
       	String respMsg = String.format("RefSponsorConfiguration record with name %s was successfully retrieved.", configName);
      	pvResponse.setResponseMessage(respMsg);
    	return buildPVResponse(null, pvResponse, origin);
    }

    @Override
    public Response removeRefSponsorConfiguration(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	RefSponsorConfiguration entity = null;
     	String configName = remoteReq.getSponsorConfigName();
       	RefSponsor refSponsor = findRefSponsor(remoteReq.getSponsorCode());

    	if (configName != null && refSponsor != null) {
    		entity = refSponsorConfigService.getConfigRecord((int) refSponsor.getSponsorId(), configName);
    		
    		if (entity != null) {
    			refSponsorConfigService.delete(entity);
     		}
     	}
    	else {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in creating RefSponsorConfiguration. SponsorConfigName is null", origin);
    	}
       	
    	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
       	String respMsg = String.format("RefSponsorConfiguration record with name %s was successfully removed.", configName);
      	pvResponse.setResponseMessage(respMsg);
    	return buildPVResponse(null, pvResponse, origin);
    }

    
    @Override
    public Response obtainExperianWebToken(RemoteUtilityRequest remoteReq, String origin) {
    	CustomLogger.enter(this.getClass());

    	String webServiceURL = commonRestService.getIpsPropertyValue(ExperianServiceImpl.EXPERIAN_CC_JWT_ENDPT);
		List<NameValueVo> headerList = new ArrayList<>();
		headerList.add(new NameValueVo(ExperianServiceImpl.HEADER_USER_DOMAIN_NAME, ExperianServiceImpl.HEADER_USER_DOMAIN_VALUE));
		headerList.add(new NameValueVo(ExperianServiceImpl.HEADER_CORRELATION_ID_NAME, ExperianServiceImpl.HEADER_CORRELATION_ID_VALUE));
		
		ExperianResultVo resultVo = new ExperianResultVo();
		resultVo.setJwtUserName(remoteReq.getExperianJwtUserId());
		resultVo.setJwtUserKey(remoteReq.getExperianJwtPasscode());

		JSONObject tokenResponseJsonObj = commonRestService.getJsonWebTokenResponse(webServiceURL, headerList, resultVo);
		
		if (tokenResponseJsonObj != null) {
			String accessToken = (String) tokenResponseJsonObj.get("access_token");
			
			RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
	       	
	       	if (accessToken != null) {
	       		String respMsg = "Experian JWT Access Token was successfully obtained.";
	       		pvResponse.setResponseMessage(respMsg);
	       		pvResponse.setExperianJwtToken(accessToken);
	       	}
	       	else {
	            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in obtaining Experian JWT Access Token.", origin);
	       	}
	    	return buildPVResponse(null, pvResponse, origin);
		}
		else {
            return buildErrorPVResponse(ErrorMessage.INVALID_TRANSACTION.getHttpResponseCode(), "Error in obtaining Experian JWT Access Token.", origin);
		}
    }
    
    @Override
    public Response getHighRiskAddresses(RemoteRequest remoteReq, String origin) {
    	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
    	String respMsg = "HighRiskAddress was successfully retrieved.";
    	
    	try {
    		
    		List<HighRiskAddress> addressList = highRiskAddressService.getAllPrimary();
    		List<String> addrStrList = new ArrayList<>(); 
    		int ctr = 0;
     		
    		for (HighRiskAddress addr : addressList) {
    	     	PersonVo personVo = new PersonVo();
    	     	personVo.setAddressLine1(addr.getAddress());
    	     	personVo.setAddressLine2(addr.getAddressLine2());
    	     	personVo.setCity(addr.getCity());
    	     	personVo.setStateProvince(addr.getState());
    	     	personVo.setPostalCode(addr.getZip());
    	     	
    	     	boolean isHighRiskAddress = false;
    	    	int addressHash = highRiskAddressService.calculateAddressHash(personVo);
    	    	
    	    	if (addressHash == addr.getAddressHash()) {
    	    		isHighRiskAddress = true;
    	    	}

      	     	if (isHighRiskAddress) {
	    			String addrStr = String.format("Address1:%s, Address2:%s, City:%s, State:%s, ZipCode:%s", addr.getAddress(), addr.getAddressLine2(),
	    					addr.getCity(), addr.getState(), addr.getZip());
	    			addrStrList.add(addrStr);
	    			ctr++;
      	     	}
    			
    			if(ctr > 9) {
    				break;  				
    			}
    		}
    		
    		pvResponse.setHighRiskAddresses(addrStrList);
	    	
    	    RefSponsorConfiguration sponsorConfigMod = refSponsorConfigService.getConfigRecord(1, RefSponsorConfiguration.HIGH_RISK_ACTIVATION);
    	    String highRiskActivated = "True".equalsIgnoreCase(sponsorConfigMod.getValue()) ? "true" : "false";
    	    pvResponse.setHighRiskActivated(highRiskActivated);
    	     
	   		pvResponse.setResponseMessage(respMsg);
   		
   			return buildPVResponse(null, pvResponse, origin);
    	}
    	catch (Exception e) {
    		respMsg = "HighRiskAddress retrieval has failed. " + e.getMessage();
    		pvResponse.setResponseMessage(respMsg);
    		return buildPVResponse(null, pvResponse, origin);
        }
    }

    @Override
    public Response updateHighRiskAddress(RemoteRequest remoteReq, String origin) {
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
    	String respMsg = "HighRiskAddress was successfully updated.";
 
    	try {
    		
	    	HighRiskAddress entity = highRiskAddressService.findHighRiskAddressByAddress(remoteReq.getStreetAddress1(), remoteReq.getCity(),
	    			remoteReq.getState(), remoteReq.getZipCode());
	    	if (entity != null) {
	    		RefHighRiskAddressType hrAddressType = highRiskAddressService.findRefHighRiskAddressTypeByTypeId(1L);
   			  	entity.setRefHighRiskAddressType(hrAddressType);
		     	entity.setRemoved("N");
	
	     		int dbAddressHash = highRiskAddressService.calculateAddressHash(entity);
	    		entity.setAddressHash(dbAddressHash);
	    		
	    		highRiskAddressService.update(entity);
	       		String dbAddress2 = entity.getAddressLine2() != null? entity.getAddressLine2() : "";
            		
          		respMsg = respMsg + String.format(" Address1:%s, Address2:%s, City:%s, State:%s, ZipCode:%s,"
          				+ " highRiskAddressType:%s, Removed:%s, AddressHash:%s", entity.getAddress(), dbAddress2,
          				entity.getCity(), entity.getState(), entity.getZip(), entity.getRefHighRiskAddressType().getDescription(),
          				entity.getRemoved(), entity.getAddressHash());
	    	}
	    	else {
	    	 	respMsg = "HighRiskAddress not found.";
	    	}
	    	
	      	pvResponse.setResponseMessage(respMsg);
	    	return buildPVResponse(null, pvResponse, origin);
    	}
    	catch (Exception e) {
     		respMsg = "HighRiskAddress retrieval has failed. " + e.getMessage();
    		pvResponse.setResponseMessage(respMsg);
    		return buildPVResponse(null, pvResponse, origin);
        }
    }
     
    @Override
    public Response checkRegExForMatch(RemoteUtilityRequest remoteReq, String origin) {
       	RemoteUtilityResponse pvResponse = new RemoteUtilityResponse();
 
    	if (remoteReq.getFieldValue().matches(remoteReq.getRegEx())) {
    		pvResponse.setResponseMessage("FieldValue was successfully validated. FieldValue matches with Regex.");	
    	}
    	else {
    		pvResponse.setResponseMessage("FieldValue is invalid. It does not match with Regex.");	   		
    	}
    	
        return buildPVResponse(null, pvResponse, origin);
    }
    
    private Response buildPVResponse(Integer status, RemoteUtilityResponse pvResponse, String origin) {
    	CustomLogger.enter(this.getClass());

        Response resp = status != null ? Response.status(status).entity(pvResponse).build()
                : Response.ok(pvResponse, MediaType.APPLICATION_JSON).build();
        ResponseBuilder rb = Response.fromResponse(resp);
        rb.header(RemoteSupportServiceImpl.ACCESS_CTL_ALLOW_ORIGIN, origin);
        rb.header(RemoteSupportServiceImpl.ACCESS_CTL_ALLOW_HEADERS, RemoteSupportServiceImpl.CONTENT_TYPE_HEADER_VALUE);
        resp = rb.build();
        return resp;
    }
    
    private Response buildErrorPVResponse(Integer status, String message, String origin) {
    	CustomLogger.enter(this.getClass());

        JSONObject resp = new JSONObject();
        resp.put("responseMessage", message);
        return buildErrorPVResponse(status, resp, origin);
    }
    
    private Response buildErrorPVResponse(Integer status, JSONObject pvResponse, String origin) {
    	CustomLogger.enter(this.getClass());

        Response resp = Response.status(status).entity(pvResponse).type(MediaType.APPLICATION_JSON).build();
        ResponseBuilder rb = Response.fromResponse(resp);
        rb.header(RemoteSupportServiceImpl.ACCESS_CTL_ALLOW_ORIGIN, origin);
        rb.header(RemoteSupportServiceImpl.ACCESS_CTL_ALLOW_HEADERS, RemoteSupportServiceImpl.CONTENT_TYPE_HEADER_VALUE);
        resp = rb.build();
        return resp;
    }
    
    private RefSponsor findRefSponsor(String sponsorCode) {
        RefSponsor sponsor = null;
        String sponsorName = "";
 
        if (sponsorCode != null) {
	        if (RefSponsor.SPONSOR_CODE_OS.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_OPERATION_SANTA;
	        }
	        else if (RefSponsor.SPONSOR_CODE_COA.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_CHANGE_ADDRESS;
	        }
	        else if (RefSponsor.SPONSOR_CODE_CR.equalsIgnoreCase(sponsorCode.toUpperCase())) {
	        	sponsorName = RefSponsor.SPONSOR_CUSTREG;
	        }
	        
	        sponsor = refSponsorDataService.findBySponsorName(sponsorName);
	        return sponsor;
        }
        
        return null;
    }
}
