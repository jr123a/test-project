package com.ips.validation;

import static com.ips.common.common.IVSCommonConstants.ALPHA;
import static com.ips.common.common.IVSCommonConstants.ABBREVIATED_STATE;
import static com.ips.persistence.common.IPSConstants.*;

/**
 * This enum is used to validate the fields in the PersonVo object using reflection and regex.
 * @author dmmnf0
 *
 */
public enum RemoteProofingValidatedField {
	SPONSOR_CODE         ("sponsorCode",        false, ALPHA),
	APP_CODE             ("appCode",            false, ALPHA),
    CUSTOMER_UNIQUE_ID   ("customerUniqueID",   true,  ALPHA_NUMERIC_WITH_HYPHEN),
    FIRST_NAME           ("firstName",          true,  FIRSTNAME_LASTNAME_REGEX),
    LAST_NAME            ("lastName",           true,  FIRSTNAME_LASTNAME_REGEX),
    STREET_ADDRESS_1     ("streetAddress1",     true,  STREET_ADDRESS_REGEX),
    STREET_ADDRESS_2     ("streetAddress2",     false, STREET_ADDRESS_REGEX),
    STREET_ADDRESS_3     ("streetAddress3",     false, STREET_ADDRESS_REGEX),
    CITY                 ("city",               true,  CITY_REGEX),
    STATE                ("state",              true,  ABBREVIATED_STATE),
    ZIPCODE              ("zipCode",            true,  ZIP_CODE_REGEX),
    URBANIZATION_CODE    ("urbanizationCode",   false, STREET_ADDRESS_REGEX),
    COUNTRY              ("country",            false, ALPHA),
    COMPANY_NAME         ("companyName",        false, COMPANY_NAME_REGEX),
    COMPANY_FEIN         ("companyFEIN",        false, NUMERIC_9_DIGIT),
    MOBILE_PHONE         ("mobilePhone",        true,  PHONE_NUMBER_10_DIGIT),
    BIRTH_DATE           ("dob",                false, MMDDYYYY_FMT_REGEX),
    PASSCODE             ("passcode",           true,  NUMERIC_4_6_DIGIT),
    EMAIL_ADDRESS        ("emailAddress",       true,  EMAIL_ADDRESS_REGEX),
    TRUE_IP_ADDRESS      ("trueIPAddress",      true,  IP_V6_V4_DUALV6),
    WEB_SESSION_ID       ("webSessionID",       true,  ALPHA_NUMERIC_WITH_HYPHEN_UNDERSCORE),
    PROFILING_SESSION_ID ("profilingSessionID", true,  ALPHA_NUMERIC_WITH_HYPHEN);
 	
	public static final String FIELD_SPONSOR_CODE         = "sponsorCode";
	public static final String FIELD_APP_CODE             = "appCode";
	public static final String FIELD_CUSTOMER_UNIQUE_ID   = "customerUniqueID";
	public static final String FIELD_FIRST_NAME           = "firstName";
	public static final String FIELD_LAST_NAME            = "lastName";
	public static final String FIELD_STREET_ADDRESS_1     = "streetAddress1";
	public static final String FIELD_STREET_ADDRESS_2     = "streetAddress2";
	public static final String FIELD_STREET_ADDRESS_3     = "streetAddress3";
	public static final String FIELD_CITY                 = "city";
	public static final String FIELD_STATE                = "state";
	public static final String FIELD_ZIPCODE              = "zipCode";
	public static final String FIELD_URBANIZATION_CODE    = "urbanizationCode";
	public static final String FIELD_COUNTRY              = "country";
	public static final String FIELD_COMPANY_NAME         = "companyName";
	public static final String FIELD_COMPANY_FEIN         = "companyFEIN";
	public static final String FIELD_MOBILE_PHONE         = "mobilePhone";
	public static final String FIELD_BIRTH_DATE           = "dob";
	public static final String FIELD_PASSCODE             = "passcode";
	public static final String FIELD_EMAIL_ADDRESS        = "emailAddress";
	public static final String FIELD_TRUE_IP_ADDRESS      = "trueIPAddress";
	public static final String FIELD_WEB_SESSION_ID       = "webSessionID";
	public static final String FIELD_PROFILING_SESSION_ID = "profilingSessionID";

    private String fieldName;
    private boolean required;
    private String regex;
     
    private RemoteProofingValidatedField(String fieldName, boolean required, String regex) {
        this.fieldName = fieldName;
        this.required = required;
        this.regex = regex;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getRegex() {
        return regex;
    }

    public boolean isRequired() {
        return required;
    }
    
    public static RemoteProofingValidatedField lookupByFieldName(String fieldName) {
        for (RemoteProofingValidatedField r : RemoteProofingValidatedField.values()) {
            if (r.getFieldName().equalsIgnoreCase(fieldName))  {
                return r;
            }
        }
        return null;
    }
}
