package com.ips.validation;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ips.common.common.Utils;
import com.ips.persistence.common.CountryCode;
import com.ips.request.RemoteRequest;
import com.ips.response.InputValidationError;
import com.ips.response.ValidationError;
import com.ips.service.RemoteProofingServiceImpl;

public class RemoteProofingValidation implements Serializable {
    private final static long serialVersionUID = 1L;

    private final static Logger LOG = LogManager.getLogger(RemoteProofingValidation.class.getName()); 
    private final static String SEPARATOR = ", ";
    private final static String VALUE_COUNTRY_US = "US";
    private final static String VALUE_COUNTRY_GB = "GB";
    private final static String VALUE_COUNTRY_UK = "UK";
    private final static String PARAM_LONGER = "longer"; 
    private final static String PARAM_SHORTER = "shorter"; 
    public  final static String SPONSOR_APP_DISABLED_FMT = "Web service call for %s application of %s sponsor is disabled";
 	private final static List<String> alpha2CodesList = Arrays.asList(CountryCode.getAlpha2Codes());
	private final static List<String> alpha3CodesList = Arrays.asList(CountryCode.getAlpha3Codes());

    public static HashMap<String, ValidationError> validateRemoteProofingData(RemoteRequest remReq) {
        HashMap<String, ValidationError> validationErrorMap = new HashMap<>();
		
    	String assessmentCall = remReq.getAssessmentCall();
 		boolean checkDevice = RemoteProofingServiceImpl.CHECK_DEVICE.equalsIgnoreCase(assessmentCall);
 		boolean checkDevicePlus = RemoteProofingServiceImpl.CHECK_DEVICE_PLUS.equalsIgnoreCase(assessmentCall);
  		boolean verifyPhone = RemoteProofingServiceImpl.VERIFY_PHONE.equalsIgnoreCase(assessmentCall);
 		boolean confirmPasscode = RemoteProofingServiceImpl.CONFIRM_PASSCODE.equalsIgnoreCase(assessmentCall);
 		boolean requestPasscode = RemoteProofingServiceImpl.REQUEST_PASSCODE.equalsIgnoreCase(assessmentCall);
 		boolean validateLink = RemoteProofingServiceImpl.VALIDATE_LINK.equalsIgnoreCase(assessmentCall);
 		boolean resendLink = RemoteProofingServiceImpl.RESEND_LINK.equalsIgnoreCase(assessmentCall);
 		boolean hasPersonDataInput = checkDevicePlus || checkDevice || verifyPhone || requestPasscode
 				|| resendLink;
 		boolean domesticAddress = false;
 				
    	String fieldValue = null;
      	String notAllowedChars = "";
      	ErrorMessage errorMessage = null;
      	
      	if (hasPersonDataInput) {
	      	String countryFieldName = RemoteProofingValidatedField.FIELD_COUNTRY;
	  		fieldValue = remReq.getCountry();
	  		errorMessage = getNullOrEmptyFieldErrorMsg(countryFieldName, fieldValue, true, validationErrorMap);
	
	        if (errorMessage != null) {
	       		fieldValue = VALUE_COUNTRY_US;
	       		remReq.setCountry(VALUE_COUNTRY_US);
	       		domesticAddress = true;
	    	}
	       	else {
	       		RemoteProofingValidatedField fieldValidation = RemoteProofingValidatedField.lookupByFieldName(countryFieldName);
	       		
	       		errorMessage = checkFormatValidationError(countryFieldName, fieldValue, null, fieldValidation.getRegex(), 2, 3, 
	        			false, validationErrorMap);
	          	
	       		if (errorMessage == null) {       		        		
	        		
	        		if (errorMessage == null) {
	        			if(fieldValue.length() == 3) {
	        				fieldValue = CountryCode.convertAlpha3ToAlpha2(fieldValue);
	        			}
	
	        			if (VALUE_COUNTRY_US.equalsIgnoreCase(fieldValue)) {
	        				domesticAddress = true;
	        			}
	        			else if (VALUE_COUNTRY_GB.equalsIgnoreCase(fieldValue)) {
	        				fieldValue = VALUE_COUNTRY_UK;
	        			}
	        			
	        			remReq.setCountry(fieldValue);
	          		}
	       		}
	    	}
      	}

        RemoteProofingValidatedField[] validatedFieldArray = null;
		try {
			validatedFieldArray = getRemoteProofingValidatedField(assessmentCall);
		} catch (Exception e) {
			LOG.error("Exception occurred while getting RemoteProofingValidatedField", e);
			return null;
		}
            	    
        for (RemoteProofingValidatedField fieldValidation : validatedFieldArray) {
           	try {
           		String fieldName = fieldValidation.getFieldName();

           		switch(fieldName) {
	           		case RemoteProofingValidatedField.FIELD_SPONSOR_CODE:
	           		case RemoteProofingValidatedField.FIELD_APP_CODE:

	           			if (RemoteProofingValidatedField.FIELD_SPONSOR_CODE.equalsIgnoreCase(fieldName)) {
	           				fieldValue = remReq.getSponsorCode();
                		}
                		else {
                			fieldValue = remReq.getAppCode();
                		}
	                	
	                	errorMessage = checkFormatValidationError(fieldName, fieldValue, null, fieldValidation.getRegex(), 2, 3, 
	                			true, validationErrorMap);
	                	
	                	if (errorMessage == null) {
	                		if (RemoteProofingValidatedField.FIELD_SPONSOR_CODE.equalsIgnoreCase(fieldName)) {
	                			remReq.setSponsorCode(fieldValue);
	                		}
	                		else {
	                			remReq.setAppCode(fieldValue);
	                		}
	                	}
	         			break;
 	           		case RemoteProofingValidatedField.FIELD_COMPANY_NAME:
	                	fieldValue = remReq.getCompanyName();
	                	
	         			notAllowedChars   = "!$%^*\"<>=[]\\;{}|:`~"; 
	   				    //All nonAlphaNum = "!$%^*\"<>=[]\\;{}|:`~@+?&()#/.,'-_"; 
	   			  	    //Allowed Chars   = "A1 @+?&()#/.,'-_";         			
	         			//Regex: ^[A-Za-z0-9\\-\\.'_,\"&()?#/+@\\s]*$ (from CustReg)
						
	         			errorMessage = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 0, 
	                			true, validationErrorMap);
	         			
	         			if (errorMessage == null) {
	                		remReq.setCompanyName(fieldValue);
	                	}
	                	break;
	             	case RemoteProofingValidatedField.FIELD_COMPANY_FEIN:
						fieldValue = remReq.getCompanyFEIN();
							
						//Regex: ^[0-9]{9}$
						
						errorMessage = checkFormatValidationError(fieldName, fieldValue, null, fieldValidation.getRegex(), 0, 0, 
	                			fieldValidation.isRequired(), validationErrorMap);
						
						if (errorMessage == null) {
	                		remReq.setCompanyFEIN(fieldValue);
	                	}
	           			break;
	           		case RemoteProofingValidatedField.FIELD_FIRST_NAME:
	           		case RemoteProofingValidatedField.FIELD_LAST_NAME:

	                	fieldValue = RemoteProofingValidatedField.FIELD_FIRST_NAME.equalsIgnoreCase(fieldName) ? remReq.getFirstName() : remReq.getLastName();
	                	
	         			notAllowedChars   = "!@$%^&*()+\"<>?=[]\\;{}|`~#/,:_";
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/,:_.'-";
	   			  	    //Allowed Chars   = "A .'-";
						//Regex: ^[\\sA-Za-z'\\.'\\-]*$ (FirstName)
	         			//Regex: ^[\\sA-Za-z'\\-\\.]*$ (LastName)
	         			
	         			errorMessage = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 0, 
	                			fieldValidation.isRequired(), validationErrorMap);
	         			
	         			if (errorMessage == null) {
	                		if (RemoteProofingValidatedField.FIELD_FIRST_NAME.equalsIgnoreCase(fieldName)) {
	                			remReq.setFirstName(fieldValue);
	                		}
	                		else {
	                			remReq.setLastName(fieldValue);
	                		}
	                	}
	           			break;                  
	           		case RemoteProofingValidatedField.FIELD_EMAIL_ADDRESS:
	                	fieldValue = remReq.getEmailAddress();
	                	
	         			notAllowedChars   = "!$%^&*()\"<>?=[]\\;{}|`~#/,:'";
	   				    //All nonAlphaNum = "!$%^&*()\"<>?=[]\\;{}|`~#/,:'+@.-_";
	   			  	    //Allowed Chars   = "A1_-.@+";
	         			//Regex:^([0-9a-zA-Z]([-.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$
		         			
	         			errorMessage = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 0, 
	                			fieldValidation.isRequired(), validationErrorMap);
	         			
	         			if (errorMessage == null) {
	                		remReq.setEmailAddress(fieldValue);
	                	}
	         			break;
	           		case RemoteProofingValidatedField.FIELD_STREET_ADDRESS_1:
	                	fieldValue = remReq.getStreetAddress1();
	                	
	         			notAllowedChars   = "!$%^*<>=[]\\;{}|`:~"; 
	   				    //All nonAlphaNum = "!$%^*<>=[]\\;{}|`:~&@()+?#/.,'-_\""; 
	   			  	    //Allowed Chars   = "A1 #/-.,'_?+&@()\"";
	         			//Regex: ^[0-9A-Za-z'\-\._",&()?#/+@\s]*$
	         			
	         			errorMessage = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 0, 
	                			fieldValidation.isRequired(), validationErrorMap);
	         			
	         			if (errorMessage == null) {
	                		remReq.setStreetAddress1(fieldValue);
	                	}
	                	break;
	           		case RemoteProofingValidatedField.FIELD_STREET_ADDRESS_2:
	                	fieldValue = remReq.getStreetAddress2();
	                	
	                	if (domesticAddress) {
	                		notAllowedChars   = "!$%^*<>=[]\\;{}|`:~"; 
		   				    //All nonAlphaNum = "!$%^*<>=[]\\;{}|`:~&@()+?#/.,'-_\""; 
		   			  	    //Allowed Chars   = "A1 #/-.,'_?+&@()\"";
		         			//Regex: ^[0-9A-Za-z'\-\._",&()?#/+@\s]*$
							
	                		errorMessage = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 0, 
		                			fieldValidation.isRequired(), validationErrorMap);
	                	}
	                	else {
	 	                	remReq.setStreetAddress2(null);
	 	                	remReq.setStreetAddress3(null);
	 	                }
	                	
                		if (errorMessage == null && fieldValidation.isRequired()) {
	                		remReq.setStreetAddress2(fieldValue);
	                	}
	                	break;
 	           		case RemoteProofingValidatedField.FIELD_CITY:
	         			fieldValue = remReq.getCity();
	         			
	         			notAllowedChars   = "!@$%^&*()+\"<>?=[]\\;{}|`~#/,:_"; 
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/,:_.'-"; 
	   			  	    //Allowed Chars   = "A -'.";
	         			//Regex: ^[A-Za-z'\-\.\s]*$
						
	         			errorMessage = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 0, 
	                			fieldValidation.isRequired(), validationErrorMap);
	         		
	         			if (errorMessage == null) {
	                		remReq.setCity(fieldValue);
	                	}
	                	break;
	           		case RemoteProofingValidatedField.FIELD_STATE:
	         			fieldValue = remReq.getState();
		    				    
	         			if (domesticAddress) {
	         				errorMessage = checkFormatValidationError(fieldName, fieldValue, null, null, 2, 2, 
		                			fieldValidation.isRequired(), validationErrorMap);
	                      	
	         				if (errorMessage == null) {
	         					errorMessage = validateDomesticStates(fieldName, fieldValue, validationErrorMap);
	                		}
	         			}
	         			else {
	         				//Regex: ^[A-Za-z'\-\.\s]*$
	         			}
	         			
	         			if (errorMessage == null) {
	                		remReq.setState(fieldValue);
	                	}
	         			break;
 	           		case RemoteProofingValidatedField.FIELD_ZIPCODE:
	         			fieldValue = remReq.getZipCode();
	         			
		         		notAllowedChars   = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'_";
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'_-";
	   			  	    //Allowed Chars   = "1-";
						
	         			String validationRegex = null;
	                	int minLength = 0;
	                	int maxLength = 0;
	                	
	                	if (domesticAddress) {
	                		minLength = 5;
	                    	maxLength = 10;
	                		validationRegex = fieldValidation.getRegex();
	                	}
	                	else {
	                		notAllowedChars   = "!$%^*<>=[]\\;{}|`~:";
		   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'-_";
		   			  	    //Allowed Chars   = "A1-";
		         			//Regex: ^[0-9\-\.'\sA-Za-z"_&( ),?#/+@]*$
	                	}
	                	
	                	errorMessage = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, validationRegex, minLength, maxLength, 
	                			fieldValidation.isRequired(), validationErrorMap);
	                  	
	                	if (errorMessage == null) {
	                		if (domesticAddress) {
	                			errorMessage = getZipCodeValidationErrorMsg(fieldName, fieldValue, validationErrorMap);
	                		}
	                	}
	                	
	                	if (errorMessage == null) {
	                		remReq.setZipCode(fieldValue);
	                	}
	                	break;
	           		case RemoteProofingValidatedField.FIELD_URBANIZATION_CODE:
						fieldValue = remReq.getUrbanizationCode();
						
						notAllowedChars   = "!$%^*<>=[]\\;{}|`:~"; 
	   				    //All nonAlphaNum = "!$%^*<>=[]\\;{}|`:~&@()+?#/.,'-_\""; 
	   			  	    //Allowed Chars   = "A1 #/-.,'_?+&@()\"";
	         			//Regex: ^[0-9A-Za-z'\-\._",&()?#/+@\s]*$
						
						errorMessage = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 0, 
	                			fieldValidation.isRequired(), validationErrorMap);
	                	
						if (errorMessage == null) {
	                		remReq.setUrbanizationCode(fieldValue);
	                	}
						break;
	           		case RemoteProofingValidatedField.FIELD_MOBILE_PHONE:
	                	fieldValue = remReq.getMobilePhone();
	                	
	                	notAllowedChars   = "!@$%^&*_\"<>?=[]\\;{}|`~#/.,:'";
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'-_"; 
	   			  	    //Allowed Chars   = "1+-()";  
	    				    
	                	validationRegex = null;
	                	minLength = 4;
	                	maxLength = 15;
	                	
	                	if (domesticAddress) {
	                		minLength = 10;
	                		validationRegex = fieldValidation.getRegex();

	                		if (fieldValue != null) {
	                			//Strip off spaces
		                		fieldValue = fieldValue.replaceAll("\\s+", "");
	                			
		                		//Strip off leading +1 chars
		                		if (fieldValue.startsWith("+1")) {
		               	        	fieldValue = fieldValue.substring(2, fieldValue.length());
		               	        }	
	                		}
	                	}

	                	errorMessage = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, validationRegex, minLength, maxLength, 
	                			fieldValidation.isRequired(), true, true, validationErrorMap);
	                	
	                	if (errorMessage == null) {
	                		remReq.setMobilePhone(fieldValue);
	                	}
	                	break; 
	           		case RemoteProofingValidatedField.FIELD_CUSTOMER_UNIQUE_ID:
	                	fieldValue = remReq.getCustomerUniqueID();
	                	
	                	notAllowedChars   = "!@$%^&*()_+\"<>?=[]\\;{}|`~#/,-";
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'-_";
	   			  	    //Allowed Chars   = "A1 :.";
	    				    
	                	errorMessage = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 50, 
	                			fieldValidation.isRequired(), validationErrorMap);
	                	
	                	if (errorMessage == null) {
	                		remReq.setCustomerUniqueID(fieldValue);
	                	}
	                	break;
 	           		case RemoteProofingValidatedField.FIELD_PROFILING_SESSION_ID:
	           		case RemoteProofingValidatedField.FIELD_WEB_SESSION_ID:
   	                	fieldValue = RemoteProofingValidatedField.FIELD_PROFILING_SESSION_ID.equalsIgnoreCase(fieldName) ? remReq.getProfilingSessionID() : remReq.getWebSessionID();
 
                		notAllowedChars   = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'";
	   				    //All nonAlphaNum = "!@$%^&*()+\"<>?=[]\\;{}|`~#/.,:'-_";
	   			  	    //Allowed Chars   = "A1 -_'";
	    				    
	                	errorMessage = checkFormatValidationError(fieldName, fieldValue, notAllowedChars, fieldValidation.getRegex(), 0, 50, 
	                			fieldValidation.isRequired(), validationErrorMap);
	                	
	                	if (errorMessage == null) {
	                		if (RemoteProofingValidatedField.FIELD_PROFILING_SESSION_ID.equalsIgnoreCase(fieldName)) {
		                		remReq.setProfilingSessionID(fieldValue);
	                		}
	                		else {
	                    		remReq.setWebSessionID(fieldValue);
	                		}
	                	}
	                	break;
	                default:
           		}
            } catch (Exception e) {
                LOG.error("Exception occurred while validating remote data", e);
            }
         
    	}

        return validationErrorMap;
    }
    
    private static ErrorMessage checkFormatValidationError(String fieldName, String fieldValue, String notAllowedChars, String validationRegex,
    		int minLength, int maxLength, boolean required, HashMap<String, ValidationError> validationErrorMap) {
    	return checkFormatValidationError(fieldName, fieldValue, notAllowedChars, validationRegex, minLength, maxLength, required, false, false, validationErrorMap);
    }

    private static ErrorMessage checkFormatValidationError(String fieldName, String fieldValue, String notAllowedChars, String validationRegex,
    		int minLength, int maxLength, boolean required, boolean removeNonNumeric, boolean checkSameDigit, HashMap<String, ValidationError> validationErrorMap) {
       	
      	if (fieldValue != null) {
      		fieldValue = fieldValue.trim();
      	}
      	
      	ErrorMessage errorMessage = getNullOrEmptyFieldErrorMsg(fieldName, fieldValue, required, validationErrorMap);
      	
       	if (errorMessage == null) {
       		errorMessage = maxLengthValidationErrorMsg(fieldName, fieldValue, maxLength);
   			
       		if (errorMessage == null) {
       			errorMessage = minLengthValidationErrorMsg(fieldName, fieldValue, minLength);
	    			
       			if (errorMessage == null) {
       				errorMessage = getContainsNotAllowedCharsErrorMessage(fieldName, fieldValue, notAllowedChars);

       				if (errorMessage == null) {
	   					if (removeNonNumeric) {
	   						fieldValue = Utils.removeNonNumericCharactersFromString(fieldValue);
	   					}
	   					
	   					errorMessage = getInvalidFormatMessage(fieldName, fieldValue, validationRegex);
		   				
		   				if (errorMessage == null && checkSameDigit) {
		   					errorMessage = getSameDigitErrorMessage(fieldName, fieldValue);
		   				}
	   				}
	   			}
       		}
       	}
       	
       	if (errorMessage != null) {
        	ValidationError validationError = getValidationError(fieldName, fieldValue, errorMessage);
	  		validationErrorMap.put(fieldName, validationError);
       	}

       	return errorMessage;
    }
    
    private static ErrorMessage getNullOrEmptyFieldErrorMsg(String fieldName, String fieldValue, boolean requiredField, HashMap<String, ValidationError> validationErrorMap) {
    	ErrorMessage errorMessage = null;
    	if (requiredField) {
		   	if (fieldValue == null) {
		   		errorMessage = ErrorMessage.MISSING_REQUIRED_FIELD;
		    	errorMessage.setMessagePlaceholders(fieldName);
		    }
		   	else {
		       	if (Utils.isEmptyString(fieldValue)) {
		       		errorMessage = ErrorMessage.EMPTY_REQUIRED_FIELD;
		       		errorMessage.setMessagePlaceholders(fieldName);
		        } 
		   	}
    	}
     	
    	if (errorMessage != null && !RemoteProofingValidatedField.FIELD_COUNTRY.equalsIgnoreCase(fieldName)) {
	        	ValidationError validationError = getValidationError(fieldName, fieldValue, errorMessage);
	          	validationErrorMap.put(fieldName, validationError);
    	}
	   	return errorMessage;
    }
    
    private static ErrorMessage getInvalidFormatMessage(String fieldName, String fieldValue, String validationRegex) {
    	ErrorMessage errorMessage = null;
    	
		if (!Utils.isEmptyString(fieldValue)) {
			try {
		    	if (!Utils.isEmptyString(validationRegex) && !Utils.matches(fieldValue, validationRegex)) {
		    		errorMessage = ErrorMessage.INVALID_FORMATTING;
		    		errorMessage.setArguments(new String[] {fieldName});
		    		return errorMessage;
				}
			} catch (Exception e) {
				LOG.error("Exception occurred while getting InvalidFormatMessage", e);
				errorMessage = ErrorMessage.INVALID_INPUT_DATA;
	    		errorMessage.setArguments(new String[] {fieldName, e.getMessage()});
	    		return errorMessage;
			}
		}
    	
    	return null;
    }
    
    private static ErrorMessage getSameDigitErrorMessage(String fieldName, String fieldValue) {
    	ErrorMessage errorMessage = null;
    	
    	if ( fieldValue != null ) {
	       	int valueLen = fieldValue.length();
	  		String regex = String.format("^(\\d)(?!\\1+$)\\d{%s}$", valueLen - 1);
	
	  		boolean hasSameDigit = !fieldValue.matches(regex);
	    	 
	  		if (hasSameDigit) {
	  			errorMessage = ErrorMessage.SAME_DIGITS;
	  			errorMessage.setArguments(new String[] {fieldName}); 
	  		}
    	}

    	return errorMessage;
    }
       	
    public static ValidationError getValidationError(String fieldName, String fieldValue, ErrorMessage errorMessage) {   
		InputValidationError inputValidationError = new InputValidationError();
		inputValidationError.setFieldName(fieldName);
     	
		if (fieldValue != null) {
			inputValidationError.setFieldValue(fieldValue);
		}
		
		inputValidationError.setErrorMessage(errorMessage.getMessage());
		
		ValidationError validationError = new ValidationError();
		validationError.setErrorMessage(errorMessage);
		validationError.setInputValidationError(inputValidationError);
		
		return validationError;
    }
	
	public static InputValidationError getInputValidationError(String fieldName, String fieldValue, String validationErrorMsg) {   
		InputValidationError validationError = new InputValidationError();
		validationError.setFieldName(fieldName);
		
		if (fieldValue != null) {
			validationError.setFieldValue(fieldValue);
		}
		
		validationError.setErrorMessage(validationErrorMsg);
		
		return validationError;
    }
	
    private static ErrorMessage getContainsNotAllowedCharsErrorMessage(String fieldName, String fieldValue, String notAllowedChars) {
    	ErrorMessage errorMessage = null;
    	if (fieldValue != null) {
	    	if (!Utils.isEmptyString(notAllowedChars)) {
		    	for (int i = 0; i < fieldValue.length(); i++) {
		            char x = fieldValue.charAt(i);
		            if (notAllowedChars.contains(String.valueOf(x))) {
		            	errorMessage = ErrorMessage.INVALID_FORMATTING;
		            	errorMessage.setArguments(new String[] {fieldName});
		            	return errorMessage;
		            }
		        }
	    	}
    	}
    	
    	return null;
    }
    
    /**
     * Validates 2 letter state code for domestic, military and US territories. Returns true if valid.
     * 
     * @param state
     *            - 2 letter state code
     * @return true if state code is valid
     */
    public static ErrorMessage validateDomesticStates(String fieldName, String state, HashMap<String, ValidationError> validationErrorMap) {
       	String allUSStates = "AL,AK,AS,AZ,AR,CA,CO,CT,DE,DC,FM,FL,GA,GU,HI,ID,IL,IN,IA,KS,KY,LA,"
    			+ "ME,MH,MD,MA,MI,MN,MS,MO,MT,NE,NV,NH,NJ,NM,NY,NC,ND,MP,OH,OK,OR,PW,PA,PR,RI,SC,"
    			+ "SD,TN,TX,UT,VT,VI,VA,WA,WV,WI,WY,AA,AE,AP";
       	
       	ErrorMessage errorMessage = null;
       	boolean isValidUSState = allUSStates.contains(state.toUpperCase());
       	
       	if (!isValidUSState) {
	       	errorMessage = ErrorMessage.INVALID_2_LETTER_CODE;
			errorMessage.setArguments(new String[] {fieldName});
        	ValidationError validationError = getValidationError(fieldName, state, errorMessage);
	  		validationErrorMap.put(fieldName, validationError);
       	}
       	
        return errorMessage;
    }

    /**
     * Validates 2 letter abbreviation for international countries. Returns true if valid.
     * 
     * @param countryAbbr - 2 letter countryAbbr code
     * @return true if countryAbbr is valid
     */
    public static ErrorMessage getCountryAbbrValidationError(String fieldName, String countryAbbr, HashMap<String, ValidationError> validationErrorMap) {
     	ErrorMessage errorMessage = null;
    	countryAbbr = countryAbbr.toUpperCase();
   		
    	if (VALUE_COUNTRY_UK.equalsIgnoreCase(countryAbbr)) {
   			countryAbbr = VALUE_COUNTRY_GB;
		}

       	if (countryAbbr.length() == 2 && !alpha2CodesList.contains(countryAbbr)) {
       		errorMessage = ErrorMessage.INVALID_2_LETTER_CODE;
       		errorMessage.setArguments(new String[] {RemoteProofingValidatedField.FIELD_COUNTRY});
        } else if(countryAbbr.length() == 3 && !alpha3CodesList.contains(countryAbbr.toUpperCase())){
        	errorMessage = ErrorMessage.INVALID_3_LETTER_CODE;
       		errorMessage.setArguments(new String[] {RemoteProofingValidatedField.FIELD_COUNTRY});
       	}
       	
       	if (errorMessage != null) {
        	ValidationError validationError = getValidationError(fieldName, countryAbbr, errorMessage);
       		validationErrorMap.put(fieldName, validationError);
       	}
        return errorMessage;
    }
    
    /**
     * Performs validation on zip code field to make sure it's a 5 digit zip code or 9 digit zip code (XXXXX-XXXX)
     */
    private static ErrorMessage getZipCodeValidationErrorMsg(String fieldName, String fieldValue, HashMap<String, ValidationError> validationErrorMap) {
        ErrorMessage errorMessage = maxLengthValidationErrorMsg(fieldName, fieldValue, 10);
        
        if (errorMessage == null) {
           errorMessage = minLengthValidationErrorMsg(fieldName, fieldValue, 5);
           
           if (errorMessage == null) {
        	   if (fieldValue.length() == 5 && !org.apache.commons.lang3.StringUtils.isNumeric(fieldValue)) {
        		   errorMessage = ErrorMessage.INVALID_FORMATTING;
        		   errorMessage.setArguments(new String[] {fieldName});
          	   }
        	   
        	   if (errorMessage == null) {
        		   if (fieldValue.length() >= 6) {
        			   if (fieldValue.indexOf('-') == -1) {
        				   errorMessage = ErrorMessage.INVALID_FORMATTING;
                		   errorMessage.setArguments(new String[] {fieldName});
        	           } 
        			   
        			   if (errorMessage == null) {
        	                String[] zipComponents = fieldValue.split("-");
        	                String zip5 = zipComponents[0];
        	                String zip4 = "";
        	                
        	                if (zipComponents.length > 1) {
        	                	zip4 = zipComponents[1];
        	                 
        	                	boolean invalidZipCode = zip5.length() != 5 || zip4.length() != 4 || !org.apache.commons.lang3.StringUtils.isNumeric(zip5);
        	                	if (invalidZipCode) {
        	        				   errorMessage = ErrorMessage.INVALID_FORMATTING;
        	                		   errorMessage.setArguments(new String[] {fieldName});
        		                }
        	                }
        	            }
        		   }
        	   }
           }
        }
        	
        if (errorMessage != null) {
        	ValidationError validationError = getValidationError(fieldName, fieldValue, errorMessage);
       		validationErrorMap.put(fieldName, validationError);
        }

        return errorMessage;
    }

    /**
     * Performs value maximum length validation)
     */
    private static ErrorMessage maxLengthValidationErrorMsg(String fieldName, String fieldValue, int maxLength) {
        
        if (!Utils.isEmptyString(fieldValue) && maxLength > 0 && fieldValue.length() > maxLength) {
        	ErrorMessage errorMessage = ErrorMessage.INVALID_FIELD_LENGTH;
        	errorMessage.setArguments(new String[] {fieldName, PARAM_LONGER, String.valueOf(maxLength)});
          	return errorMessage;
        }

        return null;
    }
    
    /**
     * Performs value minimum length validation)
     */
    private static ErrorMessage minLengthValidationErrorMsg(String fieldName, String fieldValue, int minLength) {
        if (minLength > 0 && fieldValue.length() < minLength) {
        	ErrorMessage errorMessage = ErrorMessage.INVALID_FIELD_LENGTH;
        	errorMessage.setArguments(new String[] {fieldName, PARAM_SHORTER, String.valueOf(minLength)});
          	return errorMessage;
        }
        
        return null;
    }
    
    private static RemoteProofingValidatedField [] getRemoteProofingValidatedField(String assessmentCall) {
    	  RemoteProofingValidatedField [] validatedFieldArray = null;

    	  switch (assessmentCall) {
    	  	case RemoteProofingServiceImpl.CHECK_DEVICE_PLUS:
    		  validatedFieldArray = new RemoteProofingValidatedField [] {
    				RemoteProofingValidatedField.SPONSOR_CODE, 
    				RemoteProofingValidatedField.APP_CODE,
      				RemoteProofingValidatedField.COMPANY_NAME,
      				RemoteProofingValidatedField.COMPANY_FEIN,
      				RemoteProofingValidatedField.FIRST_NAME,
      				RemoteProofingValidatedField.LAST_NAME,
      				RemoteProofingValidatedField.EMAIL_ADDRESS,
      				RemoteProofingValidatedField.STREET_ADDRESS_1,
      				RemoteProofingValidatedField.STREET_ADDRESS_2,
      				RemoteProofingValidatedField.URBANIZATION_CODE,
      				RemoteProofingValidatedField.CITY,
      				RemoteProofingValidatedField.STATE,
      				RemoteProofingValidatedField.ZIPCODE,
      				RemoteProofingValidatedField.COUNTRY,
      				RemoteProofingValidatedField.MOBILE_PHONE,
      				RemoteProofingValidatedField.PROFILING_SESSION_ID,
      				RemoteProofingValidatedField.WEB_SESSION_ID,
      				RemoteProofingValidatedField.TRUE_IP_ADDRESS};
    		  break;
    	  	case RemoteProofingServiceImpl.CHECK_DEVICE:
            	 //EmailAddress is not required yet by COA and OS applications 
    	  		 validatedFieldArray = new RemoteProofingValidatedField [] {
    				RemoteProofingValidatedField.SPONSOR_CODE, 
      				RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
        			RemoteProofingValidatedField.FIRST_NAME,
      				RemoteProofingValidatedField.LAST_NAME,
       				RemoteProofingValidatedField.STREET_ADDRESS_1,
      				RemoteProofingValidatedField.STREET_ADDRESS_2,
       				RemoteProofingValidatedField.CITY,
      				RemoteProofingValidatedField.STATE,
      				RemoteProofingValidatedField.ZIPCODE,
       				RemoteProofingValidatedField.MOBILE_PHONE,
      				RemoteProofingValidatedField.PROFILING_SESSION_ID,
      				RemoteProofingValidatedField.WEB_SESSION_ID,
      				RemoteProofingValidatedField.TRUE_IP_ADDRESS};
    	  		break;
     	  	case RemoteProofingServiceImpl.VERIFY_PHONE:
   	  		 	validatedFieldArray = new RemoteProofingValidatedField [] {
   	  				RemoteProofingValidatedField.SPONSOR_CODE, 
   	  				RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
   	  				RemoteProofingValidatedField.FIRST_NAME,
   	  				RemoteProofingValidatedField.LAST_NAME,
   	  				RemoteProofingValidatedField.MOBILE_PHONE,
   	  				RemoteProofingValidatedField.STREET_ADDRESS_1,
   	  				RemoteProofingValidatedField.STREET_ADDRESS_2,
	   	  			RemoteProofingValidatedField.CITY,
	  				RemoteProofingValidatedField.STATE,
	  				RemoteProofingValidatedField.ZIPCODE};
    	  	  break;
     	  	case RemoteProofingServiceImpl.CONFIRM_PASSCODE: 
      	  		 validatedFieldArray = new RemoteProofingValidatedField [] {
      	  			RemoteProofingValidatedField.SPONSOR_CODE, 
     				RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
     				RemoteProofingValidatedField.PASSCODE};
       	  		  break;
     	  	case RemoteProofingServiceImpl.REQUEST_PASSCODE: 
     	  		  validatedFieldArray = new RemoteProofingValidatedField [] {
     	  			RemoteProofingValidatedField.SPONSOR_CODE, 
     	  			RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
     	    		RemoteProofingValidatedField.FIRST_NAME,
     	  			RemoteProofingValidatedField.LAST_NAME,
     	  			RemoteProofingValidatedField.MOBILE_PHONE,
     	   			RemoteProofingValidatedField.STREET_ADDRESS_1,
     	  			RemoteProofingValidatedField.STREET_ADDRESS_2,
     	   			RemoteProofingValidatedField.CITY,
     	  			RemoteProofingValidatedField.STATE,
     	  			RemoteProofingValidatedField.ZIPCODE};
      	  		  break;	  
     	  	case RemoteProofingServiceImpl.VALIDATE_LINK:
    	  		 validatedFieldArray = new RemoteProofingValidatedField [] {
    	  			RemoteProofingValidatedField.SPONSOR_CODE, 
    	  			RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
    	  			RemoteProofingValidatedField.MOBILE_PHONE};
     	  		  break;
     	  	case RemoteProofingServiceImpl.RESEND_LINK:
      	  		 validatedFieldArray = new RemoteProofingValidatedField [] {
      	  			RemoteProofingValidatedField.SPONSOR_CODE, 
     				RemoteProofingValidatedField.CUSTOMER_UNIQUE_ID,
     				RemoteProofingValidatedField.FIRST_NAME,
     				RemoteProofingValidatedField.LAST_NAME,
     				RemoteProofingValidatedField.MOBILE_PHONE,
      				RemoteProofingValidatedField.STREET_ADDRESS_1,
     				RemoteProofingValidatedField.STREET_ADDRESS_2,
      				RemoteProofingValidatedField.CITY,
     				RemoteProofingValidatedField.STATE,
     				RemoteProofingValidatedField.ZIPCODE};
       	  	  break;

    	  	default:    		  
    	  }
    	  return validatedFieldArray;
    }
}
