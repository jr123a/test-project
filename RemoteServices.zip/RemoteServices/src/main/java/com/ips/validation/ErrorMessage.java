package com.ips.validation;

import java.io.Serializable;

public enum ErrorMessage implements Serializable {
	MISSING_REQUIRED_FIELDS (402, "Required fields not provided: %s"),
	MISSING_REQUIRED_FIELD  (402, "%s is required but field is missing"),
	EMPTY_REQUIRED_FIELD    (402, "%s is required but value is empty"),
	INVALID_FORMAT_FIELDS 	(401, "Fields contain invalid characters or formatting: %s"),
	INVALID_FIELD_LENGTH 	(401, "%s must not be %s than %s characters"),
	INVALID_FORMATTING   	(400, "%s contains invalid characters or formatting is invalid"),
    SAME_DIGITS             (400, "%s contains same digits"),
    INVALID_2_LETTER_CODE   (400, "%s 2-Letter code is invalid"),
    INVALID_3_LETTER_CODE   (400, "%s 3-Letter code is invalid"),
    INVALID_CODE            (400, "%s for %s code cannot be found"),
    SPONSOR_APP_DISABLED    (400, "Web service calls for %s are disabled"),
	INVALID_INPUT_DATA      (400, "%s has invalid input data. Reason: %s"),
    SPONSOR_ID_NOT_FOUND    (400, "Sponsor for sponsorID %s not found"),
    MISSING_ANSWER          (400, "Answers must be provided for all questions"),
    INVALID_STRING_LENGTH   (400, "%s must not be %s than %s characters"),
    INTERNAL_ERROR          (500, "An internal error occurred processing the request"),
    INVALID_TRANSACTION     (400, "TransactionID does not map to an existing record"),
    INVALID_BARCODE_FORMA   (400, "Barcode format is invalid"),
    INVALID_PARSE_REQUEST   (400, "Error occurred while parsing barcode"),
    CUST_REG_BAD_RESPONSE   (500, "Could not retrieve cust reg info"), 
    AUTHENTICATION_FAILED   (405, "Authentication failed"),
    BAD_RESPONSE            (500, "Internal error."),
    INVALID_REQUEST         (500, "Invalid request."),
    SPONSOR_NOT_FOUND       (400, "Sponsor for sponsorCode not found"),
    APP_NOT_FOUND           (400, "Application for appCode not found"),
    EVENT_NOT_IN_SYSTEM     (400, "Proofing event not in system"),
    EVENT_NOT_FOUND         (400, "In Person Proofing event not found for record locator: %s");
    
	
    private int httpResponseCode;
    private String message;
    private Object[] messagePlaceholders;
    private String[] arguments;
    
    private ErrorMessage(int httpResponseCode, String message) {
        this.httpResponseCode = httpResponseCode;
        this.message = message;
    }

    public int getHttpResponseCode() {
        return httpResponseCode;
    }

    public String getMessage() {
        if (messagePlaceholders != null && messagePlaceholders.length > 0) {
             return String.format(message, messagePlaceholders);
        } else {
            return message;
        }
    }

    public Object[] getMessagePlaceholders() {
        return messagePlaceholders;
    }

    public void setMessagePlaceholders(Object[] messagePlaceholders) {
        this.messagePlaceholders = messagePlaceholders;
    }
    /**
     * Overloaded setter to take a single string argument
     * @param messagePlaceholder
     */
    public void setMessagePlaceholders(String messagePlaceholder) {
        this.messagePlaceholders = new Object[] {messagePlaceholder};
    }
    
    public void setArguments(String[] args) {
    	this.arguments = args;
    	if (args.length == 4) {
    		this.message = String.format(this.message, args[0], args[1], args[2], args[3]);
    	}
    	else if (args.length == 3) {
    		this.message = String.format(this.message, args[0], args[1], args[2]);
    	}
     	else if (args.length == 2) {
    		this.message = String.format(this.message, args[0], args[1]);
    	}
     	else if (args.length == 1) {
    		this.message = String.format(this.message, args[0]);
    	}
    }
    
    public String[] getArguments() {
    	return this.arguments;
    }
}
