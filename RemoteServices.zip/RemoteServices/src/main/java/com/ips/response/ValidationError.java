package com.ips.response;

import java.io.Serializable;

import com.ips.validation.ErrorMessage;


public class ValidationError implements Serializable {
	private static final long serialVersionUID = 1L;
	private ErrorMessage errorMessage;
	private InputValidationError inputValidationError;
	
	public ErrorMessage getErrorMessage() {
		return errorMessage;
	}
	
	public void setErrorMessage(ErrorMessage errorMessage) {
		this.errorMessage = errorMessage;
	}

	public InputValidationError getInputValidationError() {
		return inputValidationError;
	}

	public void setInputValidationError(InputValidationError inputValidationError) {
		this.inputValidationError = inputValidationError;
	}
}
