package com.ips.response;

import java.io.Serializable;

public class RemoteResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    private String transactionID;
    private String conversationID;
    private String verified;
    private String phoneVerified;
    private String passcodeSent;
    private String passcodeExpired;
    private String reviewStatus;
    private String reasonCode;
    private Long attemptsIn72Hours;
    private Long phoneAttemptsIn72Hours;
    private Long passcodeAttemptsIn180Hours;
    private String lockoutExpiresDateTime;
    private String confirmationLimitReached;
    private Integer confirmationAttemptsForPasscode;
    private String responseMessage;

    public String getTransactionID() {
        return transactionID;
    }
    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }
    public String getConversationID() {
		return conversationID;
	}
	public void setConversationID(String conversationID) {
		this.conversationID = conversationID;
	}
	public String getVerified() {
        return verified;
    }
    public void setVerified(String verified) {
        this.verified = verified;
    }
    public String getPhoneVerified() {
        return phoneVerified;
    }
    public void setPhoneVerified(String phoneVerified) {
        this.phoneVerified = phoneVerified;
    }
    public String getPasscodeSent() {
        return passcodeSent;
    }
    public void setPasscodeSent(String passcodeSent) {
        this.passcodeSent = passcodeSent;
    }
    public String getPasscodeExpired() {
        return passcodeExpired;
    }
    public void setPasscodeExpired(String passcodeExpired) {
        this.passcodeExpired = passcodeExpired;
    }
    public String getReviewStatus() {
		return reviewStatus;
	}
	public void setReviewStatus(String reviewStatus) {
		this.reviewStatus = reviewStatus;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getLockoutExpiresDateTime() {
        return lockoutExpiresDateTime;
    }
    public void setLockoutExpiresDateTime(String lockoutExpiresDateTime) {
        this.lockoutExpiresDateTime = lockoutExpiresDateTime;
    }
    public String getResponseMessage() {
        return responseMessage;
    }
    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }
    public Long getAttemptsIn72Hours() {
        return attemptsIn72Hours;
    }
    public void setAttemptsIn72Hours(Long attemptsIn72Hours) {
        this.attemptsIn72Hours = attemptsIn72Hours;
    }
    public Long getPhoneAttemptsIn72Hours() {
        return phoneAttemptsIn72Hours;
    }
    public void setPhoneAttemptsIn72Hours(Long phoneAttemptsIn72Hours) {
        this.phoneAttemptsIn72Hours = phoneAttemptsIn72Hours;
    }
    public Long getPasscodeAttemptsIn180Hours() {
        return passcodeAttemptsIn180Hours;
    }
    public void setPasscodeAttemptsIn180Hours(Long passcodeAttemptsIn180Hours) {
        this.passcodeAttemptsIn180Hours = passcodeAttemptsIn180Hours;
    }
    public String getConfirmationLimitReached() {
        return confirmationLimitReached;
    }
    public void setConfirmationLimitReached(String confirmationLimitReached) {
        this.confirmationLimitReached = confirmationLimitReached;
    }
    public Integer getConfirmationAttemptsForPasscode() {
        return confirmationAttemptsForPasscode;
    }
    public void setConfirmationAttemptsForPasscode(Integer confirmationAttemptsForPasscode) {
        this.confirmationAttemptsForPasscode = confirmationAttemptsForPasscode;
    }
}
