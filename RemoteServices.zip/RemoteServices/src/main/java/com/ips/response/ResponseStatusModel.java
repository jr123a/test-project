package com.ips.response;

import java.io.Serializable;

import com.lexisnexis.ns.identity_proofing._1.RdpReasonCodeModel;

public class ResponseStatusModel implements Serializable {
	private static final long serialVersionUID = 1L;
	private String IVSReferenceId;
	private String TransactionStatus;
	private String Reference;
	private RdpReasonCodeModel TransactionReasonCode;

	public String getIVSReferenceId() {
		return IVSReferenceId;
	}
	
	public void setIVSReferenceId(String iVSReferenceId) {
		IVSReferenceId = iVSReferenceId;
	}
	
	public String getTransactionStatus() {
		return TransactionStatus;
	}
	
	public void setTransactionStatus(String transactionStatus) {
		TransactionStatus = transactionStatus;
	}
	
	public String getReference() {
		return Reference;
	}
	
	public void setReference(String reference) {
		Reference = reference;
	}
	public RdpReasonCodeModel getTransactionReasonCode() {
		return TransactionReasonCode;
	}
	
	public void setTransactionReasonCode(RdpReasonCodeModel transactionReasonCode) {
		TransactionReasonCode = transactionReasonCode;
	}
	
}
