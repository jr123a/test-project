package com.ips.request;

import java.io.Serializable;

public class RemoteRequest implements Serializable {
    private static final long serialVersionUID = 1L;
	private Long sponsorID;
	private Long appID;
	private String sponsorCode;
	private String appCode;
    private String sponsorName;
    private String appName;
    private String customerUniqueID;
    private String firstName;
    private String lastName;
    private String companyName;
    private String companyFEIN;
    private String streetAddress1;
    private String streetAddress2;
    private String streetAddress3;
    private String city;
    private String state;
    private String zipCode;
    private String urbanizationCode;
    private String country;
    private String birthDate;
    private String mobilePhone;
    private String passcode;
    private String emailAddress;
    private String trueIPAddress;
    private String webSessionID;
    private String profilingSessionID;
    private String otpExpiresMinutes;
    private String smsUrl;
    private String targetUrl;
    private String stubCaseKey;
    private String returnDebugData;
    private String deviceTypeMobile;
    private String highRiskAddressId;
    private String checkHighRiskAddress;
    private String assessmentCall;
    
	public Long getSponsorID() {
        return sponsorID;
    }
	
    public void setSponsorID(Long sponsorID) {
        this.sponsorID = sponsorID;
    }
    
	public Long getAppID() {
		return appID;
	}

	public void setAppID(Long appID) {
		this.appID = appID;
	}

	public String getSponsorCode() {
		return sponsorCode;
	}
	
	public void setSponsorCode(String sponsorCode) {
		this.sponsorCode = sponsorCode;
	}
	
	public String getSponsorName() {
		return sponsorName;
	}
	
	public void setSponsorName(String sponsorName) {
		this.sponsorName = sponsorName;
	}
	
	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}
	
    public String getCustomerUniqueID() {
        return customerUniqueID;
    }
  
	public void setCustomerUniqueID(String customerUniqueID) {
        this.customerUniqueID = customerUniqueID;
    }
	
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyFEIN() {
		return companyFEIN;
	}

	public void setCompanyFEIN(String companyFEIN) {
		this.companyFEIN = companyFEIN;
	}

	public String getStreetAddress1() {
        return streetAddress1;
    }
    
    public void setStreetAddress1(String streetAddress1) {
        this.streetAddress1 = streetAddress1;
    }
    
    public String getStreetAddress2() {
        return streetAddress2;
    }
    
    public void setStreetAddress2(String streetAddress2) {
        this.streetAddress2 = streetAddress2;
    }
    
	public String getStreetAddress3() {
		return streetAddress3;
	}
	
	public void setStreetAddress3(String streetAddress3) {
		this.streetAddress3 = streetAddress3;
	}
	
    public String getCity() {
        return city;
    }
    
    public void setCity(String city) {
        this.city = city;
    }
    
    public String getState() {
        return state;
    }
    
    public void setState(String state) {
        this.state = state;
    }
    
    public String getZipCode() {
        return zipCode;
    }
    
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
    
	public String getUrbanizationCode() {
		return urbanizationCode;
	}
	
	public void setUrbanizationCode(String urbanizationCode) {
		this.urbanizationCode = urbanizationCode;
	}
	
    public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getBirthDate() {
        return birthDate;
    }
    
    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }
    
    public String getMobilePhone() {
        return mobilePhone;
    }
    
    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }
    
    public String getPasscode() {
        return passcode;
    }
    
    public void setPasscode(String passcode) {
        this.passcode = passcode;
    }
     
	public String getEmailAddress() {
		return emailAddress;
	}
	
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	public String getTrueIPAddress() {
		return trueIPAddress;
	}
	
	public void setTrueIPAddress(String trueIPAddress) {
		this.trueIPAddress = trueIPAddress;
	}
	
	public String getWebSessionID() {
		return webSessionID;
	}
	
	public void setWebSessionID(String webSessionID) {
		this.webSessionID = webSessionID;
	}
	
	public String getProfilingSessionID() {
		return profilingSessionID;
	}
	
	public void setProfilingSessionID(String profilingSessionID) {
		this.profilingSessionID = profilingSessionID;
	}
	
	public String getOtpExpiresMinutes() {
		return otpExpiresMinutes;
	}
	
	public void setOtpExpiresMinutes(String otpExpiresMinutes) {
		this.otpExpiresMinutes = otpExpiresMinutes;
	}
	
	public String getSmsUrl() {
		return smsUrl;
	}
	
	public void setSmsUrl(String smsUrl) {
		this.smsUrl = smsUrl;
	}
	
	public String getTargetUrl() {
		return targetUrl;
	}
	
	public void setTargetUrl(String targetUrl) {
		this.targetUrl = targetUrl;
	}
	
	public String getStubCaseKey() {
		return stubCaseKey;
	}
	
	public void setStubCaseKey(String stubCaseKey) {
		this.stubCaseKey = stubCaseKey;
	}
	
	public String getReturnDebugData() {
		return returnDebugData;
	}
	
	public void setReturnDebugData(String returnDebugData) {
		this.returnDebugData = returnDebugData;
	}
	
	public String getDeviceTypeMobile() {
		return deviceTypeMobile;
	}
	
	public void setDeviceTypeMobile(String deviceTypeMobile) {
		this.deviceTypeMobile = deviceTypeMobile;
	}
	
	public String getAppCode() {
		return appCode;
	}
	
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}
	
	public String getHighRiskAddressId() {
		return highRiskAddressId;
	}
	
	public void setHighRiskAddressId(String highRiskAddressId) {
		this.highRiskAddressId = highRiskAddressId;
	}
	
	public String getCheckHighRiskAddress() {
		return checkHighRiskAddress;
	}
	
	public void setCheckHighRiskAddress(String checkHighRiskAddress) {
		this.checkHighRiskAddress = checkHighRiskAddress;
	}
	
	public String getAssessmentCall() {
		return assessmentCall;
	}

	public void setAssessmentCall(String assessmentCall) {
		this.assessmentCall = assessmentCall;
	}

	@Override
    public String toString() {
        return "\n" + "Remote Request \n[ " 
               + "\n" + "sponsorName        = " + sponsorName
               + "\n" + "firstName        = " + firstName
               + "\n" + "lastName         = " + lastName
               + "\n" + "streetAddress1   = " + streetAddress1
               + "\n" + "streetAddress2   = " + streetAddress2
               + "\n" + "city             = " + city
               + "\n" + "state            = " + state
               + "\n" + "zipCode          = " + zipCode
               + "\n" + "birthDate        = " + birthDate
               + "\n" + "mobilePhone      = " + mobilePhone
               + "\n" + "passcode         = " + passcode
               + "\n]";
    }

}
