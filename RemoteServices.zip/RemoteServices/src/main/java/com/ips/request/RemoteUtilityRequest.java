package com.ips.request;

import java.io.Serializable;

public class RemoteUtilityRequest implements Serializable {
    private static final long serialVersionUID = 1L;
	private String sponsorCode;
	private String sponsorName;
	private String experianTokenCode;
	private String experianTokenType;
	private String experianAccessToken;
	private String experianJwtUserId;
	private String experianJwtPasscode;
	private String sponsorConfigName;
	private String sponsorConfigValue;
	private String attemptTableToConfig;
	private String checkHighRiskAddress;
	private String fieldValue;
	private String regEx;
    private Integer lexisNexisOTPAllocation;
    private Integer equifaxSMFAAllocation;
    private Integer equifaxIDFSAllocation;
    private Integer experianCCAllocation;
    private int phoneVelocityWindow;
    private int personId;
    private int sponsorId;
    private int appId;
    private int proofingStatus;
	
	public String getSponsorCode() {
		return sponsorCode;
	}
	
	public void setSponsorCode(String sponsorCode) {
		this.sponsorCode = sponsorCode;
	}
	
	public String getSponsorName() {
		return sponsorName;
	}
	
	public void setSponsorName(String sponsorName) {
		this.sponsorName = sponsorName;
	}
	
	public int getPhoneVelocityWindow() {
		return phoneVelocityWindow;
	}
	
	public void setPhoneVelocityWindow(int phoneVelocityWindow) {
		this.phoneVelocityWindow = phoneVelocityWindow;
	}
	
	public Integer getLexisNexisOTPAllocation() {
		return lexisNexisOTPAllocation;
	}
	
	public void setLexisNexisOTPAllocation(Integer lexisNexisOTPAllocation) {
		this.lexisNexisOTPAllocation = lexisNexisOTPAllocation;
	}
	
	public Integer getEquifaxSMFAAllocation() {
		return equifaxSMFAAllocation;
	}
	
	public void setEquifaxSMFAAllocation(Integer equifaxSMFAAllocation) {
		this.equifaxSMFAAllocation = equifaxSMFAAllocation;
	}

	public Integer getEquifaxIDFSAllocation() {
		return equifaxIDFSAllocation;
	}

	public void setEquifaxIDFSAllocation(Integer equifaxIDFSAllocation) {
		this.equifaxIDFSAllocation = equifaxIDFSAllocation;
	}

	public Integer getExperianCCAllocation() {
		return experianCCAllocation;
	}

	public void setExperianCCAllocation(Integer experianCCAllocation) {
		this.experianCCAllocation = experianCCAllocation;
	}

	public String getAttemptTableToConfig() {
		return attemptTableToConfig;
	}

	public void setAttemptTableToConfig(String attemptTableToConfig) {
		this.attemptTableToConfig = attemptTableToConfig;
	}

	public int getPersonId() {
		return personId;
	}

	public void setPersonId(int personId) {
		this.personId = personId;
	}

	public int getProofingStatus() {
		return proofingStatus;
	}

	public void setProofingStatus(int proofingStatus) {
		this.proofingStatus = proofingStatus;
	}

	public String getExperianTokenCode() {
		return experianTokenCode;
	}

	public void setExperianTokenCode(String experianTokenCode) {
		this.experianTokenCode = experianTokenCode;
	}

	public String getExperianTokenType() {
		return experianTokenType;
	}

	public void setExperianTokenType(String experianTokenType) {
		this.experianTokenType = experianTokenType;
	}

	public String getExperianAccessToken() {
		return experianAccessToken;
	}

	public void setExperianAccessToken(String experianAccessToken) {
		this.experianAccessToken = experianAccessToken;
	}

	public String getSponsorConfigName() {
		return sponsorConfigName;
	}

	public void setSponsorConfigName(String sponsorConfigName) {
		this.sponsorConfigName = sponsorConfigName;
	}

	public String getSponsorConfigValue() {
		return sponsorConfigValue;
	}

	public int getSponsorId() {
		return sponsorId;
	}

	public void setSponsorConfigValue(String sponsorConfigValue) {
		this.sponsorConfigValue = sponsorConfigValue;
	}

	public void setSponsorId(int sponsorId) {
		this.sponsorId = sponsorId;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public String getExperianJwtUserId() {
		return experianJwtUserId;
	}

	public String getExperianJwtPasscode() {
		return experianJwtPasscode;
	}

	public void setExperianJwtUserId(String experianJwtUserId) {
		this.experianJwtUserId = experianJwtUserId;
	}

	public void setExperianJwtPasscode(String experianJwtPasscode) {
		this.experianJwtPasscode = experianJwtPasscode;
	}

	public String getCheckHighRiskAddress() {
		return checkHighRiskAddress;
	}

	public void setCheckHighRiskAddress(String checkHighRiskAddress) {
		this.checkHighRiskAddress = checkHighRiskAddress;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String getRegEx() {
		return regEx;
	}

	public void setRegEx(String regEx) {
		this.regEx = regEx;
	}
   
}
