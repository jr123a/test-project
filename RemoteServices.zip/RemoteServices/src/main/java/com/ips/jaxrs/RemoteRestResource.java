package com.ips.jaxrs;

import java.io.Serializable;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.ips.common.common.CustomLogger;
import com.ips.request.RemoteRequest;
import com.ips.request.RemoteUtilityRequest;
import com.ips.service.RemoteProofingService;
import com.ips.service.RemoteUtilityService;

@Path("remote")
public class RemoteRestResource extends SpringBeanAutowiringSupport implements Serializable {
    private final static long serialVersionUID = 1L;

    @Autowired
    private RemoteProofingService remoteProofingService;
    @Autowired
    private RemoteUtilityService remoteUtilityService;
 
    public final static String HEADER_ORIGIN = "Origin";
    
    /**
     * Web Service used to check high risk address, device reputation and email risk. LexisNexis web service is called to retrieved the 
     * bundled (multi-product) assessment result using the unique session id passed in profiling tag as key.
     * Upon completion of device reputation/email risk check, an assessment status is returned with the response. 
     *
     * Consumer: BCG Thru CustReg
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("AssessDevicePlusEmailRisk")
    public Response assessDevicePlusEmailRisk(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteProofingService.assessDevicePlusEmailRisk(remoteReq, origin);
    }
    
    /**
     * Web Service used to check high risk address and device reputation. LexisNexis web service is called to retrieved the 
     * device reputation assessment result using the unique session id passed in profiling tag as key.
     * Upon completion of device reputation check, an assessment status is returned with the response. 
     *
     * Consumer: Operation Santa / Change of Address
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CheckDevice")
    public Response checkDevice(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());
 
    	return remoteProofingService.checkDevice(remoteReq, origin);
    }
    
    /**
     * Web Service used to verify a phone number. Upon successful verification, a
     * passcode is sent to the phone. If verification fails, an appropriate response
     * is returned stating what failed.
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     * @throws Throwable 
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("VerifyPhone")
    public Response verifyPhone(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) throws Throwable {
    	CustomLogger.enter(this.getClass());

    	return remoteProofingService.verifyPhone(remoteReq, origin);
    }
 
    /**
     * Web Service used to confirm a passcode sent to a user. Indicates whether the
     * passcode entered was correct or not
     * 
     * @param passReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ConfirmPasscode")
    public Response confirmPasscode(RemoteRequest passReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteProofingService.confirmPasscode(passReq, origin);
    }

    /**
     * Web Service used to resend a passcode to a user if the user's phone has been
     * verified previously.
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     * @throws Throwable 
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RequestPasscode")
    public Response requestPasscode(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) throws Throwable {
    	CustomLogger.enter(this.getClass());

    	return remoteProofingService.requestPasscode(remoteReq, origin);
     }

    /**
     * Web Service used to resend the SMFA link to the user's phone if it has been
     * verified previously by Equifax DIT.
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ResendLink")
    public Response resendLink(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteProofingService.resendLink(remoteReq, origin);
     }
    
    /**
     * Web Service used to validate the SMFA link sent to the user's phone.
     * 
     * @param remoteReq
     *            - the data received from the request
     * @param origin
     *            - header parameter
     * @return a JSON response indicating success or fail verification
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ValidateLink")
    public Response validateLink(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteProofingService.validateLink(remoteReq, origin);
     }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CreateRefSponsorConfigurationRecords")
    public Response createRefSponsorConfigurationForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteUtilityService.createRefSponsorConfigurationForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CreateRpOtpAttemptConfigRecords")
    public Response createRpOtpAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteUtilityService.createRpOtpAttemptConfigForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CreateRpInfPvAttemptConfigRecords")
    public Response createRpInfPvAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteUtilityService.createRpInfPvAttemptConfigForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CreateRpFeatureAttemptRecords")
    public Response createRpFeatureAttemptForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteUtilityService.createRpFeatureAttemptForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RemoveRefSponsorConfigurationRecords")
    public Response removeRefSponsorConfigurationForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteUtilityService.removeRefSponsorConfigurationForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RemoveRpFeatureAttemptRecords")
    public Response removeRpFeatureAttemptForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteUtilityService.removeRpFeatureAttemptForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RemoveRpOtpAttemptConfigRecords")
    public Response removeRpOtpAttemptConfigForRemoteClient(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteUtilityService.removeRpOtpAttemptConfigForRemoteClient(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("GetModificationFingerprint")
    public Response getModificationFingerprint(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteUtilityService.getModificationFingerprint(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ConfigVerificationMethod")
    public Response configVerificationMethod(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteUtilityService.configVerificationMethod(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RetrieveSupplierConfig")
    public Response retrieveSupplierConfig(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteUtilityService.retrieveSupplierConfig(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ConfigPhoneVelocityWindow")
    public Response configPhoneVelocityWindow(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());

    	return remoteUtilityService.configPhoneVelocityWindow(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("UpdatePersonProofingStatus")
    public Response updatePersonProofingStatus(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());
    	return remoteUtilityService.updatePersonProofingStatus(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("SaveExperianAltApiInfo")
    public Response saveExperianAltApiInfo(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());
    	return remoteUtilityService.saveRpSupplierToken(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RemoveExperianAltApiInfo")
    public Response removeExperianAltApiInfo(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());
    	return remoteUtilityService.removeRpSupplierToken(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("SaveRefSponsorConfiguration")
    public Response saveRefSponsorConfiguration(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());
    	return remoteUtilityService.saveRefSponsorConfiguration(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RetrieveRefSponsorConfiguration")
    public Response retrieveRefSponsorConfiguration(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());
    	return remoteUtilityService.retrieveRefSponsorConfiguration(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("RemoveRefSponsorConfiguration")
    public Response removeRefSponsorConfiguration(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());
    	return remoteUtilityService.removeRefSponsorConfiguration(remoteReq, origin);
    }
      
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("ObtainExperianWebToken")
    public Response obtainExperianWebToken(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());
    	return remoteUtilityService.obtainExperianWebToken(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("GetHighRiskAddresses")
    public Response getHighRiskAddresses(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
    	CustomLogger.enter(this.getClass());
    	return remoteUtilityService.getHighRiskAddresses(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("UpdateHighRiskAddress")
    public Response updateHighRiskAddress(RemoteRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
     	CustomLogger.enter(this.getClass());
    	return remoteUtilityService.updateHighRiskAddress(remoteReq, origin);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("CheckRegExForMatch")
    public Response checkRegExForMatch(RemoteUtilityRequest remoteReq, @HeaderParam(HEADER_ORIGIN) String origin) {
     	CustomLogger.enter(this.getClass());
    	return remoteUtilityService.checkRegExForMatch(remoteReq, origin);
    }
    
  }
