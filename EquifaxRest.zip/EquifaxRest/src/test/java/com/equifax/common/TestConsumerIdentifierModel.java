package com.equifax.common;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
class TestConsumerIdentifierModel {
	
	@Test
	void testGetSubjectIdentifier() {
		ConsumerIdentifierModel cim = new ConsumerIdentifierModel();
		cim.setSubjectIdentifier("subjectIdentifier");
		assertEquals("subjectIdentifier", cim.getSubjectIdentifier());
	}
	
	@Test
	void testGetSubjectType() {
		ConsumerIdentifierModel cim = new ConsumerIdentifierModel();
		cim.setSubjectType("subjectType");
		assertEquals("subjectType", cim.getSubjectType());
	}
	
	@Test
	void testGetTargetUrl() {
		ConsumerIdentifierModel cim = new ConsumerIdentifierModel();
		cim.setTargetUrl("targetUrl");
		assertEquals("targetUrl", cim.getTargetUrl());
	}
	
	@Test
	void testGetSmsUrl() {
		ConsumerIdentifierModel cim = new ConsumerIdentifierModel();
		cim.setSmsUrl("smsUrl");
		assertEquals("smsUrl", cim.getSmsUrl());
	}
	
	@Test
	void testGetDeviceIp() {
		ConsumerIdentifierModel cim = new ConsumerIdentifierModel();
		cim.setDeviceIp("deviceIp");
		assertEquals("deviceIp", cim.getDeviceIp());
	}
}
