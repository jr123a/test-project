package com.equifax.common;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
class TestAdditionalErrorDetailModel {
	
	@Test
	void testGetErrorCode() {
		AdditionalErrorDetailModel aedm = new AdditionalErrorDetailModel();
		aedm.setErrorCode("errorCode");
		assertEquals("errorCode", aedm.getErrorCode());
	}
	
	@Test
	void testGetDeveloperMessage() {
		AdditionalErrorDetailModel aedm = new AdditionalErrorDetailModel();
		aedm.setDeveloperMessage("developerMessage");
		assertEquals("developerMessage", aedm.getDeveloperMessage());
	}
	
	@Test
	void testGetErrorType() {
		AdditionalErrorDetailModel aedm = new AdditionalErrorDetailModel();
		aedm.setErrorType("errorType");
		assertEquals("errorType", aedm.getErrorType());
	}
}
