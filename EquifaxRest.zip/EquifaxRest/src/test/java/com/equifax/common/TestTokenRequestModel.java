package com.equifax.common;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
public class TestTokenRequestModel {
	
	@Test
	void testTokenRequestModel() {
		TokenRequestModel trm = new TokenRequestModel();
		
		trm.setClientId("clientId");
		trm.setClientSecret("clientSecret");
		trm.setGrantType("grantType");
		trm.setScope("scope");
		
		Assertions.assertEquals("clientId", trm.getClientId());
		Assertions.assertEquals("clientSecret", trm.getClientSecret());
		Assertions.assertEquals("grantType", trm.getGrantType());
		Assertions.assertEquals("scope", trm.getScope());
	}
}
