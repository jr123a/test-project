package com.equifax.smfa.response;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.Assertions;

import com.equifax.common.AdditionalErrorDetailModel;

@TestInstance(Lifecycle.PER_CLASS)
public class TestStatusSMFAResponseModel {

	@Test
	void testStatusSMFAResponseModel() {
		StatusSMFAResponseModel ssrm = new StatusSMFAResponseModel();
		
		ssrm.setTransactionId("transationId");
		
		ResponseStatusModel rsm = new ResponseStatusModel();
		rsm.setPath("path");
		rsm.setDeviceIpMatch("deviceIpMatch");
		ssrm.setResponse(rsm);
		
		ssrm.setEfxErrorCode("efxErrorCode");
		ssrm.setDescription("description");
		
		AdditionalErrorDetailModel aedm = new AdditionalErrorDetailModel();
		aedm.setErrorCode("errorCode");
		aedm.setDeveloperMessage("developerMessage");
		aedm.setErrorType("errorType");
		ssrm.setAdditionalErrorDetails(aedm);
		
		Assertions.assertEquals("transationId", ssrm.getTransactionId());
		Assertions.assertEquals(rsm, ssrm.getResponse());
		Assertions.assertEquals("efxErrorCode", ssrm.getEfxErrorCode());
		Assertions.assertEquals("description", ssrm.getDescription());
		Assertions.assertEquals(aedm, ssrm.getAdditionalErrorDetails());
	}
}
