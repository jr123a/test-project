package com.equifax.smfa.request;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.equifax.common.ConsumerIdentifierModel;

@TestInstance(Lifecycle.PER_CLASS)
class TestInitiateSMFARequestModel {
	
	@Test
	void testGetMerchantId() {
		InitiateSMFARequestModel isrm = new InitiateSMFARequestModel();
		isrm.setMerchantId("merchantId");
		assertEquals("merchantId", isrm.getMerchantId());
	}
	
	@Test
	void testGetUsecase() {
		InitiateSMFARequestModel isrm = new InitiateSMFARequestModel();
		isrm.setUsecase("usecase");
		assertEquals("usecase", isrm.getUsecase());
	}
	
	@Test
	void testGetConsumerIdentifierModel() {
		InitiateSMFARequestModel isrm = new InitiateSMFARequestModel();
		ConsumerIdentifierModel cim = new ConsumerIdentifierModel();
		isrm.setConsumerIdentifier(cim);
		assertEquals(cim, isrm.getConsumerIdentifier());
	}
}
