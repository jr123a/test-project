package com.equifax.smfa.response;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.equifax.common.AdditionalErrorDetailModel;

import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
public class TestInitiateSMFAResponseModel {

	@Test
	void testInitiateSMFAResponseModel() {
		
		InitiateSMFAResponseModel isrm = new InitiateSMFAResponseModel();
		
		isrm.setTransactionId("transactionId");
		isrm.setSessionId("sessionId");
		isrm.setRedirectUrl("redirectUrl");
		isrm.setInstaTouch("instaTouch");
		isrm.setDescription("description");
		isrm.setMessage("message");
		isrm.setEfxErrorCode("efxErrorCode");
		isrm.setLinkSuccessfullySent(true);
		
		OtpLifecycleModel olm = new OtpLifecycleModel();
		olm.setStatus("status");
		isrm.setOtpLifecycle(olm);
		
		AdditionalErrorDetailModel aedm = new AdditionalErrorDetailModel();
		aedm.setErrorCode("errorCode");
		aedm.setDeveloperMessage("developerMessage");
		aedm.setErrorType("errorType");
		isrm.setAdditionalErrorDetails(aedm);
	
		Assertions.assertEquals("transactionId", isrm.getTransactionId());
		Assertions.assertEquals("sessionId", isrm.getSessionId());
		Assertions.assertEquals("redirectUrl", isrm.getRedirectUrl());
		Assertions.assertEquals("instaTouch", isrm.getInstaTouch());
		Assertions.assertEquals("description", isrm.getDescription());
		Assertions.assertEquals("message", isrm.getMessage());
		Assertions.assertEquals("efxErrorCode", isrm.getEfxErrorCode());
		Assertions.assertEquals(true, isrm.isLinkSuccessfullySent());
		Assertions.assertEquals(olm, isrm.getOtpLifecycle());
		Assertions.assertEquals(aedm, isrm.getAdditionalErrorDetails());
	}
}
