package com.equifax.smfa.response;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
class TestResponseStatusModel {
	
	@Test
	void testGetPath() {
		ResponseStatusModel rsm = new ResponseStatusModel();
		rsm.setPath("path");
		assertEquals("path", rsm.getPath());
	}
	
	@Test
	void testGetDeviceIpMatch() {
		ResponseStatusModel rsm = new ResponseStatusModel();
		rsm.setDeviceIpMatch("ipMatch");
		assertEquals("ipMatch", rsm.getDeviceIpMatch());
	}
}
