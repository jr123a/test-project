package com.equifax.smfa.request;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.equifax.common.ConsumerIdentifierModel;

@TestInstance(Lifecycle.PER_CLASS)
class TestStatusSMFARequestModel {
	
	@Test
	void testGetMerchantId() {
		StatusSMFARequestModel ssrm = new StatusSMFARequestModel();
		ssrm.setMerchantId("merchantId");
		assertEquals("merchantId", ssrm.getMerchantId());
	}
	
	@Test
	void testGetUsecase() {
		StatusSMFARequestModel ssrm = new StatusSMFARequestModel();
		ssrm.setUsecase("usecase");
		assertEquals("usecase", ssrm.getUsecase());
	}
	
	@Test
	void testGetConsumerIdentifierModel() {
		StatusSMFARequestModel ssrm = new StatusSMFARequestModel();
		ConsumerIdentifierModel cim = new ConsumerIdentifierModel();
		ssrm.setConsumerIdentifier(cim);
		assertEquals(cim, ssrm.getConsumerIdentifier());
	}
}
