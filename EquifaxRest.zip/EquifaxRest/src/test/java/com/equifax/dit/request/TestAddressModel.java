package com.equifax.dit.request;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
class TestAddressModel {
	
	@Test
	void testAddressModel() {
		AddressModel addressModel = new AddressModel();
		
		addressModel.setAddressType("addressType");
		addressModel.setAddressLine1("addressLine1");
		addressModel.setAddressLine2("addressLine2");
		addressModel.setCity("city");
		addressModel.setCounty("county");
		addressModel.setRegion("region");
		addressModel.setPostalCode("postalCode");
		addressModel.setPostalIdentifier("postalIdentifier");
		addressModel.setCountryCode("countryCode");
		addressModel.setPrimary(true);
		
		Assertions.assertEquals("addressType", addressModel.getAddressType());
		Assertions.assertEquals("addressLine1", addressModel.getAddressLine1());
		Assertions.assertEquals("addressLine2", addressModel.getAddressLine2());
		Assertions.assertEquals("city", addressModel.getCity());
		Assertions.assertEquals("county", addressModel.getCounty());
		Assertions.assertEquals("region", addressModel.getRegion());
		Assertions.assertEquals("postalCode", addressModel.getPostalCode());
		Assertions.assertEquals("postalIdentifier", addressModel.getPostalIdentifier());
		Assertions.assertEquals("countryCode", addressModel.getCountryCode());
		Assertions.assertEquals(true, addressModel.isPrimary());
	}
}
