package com.equifax.dit.request;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class TestIdentityModel {

	@Test
	void testIdentityModel() {
		IdentityModel im = new IdentityModel();
		
		NameModel nm = new NameModel();
		nm.setFirstName("firstName");
		nm.setMiddleName("middleName");
		nm.setLastName("lastName");
		nm.setSecondLastName("secondLastName");
		nm.setNamePrefix("namePrefix");
		nm.setNameSuffix("nameSuffix");
		im.setName(nm);
		
		List<AddressModel> addresses = new ArrayList<AddressModel>();
		AddressModel am = new AddressModel();
		am.setAddressType("addressType");
		am.setAddressLine1("addressLine1");
		am.setAddressLine2("addressLine2");
		am.setCity("city");
		am.setCounty("county");
		am.setRegion("region");
		am.setPostalCode("postalCode");
		am.setPostalIdentifier("postalIdentifier");
		am.setCountryCode("countryCode");
		am.setPrimary(true);
		addresses.add(am);
		im.setAddress(addresses);
		
		DateOfBirthModel dobm = new DateOfBirthModel();
		dobm.setDay("day");
		dobm.setMonth("month");
		dobm.setYear("year");
		im.setDateOfBirth(dobm);
		
		GovernmentIdModel gim = new GovernmentIdModel();
		gim.setDocumentType("documentType");
		gim.setValue(1);
		im.setGovernmentId(gim);
		
		List<PhoneModel> phones = new ArrayList<PhoneModel>();
		PhoneModel pm = new PhoneModel();
		int countryCode = 1;
		pm.setCountryCode(countryCode);
		pm.setArea("area");
		int number1 = 570555;
		long number2 = number1 * 1000;
		pm.setNumber(number2);
		pm.setType("type");
		pm.setPrimary(true);
		phones.add(pm);
		im.setPhone(phones);
		
		List<EmailModel> emails = new ArrayList<EmailModel>();
		EmailModel em = new EmailModel();
		em.setEmail("email");
		em.setEmailType("emailType");
		emails.add(em);
		im.setEmail(emails);
		
		Assertions.assertEquals(nm, im.getName());
		Assertions.assertEquals(addresses, im.getAddress());
		Assertions.assertEquals(dobm, im.getDateOfBirth());
		Assertions.assertEquals(gim, im.getGovernmentId());
		Assertions.assertEquals(phones, im.getPhone());
		Assertions.assertEquals(emails, im.getEmail());
	}
}
