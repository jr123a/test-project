package com.equifax.dit.response;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
class TestDetailModel {
	
	@Test
	void testGetKey() {
		DetailModel detailModel = new DetailModel();
		detailModel.setKey("Th1sIs@k3Y");
		Assertions.assertEquals("Th1sIs@k3Y", detailModel.getKey());
	}
	
	@Test
	void testGetValue() {
		DetailModel detailModel = new DetailModel();
		detailModel.setValue("value");
		Assertions.assertEquals("value", detailModel.getValue());
	}
}
