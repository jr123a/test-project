package com.equifax.dit.request;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class TestAdditionalFieldModel {

	@Test
	void testAdditionalFieldModel() {
		AdditionalFieldModel afm = new AdditionalFieldModel();
		afm.setKey("key");
		afm.setValue("value");
		Assertions.assertEquals("key", afm.getKey());
		Assertions.assertEquals("value", afm.getValue());
	}
}
