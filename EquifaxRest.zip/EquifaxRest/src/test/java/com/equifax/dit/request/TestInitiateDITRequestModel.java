package com.equifax.dit.request;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class TestInitiateDITRequestModel {

	@Test
	void testInitiateDITRequestModel() {
		InitiateDITRequestModel idrm = new InitiateDITRequestModel();
		
		idrm.setTenantId("tenantId");
		idrm.setApplicationId("applicationId");
		idrm.setReferenceId("referenceId");
		idrm.setConsumerId("consumerId");
		idrm.setCorrelationId("correlationId");
		idrm.setProductId("productId");
		idrm.setConfigId("configId");
		idrm.setEntityId("entityId");
		
		DataModel dm = new DataModel();
		dm.setIpAddress("ipAddress");
		
		IdentityModel im = new IdentityModel();
		dm.setIdentity(im);
		
		List<AdditionalFieldModel> additionalFields = new ArrayList<AdditionalFieldModel>();
		AdditionalFieldModel afm = new AdditionalFieldModel();
		additionalFields.add(afm);
		dm.setAdditionalFields(additionalFields);
		
		idrm.setData(dm);
		
		Assertions.assertEquals("tenantId", idrm.getTenantId());
		Assertions.assertEquals("applicationId", idrm.getApplicationId());
		Assertions.assertEquals("referenceId", idrm.getReferenceId());
		Assertions.assertEquals("consumerId", idrm.getConsumerId());
		Assertions.assertEquals("correlationId", idrm.getCorrelationId());
		Assertions.assertEquals("productId", idrm.getProductId());
		Assertions.assertEquals("configId", idrm.getConfigId());
		Assertions.assertEquals("entityId", idrm.getEntityId());
		Assertions.assertEquals(dm, idrm.getData());
	}
}
