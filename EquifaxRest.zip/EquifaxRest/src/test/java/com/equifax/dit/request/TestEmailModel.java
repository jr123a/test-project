package com.equifax.dit.request;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class TestEmailModel {
	
	@Test
	void testEmailModel() {
		EmailModel em = new EmailModel();
		
		em.setEmail("email");
		em.setEmailType("emailType");
		
		Assertions.assertEquals("email", em.getEmail());
		Assertions.assertEquals("emailType", em.getEmailType());
	}
}
