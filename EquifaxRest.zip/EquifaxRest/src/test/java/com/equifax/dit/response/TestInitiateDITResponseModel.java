package com.equifax.dit.response;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.equifax.common.AdditionalErrorDetailModel;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
public class TestInitiateDITResponseModel {
	
	@Test
	void testInitiateDITResponseModel() {
		
		InitiateDITResponseModel idrm = new InitiateDITResponseModel();
		
		idrm.setTransactionId("transactionId");
		idrm.setCorrelationId("correlationId");
		idrm.setReferenceTransactionId("referenceTransactionId");
		idrm.setOriginalTransactionId("originalTransactionId");
		idrm.setDecision("decision");
		idrm.setOverallDecision("overallDecision");
		idrm.setIdentityTrust("identityTrust");
		idrm.setAddressTrust("addressTrust");
		idrm.setPhoneTrust("phoneTrust");
		idrm.setPhoneVerification("phoneVerification");
		idrm.setTimestamp("timestamp");
		idrm.setMessage("message");
		idrm.setError("error");
		idrm.setEfxErrorCode("efxErrorCode");
		idrm.setDescription("description");
		idrm.setStatus(1);
		
		FaultModel fm = new FaultModel();
		FaultDetailModel fdm = new FaultDetailModel();
		fdm.setErrorcode("errorcode");
		fm.setDetail(fdm);
		idrm.setFault(fm);
		
		AdditionalErrorDetailModel aedm = new AdditionalErrorDetailModel();
		aedm.setErrorCode("errorCode");
		aedm.setDeveloperMessage("developerMessage");
		aedm.setErrorType("errorType");
		idrm.setAdditionalErrorDetails(aedm);
		
		List<DetailModel> details = new ArrayList<DetailModel>();
		DetailModel dm = new DetailModel();
		dm.setKey("key");
		dm.setValue("value");
		details.add(dm);
		idrm.setDetails(details);
		
		Assertions.assertEquals("transactionId", idrm.getTransactionId());
		Assertions.assertEquals("correlationId", idrm.getCorrelationId());
		Assertions.assertEquals("referenceTransactionId", idrm.getReferenceTransactionId());
		Assertions.assertEquals("originalTransactionId", idrm.getOriginalTransactionId());
		Assertions.assertEquals("decision", idrm.getDecision());
		Assertions.assertEquals("overallDecision", idrm.getOverallDecision());
		Assertions.assertEquals("identityTrust", idrm.getIdentityTrust());
		Assertions.assertEquals("addressTrust", idrm.getAddressTrust());
		Assertions.assertEquals("phoneTrust", idrm.getPhoneTrust());
		Assertions.assertEquals("phoneVerification", idrm.getPhoneVerification());
		Assertions.assertEquals("timestamp", idrm.getTimestamp());
		Assertions.assertEquals("message", idrm.getMessage());
		Assertions.assertEquals("error", idrm.getError());
		Assertions.assertEquals("efxErrorCode", idrm.getEfxErrorCode());
		Assertions.assertEquals("description", idrm.getDescription());
		Assertions.assertEquals(1, idrm.getStatus());
		Assertions.assertEquals(details, idrm.getDetails());
		Assertions.assertEquals(fm, idrm.getFault());
		Assertions.assertEquals(aedm, idrm.getAdditionalErrorDetails());
	}
}
