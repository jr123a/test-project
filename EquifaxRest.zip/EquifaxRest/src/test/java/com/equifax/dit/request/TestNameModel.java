package com.equifax.dit.request;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class TestNameModel {

	@Test
	void testNameModel() {
		NameModel nm = new NameModel();
		
		nm.setFirstName("firstName");
		nm.setMiddleName("middleName");
		nm.setLastName("lastName");
		nm.setSecondLastName("secondLastName");
		nm.setNamePrefix("namePrefix");
		nm.setNameSuffix("nameSuffix");
		
		Assertions.assertEquals("firstName", nm.getFirstName());
		Assertions.assertEquals("middleName", nm.getMiddleName());
		Assertions.assertEquals("lastName", nm.getLastName());
		Assertions.assertEquals("secondLastName", nm.getSecondLastName());
		Assertions.assertEquals("namePrefix", nm.getNamePrefix());
		Assertions.assertEquals("nameSuffix", nm.getNameSuffix());
	}
}
