package com.equifax.dit.response;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
class TestFaultDetailModel {
	
	@Test
	void testGetErrorcode() {
		FaultDetailModel faultDetailModel = new FaultDetailModel();
		faultDetailModel.setErrorcode("errorcode");
		Assertions.assertEquals("errorcode", faultDetailModel.getErrorcode());
	}
}
