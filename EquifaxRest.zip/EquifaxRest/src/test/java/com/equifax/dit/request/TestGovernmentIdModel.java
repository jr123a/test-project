package com.equifax.dit.request;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class TestGovernmentIdModel {

	@Test
	void testGovernmentIdModel() {
		GovernmentIdModel gim = new GovernmentIdModel();
		
		gim.setDocumentType("documentType");
		gim.setValue(1);
		
		Assertions.assertEquals("documentType", gim.getDocumentType());
		Assertions.assertEquals(1, gim.getValue());
	}
}
