package com.equifax.dit.request;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class TestDataModel {

	@Test
	void testDataModel() {
		DataModel dm = new DataModel();
		dm.setIpAddress("ipAddress");
		
		IdentityModel im = new IdentityModel();
		dm.setIdentity(im);
		
		List<AdditionalFieldModel> additionalFields = new ArrayList<AdditionalFieldModel>();
		AdditionalFieldModel afm = new AdditionalFieldModel();
		additionalFields.add(afm);
		dm.setAdditionalFields(additionalFields);
		
		Assertions.assertEquals("ipAddress", dm.getIpAddress());
		Assertions.assertEquals(im, dm.getIdentity());
		Assertions.assertEquals(additionalFields, dm.getAdditionalFields());
	}
}
