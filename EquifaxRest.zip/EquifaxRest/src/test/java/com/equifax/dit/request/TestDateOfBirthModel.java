package com.equifax.dit.request;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class TestDateOfBirthModel {
	
	@Test
	void testDateOfBirthModel() {
		DateOfBirthModel dobm = new DateOfBirthModel();
		
		dobm.setDay("day");
		dobm.setMonth("month");
		dobm.setYear("year");
		
		Assertions.assertEquals("day", dobm.getDay());
		Assertions.assertEquals("month", dobm.getMonth());
		Assertions.assertEquals("year", dobm.getYear());
	}
}
