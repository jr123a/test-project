package com.equifax.dit.response;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
public class TestFaultModel {

	@Test
	void testFaultModel() {
		FaultModel fm = new FaultModel();
		
		fm.setFaultstring("faultstring");
		
		FaultDetailModel fdm = new FaultDetailModel();
		fdm.setErrorcode("errorcode");
		fm.setDetail(fdm);
		
		Assertions.assertEquals("faultstring", fm.getFaultstring());
		Assertions.assertEquals(fdm, fm.getDetail());
	}
}
