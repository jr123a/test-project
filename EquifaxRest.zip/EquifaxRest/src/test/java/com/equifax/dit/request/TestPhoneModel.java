package com.equifax.dit.request;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class TestPhoneModel {

	@Test
	void testPhoneModel() {
		PhoneModel pm = new PhoneModel();
		
		int countryCode = 1;
		pm.setCountryCode(countryCode);
		
		pm.setArea("area");
		
		int number1 = 570555;
		long number2 = number1 * 1000;
		pm.setNumber(number2);
		
		pm.setType("type");
		pm.setPrimary(true);
		
		Assertions.assertEquals(countryCode, pm.getCountryCode());
		Assertions.assertEquals("area", pm.getArea());
		Assertions.assertEquals(number2, pm.getNumber());
		Assertions.assertEquals("type", pm.getType());
		Assertions.assertEquals(true, pm.isPrimary());
	}
}
