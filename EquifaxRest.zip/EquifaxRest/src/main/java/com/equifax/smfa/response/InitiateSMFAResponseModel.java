package com.equifax.smfa.response;

import com.equifax.common.AdditionalErrorDetailModel;

public class InitiateSMFAResponseModel {

	private String transactionId;
	private String sessionId;
	private String redirectUrl;
	private String instaTouch;
	private String description;
	private String message;
	private String efxErrorCode;
	private boolean linkSuccessfullySent;
	private OtpLifecycleModel otpLifecycle;
	private AdditionalErrorDetailModel additionalErrorDetails;
 
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getRedirectUrl() {
		return redirectUrl;
	}

	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

	public String getInstaTouch() {
		return instaTouch;
	}

	public void setInstaTouch(String instaTouch) {
		this.instaTouch = instaTouch;
	}

	public OtpLifecycleModel getOtpLifecycle() {
		return otpLifecycle;
	}

	public void setOtpLifecycle(OtpLifecycleModel otpLifecycle) {
		this.otpLifecycle = otpLifecycle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEfxErrorCode() {
		return efxErrorCode;
	}

	public void setEfxErrorCode(String efxErrorCode) {
		this.efxErrorCode = efxErrorCode;
	}

	public AdditionalErrorDetailModel getAdditionalErrorDetails() {
		return additionalErrorDetails;
	}

	public void setAdditionalErrorDetails(AdditionalErrorDetailModel additionalErrorDetails) {
		this.additionalErrorDetails = additionalErrorDetails;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isLinkSuccessfullySent() {
		return linkSuccessfullySent;
	}

	public void setLinkSuccessfullySent(boolean linkSuccessfullySent) {
		this.linkSuccessfullySent = linkSuccessfullySent;
	}

}
