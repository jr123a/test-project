package com.equifax.smfa.response;

import com.equifax.common.AdditionalErrorDetailModel;

public class StatusSMFAResponseModel {

	private String transactionId;
	private ResponseStatusModel response;
	private String efxErrorCode;
	private String description;
	private AdditionalErrorDetailModel additionalErrorDetails;
 
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public ResponseStatusModel getResponse() {
		return response;
	}

	public void setResponse(ResponseStatusModel response) {
		this.response = response;
	}

	public String getEfxErrorCode() {
		return efxErrorCode;
	}

	public void setEfxErrorCode(String efxErrorCode) {
		this.efxErrorCode = efxErrorCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public AdditionalErrorDetailModel getAdditionalErrorDetails() {
		return additionalErrorDetails;
	}

	public void setAdditionalErrorDetails(AdditionalErrorDetailModel additionalErrorDetails) {
		this.additionalErrorDetails = additionalErrorDetails;
	}

}
