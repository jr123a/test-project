package com.equifax.smfa.response;

public class OtpLifecycleModel {

	private String status;
	public static final String EQUIFAX_SMFA_SEND_LINK_SUCCESS = "SUCCESS";
	public static final String EQUIFAX_SMFA_SEND_LINK_FAILED = "FAILED";

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
