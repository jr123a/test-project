package com.equifax.smfa.request;

import com.equifax.common.ConsumerIdentifierModel;

public class InitiateSMFARequestModel {

	private String merchantId;
	private String usecase;
	private ConsumerIdentifierModel consumerIdentifier;
	
	public String getMerchantId() {
		return merchantId;
	}
	
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getUsecase() {
		return usecase;
	}

	public void setUsecase(String usecase) {
		this.usecase = usecase;
	}

	public ConsumerIdentifierModel getConsumerIdentifier() {
		return consumerIdentifier;
	}

	public void setConsumerIdentifier(ConsumerIdentifierModel consumerIdentifier) {
		this.consumerIdentifier = consumerIdentifier;
	}
	
}
