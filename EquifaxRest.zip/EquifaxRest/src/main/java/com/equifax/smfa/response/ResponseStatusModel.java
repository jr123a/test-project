package com.equifax.smfa.response;

public class ResponseStatusModel {

	public static final String RESPONSE_PATH_GREEN = "Green";
	public static final String RESPONSE_PATH_YELLOW = "Yellow";
	public static final String RESPONSE_PATH_ORANGE = "Orange";
	public static final String RESPONSE_PATH_RED = "Red";
	
	private String path;
	private String deviceIpMatch;

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getDeviceIpMatch() {
		return deviceIpMatch;
	}

	public void setDeviceIpMatch(String deviceIpMatch) {
		this.deviceIpMatch = deviceIpMatch;
	}

}
