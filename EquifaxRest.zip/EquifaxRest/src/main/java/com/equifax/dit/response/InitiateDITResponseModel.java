package com.equifax.dit.response;

import java.util.List;

import com.equifax.common.AdditionalErrorDetailModel;

public class InitiateDITResponseModel {

	private String transactionId;
	private String correlationId;
	private String referenceTransactionId;
	private String originalTransactionId;
	private String decision;
	private String overallDecision;
	private String identityTrust;
	private String addressTrust;
	private String phoneTrust;
	private String phoneVerification;
	private String timestamp;
	private String message;
	private String error;
	private String efxErrorCode;
	private String description;
	private int status;
	private FaultModel fault;
	private AdditionalErrorDetailModel additionalErrorDetails;
	private List<DetailModel> details;

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getReferenceTransactionId() {
		return referenceTransactionId;
	}
	
	public void setReferenceTransactionId(String referenceTransactionId) {
		this.referenceTransactionId = referenceTransactionId;
	}

	public String getOriginalTransactionId() {
		return originalTransactionId;
	}

	public void setOriginalTransactionId(String originalTransactionId) {
		this.originalTransactionId = originalTransactionId;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public List<DetailModel> getDetails() {
		return details;
	}

	public void setDetails(List<DetailModel> details) {
		this.details = details;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public FaultModel getFault() {
		return fault;
	}

	public void setFault(FaultModel fault) {
		this.fault = fault;
	}

	public String getOverallDecision() {
		return overallDecision;
	}

	public void setOverallDecision(String overallDecision) {
		this.overallDecision = overallDecision;
	}

	public String getIdentityTrust() {
		return identityTrust;
	}

	public void setIdentityTrust(String identityTrust) {
		this.identityTrust = identityTrust;
	}

	public String getAddressTrust() {
		return addressTrust;
	}

	public void setAddressTrust(String addressTrust) {
		this.addressTrust = addressTrust;
	}

	public String getPhoneTrust() {
		return phoneTrust;
	}

	public void setPhoneTrust(String phoneTrust) {
		this.phoneTrust = phoneTrust;
	}

	public String getPhoneVerification() {
		return phoneVerification;
	}

	public void setPhoneVerification(String phoneVerification) {
		this.phoneVerification = phoneVerification;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public AdditionalErrorDetailModel getAdditionalErrorDetails() {
		return additionalErrorDetails;
	}

	public void setAdditionalErrorDetails(AdditionalErrorDetailModel additionalErrorDetails) {
		this.additionalErrorDetails = additionalErrorDetails;
	}

	public String getEfxErrorCode() {
		return efxErrorCode;
	}

	public void setEfxErrorCode(String efxErrorCode) {
		this.efxErrorCode = efxErrorCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
