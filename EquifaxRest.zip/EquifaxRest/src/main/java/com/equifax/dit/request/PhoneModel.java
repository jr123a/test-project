package com.equifax.dit.request;

public class PhoneModel {

	private int countryCode;
	private String area;
	private long number;
	private String type;
	private boolean isPrimary;
	
	public int getCountryCode() {
		return countryCode;
	}
	
	public void setCountryCode(int countryCode) {
		this.countryCode = countryCode;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public long getNumber() {
		return number;
	}

	public void setNumber(long number) {
		this.number = number;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public boolean isPrimary() {
		return isPrimary;
	}

	public void setPrimary(boolean isPrimary) {
		this.isPrimary = isPrimary;
	}
	
	

}
