package com.equifax.dit.response;

public class DetailModel {

	private String key;
	private String value;
	
	public static final String IDENTITY_TRUST_KEY = "identityTrust";
	public static final String ADDRESS_TRUST_KEY = "addressTrust";
	public static final String PHONE_TRUST_KEY = "phoneTrust";
	public static final String PHONE_VERIFICATION_KEY = "phoneVerification";
	public static final String DETAIL_VALUE_NO = "N";
    public static final String DETAIL_VALUE_YES = "Y";


	public String getKey() {
		return key;
	}
	
	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
