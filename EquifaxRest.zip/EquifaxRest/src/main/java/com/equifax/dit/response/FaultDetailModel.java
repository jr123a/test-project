package com.equifax.dit.response;

public class FaultDetailModel {

	private String errorcode;

	public String getErrorcode() {
		return errorcode;
	}

	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}
	
}
