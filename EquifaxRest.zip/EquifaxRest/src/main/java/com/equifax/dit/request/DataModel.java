package com.equifax.dit.request;

import java.util.List;

public class DataModel {

	private String ipAddress;
	private IdentityModel identity;
	private List<AdditionalFieldModel> additionalFields;

	public String getIpAddress() {
		return ipAddress;
	}
	
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public IdentityModel getIdentity() {
		return identity;
	}

	public void setIdentity(IdentityModel identity) {
		this.identity = identity;
	}

	public List<AdditionalFieldModel> getAdditionalFields() {
		return additionalFields;
	}

	public void setAdditionalFields(List<AdditionalFieldModel> additionalFields) {
		this.additionalFields = additionalFields;
	}

}
