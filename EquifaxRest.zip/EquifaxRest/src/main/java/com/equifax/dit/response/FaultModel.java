package com.equifax.dit.response;

public class FaultModel {

	private String faultstring;
	private FaultDetailModel detail;
	
	public String getFaultstring() {
		return faultstring;
	}
	
	public void setFaultstring(String faultstring) {
		this.faultstring = faultstring;
	}

	public FaultDetailModel getDetail() {
		return detail;
	}

	public void setDetail(FaultDetailModel detail) {
		this.detail = detail;
	}

}
