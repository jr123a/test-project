package com.equifax.dit.request;

import java.util.List;

public class IdentityModel {

	private NameModel name;
	private List<AddressModel> address;
	private DateOfBirthModel dateOfBirth;
	private GovernmentIdModel governmentId;
	private List<PhoneModel> phone;
	private List<EmailModel> email;
	
	public NameModel getName() {
		return name;
	}
	
	public void setName(NameModel name) {
		this.name = name;
	}

	public List<AddressModel> getAddress() {
		return address;
	}

	public void setAddress(List<AddressModel> address) {
		this.address = address;
	}

	public DateOfBirthModel getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(DateOfBirthModel dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public GovernmentIdModel getGovernmentId() {
		return governmentId;
	}

	public void setGovernmentId(GovernmentIdModel governmentId) {
		this.governmentId = governmentId;
	}

	public List<PhoneModel> getPhone() {
		return phone;
	}

	public void setPhone(List<PhoneModel> phone) {
		this.phone = phone;
	}

	public List<EmailModel> getEmail() {
		return email;
	}

	public void setEmail(List<EmailModel> email) {
		this.email = email;
	}
}
