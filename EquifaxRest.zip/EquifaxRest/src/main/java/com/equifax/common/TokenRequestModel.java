package com.equifax.common;

public class TokenRequestModel {

	private String client_id;
	private String client_secret;
	private String grant_type;
	private String scope;
	
	public String getClientId() {
		return client_id;
	}
	
	public void setClientId(String clientId) {
		this.client_id = clientId;
	}

	public String getClientSecret() {
		return client_secret;
	}

	public void setClientSecret(String clientSecret) {
		this.client_secret = clientSecret;
	}

	public String getGrantType() {
		return grant_type;
	}

	public void setGrantType(String grantType) {
		this.grant_type = grantType;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	
}
