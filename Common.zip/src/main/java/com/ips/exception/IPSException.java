package com.ips.exception;

public class IPSException extends Exception {
    
    private static final long serialVersionUID = 1L;
    private final String message;
    
    public IPSException(String message){
        this.message = message;
    }

    @Override
    public String getMessage() {        
        return message;
    }
}
