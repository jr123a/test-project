package com.ips.common.common;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CustomLogger {
        private static final Logger loggerInstance  = LogManager.getLogger("");

        private CustomLogger() {
            super();
            throw new InstantiationError("Creating instances of this class is not allowed.");
        }
        
        public static final boolean isDebugEnabled() {            
            return loggerInstance.isEnabled(Level.DEBUG);
        }
        
        public static final boolean isInfoEnabled() {            
            return loggerInstance.isEnabled(Level.INFO);
        }
        
        public static final boolean isWarnEnabled() {            
            return loggerInstance.isEnabled(Level.WARN);
        }
        
        public static final boolean isErrorEnabled() {            
            return loggerInstance.isEnabled(Level.ERROR);
        }
        
        public static final boolean isFatalEnabled() {            
            return loggerInstance.isEnabled(Level.FATAL);
        }
            
        public static final void enter(Class<?> logClass, Object... parameters) {
            enter(Level.DEBUG, logClass, parameters);
        }
        
        public static final void enter(Level level, Class<?> logClass, Object... parameters) {
            getParameterInfo("method is called", level, logClass, parameters);
        }
        
        public static final void exit(Class<?> logClass, Object... parameters) {
            enter(Level.DEBUG, logClass, parameters);
        }
        
        public static final void exit(Level level, Class<?> logClass, Object... parameters) {
            getParameterInfo("method exits", level, logClass, parameters);
        }
            
        private static final void getParameterInfo(String action, Level level, Class<?> logClass, Object... parameters) {
            String parameterInfo = "";            
            if (parameters.length > 0) {
                StringBuilder parameterString = new StringBuilder();
                for (Object p : parameters) {
                    if (p != null) {
                        parameterString.append(p.toString() + ", ");
                    }
                }
                
                parameterInfo = String.format(" with parameters (%s)", parameterString.substring(0, parameterString.length() - 2));
            }
            
            String message = String.format("%s %s%s.", getMethodName(logClass), action, parameterInfo);
            
            if (level == level.DEBUG) {
                CustomLogger.loggerInstance.debug(message);
            }
            else if (level == level.INFO) {
                CustomLogger.loggerInstance.info(message);
            }
            else if (level == level.WARN) {
                CustomLogger.loggerInstance.warn(message);
            }
        }

        public static final void debug(Class<?> logClass, String message) {
            setMessage(logClass, message, Level.DEBUG);
        }
        
        public static final void debug(String className, String methodName, String message) {
            setMessage(className, methodName, message, Level.DEBUG);
        }

        public static final void debug(Class<?> logClass, String methodName, String message) {
            setMessage(logClass.getClass().getName(), methodName, message, Level.DEBUG);
        }

        public static final void info(Class<?> logClass, String message) {
            setMessage(logClass, message, Level.INFO);
        }

        public static final void warn(Class<?> logClass, String message, Throwable t) {
            setMessage(logClass, message, t, Level.WARN);
        }

        public static final void warn(Class<?> logClass, Throwable t) {
            setMessage(logClass, t, Level.WARN);
        }

        public static final void warn(Class<?> logClass, String message) {
            setMessage(logClass, message, Level.WARN);
        }
        
        public static final void error(Class<?> logClass, String message, Throwable t) {
            setMessage(logClass, message, t, Level.ERROR);
        }

        public static final void error(Class<?> logClass, Throwable t) {
            setMessage(logClass, t, Level.ERROR);
        }

        public static final void error(String className, String methodName, String message, Throwable t) {
            setMessage(className, methodName, message, t, Level.ERROR);
        }
        
        public static final void error(Class<?> logClass, String methodName, String message, Throwable t) {
            setMessage(logClass.getClass().getName(), methodName, message, t, Level.ERROR);
        }
        
        public static final void error(String className, String methodName, Throwable t) {
            setMessage(className, methodName, null, t, Level.ERROR);
        }
                
        public static final void error(Class<?> logClass, String message) {
            setMessage(logClass, message, Level.ERROR);
        }
        
        public static final void error(String className, String methodName, String message) {
            setMessage(className, methodName, message, Level.ERROR);
        }
        
        public static final void staticError(String className, String message, Throwable t) {
            setMessage(className, null, message, t, Level.ERROR);
        }
        
        public static final void fatal(Class<?> logClass, Throwable t) {
            setMessage(logClass, t, Level.FATAL);
        }
        
        public static final void fatal(Class<?> logClass, String message, Throwable t) {
            setMessage(logClass, message, t, Level.FATAL);
        }

        public static final void fatal(String className, String methodName, String message, Throwable t) {
            setMessage(className, methodName, message, t, Level.FATAL);
        }
        
        public static final void fatal(String className, String methodName, String message) {
            setMessage(className, methodName, message, Level.FATAL);
        }
        
        private static final void setMessage(Class<?> logClass, Throwable t, Level level) {
            setMessage(logClass, null, t, level);
        }
            
        private static final void setMessage(Class<?> logClass, String message, Throwable t, Level level) {
            message = message != null ? message : "is catching an exception.";
            message = String.format("%s %s [%s]", getMethodNames(logClass), message, t.getClass().getSimpleName());
            setLogger(message, t, level);
        }
        
        private static final void setMessage(Class<?> logClass, String message, Level level) {
            message = String.format("%s %s", getMethodNames(logClass), message);
            setLogger(message, null, level);
        }
        
        private static final void setMessage(String className, String methodName, String message, Level level) {
            setMessage(className, methodName, message, null, level);
        }
        
        private static final void setMessage(String className, String methodName, String message, Throwable t, Level level) {
            boolean nullMethodName = methodName == null;
            boolean nullThrowable = t == null;
            String msgFmt = (nullMethodName? "%s->%s %s" : "%s-> %s-> %s") + (nullThrowable?  "%s" : " [%s]");
            message = message != null ? message : "is catching an exception.";
            message = String.format(msgFmt, className, (nullMethodName? methodName : ""), message, (nullThrowable? "" : t.getClass().getSimpleName()));
            setLogger(message, t, level);
        }
        
        private static final void setLogger(String message, Throwable t, Level level) {
            if (t != null) {
                if (level == level.FATAL) {
                    CustomLogger.loggerInstance.fatal(message , t);
                }
                else if (level == level.ERROR) {
                    CustomLogger.loggerInstance.error(message , t);
                }
                else {
                    CustomLogger.loggerInstance.warn(message , t);
                }
            }
            else {
                if (level == level.FATAL) {
                    CustomLogger.loggerInstance.fatal(message);
                }
                else if (level == level.ERROR) {
                    CustomLogger.loggerInstance.error(message);
                }
                else if (level == level.WARN) {
                    CustomLogger.loggerInstance.warn(message);
                }
                else if (level == level.INFO) {
                    CustomLogger.loggerInstance.info(message);
                }
                else {
                    CustomLogger.loggerInstance.debug(message);
                }
            }
        }
        
        private static final String getMethodName(Class<?> logClass) {
            return getMethodNames(logClass, true);
        }
        
        private static final String getMethodNames(Class<?> logClass) {
            return getMethodNames(logClass, false);
        }
        
        private static final String getMethodNames(Class<?> logClass, boolean loggingMethodOnly) {
            String className = "";
            if (logClass != null) {
                className = logClass.getName();
                if (logClass.getPackage() == null) {
                    return className;
                }
            }
            else {
                return "";
            }

            StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
            String logPackageName = logClass.getPackage().getName();
            StringBuilder message = new  StringBuilder();
    
            List<String> methodsList = new ArrayList<>();
            boolean logPackageFound = false;
            int listCtr = 0;

            for (int i = stackTrace.length - 1; i > -1; i--) {
                StackTraceElement element = Thread.currentThread().getStackTrace()[i];
                className = element.getClassName();
                String methodName = element.getMethodName();
                int pos = className.lastIndexOf('.');
                if (pos == -1) {
                    return className;
                }
                String packageName = className.substring(0, pos);

                if (packageName.startsWith(logPackageName)) {
                    if (!logPackageFound) {
                        message.append(String.format("%s->",  className));
                        logPackageFound = true;
                    }
                    
                    if (!StringUtils.isEmpty(methodName) && !methodsList.contains(methodName)) {
                        methodsList.add(element.getMethodName());
                        listCtr++;
                        
                        if (listCtr > 1) {
                            break;
                        }
                    }
                }
             }
            
            if (loggingMethodOnly) {
                String method = methodsList.get(methodsList.size() - 1);
                message.append(String.format("  %s",  method));
            }
            else {
                for (String method : methodsList) {
                    message.append(String.format("  %s->",  method));
                }
            }
            return message.toString();
        }
    }
