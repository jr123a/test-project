package com.ips.common.common;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.List;
import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;
public class DateTimeUtil implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    public static final long MILLIS_PER_DAY = 1000L * 60 * 60 * 24;
    public static final String DATE_FORMAT = "MM/dd/yyyy";
    public static final String FULL_MONTH_FORMAT = "MMMMM dd, yyyy";
    public static final String TIME_FORMAT = "hh:mm a zz";    
    
    public static Date getDate(String dateStr, String pattern) {
        CustomLogger.enter(DateTimeUtil.class.getClass(), String.format("dateStr:%s, pattern:%s",  dateStr, pattern));
        try {
            return new SimpleDateFormat(pattern).parse(dateStr);
        } catch (Exception ex) {
            String logMsg = "Exception occurred parsing date string: " + dateStr + " using format: " + pattern;
            CustomLogger.error(DateTimeUtil.class.getClass(), logMsg, ex);
            return null;
        }
    }   
    
    public static String getDateString(Date dateStr, String pattern) {
        try {
            return new SimpleDateFormat(pattern).format(dateStr);
        } catch (Exception ex) {
            String logMsg = "Exception occurred parsing date string: " + " using format: " + pattern;
            CustomLogger.error(DateTimeUtil.class.getClass(), logMsg, ex);
            return null;
        }
    }   
    
    /**
     * Returns the specified date with a time of midnight (00:00:00).
     * @return
     */
    public static Date getStartDate(Date startDate)
    {
        if (startDate == null) {
            return null;
        }
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE,0);
        cal.set(Calendar.SECOND,0);  
        cal.set(Calendar.MILLISECOND, 0);          
        return cal.getTime();        
    }
    
    /**
     * Returns the specified date with the latest time for that day (23:59:59).
     * @return
     */
    public static Date getEndDate(Date endDate)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(endDate);
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE,59);
        cal.set(Calendar.SECOND,59);  
        cal.set(Calendar.MILLISECOND, 0);          
        return cal.getTime();   
    }
    /**
     * Returns the current date with a time of midnight (00:00:00).
     * @return
     */
    public static Date getCurrentDate() 
    {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE,0);
        cal.set(Calendar.SECOND,0);  
        cal.set(Calendar.MILLISECOND, 0); 
        return cal.getTime();   
    }
    
    /**
     * Returns the current year.
     * @return
     */
    public static int getCurrentYear() 
    {
        return Calendar.getInstance().get(Calendar.YEAR);
    }
    
    /**
     * Returns the current month.
     * @return
     */
    public static int getCurrentMonth() 
    {
        return Calendar.getInstance().get(Calendar.MONTH) + 1; 
    }
    
    /**
     * Adds the specified numberOfDays to the startDate and returns the new date.
     * @param startDate
     * @param numberOfDays
     * @return
     */
    public static Date getDatePlusDays(Date startDate, int numberOfDays)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        cal.add(Calendar.DATE, numberOfDays);    
        return cal.getTime();       
    }
    
    /**
     * Adds the specified numberOfHours to the startDate and returns the new date.
     * @param startDate
     * @param numberOfDays
     * @return
     */
    public static Date getDatePlusHours(Date startDate, int numberOfHours)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        cal.add(Calendar.HOUR, numberOfHours);    
        return cal.getTime();   
    }
    
    /**
     * Adds the specified numberOfSeconds to the startDate and returns the new date.
     * @param startDate
     * @param numberOfSeconds
     * @return
     */
    public static Date getDatePlusSeconds(Date startDate, int numberOfSeconds)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        cal.add(Calendar.SECOND, numberOfSeconds);     
        return cal.getTime();       
    }
    
    /**
     * Subtracts the specified numberOfDays from the targetDate and returns the new date.
     * @param targetDate
     * @param numberOfDays
     * @return
     */
    public static Date getDateMinusDays(Date targetDate, int numberOfDays)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(targetDate);
        cal.add(Calendar.DATE, -numberOfDays);      
        return cal.getTime();       
    }
    
    /**
     * Subtracts the specified numberOfHours from the targetDate and returns the new date.
     * @param targetDate
     * @param numberOfDays
     * @return
     */
    public static Date getDateMinusHours(Date targetDate, int numberOfHours)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(targetDate);
        cal.add(Calendar.HOUR, -numberOfHours);      
        return cal.getTime();   
    }

    /**
     * Adds the specified numberOfMonths to the startDate and returns the new date.
     * @param startDate
     * @param numberOfMonths
     * @return
     */
    public static Date getDatePlusMonths(Date startDate, int numberOfMonths)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        cal.add(Calendar.MONTH, numberOfMonths);     
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE,0);
        cal.set(Calendar.SECOND,0);  
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
    
    /**
     * Subtracts the specified numberOfMonths from the startDate and returns the new date.
     * @param startDate
     * @param numberOfMonths
     * @return
     */
    public static Date getDateMinusMonths(Date startDate, int numberOfMonths)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        cal.add(Calendar.MONTH, -numberOfMonths);     
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE,59);
        cal.set(Calendar.SECOND,59);  
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
    
    
    /**
     *  Calculates the observed New Years Day.
     *
     *@param  year     
     */
    public static int observedNewYearsDay(int year) {
        // January 1st
        int month = 0; // January
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            cal.set(year, month, 2);
        }
        return cal.get(Calendar.DAY_OF_YEAR);
    }
        
    /**
     *  Calculates the observed Martin Luther King Day.
     *
     *@param  year     
     */
    public static int observedMartinLutherKingDay(int year) {
        // Third Monday in January
        int month = 0; // January
        int[] dates = {16, 15, 21, 20, 19, 18, 17};
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(year, month, dates[cal.get(Calendar.DAY_OF_WEEK) - 1]);
        return cal.get(Calendar.DAY_OF_YEAR);
    }
    
    /**
     *  Calculates the observed Presidents Day.
     *
     *@param  year     
     */
    public static int observedPresidentsDay(int year) {
        // Third Monday in February
        int month = 1; // February
        int[] dates = {16, 15, 21, 20, 19, 18, 17};
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(year, month, dates[cal.get(Calendar.DAY_OF_WEEK) - 1]);
        return cal.get(Calendar.DAY_OF_YEAR);
    }
    
    /**
     *  Calculates the observed Memorial Day.
     *
     *@param  year     
     */
    public static int observedMemorialDay(int year) {
        // Last Monday in May
        int month = 4; // May
        int[] dates = {25, 31, 30, 29, 28, 27, 26};
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 31);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(year, month, dates[cal.get(Calendar.DAY_OF_WEEK) - 1]);
        return cal.get(Calendar.DAY_OF_YEAR);
    }
    
    /**
     *  Calculates the observed Independence Day.
     *
     *@param  year     
     */
    public static int observedIndependenceDay(int year) {
        // July 4th
        int month = 6; // July
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 4);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            cal.set(year, month, 5);
        }
        return cal.get(Calendar.DAY_OF_YEAR);
    }
    
    /**
     *  Calculates the observed Labor Day.
     *
     *@param  year     
     */
    public static int observedLaborDay(int year) {
        // The first Monday in September
        int month = 8; // September
        int[] dates = {1, 7, 6, 5, 4, 3, 2};
        Calendar cal = Calendar.getInstance();
        cal.set(year, 5, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(year, month, dates[cal.get(Calendar.DAY_OF_WEEK) - 1]);
        return cal.get(Calendar.DAY_OF_YEAR);
    }
    
    /**
     *  Calculates the observed Columbus Day.
     *
     *@param  year     
     */
    public static int observedColumbusDay(int year) {
        // Second Monday in October
        int month = 9; // October
        int[] dates = {9, 8, 14, 13, 12, 11, 10};
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(year, month, dates[cal.get(Calendar.DAY_OF_WEEK) - 1]);
        return cal.get(Calendar.DAY_OF_YEAR);
    }
    
    /**
     *  Calculates the observed Veterans Day.
     *
     *@param  year     
     */
    public static int observedVeteransDay(int year) {
        // November 11th
        int month = 10; // November
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 11);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            cal.set(year, month, 12);
        }
        return cal.get(Calendar.DAY_OF_YEAR);        
    }        
    
    /**
     *  Calculates the observed Thanksgiving Day.
     *
     *@param  year     
     */
    public static int observedThanksgivingDay(int year) {
        int month = 10; // November
        int[] dates = {26, 25, 24, 23, 22, 28, 27};
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(year, month, dates[cal.get(Calendar.DAY_OF_WEEK) - 1]);
        return cal.get(Calendar.DAY_OF_YEAR);
    }
    
    /**
     *  Calculates the observed Christmas Day.
     *
     *@param  year     
     */
    public static int observedChristmasDay(int year) {
        // December 25th
        int month = 11; // December
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, 25);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            cal.set(year, month, 26);
        }
        return cal.get(Calendar.DAY_OF_YEAR);
    }
    
    /**
     *  Checks if the day is a holiday.
     * 
     *@param  cal
     *@param  year     
     */
    public static boolean checkIfHoliday(Calendar cal, int year) {
        int doy = cal.get(Calendar.DAY_OF_YEAR);
         
        List<Integer> observedHolidays = Arrays.asList (
            observedNewYearsDay(year),
            observedMartinLutherKingDay(year),
            observedPresidentsDay(year),
            observedMemorialDay(year),
            observedIndependenceDay(year),
            observedLaborDay(year),
            observedColumbusDay(year),
            observedVeteransDay(year),
            observedThanksgivingDay(year),
            observedChristmasDay(year)
        );

        return observedHolidays.contains(doy);
        
    }
    
     /**
     * Returns true if it is currently after 1:55 AM on the target date.
     * @return
     */
    public static boolean isAfter2AMOnDate(Date targetDate) {
        if (!getCurrentDate().equals(getStartDate(targetDate))) {
            return false;
        }

        Date currentDate = new Date();

        Calendar cal = Calendar.getInstance();
        cal.setTime(currentDate);
        cal.set(Calendar.HOUR_OF_DAY, 1);
        cal.set(Calendar.MINUTE, 55);
        cal.set(Calendar.SECOND, 0);  
        cal.set(Calendar.MILLISECOND, 0);          
        Date currentDate2AM = cal.getTime(); 

        return currentDate.after(currentDate2AM);  
    }

    public static String formatTime12Hr(String time) throws ParseException{
        String _24HourTime = time;
        SimpleDateFormat _24HourSDF = new SimpleDateFormat("HH:mm");
        SimpleDateFormat _12HourSDF = new SimpleDateFormat("h:mm a");
        Date _24HourDt = _24HourSDF.parse(_24HourTime);
        return _12HourSDF.format(_24HourDt);
    }
    
    public static Timestamp getCurrentTime() {
        Date date = new Date();
        return new Timestamp(date.getTime());
    }
    
    public static boolean isFutureDate(String inputDate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, Locale.ENGLISH);
        sdf.setLenient(false);

        return sdf.parse(inputDate).after(Calendar.getInstance().getTime());
    }
    
    public static String hyphenateyyyyddMMDateString(String dateArg) {
        // if dateArg is not empty or null and length is 8 and it is numeric
        if (!StringUtils.isEmpty(dateArg) && dateArg.trim().length() == 8 && StringUtils.isNumeric(dateArg)) {
            // try to parse the value to ensure its in a yyyyddMM format
            // then compare the format back to original string
            // if they match then its in correct format
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyddMM");
                Date ret = sdf.parse(dateArg);
                if (sdf.format(ret).equals(dateArg)) {
                    return dateArg.substring(0, 4) + "-" + dateArg.substring(4, 6) + "-" + dateArg.substring(6);
                }
            } catch (Exception e) {
                CustomLogger.error(DateTimeUtil.class.getClass(), "Exception occurred trying to parse " + dateArg, e);
            }
        }

        return "1970-01-01";
    }     
    
    public static String getCurrentDateTime() {
        LocalDateTime currentDateTime = LocalDateTime.now(); 
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMddyyyyHHmmss");
        return currentDateTime.format(formatter);
    }
}
