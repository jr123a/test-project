package com.ips.common.common;

import java.io.Serializable;

/**
 * This class is used to store UserName and Password values extracted 
 * from a Websphere J2C Alias.  
 * This AliasVo is used instead of javax.resource.spi.security.PasswordCredential
 */
public class AliasVo implements Serializable {

    private static final long serialVersionUID = 1L;
    private String userName;
    private String password;
    
    public AliasVo(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }
    public AliasVo() {
    //Empty Constructor
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

}
