package com.ips.common.common;

import java.io.Serializable;

public enum SponsorEnum implements Serializable {

    CUSTOM_REG            (0, 1L, "CustomReg", "Custom Reg"),
    OPERATION_SANTA        (1, 2L, "Operation Santa",    "Operation Santa");
    
    private int  index;
    private long  sponsorId;
    private String sponsorName;
    private String description;
    
    private SponsorEnum(int index, long sponsorId, String sponsorName, String description) {
        this.setIndex(index);
        this.setSponsorId(sponsorId);
        this.setSponsorName(sponsorName);
        this.setDescription(description);
    }
    
    public static SponsorEnum lookupBySponsorId(long sponsorId) {
        for (SponsorEnum s : SponsorEnum.values()) {
            if (s.getSponsorId() == sponsorId)  {
                return s;
            }
        }
        return null;
    }
    
    public static String getDescriptionBySponsorId(long sponsorId) {
        SponsorEnum sponsor =  lookupBySponsorId(sponsorId);
        if(sponsor == null) {
            return null;
        }
        return sponsor.getDescription();
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public long getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(long sponsorId) {
        this.sponsorId = sponsorId;
    }

    public String getSponsorName() {
        return sponsorName;
    }

    public void setSponsorName(String sponsorName) {
        this.sponsorName = sponsorName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
