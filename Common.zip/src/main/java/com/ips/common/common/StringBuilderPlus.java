package com.ips.common.common;

public class StringBuilderPlus {

    private StringBuilder sb;

    public StringBuilderPlus(){
         sb = new StringBuilder();
    }

    public void append(String str)
    {
        sb.append(str != null ? str : "");
    }

    public void appendLine(String str)
    {
        sb.append(System.lineSeparator()).append(str != null ? str : "");
    }

    public String toString()
    {
        return sb.toString();
    }
}
