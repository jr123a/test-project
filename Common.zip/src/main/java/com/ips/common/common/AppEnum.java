package com.ips.common.common;

import java.io.Serializable;

public enum AppEnum implements Serializable {
    INFORMED_DELIVERY                    (1L, "Informed Delivery"),
    HOLD_MAIL                            (2L, "Hold Mail"),
    OPERATION_SANTA                     (3L, "Operation Santa"),
    SOCIAL_SECURITY_ADMINISTRATION      (4L, "Social Security Administration"),
    GENERAL_SERVICES_ADMINISTRATION     (5L, "General Services Administration"),
    SOCIAL_SECURITY_ADMINISTRATION_IAL2 (4L, "Social Security Administration IAL-2");
    
    private long appId;
    private String appName;
    
    private AppEnum(long appId, String appName) {
        this.setAppId(appId);
        this.setAppName(appName);
    }

    public static AppEnum lookupByAppId(long appId) {
        for (AppEnum a : AppEnum.values()) {
            if (a.getAppId() == appId) {
                return a;
            }
        }
        return null;
    }
    
    public static AppEnum lookupByAppName(String appName) {
        for (AppEnum a : AppEnum.values()) {
            if (a.getAppName().equals(appName)) {
                if(a.equals(SOCIAL_SECURITY_ADMINISTRATION_IAL2)) {
                    return AppEnum.SOCIAL_SECURITY_ADMINISTRATION;
                }
                return a;
            }
        }
        return null;
    }

    public long getAppId() {
        return appId;
    }

    public void setAppId(long appId) {
        this.appId = appId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }
}
