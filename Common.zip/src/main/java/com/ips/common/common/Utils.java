package com.ips.common.common;

import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;

import com.ibm.websphere.security.NotImplementedException;
import com.ibm.wsspi.security.auth.callback.Constants;
import com.ibm.wsspi.security.auth.callback.WSMappingCallbackHandlerFactory;
import com.ips.common.common.AliasVo;
import com.ips.exception.IPSException;
import com.usps.entreg.filter.data.EntRegPasswordCredential;
import com.usps.net2.enums.SSLTrustModeEnum;
import com.usps.net2x.entregapi.client.EntRegAPIClientEnv;

public class Utils implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private static final String LOG_USER = "User %s";
    
    private static final String ORDER_NUMBER = "Order number: ";

    private static final String ALPHA_NUMERIC = "^[a-zA-Z0-9]+$";

    public static final String ERROR_MSG_RETRIEVING_J2C = "Error occurred in retrieving J2C credentials";
    public static final String ERROR_MSG_READING_PROP = "Error occured reading from properties file: ";
    /*
     * Replaced RegEx with regex from https://www.owasp.org/index.php/OWASP_Validation_Regex_Repository
     */
    private static final String NUMERIC = "^[0-9]+$";

    // yyDDD
    private static final int NUM_DATE_DIGITS = 5;
    // [prefix character] + [check digit] + [at least one sequence digit] + NUM_DATE_DIGITS
    private static final int MIN_LENGTH = 3 + NUM_DATE_DIGITS;
     /**
      * Good characters for Internationalized Resource Identifiers (IRI).
      * This comprises most common used Unicode characters allowed in IRI
      * as detailed in RFC 3987.
      * Specifically, those two byte Unicode characters are not included.
      */

    private static final Pattern IP_ADDRESS
            = Pattern.compile(IVSCommonConstants.IP_ADDRESS_REGEX);

    /**
     *  Regular expression pattern to match most part of RFC 3987
     *  Internationalized URLs, aka IRIs.  Commonly used Unicode characters are
     *  added.
     */
    private static final Pattern WEB_URL = Pattern.compile(IVSCommonConstants.WEB_URL_REGEX); 

    private static final Pattern EMAIL_ADDRESS
            = Pattern.compile(IVSCommonConstants.EMAIL_ADDRESS_REGEX);

    
    public static String getEnvironment()
    {
        String env = getEnvironmentWithoutDot();
        if(env != null) {
            env += ".";
        }
        return env;
    }
    
    public static String getEnvironmentWithoutDot()
    {
        String env = System.getProperty("com.usps.env");
        if(env == null) {
            env = "";
            CustomLogger.error(Utils.class.getClass(), "com.usps.env JVM environment variable is NOT set");
        }else {
            CustomLogger.debug(Utils.class.getClass(), "com.usps.env JVM environment variable is set to: " + env);
        }
        return env;
    }
    
    /**
     * Returns an 8 character length random alphanumeric String
     */
    public static String getActivationCode() {
        UUID code = UUID.randomUUID();
        return code.toString().toUpperCase().replace("-", "").substring(0, 8);
    }
    
    public static String formatPhoneNumber(String strPhoneNumber) {
        String fmtPhoneNumber = null;
        
        try {
            if (StringUtils.isEmpty(strPhoneNumber)) {
                return strPhoneNumber;
            }

            if (strPhoneNumber.length() != 10) {
                return strPhoneNumber;
            }

            if (StringUtils.isNumeric(strPhoneNumber)) {
                fmtPhoneNumber = String.format("%s-%s-%s",
                        strPhoneNumber.substring(0, 3),
                        strPhoneNumber.substring(3, 6),
                        strPhoneNumber.substring(6, 10));
                return fmtPhoneNumber;
            } else {
                return strPhoneNumber;
            }
        } catch (Exception e) {
            CustomLogger.error(Utils.class.getClass(), "Error occurred in formatting phone number "
                    + strPhoneNumber + " ", e);
            return strPhoneNumber;
        }
    }
    
    public static DocumentBuilder getSecureDOMParser() throws ParserConfigurationException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        dbf.setFeature("http://xml.org/sax/features/external-general-entities", false); 
        dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false); 
        dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        dbf.setExpandEntityReferences(false);
        return dbf.newDocumentBuilder();
    }
    
    public static boolean isAlphanumeric(String input) {
        return input.matches(IVSCommonConstants.ALPHA_NUMERIC);
    }
    
    public static boolean isValidURL(String input) {
        Matcher m = WEB_URL.matcher(input);
        return m.matches();
    }
    
    public static boolean isNumeric(String input) {
        return input.matches(IVSCommonConstants.NUMERIC);
    }
    
    public static boolean isValidStreetAddress(String input) {
        return !input.contains("<") && !input.contains(">");
    }
    
    public static boolean isValidIpAddress(String input) {
        Matcher m = IP_ADDRESS.matcher(input);
        return m.matches();
    }
    
    public static boolean isValidEmailAddress(String input) {
        Matcher m = EMAIL_ADDRESS.matcher(input);
        return m.matches();
    }
    
    public static boolean isAlpha(String input) {
        return input.matches(IVSCommonConstants.ALPHA);
    }
    
    public static boolean isNumericWithHyphenComma(String input) {
        return input.matches(IVSCommonConstants.NUMERIC_WITH_HYPHEN_COMMA);
    }
    
    public static boolean isAlphaWithHyphenApostropheSpace(String input) {
        return input.matches(IVSCommonConstants.ALPHA_WITH_HYPHEN_APOSTROPHE_SPACE);
    }
    
    public static boolean isAlphaNumericWithSpace(String input) {
        return input.matches(IVSCommonConstants.ALPHA_NUMERIC_WITH_SPACE);
    }
    
    public static boolean isEmptyString(String input) {
        return input == null || input.length() == 0;
    }
    
    public static boolean matches(String input, String regex) {
        return input.matches(regex);
    }

    public static String getComputerName() {
        try {
            return InetAddress.getLocalHost().getHostName().toUpperCase();
        } catch (UnknownHostException e) {
            CustomLogger.error(Utils.class.getClass(), e);
            return "";
        }
    }
    
    public static String getPropertyWithoutEnvironment(String reqProp) {
        Properties file = new Properties();
        String prop = null;
        try {
            file.load(Utils.class.getResourceAsStream(IVSCommonConstants.IPS_PROPERTIES));
            prop = file.getProperty(reqProp);
        } catch (Exception e) {
            CustomLogger.error(Utils.class.getClass(), ERROR_MSG_READING_PROP, e);
            return null;
        }
        return prop;
    }
    
    public static String getProperty(String reqProp) {
        Properties file = new Properties();
        String prop = null;
        try {
            file.load(Utils.class.getResourceAsStream(IVSCommonConstants.IPS_PROPERTIES));
            prop = file.getProperty(IVSCommonConstants.ENVIRONMENT.concat(reqProp));
        } catch (Exception e) {
            CustomLogger.error(Utils.class.getClass(), ERROR_MSG_READING_PROP, e);
            return null;
        }
        return prop;
    }
    
    public static List<String> getProperty(List<String> stringList) {
        Properties file = new Properties();
        String prop = null;
        List<String> props = new ArrayList <>();
        try {
            file.load(Utils.class.getResourceAsStream(IVSCommonConstants.IPS_PROPERTIES));
            for(String item : stringList) {
                prop = file.getProperty(IVSCommonConstants.ENVIRONMENT.concat(item));
                props.add(prop);
                if(prop == null) {
                    CustomLogger.error(Utils.class.getClass(), ERROR_MSG_READING_PROP);
                    return Collections.emptyList();                }
            }
        } catch (Exception e) {
            CustomLogger.error(Utils.class.getClass(), ERROR_MSG_READING_PROP, e);
        }
        return props;
    }
    
    /**
     * Builds the correct Ent Reg environment object based on system properties.
     * @param debugOn
     * @return
     */
    public static EntRegAPIClientEnv buildEntRegAPIClientEnv(boolean debugOn) {
        CustomLogger.enter(Utils.class.getClass());
        String environment = System.getProperty("com.usps.stand.alone-env");
        String apiURL = System.getProperty("com.usps.stand.alone-apiURL");
        String loginURL = System.getProperty("com.usps.stand.alone-loginURL");
        String sslProtocol = System.getProperty("com.usps.stand.alone-sslProtocol");
        String sslTrustModeRaw = System.getProperty("com.usps.stand.alone-sslTrustMode");
        SSLTrustModeEnum sslTrustMode = (sslTrustModeRaw != null ?
        SSLTrustModeEnum.valueOf(sslTrustModeRaw) : null);
        EntRegAPIClientEnv env = null;
        
        String environmentName = System.getProperty("com.usps.env");
        if ((environment != null) && (apiURL != null) && (loginURL != null)) {
            try {
                CustomLogger.debug(Utils.class.getClass(), "Attempting to initialize EntRegAPIClientEnv with system properties.");
                env = new EntRegAPIClientEnv(environment, apiURL, loginURL, sslProtocol, sslTrustMode, debugOn);
            } catch (Exception e) {
                CustomLogger.error(Utils.class.getClass(), "Unable to initialize EntRegAPIClientEnv with system properties:  " + e);
                env = new EntRegAPIClientEnv(environmentName);
            }
        } else {
            CustomLogger.debug(Utils.class.getClass(), "System properties not set for stand alone client.");
            env = new EntRegAPIClientEnv(environmentName);
        } 
        return env;
    }
    
    public static AliasVo getAppCredentials(String alias) throws IPSException {
        PasswordCredential result = getPasswordCredential(alias);
        if(result == null) {
            return null;
        }
        return new AliasVo(result.getUserName(), new String(result.getPassword()));
        
    }
    public static EntRegPasswordCredential getEntRegAppCredentials(String alias) {
        PasswordCredential result = null;
        
        try {
            result = getPasswordCredential(alias);
        }
        catch (IPSException e) {
            CustomLogger.error(Utils.class.getClass(), e);
            return null;
        }
        
        if(result == null) {
            return null;
        }
        return new EntRegPasswordCredential(result.getUserName(),result.getPassword());
    }
    
    /**
     * Fetches an alias and password from a webshpere J2C alias
     * @param alias
     * @return Password Credential containing J2C credentials
     */
    public static PasswordCredential getPasswordCredential(String alias) throws IPSException {
        PasswordCredential result = null;
        try {
            HashMap<String, String> map = new HashMap<>();
            map.put(Constants.MAPPING_ALIAS, alias);

            CallbackHandler cbh = (WSMappingCallbackHandlerFactory.getInstance()).getCallbackHandler(map, null);
            LoginContext lc = new LoginContext("DefaultPrincipalMapping", cbh);
            lc.login();
            Subject subject = lc.getSubject();
            Set<Object> creds = subject.getPrivateCredentials();
            result = (PasswordCredential) creds.toArray()[0];
        } 
        // This method MUST throw an IPSException if something goes wrong to ensure that failover will occur to the other supplier
        catch (Exception e) {
            CustomLogger.error(Utils.class.getClass(), "Error occurred in retrieving J2C credentials for alias " + alias, e);
            throw new IPSException(ERROR_MSG_RETRIEVING_J2C);
        } 
        
        return result;
    }
    
    /**
     * Helper method assist logging the userID
     * @param userId
     * @return
     */
    public static String logUser(String userId) {
        return String.format(LOG_USER, userId);
    }
    
    public static String getBrowserName(HttpServletRequest request) {
        String userAgent = request.getHeader("user-agent");
        String browserName = "";
        
        if (StringUtils.containsIgnoreCase(userAgent, "msie")) {
            String substring = userAgent.substring(userAgent.indexOf("MSIE")).split(";")[0];
            browserName = substring.split(" ")[0].replace("MSIE", "IE") + "-"+ substring.split(" ")[1];
        } else if (StringUtils.containsIgnoreCase(userAgent, "safari") && StringUtils.containsIgnoreCase(userAgent, "version")) {
            browserName = (userAgent.substring(userAgent.indexOf("Safari")).split(" ")[0]).split("/")[0]+ "-"+ (userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
        } else if (StringUtils.containsIgnoreCase(userAgent, "opr") || StringUtils.containsIgnoreCase(userAgent, "opera")) {
            if (StringUtils.containsIgnoreCase(userAgent, "opera")) {
                browserName = (userAgent.substring(userAgent.indexOf("Opera")).split(" ")[0]).split("/")[0]+ "-"+ (userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
            }
            else if (StringUtils.containsIgnoreCase(userAgent, "opr")) {
                browserName = ((userAgent.substring(userAgent.indexOf("OPR")).split(" ")[0]).replace("/", "-")).replace("OPR","Opera");
            }
        } else if (StringUtils.containsIgnoreCase(userAgent, "chrome")) {
            browserName = (userAgent.substring(userAgent.indexOf("Chrome")).split(" ")[0]).replace("/", "-");
        } else if ((userAgent.indexOf("mozilla/36.0") > -1)
                || (userAgent.indexOf("netscape6") != -1)
                || (userAgent.indexOf("mozilla/35.0") != -1)
                || (userAgent.indexOf("mozilla/34.0") != -1)
                || (userAgent.indexOf("mozilla/33.1") != -1)
                || (userAgent.indexOf("mozilla/33.0") != -1)
                || (userAgent.indexOf("mozilla/32.0") != -1)
                || (userAgent.indexOf("mozilla/31.0") != -1)) {

            browserName = "Netscape-?";

        } else if (StringUtils.containsIgnoreCase(userAgent, "firefox")) {
            browserName = (userAgent.substring(userAgent.indexOf("Firefox")).split(" ")[0]).replace("/", "-");
        } else if (StringUtils.containsIgnoreCase(userAgent, "rv")) {
            browserName = "IE";
        } else {
            browserName = "Unknown, More-Info: " + userAgent;
        }    
        return browserName;
    }

    /**
     * Retrieves user name and password from a J2C alias configured in WebSphere.
     * @param j2cAlias
     * @return
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static AliasVo getJ2CData(String j2cAlias) throws Exception {
        AliasVo aliasVo = new AliasVo();
        
        //obtain WAS J2C authentication alias configuration - try in version 8.0.0.9 because 
        //currently not working because of WAS bug report PM72659 fix may not be applied to version 8.0.0.6 (Tom's local WAS version)
        try {
            Map map = new HashMap();
            map.put(Constants.MAPPING_ALIAS, j2cAlias);
            CallbackHandler callbackHandler = WSMappingCallbackHandlerFactory.getInstance().getCallbackHandler(map, null);

            LoginContext loginContext = new LoginContext("DefaultPrincipalMapping", callbackHandler);
            loginContext.login();

            Subject subject = loginContext.getSubject();
            Set credentials = subject.getPrivateCredentials();

            PasswordCredential passwordCredential = (PasswordCredential) credentials.iterator().next();

            aliasVo.setUserName(passwordCredential.getUserName());
            aliasVo.setPassword(new String(passwordCredential.getPassword()));
              
            CustomLogger.debug(Utils.class.getClass(), "J2C App User Name = "+ aliasVo.getUserName());
            
        } catch (NotImplementedException | LoginException e) {
            CustomLogger.error(Utils.class.getClass(), ERROR_MSG_RETRIEVING_J2C, e);
            throw new Exception(ERROR_MSG_RETRIEVING_J2C);
        }
        
        return aliasVo;
    }
    
    /**
     * The identifier begins with the letter "D" to indicate a request for an identity history summary 
     * provided under the U.S. Department of Justice Order 556-73. The first digit is a mod-10 check digit. 
     * The remainder of the identifier is a reversed string of sequence generated digits, followed by a 
     * two-digit year, followed by a three-digit day of the year.
     * @param input
     * @return
     */
    public static boolean isValidDNumber(String identifier) {
        CustomLogger.debug(Utils.class.getClass(), String.format("is called with parameters %s:%s, length:%s", ORDER_NUMBER, identifier, identifier.length()));
        
        // Ensure the identifier is of minimum length
        if (identifier == null || identifier.length() < MIN_LENGTH) {
            CustomLogger.debug(Utils.class.getClass(), ORDER_NUMBER + identifier + " failed length check");
            return false;
        }
        
        // Ensure the identifier prefix is correct
        if (!"D".equals(identifier.substring(0,1))) {
            CustomLogger.debug(Utils.class.getClass(), ORDER_NUMBER + identifier + " failed D check");
            return false;
        }
        
        // Ensure the identifier is alphanumeric
        if (!identifier.matches(ALPHA_NUMERIC)) {
            CustomLogger.debug(Utils.class.getClass(), ORDER_NUMBER + identifier + " failed alphanumeric check");
            return false;
        }
        
        // Ensure the D is followed by numbers
        String digits = identifier.substring(1, identifier.length());
        
        if (!digits.matches(NUMERIC)) {
            CustomLogger.debug(Utils.class.getClass(), ORDER_NUMBER + identifier + " failed numeric check");
            return false;
        }
        
        // Read the check digit
        int checkDigit = Character.digit(identifier.charAt(1), 10);
        if (checkDigit < 0) {
            CustomLogger.debug(Utils.class.getClass(), ORDER_NUMBER + identifier + " check digit less than 0");
            return false;
        }
        
        try {
            // Ensure the check digit is correct
            // Starts at 2 in order to skip the prefix character and check digit
            String baseId = identifier.substring(2);
            
            if (checkDigit != calculateCheckDigit(Long.valueOf(baseId).longValue())) {
                CustomLogger.debug(Utils.class.getClass(), ORDER_NUMBER + identifier + " failed check digit check");
                return false;
            }
            
            // Ensure the date portion is a valid date
            String dateId = baseId.substring(baseId.length() - NUM_DATE_DIGITS);
            SimpleDateFormat fmt = new SimpleDateFormat("yyDDD");
            fmt.setLenient(false);
            fmt.parse(dateId);
            // The identifier format is valid
            return true;
        } 
        catch (NumberFormatException e) {
            CustomLogger.error(Utils.class.getClass(), ORDER_NUMBER + identifier + " failed date format check", e);
            return false;
        } 
        catch (ParseException e) {
            CustomLogger.error(Utils.class.getClass(), ORDER_NUMBER + identifier + " failed date format check", e);
            return false;
        }
    }
    
    public static int calculateCheckDigit(long id) {
        int sum = 0;
        boolean evenDigit = true;
        
        while (id > 0) {
            int digit = (int) (id % 10L);
            
            if (evenDigit) {
                sum += digit;
            } 
            else {
                if (digit >= 5) {
                    sum += 2 * digit - 9;
                } else {
                    sum += 2 * digit;
                }
            }
            
            id /= 10;
            evenDigit = !evenDigit;
        }
        
        return 9 - (sum % 10);
    }

    /**
     * remove non numeric characters from string
     * This method takes a phone formatted with extra characters like (201) 555-1212 
     * and converts it to numeric only digits like 2015551212
     */
    public static String removeNonNumericCharactersFromString(String phoneNumberInput) {
        char [] phoneNumberArray1 = phoneNumberInput.toCharArray();
        List <Character> phoneNumberArray2 = new ArrayList<>();
        for (char input : phoneNumberArray1) {
            if (input >= '0' && input <= '9') {
                phoneNumberArray2.add(input);
            }
        }
        StringBuilder phoneNumberOutput = new StringBuilder(phoneNumberArray2.size());
        for (Character digit: phoneNumberArray2) {
            phoneNumberOutput.append(digit);
        }
        return(phoneNumberOutput.toString());
    }
    
}
