package com.ips.common.common;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import com.ibm.websphere.security.NotImplementedException;
import com.ibm.wsspi.security.auth.callback.Constants;
import com.ibm.wsspi.security.auth.callback.WSMappingCallbackHandlerFactory;
import com.ips.exception.IPSException;

public class WebSphereUtils implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
         * Retrieves user name and password from a J2C alias configured in WebSphere.
         * @param j2cAlias
         * @return
         */
        @SuppressWarnings({ "rawtypes", "unchecked" })
        public static AliasVo getJ2CData(String j2cAlias) throws IPSException {
            AliasVo aliasVo = new AliasVo();
            
            //obtain WAS J2C authentication alias configuration - try in version 8.0.0.9 because 
            //currently not working because of WAS bug report PM72659 fix may not be applied to version 8.0.0.6 (Tom's local WAS version)
            try {
                Map map = new HashMap();
                map.put(Constants.MAPPING_ALIAS, j2cAlias);
                CallbackHandler callbackHandler = WSMappingCallbackHandlerFactory.getInstance().getCallbackHandler(map, null);
    
                LoginContext loginContext = new LoginContext("DefaultPrincipalMapping", callbackHandler);
                loginContext.login();
    
                Subject subject = loginContext.getSubject();
                Set credentials = subject.getPrivateCredentials();
    
                PasswordCredential passwordCredential = (PasswordCredential) credentials.iterator().next();
    
                aliasVo.setUserName(passwordCredential.getUserName());
                aliasVo.setPassword(new String(passwordCredential.getPassword()));
                  
                CustomLogger.debug(WebSphereUtils.class.getClass(), "J2C App User Name = "+ aliasVo.getUserName());
                
            } catch (NotImplementedException e) {
                CustomLogger.error(WebSphereUtils.class.getClass(), "Error occurred in retrieving J2C credentials", e);
                throw new IPSException("Error occurred in retrieving J2C credentials");
            } catch (LoginException e) {
                CustomLogger.error(WebSphereUtils.class.getClass(), "Error occurred in retrieving J2C credentials", e);
                throw new IPSException("Error occurred in retrieving J2C credentials");
            }
            
            return aliasVo;
        }

    public static boolean bypassCRIDCookie() {
            CustomLogger.debug(WebSphereUtils.class.getClass(), String.format("is called with parameter Machine Name:%s",  IVSCommonConstants.COMPUTER_NAME));
            return !(IVSCommonConstants.COMPUTER_NAME.toUpperCase().endsWith("USPS.COM") || "LOCALHOST".equals(IVSCommonConstants.COMPUTER_NAME.toUpperCase()));
        }

    public static boolean isLowerEnvAndBypass() {
        // Need the parens around the OR condition so that the bypass CRID part will still be evaluated in DEV and SIT
        return ("dev.".equals(IVSCommonConstants.ENVIRONMENT) || "sit.".equals(IVSCommonConstants.ENVIRONMENT)) && bypassCRIDCookie();
    }

}
