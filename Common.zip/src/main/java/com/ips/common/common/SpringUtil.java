package com.ips.common.common;

import java.io.Serializable;

import javax.servlet.ServletContext;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class SpringUtil implements Serializable 
{ 
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    protected ApplicationContext mContext;
    protected static SpringUtil sInstance;
    
    protected SpringUtil(ServletContext servletContext) {
        mContext = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
    }
    
    public synchronized static SpringUtil getInstance(ServletContext servletContext) {
        if (sInstance == null) {
            sInstance = new SpringUtil(servletContext);
        }
        return sInstance;
    }
    
    public Object getBean(String name) {        
        return mContext.getBean(name);
    }
    
    public ApplicationContext getContext() {
        return mContext;
    }
} 
