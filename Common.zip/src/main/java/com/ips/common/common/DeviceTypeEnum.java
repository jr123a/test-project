package com.ips.common.common;

import java.io.Serializable;

public enum DeviceTypeEnum implements Serializable {

	GENERATION_5_IPOD_MPOS        (1L, "Generation 5 iPOD (mPOS)",    "Generation 5"),
	GENERATION_6_IPOD_MPOS        (2L, "Generation 6 iPOD (mPOS)",    "Generation 6"),
	RSS_RETAIL__POS               (3L, "RSS Retail/POS",    "RSS Retail/POS"),
	EBIS	        				(4L, "EBIS device (tablet, laptop or desktop)",	"EBIS"),
	MDD	 							(5L, "MDD Device",	"MDD");
    
    private long  id;
    private String description;
    private String nickName;
    
    private DeviceTypeEnum(long id, String description, String nickName) {
        this.setId(id);
        this.setDescription(description);
        this.setNickName(nickName);
    }
    
    public static DeviceTypeEnum lookupById(long id) {
        for (DeviceTypeEnum d : DeviceTypeEnum.values()) {
            if (d.getId () == id)  {
                return d;
            }
        }
        return null;
    }
    
    public static String getNickNameById(long id) {
        DeviceTypeEnum type =  lookupById(id);
        if(type == null) {
            return null;
        }
        return type.getNickName();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
}
