package com.ips.common.common;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;


import com.ibm.websphere.security.NotImplementedException;
import com.ibm.wsspi.security.auth.callback.Constants;
import com.ibm.wsspi.security.auth.callback.WSMappingCallbackHandlerFactory;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class ApplicationConstants {
    
    private static Properties props;
    private static String appName;
    private static String appPwd;
    
    public static final String ENT_REG_APP = "EntRegApp";
     
    public static final String ENTREG_APP_NAME = appName;
    public static final String ENTREG_APP_PWD = appPwd;
    public static final String ENTREG_LOGIN_URL = props.getProperty((new StringBuilder(String.valueOf(getEnvironment()))).append("com.usps.entreg.ENTREG_LOGIN_URL").toString());
    public static final String ENTREG_API_URL = props.getProperty((new StringBuilder(String.valueOf(getEnvironment()))).append("com.usps.entreg.ENTREG_API_URL").toString());
    
    public static final String FEDERATION_URL = getStringProperty((new StringBuilder(String.valueOf(getEnvironment()))).append("com.usps.ips.FEDERATION_URL").toString());
    public static final String TARGET_URL = getStringProperty((new StringBuilder(String.valueOf(getEnvironment()))).append("com.usps.ips.TARGET_URL").toString());
    public static final String SMPORTAL_URL = getStringProperty((new StringBuilder(String.valueOf(getEnvironment()))).append("com.usps.ips.SMPORTAL_URL").toString());
    public static final String GATEWAY_URL = getStringProperty((new StringBuilder(String.valueOf(getEnvironment()))).append("com.usps.ips.GATEWAY_URL").toString());
    public static final String RETRY_LOGIN_URL = getStringProperty((new StringBuilder(String.valueOf(getEnvironment()))).append("com.usps.ips.RETRY_LOGIN_URL").toString());
    
    public static final String USER_ID_KEY = "CUSTREG_USER_ID";
    public static final String CLIENT_IP_ADDR = "CLIENT_IP_ADDR";
    public static final String CLIENT_IP = "clientip";
    public static final String NS_CLIENT_IP = "NS-Client-IP";
    public static final String BSN_ESERVICE = "BSNESERVICE";
    public static final String EBSN = "EBSN";
    
    public static final String LOA_15 = "1.5";
    public static final String LOA_20 = "2.0";
    
    public static final String LOA_ID_510 = "510";
    public static final String LOA_RP_ID = "520";
    public static final Short LOA_RP_520 = 520;
    public static final Short LOA_RP_525 = 525;
    public static final String LOA_IP_ID = "600";
    public static final String LOA_IP_515 = "515";
    public static final String LOA_ID_530 = "530";
    
    public static final String LOA_RP_NAME = "Online KBA - NIST";
    public static final String LOA_RP_OTP_NAME = "Online Phone OTP - NIST";
    public static final String LOA_IP_NAME = "In-person - Retail";
    
    public static final String LOA_FLAG_ACHIEVED = "Y";
    public static final String LOA_FLAG_NOT_ACHIEVED = "N";
    
    public static final String PROOFING_STATUS_INITIATED = "INITIATION";
    public static final String PROOFING_STATUS_COMPLETE = "COMPLETE";
    public static final String PROOFING_STATUS_PHONE_VERIFIED = "PHONE VERIFIED";
    public static final String PROOFING_STATUS_PHONE_NOT_VERIFIED = "PHONE NOT VERIFIED";
    public static final String PROOFING_STATUS_PENDING = "ACTIVATION PENDING";
    public static final String PROOFING_STATUS_IN_PROGRESS = "IN PROGRESS";
    public static final String PROOFING_STATUS_CANCELLED = "CANCELLED";
    
    public static final String PROOFING_RESULT_PASSED = "Passed";
    public static final String PROOFING_RESULT_FAILED = "Failed";
    
    public static final String OTP_SUPPLIER_EQUIFAX = "Equifax";
    public static final String OTP_SUPPLIER_LEXISNEXIS = "Lexis Nexis";
    
    
    
    private ApplicationConstants() {
        throw new IllegalStateException("Constants class, do not instantiate");
    }
    
    
     static {
          props = new Properties();
          try {
               props.load(ApplicationConstants.class.getResourceAsStream("/uspsnet.properties"));
          } catch (IOException e) {
              CustomLogger.error(ApplicationConstants.class.getClass(), "Error occurred loading uspsnet.properties file ", e);
          }
          
          //J2C retrieval -try in version 8.0.0.9 because 
          //currently not working because of WAS bug report PM72659 fix may not be applied to version 8.0.0.6 (Tom's local WAS version)
          String j2cAlias = ENT_REG_APP;
          try {
              // ----------WAS 6 change -------------
              HashMap map = new HashMap();
              map.put(com.ibm.wsspi.security.auth.callback.Constants.MAPPING_ALIAS,ENT_REG_APP);
              CallbackHandler cbh = (WSMappingCallbackHandlerFactory.getInstance()).getCallbackHandler(map, null);
              LoginContext lc = new LoginContext("DefaultPrincipalMapping", cbh);
              lc.login();
         } catch(Exception e) {
             CustomLogger.error(ApplicationConstants.class.getClass(), "APPLICATION ERROR: cannot load credentials for j2calias = " + j2cAlias, e);
          }
          
          //obtain CustReg App Name and Pwd from WAS J2C authentication alias configuration - try in version 8.0.0.9 because 
          //currently not working because of WAS bug report PM72659 fix may not be applied to version 8.0.0.6 (Tom's local WAS version)
          try {
            Map map = new HashMap();
              map.put(Constants.MAPPING_ALIAS, ENT_REG_APP);
              CallbackHandler callbackHandler = WSMappingCallbackHandlerFactory.getInstance().getCallbackHandler(map, null);

              LoginContext loginContext = new LoginContext("DefaultPrincipalMapping", callbackHandler);
              loginContext.login();

              Subject subject = loginContext.getSubject();
              Set credentials = subject.getPrivateCredentials();

              PasswordCredential passwordCredential = (PasswordCredential) credentials.iterator().next();

              appName = passwordCredential.getUserName();
              appPwd = new String(passwordCredential.getPassword());
              
              CustomLogger.debug(ApplicationConstants.class.getClass(), "J2C App User Name = "+ appName);
        } catch (NotImplementedException | LoginException e) {
            CustomLogger.error(ApplicationConstants.class.getClass(), "Error occurred in retrieving J2C credentials", e);
        } 
     }  
     
     public static String getEnvironment()
     {
         String env = System.getProperty("com.usps.env");
         if(env == null) {
             env = "";
             CustomLogger.debug(ApplicationConstants.class.getClass(), "com.usps.env JVM environment variable is NOT set");
         }
         else {
            env = (new StringBuilder(String.valueOf(env))).append(".").toString();
            CustomLogger.debug(ApplicationConstants.class.getClass(), "com.usps.env JVM environment variable is set to: " + env);
         }
         return env;
     }
     
     private static String getStringProperty(String key) {
         CustomLogger.debug(ApplicationConstants.class.getClass(), "Getting value of property with key: " + key);
         String propValue = props.getProperty(key.trim());
         
         if (null == propValue) {
             return null;
         }
         else {
             return propValue.trim();
         }
     }
}
