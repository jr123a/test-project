package com.ips.common.common;

import java.io.Serializable;

public enum EquifaxStateIdEnum implements Serializable{

	DRIVERS_LICENSE			("1", "Drivers License"),
	DRIVERS_PERMIT			("2", "Drivers Permit"),
	ID_CARD					("3", "ID Card");
	
	 private String  id;
    private String description;
    
    private EquifaxStateIdEnum(String id, String description) {
        this.setId(id);
        this.setDescription(description);
    }
    
    public static EquifaxStateIdEnum lookupById(String id) {
        for (EquifaxStateIdEnum e : EquifaxStateIdEnum.values()) {
            if (e.getId () == id)  {
                return e;
            }
        }
        return null;
    }
    
    public static EquifaxStateIdEnum lookupByDescription(String desc) {
        for (EquifaxStateIdEnum e : EquifaxStateIdEnum.values()) {
            if (desc.equalsIgnoreCase(e.getDescription()))  {
                return e;
            }
        }
        return null;
    }

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
