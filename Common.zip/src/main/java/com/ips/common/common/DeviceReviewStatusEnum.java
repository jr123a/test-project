package com.ips.common.common;

import java.io.Serializable;

public enum DeviceReviewStatusEnum implements Serializable {

    PASS    (1L, "H", "pass", "High Confidence"),
    REVIEW    (2L, "M", "review", "Medium Confidence"),
    REJECT    (3L, "L", "reject", "Low Confidence");
    
    private long  deviceConfidenceId;
    private String reputationAssessment;
    private String reviewStatus;
    private String description;
    
    private DeviceReviewStatusEnum(long deviceConfidenceId, String reputationAssessment, String reviewStatus, String description) {
        setDeviceConfidenceId(deviceConfidenceId);
        setReputationAssessment(reputationAssessment);
        setReviewStatus(reviewStatus);
        setDescription(description);
    }
    
    public static DeviceReviewStatusEnum lookupByReviewStatus(String reviewStatus) {
        for (DeviceReviewStatusEnum r : DeviceReviewStatusEnum.values()) {
            if (r.getReviewStatus().equalsIgnoreCase(reviewStatus))  {
                return r;
            }
        }
        return DeviceReviewStatusEnum.REVIEW;
    }
    
    public static DeviceReviewStatusEnum lookupByReputationAssessment(String reputationAssessment) {
        for (DeviceReviewStatusEnum r : DeviceReviewStatusEnum.values()) {
            if (r.getReputationAssessment().equalsIgnoreCase(reputationAssessment))  {
                return r;
            }
        }
        return null;
    }
    
    public long getDeviceConfidenceId() {
        return deviceConfidenceId;
    }

    private void setDeviceConfidenceId(long deviceConfidenceId) {
        this.deviceConfidenceId = deviceConfidenceId;
    }

    public String getReputationAssessment() {
        return reputationAssessment;
    }

    private void setReputationAssessment(String reputationAssessment) {
        this.reputationAssessment = reputationAssessment;
    }

    public String getReviewStatus() {
        return reviewStatus;
    }

    private void setReviewStatus(String reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getDescription() {
        return description;
    }

    private void setDescription(String description) {
        this.description = description;
    }
}
