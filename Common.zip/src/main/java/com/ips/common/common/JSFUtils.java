package com.ips.common.common;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

public class JSFUtils implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private JSFUtils() {}
    
    public static String getRootViewId() {
        return getFacesContext().getViewRoot().getViewId();
    }
    
    public static String getRootViewComponentId() {
        return getFacesContext().getViewRoot().getId();
    }
    
    /**
     * default method to get FacesContext within JSF.
     * @return
     */
    public static FacesContext getFacesContext() {
        return FacesContext.getCurrentInstance();
    }
    
    public static ServletContext getServletContext() {
        return (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
    }
    
    public static void redirect(String url) throws IOException {
        getFacesContext().getExternalContext().redirect(url);
    }
    
    @SuppressWarnings("unchecked")
    public static <T> T getManagedBean(String beanName) {
        FacesContext context = FacesContext.getCurrentInstance();
        Application application = context.getApplication();
        return (T) application.evaluateExpressionGet(context, "#{" + beanName + "}", Object.class);
    }
    
    public static Application getApplication() {
        return getFacesContext().getApplication();
    }
    
    public static Map getRequestParameterMap() {
        return getFacesContext().getExternalContext().getRequestParameterMap();
    }
    
    private static Map<String, Object> getRequestMap() {
        return getFacesContext().getExternalContext().getRequestMap();
    }
    
    public static String getRequestContextPath() {
        return getFacesContext().getExternalContext().getRequestContextPath();
    }
    
    public static String getRequestAttribute(String attrName) {
        return (String)getRequestMap().get(attrName);
    }
    
    public static void setRequestAttribute(String attrName, String value) {
        getRequestMap().put(attrName, value);
    }
    
    public static void setRequestAttribute(String attrName) {
        getRequestMap().put(attrName, "");
    }
    
    public static Map getSessionMap() {
        return getFacesContext().getExternalContext().getSessionMap();
    }
    
    public static void addMessage(String message) {
        addMessage(null, message);
    }
    public static void addMessage(String componentId, String message) {
        getFacesContext().addMessage(componentId, new FacesMessage(message));
    }
    
    public static void addErrorMessage(String componentId, String message) {
        FacesMessage msg = new FacesMessage(message);
        msg.setSeverity(FacesMessage.SEVERITY_ERROR);
        getFacesContext().addMessage(componentId, msg);
    }
    
    /**
     * add facesMessage, and associates this message with the specified component
     * @param clientId - the componentId this message associated with, for example, getRootViewComponentId()
     * @param messageSummary
     * @param messageDetail
     */
    public static void addFacesErrorMessage(String clientId, String messageSummary, String messageDetail) {
        FacesMessage fm = new FacesMessage(FacesMessage.SEVERITY_ERROR, messageSummary, messageDetail);
        getFacesContext().addMessage(clientId, fm);
    }
    
    /**
     * add facesMessage only if it does not already exist for the specified component, and associates this message with the specified component
     * @param clientId - the componentId this message associated with, for example, getRootViewComponentId()
     * @param messageSummary
     * @param messageDetail
     */
    public static void addFacesErrorMessageNoDuplicate(String clientId, String message) {
        List<FacesMessage> messages = getFacesContext().getMessageList(clientId);
        
        if (messages != null && messages.isEmpty()) {
            FacesMessage msg = new FacesMessage(message);
            msg.setSeverity(FacesMessage.SEVERITY_ERROR);
            getFacesContext().addMessage(clientId, msg);
        }
    }
    
    /**
     * add facesMessage, but this message does not associate with any component
     * @param messageSummary
     * @param messageDetail
     */
    public static void addFacesErrorMessage(String messageSummary, String messageDetail) {
        FacesMessage fm = new FacesMessage(FacesMessage.SEVERITY_ERROR, messageSummary, messageDetail);
        getFacesContext().addMessage(null, fm);
    }
    
    /**
     * add facesMessage, but this message does not associate with any component
     * @param message
     */
    public static void addFacesErrorMessage(String message) {
        FacesMessage fm = new FacesMessage(FacesMessage.SEVERITY_ERROR, message, message);
        getFacesContext().addMessage(null, fm);
    }
    
    public static void removeAllFacesMessages() {
        while (FacesContext.getCurrentInstance().getMessages().hasNext()){
            FacesContext.getCurrentInstance().getMessages().remove();            
        } 
    }

}
