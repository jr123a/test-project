package com.ips.common.common;

public class IVSCommonConstants {
    public static final String IPS_PROPERTIES = "/ips.properties";
    public static final String ENVIRONMENT = Utils.getEnvironment();
    public static final String COMPUTER_NAME = Utils.getComputerName();
    //REGEX formatting
    public static final String ALPHA_NUMERIC = "^[a-zA-Z0-9]+$";
    public static final String NUMERIC = "^[0-9]+$";
    public static final String ALPHA = "^[a-zA-Z]+$";
    public static final String ALPHA_NUMERIC_WITH_HYPHEN = "^[a-zA-Z0-9-]+$";
    public static final String NUMERIC_WITH_HYPHEN = "^[0-9-]+$";
    public static final String NUMERIC_WITH_HYPHEN_COMMA = "^[0-9,.-]+$";
    public static final String ALPHA_WITH_HYPHEN_APOSTROPHE_SPACE = "^[a-zA-Z' -]+$";
    public static final String ALPHA_WITH_HYPHEN_SPACE = "^[a-zA-Z -]+$";
    public static final String ALPHA_NUMERIC_WITH_HYPHEN_APOSTROPHE_SPACE = "^[a-zA-Z0-9' -]+$";
    public static final String ABBREVIATED_STATE = "^[A-Za-z]{2}$";
    public static final String ALPHA_NUMERIC_WITH_SPACE = "^[a-zA-Z0-9 ]+$";
    public static final String BUSINESS_CUSTOMER_NAME_REGEX = "^[a-zA-Z' -&/.(),]+$";  
    public static final String STREET_ADDRESS_REGEX = "^[a-zA-Z0-9' ,.#\\/-]+$";
    public static final String EMAIL_ADDRESS_REGEX = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    public static final String IP_ADDRESS_REGEX = "^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$";
    public static final String WEB_URL_REGEX = "^((((https?|ftps?|gopher|telnet|nntp)://)|(mailto:|news:))(%[0-9A-Fa-f]{2}|[-()_.!~*';/?:@&=+$,A-Za-z0-9])+)([).!';/?:,][[:blank:]])?$"; 
    // and finally, a word boundary or end of input.  This is to stop foo.sure from matching as foo.su
 
    
    private IVSCommonConstants() {
    
    }
}
