package com.ips.service;

import java.util.List;


public interface GenericService<T> {

    T create(T entity);

    void delete(T entity);

    T update(T entity);

    List<T> list();
    
    /**
     * Find the model with the given id(PK).
     * 
     * @param type the model type
     * @param id the pk
     * @return the model with the given id (PK) or null if no such model was found
     */
    T findByPK(Object id);

}
