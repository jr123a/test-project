package com.ivs.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
class TestIVSException {
	
	private final String expected = "Exception";
	
	@Test
	void testGetMessage() {
		IVSException ivsException = new IVSException("Exception");
		Assertions.assertEquals(expected, ivsException.getMessage());
	}

}

