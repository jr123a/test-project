package com.ips.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
class TestIPSException {
	
	private final String expected = "Exception";
	
	@Test
	void testGetMessage() {
		IPSException ipsException = new IPSException("Exception");
		Assertions.assertEquals(expected, ipsException.getMessage());
	}

}
