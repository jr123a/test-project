package com.ips.common;

import com.ips.common.common.EscapeChars;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class TestEscapeChars {
    @Test
    public void forHrefAmpersandTest() {
        Assertions.assertEquals("test&amp;123", EscapeChars.forHrefAmpersand("test&123"));
    }
    
    @Test
    public void forXMLTest() {
        Assertions.assertEquals("test&lt;&gt;&quot;&#039;&amp;123", EscapeChars.forXML("test<>\"'&123"));
    }
    
    @Test
    public void toDisableTagsTest() {
        Assertions.assertEquals("test &lt; &gt; 123", EscapeChars.toDisableTags("test < > 123"));
    }
    
    @Test
    public void forRegexTest() {
        Assertions.assertEquals("test \\.\\\\\\?\\*\\+\\&\\:\\{\\}\\[\\]\\(\\)\\^\\$ 123", EscapeChars.forRegex("test .\\?*+&:{}[]()^$ 123"));
    }
    
    @Test
    public void forReplacementStringTest() {
        Assertions.assertEquals("test\\$", EscapeChars.forReplacementString("test$"));
    }
    
}