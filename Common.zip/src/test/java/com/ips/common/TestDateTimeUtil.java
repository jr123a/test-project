package com.ips.common;

import com.ips.common.common.DateTimeUtil;

import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.Assertions;

@TestInstance(Lifecycle.PER_CLASS)
public class TestDateTimeUtil {
    @Test
    public void goodGetDateTest() throws ParseException {
        String format = "MMddyyyy";
        String value = "01012019";
        
        Date actual = DateTimeUtil.getDate(value, format);
        Date expected = new SimpleDateFormat(format).parse(value);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getDateNullTest() {
        Assertions.assertNull(DateTimeUtil.getDate("01012019", "b"));
    }
    
    @Test
    public void goodGetDateStringTest() throws ParseException {
        String format = "MMddyyyy";
        String expected = "01012019";
        
        Date value = new SimpleDateFormat(format).parse(expected);
        
        String actual = DateTimeUtil.getDateString(value, format);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getDateStringNullTest() throws ParseException {
        Assertions.assertNull(DateTimeUtil.getDateString(new Date(), "b"));
    }
    
    @Test
    public void goodGetStartDateTest() throws ParseException {
        Date expected = new SimpleDateFormat("MMddyyyy HH:mm:ss").parse("01012019 00:00:00");
        Date actual = DateTimeUtil.getStartDate(new SimpleDateFormat("MMddyyyy HH:mm:ss").parse("01012019 05:20:12"));
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void returnsNullGetStartDateTest() {
        Assertions.assertNull(DateTimeUtil.getStartDate(null));
    }
    
    @Test
    public void getCurrentDateTest() throws ParseException {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);  
        cal.set(Calendar.MILLISECOND, 0);
        
        Date expected = cal.getTime();
        Date actual = DateTimeUtil.getCurrentDate();

        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getCurrentYearTest() {
        int expected = Calendar.getInstance().get(Calendar.YEAR);
        int actual = DateTimeUtil.getCurrentYear();
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getCurrentMonthTest() {
        int expected = Calendar.getInstance().get(Calendar.MONTH) + 1;
        int actual = DateTimeUtil.getCurrentMonth();
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getDatePlusDaysTest() {
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.DATE, 1);
        
        Date expected = cal.getTime();
        Date actual = DateTimeUtil.getDatePlusDays(today, 1);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getDatePlusHoursTest() {
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.HOUR, 1);
        
        Date expected = cal.getTime();
        Date actual = DateTimeUtil.getDatePlusHours(today, 1);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getDatePlusSecondsTest() {
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.SECOND, 1);
        
        Date expected = cal.getTime();
        Date actual = DateTimeUtil.getDatePlusSeconds(today, 1);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getDateMinusDaysTest() {
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.DATE, -1);
        
        Date expected = cal.getTime();
        Date actual = DateTimeUtil.getDateMinusDays(today, 1);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getDateMinusHoursTest() {
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.HOUR, -1);
        
        Date expected = cal.getTime();
        Date actual = DateTimeUtil.getDateMinusHours(today, 1);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getDatePlusMonthsTest() {
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.MONTH, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);  
        cal.set(Calendar.MILLISECOND, 0);
        
        Date expected = cal.getTime();
        Date actual = DateTimeUtil.getDatePlusMonths(today, 1);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getDateMinusMonthsTest() {
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.MONTH, -1);
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);  
        cal.set(Calendar.MILLISECOND, 0);
        
        Date expected = cal.getTime();
        Date actual = DateTimeUtil.getDateMinusMonths(today, 1);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void observedNewYearsDayTest() {
        int expected = 1;
        int actual = DateTimeUtil.observedNewYearsDay(2019);
        int sundayExpected = 2;
        int sundayActual = DateTimeUtil.observedNewYearsDay(2017);
        
        Assertions.assertEquals(expected, actual);
        Assertions.assertEquals(sundayExpected, sundayActual);
    }
    
    @Test
    public void observedMLKDayTest() {
        int expected = 21;
        int actual = DateTimeUtil.observedMartinLutherKingDay(2019);

        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void observedPresDayTest() {
        int expected = 49;
        int actual = DateTimeUtil.observedPresidentsDay(2019);

        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void observedMemorialDayTest() {
        int expected = 147;
        int actual = DateTimeUtil.observedMemorialDay(2019);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void observedIndependenceDayTest() {
        int sundayExpected = 186;
        int sundayActual = DateTimeUtil.observedIndependenceDay(2021);
        int expected = 185;
        int actual = DateTimeUtil.observedIndependenceDay(2019);
        
        Assertions.assertEquals(sundayExpected, sundayActual);
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void observedLaborDayTest() {
        int expected = 245;
        int actual = DateTimeUtil.observedLaborDay(2019);

        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void observedColumbusDayTest() {
        int expected = 287;
        int actual = DateTimeUtil.observedColumbusDay(2019);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void observedVeteransDayTest() {
        int sundayExpected = 316;
        int sundayActual = DateTimeUtil.observedVeteransDay(2018);
        int expected = 315;
        int actual = DateTimeUtil.observedVeteransDay(2019);
        
        Assertions.assertEquals(sundayExpected, sundayActual);
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void observedThanksgivingDayTest() {
        int expected = 332;
        int actual = DateTimeUtil.observedThanksgivingDay(2019);
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void observedChristmasDayTest() {
        int sundayExpected = 360;
        int sundayActual = DateTimeUtil.observedChristmasDay(2011);
        int expected = 359;
        int actual = DateTimeUtil.observedChristmasDay(2019);
        
        Assertions.assertEquals(sundayExpected, sundayActual);
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void checkIfHolidayTest() {
        Calendar newYearsDayCal = Calendar.getInstance();
        newYearsDayCal.set(Calendar.DAY_OF_YEAR, 1);
        
        Calendar mlkDayCal = Calendar.getInstance();
        mlkDayCal.set(Calendar.DAY_OF_YEAR, 21);
        
        Calendar presidentsDayCal = Calendar.getInstance();
        presidentsDayCal.set(Calendar.DAY_OF_YEAR, 49);
        
        Calendar memorialDayCal = Calendar.getInstance();
        memorialDayCal.set(Calendar.DAY_OF_YEAR, 147);
        
        Calendar independenceDayCal = Calendar.getInstance();
        independenceDayCal.set(Calendar.DAY_OF_YEAR, 185);
        
        Calendar laborDayCal = Calendar.getInstance();
        laborDayCal.set(Calendar.DAY_OF_YEAR, 245);
        
        Calendar columbusDayCal = Calendar.getInstance();
        columbusDayCal.set(Calendar.DAY_OF_YEAR, 287);
        
        Calendar veteransDayCal = Calendar.getInstance();
        veteransDayCal.set(Calendar.DAY_OF_YEAR, 315);
        
        Calendar thanksgivingDayCal = Calendar.getInstance();
        thanksgivingDayCal.set(Calendar.DAY_OF_YEAR, 332);
        
        Calendar christmasDayCal = Calendar.getInstance();
        christmasDayCal.set(Calendar.DAY_OF_YEAR, 359);
        
        Assertions.assertTrue(DateTimeUtil.checkIfHoliday(newYearsDayCal, 2019));
        Assertions.assertTrue(DateTimeUtil.checkIfHoliday(mlkDayCal, 2019));
        Assertions.assertTrue(DateTimeUtil.checkIfHoliday(presidentsDayCal, 2019));
        Assertions.assertTrue(DateTimeUtil.checkIfHoliday(memorialDayCal, 2019));
        Assertions.assertTrue(DateTimeUtil.checkIfHoliday(independenceDayCal, 2019));
        Assertions.assertTrue(DateTimeUtil.checkIfHoliday(laborDayCal, 2019));
        Assertions.assertTrue(DateTimeUtil.checkIfHoliday(columbusDayCal, 2019));
        Assertions.assertTrue(DateTimeUtil.checkIfHoliday(veteransDayCal, 2019));
        Assertions.assertTrue(DateTimeUtil.checkIfHoliday(thanksgivingDayCal, 2019));
        Assertions.assertTrue(DateTimeUtil.checkIfHoliday(christmasDayCal, 2019));
    }
    
    @Test
    public void isAfter2AMOnDateTrueTest() throws ParseException {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 5);
        
        Assertions.assertTrue(DateTimeUtil.isAfter2AMOnDate(c.getTime()));
    }
    
    @Test
    public void isAfter2AMOnDateFalseTest() throws ParseException {
        Date d = new SimpleDateFormat("MMddyyyy HH:mm:ss").parse("01012019 00:00:00");
        
        Assertions.assertFalse(DateTimeUtil.isAfter2AMOnDate(d));
    }
    
    @Test
    public void formatTime12HrTest() throws ParseException {
        String expected = "3:30 PM";
        String actual = DateTimeUtil.formatTime12Hr("15:30");
        
        Assertions.assertEquals(expected, actual);
    }
    
    @Test
    public void getCurrentTimeTest() {
        Assertions.assertNotNull(DateTimeUtil.getCurrentTime());
    }
    
    @Test
    public void isFutureDateTrueTest() throws ParseException {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1);
        String input = new SimpleDateFormat("MM/dd/yyyy").format(c.getTime());
        
        Assertions.assertTrue(DateTimeUtil.isFutureDate(input));
    }
    
    @Test
    public void isFutureDateFalseTest() throws ParseException {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -1);
        String input = new SimpleDateFormat("MM/dd/yyyy").format(c.getTime());
        
        Assertions.assertFalse(DateTimeUtil.isFutureDate(input));
    }
    
    @Test
    public void hyphenateyyyyddMMDateStringBadTest() {
        String expected = "1970-01-01";
        String actualNull = DateTimeUtil.hyphenateyyyyddMMDateString(null);
        String actualEmpty = DateTimeUtil.hyphenateyyyyddMMDateString("");
        String actualBadLength = DateTimeUtil.hyphenateyyyyddMMDateString("1");
        String actualNotNumeric = DateTimeUtil.hyphenateyyyyddMMDateString("abcdefgh");
        String actualFailFormat = DateTimeUtil.hyphenateyyyyddMMDateString("00000000");

        Assertions.assertEquals(expected, actualNull);
        Assertions.assertEquals(expected, actualEmpty);
        Assertions.assertEquals(expected, actualBadLength);
        Assertions.assertEquals(expected, actualNotNumeric);
        Assertions.assertEquals(expected, actualFailFormat);
    }
    
    @Test
    public void hyphenateyyyyddMMDateStringGoodTest() {
        String expected = "2019-20-05";
        String actual = DateTimeUtil.hyphenateyyyyddMMDateString("20192005");

        Assertions.assertEquals(expected, actual);
    }
}