import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import com.ips.persistence.common.UAgentInfo;

class UserAgentTest {

	@Test
	void iPhoneSafaritest() {
    	String userAgent = "";
    	String httpAccept = "";
    	boolean isDesktop = true;
    	userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 12_5_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1.2 Mobile/15E148 Safari/604.1";
		httpAccept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
		UAgentInfo detector = new UAgentInfo(userAgent, httpAccept);
		isDesktop = !(detector.getIsMobilePhone());
		assertEquals(false, isDesktop, "This is not a desktop user");
	}

	@Test
	void iPhoneChrometest() {
    	String userAgent = "";
    	String httpAccept = "";
    	boolean isDesktop = true;
    	userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 12_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/92.0.4515.90 Mobile/15E148 Safari/604.1";
		httpAccept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
		UAgentInfo detector = new UAgentInfo(userAgent, httpAccept);
		isDesktop = !(detector.getIsMobilePhone());
		assertEquals(false, isDesktop, "This is not a desktop user");
	}

	@Test
	void Androidtest() {
    	String userAgent = "";
    	String httpAccept = "";
    	boolean isDesktop = true;
    	userAgent = "Mozilla/5.0 (Linux; Android 10; moto e) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.98 Mobile Safari/537.36";
		httpAccept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
		UAgentInfo detector = new UAgentInfo(userAgent, httpAccept);
		isDesktop = !(detector.getIsMobilePhone());
		assertEquals(false, isDesktop, "This is not a desktop user");
	}

	@Test
	void DesktopChrometest() {
    	String userAgent = "";
    	String httpAccept = "";
    	boolean isDesktop = true;
    	userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36";
		httpAccept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
		UAgentInfo detector = new UAgentInfo(userAgent, httpAccept);
		isDesktop = !(detector.getIsMobilePhone());
		assertEquals(true, isDesktop, "This is a desktop user");
	}

}
