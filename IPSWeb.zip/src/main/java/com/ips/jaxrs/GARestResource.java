package com.ips.jaxrs;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.service.CustRegService;
import com.usps.entreg.filter.data.EntRegSSOToken;
import com.usps.net2x.entreg.data.EntRegAccount;

@Path("analytics")
public class GARestResource extends SpringBeanAutowiringSupport implements Serializable{
    
    private static final long serialVersionUID = 1L; 
    
    @Autowired
    private CustRegService custRegService;    
    
    @GET
    @Path("/getGACustRegData")  
    @Produces(MediaType.APPLICATION_JSON)
    public IPSGAProofingDataResponse getGACustRegData(@Context HttpServletRequest httpServletRequest) {    
        
        String eRegUserId = "";    
        
        EntRegSSOToken entRegSSOToken = (EntRegSSOToken) httpServletRequest.getAttribute(EntRegSSOToken.REQUEST_KEY);

        if (entRegSSOToken != null) {
            if (entRegSSOToken.isNewUserLoggedIn()) {
                eRegUserId = entRegSSOToken.getUserId();
                CustomLogger.debug(this.getClass(), "entRegSSOToken.isNewUserLoggedIn() == true ...");
            } else if (entRegSSOToken.isExpired()) {
                CustomLogger.debug(this.getClass(), "entRegSSOToken.isExpired() == true ...");
            } else {
                eRegUserId = entRegSSOToken.getUserId();
                CustomLogger.debug(this.getClass(), "all else  entRegSSOTokens ... eRegUserId ... " + eRegUserId);
            }
        } else {
            CustomLogger.error(this.getClass(), "entRegSSOToken == null ... ");
            return getDefaults();  
        }    
        
        return getCustRegAccount(eRegUserId);        
    }
    
    private IPSGAProofingDataResponse getCustRegAccount(String custRegUserId) {

        IPSGAProofingDataResponse ipsGaProofingDataResponse = new IPSGAProofingDataResponse();
        
        CustomLogger.debug(this.getClass(), "CustRegUserid is: " + custRegUserId);
 
        String accountTypeDescription = "";
        String zipCode = "";
        
        if (custRegUserId == null || "".equalsIgnoreCase(custRegUserId.trim())) {         
            return getDefaults(); 
        }

        EntRegAccount entRegAccount = custRegService.fetchAccount(custRegUserId);
        
        if (entRegAccount == null) { 
            return getDefaults();
        } else {
        
            ipsGaProofingDataResponse.setCustomerId(custRegUserId);        
            ipsGaProofingDataResponse.setAccountStartDate(DateTimeUtil.hyphenateyyyyddMMDateString(entRegAccount.getAccountInfo().getRegistrationDate()));
                        
            // Account type
            String accountTypeCode = entRegAccount.getAccountType().trim();
            if (accountTypeCode == null || "".equalsIgnoreCase(accountTypeCode)) {
                accountTypeDescription = "Unknown";
            } else if ("0".equalsIgnoreCase(accountTypeCode)) {
                accountTypeDescription = "Business";
            } else if ("1".equalsIgnoreCase(accountTypeCode)) {
                accountTypeDescription = "Personal"; 
            }
            ipsGaProofingDataResponse.setAccountType(accountTypeDescription);
    
            // Zip Code
            zipCode = entRegAccount.getAddress().getPostalCode();    
            if (zipCode == null || "".equalsIgnoreCase(zipCode.trim()) || zipCode.length() < 5) {
                zipCode = "00000";
            } else {
                zipCode = zipCode.substring(0, 5);
            }
            ipsGaProofingDataResponse.setAccountZip(zipCode);        
        
        }
        return ipsGaProofingDataResponse;
    }
    
    private IPSGAProofingDataResponse getDefaults() {    
        IPSGAProofingDataResponse ipsGaProofingDataResponse = new IPSGAProofingDataResponse(); 
        ipsGaProofingDataResponse.setCustomerId("0000000000");
        ipsGaProofingDataResponse.setAccountStartDate("1970-01-01"); 
        ipsGaProofingDataResponse.setAccountType("Unknown");
        ipsGaProofingDataResponse.setAccountZip("00000");            
        return ipsGaProofingDataResponse; 
    }
}
