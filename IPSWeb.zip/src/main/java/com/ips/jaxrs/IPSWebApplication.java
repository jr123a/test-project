package com.ips.jaxrs;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.ibm.websphere.jaxrs.providers.json4j.JSON4JObjectProvider;
import com.ips.common.common.CustomLogger;

@ApplicationPath("resources")
public class IPSWebApplication extends Application implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<Class<?>>();
        classes.add(JSON4JObjectProvider.class);
        classes.add(GARestResource.class);
        // web services for in person proofing and authenticateLDAPUser and getProperties
        classes.add(IPSRestResource.class);
        // web service for sending SSA IPP Agency Report
        classes.add(ReportRestResource.class);        
        classes.add(RssRestResource.class);
        CustomLogger.debug(this.getClass(), "REST Classes:"+classes);
        return classes;
    }
}
