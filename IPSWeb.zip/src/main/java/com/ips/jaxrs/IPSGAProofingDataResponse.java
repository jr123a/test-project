package com.ips.jaxrs;



public class IPSGAProofingDataResponse extends IPSResponse {
    private static final long serialVersionUID = 1L;

    protected String customerId; 
    protected String accountStartDate; 
    protected String accountZip;   
    protected String accountType;    

    public IPSGAProofingDataResponse() {
        super();
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getAccountStartDate() {
        return accountStartDate;
    }

    public void setAccountStartDate(String accountStartDate) {
        this.accountStartDate = accountStartDate;
    }

    public String getAccountZip() {
        return accountZip;
    }

    public void setAccountZip(String accountZip) {
        this.accountZip = accountZip;
    } 
    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    } 
}
