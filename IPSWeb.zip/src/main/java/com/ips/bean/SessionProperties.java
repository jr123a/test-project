package com.ips.bean;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import com.ips.common.common.CustomLogger;

/*
 * removed @Local annotation for class to work in WebSphere, this will need to be readded when migrated to Wildfly
 */
@Singleton
@Startup
public class SessionProperties implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private Properties properties;
    private static String propertiesResource = "ips.properties";
    
    @PostConstruct
    public void init() {
        CustomLogger.enter(this.getClass());
        
        if (properties == null) {
            properties = new Properties();
            
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            try (InputStream resourceStream = loader.getResourceAsStream(propertiesResource)) {
                properties.load(resourceStream);
                CustomLogger.debug(this.getClass(), "Loaded application properties");
            } catch (IOException e1) {
                CustomLogger.error(this.getClass(), "Error while loading application properties", e1);
            }
        }
    }
    
    public String getProperty(String key) {
        return properties.getProperty(key);
    }
}
