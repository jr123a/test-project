package com.ips.bean;

import java.io.Serializable;
import java.text.SimpleDateFormat;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.UserVo;
import com.ips.common.common.CustomLogger;
import com.ips.polocator.common.AppointmentVo;

@ManagedBean(name="schedule_confirmed")
@ViewScoped
public class ScheduleConfirmedBean extends IPSController implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private AppointmentVo appointment;
    private String scheduledDate;
    private String scheduledTime;
    private String email;
    private UserVo user;
    
    @PostConstruct
    public void init(){
        // Handle login in after page refresh
        verifyUserSessionData();
                
        appointment = getSessionAppointment();
        user = getSessionUser();
        
        if (appointment != null && user != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
            scheduledDate = sdf.format(appointment.getScheduledDate());
            scheduledTime = appointment.getScheduledTime();
            email = user.getEmail();
        }
    }
    
    /**
     * Put this in a separate method rather than init so that the routing to the 
     * System error page will work.
     */
    public void checkForObjects() {
        if(appointment == null || user == null){
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Cannot load appointment info");
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }

    public AppointmentVo getAppointment() {
        return appointment;
    }

    public void setAppointment(AppointmentVo appointment) {
        this.appointment = appointment;
    }

    public String getScheduledDate() {
        return scheduledDate;
    }

    public void setScheduledDate(String scheduledDate) {
        this.scheduledDate = scheduledDate;
    }

    public String getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(String scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public UserVo getUser() {
        return user;
    }

    public void setUser(UserVo user) {
        this.user = user;
    }
}
