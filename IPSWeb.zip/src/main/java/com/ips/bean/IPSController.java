package com.ips.bean;


import java.io.IOException;
import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.JSFUtils;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.IvsAdminUser;
import com.ips.entity.Person;
import com.ips.entity.PersonData;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefOtpVelocity;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpEvent;
import com.ips.persistence.common.DeviceAssessmentParamVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.UserVo;
import com.ips.polocator.common.AppointmentVo;
import com.ips.proofing.ProofingService;
import com.ips.service.DeviceReputationService;
import com.ips.service.HighRiskAddressService;
import com.ips.service.PersonDataDataService;
import com.ips.service.PersonDataService;
import com.ips.service.PersonProofingStatusService;
import com.ips.service.RefOtpSupplierDataService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;
import com.ips.service.RpEventDataService;
import com.usps.entreg.filter.data.EntRegSSOToken;

public class IPSController implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**PAGES **/
    protected static final String ADDRESS_CONFIRMATION_PAGE = "address_confirmation.xhtml";
    protected static final String ADDRESS_CONFIRMATION_NEXT_PAGE = "address_confirmation_next.xhtml";
    protected static final String ALTERNATE_ADDRESS_PAGE = "alternate_address.xhtml";
    protected static final String CANCEL_APPOINTMENT_PAGE = "appointment_cancel.xhtml";
    protected static final String APPOINTMENT_CONFIRMATION_PAGE = "appointment_confirmation.xhtml";
    protected static final String FACILITY_CORRECTION_PAGE = "correct_facility_admin.xhtml";
    protected static final String ADMIN_PAGE = "home.xhtml";
    protected static final String IN_PERSON_PROOFING_PAGE = "in_person_proofing.xhtml";
    protected static final String INELIGIBLE_ADDRESS_PAGE = "ineligible_address.xhtml";
    protected static final String IPP_FACILITIES_ADMIN_PAGE = "ipp_facilities_admin.xhtml";
    protected static final String IPP_ADD_USPS_LOCATION_PAGE = "ipp_facilities_admin2.xhtml";
    protected static final String ADMIN_LOGIN_PAGE = "login.xhtml";
    protected static final String LOA15_PAGE = "registration.xhtml";
    protected static final String RETAIL_ONLY_OPTION_PAGE = "retail_only_option.xhtml";
    protected static final String ROUTING_PAGE = "routing.xhtml";
    protected static final String SCHEDULE_APPOINTMENT_PAGE = "schedule_appointment.xhtml";
    protected static final String SCHEDULE_CONFIRMED_PAGE = "schedule_confirmed.xhtml";
    protected static final String SYSTEM_ERROR_PAGE = "systemError.xhtml";
    protected static final String TERMS_AND_CONDITIONS_PAGE = "terms_and_conditions.xhtml";
    protected static final String UNABLE_TO_VERIFY_PAGE = "unable_to_verify.xhtml";
    protected static final String VERIFICATION_CANCEL = "verification_cancel.xhtml";
    protected static final String VERIFICATION_ALTERNATIVES_PAGE = "verification_alternatives.xhtml";
    protected static final String VERIFICATION_CANCEL_CONFIRMED = "verification_cancel_confirmed.xhtml";
    protected static final String VERIFICATION_CANCEL_REQUEST = "verification_cancel_request.xhtml";
    protected static final String VERIFICATION_DEVICE_REPUTATION = "verification_device_reputation.xhtml";
    protected static final String VERIFICATION_ENTER_PASSCODE_PAGE = "verification_enter_passcode.xhtml";
    protected static final String VERIFICATION_ENTER_PASSCODE_HM_PAGE = "verification_enter_passcode_hm.xhtml";
    protected static final String VERIFICATION_ERROR_PAGE = "verification_error.xhtml";
    protected static final String VERIFICATION_FAILURE_PAGE = "verification_failure.xhtml";
    protected static final String VERIFICATION_IN_PERSON_PAGE = "verification_in_person.xhtml";
    protected static final String VERIFICATION_LEARN_MORE = "verification_learn_more.xhtml";
    protected static final String VERIFICATION_LOCKOUT = "verification_lockout.xhtml";
    protected static final String VERIFICATION_REQUEST_PASSCODE_PAGE = "verification_request_passcode.xhtml";
    protected static final String VERIFICATION_SEND_SMFA_PAGE = "verification_send_smfa.xhtml";
    protected static final String VERIFICATION_SEND_OTP_PAGE = "verification_send_otp.xhtml";
    protected static final String VERIFICATION_SILENT_AUTHENTICATION_PAGE = "verification_silent_authentication.xhtml";
    protected static final String VERIFICATION_STATUS_PAGE = "verification_status.xhtml";
    protected static final String VERIFICATION_SUCCESSFUL_PAGE = "verification_successful.xhtml";
    protected static final String VERIFICATION_TMX_PROFILING_PAGE = "verification_tmx_profiling.xhtml";
    protected static final String VERIFICATION_USER_INFO_PAGE = "verification_user_information.xhtml";
    protected static final String VERIFICATION_USER_INFO_HM_PAGE = "verification_user_information_hm.xhtml";
    protected static final String VERIFICATION_URL_INVOCATION_PAGE = "verification_url_invocation.xhtml";
    protected static final String VERIFICATION_VALIDATE_SMFA_PAGE = "verification_validate_smfa.xhtml";
    protected static final String VERIFICATION_VALIDATE_SMFA_GREEN_PAGE = "verification_validate_smfa_green.xhtml";
    protected static final String VERIFICATION_VALIDATE_SMFA_RED_PAGE = "verification_validate_smfa_red.xhtml";

    /**STRING CONSTANTS **/  
    protected static final String HOLD_MAIL = "HoldMail";
    protected static final String LOA15_REDIRECTION = "?LOA=1.5";   
    protected static final String REMOTE_CALL = "remote_call";
    protected static final String RETRY_LOGOUT = "com.usps.custreg.LOGOUT";
    protected static final String VERIFICATION_CANCEL_REQUEST_DESTINATION = "com.usps.ips.CANCEL_REQUEST_DESTINATION";
    protected static final String VERIFICATION_LEARN_MORE_DESTINATION = "com.usps.ips.LEARN_MORE_DESTINATION";
    protected static final String ROUTING_TO_PAGE_INFO_FORMAT = "Routing to %s page for sponsorUserId:%s with status code: %s with status: %s";
  
    protected static final String LOCATIONS_ADDED = "locsAdded";
    protected static final String ALL_LOCATIONS_ADDED = "allLocsAdded";
    protected static final String PASSCODE_EXPIRED_CODE = "code-expired";
    protected static final String CODE_INVALID = "code-invalid"; 
    protected static final String CODE_EXCEEDS_LIMIT = "code-limit";    
    
    private static final String ALLOWED_DOMAIN = "com.ips.allowedDomains";
    private static final String SERVER_NAME_MYPC = "mypc.usps.com"; 
    private static final String SERVER_NAME_LOCALHOST = "localhost";

    /**SERVICES **/
    protected static final String COMMON_REST_SERVICE = "commonRestService";
    protected static final String CUST_REG_SERVICE = "CustRegService";
    protected static final String DEVICE_REPUTATION_SERVICE = "deviceReputationService";
    protected static final String EMAILER = "emailer";
    protected static final String EQUIFAX_DATA_SERVICE = "equifaxDataService";
    protected static final String EQUIFAX_SERVICE = "equifaxService";
    protected static final String HIGH_RISK_ADDRESS_SERVICE = "highRiskAddressService";
    protected static final String IPP_EVENT_SERVICE = "ippEventService";
    protected static final String OTP_ATTEMPT_CONFIG_SERVICE = "otpAttemptConfigService";
    protected static final String OTP_LOCKOUT_INFO_SERVICE = "otpLockoutInfoService";
    protected static final String OTP_VELOCITY_CHECK_SERVICE = "otpVelocityCheckService";
    protected static final String PERSON_DATA_DATA_SERVICE = "personDataDataService";
    protected static final String PERSON_DATA_SERVICE = "personDataService";
    protected static final String PERSON_PROOFING_STATUS_SERVICE = "personProofingStatusService";
    protected static final String PHONE_VERIFICATION_SERVICE = "phoneVerificationService";
    protected static final String PROOFING_SERVICE = "ProofingService";
    protected static final String REF_LOA_LEVEL_SERVICE = "refLoaLevelService";
    protected static final String REF_OTP_SUPPLIER_DATA_SERVICE = "refOtpSupplierDataService";
    protected static final String REF_RP_STATUS_DATA_SERVICE = "refRpStatusDataService";
    protected static final String REF_SPONSOR_CNFIG_SERVICE = "refSponsorConfigurationService";
    protected static final String REF_SPONSOR_DATA_SERVICE = "RefSponsorDataService";
    protected static final String REF_STATE_SERVICE = "refStateService";
    protected static final String RP_DEVICE_REPUTATION_SERVICE = "rpDeviceReputationService";
    protected static final String RP_DIT_RESPONSE_SERVICE = "rpDitResponseService";
    protected static final String RP_EFX_DIT_DETAILS_SERVICE = "rpEfxDitDetailsService";
    protected static final String RP_EVENT_SERVICE = "rpEventService";
    protected static final String RP_EXPERIAN_DECISION_RESULT_SERVICE = "rpExperianDecisionResultService";
    protected static final String RP_EXPERIAN_RESPONSE_PAYLOAD_SERVICE = "rpExperianResponsePayloadService";
    protected static final String RP_LEXISNEXIS_RESULT_SERVICE = "rpLexisNexisResultService";
    protected static final String RP_SMFA_INITIATE_RESP_SERVICE = "rpSmfaInitiateResponseService";
    protected static final String SMFA_VELOCITY_CHECK_SERVICE = "smfaVelocityCheckService";
    protected static final String SPONSOR_INCOMING_REQUESTS_SERVICE= "sponsorIncomingRequestsService";
    protected static final String VERIFICATION_PROVIDER_SERVICE = "verificationProviderService";
    protected static final String VERIFY_ADDRESS_SERVICE = "VerifyAddressService";
     
    private static String allowedDomain = null;
    protected ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
    protected HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
    protected String callingAppName = (String) request.getSession().getAttribute(IPSConstants.CALLING_APP_NAME_KEY);
    protected boolean isHoldMail = IPSConstants.HOLD_MAIL.equalsIgnoreCase(callingAppName);
    protected String callingAppURL = (String) request.getSession().getAttribute(IPSConstants.CALLING_APP_URL_KEY);
    //LexisNexisCurrentResidencyCheck is decision from LexisNexis residency check true = passed, and false  = failed
    protected boolean passedLexisNexisCurrentResidencyCheck = true;
    protected boolean submitAttemptsMismatched;
    protected boolean submitAttemptsExceeded;
    protected boolean renewAttemptsExceeded;
    protected boolean passcodeExpired;
    protected boolean transactionKeyHasExpired;
    protected boolean error; 
    protected String errorMessage = "";
 	private String unableToVerifyRegularPhoneMsg;
 	private String unableToVerifyLandlinePhoneMsg;

    static {
            allowedDomain = Utils.getProperty(ALLOWED_DOMAIN);
    }
    
    public void logout() {
        destroySession();
        
        String url = Utils.getProperty(RETRY_LOGOUT);
        if (url == null) {
            goToPage(SYSTEM_ERROR_PAGE);
        } else {
            try {
            	FacesContext.getCurrentInstance().getExternalContext().redirect(url);
            } catch (IOException e) {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred redirecting to logout page: " + url, e);
                goToPage(SYSTEM_ERROR_PAGE);
            }
        }
    }
    
    
    private void destroySession() {
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        session.invalidate();
    }


    protected void goToPage(String nextPage) {
        String nextPageUrl = null;
        
        try {
            if (SYSTEM_ERROR_PAGE.equalsIgnoreCase(nextPage) && isHoldMail) {
                CustomLogger.debug(this.getClass(), "System out error occured, return to callingApp, Calling app is " + callingAppName);
                returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
            } else {
            	redirectToPage(nextPage);
            }
        } catch (Exception ex) {
            CustomLogger.error(this.getClass(), "Could not redirect to page: " + nextPageUrl, ex);
            redirectToPage(UNABLE_TO_VERIFY_PAGE);
        }
    }
    
    protected void manageGotoPage(String goToPageString, String logMsg) {
        if(isHoldMail) {
            CustomLogger.info(this.getClass(), String.format("%s Return to callingApp: %s", logMsg, callingAppName));
            returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        }else {
            CustomLogger.info(this.getClass(), logMsg);
            goToPage(goToPageString);
        }
    }
    
    protected void redirectToPage(String nextPage) {
    	try {
	        String nextPageUrl = null;
	        nextPageUrl = getHttpServletRequest().getContextPath() + "/" + nextPage;
	        HttpSession session = getHttpServletRequest().getSession();
	       	session.setAttribute(IPSConstants.REDIRECT_PAGE_URL_KEY, nextPageUrl);
	
	        CustomLogger.debug(this.getClass(), "goToPage() page=" + nextPageUrl);
	        FacesContext.getCurrentInstance().getExternalContext().redirect(nextPageUrl);
    	} catch (Exception ex) {
             CustomLogger.error(this.getClass(), "Could not redirect to page: " + nextPage, ex);
        }
    }
    
    public UserVo getSessionUser(){
        HttpSession session = getHttpServletRequest().getSession();
        return (UserVo) session.getAttribute(IPSConstants.USER_KEY);
    }
    
    public void setSessionUser(UserVo user){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.USER_KEY, user);
    }
    
    public void setSessionPersonVo(PersonVo personVo){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.PERSON_KEY, personVo);
    }
    
    public PersonVo getSessionPersonVo(){
        HttpSession session = getHttpServletRequest().getSession();
        return (PersonVo) session.getAttribute(IPSConstants.PERSON_KEY);
    }
    
    public void setSessionAppointment(AppointmentVo appointmentVo){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.APPOINTMENT_KEY, appointmentVo);
    }
    
    public AppointmentVo getSessionAppointment(){
        HttpSession session = getHttpServletRequest().getSession();
        return (AppointmentVo) session.getAttribute(IPSConstants.APPOINTMENT_KEY);
    }
    
    public void setSessionFilteredPOList(List<Object> filteredPOList){
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        session.setAttribute(IPSConstants.FILTERED_PO_LIST_KEY, filteredPOList);
    }
    
    @SuppressWarnings("unchecked")
    public List<Object> getSessionFilteredPOList(){
        HttpSession session = getHttpServletRequest().getSession();
        return (List<Object>) session.getAttribute(IPSConstants.FILTERED_PO_LIST_KEY);
    }
    
    public void setSessionLocsAdded(boolean locationsAdded){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(LOCATIONS_ADDED, locationsAdded);
    }    
    
    public void setSessionAllLocsAdded(boolean allLocationsAdded){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(ALL_LOCATIONS_ADDED, allLocationsAdded);
    }
    
    public IvsAdminUser getSessionAdminUser() {
        HttpSession session = getHttpServletRequest().getSession();
        return (IvsAdminUser) session.getAttribute(IPSConstants.ADMIN_USER_KEY);
    }
    
    public void setSessionAdminUser(IvsAdminUser user){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.ADMIN_USER_KEY, user);
    }
    
    public String getSessionCallingApp() {
        HttpSession session = getHttpServletRequest().getSession();
        return (String) session.getAttribute(IPSConstants.CALLING_APP_URL_KEY);
    }
    
    public void setSessionCallingApp(String callingApp){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.CALLING_APP_URL_KEY, callingApp);
    }

    public String getSessionCallingAppName() {
        HttpSession session = getHttpServletRequest().getSession();
        return (String) session.getAttribute(IPSConstants.CALLING_APP_NAME_KEY);
    }
    
    public void setSessionCallingAppName(String callingAppName){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.CALLING_APP_NAME_KEY, callingAppName);
    }
    
    public void setSessionDeviceProfilingEnabled(boolean deviceProfilingEnabled){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.DEV_PROFILING_ENABLED_KEY, deviceProfilingEnabled);
    }
    
    public boolean getSessionDeviceProfilingEnabled(){
        HttpSession session = getHttpServletRequest().getSession();
        return (boolean) session.getAttribute(IPSConstants.DEV_PROFILING_ENABLED_KEY);
    }
    
    public void setSessionDeviceProfilingSessionId(String deviceProfilingSessionId){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.DEV_PROFILING_SESSIONID_KEY, deviceProfilingSessionId);
    }
    
    public String getSessionDeviceProfilingSessionId(){
        HttpSession session = getHttpServletRequest().getSession();
        return (String) session.getAttribute(IPSConstants.DEV_PROFILING_SESSIONID_KEY);
    }
    
    public void setSessionCustomerIpAddress(String customerIpAddress){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.DEV_CUSTOMER_IP_ADDRESS_KEY, customerIpAddress);
    }
    
    public String getSessionCustomerIpAddress(){
        HttpSession session = getHttpServletRequest().getSession();
        return (String) session.getAttribute(IPSConstants.DEV_CUSTOMER_IP_ADDRESS_KEY);
    }
    
    public void setSessionVerifyPhoneError(String errorMessage){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.VERIFY_PHONE_ERROR_KEY, errorMessage);
    }
    
    public String getSessionVerifyPhoneError(){
        HttpSession session = getHttpServletRequest().getSession();
        return (String) session.getAttribute(IPSConstants.VERIFY_PHONE_ERROR_KEY);
    }
    
    public void setSessionOtpSmfaAttempts(int otpSmfaAttempts){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.OTP_SMFA_ATTEMPTS_KEY, otpSmfaAttempts);
    }
    
    public int getSessionOtpSmfaAttempts(){
        HttpSession session = getHttpServletRequest().getSession();
        if (session.getAttribute(IPSConstants.OTP_SMFA_ATTEMPTS_KEY) == null) {
        	return 0;
        }
        return (int) session.getAttribute(IPSConstants.OTP_SMFA_ATTEMPTS_KEY);
    }
    
    public DeviceAssessmentParamVo getSessionDeviceAssessmentParamVo() {
        HttpSession session = getHttpServletRequest().getSession();
        return (DeviceAssessmentParamVo) session.getAttribute(IPSConstants.DEVICE_ASSESSMT_PARAM_VO);
    }
    
    public void setSessionDeviceAssessmentParamVo(DeviceAssessmentParamVo assessmentParamVo){
        HttpSession session = getHttpServletRequest().getSession();
        session.setAttribute(IPSConstants.DEVICE_ASSESSMT_PARAM_VO, assessmentParamVo);
    }
    
    /**
     * This method routes the user to the correct page when they enter the application based on their
     * proofing status.
     * @param user
     */
    public void routeUser(UserVo user){
        String nextPage = getNextPage(user);

        if(REMOTE_CALL.equalsIgnoreCase(nextPage)){
            returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        } else {
            goToPage(nextPage);
        }
    }
    
    private String getNextPage(UserVo user) {
        String status = null;
        String page = null;
        long statusCode = user.getStatusCode();
        String sponsorUserId = user.getSponsorUserId();

        if (user.getStatus() == null) {
            return SYSTEM_ERROR_PAGE;
        }

        status = user.getStatus();
        
        PersonVo personVo = getSessionPersonVo();

        if (personVo != null) {
	       	PersonProofingStatusService personProofingStatusService = (PersonProofingStatusService)SpringUtil.getInstance(ctx).getBean(PERSON_PROOFING_STATUS_SERVICE);
	        PersonProofingStatus personProofingStatus  = personProofingStatusService.getByPersonId((int)personVo.getId());
	        
    		if (personProofingStatus.getRefRpStatus().getStatusDescription() != user.getStatus() || personProofingStatus.getRefRpStatus().getStatusCode() != user.getStatusCode()) {
    			ProofingService proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
    			PersonDataService personDataService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
    	        Person existingPerson = personDataService.findExistingPerson(RefSponsor.SPONSOR_ID_CUSTREG, user.getSponsorUserId());

    	        if (existingPerson != null) {
    	        	proofingService.updateProofingStatus(user.getStatusCode(), existingPerson, user.getLoaSought());
    	        }
    		}
        }


        if (statusCode != 0L) {
            page = checkOTPStatusCode(user, status, statusCode, sponsorUserId);
            if (!page.isEmpty()) {
                return page;
            }
        }
        
        // old logic starts here 12/7/2018
        if (IPSConstants.STATUS_NEW_TO_IPS.equalsIgnoreCase(status)
                || IPSConstants.STATUS_RP_FAILED.equalsIgnoreCase(status)
                || IPSConstants.STATUS_RP_CANCELLED.equalsIgnoreCase(status)
                || IPSConstants.STATUS_REPROOFING.equalsIgnoreCase(status)) {

            // for a new user, pull the name from the PersonVo
            if (StringUtils.isEmpty(user.getLastName())) {
                user.setFirstName(personVo.getFirstName());
                user.setLastName(personVo.getLastName());
            }
            
            if (personVo != null) {
				// This handles creating the person and person_data record as well as the proofing session
	            ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
	            ProofingService proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
	            PersonDataService personDataService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);

				try {
					Person person = personDataService.findByPK(personVo.getId());
					proofingService.startProofingSession(person, personVo);
				} catch (Exception e) {
			        CustomLogger.error(this.getClass(), "Error occurred in starting proofing session", e);
			        goToPage(SYSTEM_ERROR_PAGE);
				}
            }

            CustomLogger.info(this.getClass(),
                    String.format(ROUTING_TO_PAGE_INFO_FORMAT, "verification", sponsorUserId, statusCode, status));

            String userInfoPage = VERIFICATION_USER_INFO_PAGE;
            if (IPSConstants.STATUS_NEW_TO_IPS.equalsIgnoreCase(status)
                 || IPSConstants.STATUS_REPROOFING.equalsIgnoreCase(status)) {
            	userInfoPage = VERIFICATION_TMX_PROFILING_PAGE;
            }

            return isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : userInfoPage;
        }

        if (IPSConstants.STATUS_IPP_OPT_IN.equalsIgnoreCase(status)
                || IPSConstants.STATUS_IPP_EMAIL_SENT.equalsIgnoreCase(status)) {
            CustomLogger.debug(this.getClass(), String.format(ROUTING_TO_PAGE_INFO_FORMAT, "in_person_proofing",
                    sponsorUserId, statusCode, status));
            return IN_PERSON_PROOFING_PAGE;
        }

        if (IPSConstants.STATUS_IPP_FAILED.equalsIgnoreCase(status)) {
            CustomLogger.info(this.getClass(), String.format(ROUTING_TO_PAGE_INFO_FORMAT, "verification_failure",
                    sponsorUserId, statusCode, status));
            return VERIFICATION_FAILURE_PAGE;
        }

        if (IPSConstants.IPP_RESIDENCE_SCHEDULED.equalsIgnoreCase(status)) {
            // Retrieve appointment data
            ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
            ProofingService proofingService = (ProofingService) SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
            AppointmentVo apptVo = proofingService.findScheduledAppointment(user);
            setSessionAppointment(apptVo);

            // if scheduled appointment date is in the past, go to the Unable to Verify
            // identity page
            Date currentDate = DateTimeUtil.getCurrentDate();

            CustomLogger.debug(this.getClass(), "current date is " + currentDate);
            CustomLogger.debug(this.getClass(), "scheduled date is " + apptVo.getScheduledDate());

            if (apptVo.getScheduledDate().before(currentDate)) {
                CustomLogger.info(this.getClass(),
                        "Appointment scheduled for a past date. " + String.format(ROUTING_TO_PAGE_INFO_FORMAT,
                                "Unable to Verify Identity", sponsorUserId, statusCode, status));
                return VERIFICATION_ERROR_PAGE;
            } else {
                CustomLogger.debug(this.getClass(), String.format(ROUTING_TO_PAGE_INFO_FORMAT,
                        "appointment_confirmation", sponsorUserId, statusCode, status));
                return APPOINTMENT_CONFIRMATION_PAGE;
            }
        }

        if (IPSConstants.IPP_RESIDENCE_OPT_IN.equalsIgnoreCase(status)) {
            CustomLogger.debug(this.getClass(), String.format(ROUTING_TO_PAGE_INFO_FORMAT, "address_confirmation",
                    sponsorUserId, statusCode, status));
            ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
            ProofingService proofingService = (ProofingService) SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
            AppointmentVo apptVo = proofingService.findAddressOnFile(user);
            setSessionAppointment(apptVo);
            return ADDRESS_CONFIRMATION_PAGE;
        }

        if (IPSConstants.STATUS_ERROR.equalsIgnoreCase(status)) {
            CustomLogger.info(this.getClass(),
                    String.format(ROUTING_TO_PAGE_INFO_FORMAT, "system error", sponsorUserId, statusCode, status));
            return SYSTEM_ERROR_PAGE;
        }

        CustomLogger.debug(this.getClass(), "DEFAULT: "
                + String.format(ROUTING_TO_PAGE_INFO_FORMAT, "verification", sponsorUserId, statusCode, status));
       
        return isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : VERIFICATION_TMX_PROFILING_PAGE;
   }

    private String checkOTPStatusCode(UserVo user, String status, long statusCode, String sponsorUserId) {
        ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        DeviceReputationService deviceReputationService = (DeviceReputationService)SpringUtil.getInstance(ctx).getBean(DEVICE_REPUTATION_SERVICE);
        RpEventDataService rpEventDataService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        
       setSessionVerifyPhoneError(null);
       
        if (statusCode == RefRpStatus.RpStatus.Phone_verification_initiated.getValue()
                || statusCode == RefRpStatus.RpStatus.Phone_verification_failed.getValue()) {
        	boolean hasPassedPhoneVelocityCheck = hasPassedPhoneVelocityCheck(user);
            if (hasPassedPhoneVelocityCheck) {
            	
                CustomLogger.debug(this.getClass(), String.format(ROUTING_TO_PAGE_INFO_FORMAT, "verification_user_info", sponsorUserId, statusCode, status));
                
                return isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : VERIFICATION_USER_INFO_PAGE;
            }
            
            CustomLogger.info(this.getClass(), String.format(ROUTING_TO_PAGE_INFO_FORMAT, "verification_lockout", sponsorUserId, statusCode, status));
        
            if(isHoldMail) {
                return REMOTE_CALL;
            }else {
                return VERIFICATION_LOCKOUT;
            }
        }
        
        if (statusCode == RefRpStatus.RpStatus.Phone_verified.getValue()
                || statusCode == RefRpStatus.RpStatus.OTP_initiated.getValue()) {
            // Check for High Risk address or Low Device Reputation before continuing verification process
            if (isHighRiskAddress(getSessionPersonVo()) || deviceReputationService.isLowDeviceReputation(getSessionPersonVo())) {
                CustomLogger.info(this.getClass(), "Returning user: " + sponsorUserId + " now has high risk address");
                return UNABLE_TO_VERIFY_PAGE;
            }
            else {
                CustomLogger.debug(this.getClass(), String.format(ROUTING_TO_PAGE_INFO_FORMAT, "verification_request_passcode", sponsorUserId, statusCode, status));

                return VERIFICATION_REQUEST_PASSCODE_PAGE;
            }
        }
        
        if (statusCode == RefRpStatus.RpStatus.OTP_sent.getValue()
                || statusCode == RefRpStatus.RpStatus.OTP_confirmation_initiated.getValue()
                || statusCode == RefRpStatus.RpStatus.OTP_confirmation_failed.getValue()
                || statusCode == RefRpStatus.RpStatus.SMFA_initiated.getValue()
                || statusCode == RefRpStatus.RpStatus.SMFA_sent.getValue()
                || statusCode == RefRpStatus.RpStatus.SMFA_validation_initiated.getValue()
                || statusCode == RefRpStatus.RpStatus.SMFA_validation_failed.getValue()) {
            
            // Check for High Risk address or Low Device Reputation before continuing verification process
            if (isHighRiskAddress(getSessionPersonVo()) || deviceReputationService.isLowDeviceReputation(getSessionPersonVo())) {
                CustomLogger.info(this.getClass(), "Returning user: " + sponsorUserId + " now has high risk address");
                return UNABLE_TO_VERIFY_PAGE;
            }
            else {
                CustomLogger.debug(this.getClass(), String.format(ROUTING_TO_PAGE_INFO_FORMAT, "verification_enter_passcode", sponsorUserId, statusCode, status));
                
                // Ensure that message from SoapFaultException does not display
                ConfirmPasscodeBean confirmPasscode = JSFUtils.getManagedBean("confirmpasscode");
                confirmPasscode.clearError();
   
                if (statusCode == RefRpStatus.RpStatus.SMFA_initiated.getValue() 
                		|| statusCode == RefRpStatus.RpStatus.SMFA_sent.getValue()
                		|| statusCode == RefRpStatus.RpStatus.SMFA_validation_initiated.getValue()
                		|| statusCode == RefRpStatus.RpStatus.SMFA_validation_failed.getValue()) {
                	return VERIFICATION_SEND_SMFA_PAGE;
                }

                List<RpEvent> events = rpEventDataService.findEventBySponsorUserId(user.getSponsorUserId());
                
                if (!events.isEmpty() && events.get(0).getRefOtpSupplier().isExperianPhone()) {
                 	return VERIFICATION_REQUEST_PASSCODE_PAGE;
                }

                if (statusCode == RefRpStatus.RpStatus.OTP_confirmation_initiated.getValue()
                        || statusCode == RefRpStatus.RpStatus.OTP_confirmation_failed.getValue()) {
                        return VERIFICATION_REQUEST_PASSCODE_PAGE;
            	}
            }
        }
        else if (statusCode == RefRpStatus.RpStatus.LOA_level_achieved.getValue()) {
         	goToInformedDeliverySuccessPage();
        }
        return "";
    }
    
    /**
     * Determine if the customer's address is on the high-risk list.
     * @param addressHash
     * @return
     */
    private boolean isHighRiskAddress(PersonVo personVo) {
        ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        HighRiskAddressService riskService = (HighRiskAddressService)SpringUtil.getInstance(ctx).getBean(HIGH_RISK_ADDRESS_SERVICE);
        PersonDataDataService personDataService = (PersonDataDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_DATA_SERVICE);
        // Retrieve address_hash from person_data
        PersonData personData = personDataService.findByPK(personVo.getId());
        return riskService.highRiskAddressCheck(personData.getAddressHash(), personVo);
    }

    private boolean hasPassedPhoneVelocityCheck(UserVo user) {
        // Determine if user should go to the Phone OTP lockout page
        ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        RefOtpSupplierDataService supplierService = (RefOtpSupplierDataService)SpringUtil.getInstance(ctx).getBean(REF_OTP_SUPPLIER_DATA_SERVICE);
        PersonDataService personService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
        ProofingService proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
        RefSponsorDataService refSponsorService = (RefSponsorDataService)SpringUtil.getInstance(ctx).getBean(REF_SPONSOR_DATA_SERVICE);
        RpEventDataService rpEventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        RefOtpSupplier supplierId = supplierService.findBySupplierId(rpEventService.getLatestPhoneSupplier(getSessionPersonVo()).getOtpSupplierId());
        RefSponsor refSponsor = refSponsorService.findBySponsorName(IPSConstants.SPONSOR_CUSTREG);
      
        CustomLogger.debug(this.getClass(), "IPSController hasPassedPhoneVelocityCheck supplierId returned: " + supplierId.getOtpSupplierId());
        Person person = personService.findFirstBySponsor(refSponsor, user.getSponsorUserId());
        PersonVo personVo = new PersonVo();
        personVo.setProofingLevelSought(RefLoaLevel.LOA_15);
        // Velocity check for phone verification needs to be done before continuing with the Equifax call
        RefOtpVelocity refOtpVelocity = proofingService.phoneVelocityCheck(person, personVo, supplierId);
        
        personVo.addLogInfoMapEntry("isExceedPhoneVerificationLimit", String.valueOf(refOtpVelocity.isExceedPhoneVerificationLimit()));
        personVo.addLogInfoMapEntry("isLockoutStillInEffect", String.valueOf(refOtpVelocity.isLockoutStillInEffect()));
        
        return !refOtpVelocity.isExceedPhoneVerificationLimit() && !refOtpVelocity.isLockoutStillInEffect();
    }
    
    public void returnToCallingApp(String proofingStatus) {
        HttpSession session = getHttpServletRequest().getSession();

        callingAppURL = null;
        try {
            if (session != null) {
                callingAppURL = getSessionCallingApp();

                if (callingAppURL == null) {
                	goToLogin();
                } else if(isHoldMail) {
                        if(proofingStatus.equalsIgnoreCase(IPSConstants.PROOFING_RESULT_PASSED)) {
                            CustomLogger.info(this.getClass(), "returnToCallingApp() Hold Mail passed verification");
                            FacesContext.getCurrentInstance().getExternalContext().redirect(callingAppURL);
                         }else {
                            ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
                            RefSponsorConfigurationService refSponsorConfigService = (RefSponsorConfigurationService)SpringUtil.getInstance(ctx).getBean(REF_SPONSOR_CNFIG_SERVICE);    
                            RefSponsorConfiguration workFlowValue = refSponsorConfigService.getConfigRecord(1, RefSponsorConfiguration.HOLDMAIL_FLOW_FLAG);
                            if("True".equalsIgnoreCase(workFlowValue.getValue())) {
                                String returnURL = getFailureRedirectRegPage();
                                CustomLogger.info(this.getClass(), "returnToFailureRedirectRegPage() URL=" + returnURL);
                                FacesContext.getCurrentInstance().getExternalContext().redirect(returnURL);
                            }else {
                                callingAppURL = callingAppURL.replace("?ivsRedirect=true","?ivsRedirect=false"); 
                                CustomLogger.info(this.getClass(), "returnToCallingApp() URL=" + callingAppURL);
                                FacesContext.getCurrentInstance().getExternalContext().redirect(callingAppURL);
                            }
                        }
                } else if (isCallingAppAllowed(callingAppURL)) {
                    CustomLogger.info(this.getClass(), "returnToCallingApp() Informed Delivery passed verification > callingAppURL:" + callingAppURL );
                    if (isLocalServer()) {
                    	goToInformedDeliverySuccessPage();
                	}
                    else {
                     	FacesContext.getCurrentInstance().getExternalContext().redirect(callingAppURL);
                    }                  
                } else {
                    CustomLogger.info(this.getClass(), "Illegal appURL value: " + callingAppURL + " redirecting to allowed domain: " + allowedDomain);
                    FacesContext.getCurrentInstance().getExternalContext().redirect(allowedDomain);
                }
            }
        } catch (IOException e) {
             CustomLogger.error(this.getClass(), "Error occurred redirecting page", e);
             redirectToPage(SYSTEM_ERROR_PAGE);
        }
    }
    
    public void managePageRedirection(String goToPageString, String logMsg) {
        CustomLogger.enter(this.getClass());
        
        if(isHoldMail) {
            CustomLogger.info(this.getClass(), String.format("%s Return to callingApp: %s", logMsg, callingAppName));
            returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        }else {
            CustomLogger.info(this.getClass(), logMsg);
            try {
                if (SYSTEM_ERROR_PAGE.equalsIgnoreCase(goToPageString)) {
                    CustomLogger.debug(this.getClass(), "System out error occured, return to callingApp, Calling app is " + callingAppName);
                    returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
                } else {
                	goToPageString = getHttpServletRequest().getContextPath() + "/" + goToPageString;
                    HttpSession session = getHttpServletRequest().getSession();
                   	session.setAttribute(IPSConstants.REDIRECT_PAGE_URL_KEY, goToPageString);
                    FacesContext.getCurrentInstance().getExternalContext().redirect(goToPageString);
                }
            } catch (Exception ex) {
                CustomLogger.error(this.getClass(), "Could not redirect to page: " + goToPageString, ex);
                redirectToPage(SYSTEM_ERROR_PAGE);
            }
        }
    }

    public String getLockoutExpiresDateTimeDetail(Timestamp lockoutExpiresDatetime) {
        String formattedDate = DateTimeUtil.getDateString(lockoutExpiresDatetime, DateTimeUtil.FULL_MONTH_FORMAT);
        String formattedTime = DateTimeUtil.getDateString(lockoutExpiresDatetime, DateTimeUtil.TIME_FORMAT);
        return formattedDate + " at " + formattedTime;
    }
    
    public void goToPreferences() {
        CustomLogger.info(this.getClass(), "IPSController.goToPreferences()");
        String url = Utils.getProperty(IPSConstants.REG_PREF);
        if (url == null) {
            goToPage(SYSTEM_ERROR_PAGE);
        } else {
            try {
                CustomLogger.info(this.getClass(), "IPSController.goToPreferences() redirecting to " + url);
                FacesContext.getCurrentInstance().getExternalContext().redirect(url);
            } catch (IOException e) {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred redirecting to preferences page", e);
                goToPage(SYSTEM_ERROR_PAGE);
            }
            catch (Exception e) {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred redirecting to preferences page", e);
                goToPage(SYSTEM_ERROR_PAGE);
            }
        }
    }
    
    public void goToLogin() {
        CustomLogger.info(this.getClass(), "IPSController.goToLogin()");
        String url = Utils.getProperty(IPSConstants.REG_LOGIN);
        if (url == null) {
            goToPage(SYSTEM_ERROR_PAGE);
        } else {
            try {
                CustomLogger.info(this.getClass(), "IPSController.goToLogin() redirecting to " + url);
                FacesContext.getCurrentInstance().getExternalContext().redirect(url);
            } catch (IOException e) {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred redirecting to login page", e);
                goToPage(SYSTEM_ERROR_PAGE);
            }
            catch (Exception e) {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred redirecting to login page", e);
                goToPage(SYSTEM_ERROR_PAGE);
            }
        }
    }
    
    public void goToInformedDeliverySuccessPage() {
    	
    	String url = Utils.getProperty(IPSConstants.ID_SUCCESS_PAGE);
    	 
        if (url == null) {
             goToPage(SYSTEM_ERROR_PAGE);
        } else {
            try {
            	FacesContext.getCurrentInstance().getExternalContext().redirect(url);
            	return;
            } catch (IOException e) {
                 CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE 
                		 + "Error occurred redirecting to Informed Delivery SuccessPage",e);
                goToPage(SYSTEM_ERROR_PAGE);
            }
        }
    }

    public void goToCodeViaMailRegPage() {

        String url = Utils.getProperty(IPSConstants.CODE_VIA_MAIL_REG_PAGE);
        if (url == null) {
            goToPage(SYSTEM_ERROR_PAGE);
        } else {
            try {
            	FacesContext.getCurrentInstance().getExternalContext().redirect(url);
            } catch (IOException e) {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred redirecting to Code via mail Reg page",
                        e);
                goToPage(SYSTEM_ERROR_PAGE);
            }
        }
    }
    
    public String getFailureRedirectRegPage() {
        callingAppURL = callingAppURL.replace("?ivsRedirect=true", "");
        return Utils.getProperty(IPSConstants.FAILURE_REDIRECT_REG_PAGE) + "?app=" + callingAppName + "&appURL=" + callingAppURL ;
    }
    
    public void goToProfile() {
        
        String url = Utils.getProperty("com.usps.ips.CUSTREG_PROFILE_URL");
        if (url == null) {
            goToPage(SYSTEM_ERROR_PAGE);
        } else {
            try {
            	FacesContext.getCurrentInstance().getExternalContext().redirect(url);
            } catch (IOException e) {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred redirecting to preferences page", e);
                goToPage(SYSTEM_ERROR_PAGE);
            }
        }
    }
    
    protected String getClientIpAddress() {
        // Get IP from request header populated by CustReg
    	HttpServletRequest servletRequest = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        String clientIP = servletRequest.getHeader(IPSConstants.CLIENT_IP);
        CustomLogger.debug(this.getClass(), IPSConstants.CLIENT_IP + " = " + clientIP);

        if (StringUtils.isBlank(clientIP)) {
            clientIP = servletRequest.getHeader(IPSConstants.NS_CLIENT_IP);
            CustomLogger.debug(this.getClass(), IPSConstants.NS_CLIENT_IP + " = " + clientIP);

            // If CustReg header not populated get IP directly from client or last server that sent request
            if (StringUtils.isBlank(clientIP)) {
                clientIP = servletRequest.getRemoteAddr();
                CustomLogger.debug(this.getClass(), "IP address of the client or last proxy that sent the request = "    + clientIP);
            }
        }
        
        if (Utils.isValidIpAddress(clientIP)) {
            return clientIP;
        }
        else {
            CustomLogger.warn(this.getClass(), "WARNING: Invalid IP address found: " + clientIP);
            return "";
        }
    }
    
    public String getAppointmentCanceledMessage() {
        AppointmentVo appt = getSessionAppointment();
        SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd");
        String scheduledDate = sdf.format(appt.getScheduledDate());
        return "Your appointment for " + scheduledDate + " at " + appt.getScheduledTime() + " has been canceled.";
    }
    
    public boolean isAppointmentCanceled() {
        AppointmentVo appt = getSessionAppointment();
        if(appt != null){
            return appt.isCanceled();
        }
        return false; 
    }
    
    public void returnToVerificationError() {
        // Clear out velocity and other messages on the Unable to Verify Identity page
        goToPage(VERIFICATION_ERROR_PAGE);
    }
    
    /**
     * The refresh button does not trigger a ViewExpiredException so the session does not get
     * invalidated.  This method pulls the custRegUserId from session and, if it does not match
     * the current IVS user, redirects to the CustReg Preferences page.
     */
    public void verifyUserSessionData() {
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        
        String loggedInUserID = getLoggedInCustRegUserId();
        UserVo user = getSessionUser();

        // If the user IDs don't match, redirect to Preferences
        if (user == null) {
            CustomLogger.info(this.getClass(), "No user in session.  Session must have been invalidated. Redirecting user to Preferences page.");
            session.setAttribute(IPSConstants.USER_ID_KEY, loggedInUserID);
            goToLogin();
        } else if (!user.getSponsorUserId().equalsIgnoreCase(loggedInUserID)) {
            CustomLogger.info(this.getClass(), "Logged in user: " + loggedInUserID + " does not match session user: " + user.getSponsorUserId()
                    + ".  Redirecting user to Preferences page.");
            session.setAttribute(IPSConstants.USER_ID_KEY, loggedInUserID);
            goToLogin();
        }
    }
    
    public boolean userMatchesSession() {
        CustomLogger.enter(this.getClass());
        
        String loggedInUserID = getLoggedInCustRegUserId();
        UserVo user = getSessionUser();

        // If the user IDs don't match, redirect to Preferences
        if (user == null) {
            CustomLogger.info(this.getClass(), "No user in session.  Session must have been invalidated. Returning false.");
            return false;
        } else if (!user.getSponsorUserId().equalsIgnoreCase(loggedInUserID)) {
            CustomLogger.info(this.getClass(), "Logged in user: " + loggedInUserID + " does not match session user: " + user.getSponsorUserId()
                    + ".  Returning false.");
            return false;
        } else {
            return true;
        }
    }
    
    /**
     * Retrieves the custRegUserID of the currently logged in user.
     * @return
     */
    private String getLoggedInCustRegUserId() {
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        String userID = null;
        EntRegSSOToken entRegSSOToken = null;
        
        if(session != null){
            entRegSSOToken = (EntRegSSOToken) request.getAttribute(EntRegSSOToken.REQUEST_KEY);
        }
        
        if(entRegSSOToken != null)  {
            if(entRegSSOToken.isNewUserLoggedIn())  {
                // code to handle a user that logged out elsewhere and logged in as
                // a different user.  Typically, all data stored in session context
                // for the previous user needs to be cleaned up and initialization
                // done for the newly logged in user.
                userID = entRegSSOToken.getUserId();
            } else if(entRegSSOToken.isExpired()) {
                // code here to handle an expired session.  This should not happen
                // since the session filter should handle it.
            } else  {
                userID = entRegSSOToken.getUserId();
            }
        }
        else {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "entRegSSOToken is NULL");
            goToPage(SYSTEM_ERROR_PAGE);
        }

        if (userID == null)  {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "userID on session check is null");
            goToPage(SYSTEM_ERROR_PAGE);
        } 
        
        if (!Utils.isAlphanumeric(userID)) {
            CustomLogger.warn(this.getClass(), "WARNING: Invalid userID found in session" + userID);
        }
        
        return userID;
    }
    
    protected boolean isCallingAppAllowed(String callingApp) {
        return callingApp.startsWith(allowedDomain);
    }
    
    protected RefOtpSupplier getLatestPhoneSupplier() {
        ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        RpEventDataService eventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        // Retrieve the most recent event for the user to determine which supplier was called
        RefOtpSupplier phoneSupplier = null;
                
        List<RpEvent> events = eventService.findEventByPersonId(getSessionPersonVo().getId());
        if (!events.isEmpty()) {
            phoneSupplier = events.get(0).getRefOtpSupplier();
        }
        
        return phoneSupplier;
    }
    
    public boolean isLocalServer() {
		try {
			HttpServletRequest httpServletRequest = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		    String serverName = httpServletRequest.getServerName();
		    return serverName.contains(SERVER_NAME_MYPC) || serverName.contains(SERVER_NAME_LOCALHOST);
		} catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error occurred in checking local server", e);
			return false;
		}
	}
    
    public HttpServletResponse getHttpServletResponse() {
        return (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
    }

    public HttpServletRequest getHttpServletRequest() {
        return (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
    }
    
	public boolean isPassedLexisNexisCurrentResidencyCheck() {
		return passedLexisNexisCurrentResidencyCheck;
	}

	public void setPassedLexisNexisCurrentResidencyCheck(boolean passedLexisNexisCurrentResidencyCheck) {
		this.passedLexisNexisCurrentResidencyCheck = passedLexisNexisCurrentResidencyCheck;
	}
	
	public boolean isSubmitAttemptsMismatched() {
		return submitAttemptsMismatched;
	}


	public void setSubmitAttemptsMismatched(boolean submitAttemptsMismatched) {
		this.submitAttemptsMismatched = submitAttemptsMismatched;
	}


	public boolean isSubmitAttemptsExceeded() {
		return submitAttemptsExceeded;
	}

	public boolean isRenewAttemptsExceeded() {
		return renewAttemptsExceeded;
	}

	public boolean isPasscodeExpired() {
		return passcodeExpired;
	}

	public boolean isTransactionKeyHasExpired() {
		return transactionKeyHasExpired;
	}

	public void setSubmitAttemptsExceeded(boolean submitAttemptsExceeded) {
		this.submitAttemptsExceeded = submitAttemptsExceeded;
	}

	public void setRenewAttemptsExceeded(boolean renewAttemptsExceeded) {
		this.renewAttemptsExceeded = renewAttemptsExceeded;
	}

	public void setPasscodeExpired(boolean passcodeExpired) {
		this.passcodeExpired = passcodeExpired;
	}

	public void setTransactionKeyHasExpired(boolean transactionKeyHasExpired) {
		this.transactionKeyHasExpired = transactionKeyHasExpired;
	}

	public boolean isError() {
		return error;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setError(boolean error) {
		this.error = error;
	}
	
    public void setErrorMessage(String errorMessage) {
        //if error message equals null or "" set error to false
        this.setError((errorMessage != null && !Utils.isEmptyString(errorMessage.trim())));
        this.errorMessage = errorMessage;
    }
	
	public String getUnableToVerifyRegularPhoneMsg() {
		return unableToVerifyRegularPhoneMsg;
	}

	public String getUnableToVerifyLandlinePhoneMsg() {
		return unableToVerifyLandlinePhoneMsg;
	}

	public void setUnableToVerifyRegularPhoneMsg(String unableToVerifyRegularPhoneMsg) {
		this.unableToVerifyRegularPhoneMsg = unableToVerifyRegularPhoneMsg;
	}

	public void setUnableToVerifyLandlinePhoneMsg(String unableToVerifyLandlinePhoneMsg) {
		this.unableToVerifyLandlinePhoneMsg = unableToVerifyLandlinePhoneMsg;
	}

}
