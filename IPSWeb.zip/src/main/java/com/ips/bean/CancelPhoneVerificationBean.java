package com.ips.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

import com.equifax.smfa.response.ResponseStatusModel;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DeviceReviewStatusEnum;
import com.ips.common.common.SpringUtil;
import com.ips.entity.Person;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RpEvent;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationResponse;
import com.ips.persistence.common.UserVo;
import com.ips.proofing.ProofingService;
import com.ips.service.OtpVelocityCheckService;
import com.ips.service.PersonDataService;
import com.ips.service.RpEventDataService;
import com.ips.service.SmfaVelocityCheckService;

@ManagedBean(name="cancelphoneverification")
@ViewScoped
public class CancelPhoneVerificationBean extends RoutingController implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String formattedLockoutExpiresDateTime = "";
    private long phoneVerificationAttemptCount = 0;
    private long otpOrSmfaRequestAttemptCount = 0;
    private boolean renderRequestCodeBtn;
    private boolean renderLockoutExpiresDate;
    
    @PostConstruct
    @Override
    public void init() {
        PersonVo personVo = getSessionPersonVo();
        
        if (personVo != null) {     
            boolean isRejectDeviceAssessment = DeviceReviewStatusEnum.REJECT.getReviewStatus().equalsIgnoreCase(personVo.getDeviceAssessmentStatus());
            boolean isDenyDITDecision = PhoneVerificationResponse.PV_DECISION_FAIL.equalsIgnoreCase(personVo.getDitDecision());
            boolean isFailedPhoneVerification = PhoneVerificationResponse.PV_DECISION_FAIL.equalsIgnoreCase(personVo.getPhoneVerificationDecision());
            boolean isFailedSmfaStatus = ResponseStatusModel.RESPONSE_PATH_ORANGE.equalsIgnoreCase(personVo.getSmfaStatus())
            		|| ResponseStatusModel.RESPONSE_PATH_RED.equalsIgnoreCase(personVo.getSmfaStatus());
            boolean isFailedOtpConfirmation = IPSConstants.PROOFING_RESULT_FAILED.equalsIgnoreCase(personVo.getOtpConfirmationStatus());
            
            setRenderRequestCodeBtn(isRejectDeviceAssessment || isDenyDITDecision || isFailedPhoneVerification
            		|| isFailedSmfaStatus || isFailedOtpConfirmation);
         }
    }
    
    public void checkLockoutMessage() {
    	PersonVo personVo = getSessionPersonVo();
    	Timestamp lockoutExpiresTstamp = personVo.getLockoutExpiresDatetime();
         
        if (lockoutExpiresTstamp == null) {
          	setFormattedLockoutExpiresDateTime("");
          	setRenderLockoutExpiresDate(false);
        }
        else {
            String lockoutExpiresDateTime = getLockoutExpiresDateTimeDetail(lockoutExpiresTstamp);

            setRenderLockoutExpiresDate(true);
        	setFormattedLockoutExpiresDateTime(lockoutExpiresDateTime);
           	personVo.setLockoutExpiresDatetime(null);
        	setSessionPersonVo(personVo);
        }
        
    	setPhoneVerificationAttemptCount(personVo.getPhoneVerificationAttemptCount());
    	setOtpOrSmfaRequestAttemptCount(personVo.getOtpOrSmfaRequestAttemptCount());
    } 
    
    public String getFormattedLockoutExpiresDateTime() {
        return formattedLockoutExpiresDateTime;
    }
    
    public void setFormattedLockoutExpiresDateTime(
            String formattedLockoutExpiresDateTime) {
        this.formattedLockoutExpiresDateTime = formattedLockoutExpiresDateTime;
    }

    /**
     * This page redirects to the verification_cancel_request.xhtml page
     */
    public void returnToRequestCancelPage() {
        if(isHoldMail) {
            CustomLogger.debug(this.getClass(), "Phone Verification Canceled, return to calling app and Calling app is " + callingAppName);
            returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        }else {
            request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            String pathInfo = request.getServletPath().replace("/", "");
            CustomLogger.debug(this.getClass(), "Phone Verification Cancel Request from : "+pathInfo);
            HttpSession session = request.getSession();
            session.setAttribute(VERIFICATION_CANCEL_REQUEST_DESTINATION, pathInfo);
            goToPage(VERIFICATION_CANCEL_REQUEST);    
        }
    }
    
    /**
     * This page redirects to the verification_cancel_request.xhtml page
     */
    public void returnToRequestCancelPageForBoth() {
    	if(isHoldMail) {
             CustomLogger.debug(this.getClass(), "Phone Verification Canceled, return to calling app and Calling app is " + callingAppName);
             returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        }else {
	    	  request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	          String pathInfo = request.getServletPath().replace("/", "");
	          CustomLogger.debug(this.getClass(), "Phone Verification Cancel Request from : "+pathInfo);
	          HttpSession session = request.getSession();
	          session.setAttribute(VERIFICATION_CANCEL_REQUEST_DESTINATION, pathInfo);
	          goToPage(VERIFICATION_CANCEL_REQUEST);  
        }
    }
    
    public void returnToConfirmCancelpage() {
        goToPage(VERIFICATION_CANCEL_CONFIRMED);    
    }
    
    public void returnToVerificationUserInfoPage() {
        goToPage(isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : VERIFICATION_USER_INFO_PAGE);    
    }
    
    public void returnToPreviouspage() {
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        String pathInfo = (String) session.getAttribute(VERIFICATION_CANCEL_REQUEST_DESTINATION);
        CustomLogger.debug(this.getClass(), "Returning to previous page : "+pathInfo);
        if(VERIFICATION_USER_INFO_PAGE.equalsIgnoreCase(pathInfo)) {
            goToPage(VERIFICATION_USER_INFO_PAGE);    
        }else if(VERIFICATION_USER_INFO_HM_PAGE.equalsIgnoreCase(pathInfo)) {
            goToPage(VERIFICATION_USER_INFO_HM_PAGE);
        }else if(VERIFICATION_REQUEST_PASSCODE_PAGE.equalsIgnoreCase(pathInfo)) {
            goToPage(VERIFICATION_REQUEST_PASSCODE_PAGE);
        }else if(VERIFICATION_ENTER_PASSCODE_PAGE.equalsIgnoreCase(pathInfo)) {
            goToPage(VERIFICATION_ENTER_PASSCODE_PAGE);
	    }else if(VERIFICATION_SEND_SMFA_PAGE.equalsIgnoreCase(pathInfo)) {
	        goToPage(VERIFICATION_SEND_SMFA_PAGE);
	    }else if(VERIFICATION_VALIDATE_SMFA_PAGE.equalsIgnoreCase(pathInfo)) {
	        goToPage(VERIFICATION_VALIDATE_SMFA_PAGE);
	    }
    }
    
    public void returnToPreferencePage() {
        // If the user has exceeded the renewal attempts, change user's status to Started remote proofing so that they will go back 
        // into the pool for OTP
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        RpEventDataService rpEventService = (RpEventDataService) SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        PersonDataService personDataService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);

        PersonVo personVo = getSessionPersonVo();
        RefOtpSupplier phoneSupplier = rpEventService.getLatestPhoneSupplier(personVo);
        
        if (phoneSupplier != null) {
            RpEvent event = rpEventService.getLatestPhoneVerification(personVo.getId(), phoneSupplier.getOtpSupplierId());
            
            CustomLogger.debug(this.getClass(), "sponsorUserId: " + personVo.getSponsorUserId() + " selected Return to Preferences");
    		Person person = personDataService.findByPK(personVo.getId());

            if (event != null && (event.lastPasscodeAttemptExceededRenew() || exceededAttemptsLimit(person, personVo))) {
                CustomLogger.debug(this.getClass(), "Changing status to started remote proofing for sponsorUserId: " + personVo.getSponsorUserId());
                ProofingService proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
                proofingService.updateProofingStatus(RefRpStatus.RpStatus.Started_remote_proofing.getValue(), person, personVo.getProofingLevelSought());
            }
        }
        
        goToLogin();
    }
    
    public void returnToCodeViaMailPage() {
        goToCodeViaMailRegPage();
    }
    
    public void returnToVisitPOPage() {
        UserVo user = getSessionUser();
        // status needs to be opt-in so that the IPP page will display the correct buttons
        user.setStatus(IPSConstants.STATUS_IPP_OPT_IN);
        setSessionUser(user);
        goToPage(IN_PERSON_PROOFING_PAGE);
    }
    
    /**
     * This method handles a redirect to the verification_cancel_confirmed.xhtml page from another
     * application.  It calls fetchAccount and makes the necessary database updates needed
     * before going to the IPP page.
     */
    public void handleRedirect() {
        UserVo user = getSessionUser();
        
        // If the userVo is not in session, then another application redirected to 
        // the verification_cancel_confirmed page
        if (user == null) {
            try {
                // Call fetchAccount for user in CustReg cookie
                super.init();
                setSponsorUserInfo();
                this.user.setLoaSought(IPSConstants.LOA_15);
                this.user.setRedirectFromCustReg(true);
                setSessionUser(this.user);
                
                // Retrieve from database or create new record
                ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
                ProofingService proofingService = (ProofingService)SpringUtil.getInstance(servletContext).getBean(PROOFING_SERVICE);
                PersonDataService personDataService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);

                user = proofingService.getUserForRouting(this.user);
                
                PersonVo personVo = getSessionPersonVo();
                personVo.setSponsorUserId(user.getSponsorUserId());
                personVo.setSponsor(user.getSponsor());
                proofingService.updatePerson(personVo);
                
                Person person = personDataService.findByPK(personVo.getId());
        		
                // A proofing session must exist for assertions to CustReg
                proofingService.startProofingSession(person, personVo);
            }
            catch (Exception e) {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Exception occured while retrieving user data for IPP redirect for sponsorUserId:" 
                        + (user != null? user.getSponsorUserId() : "(null)"), e);
                goToPage(SYSTEM_ERROR_PAGE);
                return;
            }
        }
        
        // Route the user to the appropriate page if needed
        String nextPage = routeForIPP(user);
        
        if (StringUtils.isNotBlank(nextPage)){
            goToPage(nextPage);
        }
    }
    
    /**
     * This method routes the user directly to the in-person proofing page if they
     * have already opted in.  If they failed IPP, they are directed to the failure page.
     * @param user
     */
    private String routeForIPP(UserVo user){
        String nextPage = "";
        String status = user.getStatus();
        
        if (IPSConstants.STATUS_IPP_OPT_IN.equalsIgnoreCase(status) ||
            IPSConstants.STATUS_IPP_EMAIL_SENT.equalsIgnoreCase(status)){
            CustomLogger.info(this.getClass(), "IPP Routing to in_person_proofing page for user with sponsorUserId: " 
                    + user.getSponsorUserId() + " and status: " + status);
            nextPage = IN_PERSON_PROOFING_PAGE;
        }
        
        if (IPSConstants.STATUS_IPP_FAILED.equalsIgnoreCase(status)){
            CustomLogger.info(this.getClass(), "IPP Routing to verification_failure page for user with sponsorUserId: " 
                    + user.getSponsorUserId() + " and status " + status);
            nextPage = VERIFICATION_FAILURE_PAGE;
        }
        
        return nextPage;
    }
    
    public boolean isLockoutNull() {
        return (StringUtils.isEmpty(formattedLockoutExpiresDateTime)); 
    }
    
    private boolean exceededAttemptsLimit(Person person, PersonVo personVo) {
        boolean exceededLimit = false;
        
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        RpEventDataService rpEventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        
        RefOtpSupplier phoneSupplier = rpEventService.getLatestPhoneSupplier(getSessionPersonVo());
        if (phoneSupplier != null) {
        	if (phoneSupplier.isEquifaxDITPhone()) {
                SmfaVelocityCheckService smfaVelocityCheckSvc = (SmfaVelocityCheckService) SpringUtil.getInstance(ctx).getBean(SMFA_VELOCITY_CHECK_SERVICE);
                RpEventDataService rpEventDataService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
                
                RpEvent rpEvent = rpEventDataService.getLatestPhoneVerification(personVo.getId(), phoneSupplier.getOtpSupplierId());
                exceededLimit = smfaVelocityCheckSvc.exceededLinkAttemptsLimit(person, personVo, phoneSupplier, rpEvent);
        	}
        	else {
                OtpVelocityCheckService otpVelocityCheckSvc = (OtpVelocityCheckService) SpringUtil.getInstance(ctx).getBean(OTP_VELOCITY_CHECK_SERVICE);
                RpEvent rpEvent = rpEventService.getLatestPhoneVerification(personVo.getId(), phoneSupplier.getOtpSupplierId());

                exceededLimit = otpVelocityCheckSvc.exceededPasscodeAttemptsLimit(person, personVo, phoneSupplier, rpEvent);
         	}
        	setSessionPersonVo(personVo);
        }
        
        return exceededLimit; 
    }

	public boolean isRenderRequestCodeBtn() {
		return renderRequestCodeBtn;
	}

	public void setRenderRequestCodeBtn(boolean renderRequestCodeBtn) {
		this.renderRequestCodeBtn = renderRequestCodeBtn;
	}

	public boolean isRenderLockoutExpiresDate() {
		return renderLockoutExpiresDate;
	}

	public void setRenderLockoutExpiresDate(boolean renderLockoutExpiresDate) {
		this.renderLockoutExpiresDate = renderLockoutExpiresDate;
	}


	public long getPhoneVerificationAttemptCount() {
		return phoneVerificationAttemptCount;
	}

	public void setPhoneVerificationAttemptCount(long phoneVerificationAttemptCount) {
		this.phoneVerificationAttemptCount = phoneVerificationAttemptCount;
	}

	public long getOtpOrSmfaRequestAttemptCount() {
		return otpOrSmfaRequestAttemptCount;
	}

	public void setOtpOrSmfaRequestAttemptCount(long otpOrSmfaRequestAttemptCount) {
		this.otpOrSmfaRequestAttemptCount = otpOrSmfaRequestAttemptCount;
	}
}
