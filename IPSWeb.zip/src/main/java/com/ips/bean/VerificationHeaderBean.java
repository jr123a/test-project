package com.ips.bean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

//TODO Implement the USPS standard header and remove this bean
@ManagedBean(name="verificationHeaderBean")
@ViewScoped
public class VerificationHeaderBean extends IPSController implements Serializable {

    private static final long serialVersionUID = 1L;
    
}
