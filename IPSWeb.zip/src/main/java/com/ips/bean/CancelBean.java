package com.ips.bean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.entity.RefRpStatus;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.UserVo;
import com.ips.proofing.ProofingService;
import com.ips.proofing.ProofingServiceImpl;

@ManagedBean(name="cancel")
@ViewScoped
public class CancelBean extends IPSController implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final String REDIRECT_COOKIE = "CancelRedirect";
    private String redirectPage;

    public void cancelRemoteProofing() {    
        // Handle login in after page refresh
        if (userMatchesSession()) {
            ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
            WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);
            
            if (webAppCtx != null) {          
	            ProofingService service = webAppCtx.getBean(PROOFING_SERVICE, ProofingServiceImpl.class);
	            UserVo user = getSessionUser();
	            service.updateProofingStatus(RefRpStatus.RpStatus.Remote_proofing_cancelled.getValue(), user);
	            goToPage(VERIFICATION_ERROR_PAGE);
            }
        }
        else {
            goToPage(VERIFICATION_ERROR_PAGE);
        }
    }
    
    public boolean renderLOA15(){
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession(false);
        if(session != null){
            String loaSought = (String) session.getAttribute(IPSConstants.LOA_LEVEL_KEY);
            if(loaSought != null){
                return IPSConstants.LOA_15.equals(loaSought);
            }
        }
        
        return false;
    }
    
    public void goToCancelPage() {

        if(isHoldMail) {
            CustomLogger.debug(this.getClass(), "Verification Canceled, return to calling app and Calling app is " + callingAppName);
            returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        }else {
            CustomLogger.debug(this.getClass(), "In goToCancelPage");
            request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            HttpSession session = request.getSession(false);
            
            // Handle login in after page refresh
            if (userMatchesSession()) {
                FacesContext context = FacesContext.getCurrentInstance();  
                String viewRootId = context.getViewRoot().getViewId();
                redirectPage = viewRootId.substring(viewRootId.lastIndexOf('/')+1);   
                session.setAttribute(REDIRECT_COOKIE, redirectPage);
                goToPage(VERIFICATION_CANCEL);
            }
            else {
                goToLogin();
            }
        }
        
    }
    
    public void returnToRemote() {
        // Handle login in after page refresh
        if (userMatchesSession()) {
            request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            HttpSession session = request.getSession(false);
            
            String redirectPage2 = (String) session.getAttribute(REDIRECT_COOKIE);
    
            if(redirectPage2 != null){
                goToPage(redirectPage2);
            } else{
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Cannot get RedirectCookie from session.");
                goToPage(SYSTEM_ERROR_PAGE);
            }
        }
        else {
        	goToLogin();
        }
    }

    public String getRedirectPage() {
        return redirectPage;
    }

    public void setRedirectPage(String redirectPage) {
        this.redirectPage = redirectPage;
    }
}
