package com.ips.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.JSFUtils;
import com.ips.common.common.Utils;
import com.ips.entity.RefState;
import com.ips.exception.AMSException;
import com.ips.polocator.common.AppointmentVo;
import com.ips.proofing.VerifyAddressService;
import com.ips.proofing.VerifyAddressServiceImpl;
import com.ips.service.RefStateDataService;
import com.ips.service.RefStateDataServiceImpl;

@ManagedBean(name = "alternate")
@ViewScoped
public class AlternateAddressBean extends IPSController implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private AppointmentVo appointment;
    private List<RefState> states;
    
    
    @PostConstruct
    public void init(){
        // Handle login in after page refresh
        verifyUserSessionData();
                
        appointment = new AppointmentVo();
        states = new ArrayList<>();
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);
        
        if (webAppCtx != null) {
        	RefStateDataService service =webAppCtx.getBean("refStateService", RefStateDataServiceImpl.class);
            states = (List<RefState>) service.getAllActiveStates();
        }
 
    }
    
    public void verifyAddress() {
        if (valid()) {
            ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
            WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);
            
            if (webAppCtx != null) {          
            	VerifyAddressService service = webAppCtx.getBean("VerifyAddressService", VerifyAddressServiceImpl.class);

            	try {
                appointment = service.verifyAddress(appointment);
                setSessionAppointment(appointment);
                goToPage(SCHEDULE_APPOINTMENT_PAGE);
	            } catch (AMSException e) {
	                CustomLogger.error(this.getClass(), "Error calling Verify Address",e);
	                goToPage(INELIGIBLE_ADDRESS_PAGE);
	            }
            }
        }
    }

    public AppointmentVo getAppointment() {
        return appointment;
    }

    public void setAppointment(AppointmentVo appointment) {
        this.appointment = appointment;
    }

    public List<RefState> getStates() {
        return states;
    }

    public void setStates(List<RefState> states) {
        this.states = states;
    }
    
    private boolean valid() {
        boolean valid = true;
        
        if (appointment != null) {
            if (appointment.getAddress1() == null) {
                CustomLogger.debug(this.getClass(), "Street address is null");
            }
            
            if (appointment.getAddress2() == null) {
                CustomLogger.debug(this.getClass(), "Apt/Suite/Other is null");
            } 
            
            if (appointment.getCity() == null) {
                CustomLogger.debug(this.getClass(), "City is null");
            } 
            
            if (appointment.getAddress1() != null && !Utils.isValidStreetAddress(appointment.getAddress1())) {
                JSFUtils.addFacesErrorMessage("Street Address contains invalid characters.");
                valid = false;
            }
            else if (appointment.getAddress2() != null && !Utils.isValidStreetAddress(appointment.getAddress2())) {
                JSFUtils.addFacesErrorMessage("Apt/Suite/Other contains invalid characters.");
                valid = false;
            } 
            else if (appointment.getCity() != null && !Utils.isAlphanumeric(appointment.getCity())) {
                JSFUtils.addFacesErrorMessage("City contains invalid characters.");
                valid = false;
            } 
        }
        else {
            CustomLogger.debug(this.getClass(), "Appointment is null");
        }
        
        return valid;
    }
}
