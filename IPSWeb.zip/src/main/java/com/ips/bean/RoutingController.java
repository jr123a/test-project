package com.ips.bean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsor;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.UserVo;
import com.ips.proofing.ProofingService;
import com.ips.proofing.ProofingServiceImpl;
import com.ips.service.CustRegService;
import com.ips.service.PersonDataService;
import com.ips.service.PersonProofingStatusService;
import com.ips.service.RefLoaLevelService;
import com.ips.service.RefRpStatusDataService;
import com.usps.entreg.filter.data.EntRegSSOToken;
import com.usps.net2x.entreg.data.EntRegAccount;
import com.usps.net2x.entreg.data.EntRegAccountInfo;
import com.usps.net2x.entreg.data.EntRegAccountName;
import com.usps.net2x.entreg.data.EntRegAddressPHX2;
import com.usps.net2x.entreg.data.EntRegContactInfoPHX;
import com.usps.net2x.entreg.data.EntRegMobileDevices;
import com.usps.net2x.entreg.data.EntRegMobilePhone;
import com.usps.net2x.entreg.data.EntRegMobilePhoneList;
import com.usps.net2x.entreg.data.EntRegPhoneList;

@ManagedBean(name="routing")
@ViewScoped
public class RoutingController extends IPSController implements Serializable {

    @EJB
    SessionProperties properties;

    private static final long serialVersionUID = 1L;
    private static final String APP_URL_PARAM = "appURL";
    private static final String LOA_LEVEL_PARAM = "LOA";
     
    protected UserVo user;
    private String loaSought = null;
    private ApplicationContext appCtx = null;
     
    @PostConstruct
    public void init() {
        CustomLogger.enter(this.getClass());
        
        ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        appCtx = WebApplicationContextUtils.getWebApplicationContext(servletContext);
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        handleRequestParams();
        getCustRegInfo();
    }
    
    public void routeUser() {
        CustomLogger.enter(this.getClass());
        ProofingService proofingService = appCtx.getBean(PROOFING_SERVICE, ProofingServiceImpl.class);
        RefLoaLevelService loaService = appCtx.getBean(REF_LOA_LEVEL_SERVICE, RefLoaLevelService.class);
        
        PersonVo personVo = getSessionPersonVo();
        
        PersonProofingStatusService personProofingStatusService = appCtx.getBean(PERSON_PROOFING_STATUS_SERVICE, PersonProofingStatusService.class);
       	PersonProofingStatus personProofingStatus = personProofingStatusService.getByPersonId((int)personVo.getId());

        if (personProofingStatus != null) {
        	RefRpStatus refRpStatus = personProofingStatus.getRefRpStatus();
        	if (refRpStatus != null) {
        		if (refRpStatus.getStatusCode() == 8L) {
        			user.setStatus(refRpStatus.getStatusDescription());
        			user.setStatusCode(refRpStatus.getStatusCode());
 	        	}
        	}
	    }    
    	
        user.setLoaSought(loaSought);
        
        user = proofingService.getUserForRouting(user);
        setSessionUser(user);
   
  
        CustomLogger.debug(this.getClass(), "SponsorUserId:" + (user != null ? user.getSponsorUserId() : "null"));
        
        if (user == null || user.getSponsorUserId() == null || personVo == null) {
            CustomLogger.debug(this.getClass(), "Sending the user over to Cust Reg preferences."); 
            if (user != null) {
                CustomLogger.debug(this.getClass(), "SponsorUserId:" + user.getSponsorUserId());
            }
            returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
            return;
        }
        personVo.setSponsorUserId(user.getSponsorUserId());
        personVo.setSponsor(IPSConstants.SPONSOR_CUSTREG);
        
        // Person record needs to be created at this point in order to track users that entered IVS
        try {
            proofingService.updatePerson(personVo);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred creating or updating person record on entry to IVS for sponsorUserId: " 
                    + personVo.getSponsorUserId(), e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
        
        // If the user already has the level of assurance they are seeking then display a messsage to that effect.
        // Display the same message if the level sought is less than the level achieved
        if (loaSought != null) {
            long longLoaSought = loaService.findByLevel(loaSought).getLoaCode();
            
            // hasLevelSought only compares level sought to level achieved, have to also look at status!
            if (user.hasLevelSought(longLoaSought) && IPSConstants.STATUS_LOA_ACHIEVED.equalsIgnoreCase(user.getStatus())) {
                goToPage(VERIFICATION_STATUS_PAGE);
                return;
            }
        }
        
        routeUser(user);
    }
    
    public void setSponsorUserInfo(){
        CustomLogger.enter(this.getClass());
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        
        // Do NOT remove this line - this is where the userID from the CustReg
        // cookie is retrieved
        String userID = (String) session.getAttribute(IPSConstants.USER_ID_KEY);
        
        if(userID == null)  {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "VerificationBean.setSponsorUserInfo() userID is null");
            goToPage(SYSTEM_ERROR_PAGE);
        }
        
        PersonVo personVo = getSessionPersonVo();
         
        if (personVo != null) {
	        personVo.setSponsorUserId(userID);
	        personVo.setSponsor(IPSConstants.SPONSOR_CUSTREG);
	        setSessionPersonVo(personVo);
        }
    }
    
    public void handleRequestParams() {
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();

        if (session != null) {
            String callingApp = request.getParameter(APP_URL_PARAM);
            CustomLogger.debug(this.getClass(), "Routing appURL value: " + callingApp);

            // ensure the 1.5 appURL value is not overwritten with null
            if (callingApp != null) {
                if (Utils.isValidURL(callingApp)) {
                	setSessionCallingApp(callingAppURL);
                 } else {
                    CustomLogger.warn(this.getClass(), "WARNING: Invalid appURL supplied: " + callingApp);
                }
            }
            loaSought = request.getParameter(LOA_LEVEL_PARAM);
            CustomLogger.info(this.getClass(), "LOA request param value: " + loaSought);

            loaSought = IPSConstants.LOA_15;
            
            
            session.setAttribute(IPSConstants.LOA_LEVEL_KEY, loaSought);
            
            if (isValidLevelOfAssurance(loaSought)) {
                session.setAttribute(IPSConstants.LOA_LEVEL_KEY, IPSConstants.LOA_15);

            } 
            else {
                CustomLogger.warn(this.getClass(), "WARNING: Invalid LOA supplied: " + loaSought);
            }
        }        
    }
    
    private boolean isValidLevelOfAssurance(String input) {
        return RefLoaLevel.LOA_15.equals(input) ;
    }
    
    public void getCustRegInfo(){
    	String userId = "";
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();

        EntRegSSOToken tok = (EntRegSSOToken) request.getAttribute(EntRegSSOToken.REQUEST_KEY);

        if (tok != null) {
            if (tok.isNewUserLoggedIn()) {
            	userId = tok.getUserId();
                CustomLogger.debug(this.getClass(), "entRegSSOToken.isNewUserLoggedIn() == true ...");
            } else if (tok.isExpired()) {
                CustomLogger.debug(this.getClass(), "entRegSSOToken.isExpired() == true ...");
            } else {
            	userId = tok.getUserId();
                CustomLogger.debug(this.getClass(), "all else  entRegSSOTokens ... eRegUserId ... " + userId);
            }
        } 
        
        if (tok == null) {
        	return;
        }
        
        userId = tok.getUserId();

        if (userId == null) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "RoutingController.userID is null");
            goToPage(SYSTEM_ERROR_PAGE);
        } else {
            HttpSession session = request.getSession();
            session.setAttribute(IPSConstants.USER_ID_KEY, userId);
            
            String clientIPAddress = getClientIpAddress();
            session.setAttribute(IPSConstants.CLIENT_IP_ADDR, clientIPAddress);
            getCustRegUser(userId, loaSought);

            user = new UserVo();
            user.setSponsorUserId(userId);
            user.setSponsor(IPSConstants.SPONSOR_CUSTREG);

            // Set the email address on the user so that it will display on the Verification
            // Success page in the activation email sent message
            PersonVo personVo = getSessionPersonVo();
           
		    if (personVo != null) {
                user.setEmail(personVo.getEmailAddress());
            }
		    
           PersonDataService personDataService = appCtx.getBean(PERSON_DATA_SERVICE, PersonDataService.class);
     	   PersonProofingStatusService personProofingStatusService = appCtx.getBean(PERSON_PROOFING_STATUS_SERVICE, PersonProofingStatusService.class);
     	  
     	   Person existingPerson = personDataService.findExistingPerson(RefSponsor.SPONSOR_ID_CUSTREG, userId);
           
           if (existingPerson != null) {
           		Long statusCode = personProofingStatusService.getPersonProofingStatusCodeByPersonId((int)existingPerson.getPersonId());
           		
           		RefRpStatusDataService refRpStatusDataService = appCtx.getBean(REF_RP_STATUS_DATA_SERVICE, RefRpStatusDataService.class);
           		RefRpStatus refRpStatus = refRpStatusDataService.findByStatusCode(statusCode);
           		
           		if (refRpStatus != null) {
              		 if (user.getStatusCode() != 8L) {
              			 user.setStatus(refRpStatus.getStatusDescription());
              			 user.setStatusCode(refRpStatus.getStatusCode());
              		 }
           		}
           } 
           
           if (personVo != null) {
 	        	 PersonProofingStatus personProofingStatus = personProofingStatusService.getByPersonId((int)personVo.getId());
 	 	       	
 	 	        // Updates user proofing status with IVS
 	 	        if (personProofingStatus != null) {
 	 	        	RefRpStatus refRpStatus = personProofingStatus.getRefRpStatus();
 	 	        	if (refRpStatus != null) {
 	 	        		if (refRpStatus.getStatusCode() == 8L) {
	     	 	        	user.setStatus(refRpStatus.getStatusDescription());
	     	 	        	user.setStatusCode(refRpStatus.getStatusCode());
     	 	        	}
 	 	        	}
 	 	        }    
         	}
        }
    }
    
    public void getCustRegUser(String id, String loaSought){
        CustRegService custRegService = appCtx.getBean(CUST_REG_SERVICE, CustRegService.class);
        EntRegAccount acc = custRegService.fetchAccount(id);

        if (acc == null) {
            goToPage(SYSTEM_ERROR_PAGE);
        } else {
            EntRegAccountInfo account = acc.getAccountInfo();
            EntRegContactInfoPHX contact = acc.getContactInfo();

            PersonVo personVo = setPersonVoFields(account, contact, loaSought);
        	CustomLogger.debug(this.getClass(), "Remote proofing status: New PersonVo is created from CustReg account and contact.");

        	setSessionPersonVo(personVo);

            checkIfReproofing(id, loaSought, personVo);
        }
    }

    /**
     * Updates mobile phone fields for PersonVo Object
     * Sets some values to "" to avoid NullPointerExceptions
     * @param person
     * @param contact
     * @return
     */
    private PersonVo updatePersonMobile(PersonVo person, EntRegContactInfoPHX contact) {
        person.setMobileNumber("");        
        EntRegMobileDevices mobileDevices = contact.getMobileDevices();
        if (mobileDevices != null) {
            EntRegMobilePhoneList mobilePhoneList = mobileDevices.getMobilePhoneList();
            if (mobilePhoneList != null && mobilePhoneList.size() > 0) {
                EntRegMobilePhone mobilePhone = mobilePhoneList.get(0);
                
                if (mobilePhone != null && StringUtils.isNotBlank(mobilePhone.getAreaCode()) && StringUtils.isNotBlank(mobilePhone.getNumber())) {
                    person.setMobileNumber(mobilePhone.getAreaCode() + mobilePhone.getNumber());
                }
            }
        }
        return person;
    }

    /**
     * Updates phone fields for PersonVo Object
     * Sets some values to "" to avoid NullPointerExceptions
     * @param person
     * @param contact
     * @return
     */
    private PersonVo updatePersonPhone(PersonVo person, EntRegContactInfoPHX contact) {
        EntRegPhoneList phone = contact.getPhoneList();
        if (phone != null) {
            String phoneNumber = phone.get(0).getNumber();

            if (phoneNumber == null) {
                person.setPhoneNumber("");
            } else {
                person.setPhoneNumber(phoneNumber);
            }

            person.setPhoneExtension(phone.get(0).getExtension());
            person.setPhoneType     (phone.get(0).getType());
        } else {
            person.setPhoneNumber("");
            person.setPhoneExtension("");
            person.setPhoneType("");
        }
        return updatePersonMobile(person, contact);
    }     
    /**
     * Updates Name and Address fields for PersonVo Object
     * @param person
     * @param contact
     * @return
     */
    private PersonVo setPersonVoFields(EntRegAccountInfo account, EntRegContactInfoPHX contact, String loaSought) {
        PersonVo personVo = new PersonVo();
        EntRegAddressPHX2 address     = contact.getAddress();
        EntRegAccountName accountName = account.getAccountName();
        personVo.setLastName            (accountName.getLastName());
        personVo.setMiddleName          (accountName.getMiddleInitial());
        personVo.setFirstName           (accountName.getFirstName());
        personVo.setNameTitle            (accountName.getTitle());
        personVo.setNameSuffix           (accountName.getSuffix());
        personVo.setEmailAddress        (contact.getEmail());
        personVo.setAddressLine1        (address.getAddressLine1());
        personVo.setAddressLine2        (address.getAddressLine2());
        personVo.setAddressLine3        (address.getAddressLine3());
        personVo.setCity                 (address.getCity());
        String state = address.getStateProvince();
        personVo.setStateProvince       (state == null ? "" : state);
        personVo.setPostalCode          (address.getPostalCode());
        personVo.setCountry              (address.getCountryName());
        personVo.setProofingLevelSought(loaSought);
       
        return updatePersonPhone(personVo, contact);
    }

    private void checkIfReproofing(String id, String loaSought, PersonVo person) {
        ProofingService proofingService = appCtx.getBean(PROOFING_SERVICE, ProofingServiceImpl.class);
        try {
            proofingService.checkIfReproofing(id, person, loaSought);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Exception on reproofing check for sponsorUserId:" + (person != null ? person.getSponsorUserId() : "null"), e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }
}
