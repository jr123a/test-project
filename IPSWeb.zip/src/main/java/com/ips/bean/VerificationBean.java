package com.ips.bean;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Response;

import org.apache.wink.client.Resource;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.gson.Gson;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DeviceReviewStatusEnum;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.Person;
import com.ips.entity.PersonData;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RpDitResponse;
import com.ips.entity.RpEvent;
import com.ips.entity.RpExperianDecisionResult;
import com.ips.entity.RpExperianResponsePayload;
import com.ips.entity.RpLexisNexisResult;
import com.ips.entity.RpPhoneVerification;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.UserVo;
import com.ips.proofing.PhoneVerificationServiceImpl;
import com.ips.proofing.ProofingService;
import com.ips.proofing.VerificationProviderService;
import com.ips.service.DeviceReputationService;
import com.ips.service.HighRiskAddressService;
import com.ips.service.PersonDataDataService;
import com.ips.service.PersonDataService;
import com.ips.service.RefOtpSupplierDataService;
import com.ips.service.RpDitResponseService;
import com.ips.service.RpEventDataService;
import com.ips.service.RpExperianDecisionResultService;
import com.ips.service.RpExperianResponsePayloadService;
import com.ips.service.RpLexisNexisResultService;
import com.ips.service.SponsorIncomingRequestsService;

@ManagedBean(name="verification")
@ViewScoped
public class VerificationBean extends IPSController implements Serializable  {
    
    @EJB
    SessionProperties properties;

    private static final long serialVersionUID = 1L;

    protected PersonVo personVo;
    protected Person person;
    protected Person entityPerson;
    protected String phoneNumber;
    protected String progressStatusText;
    protected String requestPasscodeOrLinkText;
    protected String enterPasscodeOrValidateLinkText;
    protected String profilingSessionId;
    protected String customerIpAddress;
    protected boolean deviceProfilingEnabled;
    protected int passcodeAttempts = 0;
    private SponsorIncomingRequestsService sponsorIncomingRequestsService;
    private String dob;
    private String dob2;
    private String ssn;
    private String ssn2;
    private String pin;
    private String pin2;
    private boolean pinError = false;
    private boolean termsError = false;
    private boolean terms = false;
    private int tabIndex = 0;
    
    @PostConstruct
    public void init() {
        CustomLogger.enter(this.getClass());
        
        // Handle login in after page refresh
        verifyUserSessionData();
                
        setSponsorUserInfo();
        
        ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        sponsorIncomingRequestsService = (SponsorIncomingRequestsService)SpringUtil.getInstance(ctx).getBean(SPONSOR_INCOMING_REQUESTS_SERVICE);
    }
    
    public void setSponsorUserInfo(){
        CustomLogger.enter(this.getClass());
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        
        // Do NOT remove this line - this is where the userID from the CustReg
        // cookie is retrieved
        String userID = (String) session.getAttribute(IPSConstants.USER_ID_KEY);
        
        if(userID == null)  {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "VerificationBean.setSponsorUserInfo() userID is null");
            goToPage(SYSTEM_ERROR_PAGE);
        }
        
        personVo = getSessionPersonVo();
         
        if (personVo != null) {
	        personVo.setSponsorUserId(userID);
	        personVo.setSponsor(IPSConstants.SPONSOR_CUSTREG);
	        setSessionPersonVo(personVo);
        }
    }
    
    public void backToVerificationUserInfoPage() {
        CustomLogger.enter(this.getClass());
                
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        ProofingService proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
        PersonDataService personService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
        
        personVo = getSessionPersonVo();
        person = personService.findByPK(personVo.getId());    
    
        String pageName = isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : VERIFICATION_USER_INFO_PAGE;
        String verificationUserInfoPageUrl = String.format("%s/%s", getHttpServletRequest().getContextPath(), pageName);

        try {
            proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_initiated.getValue(), person,
                    personVo.getProofingLevelSought());
            
            FacesContext.getCurrentInstance().getExternalContext().redirect(verificationUserInfoPageUrl);
        } catch (IOException e) {
            CustomLogger.error(this.getClass(), "Could not redirect to page: " + verificationUserInfoPageUrl, e);
        }
    }
    
	public void optInAlternativeVerification() {
        CustomLogger.enter(this.getClass());
        
        // Retrieve address_hash from person_data
        personVo = getSessionPersonVo();

        if (personVo != null) {
	      	personVo.setPhoneNumber(phoneNumber);
	      	setSessionPersonVo(personVo);
        }

        goToPage(VERIFICATION_CANCEL_REQUEST);
    }
       
    /**
     * This method must only be called ONCE for a user going through the LOA 1.5 flow.
     * @return
     */
    protected final RefOtpSupplier determineVerificationMethod(boolean individualNotFound) {
        
        ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
  	 	
        personVo = getSessionPersonVo();
        personVo.setLexisNexisIndividualNotFound(individualNotFound);
        RefOtpSupplier verificationMethod = null;
        
        WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);

   	 	if (webAppCtx != null) {
   	 		VerificationProviderService verificationProviderService = webAppCtx.getBean(VERIFICATION_PROVIDER_SERVICE, VerificationProviderService.class);
        	verificationMethod = verificationProviderService.determineVerificationMethod(personVo);
   	 	}
   	 	
        if (verificationMethod == null) {
             CustomLogger.info(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred in selecting verification method for sponsorUserId:" + personVo.getSponsorUserId());
        	 goToPage(SYSTEM_ERROR_PAGE);
        }
            
        return verificationMethod;
    }

    protected void logFailedTransaction(PersonVo personVo, String failureMessage, long supplierId) {
  	    ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
   		RpEventDataService rpEventDataService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        PersonDataService personService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);

        Person person = personService.findByPK(personVo.getId());    
    
    	logFailedTransaction(person, personVo, failureMessage, supplierId);
    }
    
    protected void logFailedTransaction(Person person, PersonVo personVo, String failureMessage, long supplierId) {   	
    	if (personVo == null) {
    		return;
    	}
    	
    	long sponsorId = personVo.getSponsorId();
    	long personId = personVo.getId();
    	
   	    ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
   	    Timestamp currentDateTime = new Timestamp(new Date().getTime());
    	
   	    personVo.addLogInfoMapEntry("failureMessage", failureMessage);
   	    
   	    if (RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID == supplierId) {
    		RpEventDataService rpEventDataService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
    		RpEvent rpEvent = rpEventDataService.findLatestEventByPersonId(personVo.getId());
    		
    		if (rpEvent != null) {
	    		RpLexisNexisResultService rpLexisNexisResultService = (RpLexisNexisResultService)SpringUtil.getInstance(ctx).getBean(RP_LEXISNEXIS_RESULT_SERVICE);
	    		RpLexisNexisResult rpLexisNexisResult = new RpLexisNexisResult();
	    		rpLexisNexisResult.setEventId(rpEvent.getEventId());
	    		rpLexisNexisResult.setCreateDate(currentDateTime);
	    		rpLexisNexisResult.setResponse(getLogInfoMapAsString(personVo));
	    		rpLexisNexisResultService.create(rpLexisNexisResult);
    		}
    	}
    	else if (RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID == supplierId) {
    		RpDitResponseService rpDitResponseService = (RpDitResponseService)SpringUtil.getInstance(ctx).getBean(RP_DIT_RESPONSE_SERVICE);
     	
    		if (person != null) {
    			Gson g = new Gson();
    		    String requestJsonStr = g.toJson(person);
    		    if (requestJsonStr.length() > 4000) {
    		    	requestJsonStr = requestJsonStr.substring(0,  3990);
    		    }
	    		
    		    RpDitResponse rpDitResponse = new RpDitResponse();
	    		rpDitResponse.setPerson(person);
	    		rpDitResponse.setRequest(requestJsonStr);
	    		rpDitResponse.setResponse(getLogInfoMapAsString(personVo));
	    		rpDitResponse.setCreateDate(currentDateTime);
	    		rpDitResponseService.create(rpDitResponse);
    		}
    	}
    	else if (RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID == supplierId) {
    		RpExperianDecisionResultService rpExperianDecisionResultService = (RpExperianDecisionResultService)SpringUtil.getInstance(ctx).getBean(RP_EXPERIAN_DECISION_RESULT_SERVICE);
    		RpExperianDecisionResult rpExperianDecisionResult = rpExperianDecisionResultService.findByPersonId(personVo.getId());
			
    		if (rpExperianDecisionResult != null) {
    			RpExperianResponsePayloadService rpExperianResponsePayloadService = (RpExperianResponsePayloadService)SpringUtil.getInstance(ctx).getBean(RP_EXPERIAN_RESPONSE_PAYLOAD_SERVICE);
    			RpExperianResponsePayload rpExperianResponsePayload = new RpExperianResponsePayload();
    			rpExperianResponsePayload.setExpResultId(rpExperianDecisionResult.getExpResultId());
    			rpExperianResponsePayload.setDecisionElements(getLogInfoMapAsString(personVo));
    			rpExperianResponsePayload.setOrchestrationDecision("Phone verification API call failure.");
    			rpExperianResponsePayload.setServiceName("PV-OTP");   			
    			rpExperianResponsePayload.setCreateDate(currentDateTime);
    			rpExperianResponsePayloadService.create(rpExperianResponsePayload);
    		}
		}
    	else {
			//TODO: For log before supplier determination
    	}
    }
    
    public String getLogInfoMapAsString(PersonVo personVo) {
    	String mapAsString = null;
    
		if (!personVo.getLogInfoMap().isEmpty()) {
			Map<String, String> map = personVo.getLogInfoMap();
			mapAsString = map.entrySet() .stream() .map(entry -> entry.getKey() + "=" + entry.getValue()) .collect(Collectors.joining(", ", "{", "}")); 
		}
		
		return mapAsString;
    }
    
    public void resetErrorMessage() {
        CustomLogger.enter(this.getClass());
        
        setSessionVerifyPhoneError(null);
        getPersonVo().setMobileNumber(phoneNumber);
    }
    
    @PreDestroy
    public void destroy(){
        CustomLogger.enter(this.getClass());
    }

    public void redirectToCustReg() {
    	setSessionPersonVo(personVo);

        List<String> props = new ArrayList<>();
        props.add("com.usps.entreg.ENTREG_UPDATEPROFILE_URL");
        props.add("com.ipsweb.VERIFICATION_URL");
        props = Utils.getProperty(props);

        if (!props.isEmpty()) {
            try {
            	String url = props.get(0) + IPSConstants.CUSTREG_ACTION_REDIRECT + props.get(1);
            	FacesContext.getCurrentInstance().getExternalContext().redirect(url);
                return;
            } catch (IOException e) {
                CustomLogger.error(this.getClass(), "Error redirecting to Cust Reg for sponsorUserId:" + personVo.getSponsorUserId(), e);
            } 
        }
        goToPage(SYSTEM_ERROR_PAGE);
    }

    public void termsAndConditions() {
    	setSessionPersonVo(personVo);
        goToPage(TERMS_AND_CONDITIONS_PAGE);
    }
    
    public String getTermsAndConditionsURL() {
    	setSessionPersonVo(personVo);
        return  Utils.getProperty("com.ips.TERMS_URL");
    }
    
    public void setTermsAndConditionsURL(String value) {
        // Do nothing; setter must exist to avoid exception
    }

    public String formatPhoneNumber(){
        String temp = personVo.getPhoneNumber();
        
        if(temp.length() == 10){
            return "("+temp.substring(0,3)+") "+temp.substring(3,6)+"-"+temp.substring(6,10); 
        }
        return temp;
    }

     public void checkIfUserFailedPhoneVerification() {
        // Hack fix 
        // Scenario 4 User Failed Online Phone Verification
        setPersonVo(getSessionPersonVo());
        ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        RpEventDataService rpEventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        RefOtpSupplier supplier = rpEventService.getLatestPhoneSupplier(getSessionPersonVo());
 
        if (supplier == null) {
        	RefOtpSupplierDataService supplierDataService = (RefOtpSupplierDataService)SpringUtil.getInstance(ctx).getBean(REF_OTP_SUPPLIER_DATA_SERVICE);
        	supplier = supplierDataService.findBySupplierId(getPersonVo().getCurrentPhoneVerificationSupplierId());
        }
        
  	 	WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);
  	 	boolean userFailedEIDPhoneVerification = true;
  	 	
   	 	if (webAppCtx != null) {
   	 		PhoneVerificationServiceImpl phoneVerificationService = webAppCtx.getBean(PHONE_VERIFICATION_SERVICE, PhoneVerificationServiceImpl.class);
   	 		userFailedEIDPhoneVerification = phoneVerificationService.userFailedEIDPhoneVerification(getPersonVo(), supplier);
   	 	}
   	 		
        if (userFailedEIDPhoneVerification) {
            CustomLogger.debug(this.getClass(), "Scenario 4 hack prevented");
            goToPage(isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : VERIFICATION_USER_INFO_PAGE);    
            return;
        }
        else {
        	request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();                    

        	String callingAppName = getSessionCallingAppName();
            boolean isHoldMail = HOLD_MAIL.equalsIgnoreCase(callingAppName) ;

            if (request.getRequestURI().contains(VERIFICATION_REQUEST_PASSCODE_PAGE) 
               		|| request.getRequestURI().contains(VERIFICATION_ENTER_PASSCODE_PAGE)
               		|| request.getRequestURI().contains(VERIFICATION_ENTER_PASSCODE_HM_PAGE)
            		|| request.getRequestURI().contains(VERIFICATION_SEND_SMFA_PAGE)
            		|| request.getRequestURI().contains(VERIFICATION_VALIDATE_SMFA_PAGE)) {
                UserVo user = (UserVo) request.getSession().getAttribute(IPSConstants.USER_KEY);            
                
                if (user.getStatus().equalsIgnoreCase(IPSConstants.STATUS_LOA_ACHIEVED)) {
                    if(isHoldMail) {
                        CustomLogger.debug(this.getClass(), "Calling app is " + callingAppName);
                        returnToCallingApp(IPSConstants.PROOFING_RESULT_PASSED);
                    } else {
                        goToInformedDeliverySuccessPage();
                    }
                }
            }
        }
     }
     
    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getDob2() {
        return dob2;
    }

    public void setDob2(String dob2) {
        this.dob2 = dob2;
    }

    public String getSsn2() {
        return ssn2;
    }

    public void setSsn2(String ssn2) {
        this.ssn2 = ssn2;
    }

    public PersonVo getPersonVo() {
        return personVo;
    }

    public void setPersonVo(PersonVo personVo) {
        this.personVo = personVo;
    }

    public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getPin2() {
        return pin2;
    }

    public void setPin2(String pin2) {
        this.pin2 = pin2;
    }

    public boolean isPinError() {
        return pinError;
    }

    public void setPinError(boolean pinError) {
        this.pinError = pinError;
    }

    public boolean isTerms() {
        return terms;
    }

    public void setTerms(boolean terms) {
        this.terms = terms;
    }

    public boolean isTermsError() {
        return termsError;
    }

    public void setTermsError(boolean termsError) {
        this.termsError = termsError;
    }
    public int getTabIndex() {
        tabIndex++;
        return tabIndex;
    }
    
    public void updatePhoneNumberInSession(String mobileNumber) {
        personVo = getSessionPersonVo();
        personVo.setMobileNumber(mobileNumber);
        
        setSessionPersonVo(personVo);
    }
    
    protected String getVerificationMaskedPhoneNumberForUI() {
        CustomLogger.enter(this.getClass());
        
        // Since this bean is SessionScoped, the phone number should always
        // be retrieved from the database to ensure that a previous user's
        // phone number from the same browser session is not used
        getSavedPhone();
        setPersonVo(getSessionPersonVo());
        setVerificationPhoneNumber(getPersonVo().getMobileNumber());
        return phoneNumber.isEmpty() ? "" : "(***) ***-**" + phoneNumber.substring(8);
    }
    
    protected void getSavedPhone() {
        // retrieve last phone number from the database if routed to this page after closing browser
        personVo = getSessionPersonVo();
        
        //get Services from Spring application context        
        if (personVo != null) {
            ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
            RpEventDataService rpEventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
            
            //Retrieving phone number that was verified from the database and not using the one from CustReg.
            RefOtpSupplier phoneSupplier = rpEventService.getLatestPhoneSupplier(personVo);
                        
            if (phoneSupplier != null) {
                String retrievedPhoneNumber = getLatestPhoneByPersonId(personVo.getId(), phoneSupplier);
                                
                if (retrievedPhoneNumber != null) {
                    // Update the phone number on the personVo and update personVo in Session
                    updatePhoneNumberInSession(retrievedPhoneNumber);
                }
            }
        }
    }
    
    /** 
     * Retrieves the phone number from the database
     */
    public String getLatestPhoneByPersonId(long personId, RefOtpSupplier phoneSupplier) {
    	CustomLogger.enter(this.getClass());
    	
        ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        RpEventDataService rpEventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);

        // Retrieve the most recent phone verification event for this person
        RpEvent event = rpEventService.getLatestPhoneVerification(personId, phoneSupplier.getOtpSupplierId());
        String mobilePhoneNumber = "";
        
        if (event != null) {
            RpPhoneVerification phoneVerification = event.getRpPhoneVerification();
            mobilePhoneNumber = phoneVerification.getMobilePhoneNumber();
        }
        
        return mobilePhoneNumber;
    }

	public void setVerificationPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getProgressStatusText() {
 		progressStatusText = "Please wait while we determine if your identity is eligible to be verified online.";
			
		return progressStatusText;
	}

	public void setProgressStatusText(String progressStatusText) {
		this.progressStatusText = progressStatusText;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getRequestPasscodeOrLinkText() {
		return requestPasscodeOrLinkText;
	}

	public void setRequestPasscodeOrLinkText(String requestPasscodeOrLinkText) {
		this.requestPasscodeOrLinkText = requestPasscodeOrLinkText;
	}
	
	public String getEnterPasscodeOrValidateLinkText() {
		return enterPasscodeOrValidateLinkText;
	}

	public void setEnterPasscodeOrValidateLinkText(String enterPasscodeOrValidateLinkText) {
		this.enterPasscodeOrValidateLinkText = enterPasscodeOrValidateLinkText;
	}

	public boolean isDeviceProfilingEnabled() {
	    CustomLogger.enter(this.getClass(), "isDeviceProfilingEnabled=" + deviceProfilingEnabled);
		return deviceProfilingEnabled;
	}

	public void setDeviceProfilingEnabled(boolean deviceProfilingEnabled) {
 		this.deviceProfilingEnabled = deviceProfilingEnabled;
	}
	
    public String getProfilingSessionId() {
        return profilingSessionId;
    }

    public void setProfilingSessionId(String profilingSessionId) {
        this.profilingSessionId = profilingSessionId;
    }

    public String getCustomerIpAddress() {
        return customerIpAddress;
    }

    public void setCustomerIpAddress(String customerIpAddress) {
        this.customerIpAddress = customerIpAddress;
    }
    
    public void getTermsAndConditions() {
    	goToPage(TERMS_AND_CONDITIONS_PAGE);
    }

	public int getPasscodeAttempts() {
		return passcodeAttempts;
	}

	public void setPasscodeAttempts(int passcodeAttempts) {
		this.passcodeAttempts = passcodeAttempts;
	}
	    
}

