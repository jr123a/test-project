package com.ips.bean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.ips.common.common.CustomLogger;

@ManagedBean(name="csmfaSuccess")
@SessionScoped
public class SmfaSuccessBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;
 
    @PostConstruct
    @Override
    public void init() {
        CustomLogger.enter(this.getClass());
    }
    

 }
