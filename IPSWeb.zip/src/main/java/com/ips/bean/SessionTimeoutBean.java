package com.ips.bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.faces.bean.*;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.Utils;
import com.ips.persistence.common.IPSConstants;


@ManagedBean(name="timeout")
@ViewScoped
public class SessionTimeoutBean extends IPSController implements Serializable {

    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    public void logIn() {
    	 List<String> props = new ArrayList<>();
         props.add("com.usps.custreg.LOGIN");
         props = Utils.getProperty(props);
         
         if (!props.isEmpty()) {
             try {
                 String url = props.get(0);
                 CustomLogger.debug(this.getClass(), "Session timeout redirects to LOGIN URL:" + url);
                 FacesContext.getCurrentInstance().getExternalContext().redirect(url);
                 return;
             } catch (IOException e) {
                 CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Can not redirect to CustReg from session timeout page.", e);
             }
         }
         goToPage(SYSTEM_ERROR_PAGE);
    }

    @PreDestroy
    public void destroy(){
        CustomLogger.debug(this.getClass(), "Session Timeout Bean is destroyed.");
    }
    
    @PostConstruct
    public void create(){
        CustomLogger.debug(this.getClass(), "Session timeout Bean is alive.");
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession(false);
        if(session != null){
            session.removeAttribute(IPSConstants.SESSION_TIMEOUT_KEY);//The redirecting attribute
            CustomLogger.debug(this.getClass(), "Removing Session Attribute");
        }else{
            CustomLogger.debug(this.getClass(), "No Session when loading SessionTimeout page");
        }
    }
}
