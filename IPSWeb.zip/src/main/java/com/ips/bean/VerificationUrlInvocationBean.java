package com.ips.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.RpExperianResponsePayload;
import com.ips.persistence.common.PersonVo;
import com.ips.service.RpExperianResponsePayloadService;

@ManagedBean(name="urlInvoke")
@SessionScoped
public class VerificationUrlInvocationBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;
     
    public static String personIdParam;
    public static String bokuAuthenticationUrl;
    public static String bokuCorrelationId;
    public static String bokuReferenceId;
    public static String silentAuthPage;
     
    @PostConstruct
    @Override
    public void init() {
        CustomLogger.enter(this.getClass());
    }
    
    public void invokeBokuUrl() {
        CustomLogger.enter(this.getClass());
        
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession httpSession = request.getSession();
        String resultIdStr = "";
       
        if (httpSession != null) {
        	personVo = getSessionPersonVo();
           	resultIdStr = request.getParameter("resultid");
           	setPhoneNumber(personVo.getMobileNumber()); 
        }

        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        RpExperianResponsePayloadService rpExperianResponsePayloadService = (RpExperianResponsePayloadService)SpringUtil.getInstance(ctx).getBean("rpExperianResponsePayloadService");
        List<RpExperianResponsePayload> responsePayloadList = rpExperianResponsePayloadService.getListByResultIdSequenceIdServiceName(Long.parseLong(resultIdStr), "4", "SilentAuthFlow");
        RpExperianResponsePayload responsePayload = responsePayloadList.isEmpty()? null : responsePayloadList.get(0);
 
        if (responsePayload != null) {
        	String authenticationUrl = responsePayload.getBokuAuthenticationUrl();
        	setBokuAuthenticationUrl(authenticationUrl);
         	setBokuCorrelationId(responsePayload.getRespCorrelationId());
        	setBokuReferenceId(responsePayload.getRespReferenceId());
        }
        
        String contextPath = getHttpServletRequest().getContextPath();
          
        String silentAuthPageUrl = String.format("%s/%s", contextPath, IPSController.VERIFICATION_SILENT_AUTHENTICATION_PAGE);

        setSilentAuthPage(silentAuthPageUrl);
        setPersonIdParam("personid=" + personVo.getId());
        
       	phoneNumber = Utils.formatPhoneNumber(personVo.getPhoneNumber());
    }
    
    @Override
    public String getPhoneNumber() {
        CustomLogger.enter(this.getClass());

        if (phoneNumber == null) {
        	PersonVo personVo = getPersonVo(); 
          	phoneNumber = personVo.getMobileNumber();
        }

        if(phoneNumber != null && phoneNumber.length() > 10 ) {
            phoneNumber = Utils.removeNonNumericCharactersFromString(phoneNumber);
        }
        return phoneNumber;
    }
    
	public String getPhoneNumberFmtd() {
		String  phoneNumberFmtd = Utils.formatPhoneNumber(personVo.getMobileNumber());
		return phoneNumberFmtd;
	}

	public String getPersonIdParam() {
		return personIdParam;
	}

	public void setPersonIdParam(String personIdParam) {
		this.personIdParam = personIdParam;
	}

	public PersonVo getPersonVo() {
		return personVo;
	}

	public void setPersonVo(PersonVo personVo) {
		this.personVo = personVo;
	}

	public String getBokuAuthenticationUrl() {
		return bokuAuthenticationUrl;
	}

	public void setBokuAuthenticationUrl(String bokuAuthenticationUrl) {
		this.bokuAuthenticationUrl = bokuAuthenticationUrl;
	}

	public String getSilentAuthPage() {
		return silentAuthPage;
	}

	public void setSilentAuthPage(String silentAuthPage) {
		this.silentAuthPage = silentAuthPage;
	}

	public String getBokuCorrelationId() {
		return bokuCorrelationId;
	}

	public void setBokuCorrelationId(String bokuCorrelationId) {
		this.bokuCorrelationId = bokuCorrelationId;
	}

	public String getBokuReferenceId() {
		return bokuReferenceId;
	}

	public void setBokuReferenceId(String bokuReferenceId) {
		this.bokuReferenceId = bokuReferenceId;
	}
}
