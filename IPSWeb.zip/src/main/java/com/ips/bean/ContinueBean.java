package com.ips.bean;

import java.io.IOException;
import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.SpringUtil;
import com.ips.entity.RefOtpSupplier;
import com.ips.proofing.ProofingService;
import com.ips.service.RpSmfaInitiateResponseService;

@ManagedBean(name="continueRedirect")
@SessionScoped
public class ContinueBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final String CONTINUE_PARAM = "CONTINUE";
    private String kbaUID = null;
    private String redirectURL = null;

    @PostConstruct
    @Override
    public void init() {
        CustomLogger.enter(this.getClass());
        
    }
    

    public void redirect() {
        CustomLogger.enter(this.getClass());
        boolean foundPerson = false;
        ServletContext context = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        boolean unableToVerify = handleRequestParams();

        if (unableToVerify) {
        	String failureMessage = "Exception occurred fetching existing person.";
        	manageGotoPage(UNABLE_TO_VERIFY_PAGE, failureMessage); 
          	return;
        }
        
        String failureMessage = "";
        // handle continue redirect for secure multi-factor authentication (SMFA)
        if (kbaUID != null) {
        	// add logic to fetch person for kba_uid here
             CustomLogger.info(this.getClass(), "UID passed: " + kbaUID);

            // add logic to fetch redirect url from RP_SMFA_INITIATE_RESPONSE.REDIRECT_URL here
             if (context != null) {
	             try {
	            	 RpSmfaInitiateResponseService rpSmfaInitiateResponseService = (RpSmfaInitiateResponseService)SpringUtil.getInstance(context).getBean(RP_SMFA_INITIATE_RESP_SERVICE);
	                 redirectURL = rpSmfaInitiateResponseService.findRedirectUrl(kbaUID);
	                 CustomLogger.debug(this.getClass(), "redirect URL: " + redirectURL);
	
	             }
	             catch (Exception e) {
	                 failureMessage = "Exception occurred fetching existing person for UID: " + kbaUID;
	                 CustomLogger.error(this.getClass(), failureMessage, e);
	                 
	                 manageGotoPage(UNABLE_TO_VERIFY_PAGE, failureMessage); 
	                 return;
	             }
             }

             if (redirectURL != null) {
            	 foundPerson = true;
             }

            CustomLogger.info(this.getClass(), "foundPerson " + foundPerson);
            
            if (foundPerson) {
                CustomLogger.info(this.getClass(), "Redirecting to the redirectURL if kba_uid is found in the person table: " + redirectURL);
 
                try {
                	FacesContext.getCurrentInstance().getExternalContext().redirect(redirectURL);
                }
                catch (IOException e) {
	                failureMessage = "IOException occurred while redirecting to the redirectURL: " + redirectURL;
                    CustomLogger.error(this.getClass(), failureMessage, e);
                    manageGotoPage(UNABLE_TO_VERIFY_PAGE, failureMessage); 
                }
            }
            else {
                failureMessage = "Redirecting to unable to verify page if kba_uid is not found in the person table: " + kbaUID;
            	// Added logic to redirect to the redirect URL here
            	// if all else fails redirect to the unable to verify page
                CustomLogger.info(this.getClass(), failureMessage);
                manageGotoPage(UNABLE_TO_VERIFY_PAGE, failureMessage); 
            }
        }
   	}
    
    public boolean handleRequestParams() {
    	request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        boolean unableToVerify = false;

        if (session != null) {
            kbaUID = request.getParameter(CONTINUE_PARAM);
            CustomLogger.info(this.getClass(), "CONTINUE request param value: " + kbaUID);
        }  
        
        if (kbaUID == null) {
        	String failureMessage = "Redirecting to unable to verify page if kba_uid is not found in the person table: " + kbaUID;
        	/* Added logic to redirect to the redirect URL here if all else fails redirect to the unable to verify page */
            CustomLogger.info(this.getClass(), failureMessage);
            unableToVerify = true;
        }

        return unableToVerify;
    }

 }
