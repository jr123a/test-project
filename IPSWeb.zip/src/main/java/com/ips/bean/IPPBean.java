package com.ips.bean;


import java.io.Serializable;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.HighRiskAddressAttempt;
import com.ips.entity.IppEvent;
import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefApp;
import com.ips.entity.RefFacFacility;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.entity.RpDeviceReputation;
import com.ips.exception.AMSException;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.NameValueVo;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.UserVo;
import com.ips.polocator.common.IppVo;
import com.ips.polocator.common.LocationVo;
import com.ips.proofing.ProofingService;
import com.ips.proofing.ProofingServiceImpl;
import com.ips.proofing.VerifyAddressService;
import com.ips.proofing.VerifyAddressServiceImpl;
import com.ips.service.DeviceReputationService;
import com.ips.service.HighRiskAddressService;
import com.ips.service.IppEventService;
import com.ips.service.PersonDataService;
import com.ips.service.PersonProofingStatusService;
import com.ips.service.RefAppService;
import com.ips.service.RefRpStatusDataService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;
import com.ips.service.RpDeviceReputationService;
import com.ips.service.RpEfxDitDetailsService;
import com.ips.xml.generated.polocator.Error;
import com.ips.xml.generated.polocator.Location;

@ManagedBean(name="ippBean")
@ViewScoped
public class IPPBean extends IPSController implements Serializable {

    private static final long serialVersionUID = 1L;
    private UserVo user;
    private IppVo ippVo;
    private PersonVo personVo;
    private ServletContext servletCtx;
    private ProofingService proofingService;
    private IppEventService ippEventService;
    private PersonDataService personDataService;
    private transient List<Object> poLocations;
    private List<RefFacFacility> facilities;
    private List<LocationVo> locsVo;
    private boolean poListEmpty = false;
    private boolean poListError = false;
    private String searchZipCode;
    
    private boolean emailSent;
    private boolean emailAndRetry;
    private boolean btnContinue;
    private boolean instructions;
    private boolean intro;
    private boolean facSuccess;
    private boolean note;
    private boolean btnCancel;
    private boolean btnEmail2;
    private boolean allowOnlineRetry;
    
    @PostConstruct
    public void init(){            
        CustomLogger.enter(this.getClass());
        
        // Handle login in after page refresh
        verifyUserSessionData();
        
        servletCtx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(servletCtx);
        
        if (webAppCtx != null) {          
	        proofingService = webAppCtx.getBean(PROOFING_SERVICE, ProofingServiceImpl.class);
	        
	        user = getSessionUser();
	        ippVo = proofingService.getIppPageUserInfo(user);
	        personVo = getSessionPersonVo();
	        poLocations = getSessionFilteredPOList();
	
	        // Store record locator in session
	        HttpSession session = getHttpServletRequest().getSession();
	        session.setAttribute("recordLocator", ippVo.getRecordLocator());
	        
	        setAllowOnlineRetry(allowOnlineVerificationRetry());
        }
    }
    
    /**
     * Put this in a separate method rather than init so that the routing to the 
     * System error page will work.
     */
    public void checkForObjects() {
        CustomLogger.enter(this.getClass());
        StringBuilder sb = new StringBuilder("Phone");
        StringBuilder sb2 = new StringBuilder("OTP");
        StringBuilder sb3 = new StringBuilder("New");
        // Handle login in after page refresh
        verifyUserSessionData();
         
        WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(servletCtx);
      
        
        if(user == null){
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Cannot load user info");
            goToPage(SYSTEM_ERROR_PAGE);
        }
        
        if(ippVo.getStatus() != null){
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Cannot get Status from VO");
            goToPage(SYSTEM_ERROR_PAGE);
        }
        
        if (webAppCtx != null) {          
        	VerifyAddressService verifyAddressService = webAppCtx.getBean(VERIFY_ADDRESS_SERVICE,VerifyAddressServiceImpl.class);       
	        if (poLocations == null) {
	            CustomLogger.debug(this.getClass(), "poLocations is null, call PO Locator.");
	            searchByAddress();
	            processPOLocatorResponse(verifyAddressService, poLocations);
	        } else {
	            CustomLogger.debug(this.getClass(), "poLocations is not null.");
	            processPOLocatorResponse(verifyAddressService, poLocations);
	        }
        }
        
      	PersonProofingStatusService personProofingStatusService = (PersonProofingStatusService)SpringUtil.getInstance(ctx).getBean(PERSON_PROOFING_STATUS_SERVICE);
      	PersonDataService personDataService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);

        Person existingPerson = personDataService.findExistingPerson(RefSponsor.SPONSOR_ID_CUSTREG, user.getSponsorUserId());

        if (existingPerson != null) {
            PersonProofingStatus proofingStatus = personProofingStatusService.getByPersonId((int)existingPerson.getPersonId());

        	if (proofingStatus != null) {
        		if (proofingStatus.getRefRpStatus().getStatusDescription() != user.getStatus() || proofingStatus.getRefRpStatus().getStatusCode() != user.getStatusCode()) {
        			ProofingService proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
        			
        			RefRpStatusDataService refRpStatusDataService = (RefRpStatusDataService)SpringUtil.getInstance(ctx).getBean(REF_RP_STATUS_DATA_SERVICE); 
        			RefRpStatus refRpStatus = refRpStatusDataService.findByDescription(user.getStatus());
        			        			
        			proofingService.updateProofingStatus(refRpStatus.getStatusCode(), existingPerson, user.getLoaSought());
        			user.setStatusCode(refRpStatus.getStatusCode());
        			user.setStatus(refRpStatus.getStatusDescription());
            	}
        	}
        }

        CustomLogger.debug(this.getClass(), "User status in createObject: " + user.getStatus());
        
        // display the correct IPP page
        if(IPSConstants.STATUS_IPP_OPT_IN.equalsIgnoreCase(user.getStatus())){
            if(poListEmpty){
                displayFacListEmptyPage();
            } else{
                displayFacListNotEmptyPage();
            }
        } else if(IPSConstants.STATUS_IPP_EMAIL_SENT.equalsIgnoreCase(user.getStatus())){
        	boolean hasDisplay = false;
          	 if (webAppCtx != null) { 
        		  // To handle previous issue of IppEvent not created
          		 personDataService = (PersonDataService)SpringUtil.getInstance(servletCtx).getBean(PERSON_DATA_SERVICE);
          		 Person person = null;
           		 personVo = getSessionPersonVo();
           		 
           		 if (personVo != null) {
           			 person = personDataService.findByPK(personVo.getId());
              	 } else {
            		 person = personDataService.findExistingPerson(RefSponsor.SPONSOR_ID_CUSTREG, user.getSponsorUserId());
       			 }
         
           		 if (person != null) {
          			  ippEventService = (IppEventService)SpringUtil.getInstance(servletCtx).getBean(IPP_EVENT_SERVICE);
	           		  IppEvent existingIppEvent = ippEventService.findIppEventByPersonId(person.getPersonId());
	           		  hasDisplay = true;
	           		  
	           		  if (existingIppEvent == null) {
	           			 if(poListEmpty){
	                         displayFacListEmptyPage();
	                     } else{
	                         displayFacListNotEmptyPage();
	                     }
	           		  }
	           		  else {
	           			displayFullIppPage();
	           		  }
           		  }
           	  }
          	 
          	 if (!hasDisplay) {
          		displayFullIppPage();
          	 }
        } else if(IPSConstants.STATUS_ERROR.equalsIgnoreCase(user.getStatus())){
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "User status retuned Error");
            goToPage(SYSTEM_ERROR_PAGE);
        }else if(user.getStatus().contains(sb) || user.getStatus().contains(sb2)|| user.getStatus().contains(sb3)){
            displayFacListNotEmptyPage();
        }
    }
    
    public void requestNewEmail(){            
        try {
            user = proofingService.resendIPPEmail(user, locsVo, poListError);
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Exception occured while sending IPP email for sponsorUserId:" + user.getSponsorUserId(), e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
        
        if(IPSConstants.STATUS_IPP_EMAIL_SENT.equalsIgnoreCase(user.getStatus())){
            user.setIPPemailSent(true);
        } else if(IPSConstants.STATUS_IPP_OPT_IN.equalsIgnoreCase(user.getStatus())){
            user.setIPPemailSent(false);
            user.setStatus(IPSConstants.STATUS_IPP_EMAIL_SENT);
        }
        setSessionFilteredPOList(poLocations);
        setSessionUser(user);
        if(IPSConstants.STATUS_ERROR.equalsIgnoreCase(user.getStatus())){
            routeUser(user);
        }
    }
    
    public void retryRp(){
        try {
            user = proofingService.retryRemoteProofing(user);
        } 
        catch (Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred on retry remote proofing for sponsorUserId: ." + user.getSponsorUserId(), e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
        
        user.setIPPemailSent(false);
        setSessionUser(user);
        routeUser(user);
    }

    public void searchByZipCode(){
        CustomLogger.enter(this.getClass(), String.format("searchZipCode:%s",  searchZipCode));
        poListError = false;
        user.setIPPemailSent(false);
        
        RefSponsorDataService refSponsorService = (RefSponsorDataService)SpringUtil.getInstance(servletCtx).getBean(REF_SPONSOR_DATA_SERVICE);
        RefSponsorConfigurationService refSponsorConfigService = (RefSponsorConfigurationService)SpringUtil.getInstance(servletCtx).getBean(REF_SPONSOR_CNFIG_SERVICE);
        
        // This method is only called from the front end so Sponsor will be CustReg
        RefSponsor sponsor = refSponsorService.findByPK(RefSponsor.SPONSOR_ID_CUSTREG);
        // ippVo should not be recreated - important information is set on the Vo in 
        // the getIppPageUserInfo method of ProofingServiceImpl
        ippVo.setSponsorId(sponsor.getSponsorId());
        ippVo.setSponsorCustReg(sponsor.isCustomerRegistration());
        ippVo.setSponsorActiveIppClient(sponsor.isIppClientActive());
        ippVo.setSponsorUsingFacilitySubList(sponsor.isClientUsingFacilitySublist());
        //Added for IAL2 transactions
        RefSponsorConfiguration optionEnabled = refSponsorConfigService.getConfigRecord((int) sponsor.getSponsorId(),
                RefSponsorConfiguration.IAL2_REQUIRED);
        if(optionEnabled!=null && optionEnabled.getValue()!=null) {
            ippVo.setIal2Transaction(optionEnabled.getValue());
        } else {
            ippVo.setIal2Transaction("");    
        }
        
        WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(servletCtx);

        if (webAppCtx != null) {
        	VerifyAddressService verifyAddressService = webAppCtx.getBean(VERIFY_ADDRESS_SERVICE,VerifyAddressServiceImpl.class);
	        try {
	            poLocations = verifyAddressService.getFilteredPOListByZipCode(ippVo, searchZipCode);
	        } catch (AMSException e) {
	            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred when getting PO Locations by ZIP Code.",e);
	            goToPage(SYSTEM_ERROR_PAGE);
	        }
        }
    }

    public void searchByAddress(){
        poListError = false;
        user.setIPPemailSent(false);

        WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(servletCtx);

        if (webAppCtx != null) {
	        VerifyAddressService verifyAddressService = webAppCtx.getBean(VERIFY_ADDRESS_SERVICE,VerifyAddressServiceImpl.class);
	
	        try {
	            poLocations = verifyAddressService.getFilteredPOList(ippVo);
	        } catch (AMSException e) {
	            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred when getting PO Locations by Address for sponsorUserId:" + user.getSponsorUserId(), e);
	            goToPage(SYSTEM_ERROR_PAGE);
	        }
        }
    }
    
    public void processPOLocatorResponse(VerifyAddressService verifyAddressService, List<Object> poLocatortList) {
        List<Location> locationList = new ArrayList<>();
        
        for (Object obj : poLocatortList) {
            if (obj != null) {
                if (obj instanceof Location) {
                    locationList.add((Location) obj);
                    poListError = false;
                } else {
                    if (obj instanceof Error) {
                        poListError = true;
                        break;
                    }
                }
            }
        }
        CustomLogger.debug(this.getClass(), "PO Locations Count = " + locationList.size());

        // Get LocationVo
        try {
            locsVo = verifyAddressService.getLocationVo(locationList);
            poListEmpty = locsVo.isEmpty();
        } catch (ParseException e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred when parsing.", e);
            goToPage(SYSTEM_ERROR_PAGE);
        } catch (Exception e){
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred when processing the response.", e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }
    
    public void continueToIPP(){
        CustomLogger.enter(this.getClass());
         
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        
        // Retrieve the high risk address attempt if one was created in this session
        HighRiskAddressAttempt attempt = null;
        
        // Retrieve the sponsor app if one was created in this session
        RpDeviceReputation deviceReputation = null;
                
        HighRiskAddressService highRiskAddressService = (HighRiskAddressService)SpringUtil.getInstance(servletCtx).getBean(HIGH_RISK_ADDRESS_SERVICE);
        
        if (personVo != null) {
            if (personVo.getHighRiskAttemptId() != 0) {
                attempt = highRiskAddressService.findHighRiskAttempt(personVo.getHighRiskAttemptId());
            }
            
            //Device Reputation
            DeviceReputationService deviceReputationService = (DeviceReputationService)SpringUtil.getInstance(servletCtx).getBean(DEVICE_REPUTATION_SERVICE);
            String callingAppName = getSessionCallingAppName();
            boolean isDeviceProfilingEnabled = deviceReputationService.isDeviceProfilingEnabled(personVo.getId(), personVo.getSponsorId(), callingAppName, false);
            
            if (isDeviceProfilingEnabled) {        
                PersonDataService personService = (PersonDataService)SpringUtil.getInstance(servletCtx).getBean(PERSON_DATA_SERVICE);
                RpDeviceReputationService rpDeviceReputationService = (RpDeviceReputationService)SpringUtil.getInstance(servletCtx).getBean(RP_DEVICE_REPUTATION_SERVICE);
                Person person = personService.findByPK(personVo.getId());
                if (person != null) {
                  	String appName = personVo.getCallingAppName();
         
		        	if (!Utils.isEmptyString(personVo.getCallingAppName()))  {
                		if (IPSConstants.HOLD_MAIL.equalsIgnoreCase(appName)) {
                			appName = RefApp.HOLD_MAIL;
                		}
                	}
                	else {
                		appName = RefApp.INFORMED_DELIVERY;
                	}
		        	
                    WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(servletCtx);

		        	if (webAppCtx != null) {
	                	RefAppService refAppService = webAppCtx.getBean(RefAppService.class);
	                	RefApp refApp = refAppService.findByAppName(appName);
	                    deviceReputation = rpDeviceReputationService.getByPersonAndAppId(person.getPersonId(), refApp.getAppId());
		        	}
                }
            }
        }
        
        try {
            if (user != null) {
                CustomLogger.debug(this.getClass(), "user.getStatus() = " + user.getStatus());
            } else {
                CustomLogger.debug(this.getClass(), "user is null!");
            }

            user = proofingService.confirmOptIn(user, attempt, deviceReputation);
            
            CustomLogger.debug(this.getClass(), "User status in Continue to IPP: " + user.getStatus());
            // To handle browser page refresh, display full IPP page if user 
            // already opted in (i.e user rp status is 5 - In-person email sent)
            if(IPSConstants.STATUS_IPP_EMAIL_SENT.equalsIgnoreCase(user.getStatus())){
                displayFullIppPage();
            }
            
            ippVo =  proofingService.getIppPageUserInfo(user);
            setSessionUser(user);
            // Store record locator in session
            session.setAttribute("recordLocator", ippVo.getRecordLocator());
        } catch (Exception e) {
            if (user != null) {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error Opting In for sponsorUserId:" + user.getSponsorUserId(), e);
            } else {
                CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error Opting In for user, user is null");
            }
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }
    
    private void displayFacListEmptyPage(){
        CustomLogger.enter(this.getClass());
        emailSent = false;
        emailAndRetry = false;
        btnContinue = false;
        instructions = false;
        intro = false;
        facSuccess = false;
        note = false;
        btnCancel = true;
        user = getSessionUser();
        btnEmail2 = false;
    }
    
    private void displayFacListNotEmptyPage(){
        CustomLogger.enter(this.getClass());
        emailSent = false;
        emailAndRetry = false;
        btnContinue = true;
        instructions = false;
        intro = true;
        facSuccess = true;
        note = false;
        btnCancel = true;
        user = getSessionUser();
        btnEmail2 = false;
    }
    
    private void displayFullIppPage(){
        CustomLogger.enter(this.getClass());
        emailSent = true;
        user = getSessionUser();
        emailAndRetry = isAllowOnlineRetry();
        btnContinue = false;
        instructions = true;
        intro = true;
        facSuccess = false;
        note = true;
        btnCancel = false;
        btnEmail2 = true;
    }
    
    private boolean allowOnlineVerificationRetry() {
    	/**
    	 * Check Equifax DIT Decision Deny only for Equifax 2.0 and not Lexis Nexis RDP or Equifax IDFS
    	 */
    	if (equifaxDITSupplier()) {
    		return !isHighRisk() && !isLowReputation() && !isEquifaxDITDecisionDeny() && !user.isRedirectFromCustReg();
    	}
        else
        {
        	return !isHighRisk() && !isLowReputation() && !user.isRedirectFromCustReg();
        }
    }
    
    private boolean equifaxDITSupplier() {
		return RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_NAME.equalsIgnoreCase(personVo.getPhoneVerificationSupplierName());
	}

	private boolean isHighRisk() {
        return personVo != null && personVo.getHighRiskAttemptId() != 0;
    }

    private boolean isLowReputation() {
        DeviceReputationService deviceReputationService = (DeviceReputationService)SpringUtil.getInstance(servletCtx).getBean(DEVICE_REPUTATION_SERVICE);
        return deviceReputationService.isLowDeviceReputation(personVo);
    }
    
    private boolean isEquifaxDITDecisionDeny() {
        RpEfxDitDetailsService ditDetailsService = (RpEfxDitDetailsService)SpringUtil.getInstance(servletCtx).getBean(RP_EFX_DIT_DETAILS_SERVICE);
        return ditDetailsService.isEquifaxDITDecisionDeny(personVo.getId());
    }
    
    public UserVo getUser() {
        return user;
    }

    public void setUser(UserVo user) {
        this.user = user;
    }

    public IppVo getIppVo() {
        return ippVo;
    }

    public void setIppVo(IppVo ippVo) {
        this.ippVo = ippVo;
    }

    public PersonVo getPersonVo() {
		return personVo;
	}

	public void setPersonVo(PersonVo personVo) {
		this.personVo = personVo;
	}

	public ServletContext getServletCtx() {
		return servletCtx;
	}

	public void setServletCtx(ServletContext servletCtx) {
		this.servletCtx = servletCtx;
	}

    public List<RefFacFacility> getFacilities() {
        return facilities;
    }

    public void setFacilities(List<RefFacFacility> facilities) {
        this.facilities = facilities;
    }

    public List<LocationVo> getLocsVo() {
        return locsVo;
    }

    public void setLocsVo(List<LocationVo> locsVo) {
        this.locsVo = locsVo;
    }

    public boolean isPoListEmpty() {
        return poListEmpty;
    }

    public void setPoListEmpty(boolean poListEmpty) {
        this.poListEmpty = poListEmpty;
    }

    public boolean isPoListError() {
        return poListError;
    }

    public void setPoListError(boolean poListError) {
        this.poListError = poListError;
    }

    public String getSearchZipCode() {
        return searchZipCode;
    }

    public void setSearchZipCode(String searchZipCode) {
        this.searchZipCode = searchZipCode;
    }

    public boolean isEmailSent() {
        return emailSent;
    }

    public void setEmailSent(boolean emailSent) {
        this.emailSent = emailSent;
    }

    public boolean isEmailAndRetry() {
        return emailAndRetry;
    }

    public void setEmailAndRetry(boolean emailAndRetry) {
        this.emailAndRetry = emailAndRetry;
    }

    public boolean isBtnContinue() {
        return btnContinue;
    }

    public void setBtnContinue(boolean btnContinue) {
        this.btnContinue = btnContinue;
    }

    public boolean isInstructions() {
        return instructions;
    }

    public void setInstructions(boolean instructions) {
        this.instructions = instructions;
    }

    public boolean isIntro() {
        return intro;
    }

    public void setIntro(boolean intro) {
        this.intro = intro;
    }

    public boolean isFacSuccess() {
        return facSuccess;
    }

    public void setFacSuccess(boolean facSuccess) {
        this.facSuccess = facSuccess;
    }

    public boolean isNote() {
        return note;
    }

    public void setNote(boolean note) {
        this.note = note;
    }

    public boolean isBtnCancel() {
        return btnCancel;
    }

    public void setBtnCancel(boolean btnCancel) {
        this.btnCancel = btnCancel;
    }

    public boolean isBtnEmail2() {
        return btnEmail2;
    }

    public void setBtnEmail2(boolean btnEmail2) {
        this.btnEmail2 = btnEmail2;
    }

	public boolean isAllowOnlineRetry() {
		return allowOnlineRetry;
	}

	public void setAllowOnlineRetry(boolean allowOnlineRetry) {
		this.allowOnlineRetry = allowOnlineRetry;
	}

	public ProofingService getProofingService() {
		return proofingService;
	}

	public void setProofingService(ProofingService proofingService) {
		this.proofingService = proofingService;
	}
}
