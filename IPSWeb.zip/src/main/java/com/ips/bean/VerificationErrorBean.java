package com.ips.bean;

import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.entity.RefRpStatus;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.UserVo;
import com.ips.polocator.common.AppointmentVo;
import com.ips.polocator.common.LocationVo;
import com.ips.proofing.ProofingService;
import com.ips.proofing.ProofingServiceImpl;
import com.ips.proofing.VerifyAddressService;
import com.ips.proofing.VerifyAddressServiceImpl;
import com.ips.xml.generated.polocator.Error;
import com.ips.xml.generated.polocator.Location;


@ManagedBean(name="verificationError")
@ViewScoped
public class VerificationErrorBean extends IPSController implements Serializable{
    private static final long serialVersionUID = 1L;
    private static Properties props;
    private UserVo user;
    private boolean poListEmpty = false;
    private boolean errorConnect = false;
    private boolean errorUnabletoVerify = false;
    private boolean errorAttemptTooSoon = false;
    private boolean errorContinueToIPP = false;
    private boolean ippAtFacility = Boolean.parseBoolean(props.getProperty("facility_ipp_active"));
    private boolean ippAtResidence = Boolean.parseBoolean(props.getProperty("residence_ipp_active"));
    
    static {
        props = new Properties();
        try {
             props.load(VerificationErrorBean.class.getResourceAsStream("/ips.properties"));
        } catch (IOException e) {
            CustomLogger.error(VerificationErrorBean.class.getClass(), "Error occurred loading ips.properties file ", e);
        }
    }
    
    @PostConstruct
    public void init(){
        // Handle login in after page refresh
        verifyUserSessionData();
                
        user = getSessionUser();
    }
        
    /**
     * Put this in a separate method rather than init so that the routing to the 
     * System error page will work.
     */
    public void checkForObjects() {
        if(user == null){
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "No user was present in session.");
            goToPage(SYSTEM_ERROR_PAGE);
            return;
        }
        
        // Look up user PO Facilities, but make POLocator call once
        CustomLogger.debug(this.getClass(), "ippAtFacility init = " + ippAtFacility + ", ippAtResidence init = " + ippAtResidence);
        boolean facilitiesFound = false;
        if (ippAtFacility || ippAtResidence) {
            facilitiesFound = !isUserFilteredPOListEmpty();
        }
        
        ippAtFacility = (ippAtFacility && facilitiesFound);
        ippAtResidence = (ippAtResidence && facilitiesFound);
        CustomLogger.debug(this.getClass(), "facilitiesFound = " + facilitiesFound + ", ippAtFacility = " + ippAtFacility + ", ippAtResidence = " + ippAtResidence);
    }
    
    public void returnToCodeViaMailPage() {
        goToCodeViaMailRegPage();
    }

    private boolean isUserFilteredPOListEmpty(){
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
 	 	WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);
   
    	if (webAppCtx != null) {
	        try {
	            ProofingService service = webAppCtx.getBean(PROOFING_SERVICE, ProofingServiceImpl.class);
	          	VerifyAddressService verifyAddressService = webAppCtx.getBean(VERIFY_ADDRESS_SERVICE,VerifyAddressServiceImpl.class);

	            user = service.getUserFilteredPOList(user);
	            List<Object> filteredPOList = user.getFilteredPOList();
	            setSessionFilteredPOList(filteredPOList);
	           
	           	processPOLocatorResponse(verifyAddressService, filteredPOList);
	         }
	        catch (Exception e) {
	            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred on getUserFilteredPOList for sponsorUserId: " 
	                    + (user != null ? user.getSponsorUserId() : "user is null"), e);
	            goToPage(SYSTEM_ERROR_PAGE);
	        }
    	}
     
        return poListEmpty;
    }
    
    public void processPOLocatorResponse(VerifyAddressService verifyAddressService, List<Object> poLocatortList) {
        List<Location> locationList = new ArrayList<>();
        
        for (Object obj : poLocatortList) {
            if (obj != null) {
                if (obj instanceof Location) {
                    locationList.add((Location) obj);
                } else {
                    if (obj instanceof Error) {
                        break;
                    }
                }
            }
            else {
                locationList.add(null);
            }
        }
        CustomLogger.debug(this.getClass(), "PO Locations Count = " + locationList.size());

        // Get LocationVo
        try {
            List<LocationVo> locsVo = verifyAddressService.getLocationVo(locationList);
            poListEmpty = locsVo.isEmpty();
        } catch (ParseException e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred when parsing.", e);
            goToPage(SYSTEM_ERROR_PAGE);
        } catch (Exception e){
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred when processing the response.", e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }
    
    public void optInToIpp(){
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
	 	WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);

	 	if (webAppCtx != null) {
	        ProofingService service = webAppCtx.getBean(PROOFING_SERVICE, ProofingServiceImpl.class);
	        
	        try {
	            user = service.optInToIpp(user);
	            setSessionUser(user);
	            routeUser(user);
	        }
	        catch (Exception e) {
	            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred on opt-in to IPP for sponsorUserId: " + user.getSponsorUserId(), e);
	            goToPage(SYSTEM_ERROR_PAGE);
	        }
	 	}
    }
    
    public void optInToIppResidence(){
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
	 	WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);

	 	if (webAppCtx != null) {
	        ProofingService service = webAppCtx.getBean(PROOFING_SERVICE, ProofingServiceImpl.class);        
	        AppointmentVo appointment = service.findAddressOnFile(user);    
	        
	        setSessionAppointment(appointment);
	        CustomLogger.error(this.getClass(), "VerificationErrorBean.Appointment saved in session for sponsorUserId:" + user.getSponsorUserId() + " Scheduled Date "+appointment.getScheduledDate()+" and Scheduled Time "+appointment.getScheduledTime());
	        
	        service.updateProofingStatus(RefRpStatus.RpStatus.IPP_at_residence_scheduled.getValue(), user);
	        
	        goToPage(ADDRESS_CONFIRMATION_PAGE);
	 	}
    }
    
    public UserVo getUser() {
        return user;
    }

    public void setUser(UserVo user) {
        this.user = user;
    }

    public boolean isErrorConnect() {
        return errorConnect;
    }

    public void setErrorConnect(boolean errorConnect) {
        this.errorConnect = errorConnect;
    }

    public boolean isErrorUnabletoVerify() {    
        return errorUnabletoVerify;
    }

    public void setErrorUnabletoVerify(boolean errorUnabletoVerify) {
        this.errorUnabletoVerify = errorUnabletoVerify;
    }

    public boolean isErrorAttemptTooSoon() {
        return errorAttemptTooSoon;
    }

    public void setErrorAttemptTooSoon(boolean errorAttemptTooSoon) {
        this.errorAttemptTooSoon = errorAttemptTooSoon;
    }

    public boolean isErrorContinueToIPP() {
        return errorContinueToIPP;
    }

    public void setErrorContinueToIPP(boolean errorContinueToIPP) {
        this.errorContinueToIPP = errorContinueToIPP;
    }

    public boolean isIppAtFacility() {
        return ippAtFacility;
    }

    public void setIppAtFacility(boolean ippAtFacility) {
        this.ippAtFacility = ippAtFacility;
    }

    public boolean isIppAtResidence() {
        return ippAtResidence;
    }

    public void setIppAtResidence(boolean ippAtResidence) {
        this.ippAtResidence = ippAtResidence;
    }
    
    public boolean isPoListEmpty() {
        return poListEmpty;
    }

    public void setPoListEmpty(boolean poListEmpty) {
        this.poListEmpty = poListEmpty;
    }
}
