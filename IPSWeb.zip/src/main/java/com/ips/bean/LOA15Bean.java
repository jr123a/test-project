package com.ips.bean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.Utils;
import com.ips.persistence.common.IPSConstants;

@ManagedBean(name="loa15")
@ViewScoped
public class LOA15Bean extends IPSController implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private static final String APP_ID_PARAM = "appID";
    private static final String APP_URL_PARAM = "appURL";
    private static final String CALLING_APP_NAME_PARAM = "app";
    
    @PostConstruct
    public void init() {
        handleRequestParams();
    }
    
    public void handleRequestParams() {
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession session = request.getSession();
        
        String callingAppID = null;
        String callingAppURL = null;
        String callingAppName = null;

        if (session != null) {
            callingAppID = request.getParameter(APP_ID_PARAM);
            callingAppURL = request.getParameter(APP_URL_PARAM);
            callingAppName = request.getParameter(CALLING_APP_NAME_PARAM);
            
            if (callingAppURL != null) {
                if (Utils.isValidURL(callingAppURL)) {
                    CustomLogger.info(this.getClass(), "appURL value: " + callingAppURL);
                    CustomLogger.info(this.getClass(), "callingAppID value: " + callingAppID);
                    CustomLogger.info(this.getClass(), "callingAppName value: " + callingAppName);
                    setSessionCallingApp(callingAppURL);
                }else{
                    CustomLogger.warn(this.getClass(), "WARNING: Invalid appURL supplied: " + callingAppURL);
                }
            }
            
            if (callingAppName != null) {
                CustomLogger.debug(this.getClass(), "app value: " + callingAppName);
                setSessionCallingAppName(callingAppName);
            }

            if (callingAppID != null) {
                CustomLogger.debug(this.getClass(), "appID value: " + callingAppID);
                session.setAttribute(IPSConstants.CALLING_APP_ID_KEY, callingAppID);
            }
        }
    }
    
    public void routeUser(){
        goToPage(LOA15_REDIRECTION);
    }

}
