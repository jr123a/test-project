package com.ips.bean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.equifax.smfa.response.ResponseStatusModel;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.SpringUtil;
import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.proofing.EquifaxService;
import com.ips.proofing.EquifaxServiceImpl;
import com.ips.proofing.ProofingService;
import com.ips.proofing.ProofingServiceImpl;
import com.ips.service.PersonDataService;
import com.ips.service.PersonProofingStatusService;
import com.ips.service.RefLoaLevelService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;

import io.jsonwebtoken.io.IOException;

@ManagedBean(name="validateEquifaxSmfaGreen")
@SessionScoped
public class ValidateEquifaxSmfaGreenBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private RefLoaLevelService refLoaLevelService;
    private PersonProofingStatusService personProofingStatusService;
    private String linkValidationStatus;
    
    public void processColor() {
        CustomLogger.enter(this.getClass());
  
        ServletContext context = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        personProofingStatusService = (PersonProofingStatusService)SpringUtil.getInstance(context).getBean(PERSON_PROOFING_STATUS_SERVICE);
        PersonProofingStatus personProofingStatus = personProofingStatusService.getByPersonId((int)getPersonVo().getId());
        
        Long proofingStatusCode = RefRpStatus.RpStatus.LOA_level_achieved.getValue();  	 
   	 	String loaSought = personVo.getProofingLevelSought();
 
        if (personProofingStatus != null && !personProofingStatus.getStatusCode().equals(proofingStatusCode)) {
     		ProofingService proofingService = (ProofingService)SpringUtil.getInstance(context).getBean(PROOFING_SERVICE);
            proofingService.updateProofingStatus(proofingStatusCode, person, loaSought);
        }
        
        if(isHoldMail) {
            CustomLogger.debug(this.getClass(), "SMFA link successfully validated, return to calling app and Calling app is " + callingAppName);
            returnToCallingApp(IPSConstants.PROOFING_RESULT_PASSED);
        } else {
        	// clear error message from prior failures if successful  
        	setSessionVerifyPhoneError(null);
        	goToInformedDeliverySuccessPage();
        }
   	}
     
	public String getLinkValidationStatus() {
		return linkValidationStatus;
	}

	public void setLinkValidationStatus(String linkValidationStatus) {
		this.linkValidationStatus = linkValidationStatus;
	}

	
	public void redirectToUnableToVerify() {
        CustomLogger.enter(this.getClass());
        goToPage(UNABLE_TO_VERIFY_PAGE);
	}
	
    public String getMaskedPhoneNumberForUI() {
    	return this.getVerificationMaskedPhoneNumberForUI();
    }
	
	public void continueToSuccessPage() {
		returnToCallingApp(IPSConstants.PROOFING_RESULT_PASSED);
	}

}
