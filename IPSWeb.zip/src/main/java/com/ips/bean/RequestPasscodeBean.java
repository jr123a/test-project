package com.ips.bean;

import java.io.IOException;
import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.JSFUtils;
import com.ips.common.common.SpringUtil;
import com.ips.entity.Person;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RpEvent;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.proofing.PhoneVerificationService;
import com.ips.proofing.PhoneVerificationServiceImpl;
import com.ips.proofing.ProofingService;
import com.ips.service.OtpVelocityCheckService;
import com.ips.service.PersonDataService;
import com.ips.service.RefOtpSupplierDataService;
import com.ips.service.RpEventDataService;

@ManagedBean(name="requestpasscode")
@SessionScoped
public class RequestPasscodeBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private String passcodeSentMessage;   
    private long phoneVerificationAttemptCount = 0;
    private long otpOrSmfaRequestAttemptCount = 0;
    
    public void checkErrorMessage() {
        String sessionVerifyPhoneError = getSessionVerifyPhoneError();
        if (StringUtils.isEmpty(sessionVerifyPhoneError)) {
        	this.setError(false);
        	this.setErrorMessage(null);
        	
        	PersonVo personVo = getSessionPersonVo();
          	setPhoneVerificationAttemptCount(personVo.getPhoneVerificationAttemptCount());
        	setOtpOrSmfaRequestAttemptCount(personVo.getOtpOrSmfaRequestAttemptCount());
        }
        else {
        	this.setError(true);
        	this.setErrorMessage(sessionVerifyPhoneError);
        	setSessionVerifyPhoneError(null);
        }
        
    	PersonVo personVo = getSessionPersonVo();
    	if (personVo != null) {
    		setPhoneVerificationAttemptCount(personVo.getPhoneVerificationAttemptCount());
    		setOtpOrSmfaRequestAttemptCount(personVo.getOtpOrSmfaRequestAttemptCount());
    	}
    }
    
    public void sendPasscodeToPhone() throws Throwable {
        CustomLogger.enter(this.getClass());
        
        // Clear out previous passcode error messages
        ConfirmPasscodeBean confirmPasscode = JSFUtils.getManagedBean("confirmpasscode");
        confirmPasscode.setErrorMessage(null);
        // clear the "A new code has been sent to your mobile device" message 
        ResendPasscodeBean resendPasscode = JSFUtils.getManagedBean("resendpasscode");
        resendPasscode.resetBeanValue();
        this.passcodeAttempts = 0;

        setPersonVo(getSessionPersonVo());
        
        // If the user comes directly to this page the phone number must be retrieved from the database
        getSavedPhone();
        
        //get Services from Spring application context
        
        ServletContext ctx = (ServletContext)FacesContext.getCurrentInstance().getExternalContext().getContext();
        RpEventDataService rpEventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        PersonDataService personDataService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
        RefOtpSupplier phoneSupplier = rpEventService.getLatestPhoneSupplier(getSessionPersonVo());
        CustomLogger.debug(this.getClass(), "RequestPasscodeBean phoneSupplier returned: " + phoneSupplier.getOtpSupplierId() );

        // Only generate new passcode if user has not exceeded passcode attempts limit
        PersonVo personVo = getPersonVo();
		setSessionOtpSmfaAttempts(0);
		Person person = personDataService.findByPK(personVo.getId());
		
		boolean exceededPasscodeAttemptsLimit = exceededPasscodeAttemptsLimit(person, personVo, phoneSupplier);
        setSessionPersonVo(personVo);

        if (exceededPasscodeAttemptsLimit) {
        	setSessionPersonVo(personVo);
            String logMsg = String.format("The User has exceeded passcode attempts limit for sponsorUserId: %s.", getPersonVo().getSponsorUserId());
            manageGotoPage(VERIFICATION_LOCKOUT, logMsg);          
        }
        else {
            ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
           
            boolean sendPasscodeSuccessful = false;
            
            try {
            	 WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);

             	if (webAppCtx != null) {
             		PhoneVerificationService phoneVerificationService = webAppCtx.getBean(PHONE_VERIFICATION_SERVICE, PhoneVerificationServiceImpl.class);
               		sendPasscodeSuccessful = phoneVerificationService.sendPasscodeSuccessful(personVo, phoneSupplier);
             	}
             	
                if (sendPasscodeSuccessful) {
                	setPasscodeSentMessage("A code has been sent to your mobile device!");
                	CustomLogger.debug(this.getClass(), "Transaction processed successfully");
                }
                else {
	                if (!StringUtils.isEmpty(personVo.getErrorMessage())) {
	                	setSessionVerifyPhoneError(personVo.getErrorMessage());
	                	if (personVo.isOtpSmsLandline()) {
	               			// This handles land lines. Latest verbiage from Human Factors:
	            			// Unfortunately, we were not able to verify your identity with the information you entered. Landline numbers are not supported. Please enter a mobile phone number or cancel Online Mobile Phone Verification.
	            			// During testing we determined that 422s are land lines
	            			CustomLogger.error(this.getClass(), "Landline numbers are not supported.");
	                        setSessionVerifyPhoneError(IPSConstants.UNABLE_TO_VERIFY_LANDLINE_MSG);
	                      	personVo.setRenderErrorMessage(true);
	                  		setSessionPersonVo(personVo);

	                  		goToPage(isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : VERIFICATION_USER_INFO_PAGE);
	                		return;
	                	}
	                	else {
	                		setSessionVerifyPhoneError(personVo.getErrorMessage());
	                		manageGotoPage(VERIFICATION_REQUEST_PASSCODE_PAGE, personVo.getErrorMessage()); 
		                	return;
	                	}
	                }
                } 
            } catch (PhoneVerificationException e) {
                String errorMsg = String.format("PhoneVerificationException occurred during send passcode for sponsorUserId: %s.", getPersonVo().getSponsorUserId());
                manageGotoPage(VERIFICATION_CANCEL_CONFIRMED, errorMsg);          
            } catch (IPSException e) {
                String errorMsg = String.format("Error sending passcode for sponsorUserId: %s.", getPersonVo().getSponsorUserId());
                manageGotoPage(VERIFICATION_CANCEL_CONFIRMED, errorMsg);          
            }
            
            if (sendPasscodeSuccessful) {
            	setErrorMessage("");  
            	goToPage(VERIFICATION_ENTER_PASSCODE_PAGE);
            }
            else {
            	setSessionVerifyPhoneError(IPSConstants.PASSCODE_NOT_SENT_MSG);
             	goToPage(VERIFICATION_REQUEST_PASSCODE_PAGE);
            }
        }
    }

    private boolean exceededPasscodeAttemptsLimit(Person person, PersonVo personVo, RefOtpSupplier phoneSupplier) {
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        OtpVelocityCheckService otpVelocityCheckSvc = (OtpVelocityCheckService) SpringUtil.getInstance(ctx).getBean(OTP_VELOCITY_CHECK_SERVICE);
        RpEventDataService rpEventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);

        RpEvent rpEvent = rpEventService.getLatestPhoneVerification(personVo.getId(), phoneSupplier.getOtpSupplierId());

        return otpVelocityCheckSvc.exceededPasscodeAttemptsLimit(person, personVo, phoneSupplier, rpEvent);
    }
    
    public boolean hasInitialPasscodeAttempt() {
        setPersonVo(getSessionPersonVo());
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        OtpVelocityCheckService otpVelocityCheckSvc = (OtpVelocityCheckService) SpringUtil.getInstance(ctx).getBean(OTP_VELOCITY_CHECK_SERVICE);
        RpEventDataService rpEventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        RefOtpSupplier phoneSupplier = rpEventService.getLatestPhoneSupplier(getSessionPersonVo());
        
        if (phoneSupplier == null) {
           	RefOtpSupplierDataService supplierDataService = (RefOtpSupplierDataService)SpringUtil.getInstance(ctx).getBean(REF_OTP_SUPPLIER_DATA_SERVICE);
          	phoneSupplier = supplierDataService.findBySupplierId(getPersonVo().getCurrentPhoneVerificationSupplierId());
        }

        return otpVelocityCheckSvc.hasInitialPasscodeAttempt(getPersonVo().getId(), phoneSupplier.getOtpSupplierId());
    }
    
    @Override
    public void backToVerificationUserInfoPage() {
        CustomLogger.enter(this.getClass());
                
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        ProofingService proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
        PersonDataService personService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
        
        PersonVo personVo = getSessionPersonVo();
        Person person = personService.findByPK(personVo.getId());    
    
        String pageName = isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : VERIFICATION_USER_INFO_PAGE;
        String verificationUserInfoPageUrl = String.format("%s/%s", getHttpServletRequest().getContextPath(), pageName);

        try {
            proofingService.updateProofingStatus(RefRpStatus.RpStatus.Phone_verification_initiated.getValue(), person,
                    personVo.getProofingLevelSought());
            
            FacesContext.getCurrentInstance().getExternalContext().redirect(verificationUserInfoPageUrl);
        } catch (IOException e) {
            CustomLogger.error(this.getClass(), "Could not redirect to page: " + verificationUserInfoPageUrl, e);
        }
    }
    
    public boolean isHoldMail() {
    	return isHoldMail; 
    }
    
    public String getMaskedPhoneNumberForUI() {
    	return this.getVerificationMaskedPhoneNumberForUI();
    }
    
    public String getPasscodeSentMessage() {
        return passcodeSentMessage;
    }

    public void setPasscodeSentMessage(String passcodeSentMessage) {
        this.passcodeSentMessage = passcodeSentMessage;
    }

	public long getPhoneVerificationAttemptCount() {
		return phoneVerificationAttemptCount;
	}

	public void setPhoneVerificationAttemptCount(long phoneVerificationAttemptCount) {
		this.phoneVerificationAttemptCount = phoneVerificationAttemptCount;
	}

	public long getOtpOrSmfaRequestAttemptCount() {
		return otpOrSmfaRequestAttemptCount;
	}

	public void setOtpOrSmfaRequestAttemptCount(long otpOrSmfaRequestAttemptCount) {
		this.otpOrSmfaRequestAttemptCount = otpOrSmfaRequestAttemptCount;
	}
}
