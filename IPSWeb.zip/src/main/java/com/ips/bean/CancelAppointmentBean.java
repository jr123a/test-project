package com.ips.bean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.UserVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.SpringUtil;
import com.ips.polocator.common.AppointmentVo;
import com.ips.proofing.ProofingService;

@ManagedBean(name="cancelAppointment")
@ViewScoped
public class CancelAppointmentBean extends IPSController implements Serializable {

    private static final long serialVersionUID = 1L;

    public void cancelAppt() {    
        // Handle login in after page refresh
        verifyUserSessionData();
                
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        ProofingService proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
        UserVo user = getSessionUser();
        
        try {
            AppointmentVo appt = getSessionAppointment();
            proofingService.cancelAppointment(user, appt);
            appt.setScheduled(false);
            appt.setCanceled(true);
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred on canceling appointment for sponsorUserId: " + user.getSponsorUserId(), e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
        
        goToPage(VERIFICATION_ERROR_PAGE);
    }
    
    public void returnToSchedule() {
        goToPage(APPOINTMENT_CONFIRMATION_PAGE);
    }
}
