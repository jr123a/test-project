package com.ips.bean;

import java.io.File;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.persistence.common.EmailText;
import com.ips.persistence.common.Emailer;
import com.ips.persistence.common.GenerateBarcodeUtil;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.UserVo;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.SpringUtil;
import com.ips.exception.AMSException;
import com.ips.polocator.common.AppointmentVo;
import com.ips.proofing.ProofingService;
import com.ips.proofing.ProofingServiceImpl;
import com.ips.proofing.VerifyAddressService;
import com.ips.proofing.VerifyAddressServiceImpl;


@ManagedBean(name="confirmation")
@ViewScoped
public class AppointmentConfirmationBean extends IPSController implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private AppointmentVo appointment;
    private String scheduledDate;
    private UserVo user;
    private Emailer emailer;
    private boolean emailSent = false;
    private String email;
    
    @PostConstruct
    public void init(){
        // Handle login in after page refresh
        verifyUserSessionData();
                
        appointment = getSessionAppointment();
        user = getSessionUser();
        email = user.getEmail();
    
        if (appointment != null &&  appointment.getScheduledDate() != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
            scheduledDate = sdf.format(appointment.getScheduledDate());
        }
    }
    
    /**
     * Put this in a separate method rather than init so that the routing to the 
     * System error page will work.
     */
    public void checkForObjects() {
        if(appointment == null || user == null){
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Cannot load appointment info || user is null");
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }
    
    public void confirmtAppt(){
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);
        
        if (webAppCtx != null) {          
        	ProofingService service = webAppCtx.getBean(PROOFING_SERVICE, ProofingServiceImpl.class);
        
	        try {
	            user = service.optInToIppAtResidence(user, appointment);    
	        
	            goToPage(SCHEDULE_CONFIRMED_PAGE);
	            CustomLogger.debug(this.getClass(), "IPP Event created for User: " + user.getSponsorUserId());
	        }
	        catch (Exception e) {
	            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred confirming appointment for sponsorUserId: " + user.getSponsorUserId(), e);
	            goToPage(SYSTEM_ERROR_PAGE);
	        }
        }
    }

    public void cancelAppt() {
        // Clear out velocity and other messages on the Unable to Verify Identity page
        
        if (isAppointmentScheduled()) {
            goToPage(CANCEL_APPOINTMENT_PAGE);
        }
        else {
            setSessionAppointment(null);
            CustomLogger.debug(this.getClass(), "Appointment deleted from session for User: " + user.getSponsorUserId());
            goToPage(VERIFICATION_ERROR_PAGE);
        }
    }
    
    public void modifyAppt() {
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        ProofingService proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
        UserVo user2 = getSessionUser();
        
        try {
            AppointmentVo appt = getSessionAppointment();
            proofingService.cancelAppointment(user2, appt);
            appt.setScheduled(false);
            appt.setCanceled(true);
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred on canceling appointment for sponsorUserId: " + user2.getSponsorUserId(), e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
        
        goToPage(ADDRESS_CONFIRMATION_PAGE);
    }
    
    public void confirmAddress(){
        goToPage(ADDRESS_CONFIRMATION_NEXT_PAGE);
    }
    
    public void denyAddress(){
        goToPage(RETAIL_ONLY_OPTION_PAGE);
    }
    
    public void confirmAddressNext(){
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);
        
        if (webAppCtx != null) {          
        	VerifyAddressService service = webAppCtx.getBean(VERIFY_ADDRESS_SERVICE, VerifyAddressServiceImpl.class);
        
	        try {
	            appointment = service.verifyAddress(appointment);
	            setSessionAppointment(appointment);
	            goToPage(SCHEDULE_APPOINTMENT_PAGE);
	        } catch (AMSException e) {
	            CustomLogger.error(this.getClass(), "Error calling Verify Address",e);
	            goToPage(INELIGIBLE_ADDRESS_PAGE);
	        } catch (Exception e){
	            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred when address is being verified: ",e);
	            goToPage(SYSTEM_ERROR_PAGE);
	        }
        }
    }
    
    public String getEmail(){
        return email;
    }
    
    public void setEmail(String email){
        this.email = email;
    }
    
    public void denyAddressNext(){
        goToPage(ALTERNATE_ADDRESS_PAGE);
    }
    
    public AppointmentVo getAppointment() {
        return appointment;
    }

    public void setAppointment(AppointmentVo appointment) {
        this.appointment = appointment;
    }

    public String getScheduledDate() {
        return scheduledDate;
    }

    public void setScheduledDate(String scheduledDate) {
        this.scheduledDate = scheduledDate;
    }
    
    public boolean isAppointmentScheduled() {
        return appointment != null && appointment.isScheduled();
    }

    public UserVo getUser() {
        return user;
    }

    public void setUser(UserVo user) {
        this.user = user;
    }
    
    public boolean isTooLateToCancel() {
        Date apptDate = appointment.getScheduledDate();
        return DateTimeUtil.isAfter2AMOnDate(apptDate);
    }
    
    public Emailer getEmailer() {
        return emailer;
    }

    public void setEmailer(Emailer emailer) {
        this.emailer = emailer;
    }
    
    public void requestNewVerificationEmail(){

        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);
        
        if (webAppCtx != null) {          
	        emailer = webAppCtx.getBean(EMAILER, Emailer.class);
	                
	        GenerateBarcodeUtil barcode = new GenerateBarcodeUtil();
	        String barcodeFile = barcode.generateBarcode(appointment.getRecordLocator());
	        CustomLogger.debug(this.getClass(), ("Barcode Path: " + barcodeFile));
	        //send email
	        String emailTo = email;
	        CustomLogger.debug(this.getClass(), "Email to: " + emailTo);
	        try {
	            emailer.sendIppEmail(barcodeFile, emailTo, EmailText.getHTMLTextIPPResidence(appointment, false), EmailText.IPP_SUBJECT, null);
	            user.setIPPemailSent(true);
	            setSessionUser(user);
	            goToPage(APPOINTMENT_CONFIRMATION_PAGE);
	        } catch (Exception e) {
	            CustomLogger.error(this.getClass(), "Cannot Send Email: ",e);
	            user.setIPPemailSent(false);
	            setSessionUser(user);
	            goToPage(APPOINTMENT_CONFIRMATION_PAGE);
	        }    
	        //delete barcode file
	        File file = new File(barcodeFile);
	        file.delete();
	        CustomLogger.debug(this.getClass(), "Barcode Deleted!");
        }
    }

    public boolean isEmailSent() {
        return emailSent;
    }

    public void setEmailSent(boolean emailSent) {
        this.emailSent = emailSent;
    }

    public void gotoOnlineVerification(){
        setSessionAppointment(null);
        goToPage(isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : VERIFICATION_USER_INFO_PAGE);
    }
}
