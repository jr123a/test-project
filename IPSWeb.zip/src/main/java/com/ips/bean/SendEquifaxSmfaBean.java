package com.ips.bean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.SpringUtil;
import com.ips.entity.Person;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RpEvent;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.UAgentInfo;
import com.ips.proofing.PhoneVerificationService;
import com.ips.proofing.PhoneVerificationServiceImpl;
import com.ips.service.PersonDataService;
import com.ips.service.RefOtpSupplierDataService;
import com.ips.service.RpEventDataService;
import com.ips.service.SmfaVelocityCheckService;

@ManagedBean(name="sendEquifaxSmfa")
@SessionScoped
public class SendEquifaxSmfaBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;
    private String linkSentMessage;
    private long phoneVerificationAttemptCount = 0;
    private long otpOrSmfaRequestAttemptCount = 0;

      
    public void checkErrorMessage() {
	    String sessionVerifyPhoneError = getSessionVerifyPhoneError();
	    if (StringUtils.isEmpty(sessionVerifyPhoneError)) {
	    	this.setError(false);
	    	this.setErrorMessage(null);
	    }
	    else {
	    	this.setError(true);
	    	this.setErrorMessage(sessionVerifyPhoneError);
	    	setSessionVerifyPhoneError(null);
	    }
	    
		PersonVo personVo = getSessionPersonVo();
		if (personVo != null) {
			setPhoneVerificationAttemptCount(personVo.getPhoneVerificationAttemptCount());
			setOtpOrSmfaRequestAttemptCount(personVo.getOtpOrSmfaRequestAttemptCount());
		}
	}
    
    public void sendLinkToPhone() throws Exception  {
        CustomLogger.enter(this.getClass());

        // If the user comes directly to this page the phone number must be retrieved from the database
        getSavedPhone();
        setPersonVo(getSessionPersonVo());
        PersonVo personVo = getPersonVo();
		setSessionOtpSmfaAttempts(0);

        ServletContext ctx = (ServletContext)FacesContext.getCurrentInstance().getExternalContext().getContext();
        RefOtpSupplierDataService supplierService = (RefOtpSupplierDataService)SpringUtil.getInstance(ctx).getBean(REF_OTP_SUPPLIER_DATA_SERVICE);
        PersonDataService personService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);

        RefOtpSupplier phoneSupplier = supplierService.findBySupplierId(RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID);
 		Person person = personService.findByPK(personVo.getId()); 
        CustomLogger.debug(this.getClass(), "RequestLinkBean phoneSupplier returned: " + phoneSupplier.getOtpSupplierId() );

        // Only generate new link if user has not exceeded link attempts limit
        boolean exceededLinkAttemptsLimit = exceededLinkAttemptsLimit(person, personVo, phoneSupplier);
        setSessionPersonVo(personVo);
		
        if (exceededLinkAttemptsLimit) {
        	setSessionPersonVo(personVo);
             String logMsg = String.format("The User has exceeded link attempts limit for sponsorUserId: %s.", personVo.getSponsorUserId());
             manageGotoPage(VERIFICATION_LOCKOUT, logMsg);          
        }
        else {
        	int otpSmfaAttempts = getSessionOtpSmfaAttempts();
        	
        	if (otpSmfaAttempts > 2) {
             	//IVS enforces SUBMIT_EXCEEDED after 3 attempts
                setSessionVerifyPhoneError(IPSConstants.EXCEEDED_LINK_REQUESTS_MSG);
           		setSessionPersonVo(personVo);

           		goToPage(isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : VERIFICATION_USER_INFO_PAGE);
        		return;
        	}
        	else {
        		setSessionOtpSmfaAttempts(otpSmfaAttempts + 1);
        	}
        	
            ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();

            try {
            	String userAgent = "";
            	String httpAccept = "";
            	boolean isDesktop = true;
            	try {
            		request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            		userAgent = request.getHeader("User-Agent");
            		httpAccept = request.getHeader("Accept");
            		UAgentInfo detector = new UAgentInfo(userAgent, httpAccept);
            		isDesktop = !(detector.getIsMobilePhone());
            	}
            	catch (Exception ex) {
                    CustomLogger.error(this.getClass(), "Unable to get User-Agent ", ex);
            	}
				
            	int linkSuccessfullySent = 422;
           	 	WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);

           	 	if (webAppCtx != null) {
           	 		PhoneVerificationService phoneVerificationService = webAppCtx.getBean(PHONE_VERIFICATION_SERVICE, PhoneVerificationServiceImpl.class);
           	 
           	 		try {
	                      linkSuccessfullySent = phoneVerificationService.sendSmfaLink(personVo, phoneSupplier, isDesktop);
	             	}
	            	catch (Exception ex) {
	                    CustomLogger.error(this.getClass(), "Exception occurs when invoking sendSmfaLink method. ", ex);
	            	}
            	}
                
                setSessionPersonVo(personVo);
                CustomLogger.debug(this.getClass(), "SMFA link sent successfully");
                setLinkSentMessage("A link has been sent to your mobile device!");
                
        		if (linkSuccessfullySent == 0) {
        			// Hide error message if the link is sent successfully
        			setSessionVerifyPhoneError(null);
        			goToPage(VERIFICATION_VALIDATE_SMFA_PAGE);
        		}
        		else if (linkSuccessfullySent == 200
        				|| linkSuccessfullySent == 422) {
        			// This handles land lines
        			// Latest verbiage from Human Factors:
        			// Unfortunately, we were not able to verify your identity with the information you entered. Landline numbers are not supported. Please enter a mobile phone number or cancel Online Mobile Phone Verification.
        			// During testing we determined that 422s are land lines
        			CustomLogger.error(this.getClass(), "SMFA Unable To Send link error code " + linkSuccessfullySent);
                    setSessionVerifyPhoneError(IPSConstants.UNABLE_TO_VERIFY_LANDLINE_MSG);
                  	personVo.setRenderErrorMessage(true);
              		setSessionPersonVo(personVo);

              		goToPage(isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : VERIFICATION_USER_INFO_PAGE);
        		}
        		else { 
        			// if 500 error occurred then display message
        			// Unfortunately, we were not able to verify your identity with the information you entered.
                    // Please enter a mobile phone number or cancel Online Mobile Phone Verification.
                    CustomLogger.error(this.getClass(), "SMFA Unable To Send link error code " + linkSuccessfullySent);
                    setSessionVerifyPhoneError(IPSConstants.UNABLE_TO_VERIFY_PHONE_MSG);
                  	personVo.setRenderErrorMessage(true);
              		setSessionPersonVo(personVo);
              		
              		goToPage(isHoldMail ? VERIFICATION_USER_INFO_HM_PAGE : VERIFICATION_USER_INFO_PAGE);
        		}
             } 
            catch (Exception e) {
                String errorMsg = String.format("IPSException occurred during send SMFA link for sponsorUserId: %s.", personVo.getSponsorUserId());
                CustomLogger.error(this.getClass(), errorMsg, e);
                manageGotoPage(VERIFICATION_CANCEL_CONFIRMED, errorMsg); 
                throw new IPSException(e.getMessage());
            }
        }
    }
    
    private boolean exceededLinkAttemptsLimit(Person person, PersonVo personVo, RefOtpSupplier phoneSupplier) {
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        SmfaVelocityCheckService smfaVelocityCheckSvc = (SmfaVelocityCheckService) SpringUtil.getInstance(ctx).getBean(SMFA_VELOCITY_CHECK_SERVICE);
        RpEventDataService rpEventDataService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
          
        RpEvent rpEvent = rpEventDataService.getLatestPhoneVerification(personVo.getId(), phoneSupplier.getOtpSupplierId());
        return smfaVelocityCheckSvc.exceededLinkAttemptsLimit(person, personVo, phoneSupplier, rpEvent);
    }
    
    public String getMaskedPhoneNumberForUI() {
    	return this.getVerificationMaskedPhoneNumberForUI();
    }
    
    public String getLinkSentMessage() {
        return linkSentMessage;
    }

    public void setLinkSentMessage(String linkSentMessage) {
        this.linkSentMessage = linkSentMessage;
    }
    
    public void resendLinkToPhone() {
        CustomLogger.enter(this.getClass());
        
    }

	public long getPhoneVerificationAttemptCount() {
		return phoneVerificationAttemptCount;
	}

	public void setPhoneVerificationAttemptCount(long phoneVerificationAttemptCount) {
		this.phoneVerificationAttemptCount = phoneVerificationAttemptCount;
	}

	public long getOtpOrSmfaRequestAttemptCount() {
		return otpOrSmfaRequestAttemptCount;
	}

	public void setOtpOrSmfaRequestAttemptCount(long otpOrSmfaRequestAttemptCount) {
		this.otpOrSmfaRequestAttemptCount = otpOrSmfaRequestAttemptCount;
	}
}
