package com.ips.bean;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.ips.persistence.common.IPSConstants;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.polocator.common.AppointmentVo;

@ManagedBean(name="appointment")
@ViewScoped
public class AppointmentBean extends IPSController implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String apptDate;
    private String apptTime;
    private List<String> dateList = new ArrayList<>();    //final arraylist of dates    
    
    
    @PostConstruct
    public void init(){    
        // Handle login in after page refresh
        verifyUserSessionData();
                
        SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
        Date date = new Date();
        ArrayList<Calendar> list = new ArrayList<>();    //arraylist of dates with no Sundays
        Calendar cal;        
        Date date2;
        for (int x=0; x<5; x++){
            date2 = DateTimeUtil.getDatePlusDays(date, x+1);
            cal = Calendar.getInstance();
            cal.setTime(date2);
            if(cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY ){
                for(int y=x; y<5; y++){
                    date2 = DateTimeUtil.getDatePlusDays(date, y+2);
                    cal = Calendar.getInstance();
                    cal.setTime(date2);
                    list.add(cal);
                }
                break;
            }
            cal.setTime(date2);
            list.add(cal);
        }
        
        int currentYear = new GregorianCalendar().get(Calendar.YEAR);
        
        for (int x=0; x<list.size(); x++){
            if(DateTimeUtil.checkIfHoliday(list.get(x), currentYear)){
                for(int y=x; y<list.size(); y++){
                    list.get(y).add(Calendar.DATE, 1);                    
                    if(list.get(y).get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY){
                        for (int a=y; a<list.size(); a++){
                            list.get(a).add(Calendar.DATE, 1);
                            dateList.add(sdf.format(list.get(a).getTime()));
                        }
                        break;
                    }
                    dateList.add(sdf.format(list.get(y).getTime()));
                }
                break;
            }
            dateList.add(sdf.format(list.get(x).getTime()));
        }
    }

    public void getAppointment(){
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
        AppointmentVo appointment = getSessionAppointment();
        try {
            appointment.setScheduledDate(sdf.parse(apptDate));
            appointment.setScheduledTime(apptTime);
            setSessionAppointment(appointment);
            CustomLogger.debug(this.getClass(), appointment.getScheduledDate()+" and "+appointment.getScheduledTime()+" are saved in session!");
            goToPage(APPOINTMENT_CONFIRMATION_PAGE);
        } catch (ParseException e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Cannot parse appointment: ",e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }

    public String getApptDate() {
        return apptDate;
    }

    public void setApptDate(String apptDate) {
        this.apptDate = apptDate;
    }

    public String getApptTime() {
        return apptTime;
    }

    public void setApptTime(String apptTime) {
        this.apptTime = apptTime;
    }

    public List<String> getDateList() {
        return dateList;
    }

    public void setDateList(List<String> dateList) {
        this.dateList = dateList;
    }            
}
