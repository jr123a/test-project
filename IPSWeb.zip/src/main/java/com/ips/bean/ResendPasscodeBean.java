package com.ips.bean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.JSFUtils;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.Person;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RpEvent;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.proofing.PhoneVerificationServiceImpl;
import com.ips.service.OtpVelocityCheckService;
import com.ips.service.PersonDataService;
import com.ips.service.RpEventDataService;

@ManagedBean(name="resendpasscode")
@SessionScoped
public class ResendPasscodeBean extends VerificationBean implements Serializable {
    private static final long serialVersionUID = 1L;
    private String errorMessage;
    private boolean passcodeSentMessage;
    
    @PostConstruct
    @Override
    public void init() {
         CustomLogger.enter(this.getClass());
        setPasscodeSentMessage(false);
    }
    
    public void resendPasscodeToPhone() throws Throwable {
        CustomLogger.enter(this.getClass());
        
        setPasscodeSentMessage(false);
        boolean renewAttemptsExceeded = false;
        boolean resendPasscodeSuccessful = false;
        setPersonVo(getSessionPersonVo());
		setSessionOtpSmfaAttempts(0);

        // If the user comes directly to this page the phone number must be retrieved from the database 
        // in order for the call to Lexis Nexis to work
        getSavedPhone();
        
        // Clear out previous passcode error messages
        ConfirmPasscodeBean confirmPasscode = JSFUtils.getManagedBean("confirmpasscode");
        confirmPasscode.setErrorMessage(null);

        //get Services from Spring application context
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        RpEventDataService rpEventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        RefOtpSupplier supplier = rpEventService.getLatestPhoneSupplier(getSessionPersonVo());
        PersonDataService personDataService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);

        RpEvent event = null;
        
        // Do not call Equifax if the last passcode attempt was the last allowed renew attempt
        try {
            event = rpEventService.getLatestPhoneVerification(getPersonVo().getId(), supplier.getOtpSupplierId());
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error checking event status of OTP: for sponsorUserId:" + getPersonVo().getSponsorUserId(), e);
                goToPage(SYSTEM_ERROR_PAGE);
        }
        
        try {
            // Only generate subsequent passcode if user has not exceeded passcode attempts limit
            PersonVo personVo = getPersonVo();
            Person person = personDataService.findByPK(personVo.getId());
            boolean exceededPasscodeAttemptsLimit= exceededPasscodeAttemptsLimit(person, personVo, supplier);

            if (exceededPasscodeAttemptsLimit) {
            	setSessionPersonVo(personVo);

               	String logMsg = String.format("The User has exceeded passcode attempts limit for sponsorUserId: %s.", getPersonVo().getSponsorUserId());
                manageGotoPage(VERIFICATION_LOCKOUT, logMsg);          
            }
            else {
                // If the user has exceeded the number of renewal requests, redirect to the Unable to Verify page
                if (event == null) {
                    CustomLogger.error(this.getClass(), "resendPasscodeToPhone: event is null");
                    goToPage(SYSTEM_ERROR_PAGE);
                }
                else if (event.lastPasscodeAttemptExceededRenew()) {
                    goToPage(VERIFICATION_CANCEL_CONFIRMED);
                }
                else {
                 	 WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);

                 	if (webAppCtx != null) {
	                    PhoneVerificationServiceImpl phoneVerificationService = webAppCtx.getBean(PHONE_VERIFICATION_SERVICE, PhoneVerificationServiceImpl.class);
	                 	
	                	//renewAttemptsExceeded is for Equifax
	                	if (supplier.isEquifaxIDFSPhone()) {
		                    renewAttemptsExceeded = phoneVerificationService.resendPasscode(getPersonVo(), supplier, event);   
		                    resendPasscodeSuccessful = !renewAttemptsExceeded;
	                	} else {
	                		resendPasscodeSuccessful = phoneVerificationService.resendPasscode(getPersonVo(), supplier, event);
	                	}
                 	}
                    CustomLogger.debug(this.getClass(), "Transaction processed successfully");

                    // If the user has exceeded the number of renewal requests, redirect to the Unable to Verify page
                    if (!resendPasscodeSuccessful) {
                    	//For retry
                    	if (supplier.isExperianPhone()) { 
                           	setErrorMessage(IPSConstants.PASSCODE_NOT_SENT_MSG);  
                     		goToPage(VERIFICATION_REQUEST_PASSCODE_PAGE);
                    	} else {
	                        goToPage(VERIFICATION_CANCEL_CONFIRMED);
                    	}
                    }
                    else {
                        setPasscodeSentMessage(true);
                        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
                        
                        if(request.getRequestURI().contains(VERIFICATION_REQUEST_PASSCODE_PAGE)) {
                            goToPage(VERIFICATION_ENTER_PASSCODE_PAGE);
                        }                
                    }
                }
            }
        } catch (PhoneVerificationException e) {
            CustomLogger.error(this.getClass(), "PhoneVerificationException occurred during resend passcode.", e);
            goToPage(VERIFICATION_CANCEL_CONFIRMED);
        } catch (IPSException e) {
            String errorMsg = String.format("Error sending passcode for sponsorUserId: %s.", getPersonVo().getSponsorUserId());
            CustomLogger.error(this.getClass(), errorMsg, e);

            setErrorMessage(e.getMessage());
            if (e.getMessage() != null && e.getMessage().toUpperCase().startsWith("FAULT OCCUR")) {
                manageGotoPage(VERIFICATION_LOCKOUT, errorMsg);          
            } else {
                goToPage(VERIFICATION_ENTER_PASSCODE_PAGE);
            }
        }
    }
    
    public boolean exceededPasscodeAttemptsLimit(Person person, PersonVo personVo, RefOtpSupplier otpSupplier) {
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        OtpVelocityCheckService otpVelocityCheckSvc = (OtpVelocityCheckService) SpringUtil.getInstance(ctx).getBean(OTP_VELOCITY_CHECK_SERVICE);
        RpEventDataService rpEventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);

        RpEvent rpEvent = rpEventService.getLatestPhoneVerification(personVo.getId(), otpSupplier.getOtpSupplierId());

        return otpVelocityCheckSvc.exceededPasscodeAttemptsLimit(person, personVo, otpSupplier, rpEvent);
    }
     
    public void resetBeanValue() {
         setPasscodeSentMessage(false);
    }

    @Override
    public String getErrorMessage() {
        return errorMessage;
    }

    @Override
    public void setErrorMessage(String errorMessage) {
       //if error message equals null or "" set error to false
        this.setError((errorMessage != null && !Utils.isEmptyString(errorMessage.trim())));
        this.errorMessage = errorMessage;
    }

    public boolean isPasscodeSentMessage() {
        return passcodeSentMessage;
    }

    public void setPasscodeSentMessage(boolean passcodeSentMessage) {
        this.passcodeSentMessage = passcodeSentMessage;
    }

}
