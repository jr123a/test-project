package com.ips.bean;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.DeviceReviewStatusEnum;
import com.ips.common.common.JSFUtils;
import com.ips.common.common.SpringUtil;
import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefApp;
import com.ips.entity.RefDeviceConfidence;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefRpStatus.RpStatus;
import com.ips.entity.RefSponsor;
import com.ips.persistence.common.DeviceAssessmentParamVo;
import com.ips.persistence.common.DeviceReputationResult;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationParamVo;
import com.ips.proofing.ProofingService;
import com.ips.service.DeviceReputationService;
import com.ips.service.DeviceReputationServiceImpl;
import com.ips.service.HighRiskAddressService;
import com.ips.service.PersonDataDataService;
import com.ips.service.PersonDataService;
import com.ips.service.PersonProofingStatusService;
import com.ips.service.RefLoaLevelService;

@ManagedBean(name="tmxProfiling")
@SessionScoped
public class VerificationTmxProfilingBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String profileNumber;
    private String profilingOrgId;
    private String deviceReputationPage;

    private PhoneVerificationParamVo verificationParamVo;
    private DeviceReputationService deviceReputationService;
    private PersonDataService personService;
    private boolean initialized;
    private boolean profilingComplete;
    private DeviceAssessmentParamVo assessmentParamVo;
    private HighRiskAddressService highRiskAddressService;
    private PersonDataDataService personDataService;
    private ProofingService proofingService;
    private RefLoaLevelService refLoaLevelService;
    private PersonProofingStatusService personProofingStatusService;

    @PostConstruct
    @Override
    public void init() {
        if (!initialized) {
        	initDeviceReputationProfiler();
        	 setInitialized(true);
        }
    }

    /**
     * Determine if the device profiling is enabled and ip address is successfully for obtained for customer's device.
     * If so, profilingSEssionId and profilingOrdId are set.
     * @return
     */
    public void initDeviceReputationProfiler(){
        CustomLogger.enter(this.getClass());
 
        updateUserInfo();

        resetProofingStatus();
        
        String callingAppName = getSessionCallingAppName();     
        PersonVo personVo = prepareSponsorId();
        boolean isDeviceProfilingEnabled = deviceReputationService.isDeviceProfilingEnabled(personVo.getId(), personVo.getSponsorId(), callingAppName, true);
        setDeviceProfilingEnabled(isDeviceProfilingEnabled);
      
       	CustomLogger.debug(this.getClass(), "VerificationTmxProfilingBean > initDeviceReputationProfiler > isDeviceProfilingEnabled:" + isDeviceProfilingEnabled);
        
        try {
            HttpSession session = getHttpServletRequest().getSession();
            String clientIPAddress =  (String) session.getAttribute(IPSConstants.CLIENT_IP_ADDR);
            setCustomerIpAddress(clientIPAddress);
            setSessionCustomerIpAddress(clientIPAddress);
             
        	CustomLogger.debug(this.getClass(), "VerificationTmxProfilingBean > initDeviceReputationProfiler > clientIPAddress:" + clientIPAddress);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error occurred in getting host address: ", e);
        }    
 
      	setSessionDeviceProfilingEnabled(isDeviceProfilingEnabled());
    	CustomLogger.debug(this.getClass(), "Remote proofing status: Device profiling is enabled and IP address is obtained.");

        String sponsorUserId = personVo.getSponsorUserId();
        String profilingSessionId = deviceReputationService.getProfilingSessionId(sponsorUserId);
        setProfilingSessionId(profilingSessionId);
        setProfilingOrgId(deviceReputationService.retrieveOrgId(sponsorUserId));   
        setSessionDeviceProfilingSessionId(profilingSessionId);
		setProfilingComplete(true);    
		        
       	CustomLogger.debug(this.getClass(), "VerificationTmxProfilingBean > initDeviceReputationProfiler > profilingOrgId:" + profilingOrgId
       			+ ", profilingSessionId:" + profilingSessionId);
    }
    
	/**
	 * Update user info 
	 * WARNING: This method is called twice on initial load and then called
	 * on each subsequent page load.  Because the UserInfoBean.java is a 
	 * session bean init() will not get called on every page load, only on the
	 * first one in the session.  Therefore, do not add things to the 
	 * updateUserInfo() method that you want to occur only once per session 
	 * and not once for every page load.
	 */
    public void updateUserInfo() {
        CustomLogger.enter(this.getClass());
       
        loadServices();
        
        String contextPath = getHttpServletRequest().getContextPath();
        setDeviceReputationPage(String.format("%s/%s", contextPath, IPSController.VERIFICATION_DEVICE_REPUTATION));

        PersonVo personVo = getSessionPersonVo();
        verifyUserSessionData();
                
        setSponsorUserInfo();
        setPhoneNumber(personVo.getMobileNumber());    

        // Retrieve person object from the database before updating proofing status
        person = personService.findByPK(personVo.getId());
        setPerson(person);     
       	setSessionPersonVo(personVo);
    }
    
    public void loadServices() {
        CustomLogger.enter(this.getClass());
        
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
    
        highRiskAddressService = (HighRiskAddressService)SpringUtil.getInstance(ctx).getBean(HIGH_RISK_ADDRESS_SERVICE);
        personService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
        personDataService = (PersonDataDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_DATA_SERVICE);
        proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
        deviceReputationService = (DeviceReputationService)SpringUtil.getInstance(ctx).getBean(DEVICE_REPUTATION_SERVICE);
        refLoaLevelService = (RefLoaLevelService)SpringUtil.getInstance(ctx).getBean(REF_LOA_LEVEL_SERVICE);
        personProofingStatusService = (PersonProofingStatusService)SpringUtil.getInstance(ctx).getBean(PERSON_PROOFING_STATUS_SERVICE);

        CustomLogger.debug(this.getClass(), String.format("Remote proofing status: User has %s transaction.", isHoldMail ? "Hold Mail" : "Informed Delivery"));
    }
    
    public void resetProofingStatus() {
        CustomLogger.enter(this.getClass());
                
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
        personService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
        
        PersonVo personVo = getSessionPersonVo();
        Person person = personService.findByPK(personVo.getId());    
        
        proofingService.updateProofingStatus(RefRpStatus.RpStatus.Started_remote_proofing.getValue(), person,
                personVo.getProofingLevelSought());
    }
    
    public String getPhoneNumberForUI() {
        CustomLogger.enter(this.getClass());
        
        // Since this bean is SessionScoped, the phone number should always
        // be retrieved from the database to ensure that a previous user's
        // phone number from the same browser session is not used
        getSavedPhone();
        setPersonVo(getSessionPersonVo());
        setPhoneNumber(getPersonVo().getMobileNumber());
        
        if(!phoneNumber.isEmpty()) {
                String number = phoneNumber.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");
                CustomLogger.debug(this.getClass(), "Phone number returned by getPhoneNumberForUI " + number);
                return number;
        } else {
            return "";
        }
    }

    private PersonVo prepareSponsorId() {
          CustomLogger.enter(this.getClass());
          
        PersonVo personVo = getPersonVo();
        personVo.setSponsorId(RefSponsor.SPONSOR_ID_CUSTREG);
        personVo.setTransactionOriginAppName(isHoldMail ? RefApp.HOLD_MAIL : RefApp.INFORMED_DELIVERY);
        return personVo;
    }
    
	public void redirectPage() {
        CustomLogger.enter(this.getClass());
        
        HttpSession session = getHttpServletRequest().getSession();
        String nextPageUrl =(String) session.getAttribute(IPSConstants.REDIRECT_PAGE_URL_KEY);
         
        try {
        	if (nextPageUrl != null) {
       	       	session.setAttribute(IPSConstants.REDIRECT_PAGE_URL_KEY, null);
        		FacesContext.getCurrentInstance().getExternalContext().redirect(nextPageUrl);
        	}
		} catch (IOException e) {
	        CustomLogger.error(this.getClass(), "redirectPage to page" + nextPageUrl);
		}  
	}
    
    public void assessDeviceReputation() {
        loadServices();
 
        PersonVo personVo = getSessionPersonVo();
        if (personVo != null) {
        	setPersonVo(getSessionPersonVo());
        	setPhoneNumber(getPersonVo().getMobileNumber());
        }
        else {
          	goToPage(SYSTEM_ERROR_PAGE);
        }
        
        if (getPerson() == null) {
       		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
            personService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
        	Person person = personService.findByPK(getPersonVo().getId());
        	setPerson(person);
        }

        String loaSought = getPersonVo().getProofingLevelSought();
        Long statusCode = RpStatus.Started_remote_proofing.getValue();
        PersonProofingStatus proofingStatus = personProofingStatusService.getByPersonId((int)getPersonVo().getId());
        
        if (proofingStatus == null || !proofingStatus.getStatusCode().equals(statusCode)) {
        	proofingService.updateProofingStatus(statusCode, person, loaSought);
        }
        
        if (personVo != null) {
        	personVo.setStatusCode(statusCode);
        }
 
 		determineDeviceReputationDecision();
    }
     
    public void determineDeviceReputationDecision() {
        CustomLogger.enter(this.getClass());
 
        String loaSought = getPersonVo().getProofingLevelSought();
  
        // Retrieve address_hash from person_data
        PersonVo personVo = prepareSponsorId();

        setSessionVerifyPhoneError(null);
        
        try {
        	int addressHash = personVo.getAddressHash();
        	
        	if (isHighRiskAddress(addressHash)) {
             	CustomLogger.debug(this.getClass(), "Remote proofing status: User has high risk address.");

                personVo.setDeviceAssessmentStatus(null);
                setSessionPersonVo(personVo);
	            String logMsg =  "User has high risk address.";
                manageGotoPage(UNABLE_TO_VERIFY_PAGE, logMsg);          
            }
            else {     
             	DeviceReputationResult deviceReputationResult = null;
                assessmentParamVo = getAssessmentParamVo();
                  
                String callingAppName = getSessionCallingAppName(); 
                boolean isHoldMail = IPSConstants.HOLD_MAIL.equalsIgnoreCase(callingAppName) || RefApp.HOLD_MAIL.equalsIgnoreCase(callingAppName);
                
                //This method is only called from IPSWeb VerificationUserInfo and there are only 2 calling applications.
                callingAppName = isHoldMail ? RefApp.HOLD_MAIL : RefApp.INFORMED_DELIVERY;
                assessmentParamVo.setCallingAppName(callingAppName);
                  
                boolean isDeviceProfilingEnabled = getSessionDeviceProfilingEnabled();
  
            	if (this.customerIpAddress == null) {
             		this.customerIpAddress = getSessionCustomerIpAddress();
            	}

    	       	personVo.setCallingAppName(callingAppName);
    	       	personVo.setCallingAppUrl(callingAppURL);
            	personVo.setTrueIPAddress(this.customerIpAddress);
            	DeviceReviewStatusEnum reviewStatus = DeviceReviewStatusEnum.REVIEW;
            	assessmentParamVo.setCallingAppName(callingAppName);
                			
            	if (isDeviceProfilingEnabled) {
            		deviceReputationResult = getDeviceReputationResult(person, personVo, assessmentParamVo);
              		reviewStatus = deviceReputationResult.getDeviceReviewStatus();
            	}
            	else {
            	 	//Create RpDeviceReputation if Device Profiling is not enabled
                	assessmentParamVo.setReviewStatus(DeviceReviewStatusEnum.REVIEW.getReviewStatus());
                	assessmentParamVo.setReputationAssessment(DeviceReviewStatusEnum.REVIEW.getReputationAssessment());
                	assessmentParamVo.setCallingAppName(callingAppName);
                	assessmentParamVo.setDeviceScore(0);
                	assessmentParamVo.setRequestId(null);
                	assessmentParamVo.setMobilePhoneNumber(personVo.getMobileNumber());
                	
                	deviceReputationService.recordDeviceAssessmentAttempt(person, assessmentParamVo);
                   	CustomLogger.debug(this.getClass(), "Remote proofing status: Device profiling is disabled and device reputation assessment is bypassed.");
            	}
                       
                personVo.setDeviceAssessmentStatus(reviewStatus.getReviewStatus());
                setSessionPersonVo(personVo);
                    
                if (reviewStatus == DeviceReviewStatusEnum.PASS) {
                    //Redirect user to the Proofing Success page.  
					if(isHoldMail) {
		                CustomLogger.debug(this.getClass(), "Passcode Confirmed, return to calling app and Calling app is " + callingAppName);
		                returnToCallingApp(IPSConstants.PROOFING_RESULT_PASSED);
		                return;
		            }else {
		            	// clear error message from prior failures if successful  
			        	setSessionVerifyPhoneError(null);
		            	goToInformedDeliverySuccessPage();
		            }
                  	CustomLogger.debug(this.getClass(), "Remote proofing status: User device reputation has high confidence.");
                }
                else if (reviewStatus == DeviceReviewStatusEnum.REJECT) {
                   	CustomLogger.debug(this.getClass(), "Remote proofing status: User device reputation has low confidence.");

                    //Redirect user to Unable to Verify page where the user has the option to find Post Office for in-person proofing.    
                   	managePageRedirection(UNABLE_TO_VERIFY_PAGE, "User has low device reputation.");
                }
                else {
                	setSessionVerifyPhoneError(null);
                   	CustomLogger.debug(this.getClass(), "Remote proofing status: User device reputation has medium confidence.");
                    managePageRedirection(VERIFICATION_USER_INFO_PAGE, "User has medium device reputation.");
                 }
             }
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred on verifyPhone for user: " + getPersonVo().getSponsorUserId(), e);
 
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }
    
    /**
     * Determine if the customer's address is on the high-risk list.
     * @param addressHash
     * @return
     */
    private boolean isHighRiskAddress(int addressHash) {
        CustomLogger.enter(this.getClass());
        
        PersonVo personVo = getPersonVo();
        boolean isHighRisk = highRiskAddressService.highRiskAddressCheck(addressHash, personVo);
        setSessionPersonVo(personVo);
        return isHighRisk;
    }
    
    @Override
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }  
 
    /**
     * Determine the DeviceReputationResult result returned fromLexisNexis RDP web service call.
     * If the service call has exception, the status is set to the default value of "review".
     * @return DeviceReputationResult
     */
    private DeviceReputationResult getDeviceReputationResult(Person person, PersonVo personVo, DeviceAssessmentParamVo assessmentParamVo) {
        CustomLogger.enter(this.getClass());
        
        DeviceReputationResult deviceReputationResult = new DeviceReputationResult();

        try {
         	deviceReputationResult = deviceReputationService.createDeviceReputationResult(person, personVo, assessmentParamVo);
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred on assessing device reputation for user: " + personVo.getSponsorUserId(), e);

            DeviceReviewStatusEnum deviceReviewStatus = DeviceReviewStatusEnum.REVIEW;
            deviceReputationResult.setDeviceReviewStatus(deviceReviewStatus);
        }    
        setAssessmentParamVo(assessmentParamVo);
        
        return deviceReputationResult;
    }

    public String getProfileNumber() {
        return profileNumber;
    }

    public void setProfileNumber(String profileNumber) {
        this.profileNumber = profileNumber;
    }

    public String getProfilingOrgId() {
        return profilingOrgId;
    }

    public void setProfilingOrgId(String profilingOrgId) {
        this.profilingOrgId = profilingOrgId;
    }

    public boolean isInitialized() {
        CustomLogger.enter(this.getClass(), "isInitialized()=" + initialized);
        
        return initialized;
    }

    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }

    public boolean isProfilingComplete() {
        CustomLogger.enter(this.getClass(), "isProfilingComplete()=" + profilingComplete);
        
        return profilingComplete;
    }

    public void setProfilingComplete(boolean profilingComplete) {
        this.profilingComplete = profilingComplete;
    }

    public DeviceAssessmentParamVo getAssessmentParamVo() {
        if (assessmentParamVo == null) {
            assessmentParamVo = new DeviceAssessmentParamVo();
        }
        
        String callingAppName = getSessionCallingAppName();
        boolean isHoldMail = IPSConstants.HOLD_MAIL.equalsIgnoreCase(callingAppName) || RefApp.HOLD_MAIL.equalsIgnoreCase(callingAppName);
       
        PersonVo personVo = getPersonVo();
        
        //This method is only called from IPSWeb VerificationUserInfo and there are only 2 calling applications.
        callingAppName = isHoldMail ? RefApp.HOLD_MAIL : RefApp.INFORMED_DELIVERY;

      	CustomLogger.debug(this.getClass(), String.format("VerificationDeviceReputationBean > getAssessmentParamVo > CallingAppName:%s, ProfilingSessionId:%s, MobileNumber:%s",
      			callingAppName, getProfilingSessionId(), personVo.getMobileNumber()));

        if (getProfilingSessionId() == null) {
        	setProfilingSessionId(getSessionDeviceProfilingSessionId());
        }
        assessmentParamVo.setCallingAppName(callingAppName);
        assessmentParamVo.setSessionId(getProfilingSessionId());
        assessmentParamVo.setMobilePhoneNumber(personVo.getMobileNumber());

        setSessionDeviceAssessmentParamVo(assessmentParamVo);
        
        return assessmentParamVo;
    }

    public void setAssessmentParamVo(DeviceAssessmentParamVo assessmentParamVo) {
        this.assessmentParamVo = assessmentParamVo;
    }

    public PhoneVerificationParamVo getVerificationParamVo() {
        if (verificationParamVo == null) {
            verificationParamVo = new PhoneVerificationParamVo();
        }
        return verificationParamVo;
    }

    public void setVerificationParamVo(PhoneVerificationParamVo verificationParamVo) {
        this.verificationParamVo = verificationParamVo;
    }

    public String getDeviceReputationPage() {
		return deviceReputationPage;
	}

	public void setDeviceReputationPage(String deviceReputationPage) {
		this.deviceReputationPage = deviceReputationPage;
	}

	@Override
	public boolean isDeviceProfilingEnabled() {
		return deviceProfilingEnabled;
	}

	@Override
	public void setDeviceProfilingEnabled(boolean deviceProfilingEnabled) {
		this.deviceProfilingEnabled = deviceProfilingEnabled;
	}

	public DeviceReputationService getDeviceReputationService() {
		return deviceReputationService;
	}

	public PersonDataService getPersonService() {
		return personService;
	}

	public HighRiskAddressService getHighRiskAddressService() {
		return highRiskAddressService;
	}

	public PersonDataDataService getPersonDataService() {
		return personDataService;
	}

	public ProofingService getProofingService() {
		return proofingService;
	}

	public void setDeviceReputationService(DeviceReputationService deviceReputationService) {
		this.deviceReputationService = deviceReputationService;
	}

	public void setPersonService(PersonDataService personService) {
		this.personService = personService;
	}

	public void setHighRiskAddressService(HighRiskAddressService highRiskAddressService) {
		this.highRiskAddressService = highRiskAddressService;
	}

	public void setPersonDataService(PersonDataDataService personDataService) {
		this.personDataService = personDataService;
	}

	public void setProofingService(ProofingService proofingService) {
		this.proofingService = proofingService;
	}

}
