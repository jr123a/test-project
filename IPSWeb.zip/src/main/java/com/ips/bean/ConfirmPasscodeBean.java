package com.ips.bean;

import java.io.Serializable;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.equifax.eid.soap.schema.usidentityfraudservice.v2.*;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.JSFUtils;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefOtpMatchQuality;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RpEvent;
import com.ips.entity.RpOtpAttempt;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.proofing.PhoneVerificationServiceImpl;
import com.ips.service.OtpVelocityCheckService;
import com.ips.service.PersonDataService;
import com.ips.service.PersonProofingStatusService;
import com.ips.service.RefRpStatusDataService;
import com.ips.service.RpEventDataService;
import com.ips.service.RpOtpAttemptDataService;

@ManagedBean(name="confirmpasscode")
@SessionScoped
public class ConfirmPasscodeBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;
    private PersonDataService personDataService;
    private PersonProofingStatusService personProofingStatusService;
    private OtpVelocityCheckService otpVelocityCheckService;
    private RpOtpAttemptDataService rpOtpAttemptDataService;
    private String passcode;
    private String errorCode = ""; 
    private boolean confirmPasscodeInvoked; 
    private boolean passcodeConfirmed;
    private long phoneVerificationAttemptCount = 0;
    private long otpOrSmfaRequestAttemptCount = 0;
    private int otpSmfaAttemptsPerRequest = 0;
    
    @PostConstruct
    @Override
    public void init() {
         CustomLogger.enter(this.getClass());
        setPasscode(""); // clear the passcode when returning to the page
        
        // Ensure that message from SoapFaultException does not display when user clicks browser back button
        if (getErrorMessage() != null && Utils.isNumeric(getErrorMessage())) {
            clearError();
        }
            
        CustomLogger.info(this.getClass(), "Error Message=" + getErrorMessage());
    }
    
    public void checkErrorMessage() {
	    String sessionVerifyPhoneError = getSessionVerifyPhoneError();
	    if (StringUtils.isEmpty(sessionVerifyPhoneError)) {
	    	this.setError(false);
	    	this.setErrorMessage(null);	    
	    }
	    else {
	    	this.setError(true);
	    	this.setErrorMessage(sessionVerifyPhoneError);
	    	setSessionVerifyPhoneError(null);
	    }
	    
    	PersonVo personVo = getSessionPersonVo();
    	if (personVo != null) {
    		setPhoneVerificationAttemptCount(personVo.getPhoneVerificationAttemptCount());
    		setOtpOrSmfaRequestAttemptCount(personVo.getOtpOrSmfaRequestAttemptCount());
    	}
    	
    	setOtpSmfaAttemptsPerRequest(getSessionOtpSmfaAttempts());
    }
    
    public void confirmPasscode() {
        CustomLogger.enter(this.getClass());
        
        //get Services from Spring application context
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        personDataService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
        personProofingStatusService = (PersonProofingStatusService)SpringUtil.getInstance(ctx).getBean("personProofingStatusService");
        otpVelocityCheckService = (OtpVelocityCheckService)SpringUtil.getInstance(ctx).getBean("otpVelocityCheckService");
         
        personVo = getSessionPersonVo();
        PersonProofingStatus personProofingStatus = personProofingStatusService.getByPersonId((int) personVo.getId());       
        
         if (personProofingStatus != null && personProofingStatus.getRefRpStatus().getStatusCode() == RefRpStatus.RpStatus.LOA_level_achieved.getValue()) {
        	if(isHoldMail) {
                CustomLogger.debug(this.getClass(), "Passcode Confirmed, return to calling app and Calling app is " + callingAppName);
                returnToCallingApp(IPSConstants.PROOFING_RESULT_PASSED);
                return;
            }else {
            	// clear error message from prior failures if successful  
	        	setSessionVerifyPhoneError(null);
            	goToInformedDeliverySuccessPage();
            }
        }
        
        // Clear out the resend passcode message
        ResendPasscodeBean resendPasscode = JSFUtils.getManagedBean("resendpasscode");
        resendPasscode.setPasscodeSentMessage(false);
        
        PhoneVerificationServiceImpl phoneVerificationService = WebApplicationContextUtils.getWebApplicationContext(ctx).getBean(PHONE_VERIFICATION_SERVICE, PhoneVerificationServiceImpl.class);
        RpEventDataService rpEventService = (RpEventDataService) SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);

        // Do not call the supplier if the last passcode attempt was the last allowed submit attempt
        RefOtpSupplier supplier = rpEventService.getLatestPhoneSupplier(personVo);
        RpEvent event = rpEventService.getLatestPhoneVerification(personVo.getId(), supplier.getOtpSupplierId());
        passcode = getPasscode() != null ? getPasscode().trim() : getPasscode();
        String failureMessage = "";
        
        if (Utils.isEmptyString(passcode)) {
        	setSessionVerifyPhoneError(IPSConstants.PASSCODE_INVALID_NUMBER_MSG);
        } 
        else if ((supplier.isExperianPhone() && !(passcode.length() == 4 || passcode.length() == 6)) || (!supplier.isExperianPhone() && passcode.length() != 6)) {
           	setSessionVerifyPhoneError(IPSConstants.PASSCODE_INVALID_LENGTH_MSG);
     	}
        else {
    		Person person = personDataService.findByPK(personVo.getId());
            boolean exceededPasscodeAttemptsLimit = otpVelocityCheckService.exceededPasscodeAttemptsLimit(person, personVo, supplier, event);
            setSessionPersonVo(personVo);
            
            if (exceededPasscodeAttemptsLimit) {
            	//Maximum of 8 attempts per event in 72 hours
             	setSessionPersonVo(personVo);
                String logMsg = String.format("The User has exceeded passcode attempts limit for sponsorUserId: %s.", getPersonVo().getSponsorUserId());
                manageGotoPage(VERIFICATION_LOCKOUT, logMsg);   
  	        } 
            else {
            	boolean hasException = false;
                try {
                	otpSmfaAttemptsPerRequest = getSessionOtpSmfaAttempts();
                    
                	if (otpSmfaAttemptsPerRequest > 3) {
                    	//IVS enforces SUBMIT_EXCEEDED for Experian after more than 3 attempts
                       	setSessionVerifyPhoneError(IPSConstants.EXCEEDED_PASSCODE_REQUESTS_MSG + IPSConstants.SEND_NEW_CODE_NOW_MSG);
     		            setErrorCode(CODE_EXCEEDS_LIMIT);
                		manageGotoPage(VERIFICATION_ENTER_PASSCODE_PAGE, "Failed OTP confirmation.");   
                		return;
                	}
                	else {
                		setSessionOtpSmfaAttempts(otpSmfaAttemptsPerRequest + 1);
                	}
                	
                	personVo.setPasscode(getPasscode());
					passcodeConfirmed = phoneVerificationService.confirmPasscode(personVo, supplier, event);
					
					if (passcodeConfirmed) {
					   if(isHoldMail) {
	                        CustomLogger.debug(this.getClass(), "Passcode Confirmed, return to calling app and Calling app is " + callingAppName);
	                        returnToCallingApp(IPSConstants.PROOFING_RESULT_PASSED);
	                        return;
	                    }else {
	                    	// clear error message from prior failures if successful  
	                       	setSessionVerifyPhoneError(null);
	                    	goToInformedDeliverySuccessPage();
	                    	return;
	                    }
					}
					else {   
					   	RpOtpAttempt latestRequestOtpAttempt = getLatestOtpRequestAttempt(person.getPersonId(), supplier.getOtpSupplierId(), event.getEventId());
						passcodeExpired =  passcodeExpired(personVo, latestRequestOtpAttempt);
						if (passcodeExpired) {
								//TIMEOUT
		    		        	//Occurs with Experian, LexisNexis and Equifax IDFS (currently turned off in production)
		    		        	//IVS enforces TIMEOUT for all supplier after 5 minutes if the supplier does not return TIMEOUT code yet.
		    		        	setSessionVerifyPhoneError(IPSConstants.PASSCODE_EXPIRED_MSG + IPSConstants.SEND_NEW_CODE_NOW_MSG);
		    		        	return;
						}
						else {
							transactionKeyHasExpired = transactionKeyHasExpired(latestRequestOtpAttempt);
							if (transactionKeyHasExpired) {
								//Transaction expires after 30 minutes from last OTP attempt
		    		        	//IVS enforces for all supplier after 30 minutes 
		    		           	setSessionVerifyPhoneError(IPSConstants.TRANSACTION_EXPIRED_MSG);
		    		           	return;
							}
							else {
								submitAttemptsExceeded = submitAttemptsExceeded(personVo, latestRequestOtpAttempt); 
								if (submitAttemptsExceeded) {
									//SUBMIT_EXCEEDED = "TOO_MANY_SUBMIT_ATTEMPTS";
			                    	//Occurs both with LexisNexis and Equifax IDFS (currently turned off in production)
			                       	setSessionVerifyPhoneError(IPSConstants.EXCEEDED_PASSCODE_REQUESTS_MSG + IPSConstants.SEND_NEW_CODE_NOW_MSG);
			     		            setErrorCode(CODE_EXCEEDS_LIMIT);
			     		            return;
								}
								else {
									renewAttemptsExceeded = renewAttemptsExceeded(personVo, latestRequestOtpAttempt);
									if (renewAttemptsExceeded) {
										//RENEW_EXCEEDED = "TOO_MANY_RENEW_ATTEMPTS";
				    		        	//Only occurs with Equifax IDFS (currently turned off in production)
				                    	failureMessage = "Renew attempts exceeded.";
				                  		logFailedTransaction(person, personVo, failureMessage, supplier.getOtpSupplierId());
				    		            manageGotoPage(UNABLE_TO_VERIFY_PAGE, failureMessage);          
				    		            return;
									}
									else {
										submitAttemptsMismatched = submitAttemptsMismatched(personVo, latestRequestOtpAttempt);
										if (submitAttemptsMismatched) {
											//event.getLatestOtpAttempt().getRefOtpMatchQuality().getMatchQuality().equals(MISMATCH);
					    		        	//IVS enforces SUBMIT_EXCEEDED after 3 mismatched attempts for all suppliers
					    		           	setSessionVerifyPhoneError(IPSConstants.PASSCODE_INVALID_NUMBER_MSG);
					    		           	return;
										}
										else {
					    		        	//Other fail reason
					    		           	setSessionVerifyPhoneError(personVo.getErrorMessage());
					                    	failureMessage = "Failed OTP confirmation.";
					                  		logFailedTransaction(person, personVo, failureMessage, supplier.getOtpSupplierId());
					    		        	manageGotoPage(UNABLE_TO_VERIFY_PAGE, failureMessage);   
					    		        	return;
					    		        }
									}
								}
							}
						}
					}
				} catch (IPSException | CredentialsErrorFault | InvalidTransactionKeyFault | ValidationErrorFault e) {
	            	hasException = true;
	                CustomLogger.error(this.getClass(), "Could Not Send Passcode: ",e);
	               	setSessionVerifyPhoneError("Could not validate passcode.");
	            }
	            catch (PhoneVerificationException e) {
	            	hasException = true;
		            CustomLogger.error(this.getClass(), String.format("%s may be failing.", supplier.getOtpSupplierName()), e);
		           	setSessionVerifyPhoneError("Failed to validate passcode.");
	            } 
                
                if (hasException) {
		        	//Other system-failures
		           	setSessionVerifyPhoneError(personVo.getErrorMessage());
                	failureMessage = "Failed OTP confirmation.";
              		logFailedTransaction(person, personVo, failureMessage, supplier.getOtpSupplierId());
		        	manageGotoPage(UNABLE_TO_VERIFY_PAGE, failureMessage); 
                }
            }
        }
    }
    
    private boolean passcodeExpired(PersonVo personVo, RpOtpAttempt latestRequestOtpAttempt) {
    	if (personVo.isPasscodeExpired()) {
    		return true;
    	}
    	
    	boolean passcodeExpired = false;
    	int minutes = 5;

    	if (latestRequestOtpAttempt != null) {
    		 //IVS enforced expiration
	    	 Date otpSentDateTime = latestRequestOtpAttempt.getOtpSentDateTime();
	         CustomLogger.debug(this.getClass(), "ConfirmPasscode otpSentDateTime=" + otpSentDateTime);
	         Date minutesAgo = new Date(System.currentTimeMillis() - minutes*60*1000);
	         CustomLogger.debug(this.getClass(), String.format("ConfirmPasscode expires in %s. %s minutes passed.", minutes, minutesAgo));
	         passcodeExpired = (minutesAgo.compareTo(otpSentDateTime) > 0);

	         //Vendor enforced expiration
	     	 if (!passcodeExpired) {
	     		RefOtpMatchQuality latestMatchQuality = latestRequestOtpAttempt.getRefOtpMatchQuality();
	     		passcodeExpired = latestMatchQuality != null && latestMatchQuality.isExpired();
	     	 }
    	}

    	return passcodeExpired;
    }
    
    private boolean transactionKeyHasExpired(RpOtpAttempt latestRequestOtpAttempt) {
    	boolean transactionKeyHasExpired = false;
    	int minutes = 30;

    	if (latestRequestOtpAttempt != null) {
    		 //IVS enforced expiration
	    	 Date dateLatestRequestAttemptCreated = latestRequestOtpAttempt.getCreateDate();
	         CustomLogger.debug(this.getClass(), "ConfirmPasscode DateLatestRequestAttemptCreated=" + dateLatestRequestAttemptCreated);
	         Date minutesAgo = new Date(System.currentTimeMillis() - minutes * 60 * 1000);
	         CustomLogger.debug(this.getClass(), String.format("ConfirmPasscode expires in %s. %s minutes passed.", minutes, minutesAgo));
	         transactionKeyHasExpired = (minutesAgo.compareTo(dateLatestRequestAttemptCreated) > 0);
    	}

    	return transactionKeyHasExpired;
    }
    
    private boolean submitAttemptsExceeded(PersonVo personVo, RpOtpAttempt latestRequestOtpAttempt) {
    	if (personVo.isPasscodeSubmitExceeded()) {
    		return true;
    	}
    	
    	boolean submitAttemptsExceeded = false;

    	if (latestRequestOtpAttempt != null) {
    		RefOtpMatchQuality latestMatchQuality = latestRequestOtpAttempt.getRefOtpMatchQuality();
    		submitAttemptsExceeded = latestMatchQuality != null && latestMatchQuality.isSubmitExceeded();
        }
            
    	return submitAttemptsExceeded;
    }
    
    private boolean renewAttemptsExceeded(PersonVo personVo, RpOtpAttempt latestRequestOtpAttempt) {
    	boolean renewAttemptsExceeded = false;

    	if (latestRequestOtpAttempt != null) {
    		RefOtpMatchQuality latestMatchQuality = latestRequestOtpAttempt.getRefOtpMatchQuality();
    		renewAttemptsExceeded = latestMatchQuality != null && latestMatchQuality.isRenewExceeded();
        }
            
    	return renewAttemptsExceeded;
    }
    
    private boolean submitAttemptsMismatched(PersonVo personVo, RpOtpAttempt latestRequestOtpAttempt) {
    	if (personVo.isSubmitAttemptsMismatched()) {
    		return true;
    	}
    	
    	boolean submitAttemptsMismatched = false;

    	if (latestRequestOtpAttempt != null) {
    		RefOtpMatchQuality latestMatchQuality = latestRequestOtpAttempt.getRefOtpMatchQuality();
    		submitAttemptsMismatched = latestMatchQuality != null && latestMatchQuality.isMismatch();
        }
            
    	return submitAttemptsMismatched;
    }
    
    private RpOtpAttempt getLatestOtpRequestAttempt(long personId, long otpSupplierId, long rpEventId) {
        RpOtpAttempt latestAttempt = null;

        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        rpOtpAttemptDataService = (RpOtpAttemptDataService)SpringUtil.getInstance(ctx).getBean("rpOtpAttemptDataService");
         
        return rpOtpAttemptDataService.getLatestOtpRequestAttempt(personId, otpSupplierId, rpEventId);
    }
    
    public boolean isHoldMail() {
    	return isHoldMail; 
    }
    
    public String getMaskedPhoneNumberForUI() {
    	return this.getVerificationMaskedPhoneNumberForUI();
    }
 
    public void clearError() {
        setErrorMessage("");
    }
     
    public String getPasscode() {
        return passcode;
    }

    public void setPasscode(String passcode) {
        this.passcode = passcode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }  
	  
	public boolean isConfirmPasscodeInvoked() {
		return confirmPasscodeInvoked;
	}

	public void setConfirmPasscodeInvoked(boolean confirmPasscodeInvoked) {
		this.confirmPasscodeInvoked = confirmPasscodeInvoked;
	}

	public boolean isPasscodeConfirmed() {
		return passcodeConfirmed;
	}

	public void setPasscodeConfirmed(boolean passcodeConfirmed) {
		this.passcodeConfirmed = passcodeConfirmed;
	}

	public long getPhoneVerificationAttemptCount() {
		return phoneVerificationAttemptCount;
	}

	public void setPhoneVerificationAttemptCount(long phoneVerificationAttemptCount) {
		this.phoneVerificationAttemptCount = phoneVerificationAttemptCount;
	}

	public long getOtpOrSmfaRequestAttemptCount() {
		return otpOrSmfaRequestAttemptCount;
	}

	public void setOtpOrSmfaRequestAttemptCount(long otpOrSmfaRequestAttemptCount) {
		this.otpOrSmfaRequestAttemptCount = otpOrSmfaRequestAttemptCount;
	}

	public int getOtpSmfaAttemptsPerRequest() {
		return otpSmfaAttemptsPerRequest;
	}

	public void setOtpSmfaAttemptsPerRequest(int otpSmfaAttemptsPerRequest) {
		this.otpSmfaAttemptsPerRequest = otpSmfaAttemptsPerRequest;
	}

}
