package com.ips.bean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.ips.common.common.Utils;

@ManagedBean(name="learnmore")
@ViewScoped
public class LearnMoreBean extends IPSController implements Serializable {

    private static final String PRIVACY_POLICY_URL = "com.usps.PRIVACY_POLICY_URL";
    private static final String CUSTOMER_SERVICE_URL = "com.usps.CUSTOMER_SERVICE_URL";
    private static final String INFORMED_DELIVERY_URL = "com.usps.INFORMED_DELIVERY_URL";
    private static final long serialVersionUID = 1L;
    
    public String getInformedDeliveryLink() {
        return Utils.getProperty(INFORMED_DELIVERY_URL);
    }
    
    public String getCustomerServiceLink() {
        return Utils.getProperty(CUSTOMER_SERVICE_URL);
    }
    
    public String getPrivacyPolicyLink() {
        return Utils.getProperty(PRIVACY_POLICY_URL);
    }
}

