package com.ips.bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.DeviceReviewStatusEnum;
import com.ips.common.common.JSFUtils;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.Person;
import com.ips.entity.PersonData;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefApp;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefOtpVelocity;
import com.ips.entity.RefRpStatus.RpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RpEvent;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.DeviceAssessmentParamVo;
import com.ips.persistence.common.DeviceReputationResult;
import com.ips.persistence.common.ExperianResultVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationParamVo;
import com.ips.persistence.common.PhoneVerificationResponse;
import com.ips.proofing.PhoneVerificationService;
import com.ips.proofing.ProofingService;
import com.ips.proofing.VerificationProviderService;
import com.ips.service.DeviceReputationService;
import com.ips.service.DeviceReputationServiceImpl;
import com.ips.service.HighRiskAddressService;
import com.ips.service.PersonDataDataService;
import com.ips.service.PersonDataService;
import com.ips.service.PersonProofingStatusService;
import com.ips.service.RefLoaLevelService;
import com.ips.service.RefOtpSupplierDataService;
import com.ips.service.RpEventDataService;

@ManagedBean(name="userInfoHm")
@SessionScoped
public class VerificationUserInfoHmBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String profileNumber;
    private String errorMessage;
    private String verificationErrorMessage;
    boolean isDeviceProfilingEnabled;
    private String profilingOrgId;
    private String customerIpAddress;
 
    private RefOtpSupplier phoneSupplier;
    private DeviceAssessmentParamVo assessmentParamVo;
    private PhoneVerificationParamVo verificationParamVo;
    private DeviceReputationService deviceReputationService;
    private HighRiskAddressService highRiskAddressService;
    private PersonDataDataService personDataService;
    private PersonDataService personService;
    private ProofingService proofingService;
    private RefOtpSupplierDataService supplierService;
    private RpEventDataService eventService;
    private PhoneVerificationService phoneVerificationService;
    private VerificationProviderService verificationProviderService;
    private RefLoaLevelService refLoaLevelService;
    private PersonProofingStatusService personProofingStatusService;
    private boolean initialized;
    private boolean profilingComplete;
    private boolean verificationError;
    
    @PostConstruct
    @Override
    public void init() {
        CustomLogger.enter(this.getClass());
        
        loadServices();
    }

    public void loadServices() {
        CustomLogger.enter(this.getClass());
        
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
    
        highRiskAddressService = (HighRiskAddressService)SpringUtil.getInstance(ctx).getBean(HIGH_RISK_ADDRESS_SERVICE);
        personDataService = (PersonDataDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_DATA_SERVICE);
        personService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
        proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
        supplierService = (RefOtpSupplierDataService)SpringUtil.getInstance(ctx).getBean(REF_OTP_SUPPLIER_DATA_SERVICE);
        eventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        deviceReputationService = (DeviceReputationService)SpringUtil.getInstance(ctx).getBean(DEVICE_REPUTATION_SERVICE);
        phoneVerificationService = (PhoneVerificationService)SpringUtil.getInstance(ctx).getBean(PHONE_VERIFICATION_SERVICE);
        verificationProviderService = (VerificationProviderService)SpringUtil.getInstance(ctx).getBean(VERIFICATION_PROVIDER_SERVICE);
        refLoaLevelService = (RefLoaLevelService)SpringUtil.getInstance(ctx).getBean(REF_LOA_LEVEL_SERVICE);
        personProofingStatusService = (PersonProofingStatusService)SpringUtil.getInstance(ctx).getBean(PERSON_PROOFING_STATUS_SERVICE);

        CustomLogger.debug(this.getClass(), String.format("Remote proofing status: User has %s transaction.", isHoldMail ? "Hold Mail" : "Informed Delivery"));
    }
    
	/**
	 * Update user info 
	 * WARNING: This method is called twice on initial load and then called
	 * on each subsequent page load.  Because the VerificationUserInfoHmBean.java is a 
	 * session bean init() will not get called on every page load, only on the
	 * first one in the session.  Therefore, do not add things to the 
	 * updateUserInfo() method that you want to occur only once per session 
	 * and not once for every page load.
	 */
    public void updateUserInfo() {
        CustomLogger.enter(this.getClass());
        
        // Handle login in after page refresh
        verifyUserSessionData();
                
        setSponsorUserInfo();
         personVo = getSessionPersonVo();
        
        if (personVo != null) {
	        setPhoneNumber(personVo.getMobileNumber());    
	
	        // Retrieve person object from the database before updating proofing status
	        person = personService.findByPK(personVo.getId());
	        setPerson(person);
	        
	       	personVo.setCallingAppName(callingAppName);
	       	personVo.setCallingAppUrl(callingAppURL);
	       	
	       	phoneNumber = Utils.formatPhoneNumber(personVo.getPhoneNumber());

	        if (personVo.isRenderErrorMessage()) {
	        	personVo.setRenderErrorMessage(false);
	        }
	        else {
	           	FacesContext facesContext = FacesContext.getCurrentInstance(); 
	            @SuppressWarnings("deprecation")
				SendEquifaxSmfaBean sendEquifaxSmfa = (SendEquifaxSmfaBean) facesContext.getApplication()
	           	.getVariableResolver().resolveVariable(facesContext, "sendEquifaxSmfa");
	        }
	        
	        String sessionVerifyPhoneError = getSessionVerifyPhoneError();
	        if (StringUtils.isEmpty(sessionVerifyPhoneError)) {
	        	this.setVerificationError(false);
		    	this.setVerificationErrorMessage(null);	   
	        }
	        else {
	        	this.setVerificationError(true);
		    	this.setVerificationErrorMessage(sessionVerifyPhoneError);
		    	setSessionVerifyPhoneError(null);
	        }
	        
	       	setSessionPersonVo(personVo);
        }
        else {
          	returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        }
    }
    
    /**
     * Determine if the device profiling is enabled and ip address is successfully for obtained for customer's device.
     * If so, profilingSEssionId and profilingOrdId are set.
     * @return
     */
    public void initDeviceReputationProfiler(){
        CustomLogger.enter(this.getClass());
        
        String callingAppName = getSessionCallingAppName();
        PersonVo personVo = prepareSponsorId();
        isDeviceProfilingEnabled = deviceReputationService.isDeviceProfilingEnabled(personVo.getId(), personVo.getSponsorId(), callingAppName, true);
        setDeviceProfilingEnabled(isDeviceProfilingEnabled);
        boolean hasIpAddress = false;

        try {
            HttpSession session = getHttpServletRequest().getSession();
            String clientIPAddress =  (String) session.getAttribute(IPSConstants.CLIENT_IP_ADDR);
            setCustomerIpAddress(clientIPAddress);
            hasIpAddress = true;
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error occurred in getting host address: ", e);
        }    
                
        if (isDeviceProfilingEnabled() && hasIpAddress) {
        	CustomLogger.debug(this.getClass(), "Remote proofing status: Device profiling is enabled and IP address is obtained.");

            String sponsorUserId = personVo.getSponsorUserId();
            setProfilingSessionId(deviceReputationService.getProfilingSessionId(sponsorUserId));
            setProfilingOrgId(deviceReputationService.retrieveOrgId(sponsorUserId));    
        }
    }

    
    /*
     * This method verifyPhoneNumber will check to see if the mobile number is valid and associated with the user and 
     * then redirect them to the waiting page which will in turn redirect them to the verification_enter_passcode page
     */
    public void verifyPhoneNumber() throws Throwable {
        CustomLogger.enter(this.getClass());
          
        String loaSought = getPersonVo().getProofingLevelSought();
        Long statusCode = RpStatus.Started_remote_proofing.getValue();
        PersonProofingStatus proofingStatus = personProofingStatusService.getByPersonId((int)getPersonVo().getId());

        setSessionVerifyPhoneError(null);
 
        if (proofingStatus == null || !proofingStatus.getStatusCode().equals(statusCode)) {
        	proofingService.updateProofingStatus(statusCode, person, loaSought);
        }
  
        // Retrieve address_hash from person_data
        PersonVo personVo = prepareSponsorId();
        PersonData personData = personDataService.findByPK(personVo.getId());
        	
        String phoneNumber = getPhoneNumber();
        personVo.setPhoneNumber(phoneNumber);
        setSessionPersonVo(personVo);
        
        if (!StringUtils.isEmpty(phoneNumber)) {
        	String phoneNumericOnly = phoneNumber.replaceAll( "[^\\d]", "" );
        	if (phoneNumericOnly.length() != 10) {
        		setSessionVerifyPhoneError("Please enter a mobile number with 10 digits.");
        		return;
        	}

           	CustomLogger.debug(this.getClass(), String.format("Remote proofing status: User has entered the phone number:%s.", getPhoneNumber()));
            updatePhoneNumberInSession(getPhoneNumber()); 
            setPersonVo(getSessionPersonVo());

            // Clear phone supplier so the user can get the other supplier 
            // or be evaluated for repeat phone verification if they verify again
     		checkPreviousPhoneVerificationDecision(getPerson(), getPersonVo()); 
     		personVo = getSessionPersonVo();
        }
        else {
            CustomLogger.error(this.getClass(), "Phone number entered is null.");
            setSessionVerifyPhoneError("You must enter in a valid U.S. mobile phone number (e.g. XXX-XXX-XXXX)");
            return;
        }

        try {
            if (isHighRiskAddress(personData.getAddressHash())) {  
            	CustomLogger.debug(this.getClass(), "Remote proofing status: User has high risk address.");

                personVo.setDeviceAssessmentStatus(null);
                setSessionPersonVo(personVo);

                returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
            }
            else {     
            	DeviceReputationResult deviceReputationResult = null;
                assessmentParamVo = getAssessmentParamVo();
                  
                String callingAppName = getSessionCallingAppName();
                boolean isHoldMail = IPSConstants.HOLD_MAIL.equalsIgnoreCase(callingAppName) || RefApp.HOLD_MAIL.equalsIgnoreCase(callingAppName);
                
                //This method is only called from IPSWeb VerificationUserInfo and there are only 2 calling applications.
                callingAppName = isHoldMail ? RefApp.HOLD_MAIL : RefApp.INFORMED_DELIVERY;
                assessmentParamVo.setCallingAppName(callingAppName);
                
                if (isDeviceProfilingEnabled()) {
                    personVo.setTrueIPAddress(this.customerIpAddress);
                    
                    deviceReputationResult = getDeviceReputationResult(person, personVo, assessmentParamVo);
                    DeviceReviewStatusEnum reviewStatus = deviceReputationResult.getDeviceReviewStatus();
                    
                    personVo.setDeviceAssessmentStatus(reviewStatus.getReviewStatus());
                    setSessionPersonVo(personVo);
                    
                    if (reviewStatus == DeviceReviewStatusEnum.PASS) {
                        //Redirect user to the Proofing Success page.  
                        returnToCallingApp(IPSConstants.PROOFING_RESULT_PASSED);
                      	CustomLogger.debug(this.getClass(), "Remote proofing status: User device reputation has high confidence.");
                        return;
                    }
                    else if (reviewStatus == DeviceReviewStatusEnum.REJECT) {
                       	CustomLogger.debug(this.getClass(), "Remote proofing status: User device reputation has low confidence.");

                        //Redirect user to Unable to Verify page where the user has the option to find Post Office for in-person proofing.    
                        returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
                        return;
                    }
                    else {
                       	CustomLogger.debug(this.getClass(), "Remote proofing status: User device reputation has medium confidence.");
                    }
                }
                else {
                   	//Create RpDeviceReputation if Device Profiling is not enabled
                	assessmentParamVo.setReviewStatus(DeviceReviewStatusEnum.REVIEW.getReviewStatus());
                	assessmentParamVo.setReputationAssessment(DeviceReviewStatusEnum.REVIEW.getReputationAssessment());
                	assessmentParamVo.setCallingAppName(callingAppName);
                	assessmentParamVo.setDeviceScore(0);
                	assessmentParamVo.setRequestId(null);
                	assessmentParamVo.setMobilePhoneNumber(personVo.getMobileNumber());
                	
                	deviceReputationService.recordDeviceAssessmentAttempt(person, assessmentParamVo);
                   	CustomLogger.debug(this.getClass(), "Remote proofing status: Device profiling is disabled and device reputation assessment is bypassed.");
                }
                 
                verifyPhone(getPerson(), personVo, deviceReputationResult);
             }
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred on verifyPhone for user: " + getPersonVo().getSponsorUserId(), e);
            returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        }
    }
    
    public void cancelPhoneVerification() {
        CustomLogger.enter(this.getClass());
        
        // Retrieve address_hash from person_data
        PersonVo personVo = getPersonVo();
        PersonData personData = personDataService.findByPK(personVo.getId());
        boolean isLowDeviceReputation = deviceReputationService.isLowDeviceReputation(personVo);
        boolean isHighRiskAddress = isHighRiskAddress(personData.getAddressHash());
        String logMsg = "Phone Verification Cancelled for Hold Mail user with sponsorUserId " +  personVo.getSponsorUserId();

        if (isHighRiskAddress || isLowDeviceReputation) {
        	if (isLowDeviceReputation) {
                DeviceReviewStatusEnum rejectStatus = DeviceReviewStatusEnum.REJECT;        
                personVo.setDeviceAssessmentStatus(rejectStatus.getReviewStatus());
                setSessionPersonVo(personVo);
            }
        	
        	logMsg = String.format("%s %s", logMsg, (isHighRiskAddress? " with high risk address." : " with low device reputation."));
            returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        }
        else {
           	returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        }
    }
    
    /**
     * Determine if the customer's address is on the high-risk list.
     * @param addressHash
     * @return
     */
    private boolean isHighRiskAddress(int addressHash) {
        CustomLogger.enter(this.getClass());
        
        PersonVo personVo = getPersonVo();
        boolean isHighRisk = highRiskAddressService.highRiskAddressCheck(addressHash, personVo);
        setSessionPersonVo(personVo);
        return isHighRisk;
    }
        
    /**
     * Logic to verify the customer's phone number.  Will only be called if the customer does not have a high risk address 
     * and does have medium confidence device reputation.
     * @throws PhoneVerificationException 
     * @throws IPSException 
     */ 
    private void verifyPhone(Person person, PersonVo personVo, DeviceReputationResult deviceReputationResult) throws Throwable {
        CustomLogger.enter(this.getClass());
        
        PhoneVerificationResponse pvResponse = null;
  
        verificationParamVo = getVerificationParamVo();
        verificationParamVo.setMobilePhoneNumber(getPhoneNumber());
        personVo.setResetProofingStatus(false);
        
        //Check if the device assessment is individualNotFound. If so, the transaction is sent to Experian or Equifax.
        // if deviceReputationResult is null, then individualNotFound = false
        boolean individualNotFound = false;
        if (deviceReputationResult != null) {
        	individualNotFound = DeviceReputationResult.DISCO_FAIL_REASON_INDIVIDUAL_NOT_FOUND.equalsIgnoreCase(deviceReputationResult.getDiscoveryProductReasonCode());
        }
        setPhoneSupplier(determineVerificationMethod(individualNotFound));
      	personVo.setCurrentPhoneVerificationSupplierId(getPhoneSupplier().getOtpSupplierId());

        // Every time the user goes to the User Information page and clicks Continue, a new event should be created
        try {                               
            // Velocity check for phone verification needs to be done before continuing with the vendor call 
        	personVo.setCallingVelocityType(IPSConstants.VELOCITY_TYPE_PHONE);
        	RefOtpVelocity phoneVelocity = proofingService.phoneVelocityCheck(person, personVo, phoneSupplier);
        	boolean passVelocityCheck = !phoneVelocity.isExceedPhoneVerificationLimit() && !phoneVelocity.isLockoutStillInEffect();

        	if (passVelocityCheck) {
        		if (phoneVelocity.isExceedPhoneRepeatAssessmentLimit()) {
               	    returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
               		return;
              	}
        		
              	CustomLogger.debug(this.getClass(), "Remote proofing status: User has passed phone velocity check.");
    
                // If the EID Decision is not Y, the user's identity cannot be verified
                // Only go to the Unable to Verify/Cancel Confirmed page if the overall assessment is FAIL and EID is N
                
                pvResponse = verifyPhone(personVo);  

           		if (personVo.isAlternateSupplierForCustNotOnFile() && pvResponse != null) {
                    pvResponse.setPhoneVerificationDecision(personVo.getPhoneVerificationDecision());
          			personVo.setAlternateSupplierForCustNotOnFile(false);
           		}
           		
                setSessionPersonVo(personVo);
            } else {
                resetErrorMessage();
                returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
                return;
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred during phone verification for sponsorUserId:" + (person != null? person.getSponsorUserId() : "null"), e);
            returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
            return;
        }
        
   		resetErrorMessage();    // Clear error message when phone number verified successfully
   		
        if (pvResponse != null) {
        	String pvDecision = pvResponse.getPhoneVerificationDecision();
       		long supplierId = pvResponse.getPhoneVerificationSupplierId(); 
          	CustomLogger.debug(this.getClass(), String.format("Remote proofing status: Phone verification decision is %s by %s.", 
          			pvDecision, pvResponse.getPhoneVerificationSupplierName()));
        	CustomLogger.debug(this.getClass(), String.format("Remote proofing status: Phone verification supplier Id> From PvResponse: %s, From Person: %s.", 
        			pvResponse.getPhoneVerificationSupplierId(), personVo.getCurrentPhoneVerificationSupplierId()));

          	if (PhoneVerificationResponse.PV_DECISION_PASS.equalsIgnoreCase(pvDecision) 
          			|| PhoneVerificationResponse.PV_DECISION_APPROVE.equalsIgnoreCase(pvDecision)) {
         		if (RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID == supplierId || RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID == supplierId) {
        			returnToCallingApp(IPSConstants.PROOFING_RESULT_PASSED);
     			}
         	}
        	else if (PhoneVerificationResponse.PV_DECISION_REVIEW.equalsIgnoreCase(pvDecision)) {
				if (RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID == supplierId) {
     				goToPage(VERIFICATION_SEND_SMFA_PAGE);
     			}
				else if (RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID == supplierId) {
					if (ExperianResultVo.NEXT_ACTION_INIT_BOKU_OTP.equalsIgnoreCase(pvResponse.getNextAction())) {
						goToPage(VERIFICATION_REQUEST_PASSCODE_PAGE);
					} else if (ExperianResultVo.NEXT_ACTION_RESUME_BOKU_OTP.equalsIgnoreCase(pvResponse.getNextAction())) {
						goToPage(VERIFICATION_ENTER_PASSCODE_PAGE);
					} else if (ExperianResultVo.NEXT_ACTION_INVOKE_BOKU_URL.equalsIgnoreCase(pvResponse.getNextAction())) {
						goToPage(String.format("%s?resultid=%s", VERIFICATION_URL_INVOCATION_PAGE, pvResponse.getRecordId()));
					} else if (ExperianResultVo.NEXT_ACTION_SUBMIT_VALID_PHONE.equalsIgnoreCase(pvResponse.getNextAction())) {
		                setSessionVerifyPhoneError(IPSConstants.UNABLE_TO_VERIFY_PHONE_MSG);
						goToPage(VERIFICATION_USER_INFO_HM_PAGE);
					}
					else {
						goToPage(VERIFICATION_USER_INFO_HM_PAGE);
					}
     			} else {
     				goToPage(VERIFICATION_REQUEST_PASSCODE_PAGE);
            	}
        	} else  {
        		if (RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID == supplierId) {
                  	boolean isPassedLexisNexisCurrentResidencyCheck = isPassedLexisNexisCurrentResidencyCheck();

                  	String logMsgFmt = "Phone verification with LexisNexis has failed and current residency check has %s.";
                  	if (isPassedLexisNexisCurrentResidencyCheck) {
                  		personVo.setRenderErrorMessage(true);
                  		setSessionPersonVo(personVo);
                        setSessionVerifyPhoneError(IPSConstants.UNABLE_TO_VERIFY_PHONE_MSG);
                  		goToPage(VERIFICATION_USER_INFO_HM_PAGE);
                  	} else {
                   		returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
                  	}
                } else if (RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID == supplierId) {
         			returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        		} else if (RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID == supplierId) {
                 	String logMsgFmt = "Phone verification with Experian PreciseID has failed.";

        			if (Utils.isEmptyString(pvResponse.getEventFinalDecision())) {
                 		personVo.setRenderErrorMessage(true);
                  		setSessionPersonVo(personVo);
                        setSessionVerifyPhoneError(IPSConstants.UNABLE_TO_VERIFY_PHONE_MSG);
 
                        goToPage(VERIFICATION_USER_INFO_HM_PAGE);
        			} else {
           				returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        			}
        		} else if (RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID == supplierId && PhoneVerificationResponse.PV_DECISION_FAIL.equalsIgnoreCase(pvDecision)) {
        			personVo.setDitDecision(pvDecision);
        			setSessionPersonVo(personVo);
         			returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        		} else {
                  	String logMsgFmt = "Phone verification has failed with error %s.";
               		returnToCallingApp(IPSConstants.PROOFING_RESULT_FAILED);
        		}
             }
         }
    }

    @Override
    public String getPhoneNumber() {
        CustomLogger.enter(this.getClass());
        
        if (phoneNumber == null) {
        	PersonVo personVo = getPersonVo(); 
          	phoneNumber = personVo.getMobileNumber();
        }
        
        if(phoneNumber != null && phoneNumber.length() > 10 ) {
            phoneNumber = Utils.removeNonNumericCharactersFromString(phoneNumber);
        }
        return phoneNumber;
    }

    public String getPhoneNumberForUI() {
        CustomLogger.enter(this.getClass());
        
        // Since this bean is SessionScoped, the phone number should always
        // be retrieved from the database to ensure that a previous user's
        // phone number from the same browser session is not used
        getSavedPhone();
        setPersonVo(getSessionPersonVo());
        setPhoneNumber(getPersonVo().getMobileNumber());
        
        if(!phoneNumber.isEmpty()) {
                String number = phoneNumber.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");
                CustomLogger.debug(this.getClass(), "Phone number returned by getPhoneNumberForUI " + number);
                return number;
        } else {
            return "";
        }
    }
    
    @Override
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    @Override
    public void resetErrorMessage() {
        CustomLogger.enter(this.getClass());
        
        setSessionVerifyPhoneError(null);
        setPhoneNumber("");
        getPersonVo().setMobileNumber(phoneNumber);
    }

    private PhoneVerificationResponse verifyPhone(PersonVo personVo) throws Throwable {
        CustomLogger.enter(this.getClass());
 
        // SponsorId is getting wiped out between calls to verifyPhone causing issues with supplier failover - make sure it's set
        personVo.setSponsorId(RefSponsor.SPONSOR_ID_CUSTREG);
        personVo.setTransactionOriginAppName(isHoldMail ? RefApp.HOLD_MAIL : RefApp.INFORMED_DELIVERY);
        personVo.setAppId(isHoldMail ? RefApp.HOLD_MAIL_APP_ID : RefApp.INFORMED_DELIVERY_APP_ID);
        PhoneVerificationResponse pvResponse = null;
        RefOtpSupplier otpSupplier = null;
        
        try {
        	personVo.setWebServiceCall(false);
         	otpSupplier = getPhoneSupplier();
          	pvResponse = phoneVerificationService.verifyPhone(personVo, otpSupplier);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), String.format("Exception occurred on verifying phone with %s for user: %s", 
					(otpSupplier != null ? otpSupplier.getOtpSupplierName() : "null"), personVo.getSponsorUserId()), e);
		}
        
        if (getPhoneSupplier().isLexisNexisPhone()) {
        	setPassedLexisNexisCurrentResidencyCheck(phoneVerificationService.isPrecheckPassed());
        }        
        return pvResponse;
    }
      
    private PersonVo prepareSponsorId() {
          CustomLogger.enter(this.getClass());
          
        PersonVo personVo = getPersonVo();
        personVo.setSponsorId(RefSponsor.SPONSOR_ID_CUSTREG);
        personVo.setTransactionOriginAppName(isHoldMail ? RefApp.HOLD_MAIL : RefApp.INFORMED_DELIVERY);
        return personVo;
    }
      
    /**
     * This is needed for the case where switching is configured between the OTP suppliers.  If the call switches to the other supplier, the correct
     * event must be retrieved.
     * @return
     */
    public RpEvent getLatestEvent() {    
        CustomLogger.enter(this.getClass());
        
        RpEvent event = null;
        
        List<RpEvent> events = eventService.findEventByPersonId(getSessionPersonVo().getId());
        if (!events.isEmpty()) {
            event = events.get(0);
            phoneSupplier = event.getRefOtpSupplier();
        }
        
        return event;
    }
      
       
    /**
     * Determine the DeviceReputationResult result returned fromLexisNexis RDP web service call.
     * If the service call has exception, the status is set to the default value of "review".
     * @return DeviceReputationResult
     */
    private DeviceReputationResult getDeviceReputationResult(Person person, PersonVo personVo, DeviceAssessmentParamVo assessmentParamVo) {
        CustomLogger.enter(this.getClass());
        
        DeviceReputationResult deviceReputationResult = new DeviceReputationResult();

        try {
        	assessmentParamVo.setCallingAppName(RefApp.HOLD_MAIL);
        	deviceReputationResult = deviceReputationService.createDeviceReputationResult(person, personVo, assessmentParamVo);
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred on assessing device reputation for user: " + personVo.getSponsorUserId(), e);

            DeviceReviewStatusEnum deviceReviewStatus = DeviceReviewStatusEnum.REVIEW;
            deviceReputationResult.setDeviceReviewStatus(deviceReviewStatus);
        }    
        setAssessmentParamVo(assessmentParamVo);
        
        return deviceReputationResult;
    }
      
    private void checkPreviousPhoneVerificationDecision(Person person, PersonVo personVo) {
	    //Previous phone verification decision check needs to be done to determine if there was one.
	    boolean hasPreviousPhoneVerificationDecision = false;
	    RefOtpSupplier prevSupplier = null;
	    
		try {
			hasPreviousPhoneVerificationDecision = phoneVerificationService.hasPreviousPhoneVerificationDecision(person, personVo,  verificationParamVo);
		} catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error occurred in checking previous phone verification decision: ", e);
        }  
	
	    // Retrieve the phone supplier that is set if it has previous phone verification decision.
	    if (hasPreviousPhoneVerificationDecision) {  
	       	CustomLogger.debug(this.getClass(), "Remote proofing status: User has previous phone verification.");
  
	       	long prevSupplierId = personVo.getPreviousPhoneVerificationSupplierId();
	    	personVo.setCurrentPhoneVerificationSupplierId(prevSupplierId);
	       	prevSupplier = supplierService.findBySupplierId(prevSupplierId);
            setPhoneSupplier(prevSupplier);
	    } 
	    else {	 
	       	CustomLogger.debug(this.getClass(), "User has no previous phone verification. User is getting new phone supplier.");
   	        // If there was no previous phone verification decision,
	       	// clear phone supplier so the user can get the other supplier. 
	    }
	    
        setSessionPersonVo(personVo);
    }
    
	public void redirectPage() {
        CustomLogger.enter(this.getClass());
        
        HttpSession session = getHttpServletRequest().getSession();
        String nextPageUrl =(String) session.getAttribute(IPSConstants.REDIRECT_PAGE_URL_KEY);
         
        try {
        	if (nextPageUrl != null) {
       	       	session.setAttribute(IPSConstants.REDIRECT_PAGE_URL_KEY, null);
        		FacesContext.getCurrentInstance().getExternalContext().redirect(nextPageUrl);
        	}
		} catch (IOException e) {
	        CustomLogger.error(this.getClass(), "redirectPage to page" + nextPageUrl);
		}  
	}
    
	@Override
    public String getErrorMessage() {
        return errorMessage;
    }

	@Override
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getProfileNumber() {
        return profileNumber;
    }

    public void setProfileNumber(String profileNumber) {
        this.profileNumber = profileNumber;
    }

    public RefOtpSupplier getPhoneSupplier() {
 
        // if the phone supplier is not set because this is an existing user returning to IVS,
        // then determineVerificationMethod can be called.  It must not be called again for a new user.
        if (phoneSupplier == null) {
        	 setPhoneSupplier(determineVerificationMethod(false));
        }
        
        return phoneSupplier;
    }

    public void setPhoneSupplier(RefOtpSupplier phoneSupplier) {
        this.phoneSupplier = phoneSupplier;
    }

    @Override
    public boolean isDeviceProfilingEnabled() {
        CustomLogger.enter(this.getClass(), "isDeviceProfilingEnabled=" + isDeviceProfilingEnabled);
    
        return isDeviceProfilingEnabled;
    }

    @Override
    public void setDeviceProfilingEnabled(boolean isDeviceProfilingEnabled) {
        this.isDeviceProfilingEnabled = isDeviceProfilingEnabled;
    }

    public String getProfilingOrgId() {
        return profilingOrgId;
    }

    public void setProfilingOrgId(String profilingOrgId) {
        this.profilingOrgId = profilingOrgId;
    }

    @Override
    public String getProfilingSessionId() {
        return profilingSessionId;
    }

    @Override
    public void setProfilingSessionId(String profilingSessionId) {
        this.profilingSessionId = profilingSessionId;
    }

    @Override
    public String getCustomerIpAddress() {
        return customerIpAddress;
    }

    @Override
    public void setCustomerIpAddress(String customerIpAddress) {
        this.customerIpAddress = customerIpAddress;
    }

    public boolean isInitialized() {
        CustomLogger.enter(this.getClass(), "isInitialized()=" + initialized);
        
        return initialized;
    }

    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }

    public boolean isProfilingComplete() {
        CustomLogger.enter(this.getClass(), "isProfilingComplete()=" + profilingComplete);
        
        return profilingComplete;
    }

    public void setProfilingComplete(boolean profilingComplete) {
        this.profilingComplete = profilingComplete;
    }

    public DeviceAssessmentParamVo getAssessmentParamVo() {
        if (assessmentParamVo == null) {
            assessmentParamVo = new DeviceAssessmentParamVo();
        }
        
        String callingAppName = getSessionCallingAppName();
        boolean isHoldMail = IPSConstants.HOLD_MAIL.equalsIgnoreCase(callingAppName) || RefApp.HOLD_MAIL.equalsIgnoreCase(callingAppName);

        //This method is only called from IPSWeb VerificationUserInfo and there are only 2 calling applications.
        callingAppName = isHoldMail ? RefApp.HOLD_MAIL : RefApp.INFORMED_DELIVERY;
        assessmentParamVo.setCallingAppName(callingAppName);
        assessmentParamVo.setSessionId(getProfilingSessionId());
        assessmentParamVo.setMobilePhoneNumber(getPhoneNumber());

        return assessmentParamVo;
    }

    public void setAssessmentParamVo(DeviceAssessmentParamVo assessmentParamVo) {
        this.assessmentParamVo = assessmentParamVo;
    }

    public PhoneVerificationParamVo getVerificationParamVo() {
        if (verificationParamVo == null) {
            verificationParamVo = new PhoneVerificationParamVo();
        }
        return verificationParamVo;
    }

    public void setVerificationParamVo(PhoneVerificationParamVo verificationParamVo) {
        this.verificationParamVo = verificationParamVo;
    }

    public String getVerificationErrorMessage() {
		return verificationErrorMessage;
	}

	public void setVerificationErrorMessage(String verificationErrorMessage) {
		this.verificationErrorMessage = verificationErrorMessage;
	}

	public boolean isVerificationError() {
		return verificationError;
	}

	public void setVerificationError(boolean verificationError) {
		this.verificationError = verificationError;
	}
}
