package com.ips.bean;

import java.io.Serializable;
import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.Utils;


@ManagedBean(name="navBean")
@SessionScoped
public class NavBean implements Serializable {    
        
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    FacesContext context = FacesContext.getCurrentInstance();
    
    /**
     * retrieve the current page name
     * @return
     */
    public String getPageName() {
        context = FacesContext.getCurrentInstance();  
        String viewRootId = context.getViewRoot().getViewId();
        return viewRootId.substring(viewRootId.lastIndexOf('/')+1,viewRootId.indexOf('.'));        
    }
    
    public String getSystemErrorCode() {
        String errorCode = DateTimeUtil.getDateString(new Date(),"yyyyMMddHHmmss"); 
        String env = Utils.getEnvironment();

        if ("dev.".equalsIgnoreCase(env)) {
            errorCode += "D";
        }
        else if ("sit.".equalsIgnoreCase(env)) {
            errorCode += "S";
        }
        else if ("cat.".equalsIgnoreCase(env)) {
            errorCode += "C";
        }
        else if ("prod.".equalsIgnoreCase(env)) {
            errorCode += "P";
        }
      
        return errorCode;
    }

}

