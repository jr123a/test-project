/**
 * 
 */
package com.ips.bean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.ips.common.common.CustomLogger;

/**
 * @author QMFTM0
 *
 */

// what is this bean for? remove it?
// This Bean extends VerificationBean (inheritance) and therefore has all the functionality of that bean with a different unique bean name
@ManagedBean(name="passcodesuccessful")
@ViewScoped
public class PasscodeSuccessfulBean extends VerificationBean implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @PostConstruct
    @Override
    public void init() {
        CustomLogger.enter(this.getClass());
        
    }
    
    public String getMaskedPhoneNumberForUI() {
    	return this.getVerificationMaskedPhoneNumberForUI();
    }
}
