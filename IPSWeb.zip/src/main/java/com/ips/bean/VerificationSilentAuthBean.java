package com.ips.bean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.Person;
import com.ips.persistence.common.ExperianResultVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.proofing.ExperianServiceImpl;
import com.ips.service.PersonDataService;

@ManagedBean(name="silentAuth")
@SessionScoped
public class VerificationSilentAuthBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;
     
    public static String bokuAuthenticationUrl;
    public static boolean initialize;
    
    @PostConstruct
    @Override
    public void init() {
        CustomLogger.enter(this.getClass());
    }
    
    public void verifySilentAuth() {
        CustomLogger.enter(this.getClass());
        
        request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        HttpSession httpSession = request.getSession();
        setPersonVo(getSessionPersonVo());
        
        if (httpSession != null) {
        	personVo = getSessionPersonVo();
     		
       		String responseOk = request.getParameter("responseok");
       		String responseStatus = request.getParameter("responsestatus");
      		String bokuCorrelationId = request.getParameter("correlationid");
      		String bokuReferenceId = request.getParameter("referenceid");
 
       		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
    	 	WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);
    	 	ExperianServiceImpl experianService = null;
    	 	
    	 	if (webAppCtx != null) {
    	 		experianService = webAppCtx.getBean("experianService", ExperianServiceImpl.class);
    	 	}
    	 	
            PersonDataService personService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
  			Person person = personService.findByPK(personVo.getId());
	
  			try {
				 ExperianResultVo resultVo = new ExperianResultVo();
				 resultVo.setBokuAuthenticationKey(bokuReferenceId);
				 resultVo.setBokuCorrelationId(bokuCorrelationId);
				 resultVo.setUrlInvocationResponse(String.format("response.ok=%s&response.status=%s", responseOk, responseStatus));
				 boolean silentAuthenticationSuccessful =  experianService != null?
						 experianService.silentAuthenticationSuccessful(person, personVo, resultVo) : false;

				 if (silentAuthenticationSuccessful) {
					 if(isHoldMail) {
			                CustomLogger.debug(this.getClass(), "Silent Authentication Successful for Hold Mail, return to calling app and Calling app is " + callingAppName);
			                returnToCallingApp(IPSConstants.PROOFING_RESULT_PASSED);
			                return;
			          }else {
			            	// clear error message from prior failures if successful  
				        	setSessionVerifyPhoneError(null);

			            	goToInformedDeliverySuccessPage();
			          }
				 } else {
					boolean sendPasscodeSuccessful = experianService != null?
							experianService.resendPasscodeSuccessful(person, personVo) : false;

					if (sendPasscodeSuccessful) {
						goToPage(VERIFICATION_ENTER_PASSCODE_PAGE);
					} else {
						goToPage(VERIFICATION_REQUEST_PASSCODE_PAGE);
					}
				}
			} catch (Exception ex) {
				CustomLogger.error(this.getClass(),
						"Exception occurred during Person findByPK call for sponsorUserId: "
								+ personVo.getSponsorUserId() + " " + personVo.getFullName(), ex);
 			}
 			
   	      	phoneNumber = Utils.formatPhoneNumber(personVo.getPhoneNumber());
        }
    }

	public String getBokuAuthenticationUrl() {
		return bokuAuthenticationUrl;
	}

	public void setBokuAuthenticationUrl(String bokuAuthenticationUrl) {
		this.bokuAuthenticationUrl = bokuAuthenticationUrl;
	}

	public boolean isInitialize() {
		return initialize;
	}

	public void setInitialize(boolean initialize) {
		this.initialize = initialize;
	}

	
}
