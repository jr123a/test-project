package com.ips.bean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.UserVo;
import com.ips.common.common.CustomLogger;
import com.ips.proofing.ProofingService;
import com.ips.proofing.ProofingServiceImpl;

@ManagedBean(name="verificationFailure")
@ViewScoped
public class VerificationFailureBean extends IPSController implements
        Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private UserVo user;
    private String confirmationNumber;
    
    @PostConstruct
    public void init(){

    }
    
    /**
     * Put this in a separate method rather than init so that the routing to the 
     * System error page will work.
     */
    public void checkForObjects() {
    	verifyUserSessionData();
        user = getSessionUser();
        
        if(user == null){
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Cannot load user info");
            goToPage(SYSTEM_ERROR_PAGE);
        }
        else {
             showConfirmationNumber();
        }
    }
    
    private void showConfirmationNumber(){
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
	 	WebApplicationContext  webAppCtx = WebApplicationContextUtils.getWebApplicationContext(ctx);

	 	if (webAppCtx != null) {
	 		ProofingService service = webAppCtx.getBean(PROOFING_SERVICE, ProofingServiceImpl.class);
        	confirmationNumber = service.displayConfirmationNumber(user);    
	 	}
    }

    public String getConfirmationNumber() {
        return confirmationNumber;
    }

    public void setConfirmationNumber(String confirmationNumber) {
        this.confirmationNumber = confirmationNumber;
    }

}
