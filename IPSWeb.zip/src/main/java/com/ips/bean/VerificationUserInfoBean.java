package com.ips.bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;

import com.ips.common.common.CustomLogger;
import com.ips.common.common.DateTimeUtil;
import com.ips.common.common.SpringUtil;
import com.ips.common.common.Utils;
import com.ips.entity.Person;
import com.ips.entity.PersonData;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefApp;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefOtpVelocity;
import com.ips.entity.RefRpStatus.RpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RpDeviceReputation;
import com.ips.entity.RpEvent;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.DeviceAssessmentParamVo;
import com.ips.persistence.common.DeviceReputationResult;
import com.ips.persistence.common.ExperianResultVo;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.persistence.common.PhoneVerificationParamVo;
import com.ips.persistence.common.PhoneVerificationResponse;
import com.ips.proofing.PhoneVerificationService;
import com.ips.proofing.ProofingService;
import com.ips.proofing.VerificationProviderService;
import com.ips.service.PersonDataDataService;
import com.ips.service.PersonDataService;
import com.ips.service.PersonProofingStatusService;
import com.ips.service.RefLoaLevelService;
import com.ips.service.RefOtpSupplierDataService;
import com.ips.service.RpDeviceReputationService;
import com.ips.service.RpEventDataService;
import com.ips.service.SponsorIncomingRequestsService;

@ManagedBean(name="userInfo")
@SessionScoped
public class VerificationUserInfoBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String errorMessage;
    private String verificationErrorMessage;
    private RefOtpSupplier phoneSupplier;
    private PhoneVerificationParamVo verificationParamVo;
    
    private PersonDataDataService personDataService;
    private PersonDataService personService;
    private PhoneVerificationService phoneVerificationService;
    private ProofingService proofingService;
    private RefOtpSupplierDataService supplierService;
    private RpDeviceReputationService rpDeviceReputationService;
    private RpEventDataService eventService;
    private RefLoaLevelService refLoaLevelService;
    private PersonProofingStatusService personProofingStatusService;
    private boolean initialized;
    private boolean verificationError;
     
    @PostConstruct
    @Override
    public void init() {
        CustomLogger.enter(this.getClass());
        
        loadServices();
    }

    public void loadServices() {
        CustomLogger.enter(this.getClass());
        
        ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
    
        personDataService = (PersonDataDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_DATA_SERVICE);
        personService = (PersonDataService)SpringUtil.getInstance(ctx).getBean(PERSON_DATA_SERVICE);
        phoneVerificationService = (PhoneVerificationService)SpringUtil.getInstance(ctx).getBean(PHONE_VERIFICATION_SERVICE);
        proofingService = (ProofingService)SpringUtil.getInstance(ctx).getBean(PROOFING_SERVICE);
        supplierService = (RefOtpSupplierDataService)SpringUtil.getInstance(ctx).getBean(REF_OTP_SUPPLIER_DATA_SERVICE);
        rpDeviceReputationService = (RpDeviceReputationService)SpringUtil.getInstance(ctx).getBean(RP_DEVICE_REPUTATION_SERVICE);
        eventService = (RpEventDataService)SpringUtil.getInstance(ctx).getBean(RP_EVENT_SERVICE);
        refLoaLevelService = (RefLoaLevelService)SpringUtil.getInstance(ctx).getBean(REF_LOA_LEVEL_SERVICE);
        personProofingStatusService = (PersonProofingStatusService)SpringUtil.getInstance(ctx).getBean(PERSON_PROOFING_STATUS_SERVICE);
         
        CustomLogger.debug(this.getClass(), String.format("Remote proofing status: User has %s transaction.", isHoldMail ? "Hold Mail" : "Informed Delivery"));
    }
    
	/**
	 * Update user info 
	 * WARNING: This method is called twice on initial load and then called
	 * on each subsequent page load.  Because the UserInfoBean.java is a 
	 * session bean init() will not get called on every page load, only on the
	 * first one in the session.  Therefore, do not add things to the 
	 * updateUserInfo() method that you want to occur only once per session 
	 * and not once for every page load.
	 */
    public void updateUserInfo() {
        CustomLogger.enter(this.getClass());
        
        PersonVo personVo = getSessionPersonVo();
        
        if (personVo != null) {
        	setPersonVo(getSessionPersonVo());
	        setSponsorUserInfo();
	        setPersonVo(getSessionPersonVo());
	        setPhoneNumber(personVo.getMobileNumber());    
	
	        // Retrieve person object from the database before updating proofing status
	        person = personService.findByPK(personVo.getId());
	        setPerson(person);
	        
	       	personVo.setCallingAppName(callingAppName);
	       	personVo.setCallingAppUrl(callingAppURL);

	        setPhoneNumber(personVo.getPhoneNumber());
	        
	        if (personVo.isRenderErrorMessage()) {
	        	personVo.setRenderErrorMessage(false);
	        }
	        else {
	           	FacesContext facesContext = FacesContext.getCurrentInstance(); 
	           	@SuppressWarnings("deprecation")
				SendEquifaxSmfaBean sendEquifaxSmfa = (SendEquifaxSmfaBean) facesContext.getApplication()
	           	.getVariableResolver().resolveVariable(facesContext, "sendEquifaxSmfa");
	        }
	        
	        String sessionVerifyPhoneError = getSessionVerifyPhoneError();
	        if (StringUtils.isEmpty(sessionVerifyPhoneError)) {
	        	this.setVerificationError(false);
		    	this.setVerificationErrorMessage(null);	   
	        }
	        else {
	        	this.setVerificationError(true);
		    	this.setVerificationErrorMessage(sessionVerifyPhoneError);
		    	setSessionVerifyPhoneError(null);
	        }
	        
	       	setSessionPersonVo(personVo);
        }
        else {
        	goToPage(SYSTEM_ERROR_PAGE);
        }
    }
  
 
    /*
     * This method verifyPhoneNumber will check to see if the mobile number is valid and associated with the user and 
     * then redirect them to the waiting page which will in turn redirect them to the verification_enter_passcode page
     */
    public void verifyPhoneNumber()  throws Throwable {
        CustomLogger.enter(this.getClass());
  
        // Retrieve address_hash from person_data
        PersonVo personVo = prepareSponsorId();
        PersonData personData = personDataService.findByPK(personVo.getId());
        String phoneNumber = getPhoneNumber();
        
        if (!StringUtils.isEmpty(phoneNumber)) {
        	String phoneNumericOnly = phoneNumber.replaceAll( "[^\\d]", "" );
        	if (phoneNumericOnly.length() != 10) {
        		this.setError(false);
		    	this.setErrorMessage(null);	 
        		setSessionVerifyPhoneError("Please enter a mobile number with 10 digits.");
        		return;
        	}
        	
           	CustomLogger.debug(this.getClass(), String.format("Remote proofing status: User has entered the phone number:%s.", getPhoneNumber()));
            updatePhoneNumberInSession(getPhoneNumber()); 
            setPersonVo(getSessionPersonVo());

            // Clear phone supplier so the user can get the other supplier 
            // or be evaluated for repeat phone verification if they verify again
     		checkPreviousPhoneVerificationDecision(getPerson(), getPersonVo()); 
     		personVo = getSessionPersonVo();
        }
        else {
            CustomLogger.error(this.getClass(), "Phone number entered is null.");
            this.setError(false);
	    	this.setErrorMessage(null);	 
            setSessionVerifyPhoneError("You must enter in a valid U.S. mobile phone number (e.g. XXX-XXX-XXXX)");
            return;
        }
            
        try {
        	DeviceAssessmentParamVo deviceAssessmentParamVo = getSessionDeviceAssessmentParamVo();
        	
        	if (deviceAssessmentParamVo != null) {
	        	RpDeviceReputation deviceReputation = rpDeviceReputationService.getBySessionId(deviceAssessmentParamVo.getSessionId());
	
	            if (deviceReputation != null) {
	                deviceReputation.setMobilePhoneNumber(getPhoneNumber());
	                deviceReputation.setUpdateDate(DateTimeUtil.getCurrentTime());
	                rpDeviceReputationService.update(deviceReputation);
	            }
        	}

            verifyPhone(getPerson(), personVo);
        }
        catch (Exception e) {
            CustomLogger.error(this.getClass(), "Exception occurred on verifyPhone for user: " + getPersonVo().getSponsorUserId(), e);
            goToPage(SYSTEM_ERROR_PAGE);
        }
    }
    
    public void cancelPhoneVerification() {
        CustomLogger.enter(this.getClass());
        
        // Retrieve address_hash from person_data
        PersonVo personVo = getPersonVo();
        String logMsg = "Phone Verification Cancelled for Hold Mail user with sponsorUserId " +  personVo.getSponsorUserId();

        goToPage(VERIFICATION_CANCEL_CONFIRMED);
    }
 
    /**
     * Logic to verify the customer's phone number.  Will only be called if the customer does not have a high risk address 
     * and does have medium confidence device reputation.
     * @throws PhoneVerificationException 
     * @throws IPSException 
     */ 
    private void verifyPhone(Person person, PersonVo personVo)  throws Throwable {
        CustomLogger.enter(this.getClass());
        
        PhoneVerificationResponse pvResponse = null;
  
        verificationParamVo = getVerificationParamVo();
        verificationParamVo.setMobilePhoneNumber(getPhoneNumber());
        personVo.setResetProofingStatus(false);
        String failureMessage = "";
        
        //Check if the device assessment is individualNotFound. If so, the transaction is sent to Experian or Equifax.
        // if deviceReputationResult is null, then individualNotFound = false
        boolean individualNotFound = individualNotFound = DeviceReputationResult.DISCO_FAIL_REASON_INDIVIDUAL_NOT_FOUND.equalsIgnoreCase(personVo.getDiscoveryProductReasonCode());
       	
        setPhoneSupplier(determineVerificationMethod(individualNotFound));
       	personVo.setCurrentPhoneVerificationSupplierId(getPhoneSupplier().getOtpSupplierId());
        // Every time the user goes to the User Information page and clicks Continue, a new event should be created
        try {                               
            // Velocity check for phone verification needs to be done before continuing with the vendor call 
        	personVo.setCallingVelocityType(IPSConstants.VELOCITY_TYPE_PHONE);
        	RefOtpVelocity phoneVelocity = proofingService.phoneVelocityCheck(person, personVo, phoneSupplier);
        	boolean passVelocityCheck = !phoneVelocity.isExceedPhoneVerificationLimit() && !phoneVelocity.isLockoutStillInEffect();
      	
        	if (passVelocityCheck) {
        		if (phoneVelocity.isExceedPhoneRepeatAssessmentLimit()) {
               		goToPage(VERIFICATION_CANCEL_CONFIRMED);
               		return;
              	}
        		
              	CustomLogger.debug(this.getClass(), "Remote proofing status: User has passed phone velocity check.");
    
                // If the EID Decision is not Y, the user's identity cannot be verified
                // Only go to the Unable to Verify/Cancel Confirmed page if the overall assessment is FAIL and EID is N
                
                pvResponse = verifyPhone(personVo);  

           		if (personVo.isAlternateSupplierForCustNotOnFile() && pvResponse != null) {
                    pvResponse.setPhoneVerificationDecision(personVo.getPhoneVerificationDecision());
          			personVo.setAlternateSupplierForCustNotOnFile(false);
           		}
           		
                setSessionPersonVo(personVo);
            } else {
                resetErrorMessage();
                setSessionVerifyPhoneError(null);
                setSessionPersonVo(personVo);
  
                goToPage(VERIFICATION_LOCKOUT);
                return;
            }
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), IPSConstants.REDIRECT_TO_STATUS_ERROR_PAGE + "Error occurred during phone verification for sponsorUserId:" + (person != null? person.getSponsorUserId() : "null"), e);
            goToPage(SYSTEM_ERROR_PAGE);
            return;
        }
        
   		resetErrorMessage();    // Clear error message when phone number verified successfully
   		
        if (pvResponse != null) {
           	personVo.setPhoneNumber(phoneNumber);
        			
        	String pvDecision = pvResponse.getPhoneVerificationDecision();
       		long supplierId = pvResponse.getPhoneVerificationSupplierId();
       		
          	CustomLogger.debug(this.getClass(), String.format("Remote proofing status: Phone verification decision is %s by %s.", 
          			pvDecision, pvResponse.getPhoneVerificationSupplierName()));
        	CustomLogger.debug(this.getClass(), String.format("Remote proofing status: Phone verification supplier Id> From PvResponse: %s, From Person: %s.", 
        			pvResponse.getPhoneVerificationSupplierId(), personVo.getCurrentPhoneVerificationSupplierId()));

          	if (PhoneVerificationResponse.PV_DECISION_PASS.equalsIgnoreCase(pvDecision) 
          			|| PhoneVerificationResponse.PV_DECISION_APPROVE.equalsIgnoreCase(pvDecision)) {
         		if (RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID == supplierId || RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID == supplierId) {
 					if(isHoldMail) {
		                CustomLogger.debug(this.getClass(), "Passcode Confirmed, return to calling app and Calling app is " + callingAppName);
		                returnToCallingApp(IPSConstants.PROOFING_RESULT_PASSED);
		            }else {
		            	// clear error message from prior failures if successful  
			        	setSessionVerifyPhoneError(null);
		            	goToInformedDeliverySuccessPage();
		            }
     			}
         	}
        	else if (PhoneVerificationResponse.PV_DECISION_REVIEW.equalsIgnoreCase(pvDecision)) {
				if (RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID == supplierId) {
     				goToPage(VERIFICATION_SEND_SMFA_PAGE);
     			}
				else if (RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID == supplierId) {
					if (ExperianResultVo.NEXT_ACTION_INIT_BOKU_OTP.equalsIgnoreCase(pvResponse.getNextAction())) {
						goToPage(VERIFICATION_REQUEST_PASSCODE_PAGE);
					} else if (ExperianResultVo.NEXT_ACTION_RESUME_BOKU_OTP.equalsIgnoreCase(pvResponse.getNextAction())) {
						goToPage(VERIFICATION_ENTER_PASSCODE_PAGE);
					} else if (ExperianResultVo.NEXT_ACTION_INVOKE_BOKU_URL.equalsIgnoreCase(pvResponse.getNextAction())) {
						goToPage(String.format("%s?resultid=%s", VERIFICATION_URL_INVOCATION_PAGE, pvResponse.getRecordId()));
					} else if (ExperianResultVo.NEXT_ACTION_SUBMIT_VALID_PHONE.equalsIgnoreCase(pvResponse.getNextAction())) {
		                setSessionVerifyPhoneError(IPSConstants.UNABLE_TO_VERIFY_PHONE_MSG);
						goToPage(VERIFICATION_USER_INFO_PAGE);
					}
					else {
						goToPage(VERIFICATION_USER_INFO_PAGE);
					}
     			} else {
     				goToPage(VERIFICATION_REQUEST_PASSCODE_PAGE);
            	}
        	} else  {
        		if (RefOtpSupplier.LEXISNEXIS_RDP_OTP_SUPPLIER_ID == supplierId) {
                  	boolean isPassedLexisNexisCurrentResidencyCheck = isPassedLexisNexisCurrentResidencyCheck();

                  	String logMsgFmt = "Phone verification with LexisNexis has failed and current residency check has %s.";
                  	if (isPassedLexisNexisCurrentResidencyCheck) {
                  		personVo.setRenderErrorMessage(true);
                  		setSessionPersonVo(personVo);
                        setSessionVerifyPhoneError(IPSConstants.UNABLE_TO_VERIFY_PHONE_MSG);
                 		goToPage(VERIFICATION_USER_INFO_PAGE);
                  	} else {
                  		failureMessage = String.format(logMsgFmt, "failed");
                   		goToPage(UNABLE_TO_VERIFY_PAGE);
                  	}
                } else if (RefOtpSupplier.EQUIFAX_IDFS_OTP_SUPPLIER_ID == supplierId) {
                	failureMessage = "Phone verification with Equifax IDFS has failed.";
           			goToPage(UNABLE_TO_VERIFY_PAGE);
        		} else if (RefOtpSupplier.EXPERIAN_CROSSCORE_SUPPLIER_ID == supplierId) {
        			failureMessage = "Phone verification with Experian PreciseID has failed.";

        			if (Utils.isEmptyString(pvResponse.getEventFinalDecision())) {
                 		personVo.setRenderErrorMessage(true);
                  		setSessionPersonVo(personVo);
                        setSessionVerifyPhoneError(IPSConstants.UNABLE_TO_VERIFY_PHONE_MSG);
                  		goToPage(VERIFICATION_USER_INFO_PAGE);
        			} else {
           				goToPage(UNABLE_TO_VERIFY_PAGE);
        			}
        		} else if (RefOtpSupplier.EQUIFAX_DIT_SMFA_SUPPLIER_ID == supplierId) { 
    				if (PhoneVerificationResponse.PV_DECISION_FAIL.equalsIgnoreCase(pvDecision) || PhoneVerificationResponse.PV_DECISION_DENY.equalsIgnoreCase(pvDecision)) {
	        			personVo.setDitDecision(pvDecision);
	        			setSessionPersonVo(personVo);
	       				failureMessage = "Phone verification with Equifax DIT has failed.";
	        			goToPage(UNABLE_TO_VERIFY_PAGE);
    				}
        		}
             }
         }else {
         	goToPage(UNABLE_TO_VERIFY_PAGE);
   		}
     }

    @Override
    public String getPhoneNumber() {
        CustomLogger.enter(this.getClass());

        if (phoneNumber == null) {
        	PersonVo personVo = getPersonVo(); 
          	phoneNumber = personVo.getMobileNumber();
        }

        if(phoneNumber != null && phoneNumber.length() > 10 ) {
            phoneNumber = Utils.removeNonNumericCharactersFromString(phoneNumber);
        }
        return phoneNumber;
    }

    public String getPhoneNumberForUI() {
        CustomLogger.enter(this.getClass());
        
        // Since this bean is SessionScoped, the phone number should always
        // be retrieved from the database to ensure that a previous user's
        // phone number from the same browser session is not used
        getSavedPhone();
        setPersonVo(getSessionPersonVo());
        setPhoneNumber(getPersonVo().getMobileNumber());
        
        if(!phoneNumber.isEmpty()) {
                String number = phoneNumber.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");
                CustomLogger.debug(this.getClass(), "Phone number returned by getPhoneNumberForUI " + number);
                return number;
        } else {
            return "";
        }
    }
    
    @Override
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public void resetErrorMessage() {
        CustomLogger.enter(this.getClass());
        
        setSessionVerifyPhoneError(null);
        getPersonVo().setMobileNumber(phoneNumber);
    }

    private PhoneVerificationResponse verifyPhone(PersonVo personVo) throws Throwable {
        CustomLogger.enter(this.getClass());
 
        // SponsorId is getting wiped out between calls to verifyPhone causing issues with supplier failover - make sure it's set
        personVo.setSponsorId(RefSponsor.SPONSOR_ID_CUSTREG);
        personVo.setTransactionOriginAppName(isHoldMail ? RefApp.HOLD_MAIL : RefApp.INFORMED_DELIVERY);
        personVo.setAppId(isHoldMail ? RefApp.HOLD_MAIL_APP_ID : RefApp.INFORMED_DELIVERY_APP_ID);
        PhoneVerificationResponse pvResponse = null;
        RefOtpSupplier otpSupplier = null;
        
        try {
        	personVo.setWebServiceCall(false);
         	otpSupplier = getPhoneSupplier();
          	pvResponse = phoneVerificationService.verifyPhone(personVo, otpSupplier);
		} catch (Exception e) {
			CustomLogger.error(this.getClass(), String.format("Exception occurred on verifying phone with %s for user: %s", 
					(otpSupplier != null ? otpSupplier.getOtpSupplierName() : "null"), personVo.getSponsorUserId()), e);
		}
        
        if (getPhoneSupplier().isLexisNexisPhone()) {
        	setPassedLexisNexisCurrentResidencyCheck(phoneVerificationService.isPrecheckPassed());
        }        
        return pvResponse;
    }
      
    private PersonVo prepareSponsorId() {
          CustomLogger.enter(this.getClass());
          
        PersonVo personVo = getPersonVo();
        personVo.setSponsorId(RefSponsor.SPONSOR_ID_CUSTREG);
        personVo.setTransactionOriginAppName(isHoldMail ? RefApp.HOLD_MAIL : RefApp.INFORMED_DELIVERY);
        return personVo;
    }
      
    /**
     * This is needed for the case where switching is configured between the OTP suppliers.  If the call switches to the other supplier, the correct
     * event must be retrieved.
     * @return
     */
    public RpEvent getLatestEvent() {    
        CustomLogger.enter(this.getClass());
        
        RpEvent event = null;
        
        List<RpEvent> events = eventService.findEventByPersonId(getSessionPersonVo().getId());
        if (!events.isEmpty()) {
            event = events.get(0);
            phoneSupplier = event.getRefOtpSupplier();
        }
        
        return event;
    }
       
    private void checkPreviousPhoneVerificationDecision(Person person, PersonVo personVo) {
	    //Previous phone verification decision check needs to be done to determine if there was one.
	    boolean hasPreviousPhoneVerificationDecision = false;
	    RefOtpSupplier prevSupplier = null;
	    
		try {
			hasPreviousPhoneVerificationDecision = phoneVerificationService.hasPreviousPhoneVerificationDecision(person, personVo,  verificationParamVo);
		} catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error occurred in checking previous phone verification decision: ", e);
        }  
	
	    // Retrieve the phone supplier that is set if it has previous phone verification decision.
	    if (hasPreviousPhoneVerificationDecision) {  
	       	CustomLogger.debug(this.getClass(), "Remote proofing status: User has previous phone verification.");
  
	       	long prevSupplierId = personVo.getPreviousPhoneVerificationSupplierId();
	    	personVo.setCurrentPhoneVerificationSupplierId(prevSupplierId);
	       	prevSupplier = supplierService.findBySupplierId(prevSupplierId);
            setPhoneSupplier(prevSupplier);
 	    } 
	    else {	 
	       	CustomLogger.debug(this.getClass(), "User has no previous phone verification. User is getting new phone supplier.");
   	        // If there was no previous phone verification decision,
	       	// clear phone supplier so the user can get the other supplier. 
	    }
	    
        setSessionPersonVo(personVo);
    }
    
	public void redirectPage() {
        CustomLogger.enter(this.getClass());
        
        HttpSession session = getHttpServletRequest().getSession();
        String nextPageUrl =(String) session.getAttribute(IPSConstants.REDIRECT_PAGE_URL_KEY);
         
        try {
        	if (nextPageUrl != null) {
       	       	session.setAttribute(IPSConstants.REDIRECT_PAGE_URL_KEY, null);
        		FacesContext.getCurrentInstance().getExternalContext().redirect(nextPageUrl);
        	}
		} catch (IOException e) {
	        CustomLogger.error(this.getClass(), "redirectPage to page=" + nextPageUrl);
		}  
	}
    
	@Override
    public String getErrorMessage() {
        return errorMessage;
    }

	@Override
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public RefOtpSupplier getPhoneSupplier() {
 
        // if the phone supplier is not set because this is an existing user returning to IVS,
        // then determineVerificationMethod can be called.  It must not be called again for a new user.
        if (phoneSupplier == null) {
        	 setPhoneSupplier(determineVerificationMethod(false));
        }
        
        return phoneSupplier;
    }

    public void setPhoneSupplier(RefOtpSupplier phoneSupplier) {
        this.phoneSupplier = phoneSupplier;
    }

    public boolean isInitialized() {
        CustomLogger.enter(this.getClass(), "isInitialized()=" + initialized);
        
        return initialized;
    }

    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }

    public PhoneVerificationParamVo getVerificationParamVo() {
        if (verificationParamVo == null) {
            verificationParamVo = new PhoneVerificationParamVo();
        }
        return verificationParamVo;
    }

    public void setVerificationParamVo(PhoneVerificationParamVo verificationParamVo) {
        this.verificationParamVo = verificationParamVo;
    }

	public String getVerificationErrorMessage() {
		return verificationErrorMessage;
	}

	public void setVerificationErrorMessage(String verificationErrorMessage) {
		this.verificationErrorMessage = verificationErrorMessage;
	}

	public boolean isVerificationError() {
		return verificationError;
	}

	public void setVerificationError(boolean verificationError) {
		this.verificationError = verificationError;
	}
}
