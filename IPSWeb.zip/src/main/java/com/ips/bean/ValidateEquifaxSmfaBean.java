package com.ips.bean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.springframework.web.context.support.WebApplicationContextUtils;

import com.equifax.smfa.response.ResponseStatusModel;
import com.ips.common.common.CustomLogger;
import com.ips.common.common.SpringUtil;
import com.ips.entity.Person;
import com.ips.entity.PersonProofingStatus;
import com.ips.entity.RefLoaLevel;
import com.ips.entity.RefOtpSupplier;
import com.ips.entity.RefRpStatus;
import com.ips.entity.RefSponsor;
import com.ips.entity.RefSponsorConfiguration;
import com.ips.exception.IPSException;
import com.ips.exception.PhoneVerificationException;
import com.ips.persistence.common.IPSConstants;
import com.ips.persistence.common.PersonVo;
import com.ips.proofing.EquifaxService;
import com.ips.proofing.EquifaxServiceImpl;
import com.ips.proofing.ProofingService;
import com.ips.proofing.ProofingServiceImpl;
import com.ips.service.PersonDataService;
import com.ips.service.PersonProofingStatusService;
import com.ips.service.RefLoaLevelService;
import com.ips.service.RefSponsorConfigurationService;
import com.ips.service.RefSponsorDataService;

import io.jsonwebtoken.io.IOException;

@ManagedBean(name="validateEquifaxSmfa")
@SessionScoped
public class ValidateEquifaxSmfaBean extends VerificationBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private RefLoaLevelService refLoaLevelService;
    private PersonProofingStatusService personProofingStatusService;
    private String linkValidationStatus;
    private boolean showResendLink;
    private int pageLoads;
    
    public void getColor() {
        CustomLogger.enter(this.getClass());
        
   	 	String smfaStatus = "";
   	 	setPageLoads(getPageLoads() + 1);
   	 	if (10 < getPageLoads()) {
   	 		setPageLoads(0);
   	 		goToPage(VERIFICATION_SEND_SMFA_PAGE);
   	 	}
   	 	else {
	   	 	try {
	   	 		smfaStatus = getColorResult();
	   	 	}
	   	 	catch (IPSException e) {
	            CustomLogger.warn(this.getClass(), "IPSException occurred getting SMFA verify result", e);
				return;
	   	 	}
	   	 	catch (PhoneVerificationException pve) {
	            CustomLogger.warn(this.getClass(), "PhoneVerificationException occurred getting SMFA verify result", pve);
				return;
	   	 	}

		   	 switch(smfaStatus) {
				case ResponseStatusModel.RESPONSE_PATH_GREEN:  
				case ResponseStatusModel.RESPONSE_PATH_YELLOW:  
					goToPage(VERIFICATION_VALIDATE_SMFA_GREEN_PAGE);
					break;
				case ResponseStatusModel.RESPONSE_PATH_ORANGE: 
				case ResponseStatusModel.RESPONSE_PATH_RED:  
					goToPage(VERIFICATION_VALIDATE_SMFA_RED_PAGE);
					break;
				default:                   
					break;
		   	 }
   	 	}
   	 }
    
    private String getColorResult() throws IPSException, PhoneVerificationException, IOException {
		ServletContext context = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
         EquifaxService equifaxService = WebApplicationContextUtils.getWebApplicationContext(context).getBean(EQUIFAX_SERVICE, EquifaxServiceImpl.class);
         PersonDataService personService = (PersonDataService)SpringUtil.getInstance(context).getBean(PERSON_DATA_SERVICE);
  	     ProofingService proofingService = WebApplicationContextUtils.getWebApplicationContext(context).getBean(PROOFING_SERVICE, ProofingServiceImpl.class);
         refLoaLevelService = (RefLoaLevelService)SpringUtil.getInstance(context).getBean(REF_LOA_LEVEL_SERVICE);
         personProofingStatusService = (PersonProofingStatusService)SpringUtil.getInstance(context).getBean(PERSON_PROOFING_STATUS_SERVICE);

         boolean hasException = true;
  	     setSponsorUserInfo();

         PersonVo personVo = getSessionPersonVo();
         // getting null pointer exception on next line because personVo is null after session timeout and get redirected back to this page
         CustomLogger.info(this.getClass(), "Validate Equifax SMFA fetching person with person id: " 
                 + personVo.getId());
         // getting NullPointerException on this next line when the session times out on the smfa validate page
         Person person = personService.findByPK(personVo.getId()); 
         /*
          * LOA level achieved (10) IPS_OWN.REF_RP_STATUS
          */
         // D-68692 SMFA Validate is getting called after user was successfully proofed or failed validation.
         // determine the person has already achieved LOA 1.5 and return the color yellow, because we do not know if it is green or yellow
         // this will prevent another row from being persisted to rp_smfa_validate_response table
         if (person.getAchievedLoaLevel() != null
        		 && person.getAchievedLoaLevel().getLoaLevel() != null
        		 && "1.5".equals(person.getAchievedLoaLevel().getLoaLevel())) {
             CustomLogger.debug(this.getClass(), "SMFA Validate person has already achieved LOA 1.5, returning yellow");
             return ResponseStatusModel.RESPONSE_PATH_YELLOW;
         }
         /*
          * SMFA validation failed (30) IPS_OWN.REF_RP_STATUS
          */
         // D-68692 SMFA Validate is getting called after user was successfully proofed or failed validation.
         // Need to handle the SMFA validation failed (30) condition and not call SMFA Validate again
         PersonProofingStatus personProofingStatus = personProofingStatusService.getByPersonId((int)getPersonVo().getId());

         if (personProofingStatus != null && personProofingStatus.getStatusCode().equals(RefRpStatus.RpStatus.SMFA_validation_failed.getValue())) {
             CustomLogger.debug(this.getClass(), "SMFA Validate person has already failed SMFA Validation, returning red");
             return ResponseStatusModel.RESPONSE_PATH_RED;
         }

         String smfaStatus = "";
         try {
             smfaStatus = equifaxService.getSmfaStatus(personVo, true);
   		} 
        catch (Exception e) {
 			CustomLogger.error(this.getClass(), "Exception occurred in getting StatusSMFARequestModel request.", e);
 			return "";
  		}

       	if ("Token expired".equalsIgnoreCase(smfaStatus)) {
			try {
				String bearerToken = equifaxService.generateEquifaxBearerToken(EquifaxServiceImpl.EQUIFAX_SMFA_OAUTH_SCOPE,
						EquifaxServiceImpl.EQUIFAX_SMFA_TOKEN_TYPE, true);
				personVo.setSmfaToken(bearerToken);
				smfaStatus = equifaxService.getSmfaStatus(personVo, false);
			} catch (Exception e) {
		      	CustomLogger.error(this.getClass(), "Generic Exception occured in obtaining new token. Exception Message:" + e.getMessage(), e);  
		      	return "";
			}
       	}

       	if (IPSConstants.STATUS_ERROR.equalsIgnoreCase(smfaStatus)) {
			try {
				String bearerToken = equifaxService.generateEquifaxBearerToken(EquifaxServiceImpl.EQUIFAX_SMFA_OAUTH_SCOPE,
						EquifaxServiceImpl.EQUIFAX_SMFA_TOKEN_TYPE, true);
				personVo.setSmfaToken(bearerToken);
				
				int attmptCtr = 0;
				boolean hasError = true;

				do {
					attmptCtr = attmptCtr + 1;
					if (attmptCtr >= 2) {
						CustomLogger.error(this.getClass(), "Equifax SMFA call repeating for 422 error " + attmptCtr + " times");
					}
					
					smfaStatus = equifaxService.getSmfaStatus(personVo, false);
					hasError = IPSConstants.STATUS_ERROR.equalsIgnoreCase(smfaStatus);
				} while (attmptCtr <= 3 && (hasError));
			} catch (Exception e) {
		      	CustomLogger.error(this.getClass(), "Generic Exception occured in obtaining SMFA Status. Exception Message:" + e.getMessage(), e);  
		      	return "";
			}
       	 }

         return smfaStatus;
	}
 
    
    /*
     * Public method exposed to xhtml page
     */
    public int getSecondsBetweenPolling() {
    	return secondsBetweenPolling();
    }
    
    private int secondsBetweenPolling() {
        CustomLogger.enter(this.getClass());

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        String configValue = null;
        RefSponsorConfiguration sponsorConfig = null;

        try {
            RefSponsorDataService refSponsorService = (RefSponsorDataService)SpringUtil.getInstance(ctx).getBean(REF_SPONSOR_DATA_SERVICE);
            RefSponsorConfigurationService refSponsorConfigService = (RefSponsorConfigurationService)SpringUtil.getInstance(ctx).getBean(REF_SPONSOR_CNFIG_SERVICE);
            
            // This method is only called from the front end so Sponsor will be CustReg
            RefSponsor sponsor = refSponsorService.findByPK(RefSponsor.SPONSOR_ID_CUSTREG);
			sponsorConfig = refSponsorConfigService.getConfigRecord((int)sponsor.getSponsorId()
					, RefSponsorConfiguration.EQUIFAX_SECONDS_BETWEEN_POLLING);
            configValue = sponsorConfig.getValue();
           
            return Integer.parseInt(configValue);
         } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error in getting Equifax.SecondsBetweenPolling config value.", e);
            return -1;
        }
    }

    /**
     * public method exposed to xhtml page
     */
    public int getSecondsBeforeResendLink() {
    	return secondsBeforeResendLink();
    }
    
    private int secondsBeforeResendLink() {
        CustomLogger.enter(this.getClass());

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        String configValue = null;
        RefSponsorConfiguration sponsorConfig = null;

        try {
            RefSponsorDataService refSponsorService = (RefSponsorDataService)SpringUtil.getInstance(ctx).getBean(REF_SPONSOR_DATA_SERVICE);
            RefSponsorConfigurationService refSponsorConfigService = (RefSponsorConfigurationService)SpringUtil.getInstance(ctx).getBean(REF_SPONSOR_CNFIG_SERVICE);
            
            // This method is only called from the front end so Sponsor will be CustReg
            RefSponsor sponsor = refSponsorService.findByPK(RefSponsor.SPONSOR_ID_CUSTREG);
			sponsorConfig = refSponsorConfigService.getConfigRecord((int) sponsor.getSponsorId()
					, RefSponsorConfiguration.EQUIFAX_SECONDS_BEFORE_RESEND_LINK);
            configValue = sponsorConfig.getValue();
            
            return Integer.parseInt(configValue);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error in getting Equifax.SecondsBeforeResendLink config value.", e);
            return -1;
        }
    }
    
    /**
     * public method exposed to xhtml page
     */
    public int getPollingMinutes() {
    	return pollingMinutes();
    }
    
    private int pollingMinutes() {
        CustomLogger.enter(this.getClass());

		ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
        String configValue = null;
        RefSponsorConfiguration sponsorConfig = null;

        try {
            RefSponsorDataService refSponsorService = (RefSponsorDataService)SpringUtil.getInstance(ctx).getBean(REF_SPONSOR_DATA_SERVICE);
            RefSponsorConfigurationService refSponsorConfigService = (RefSponsorConfigurationService)SpringUtil.getInstance(ctx).getBean(REF_SPONSOR_CNFIG_SERVICE);
            
            // This method is only called from the front end so Sponsor will be CustReg
            RefSponsor sponsor = refSponsorService.findByPK(RefSponsor.SPONSOR_ID_CUSTREG);
			sponsorConfig = refSponsorConfigService.getConfigRecord((int) sponsor.getSponsorId()
					, RefSponsorConfiguration.EQUIFAX_POLLING_MINUTES);
            configValue = sponsorConfig.getValue();
            
            return Integer.parseInt(configValue);
        } catch (Exception e) {
            CustomLogger.error(this.getClass(), "Error in getting Equifax.PollingMinutes config value.", e);
            return -1;
        }
    }
    
	public String getLinkValidationStatus() {
		return linkValidationStatus;
	}

	public void setLinkValidationStatus(String linkValidationStatus) {
		this.linkValidationStatus = linkValidationStatus;
	}

	// validateEquifaxSmfa.displayResendLink
	/**
	 * If 45 seconds have passed since the page loaded then display the link to resend the link to the phone
	 */
	public boolean displayResendLink() {
        CustomLogger.enter(this.getClass());
		int secondsBetweenPolling = secondsBetweenPolling();
		int secondsBeforeResendLink = secondsBeforeResendLink();
		int pageLoads2 = getPageLoads();
		// check math
        CustomLogger.debug(this.getClass(), "secondsBetweenPolling=" + secondsBetweenPolling);
        CustomLogger.debug(this.getClass(), "secondsBeforeResendLink=" + secondsBeforeResendLink);
        CustomLogger.debug(this.getClass(), "pageLoads2=" + pageLoads2);

        showResendLink = (pageLoads2) >= (secondsBeforeResendLink / secondsBetweenPolling);
 		return isShowResendLink();
	}
	
	public void redirectToUnableToVerify() {
        CustomLogger.enter(this.getClass());
        goToPage(UNABLE_TO_VERIFY_PAGE);
	}
	
    public String getMaskedPhoneNumberForUI() {
    	return this.getVerificationMaskedPhoneNumberForUI();
    }

	public boolean isShowResendLink() {
		return showResendLink;
	}

	public void setShowResendLink(boolean showResendLink) {
		this.showResendLink = showResendLink;
	}

	public int getPageLoads() {
		return pageLoads;
	}

	public void setPageLoads(int pageLoads) {
		this.pageLoads = pageLoads;
	}
	
	public void continueToSuccessPage() {
		returnToCallingApp(IPSConstants.PROOFING_RESULT_PASSED);
	}

}
