package com.ips.servlet;

import java.io.Serializable;

import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.servlet.http.HttpServletResponse;

import com.ips.common.common.CustomLogger;

public class CacheControlPhaseListener implements PhaseListener, Serializable {

    private static final long serialVersionUID = 1L;

    @Override
    public PhaseId getPhaseId()
    {
        return PhaseId.RENDER_RESPONSE;
    }

    @Override
    public void afterPhase(PhaseEvent event)
    {
    //TODO why is this empty
    }

    @Override
    public void beforePhase(PhaseEvent event)
    {
        FacesContext facesContext = event.getFacesContext();
        String requestServletPath = facesContext.getExternalContext().getRequestServletPath();
        
        CustomLogger.debug(this.getClass(), "Request servlet path: " + requestServletPath);
        
        if (requestServletPath != null && (requestServletPath.endsWith("xhtml") || requestServletPath.endsWith("css"))) {
            HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
            response.addHeader("Pragma", "no-cache");
            response.addHeader("Cache-Control", "no-cache");
            // Stronger according to blog comment below that references HTTP spec
            response.addHeader("Cache-Control", "no-store");
            response.addHeader("Cache-Control", "must-revalidate");
            // some date in the past
            response.addHeader("Expires", "Mon, 8 Aug 2006 10:00:00 GMT");
            response.addHeader("X-Content-Type-Options", "nosniff");
        }
    }

}
