package com.ips.servlet.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

public class NoopFilter implements Filter{

    @Override
    public void destroy() {
        //Nothing to do here
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        //Ignore further filtering, dispatch the request
        request.getRequestDispatcher(((HttpServletRequest) request).getServletPath() + StringUtils.defaultString(((HttpServletRequest)request).getPathInfo())).forward(request,response);
    }
    
    @Override
    public void init(FilterConfig arg0) throws ServletException {
        //Nothing to do here
    }
    
}
